
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $scm, $so, $scp, $snv, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Drawing.Primitives", 
    {"h":48939,"f":"System.Drawing.Primitives","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Drawing.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Drawing.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdp.System.Drawing.KnownColorNames", ($self) => class KnownColorNames
        {
            /*string[]*/ static s_colorNameTable = null;
            static /*string */ KnownColorToName(/*KnownColor*/ color)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(color > 0 && color <= 175/*KnownColor.RebeccaPurple*/, "color > 0 && color <= KnownColor.RebeccaPurple");
                return $.$spc.System.Array.$ReadT1.call($.$sdp.System.Drawing.KnownColorNames.s_colorNameTable, ((color - 1) | 0));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_colorNameTable = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), ["ActiveBorder", "ActiveCaption", "ActiveCaptionText", "AppWorkspace", "Control", "ControlDark", "ControlDarkDark", "ControlLight", "ControlLightLight", "ControlText", "Desktop", "GrayText", "Highlight", "HighlightText", "HotTrack", "InactiveBorder", "InactiveCaption", "InactiveCaptionText", "Info", "InfoText", "Menu", "MenuText", "ScrollBar", "Window", "WindowFrame", "WindowText", "Transparent", "AliceBlue", "AntiqueWhite", "Aqua", "Aquamarine", "Azure", "Beige", "Bisque", "Black", "BlanchedAlmond", "Blue", "BlueViolet", "Brown", "BurlyWood", "CadetBlue", "Chartreuse", "Chocolate", "Coral", "CornflowerBlue", "Cornsilk", "Crimson", "Cyan", "DarkBlue", "DarkCyan", "DarkGoldenrod", "DarkGray", "DarkGreen", "DarkKhaki", "DarkMagenta", "DarkOliveGreen", "DarkOrange", "DarkOrchid", "DarkRed", "DarkSalmon", "DarkSeaGreen", "DarkSlateBlue", "DarkSlateGray", "DarkTurquoise", "DarkViolet", "DeepPink", "DeepSkyBlue", "DimGray", "DodgerBlue", "Firebrick", "FloralWhite", "ForestGreen", "Fuchsia", "Gainsboro", "GhostWhite", "Gold", "Goldenrod", "Gray", "Green", "GreenYellow", "Honeydew", "HotPink", "IndianRed", "Indigo", "Ivory", "Khaki", "Lavender", "LavenderBlush", "LawnGreen", "LemonChiffon", "LightBlue", "LightCoral", "LightCyan", "LightGoldenrodYellow", "LightGray", "LightGreen", "LightPink", "LightSalmon", "LightSeaGreen", "LightSkyBlue", "LightSlateGray", "LightSteelBlue", "LightYellow", "Lime", "LimeGreen", "Linen", "Magenta", "Maroon", "MediumAquamarine", "MediumBlue", "MediumOrchid", "MediumPurple", "MediumSeaGreen", "MediumSlateBlue", "MediumSpringGreen", "MediumTurquoise", "MediumVioletRed", "MidnightBlue", "MintCream", "MistyRose", "Moccasin", "NavajoWhite", "Navy", "OldLace", "Olive", "OliveDrab", "Orange", "OrangeRed", "Orchid", "PaleGoldenrod", "PaleGreen", "PaleTurquoise", "PaleVioletRed", "PapayaWhip", "PeachPuff", "Peru", "Pink", "Plum", "PowderBlue", "Purple", "Red", "RosyBrown", "RoyalBlue", "SaddleBrown", "Salmon", "SandyBrown", "SeaGreen", "SeaShell", "Sienna", "Silver", "SkyBlue", "SlateBlue", "SlateGray", "Snow", "SpringGreen", "SteelBlue", "Tan", "Teal", "Thistle", "Tomato", "Turquoise", "Violet", "Wheat", "White", "WhiteSmoke", "Yellow", "YellowGreen", "ButtonFace", "ButtonHighlight", "ButtonShadow", "GradientActiveCaption", "GradientInactiveCaption", "MenuBar", "MenuHighlight", "RebeccaPurple"], [-1], null);
                }
            }
            static $h = 442155;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"color","p":376619}],"n":"KnownColorToName","d":442155,"h":8590376747,"f":33}],"l":[{"t":0,"n":"s_colorNameTable","d":442155,"h":4295409451,"f":34}],"h":442155}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.KnownColorNames`; }
        });
        
        $asm.$cls("$sdp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sdp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Drawing.Primitives", $.$sdp.System.SR.$type.Assembly);
                    $.$sdp.System.SR.s_resourceManager = temp;
                }
                return $.$sdp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sdp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sdp.System.SR.resourceCulture = value;
            }
            static /*string */ get ConvertInvalidPrimitive()
            {
                return "{0} is not a valid value for {1}.";
            }
            static /*string */ FormatConvertInvalidPrimitive(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("{0} is not a valid value for {1}.", arg1, arg2);
            }
            static /*string */ get InvalidColor()
            {
                return "Color '{0}' is not valid.";
            }
            static /*string */ FormatInvalidColor(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Color '{0}' is not valid.", arg1);
            }
            static /*string */ get InvalidEx2BoundArgument()
            {
                return "Value of '{1}' is not valid for '{0}'. '{0}' should be greater than or equal to {2} and less than or equal to {3}.";
            }
            static /*string */ FormatInvalidEx2BoundArgument(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4, /*object*/ arg5)
            {
                return $.$spc.System.String.Format$4("Value of '{1}' is not valid for '{0}'. '{0}' should be greater than or equal to {2} and less than or equal to {3}.", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg1, arg2, arg3, arg4, arg5 ]));
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sdp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sdp.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sdp.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sdp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1097515;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1097515}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sdp.System.Experimentals", ($self) => class Experimentals
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static TensorTDiagId = null;
            /*string*/ static SystemColorsDiagId = null;
            /*string*/ static ArmSveDiagId = null;
            /*string*/ static X86BaseDivRemDiagId = null;
            /*string*/ static PostQuantumCryptographyDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.TensorTDiagId = "SYSLIB5001";
                }
                {
                    this.SystemColorsDiagId = "SYSLIB5002";
                }
                {
                    this.ArmSveDiagId = "SYSLIB5003";
                }
                {
                    this.X86BaseDivRemDiagId = "SYSLIB5004";
                }
                {
                    this.PostQuantumCryptographyDiagId = "SYSLIB5006";
                }
            }
            static $h = 1031979;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":1031979,"h":4295999275,"f":40},{"t":1310721,"n":"TensorTDiagId","d":1031979,"h":8590966571,"f":40},{"t":1310721,"n":"SystemColorsDiagId","d":1031979,"h":12885933867,"f":40},{"t":1310721,"n":"ArmSveDiagId","d":1031979,"h":17180901163,"f":40},{"t":1310721,"n":"X86BaseDivRemDiagId","d":1031979,"h":21475868459,"f":40},{"t":1310721,"n":"PostQuantumCryptographyDiagId","d":1031979,"h":25770835755,"f":40}],"h":1031979}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Experimentals`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.SystemColors", ($self) => class SystemColors
        {
            /*bool*/ static s_useAlternativeColorSet = false;
            static /*Color */ get ActiveBorder()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/);
            }
            static /*Color */ get ActiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/);
            }
            static /*Color */ get ActiveCaptionText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/);
            }
            static /*Color */ get AppWorkspace()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/);
            }
            static /*Color */ get ButtonFace()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(168/*KnownColor.ButtonFace*/);
            }
            static /*Color */ get ButtonHighlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(169/*KnownColor.ButtonHighlight*/);
            }
            static /*Color */ get ButtonShadow()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(170/*KnownColor.ButtonShadow*/);
            }
            static /*Color */ get Control()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/);
            }
            static /*Color */ get ControlDark()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/);
            }
            static /*Color */ get ControlDarkDark()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/);
            }
            static /*Color */ get ControlLight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/);
            }
            static /*Color */ get ControlLightLight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/);
            }
            static /*Color */ get ControlText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/);
            }
            static /*Color */ get Desktop()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/);
            }
            static /*Color */ get GradientActiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(171/*KnownColor.GradientActiveCaption*/);
            }
            static /*Color */ get GradientInactiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(172/*KnownColor.GradientInactiveCaption*/);
            }
            static /*Color */ get GrayText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/);
            }
            static /*Color */ get Highlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/);
            }
            static /*Color */ get HighlightText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/);
            }
            static /*Color */ get HotTrack()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(15/*KnownColor.HotTrack*/);
            }
            static /*Color */ get InactiveBorder()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/);
            }
            static /*Color */ get InactiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/);
            }
            static /*Color */ get InactiveCaptionText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/);
            }
            static /*Color */ get Info()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/);
            }
            static /*Color */ get InfoText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/);
            }
            static /*Color */ get Menu()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/);
            }
            static /*Color */ get MenuBar()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(173/*KnownColor.MenuBar*/);
            }
            static /*Color */ get MenuHighlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(174/*KnownColor.MenuHighlight*/);
            }
            static /*Color */ get MenuText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/);
            }
            static /*Color */ get ScrollBar()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/);
            }
            static /*Color */ get Window()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/);
            }
            static /*Color */ get WindowFrame()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/);
            }
            static /*Color */ get WindowText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/);
            }
            static /*bool */ get UseAlternativeColorSet()
            {
                return $.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet;
            }
            static /*bool */ set UseAlternativeColorSet(value)
            {
                $.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet = value;
            }
            static $h = 966443;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":114475,"g":{"r":0,"d":0,"h":12885868331,"f":33},"n":"ActiveBorder","d":966443,"h":8590901035,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":21475802923,"f":33},"n":"ActiveCaption","d":966443,"h":17180835627,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":30065737515,"f":33},"n":"ActiveCaptionText","d":966443,"h":25770770219,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":38655672107,"f":33},"n":"AppWorkspace","d":966443,"h":34360704811,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":47245606699,"f":33},"n":"ButtonFace","d":966443,"h":42950639403,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":55835541291,"f":33},"n":"ButtonHighlight","d":966443,"h":51540573995,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":64425475883,"f":33},"n":"ButtonShadow","d":966443,"h":60130508587,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":73015410475,"f":33},"n":"Control","d":966443,"h":68720443179,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":81605345067,"f":33},"n":"ControlDark","d":966443,"h":77310377771,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":90195279659,"f":33},"n":"ControlDarkDark","d":966443,"h":85900312363,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":98785214251,"f":33},"n":"ControlLight","d":966443,"h":94490246955,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":107375148843,"f":33},"n":"ControlLightLight","d":966443,"h":103080181547,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":115965083435,"f":33},"n":"ControlText","d":966443,"h":111670116139,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":124555018027,"f":33},"n":"Desktop","d":966443,"h":120260050731,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":133144952619,"f":33},"n":"GradientActiveCaption","d":966443,"h":128849985323,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":141734887211,"f":33},"n":"GradientInactiveCaption","d":966443,"h":137439919915,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":150324821803,"f":33},"n":"GrayText","d":966443,"h":146029854507,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":158914756395,"f":33},"n":"Highlight","d":966443,"h":154619789099,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":167504690987,"f":33},"n":"HighlightText","d":966443,"h":163209723691,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":176094625579,"f":33},"n":"HotTrack","d":966443,"h":171799658283,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":184684560171,"f":33},"n":"InactiveBorder","d":966443,"h":180389592875,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":193274494763,"f":33},"n":"InactiveCaption","d":966443,"h":188979527467,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":201864429355,"f":33},"n":"InactiveCaptionText","d":966443,"h":197569462059,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":210454363947,"f":33},"n":"Info","d":966443,"h":206159396651,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":219044298539,"f":33},"n":"InfoText","d":966443,"h":214749331243,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":227634233131,"f":33},"n":"Menu","d":966443,"h":223339265835,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":236224167723,"f":33},"n":"MenuBar","d":966443,"h":231929200427,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":244814102315,"f":33},"n":"MenuHighlight","d":966443,"h":240519135019,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":253404036907,"f":33},"n":"MenuText","d":966443,"h":249109069611,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":261993971499,"f":33},"n":"ScrollBar","d":966443,"h":257699004203,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":270583906091,"f":33},"n":"Window","d":966443,"h":266288938795,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":279173840683,"f":33},"n":"WindowFrame","d":966443,"h":274878873387,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":287763775275,"f":33},"n":"WindowText","d":966443,"h":283468807979,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":296353709867,"f":33},"s":{"r":0,"d":0,"h":300648677163,"f":33},"n":"UseAlternativeColorSet","d":966443,"h":292058742571,"f":33}],"l":[{"t":262145,"n":"s_useAlternativeColorSet","d":966443,"h":4295933739,"f":40}],"h":966443}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.SystemColors`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorTable", ($self) => class ColorTable
        {
            /*Lazy<Dictionary<string, Color>>*/ static s_colorConstants = null;
            static /*Dictionary<string, Color> */ GetColors()
            {
                /*var*/ let colors = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color))().$ctor$3($.$spc.System.StringComparer.OrdinalIgnoreCase);
                $.$sdp.System.Drawing.ColorTable.FillWithProperties(colors, $.$sdp.System.Drawing.Color.$type);
                $.$sdp.System.Drawing.ColorTable.FillWithProperties(colors, $.$sdp.System.Drawing.SystemColors.$type);
                return colors;
            }
            static /*void */ FillWithProperties(/*Dictionary<string, Color>*/ dictionary, /*Type*/ typeWithColors)
            {
                let $i1 = 0;
                let $arr1 = typeWithColors.GetProperties$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/);
                while ($i1 < $arr1.length)
                {
                    let prop = $arr1[$i1++];
                    if ($.$spc.System.Type.op_Equality$1(prop.PropertyType, $.$sdp.System.Drawing.Color.$type))
                    {
                        dictionary.set_Item(prop.Name, $.$cast(prop.GetValue$1(null, null), $.$sdp.System.Drawing.Color));
                    }
                }
            }
            static /*Dictionary<string, Color> */ get Colors()
            {
                return $.$sdp.System.Drawing.ColorTable.s_colorConstants.Value;
            }
            static /*bool */ TryGetNamedColor(/*string*/ name, /*out Color*/ result)
            {
                return $.$sdp.System.Drawing.ColorTable.Colors.TryGetValue(name, result);
            }
            static /*bool */ IsKnownNamedColor(/*string*/ name)
            {
                return $.$sdp.System.Drawing.ColorTable.Colors.TryGetValue(name, $.$discardRef());
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_colorConstants = new ($.$spc.System.Lazy$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)))().$ctor$3(new ($.$spc.System.Func$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)))().$ctor($.$sdp.System.Drawing.ColorTable, $.$sdp.System.Drawing.ColorTable.GetColors));
                }
            }
            static $h = 245547;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h,"g":{"r":0,"d":0,"h":21475082027,"f":40},"n":"Colors","d":245547,"h":17180114731,"f":40}],"m":[{"r":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h,"n":"GetColors","d":245547,"h":8590180139,"f":34},{"r":65537,"p":[{"n":"dictionary","p":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h},{"n":"typeWithColors","p":142606337}],"n":"FillWithProperties","d":245547,"h":12885147435,"f":34},{"r":262145,"p":[{"n":"name","p":1310721},{"n":"result","p":114475,"f":2}],"n":"TryGetNamedColor","d":245547,"h":25770049323,"f":40},{"r":262145,"p":[{"n":"name","p":1310721}],"n":"IsKnownNamedColor","d":245547,"h":30065016619,"f":40}],"l":[{"t":$.$spc.System.Lazy$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)).$h,"n":"s_colorConstants","d":245547,"h":4295212843,"f":34}],"h":245547}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.ColorTable`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorConverterCommon", ($self) => class ColorConverterCommon
        {
            static /*Color */ ConvertFromString(/*string*/ strValue, /*CultureInfo*/ culture)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(culture !== null, "culture != null");
                /*string*/ let text = $.$spc.System.String.Trim.call(strValue);
                if (text.length === 0)
                {
                    return $.$sdp.System.Drawing.Color.Empty;
                }
                {
                    /*Color*/ let c;
                    if ($.$sdp.System.Drawing.ColorTable.TryGetNamedColor(text, $.$ref(() => c, ($v) => c = $v, $.$sdp.System.Drawing.Color)))
                    {
                        return c;
                    }
                }
                /*char*/ let sep = $.$spc.System.String.get_Chars.call(culture.TextInfo.ListSeparator, 0);
                if (!$.$spc.System.String.Contains$2.call(text, sep))
                {
                    if (text.length >= 2 && ($.$spc.System.String.get_Chars.call(text, 0) === /*'*/ 39 || $.$spc.System.String.get_Chars.call(text, 0) === /*\"*/ 34) && $.$spc.System.String.get_Chars.call(text, 0) === $.$spc.System.String.get_Chars.call(text, ((text.length - 1) | 0)))
                    {
                        /*string*/ let colorName = $.$spc.System.String.Substring$1.call(text, 1, ((text.length - 2) | 0));
                        return $.$sdp.System.Drawing.Color.FromName(colorName);
                    }
                    else if ((text.length === 7 && $.$spc.System.String.get_Chars.call(text, 0) === /*#*/ 35) || (text.length === 8 && ($.$spc.System.String.StartsWith.call(text, "0x") || $.$spc.System.String.StartsWith.call(text, "0X"))) || (text.length === 8 && ($.$spc.System.String.StartsWith.call(text, "&h") || $.$spc.System.String.StartsWith.call(text, "&H"))))
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$1(((4278190080 | ($.$sdp.System.Drawing.ColorConverterCommon.IntFromString($.$spc.System.String.op_Implicit(text), culture) >>> 0)) | 0)));
                    }
                }
                /*ReadOnlySpan<char>*/ let textSpan = $.$spc.System.String.op_Implicit(text);
                /*Span<Range>*/ let tokens = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Range, 5, null);
                return (() =>
                {
                    let $switch1 = $.$spc.System.MemoryExtensions.Split$2(textSpan, tokens, sep, 0);
                    if ($switch1 === 1)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$1($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture)));
                    }
                    if ($switch1 === 3)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$4($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(1).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(2).$v], culture)));
                    }
                    if ($switch1 === 4)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$2($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(1).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(2).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(3).$v], culture)));
                    }
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sdp.System.SR.Format($.$sdp.System.SR.InvalidColor, text));
                })();
            }
            static /*Color */ PossibleKnownColor(/*Color*/ color)
            {
                /*int*/ let targetARGB = color.ToArgb();
                var $en2 = $.$sdp.System.Drawing.ColorTable.Colors.Values.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current;
                    {
                        if (c.ToArgb() === targetARGB)
                        {
                            return c;
                        }
                    }
                }
                return color;
            }
            static /*int */ IntFromString(/*ReadOnlySpan<char>*/ text, /*CultureInfo*/ culture)
            {
                text = $.$spc.System.MemoryExtensions.Trim$10(text);
                try
                {
                    if (text.get_Item(0).$v === /*#*/ 35)
                    {
                        return $.$spc.System.Convert.ToInt32$18($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(text.Slice(1)), 16);
                    }
                    else if ($.$spc.System.MemoryExtensions.StartsWith$5(text, $.$spc.System.String.op_Implicit("0x"), 5/*StringComparison.OrdinalIgnoreCase*/) || $.$spc.System.MemoryExtensions.StartsWith$5(text, $.$spc.System.String.op_Implicit("&h"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spc.System.Convert.ToInt32$18($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(text.Slice(2)), 16);
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(culture !== null, "culture != null");
                        /*var*/ let formatInfo = $.$cast(culture.GetFormat($.$spc.System.Globalization.NumberFormatInfo.$type), $.$spc.System.Globalization.NumberFormatInfo);
                        return $.$spc.System.Int32.Parse$5(text, formatInfo);
                    }
                }
                catch(e)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$11($.$sdp.System.SR.Format$1($.$sdp.System.SR.ConvertInvalidPrimitive, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(text), "Int32"), e);
                }
            }
            static $h = 180011;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":114475,"p":[{"n":"strValue","p":1310721},{"n":"culture","p":51183617}],"n":"ConvertFromString","d":180011,"h":4295147307,"f":33},{"r":114475,"p":[{"n":"color","p":114475}],"n":"PossibleKnownColor","d":180011,"h":8590114603,"f":34},{"r":655361,"p":[{"n":"text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"culture","p":51183617}],"n":"IntFromString","d":180011,"h":12885081899,"f":34}],"h":180011}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.ColorConverterCommon`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.KnownColorTable", ($self) => class KnownColorTable
        {
            /*byte*/ static KnownColorKindSystem = 0;
            /*byte*/ static KnownColorKindWeb = 1;
            /*byte*/ static KnownColorKindUnknown = 2;
            static /*ReadOnlySpan<uint> */ get ColorValueTable()
            {
                return this.$cacheColorValueTable ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$2([ 0, 4292137160, 4278211811, 4294967295, 4286611584, 4293716440, 4289505433, 4285624164, 4294045666, 4294967295, 4278190080, 4278210200, 4289505433, 4281428677, 4294967295, 4278190208, 4292137160, 4286224095, 4292404472, 4294967265, 4278190080, 4294967295, 4278190080, 4292137160, 4294967295, 4278190080, 4278190080, 16777215, 4293982463, 4294634455, 4278255615, 4286578644, 4293984255, 4294309340, 4294960324, 4278190080, 4294962125, 4278190335, 4287245282, 4289014314, 4292786311, 4284456608, 4286578432, 4291979550, 4294934352, 4284782061, 4294965468, 4292613180, 4278255615, 4278190219, 4278225803, 4290283019, 4289309097, 4278215680, 4290623339, 4287299723, 4283788079, 4294937600, 4288230092, 4287299584, 4293498490, 4287609999, 4282924427, 4281290575, 4278243025, 4287889619, 4294907027, 4278239231, 4285098345, 4280193279, 4289864226, 4294966000, 4280453922, 4294902015, 4292664540, 4294506751, 4294956800, 4292519200, 4286611584, 4278222848, 4289593135, 4293984240, 4294928820, 4291648604, 4283105410, 4294967280, 4293977740, 4293322490, 4294963445, 4286381056, 4294965965, 4289583334, 4293951616, 4292935679, 4294638290, 4292072403, 4287688336, 4294948545, 4294942842, 4280332970, 4287090426, 4286023833, 4289774814, 4294967264, 4278255360, 4281519410, 4294635750, 4294902015, 4286578688, 4284927402, 4278190285, 4290401747, 4287852763, 4282168177, 4286277870, 4278254234, 4282962380, 4291237253, 4279834992, 4294311930, 4294960353, 4294960309, 4294958765, 4278190208, 4294833638, 4286611456, 4285238819, 4294944000, 4294919424, 4292505814, 4293847210, 4288215960, 4289720046, 4292571283, 4294963157, 4294957753, 4291659071, 4294951115, 4292714717, 4289781990, 4286578816, 4294901760, 4290547599, 4282477025, 4287317267, 4294606962, 4294222944, 4281240407, 4294964718, 4288696877, 4290822336, 4287090411, 4285160141, 4285563024, 4294966010, 4278255487, 4282811060, 4291998860, 4278222976, 4292394968, 4294927175, 4282441936, 4293821166, 4294303411, 4294967295, 4294309365, 4294967040, 4288335154, 4293980400, 4294967295, 4288716960, 4290367978, 4292338930, 4293980400, 4281571839, 4284887961 ]);
            }
            static /*ReadOnlySpan<byte> */ get ColorKindTable()
            {
                return this.$cacheColorKindTable ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 2/*KnownColorKindUnknown*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 1/*KnownColorKindWeb*/ ]);
            }
            static /*ReadOnlySpan<uint> */ get AlternateSystemColors()
            {
                return this.$cacheAlternateSystemColors ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$2([ 0, 4282795590, 4282146680, 4294967295, 4282137660, 4280295456, 4283058762, 4284111450, 4281216558, 4280229663, 4294967295, 4279242768, 4288059030, 4280837300, 4278190080, 4281163695, 4282138433, 4281813850, 4290690750, 4283453500, 4290690750, 4281808695, 4293980400, 4283453520, 4281479730, 4280821800, 4293980400, 4280295456, 4279242768, 4282795590, 4282475650, 4283790230, 4281808695, 4280975570 ]);
            }
            static /*Color */ ArgbToKnownColor(/*uint*/ argb)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((argb & 4278190080/*Color.ARGBAlphaMask*/) === 4278190080/*Color.ARGBAlphaMask*/, "(argb & Color.ARGBAlphaMask) == Color.ARGBAlphaMask");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$sdp.System.Drawing.KnownColorTable.ColorValueTable.Length === $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.Length, "ColorValueTable.Length == ColorKindTable.Length");
                /*ReadOnlySpan<uint>*/ let colorValueTable = $.$sdp.System.Drawing.KnownColorTable.ColorValueTable;
                for(/*int*/ let index = 1; index < colorValueTable.Length; ++index)
                {
                    if ($.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(index).$v === 1/*KnownColorKindWeb*/ && colorValueTable.get_Item(index).$v === argb)
                    {
                        return $.$sdp.System.Drawing.Color.FromKnownColor($.$cast(index, $.$sdp.System.Drawing.KnownColor));
                    }
                }
                return $.$sdp.System.Drawing.Color.FromArgb$1((argb | 0));
            }
            static /*uint */ KnownColorToArgb(/*KnownColor*/ color)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(color > 0 && color <= 175/*KnownColor.RebeccaPurple*/, "color > 0 && color <= KnownColor.RebeccaPurple");
                return $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(color).$v === 0/*KnownColorKindSystem*/ ? $.$sdp.System.Drawing.KnownColorTable.GetSystemColorArgb(color) : $.$sdp.System.Drawing.KnownColorTable.ColorValueTable.get_Item(color).$v;
            }
            static /*uint */ GetAlternateSystemColorArgb(/*KnownColor*/ color)
            {
                /*int*/ let index = color <= 26/*KnownColor.WindowText*/ ? color : ((((((color - 168/*KnownColor.ButtonFace*/) | 0) + 26/*KnownColor.WindowText*/) | 0) + 1) | 0);
                return $.$sdp.System.Drawing.KnownColorTable.AlternateSystemColors.get_Item(index).$v;
            }
            static /*uint */ GetSystemColorArgb(/*KnownColor*/ color)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$sdp.System.Drawing.Color.IsKnownColorSystem(color), "Color.IsKnownColorSystem(color)");
                return (!$.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet) ? $.$sdp.System.Drawing.KnownColorTable.ColorValueTable.get_Item(color).$v : $.$sdp.System.Drawing.KnownColorTable.GetAlternateSystemColorArgb(color);
            }
            static $h = 507691;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"g":{"r":0,"d":0,"h":21475344171,"f":33},"n":"ColorValueTable","d":507691,"h":17180376875,"f":33},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":30065278763,"f":33},"n":"ColorKindTable","d":507691,"h":25770311467,"f":33},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"g":{"r":0,"d":0,"h":38655213355,"f":34},"n":"AlternateSystemColors","d":507691,"h":34360246059,"f":34}],"m":[{"r":114475,"p":[{"n":"argb","p":720897}],"n":"ArgbToKnownColor","d":507691,"h":42950180651,"f":40},{"r":720897,"p":[{"n":"color","p":376619}],"n":"KnownColorToArgb","d":507691,"h":47245147947,"f":33},{"r":720897,"p":[{"n":"color","p":376619}],"n":"GetAlternateSystemColorArgb","d":507691,"h":51540115243,"f":34},{"r":720897,"p":[{"n":"color","p":376619}],"n":"GetSystemColorArgb","d":507691,"h":55835082539,"f":33}],"l":[{"t":393217,"n":"KnownColorKindSystem","d":507691,"h":4295474987,"f":33},{"t":393217,"n":"KnownColorKindWeb","d":507691,"h":8590442283,"f":33},{"t":393217,"n":"KnownColorKindUnknown","d":507691,"h":12885409579,"f":33}],"h":507691}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.KnownColorTable`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorTranslator", ($self) => class ColorTranslator
        {
            /*int*/ static COLORREF_RedShift = 0;
            /*int*/ static COLORREF_GreenShift = 8;
            /*int*/ static COLORREF_BlueShift = 16;
            /*int*/ static OleSystemColorFlag = -2147483648;
            /*Dictionary<string, Color>?*/ static s_htmlSysColorTable = null;
            static /*uint */ COLORREFToARGB(/*uint*/ value)
            {
                return (((value >>> 0/*COLORREF_RedShift*/) & 255) << 16/*Color.ARGBRedShift*/) >>> 0 | (((value >>> 8/*COLORREF_GreenShift*/) & 255) << 8/*Color.ARGBGreenShift*/) >>> 0 | (((value >>> 16/*COLORREF_BlueShift*/) & 255) << 0/*Color.ARGBBlueShift*/) >>> 0 | 4278190080/*Color.ARGBAlphaMask*/;
            }
            static /*int */ ToWin32(/*Color*/ c)
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                c.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                return r << 0/*COLORREF_RedShift*/ | g << 8/*COLORREF_GreenShift*/ | b << 16/*COLORREF_BlueShift*/;
            }
            static /*int */ ToOle(/*Color*/ c)
            {
                if (c.IsKnownColor && c.IsSystemColor)
                {
                    let $switch1 = c.ToKnownColor();
                    switch($switch1)
                    {
                        case 1/*KnownColor.ActiveBorder*/:
                        return (2147483658 | 0);
                        case 2/*KnownColor.ActiveCaption*/:
                        return (2147483650 | 0);
                        case 3/*KnownColor.ActiveCaptionText*/:
                        return (2147483657 | 0);
                        case 4/*KnownColor.AppWorkspace*/:
                        return (2147483660 | 0);
                        case 168/*KnownColor.ButtonFace*/:
                        return (2147483663 | 0);
                        case 169/*KnownColor.ButtonHighlight*/:
                        return (2147483668 | 0);
                        case 170/*KnownColor.ButtonShadow*/:
                        return (2147483664 | 0);
                        case 5/*KnownColor.Control*/:
                        return (2147483663 | 0);
                        case 6/*KnownColor.ControlDark*/:
                        return (2147483664 | 0);
                        case 7/*KnownColor.ControlDarkDark*/:
                        return (2147483669 | 0);
                        case 8/*KnownColor.ControlLight*/:
                        return (2147483670 | 0);
                        case 9/*KnownColor.ControlLightLight*/:
                        return (2147483668 | 0);
                        case 10/*KnownColor.ControlText*/:
                        return (2147483666 | 0);
                        case 11/*KnownColor.Desktop*/:
                        return (2147483649 | 0);
                        case 171/*KnownColor.GradientActiveCaption*/:
                        return (2147483675 | 0);
                        case 172/*KnownColor.GradientInactiveCaption*/:
                        return (2147483676 | 0);
                        case 12/*KnownColor.GrayText*/:
                        return (2147483665 | 0);
                        case 13/*KnownColor.Highlight*/:
                        return (2147483661 | 0);
                        case 14/*KnownColor.HighlightText*/:
                        return (2147483662 | 0);
                        case 15/*KnownColor.HotTrack*/:
                        return (2147483674 | 0);
                        case 16/*KnownColor.InactiveBorder*/:
                        return (2147483659 | 0);
                        case 17/*KnownColor.InactiveCaption*/:
                        return (2147483651 | 0);
                        case 18/*KnownColor.InactiveCaptionText*/:
                        return (2147483667 | 0);
                        case 19/*KnownColor.Info*/:
                        return (2147483672 | 0);
                        case 20/*KnownColor.InfoText*/:
                        return (2147483671 | 0);
                        case 21/*KnownColor.Menu*/:
                        return (2147483652 | 0);
                        case 173/*KnownColor.MenuBar*/:
                        return (2147483678 | 0);
                        case 174/*KnownColor.MenuHighlight*/:
                        return (2147483677 | 0);
                        case 22/*KnownColor.MenuText*/:
                        return (2147483655 | 0);
                        case 23/*KnownColor.ScrollBar*/:
                        return (2147483648 | 0);
                        case 24/*KnownColor.Window*/:
                        return (2147483653 | 0);
                        case 25/*KnownColor.WindowFrame*/:
                        return (2147483654 | 0);
                        case 26/*KnownColor.WindowText*/:
                        return (2147483656 | 0);
                    }
                }
                return $.$sdp.System.Drawing.ColorTranslator.ToWin32(c);
            }
            static /*Color */ FromOle(/*int*/ oleColor)
            {
                if ((oleColor & -2147483648/*OleSystemColorFlag*/) !== 0)
                {
                    switch(oleColor)
                    {
                        case (2147483658 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/);
                        case (2147483650 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/);
                        case (2147483657 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/);
                        case (2147483660 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/);
                        case (2147483663 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/);
                        case (2147483664 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/);
                        case (2147483669 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/);
                        case (2147483670 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/);
                        case (2147483668 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/);
                        case (2147483666 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/);
                        case (2147483649 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/);
                        case (2147483675 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(171/*KnownColor.GradientActiveCaption*/);
                        case (2147483676 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(172/*KnownColor.GradientInactiveCaption*/);
                        case (2147483665 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/);
                        case (2147483661 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/);
                        case (2147483662 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/);
                        case (2147483674 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(15/*KnownColor.HotTrack*/);
                        case (2147483659 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/);
                        case (2147483651 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/);
                        case (2147483667 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/);
                        case (2147483672 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/);
                        case (2147483671 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/);
                        case (2147483652 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/);
                        case (2147483678 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(173/*KnownColor.MenuBar*/);
                        case (2147483677 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(174/*KnownColor.MenuHighlight*/);
                        case (2147483655 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/);
                        case (2147483648 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/);
                        case (2147483653 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/);
                        case (2147483654 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/);
                        case (2147483656 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/);
                    }
                }
                return $.$sdp.System.Drawing.KnownColorTable.ArgbToKnownColor($.$sdp.System.Drawing.ColorTranslator.COLORREFToARGB((oleColor >>> 0)));
            }
            static /*Color */ FromWin32(/*int*/ win32Color)
            {
                return $.$sdp.System.Drawing.ColorTranslator.FromOle(win32Color);
            }
            static /*Color */ FromHtml(/*string*/ htmlColor)
            {
                /*Color*/ let c = $.$sdp.System.Drawing.Color.Empty;
                if (($.$spc.System.String.op_Equality(htmlColor, null)) || (htmlColor.length === 0))
                {
                    return c;
                }
                if (($.$spc.System.String.get_Chars.call(htmlColor, 0) === /*#*/ 35) && ((htmlColor.length === 7) || (htmlColor.length === 4)))
                {
                    if (htmlColor.length === 7)
                    {
                        c = $.$sdp.System.Drawing.Color.FromArgb$4($.$spc.System.Convert.ToInt32$18($.$spc.System.String.Substring$1.call(htmlColor, 1, 2), 16), $.$spc.System.Convert.ToInt32$18($.$spc.System.String.Substring$1.call(htmlColor, 3, 2), 16), $.$spc.System.Convert.ToInt32$18($.$spc.System.String.Substring$1.call(htmlColor, 5, 2), 16));
                    }
                    else 
                    {
                        /*string*/ let r = $.$spc.System.Char.ToString$2($.$spc.System.String.get_Chars.call(htmlColor, 1));
                        /*string*/ let g = $.$spc.System.Char.ToString$2($.$spc.System.String.get_Chars.call(htmlColor, 2));
                        /*string*/ let b = $.$spc.System.Char.ToString$2($.$spc.System.String.get_Chars.call(htmlColor, 3));
                        c = $.$sdp.System.Drawing.Color.FromArgb$4($.$spc.System.Convert.ToInt32$18(r + r, 16), $.$spc.System.Convert.ToInt32$18(g + g, 16), $.$spc.System.Convert.ToInt32$18(b + b, 16));
                    }
                }
                if (c.IsEmpty && $.$spc.System.String.Equals$5(htmlColor, "LightGrey", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    c = $.$sdp.System.Drawing.Color.LightGray;
                }
                if (c.IsEmpty)
                {
                    if ($.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable === null)
                    {
                        $.$sdp.System.Drawing.ColorTranslator.InitializeHtmlSysColorTable();
                    }
                    $.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable.TryGetValue($.$spc.System.String.ToLowerInvariant.call(htmlColor), $.$ref(() => c, ($v) => c = $v, $.$sdp.System.Drawing.Color));
                }
                if (c.IsEmpty)
                {
                    try
                    {
                        c = $.$sdp.System.Drawing.ColorConverterCommon.ConvertFromString(htmlColor, $.$spc.System.Globalization.CultureInfo.CurrentCulture);
                    }
                    catch(ex)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$12(ex.Message, "htmlColor", ex);
                    }
                }
                return c;
            }
            static /*string */ ToHtml(/*Color*/ c)
            {
                /*string*/ let colorString = $.$spc.System.String.Empty;
                if (c.IsEmpty)
                {
                    return colorString;
                }
                if (c.IsSystemColor)
                {
                    let $switch1 = c.ToKnownColor();
                    switch($switch1)
                    {
                        case 1/*KnownColor.ActiveBorder*/:
                        colorString = "activeborder";
                        break;
                        case 171/*KnownColor.GradientActiveCaption*/:
                        case 2/*KnownColor.ActiveCaption*/:
                        colorString = "activecaption";
                        break;
                        case 4/*KnownColor.AppWorkspace*/:
                        colorString = "appworkspace";
                        break;
                        case 11/*KnownColor.Desktop*/:
                        colorString = "background";
                        break;
                        case 5/*KnownColor.Control*/:
                        case 8/*KnownColor.ControlLight*/:
                        colorString = "buttonface";
                        break;
                        case 6/*KnownColor.ControlDark*/:
                        colorString = "buttonshadow";
                        break;
                        case 10/*KnownColor.ControlText*/:
                        colorString = "buttontext";
                        break;
                        case 3/*KnownColor.ActiveCaptionText*/:
                        colorString = "captiontext";
                        break;
                        case 12/*KnownColor.GrayText*/:
                        colorString = "graytext";
                        break;
                        case 15/*KnownColor.HotTrack*/:
                        case 13/*KnownColor.Highlight*/:
                        colorString = "highlight";
                        break;
                        case 174/*KnownColor.MenuHighlight*/:
                        case 14/*KnownColor.HighlightText*/:
                        colorString = "highlighttext";
                        break;
                        case 16/*KnownColor.InactiveBorder*/:
                        colorString = "inactiveborder";
                        break;
                        case 172/*KnownColor.GradientInactiveCaption*/:
                        case 17/*KnownColor.InactiveCaption*/:
                        colorString = "inactivecaption";
                        break;
                        case 18/*KnownColor.InactiveCaptionText*/:
                        colorString = "inactivecaptiontext";
                        break;
                        case 19/*KnownColor.Info*/:
                        colorString = "infobackground";
                        break;
                        case 20/*KnownColor.InfoText*/:
                        colorString = "infotext";
                        break;
                        case 173/*KnownColor.MenuBar*/:
                        case 21/*KnownColor.Menu*/:
                        colorString = "menu";
                        break;
                        case 22/*KnownColor.MenuText*/:
                        colorString = "menutext";
                        break;
                        case 23/*KnownColor.ScrollBar*/:
                        colorString = "scrollbar";
                        break;
                        case 7/*KnownColor.ControlDarkDark*/:
                        colorString = "threeddarkshadow";
                        break;
                        case 9/*KnownColor.ControlLightLight*/:
                        colorString = "buttonhighlight";
                        break;
                        case 24/*KnownColor.Window*/:
                        colorString = "window";
                        break;
                        case 25/*KnownColor.WindowFrame*/:
                        colorString = "windowframe";
                        break;
                        case 26/*KnownColor.WindowText*/:
                        colorString = "windowtext";
                        break;
                    }
                }
                else if (c.IsNamedColor)
                {
                    if ($.$sdp.System.Drawing.Color.op_Equality(c, $.$sdp.System.Drawing.Color.LightGray))
                    {
                        colorString = "LightGrey";
                    }
                    else 
                    {
                        colorString = c.Name;
                    }
                }
                else 
                {
                    /*int*/ let r;
                    /*int*/ let g;
                    /*int*/ let b;
                    c.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                    colorString = (() =>
                    {
                        var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(1, 3);
                        $handler.AppendLiteral("#");
                        $handler.AppendFormatted$8($.$box(r, $.$spc.System.Int32), null, "X2");
                        $handler.AppendFormatted$8($.$box(g, $.$spc.System.Int32), null, "X2");
                        $handler.AppendFormatted$8($.$box(b, $.$spc.System.Int32), null, "X2");
                        return $handler.ToStringAndClear();
                    })();
                }
                return colorString;
            }
            static /*void */ InitializeHtmlSysColorTable()
            {
                $.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable = (() =>
                {
                    //new $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)()
                    const $t1 = $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color);
                    const $i1 = new $t1();
                    $i1.$ctor$2(27);
                    $i1.set_Item("activeborder", $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/));
                    $i1.set_Item("activecaption", $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/));
                    $i1.set_Item("appworkspace", $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/));
                    $i1.set_Item("background", $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/));
                    $i1.set_Item("buttonface", $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/));
                    $i1.set_Item("buttonhighlight", $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/));
                    $i1.set_Item("buttonshadow", $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/));
                    $i1.set_Item("buttontext", $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/));
                    $i1.set_Item("captiontext", $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/));
                    $i1.set_Item("graytext", $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/));
                    $i1.set_Item("highlight", $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/));
                    $i1.set_Item("highlighttext", $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/));
                    $i1.set_Item("inactiveborder", $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/));
                    $i1.set_Item("inactivecaption", $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/));
                    $i1.set_Item("inactivecaptiontext", $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/));
                    $i1.set_Item("infobackground", $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/));
                    $i1.set_Item("infotext", $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/));
                    $i1.set_Item("menu", $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/));
                    $i1.set_Item("menutext", $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/));
                    $i1.set_Item("scrollbar", $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/));
                    $i1.set_Item("threeddarkshadow", $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/));
                    $i1.set_Item("threedface", $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/));
                    $i1.set_Item("threedhighlight", $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/));
                    $i1.set_Item("threedlightshadow", $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/));
                    $i1.set_Item("window", $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/));
                    $i1.set_Item("windowframe", $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/));
                    $i1.set_Item("windowtext", $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/));
                    return $i1;
                })();
            }
            static $h = 311083;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":720897,"p":[{"n":"value","p":720897}],"n":"COLORREFToARGB","d":311083,"h":25770114859,"f":40},{"r":655361,"p":[{"n":"c","p":114475}],"n":"ToWin32","d":311083,"h":30065082155,"f":33},{"r":655361,"p":[{"n":"c","p":114475}],"n":"ToOle","d":311083,"h":34360049451,"f":33},{"r":114475,"p":[{"n":"oleColor","p":655361}],"n":"FromOle","d":311083,"h":38655016747,"f":33},{"r":114475,"p":[{"n":"win32Color","p":655361}],"n":"FromWin32","d":311083,"h":42949984043,"f":33},{"r":114475,"p":[{"n":"htmlColor","p":1310721}],"n":"FromHtml","d":311083,"h":47244951339,"f":33},{"r":1310721,"p":[{"n":"c","p":114475}],"n":"ToHtml","d":311083,"h":51539918635,"f":33},{"r":65537,"n":"InitializeHtmlSysColorTable","d":311083,"h":55834885931,"f":34}],"l":[{"t":655361,"n":"COLORREF_RedShift","d":311083,"h":4295278379,"f":40},{"t":655361,"n":"COLORREF_GreenShift","d":311083,"h":8590245675,"f":40},{"t":655361,"n":"COLORREF_BlueShift","d":311083,"h":12885212971,"f":40},{"t":655361,"n":"OleSystemColorFlag","d":311083,"h":17180180267,"f":34},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h,"n":"s_htmlSysColorTable","d":311083,"h":21475147563,"f":34}],"h":311083}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.ColorTranslator`; }
        });
        
        $asm.$str("$sdp.System.Drawing.SizeF", ($self) => class SizeF extends $.$spc.System.ValueType
        {
            /*SizeF*/ static Empty;
            /*float*/  get width() { return this.$getField(0, $.$spc.System.Single); }
            /*float*/  set width(value) { this.$setField(0, $.$spc.System.Single, value); }
            /*float*/  get height() { return this.$getField(4, $.$spc.System.Single); }
            /*float*/  set height(value) { this.$setField(4, $.$spc.System.Single, value); }
            $ctor$2(/*SizeF*/ size)
            {
                super.$ctor$1();
                {
                    this.width = size.width;
                    this.height = size.height;
                }
                return this;
            }
            $ctor$3(/*PointF*/ pt)
            {
                super.$ctor$1();
                {
                    this.width = pt.X;
                    this.height = pt.Y;
                }
                return this;
            }
            $ctor$4(/*Vector2*/ vector)
            {
                super.$ctor$1();
                {
                    this.width = vector.X;
                    this.height = vector.Y;
                }
                return this;
            }
            /*Vector2 */ ToVector2()
            {
                return new $.$spc.System.Numerics.Vector2().$ctor$3(this.width, this.height);
            }
            $ctor$5(/*float*/ width, /*float*/ height)
            {
                super.$ctor$1();
                {
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            static /*Vector2 */ op_Explicit(/*SizeF*/ size)
            {
                return size.ToVector2();
            }
            static /*SizeF */ op_Explicit$1(/*Vector2*/ vector)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$4(vector.Clone());
            }
            static /*SizeF */ op_Addition(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return $.$sdp.System.Drawing.SizeF.Add(sz1.Clone(), sz2.Clone());
            }
            static /*SizeF */ op_Subtraction(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return $.$sdp.System.Drawing.SizeF.Subtract(sz1.Clone(), sz2.Clone());
            }
            static /*SizeF */ op_Multiply(/*float*/ left, /*SizeF*/ right)
            {
                return $.$sdp.System.Drawing.SizeF.Multiply(right.Clone(), left);
            }
            static /*SizeF */ op_Multiply$1(/*SizeF*/ left, /*float*/ right)
            {
                return $.$sdp.System.Drawing.SizeF.Multiply(left.Clone(), right);
            }
            static /*SizeF */ op_Division(/*SizeF*/ left, /*float*/ right)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(left.width / right, left.height / right);
            }
            static /*bool */ op_Equality(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return sz1.Width === sz2.Width && sz1.Height === sz2.Height;
            }
            static /*bool */ op_Inequality(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return !($.$sdp.System.Drawing.SizeF.op_Equality(sz1, sz2));
            }
            static /*PointF */ op_Explicit$2(/*SizeF*/ size)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(size.Width, size.Height);
            }
            /*bool */ get IsEmpty()
            {
                return this.width === 0 && this.height === 0;
            }
            /*float */ get Width()
            {
                return this.width;
            }
            /*float */ set Width(value)
            {
                this.width = value;
            }
            /*float */ get Height()
            {
                return this.height;
            }
            /*float */ set Height(value)
            {
                this.height = value;
            }
            static /*SizeF */ Add(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(sz1.Width + sz2.Width, sz1.Height + sz2.Height);
            }
            static /*SizeF */ Subtract(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(sz1.Width - sz2.Width, sz1.Height - sz2.Height);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.SizeF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.SizeF));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.SizeF.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*SizeF*/ other)
            {
                return $.$sdp.System.Drawing.SizeF.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Single, $.$spc.System.Single, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.SizeF.GetHashCode.apply(this, arguments); }
            /*PointF */ ToPointF()
            {
                return $.$sdp.System.Drawing.SizeF.op_Explicit$2(this);
            }
            /*Size */ ToSize()
            {
                return $.$sdp.System.Drawing.Size.Truncate(this);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{Width=${this.width}, Height=${this.height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.SizeF.ToString.apply(this, arguments); }
            static /*SizeF */ Multiply(/*SizeF*/ size, /*float*/ multiplier)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(size.width * multiplier, size.height * multiplier);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.SizeF>.Equals(System.Drawing.SizeF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$6()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.SizeF);
                }
            }
            static $h = 900907;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":85900246827,"f":1},"n":"IsEmpty","d":900907,"h":81605279531,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":94490181419,"f":1},"s":{"r":0,"d":0,"h":98785148715,"f":1},"n":"Width","d":900907,"h":90195214123,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":107375083307,"f":1},"s":{"r":0,"d":0,"h":111670050603,"f":1},"n":"Height","d":900907,"h":103080116011,"f":1}],"m":[{"r":70582273,"n":"ToVector2","d":900907,"h":30065671979,"f":1},{"r":900907,"p":[{"n":"sz1","p":900907},{"n":"sz2","p":900907}],"n":"Add","d":900907,"h":115965017899,"f":33},{"r":900907,"p":[{"n":"sz1","p":900907},{"n":"sz2","p":900907}],"n":"Subtract","d":900907,"h":120259985195,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":900907,"h":124554952491,"f":32769},{"r":262145,"p":[{"n":"other","p":900907}],"n":"Equals","o":"@$2","d":900907,"h":128849919787,"f":1},{"r":655361,"n":"GetHashCode","d":900907,"h":133144887083,"f":32769},{"r":638763,"n":"ToPointF","d":900907,"h":137439854379,"f":1},{"r":835371,"n":"ToSize","d":900907,"h":141734821675,"f":1},{"r":1310721,"n":"ToString","d":900907,"h":146029788971,"f":32769},{"r":900907,"p":[{"n":"size","p":900907},{"n":"multiplier","p":1114113}],"n":"Multiply","d":900907,"h":150324756267,"f":34}],"l":[{"t":900907,"n":"Empty","d":900907,"h":4295868203,"f":33},{"t":1114113,"n":"width","d":900907,"h":8590835499,"f":2},{"t":1114113,"n":"height","d":900907,"h":12885802795,"f":2}],"c":[{"p":[{"n":"size","p":900907}],"n":".ctor","o":"$ctor$2","d":900907,"h":17180770091,"f":1},{"p":[{"n":"pt","p":638763}],"n":".ctor","o":"$ctor$3","d":900907,"h":21475737387,"f":1},{"p":[{"n":"vector","p":70582273}],"n":".ctor","o":"$ctor$4","d":900907,"h":25770704683,"f":1},{"p":[{"n":"width","p":1114113},{"n":"height","p":1114113}],"n":".ctor","o":"$ctor$5","d":900907,"h":34360639275,"f":1},{"n":".ctor","o":"$ctor$6","d":900907,"h":154619723563,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.SizeF).$h],"h":900907,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1505155,"c":17181374339,"a":[{"v":"System.Drawing.SizeFConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.SizeF) ]; }
            static get $fullName() { return `System.Drawing.SizeF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Point", ($self) => class Point extends $.$spc.System.ValueType
        {
            /*Point*/ static Empty;
            /*int*/  get x() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set x(value) { this.$setField(0, $.$spc.System.Int32, value); }
            /*int*/  get y() { return this.$getField(4, $.$spc.System.Int32); }
            /*int*/  set y(value) { this.$setField(4, $.$spc.System.Int32, value); }
            $ctor$2(/*int*/ x, /*int*/ y)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                }
                return this;
            }
            $ctor$3(/*Size*/ sz)
            {
                super.$ctor$1();
                {
                    this.x = sz.Width;
                    this.y = sz.Height;
                }
                return this;
            }
            $ctor$4(/*int*/ dw)
            {
                super.$ctor$1();
                {
                    this.x = $.$sdp.System.Drawing.Point.LowInt16(dw);
                    this.y = $.$sdp.System.Drawing.Point.HighInt16(dw);
                }
                return this;
            }
            /*bool */ get IsEmpty()
            {
                return this.x === 0 && this.y === 0;
            }
            /*int */ get X()
            {
                return this.x;
            }
            /*int */ set X(value)
            {
                this.x = value;
            }
            /*int */ get Y()
            {
                return this.y;
            }
            /*int */ set Y(value)
            {
                this.y = value;
            }
            static /*PointF */ op_Implicit(/*Point*/ p)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(p.X, p.Y);
            }
            static /*Size */ op_Explicit(/*Point*/ p)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(p.X, p.Y);
            }
            static /*Point */ op_Addition(/*Point*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.Point.Add(pt.Clone(), sz.Clone());
            }
            static /*Point */ op_Subtraction(/*Point*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.Point.Subtract(pt.Clone(), sz.Clone());
            }
            static /*bool */ op_Equality(/*Point*/ left, /*Point*/ right)
            {
                return left.X === right.X && left.Y === right.Y;
            }
            static /*bool */ op_Inequality(/*Point*/ left, /*Point*/ right)
            {
                return !($.$sdp.System.Drawing.Point.op_Equality(left, right));
            }
            static /*Point */ Add(/*Point*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(((pt.X + sz.Width) | 0), ((pt.Y + sz.Height) | 0));
            }
            static /*Point */ Subtract(/*Point*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(((pt.X - sz.Width) | 0), ((pt.Y - sz.Height) | 0));
            }
            static /*Point */ Ceiling(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2($.$cast(Math.ceil(value.X), $.$spc.System.Int32), $.$cast(Math.ceil(value.Y), $.$spc.System.Int32));
            }
            static /*Point */ Truncate(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2($.$cast(value.X, $.$spc.System.Int32), $.$cast(value.Y, $.$spc.System.Int32));
            }
            static /*Point */ Round(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2($.$cast($.$spc.System.Math.Round$4(value.X), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Y), $.$spc.System.Int32));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Point) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Point));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Point.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Point*/ other)
            {
                return $.$sdp.System.Drawing.Point.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Int32, $.$spc.System.Int32, this.X, this.Y);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Point.GetHashCode.apply(this, arguments); }
            /*void */ Offset(/*int*/ dx, /*int*/ dy)
            {
                //unchecked
                {
                    this.X += dx;
                    this.Y += dy;
                }
            }
            /*void */ Offset$1(/*Point*/ p)
            {
                return this.Offset(p.X, p.Y);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Point.ToString.apply(this, arguments); }
            static /*short */ HighInt16(/*int*/ n)
            {
                return $.$cast(((n >> 16) & 65535), $.$spc.System.Int16);
            }
            static /*short */ LowInt16(/*int*/ n)
            {
                return $.$cast((n & 65535), $.$spc.System.Int16);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Point>.Equals(System.Drawing.Point)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$5()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Point);
                }
            }
            static $h = 573227;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360311595,"f":1},"n":"IsEmpty","d":573227,"h":30065344299,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":42950246187,"f":1},"s":{"r":0,"d":0,"h":47245213483,"f":1},"n":"X","d":573227,"h":38655278891,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55835148075,"f":1},"s":{"r":0,"d":0,"h":60130115371,"f":1},"n":"Y","d":573227,"h":51540180779,"f":1}],"m":[{"r":573227,"p":[{"n":"pt","p":573227},{"n":"sz","p":835371}],"n":"Add","d":573227,"h":90194886443,"f":33},{"r":573227,"p":[{"n":"pt","p":573227},{"n":"sz","p":835371}],"n":"Subtract","d":573227,"h":94489853739,"f":33},{"r":573227,"p":[{"n":"value","p":638763}],"n":"Ceiling","d":573227,"h":98784821035,"f":33},{"r":573227,"p":[{"n":"value","p":638763}],"n":"Truncate","d":573227,"h":103079788331,"f":33},{"r":573227,"p":[{"n":"value","p":638763}],"n":"Round","d":573227,"h":107374755627,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":573227,"h":111669722923,"f":32769},{"r":262145,"p":[{"n":"other","p":573227}],"n":"Equals","o":"@$2","d":573227,"h":115964690219,"f":1},{"r":655361,"n":"GetHashCode","d":573227,"h":120259657515,"f":32769},{"r":65537,"p":[{"n":"dx","p":655361},{"n":"dy","p":655361}],"n":"Offset","d":573227,"h":124554624811,"f":1},{"r":65537,"p":[{"n":"p","p":573227}],"n":"Offset","o":"@$1","d":573227,"h":128849592107,"f":1},{"r":1310721,"n":"ToString","d":573227,"h":133144559403,"f":32769},{"r":524289,"p":[{"n":"n","p":655361}],"n":"HighInt16","d":573227,"h":137439526699,"f":34},{"r":524289,"p":[{"n":"n","p":655361}],"n":"LowInt16","d":573227,"h":141734493995,"f":34}],"l":[{"t":573227,"n":"Empty","d":573227,"h":4295540523,"f":33},{"t":655361,"n":"x","d":573227,"h":8590507819,"f":2},{"t":655361,"n":"y","d":573227,"h":12885475115,"f":2}],"c":[{"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":".ctor","o":"$ctor$2","d":573227,"h":17180442411,"f":1},{"p":[{"n":"sz","p":835371}],"n":".ctor","o":"$ctor$3","d":573227,"h":21475409707,"f":1},{"p":[{"n":"dw","p":655361}],"n":".ctor","o":"$ctor$4","d":573227,"h":25770377003,"f":1},{"n":".ctor","o":"$ctor$5","d":573227,"h":146029461291,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Point).$h],"h":573227,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1505155,"c":17181374339,"a":[{"v":"System.Drawing.PointConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Point) ]; }
            static get $fullName() { return `System.Drawing.Point`; }
        });
        
        $asm.$str("$sdp.System.Drawing.PointF", ($self) => class PointF extends $.$spc.System.ValueType
        {
            /*PointF*/ static Empty;
            /*float*/  get x() { return this.$getField(0, $.$spc.System.Single); }
            /*float*/  set x(value) { this.$setField(0, $.$spc.System.Single, value); }
            /*float*/  get y() { return this.$getField(4, $.$spc.System.Single); }
            /*float*/  set y(value) { this.$setField(4, $.$spc.System.Single, value); }
            $ctor$2(/*float*/ x, /*float*/ y)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                }
                return this;
            }
            $ctor$3(/*Vector2*/ vector)
            {
                super.$ctor$1();
                {
                    this.x = vector.X;
                    this.y = vector.Y;
                }
                return this;
            }
            /*Vector2 */ ToVector2()
            {
                return new $.$spc.System.Numerics.Vector2().$ctor$3(this.x, this.y);
            }
            /*bool */ get IsEmpty()
            {
                return this.x === 0 && this.y === 0;
            }
            /*float */ get X()
            {
                return this.x;
            }
            /*float */ set X(value)
            {
                this.x = value;
            }
            /*float */ get Y()
            {
                return this.y;
            }
            /*float */ set Y(value)
            {
                this.y = value;
            }
            static /*Vector2 */ op_Explicit(/*PointF*/ point)
            {
                return point.ToVector2();
            }
            static /*PointF */ op_Explicit$1(/*Vector2*/ vector)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$3(vector.Clone());
            }
            static /*PointF */ op_Addition(/*PointF*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Add(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Subtraction(/*PointF*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Subtract(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Addition$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Add$1(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Subtraction$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Subtract$1(pt.Clone(), sz.Clone());
            }
            static /*bool */ op_Equality(/*PointF*/ left, /*PointF*/ right)
            {
                return left.X === right.X && left.Y === right.Y;
            }
            static /*bool */ op_Inequality(/*PointF*/ left, /*PointF*/ right)
            {
                return !($.$sdp.System.Drawing.PointF.op_Equality(left, right));
            }
            static /*PointF */ Add(/*PointF*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X + sz.Width, pt.Y + sz.Height);
            }
            static /*PointF */ Subtract(/*PointF*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X - sz.Width, pt.Y - sz.Height);
            }
            static /*PointF */ Add$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X + sz.Width, pt.Y + sz.Height);
            }
            static /*PointF */ Subtract$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X - sz.Width, pt.Y - sz.Height);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.PointF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.PointF));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.PointF.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*PointF*/ other)
            {
                return $.$sdp.System.Drawing.PointF.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Single.GetHashCode.call(this.X), $.$spc.System.Single.GetHashCode.call(this.Y));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.PointF.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.x}, Y=${this.y}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.PointF.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.PointF>.Equals(System.Drawing.PointF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.PointF);
                }
            }
            static $h = 638763;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360377131,"f":1},"n":"IsEmpty","d":638763,"h":30065409835,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":42950311723,"f":1},"s":{"r":0,"d":0,"h":47245279019,"f":1},"n":"X","d":638763,"h":38655344427,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":55835213611,"f":1},"s":{"r":0,"d":0,"h":60130180907,"f":1},"n":"Y","d":638763,"h":51540246315,"f":1}],"m":[{"r":70582273,"n":"ToVector2","d":638763,"h":25770442539,"f":1},{"r":638763,"p":[{"n":"pt","p":638763},{"n":"sz","p":835371}],"n":"Add","d":638763,"h":98784886571,"f":33},{"r":638763,"p":[{"n":"pt","p":638763},{"n":"sz","p":835371}],"n":"Subtract","d":638763,"h":103079853867,"f":33},{"r":638763,"p":[{"n":"pt","p":638763},{"n":"sz","p":900907}],"n":"Add","o":"@$1","d":638763,"h":107374821163,"f":33},{"r":638763,"p":[{"n":"pt","p":638763},{"n":"sz","p":900907}],"n":"Subtract","o":"@$1","d":638763,"h":111669788459,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":638763,"h":115964755755,"f":32769},{"r":262145,"p":[{"n":"other","p":638763}],"n":"Equals","o":"@$2","d":638763,"h":120259723051,"f":1},{"r":655361,"n":"GetHashCode","d":638763,"h":124554690347,"f":32769},{"r":1310721,"n":"ToString","d":638763,"h":128849657643,"f":32769}],"l":[{"t":638763,"n":"Empty","d":638763,"h":4295606059,"f":33},{"t":1114113,"n":"x","d":638763,"h":8590573355,"f":2},{"t":1114113,"n":"y","d":638763,"h":12885540651,"f":2}],"c":[{"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":".ctor","o":"$ctor$2","d":638763,"h":17180507947,"f":1},{"p":[{"n":"vector","p":70582273}],"n":".ctor","o":"$ctor$3","d":638763,"h":21475475243,"f":1},{"n":".ctor","o":"$ctor$4","d":638763,"h":133144624939,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.PointF).$h],"h":638763,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.PointF) ]; }
            static get $fullName() { return `System.Drawing.PointF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Size", ($self) => class Size extends $.$spc.System.ValueType
        {
            /*Size*/ static Empty;
            /*int*/  get width() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set width(value) { this.$setField(0, $.$spc.System.Int32, value); }
            /*int*/  get height() { return this.$getField(4, $.$spc.System.Int32); }
            /*int*/  set height(value) { this.$setField(4, $.$spc.System.Int32, value); }
            $ctor$2(/*Point*/ pt)
            {
                super.$ctor$1();
                {
                    this.width = pt.X;
                    this.height = pt.Y;
                }
                return this;
            }
            $ctor$3(/*int*/ width, /*int*/ height)
            {
                super.$ctor$1();
                {
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            static /*SizeF */ op_Implicit(/*Size*/ p)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(p.Width, p.Height);
            }
            static /*Size */ op_Addition(/*Size*/ sz1, /*Size*/ sz2)
            {
                return $.$sdp.System.Drawing.Size.Add(sz1.Clone(), sz2.Clone());
            }
            static /*Size */ op_Subtraction(/*Size*/ sz1, /*Size*/ sz2)
            {
                return $.$sdp.System.Drawing.Size.Subtract(sz1.Clone(), sz2.Clone());
            }
            static /*Size */ op_Multiply(/*int*/ left, /*Size*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply(right.Clone(), left);
            }
            static /*Size */ op_Multiply$1(/*Size*/ left, /*int*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply(left.Clone(), right);
            }
            static /*Size */ op_Division(/*Size*/ left, /*int*/ right)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.trunc(left.width / right), $.trunc(left.height / right));
            }
            static /*SizeF */ op_Multiply$2(/*float*/ left, /*Size*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply$1(right.Clone(), left);
            }
            static /*SizeF */ op_Multiply$3(/*Size*/ left, /*float*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply$1(left.Clone(), right);
            }
            static /*SizeF */ op_Division$1(/*Size*/ left, /*float*/ right)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(left.width / right, left.height / right);
            }
            static /*bool */ op_Equality(/*Size*/ sz1, /*Size*/ sz2)
            {
                return sz1.Width === sz2.Width && sz1.Height === sz2.Height;
            }
            static /*bool */ op_Inequality(/*Size*/ sz1, /*Size*/ sz2)
            {
                return !($.$sdp.System.Drawing.Size.op_Equality(sz1, sz2));
            }
            static /*Point */ op_Explicit(/*Size*/ size)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(size.Width, size.Height);
            }
            /*bool */ get IsEmpty()
            {
                return this.width === 0 && this.height === 0;
            }
            /*int */ get Width()
            {
                return this.width;
            }
            /*int */ set Width(value)
            {
                this.width = value;
            }
            /*int */ get Height()
            {
                return this.height;
            }
            /*int */ set Height(value)
            {
                this.height = value;
            }
            static /*Size */ Add(/*Size*/ sz1, /*Size*/ sz2)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((sz1.Width + sz2.Width) | 0), ((sz1.Height + sz2.Height) | 0));
            }
            static /*Size */ Ceiling(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast(Math.ceil(value.Width), $.$spc.System.Int32), $.$cast(Math.ceil(value.Height), $.$spc.System.Int32));
            }
            static /*Size */ Subtract(/*Size*/ sz1, /*Size*/ sz2)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((sz1.Width - sz2.Width) | 0), ((sz1.Height - sz2.Height) | 0));
            }
            static /*Size */ Truncate(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast(value.Width, $.$spc.System.Int32), $.$cast(value.Height, $.$spc.System.Int32));
            }
            static /*Size */ Round(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast($.$spc.System.Math.Round$4(value.Width), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Height), $.$spc.System.Int32));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Size) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Size));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Size.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Size*/ other)
            {
                return $.$sdp.System.Drawing.Size.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Int32, $.$spc.System.Int32, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Size.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{Width=${this.width}, Height=${this.height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Size.ToString.apply(this, arguments); }
            static /*Size */ Multiply(/*Size*/ size, /*int*/ multiplier)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((size.width * multiplier) | 0), ((size.height * multiplier) | 0));
            }
            static /*SizeF */ Multiply$1(/*Size*/ size, /*float*/ multiplier)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(size.width * multiplier, size.height * multiplier);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Size>.Equals(System.Drawing.Size)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Size);
                }
            }
            static $h = 835371;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":81605213995,"f":1},"n":"IsEmpty","d":835371,"h":77310246699,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":90195148587,"f":1},"s":{"r":0,"d":0,"h":94490115883,"f":1},"n":"Width","d":835371,"h":85900181291,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103080050475,"f":1},"s":{"r":0,"d":0,"h":107375017771,"f":1},"n":"Height","d":835371,"h":98785083179,"f":1}],"m":[{"r":835371,"p":[{"n":"sz1","p":835371},{"n":"sz2","p":835371}],"n":"Add","d":835371,"h":111669985067,"f":33},{"r":835371,"p":[{"n":"value","p":900907}],"n":"Ceiling","d":835371,"h":115964952363,"f":33},{"r":835371,"p":[{"n":"sz1","p":835371},{"n":"sz2","p":835371}],"n":"Subtract","d":835371,"h":120259919659,"f":33},{"r":835371,"p":[{"n":"value","p":900907}],"n":"Truncate","d":835371,"h":124554886955,"f":33},{"r":835371,"p":[{"n":"value","p":900907}],"n":"Round","d":835371,"h":128849854251,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":835371,"h":133144821547,"f":32769},{"r":262145,"p":[{"n":"other","p":835371}],"n":"Equals","o":"@$2","d":835371,"h":137439788843,"f":1},{"r":655361,"n":"GetHashCode","d":835371,"h":141734756139,"f":32769},{"r":1310721,"n":"ToString","d":835371,"h":146029723435,"f":32769},{"r":835371,"p":[{"n":"size","p":835371},{"n":"multiplier","p":655361}],"n":"Multiply","d":835371,"h":150324690731,"f":34},{"r":900907,"p":[{"n":"size","p":835371},{"n":"multiplier","p":1114113}],"n":"Multiply","o":"@$1","d":835371,"h":154619658027,"f":34}],"l":[{"t":835371,"n":"Empty","d":835371,"h":4295802667,"f":33},{"t":655361,"n":"width","d":835371,"h":8590769963,"f":2},{"t":655361,"n":"height","d":835371,"h":12885737259,"f":2}],"c":[{"p":[{"n":"pt","p":573227}],"n":".ctor","o":"$ctor$2","d":835371,"h":17180704555,"f":1},{"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":".ctor","o":"$ctor$3","d":835371,"h":21475671851,"f":1},{"n":".ctor","o":"$ctor$4","d":835371,"h":158914625323,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Size).$h],"h":835371,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1505155,"c":17181374339,"a":[{"v":"System.Drawing.SizeConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Size) ]; }
            static get $fullName() { return `System.Drawing.Size`; }
        });
        
        $asm.$str("$sdp.System.Drawing.RectangleF", ($self) => class RectangleF extends $.$spc.System.ValueType
        {
            /*RectangleF*/ static Empty;
            /*float*/  get x() { return this.$getField(0, $.$spc.System.Single); }
            /*float*/  set x(value) { this.$setField(0, $.$spc.System.Single, value); }
            /*float*/  get y() { return this.$getField(4, $.$spc.System.Single); }
            /*float*/  set y(value) { this.$setField(4, $.$spc.System.Single, value); }
            /*float*/  get width() { return this.$getField(8, $.$spc.System.Single); }
            /*float*/  set width(value) { this.$setField(8, $.$spc.System.Single, value); }
            /*float*/  get height() { return this.$getField(12, $.$spc.System.Single); }
            /*float*/  set height(value) { this.$setField(12, $.$spc.System.Single, value); }
            $ctor$2(/*float*/ x, /*float*/ y, /*float*/ width, /*float*/ height)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            $ctor$3(/*PointF*/ location, /*SizeF*/ size)
            {
                super.$ctor$1();
                {
                    this.x = location.X;
                    this.y = location.Y;
                    this.width = size.Width;
                    this.height = size.Height;
                }
                return this;
            }
            $ctor$4(/*Vector4*/ vector)
            {
                super.$ctor$1();
                {
                    this.x = vector.X;
                    this.y = vector.Y;
                    this.width = vector.Z;
                    this.height = vector.W;
                }
                return this;
            }
            /*Vector4 */ ToVector4()
            {
                return new $.$spc.System.Numerics.Vector4().$ctor$5(this.x, this.y, this.width, this.height);
            }
            static /*Vector4 */ op_Explicit(/*RectangleF*/ rectangle)
            {
                return rectangle.ToVector4();
            }
            static /*RectangleF */ op_Explicit$1(/*Vector4*/ vector)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$4(vector.Clone());
            }
            static /*RectangleF */ FromLTRB(/*float*/ left, /*float*/ top, /*float*/ right, /*float*/ bottom)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$2(left, top, right - left, bottom - top);
            }
            /*PointF */ get Location()
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(this.X, this.Y);
            }
            /*PointF */ set Location(value)
            {
                this.X = value.X;
                this.Y = value.Y;
            }
            /*SizeF */ get Size()
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(this.Width, this.Height);
            }
            /*SizeF */ set Size(value)
            {
                this.Width = value.Width;
                this.Height = value.Height;
            }
            /*float */ get X()
            {
                return this.x;
            }
            /*float */ set X(value)
            {
                this.x = value;
            }
            /*float */ get Y()
            {
                return this.y;
            }
            /*float */ set Y(value)
            {
                this.y = value;
            }
            /*float */ get Width()
            {
                return this.width;
            }
            /*float */ set Width(value)
            {
                this.width = value;
            }
            /*float */ get Height()
            {
                return this.height;
            }
            /*float */ set Height(value)
            {
                this.height = value;
            }
            /*float */ get Left()
            {
                return this.X;
            }
            /*float */ get Top()
            {
                return this.Y;
            }
            /*float */ get Right()
            {
                return this.X + this.Width;
            }
            /*float */ get Bottom()
            {
                return this.Y + this.Height;
            }
            /*bool */ get IsEmpty()
            {
                return (this.Width <= 0) || (this.Height <= 0);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.RectangleF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.RectangleF));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.RectangleF.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*RectangleF*/ other)
            {
                return $.$sdp.System.Drawing.RectangleF.op_Equality(this, other);
            }
            static /*bool */ op_Equality(/*RectangleF*/ left, /*RectangleF*/ right)
            {
                return left.X === right.X && left.Y === right.Y && left.Width === right.Width && left.Height === right.Height;
            }
            static /*bool */ op_Inequality(/*RectangleF*/ left, /*RectangleF*/ right)
            {
                return !($.$sdp.System.Drawing.RectangleF.op_Equality(left, right));
            }
            /*bool */ Contains(/*float*/ x, /*float*/ y)
            {
                return this.X <= x && x < this.X + this.Width && this.Y <= y && y < this.Y + this.Height;
            }
            /*bool */ Contains$1(/*PointF*/ pt)
            {
                return this.Contains(pt.X, pt.Y);
            }
            /*bool */ Contains$2(/*RectangleF*/ rect)
            {
                return (this.X <= rect.X) && (rect.X + rect.Width <= this.X + this.Width) && (this.Y <= rect.Y) && (rect.Y + rect.Height <= this.Y + this.Height);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$3($.$spc.System.Single, $.$spc.System.Single, $.$spc.System.Single, $.$spc.System.Single, this.X, this.Y, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.RectangleF.GetHashCode.apply(this, arguments); }
            /*void */ Inflate(/*float*/ x, /*float*/ y)
            {
                this.X -= x;
                this.Y -= y;
                this.Width += 2 * x;
                this.Height += 2 * y;
            }
            /*void */ Inflate$1(/*SizeF*/ size)
            {
                return this.Inflate(size.Width, size.Height);
            }
            static /*RectangleF */ Inflate$2(/*RectangleF*/ rect, /*float*/ x, /*float*/ y)
            {
                /*RectangleF*/ let r = rect;
                r.Inflate(x, y);
                return r;
            }
            /*void */ Intersect(/*RectangleF*/ rect)
            {
                /*RectangleF*/ let result = $.$sdp.System.Drawing.RectangleF.Intersect$1(rect.Clone(), this);
                this.X = result.X;
                this.Y = result.Y;
                this.Width = result.Width;
                this.Height = result.Height;
            }
            static /*RectangleF */ Intersect$1(/*RectangleF*/ a, /*RectangleF*/ b)
            {
                /*float*/ let x1 = $.$spc.System.Math.Max$8(a.X, b.X);
                /*float*/ let x2 = $.$spc.System.Math.Min$8(a.X + a.Width, b.X + b.Width);
                /*float*/ let y1 = $.$spc.System.Math.Max$8(a.Y, b.Y);
                /*float*/ let y2 = $.$spc.System.Math.Min$8(a.Y + a.Height, b.Y + b.Height);
                if (x2 >= x1 && y2 >= y1)
                {
                    return new $.$sdp.System.Drawing.RectangleF().$ctor$2(x1, y1, x2 - x1, y2 - y1);
                }
                return $.$sdp.System.Drawing.RectangleF.Empty;
            }
            /*bool */ IntersectsWith(/*RectangleF*/ rect)
            {
                return (rect.X < this.X + this.Width) && (this.X < rect.X + rect.Width) && (rect.Y < this.Y + this.Height) && (this.Y < rect.Y + rect.Height);
            }
            static /*RectangleF */ Union(/*RectangleF*/ a, /*RectangleF*/ b)
            {
                /*float*/ let x1 = $.$spc.System.Math.Min$8(a.X, b.X);
                /*float*/ let x2 = $.$spc.System.Math.Max$8(a.X + a.Width, b.X + b.Width);
                /*float*/ let y1 = $.$spc.System.Math.Min$8(a.Y, b.Y);
                /*float*/ let y2 = $.$spc.System.Math.Max$8(a.Y + a.Height, b.Y + b.Height);
                return new $.$sdp.System.Drawing.RectangleF().$ctor$2(x1, y1, x2 - x1, y2 - y1);
            }
            /*void */ Offset(/*PointF*/ pos)
            {
                return this.Offset$1(pos.X, pos.Y);
            }
            /*void */ Offset$1(/*float*/ x, /*float*/ y)
            {
                this.X += x;
                this.Y += y;
            }
            static /*RectangleF */ op_Implicit(/*Rectangle*/ r)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$2(r.X, r.Y, r.Width, r.Height);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y},Width=${this.Width},Height=${this.Height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.RectangleF.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.RectangleF>.Equals(System.Drawing.RectangleF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$5()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.RectangleF);
                }
            }
            static $h = 769835;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":638763,"g":{"r":0,"d":0,"h":60130311979,"f":1},"s":{"r":0,"d":0,"h":64425279275,"f":1},"n":"Location","d":769835,"h":55835344683,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":900907,"g":{"r":0,"d":0,"h":73015213867,"f":1},"s":{"r":0,"d":0,"h":77310181163,"f":1},"n":"Size","d":769835,"h":68720246571,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":85900115755,"f":1},"s":{"r":0,"d":0,"h":90195083051,"f":1},"n":"X","d":769835,"h":81605148459,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":98785017643,"f":1},"s":{"r":0,"d":0,"h":103079984939,"f":1},"n":"Y","d":769835,"h":94490050347,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":111669919531,"f":1},"s":{"r":0,"d":0,"h":115964886827,"f":1},"n":"Width","d":769835,"h":107374952235,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":124554821419,"f":1},"s":{"r":0,"d":0,"h":128849788715,"f":1},"n":"Height","d":769835,"h":120259854123,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":137439723307,"f":1},"n":"Left","d":769835,"h":133144756011,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":146029657899,"f":1},"n":"Top","d":769835,"h":141734690603,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":154619592491,"f":1},"n":"Right","d":769835,"h":150324625195,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":163209527083,"f":1},"n":"Bottom","d":769835,"h":158914559787,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":262145,"g":{"r":0,"d":0,"h":171799461675,"f":1},"n":"IsEmpty","d":769835,"h":167504494379,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]}],"m":[{"r":70713345,"n":"ToVector4","d":769835,"h":38655475499,"f":1},{"r":769835,"p":[{"n":"left","p":1114113},{"n":"top","p":1114113},{"n":"right","p":1114113},{"n":"bottom","p":1114113}],"n":"FromLTRB","d":769835,"h":51540377387,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":769835,"h":176094428971,"f":32769},{"r":262145,"p":[{"n":"other","p":769835}],"n":"Equals","o":"@$2","d":769835,"h":180389396267,"f":1},{"r":262145,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Contains","d":769835,"h":193274298155,"f":1},{"r":262145,"p":[{"n":"pt","p":638763}],"n":"Contains","o":"@$1","d":769835,"h":197569265451,"f":1},{"r":262145,"p":[{"n":"rect","p":769835}],"n":"Contains","o":"@$2","d":769835,"h":201864232747,"f":1},{"r":655361,"n":"GetHashCode","d":769835,"h":206159200043,"f":32769},{"r":65537,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Inflate","d":769835,"h":210454167339,"f":1},{"r":65537,"p":[{"n":"size","p":900907}],"n":"Inflate","o":"@$1","d":769835,"h":214749134635,"f":1},{"r":769835,"p":[{"n":"rect","p":769835},{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Inflate","o":"@$2","d":769835,"h":219044101931,"f":33},{"r":65537,"p":[{"n":"rect","p":769835}],"n":"Intersect","d":769835,"h":223339069227,"f":1},{"r":769835,"p":[{"n":"a","p":769835},{"n":"b","p":769835}],"n":"Intersect","o":"@$1","d":769835,"h":227634036523,"f":33},{"r":262145,"p":[{"n":"rect","p":769835}],"n":"IntersectsWith","d":769835,"h":231929003819,"f":1},{"r":769835,"p":[{"n":"a","p":769835},{"n":"b","p":769835}],"n":"Union","d":769835,"h":236223971115,"f":33},{"r":65537,"p":[{"n":"pos","p":638763}],"n":"Offset","d":769835,"h":240518938411,"f":1},{"r":65537,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Offset","o":"@$1","d":769835,"h":244813905707,"f":1},{"r":1310721,"n":"ToString","d":769835,"h":253403840299,"f":32769}],"l":[{"t":769835,"n":"Empty","d":769835,"h":4295737131,"f":33},{"t":1114113,"n":"x","d":769835,"h":8590704427,"f":2},{"t":1114113,"n":"y","d":769835,"h":12885671723,"f":2},{"t":1114113,"n":"width","d":769835,"h":17180639019,"f":2},{"t":1114113,"n":"height","d":769835,"h":21475606315,"f":2}],"c":[{"p":[{"n":"x","p":1114113},{"n":"y","p":1114113},{"n":"width","p":1114113},{"n":"height","p":1114113}],"n":".ctor","o":"$ctor$2","d":769835,"h":25770573611,"f":1},{"p":[{"n":"location","p":638763},{"n":"size","p":900907}],"n":".ctor","o":"$ctor$3","d":769835,"h":30065540907,"f":1},{"p":[{"n":"vector","p":70713345}],"n":".ctor","o":"$ctor$4","d":769835,"h":34360508203,"f":1},{"n":".ctor","o":"$ctor$5","d":769835,"h":257698807595,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.RectangleF).$h],"h":769835,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.RectangleF) ]; }
            static get $fullName() { return `System.Drawing.RectangleF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Rectangle", ($self) => class Rectangle extends $.$spc.System.ValueType
        {
            /*Rectangle*/ static Empty;
            /*int*/  get x() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set x(value) { this.$setField(0, $.$spc.System.Int32, value); }
            /*int*/  get y() { return this.$getField(4, $.$spc.System.Int32); }
            /*int*/  set y(value) { this.$setField(4, $.$spc.System.Int32, value); }
            /*int*/  get width() { return this.$getField(8, $.$spc.System.Int32); }
            /*int*/  set width(value) { this.$setField(8, $.$spc.System.Int32, value); }
            /*int*/  get height() { return this.$getField(12, $.$spc.System.Int32); }
            /*int*/  set height(value) { this.$setField(12, $.$spc.System.Int32, value); }
            $ctor$2(/*int*/ x, /*int*/ y, /*int*/ width, /*int*/ height)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            $ctor$3(/*Point*/ location, /*Size*/ size)
            {
                super.$ctor$1();
                {
                    this.x = location.X;
                    this.y = location.Y;
                    this.width = size.Width;
                    this.height = size.Height;
                }
                return this;
            }
            static /*Rectangle */ FromLTRB(/*int*/ left, /*int*/ top, /*int*/ right, /*int*/ bottom)
            {
                return new $.$sdp.System.Drawing.Rectangle().$ctor$2(left, top, ((right - left) | 0), ((bottom - top) | 0));
            }
            /*Point */ get Location()
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(this.X, this.Y);
            }
            /*Point */ set Location(value)
            {
                this.X = value.X;
                this.Y = value.Y;
            }
            /*Size */ get Size()
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(this.Width, this.Height);
            }
            /*Size */ set Size(value)
            {
                this.Width = value.Width;
                this.Height = value.Height;
            }
            /*int */ get X()
            {
                return this.x;
            }
            /*int */ set X(value)
            {
                this.x = value;
            }
            /*int */ get Y()
            {
                return this.y;
            }
            /*int */ set Y(value)
            {
                this.y = value;
            }
            /*int */ get Width()
            {
                return this.width;
            }
            /*int */ set Width(value)
            {
                this.width = value;
            }
            /*int */ get Height()
            {
                return this.height;
            }
            /*int */ set Height(value)
            {
                this.height = value;
            }
            /*int */ get Left()
            {
                return this.X;
            }
            /*int */ get Top()
            {
                return this.Y;
            }
            /*int */ get Right()
            {
                return ((this.X + this.Width) | 0);
            }
            /*int */ get Bottom()
            {
                return ((this.Y + this.Height) | 0);
            }
            /*bool */ get IsEmpty()
            {
                return this.height === 0 && this.width === 0 && this.x === 0 && this.y === 0;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Rectangle) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Rectangle));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Rectangle.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Rectangle*/ other)
            {
                return $.$sdp.System.Drawing.Rectangle.op_Equality(this, other);
            }
            static /*bool */ op_Equality(/*Rectangle*/ left, /*Rectangle*/ right)
            {
                return left.X === right.X && left.Y === right.Y && left.Width === right.Width && left.Height === right.Height;
            }
            static /*bool */ op_Inequality(/*Rectangle*/ left, /*Rectangle*/ right)
            {
                return !($.$sdp.System.Drawing.Rectangle.op_Equality(left, right));
            }
            static /*Rectangle */ Ceiling(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2($.$cast(Math.ceil(value.X), $.$spc.System.Int32), $.$cast(Math.ceil(value.Y), $.$spc.System.Int32), $.$cast(Math.ceil(value.Width), $.$spc.System.Int32), $.$cast(Math.ceil(value.Height), $.$spc.System.Int32));
                }
            }
            static /*Rectangle */ Truncate(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2($.$cast(value.X, $.$spc.System.Int32), $.$cast(value.Y, $.$spc.System.Int32), $.$cast(value.Width, $.$spc.System.Int32), $.$cast(value.Height, $.$spc.System.Int32));
                }
            }
            static /*Rectangle */ Round(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2($.$cast($.$spc.System.Math.Round$4(value.X), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Y), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Width), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Height), $.$spc.System.Int32));
                }
            }
            /*bool */ Contains(/*int*/ x, /*int*/ y)
            {
                return this.X <= x && x < ((this.X + this.Width) | 0) && this.Y <= y && y < ((this.Y + this.Height) | 0);
            }
            /*bool */ Contains$1(/*Point*/ pt)
            {
                return this.Contains(pt.X, pt.Y);
            }
            /*bool */ Contains$2(/*Rectangle*/ rect)
            {
                return (this.X <= rect.X) && (((rect.X + rect.Width) | 0) <= ((this.X + this.Width) | 0)) && (this.Y <= rect.Y) && (((rect.Y + rect.Height) | 0) <= ((this.Y + this.Height) | 0));
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$3($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, this.X, this.Y, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Rectangle.GetHashCode.apply(this, arguments); }
            /*void */ Inflate(/*int*/ width, /*int*/ height)
            {
                //unchecked
                {
                    this.X -= width;
                    this.Y -= height;
                    this.Width += ((2 * width) | 0);
                    this.Height += ((2 * height) | 0);
                }
            }
            /*void */ Inflate$1(/*Size*/ size)
            {
                return this.Inflate(size.Width, size.Height);
            }
            static /*Rectangle */ Inflate$2(/*Rectangle*/ rect, /*int*/ x, /*int*/ y)
            {
                /*Rectangle*/ let r = rect;
                r.Inflate(x, y);
                return r;
            }
            /*void */ Intersect(/*Rectangle*/ rect)
            {
                /*Rectangle*/ let result = $.$sdp.System.Drawing.Rectangle.Intersect$1(rect.Clone(), this);
                this.X = result.X;
                this.Y = result.Y;
                this.Width = result.Width;
                this.Height = result.Height;
            }
            static /*Rectangle */ Intersect$1(/*Rectangle*/ a, /*Rectangle*/ b)
            {
                /*int*/ let x1 = $.$spc.System.Math.Max$4(a.X, b.X);
                /*int*/ let x2 = $.$spc.System.Math.Min$4(((a.X + a.Width) | 0), ((b.X + b.Width) | 0));
                /*int*/ let y1 = $.$spc.System.Math.Max$4(a.Y, b.Y);
                /*int*/ let y2 = $.$spc.System.Math.Min$4(((a.Y + a.Height) | 0), ((b.Y + b.Height) | 0));
                if (x2 >= x1 && y2 >= y1)
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2(x1, y1, ((x2 - x1) | 0), ((y2 - y1) | 0));
                }
                return $.$sdp.System.Drawing.Rectangle.Empty;
            }
            /*bool */ IntersectsWith(/*Rectangle*/ rect)
            {
                return (rect.X < ((this.X + this.Width) | 0)) && (this.X < ((rect.X + rect.Width) | 0)) && (rect.Y < ((this.Y + this.Height) | 0)) && (this.Y < ((rect.Y + rect.Height) | 0));
            }
            static /*Rectangle */ Union(/*Rectangle*/ a, /*Rectangle*/ b)
            {
                /*int*/ let x1 = $.$spc.System.Math.Min$4(a.X, b.X);
                /*int*/ let x2 = $.$spc.System.Math.Max$4(((a.X + a.Width) | 0), ((b.X + b.Width) | 0));
                /*int*/ let y1 = $.$spc.System.Math.Min$4(a.Y, b.Y);
                /*int*/ let y2 = $.$spc.System.Math.Max$4(((a.Y + a.Height) | 0), ((b.Y + b.Height) | 0));
                return new $.$sdp.System.Drawing.Rectangle().$ctor$2(x1, y1, ((x2 - x1) | 0), ((y2 - y1) | 0));
            }
            /*void */ Offset(/*Point*/ pos)
            {
                return this.Offset$1(pos.X, pos.Y);
            }
            /*void */ Offset$1(/*int*/ x, /*int*/ y)
            {
                //unchecked
                {
                    this.X += x;
                    this.Y += y;
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y},Width=${this.Width},Height=${this.Height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Rectangle.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Rectangle>.Equals(System.Drawing.Rectangle)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Rectangle);
                }
            }
            static $h = 704299;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":573227,"g":{"r":0,"d":0,"h":42950377259,"f":1},"s":{"r":0,"d":0,"h":47245344555,"f":1},"n":"Location","d":704299,"h":38655409963,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":835371,"g":{"r":0,"d":0,"h":55835279147,"f":1},"s":{"r":0,"d":0,"h":60130246443,"f":1},"n":"Size","d":704299,"h":51540311851,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":68720181035,"f":1},"s":{"r":0,"d":0,"h":73015148331,"f":1},"n":"X","d":704299,"h":64425213739,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":81605082923,"f":1},"s":{"r":0,"d":0,"h":85900050219,"f":1},"n":"Y","d":704299,"h":77310115627,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":94489984811,"f":1},"s":{"r":0,"d":0,"h":98784952107,"f":1},"n":"Width","d":704299,"h":90195017515,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":107374886699,"f":1},"s":{"r":0,"d":0,"h":111669853995,"f":1},"n":"Height","d":704299,"h":103079919403,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":120259788587,"f":1},"n":"Left","d":704299,"h":115964821291,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":128849723179,"f":1},"n":"Top","d":704299,"h":124554755883,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":137439657771,"f":1},"n":"Right","d":704299,"h":133144690475,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":146029592363,"f":1},"n":"Bottom","d":704299,"h":141734625067,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":262145,"g":{"r":0,"d":0,"h":154619526955,"f":1},"n":"IsEmpty","d":704299,"h":150324559659,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]}],"m":[{"r":704299,"p":[{"n":"left","p":655361},{"n":"top","p":655361},{"n":"right","p":655361},{"n":"bottom","p":655361}],"n":"FromLTRB","d":704299,"h":34360442667,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":704299,"h":158914494251,"f":32769},{"r":262145,"p":[{"n":"other","p":704299}],"n":"Equals","o":"@$2","d":704299,"h":163209461547,"f":1},{"r":704299,"p":[{"n":"value","p":769835}],"n":"Ceiling","d":704299,"h":176094363435,"f":33},{"r":704299,"p":[{"n":"value","p":769835}],"n":"Truncate","d":704299,"h":180389330731,"f":33},{"r":704299,"p":[{"n":"value","p":769835}],"n":"Round","d":704299,"h":184684298027,"f":33},{"r":262145,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Contains","d":704299,"h":188979265323,"f":1},{"r":262145,"p":[{"n":"pt","p":573227}],"n":"Contains","o":"@$1","d":704299,"h":193274232619,"f":1},{"r":262145,"p":[{"n":"rect","p":704299}],"n":"Contains","o":"@$2","d":704299,"h":197569199915,"f":1},{"r":655361,"n":"GetHashCode","d":704299,"h":201864167211,"f":32769},{"r":65537,"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":"Inflate","d":704299,"h":206159134507,"f":1},{"r":65537,"p":[{"n":"size","p":835371}],"n":"Inflate","o":"@$1","d":704299,"h":210454101803,"f":1},{"r":704299,"p":[{"n":"rect","p":704299},{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Inflate","o":"@$2","d":704299,"h":214749069099,"f":33},{"r":65537,"p":[{"n":"rect","p":704299}],"n":"Intersect","d":704299,"h":219044036395,"f":1},{"r":704299,"p":[{"n":"a","p":704299},{"n":"b","p":704299}],"n":"Intersect","o":"@$1","d":704299,"h":223339003691,"f":33},{"r":262145,"p":[{"n":"rect","p":704299}],"n":"IntersectsWith","d":704299,"h":227633970987,"f":1},{"r":704299,"p":[{"n":"a","p":704299},{"n":"b","p":704299}],"n":"Union","d":704299,"h":231928938283,"f":33},{"r":65537,"p":[{"n":"pos","p":573227}],"n":"Offset","d":704299,"h":236223905579,"f":1},{"r":65537,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Offset","o":"@$1","d":704299,"h":240518872875,"f":1},{"r":1310721,"n":"ToString","d":704299,"h":244813840171,"f":32769}],"l":[{"t":704299,"n":"Empty","d":704299,"h":4295671595,"f":33},{"t":655361,"n":"x","d":704299,"h":8590638891,"f":2},{"t":655361,"n":"y","d":704299,"h":12885606187,"f":2},{"t":655361,"n":"width","d":704299,"h":17180573483,"f":2},{"t":655361,"n":"height","d":704299,"h":21475540779,"f":2}],"c":[{"p":[{"n":"x","p":655361},{"n":"y","p":655361},{"n":"width","p":655361},{"n":"height","p":655361}],"n":".ctor","o":"$ctor$2","d":704299,"h":25770508075,"f":1},{"p":[{"n":"location","p":573227},{"n":"size","p":835371}],"n":".ctor","o":"$ctor$3","d":704299,"h":30065475371,"f":1},{"n":".ctor","o":"$ctor$4","d":704299,"h":249108807467,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Rectangle).$h],"h":704299,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1505155,"c":17181374339,"a":[{"v":"System.Drawing.RectangleConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Rectangle) ]; }
            static get $fullName() { return `System.Drawing.Rectangle`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Color", ($self) => class Color extends $.$spc.System.ValueType
        {
            /*Color*/ static Empty;
            static /*Color */ get Transparent()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(27/*KnownColor.Transparent*/);
            }
            static /*Color */ get AliceBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(28/*KnownColor.AliceBlue*/);
            }
            static /*Color */ get AntiqueWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(29/*KnownColor.AntiqueWhite*/);
            }
            static /*Color */ get Aqua()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(30/*KnownColor.Aqua*/);
            }
            static /*Color */ get Aquamarine()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(31/*KnownColor.Aquamarine*/);
            }
            static /*Color */ get Azure()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(32/*KnownColor.Azure*/);
            }
            static /*Color */ get Beige()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(33/*KnownColor.Beige*/);
            }
            static /*Color */ get Bisque()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(34/*KnownColor.Bisque*/);
            }
            static /*Color */ get Black()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(35/*KnownColor.Black*/);
            }
            static /*Color */ get BlanchedAlmond()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(36/*KnownColor.BlanchedAlmond*/);
            }
            static /*Color */ get Blue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(37/*KnownColor.Blue*/);
            }
            static /*Color */ get BlueViolet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(38/*KnownColor.BlueViolet*/);
            }
            static /*Color */ get Brown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(39/*KnownColor.Brown*/);
            }
            static /*Color */ get BurlyWood()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(40/*KnownColor.BurlyWood*/);
            }
            static /*Color */ get CadetBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(41/*KnownColor.CadetBlue*/);
            }
            static /*Color */ get Chartreuse()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(42/*KnownColor.Chartreuse*/);
            }
            static /*Color */ get Chocolate()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(43/*KnownColor.Chocolate*/);
            }
            static /*Color */ get Coral()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(44/*KnownColor.Coral*/);
            }
            static /*Color */ get CornflowerBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(45/*KnownColor.CornflowerBlue*/);
            }
            static /*Color */ get Cornsilk()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(46/*KnownColor.Cornsilk*/);
            }
            static /*Color */ get Crimson()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(47/*KnownColor.Crimson*/);
            }
            static /*Color */ get Cyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(48/*KnownColor.Cyan*/);
            }
            static /*Color */ get DarkBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(49/*KnownColor.DarkBlue*/);
            }
            static /*Color */ get DarkCyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(50/*KnownColor.DarkCyan*/);
            }
            static /*Color */ get DarkGoldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(51/*KnownColor.DarkGoldenrod*/);
            }
            static /*Color */ get DarkGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(52/*KnownColor.DarkGray*/);
            }
            static /*Color */ get DarkGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(53/*KnownColor.DarkGreen*/);
            }
            static /*Color */ get DarkKhaki()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(54/*KnownColor.DarkKhaki*/);
            }
            static /*Color */ get DarkMagenta()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(55/*KnownColor.DarkMagenta*/);
            }
            static /*Color */ get DarkOliveGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(56/*KnownColor.DarkOliveGreen*/);
            }
            static /*Color */ get DarkOrange()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(57/*KnownColor.DarkOrange*/);
            }
            static /*Color */ get DarkOrchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(58/*KnownColor.DarkOrchid*/);
            }
            static /*Color */ get DarkRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(59/*KnownColor.DarkRed*/);
            }
            static /*Color */ get DarkSalmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(60/*KnownColor.DarkSalmon*/);
            }
            static /*Color */ get DarkSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(61/*KnownColor.DarkSeaGreen*/);
            }
            static /*Color */ get DarkSlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(62/*KnownColor.DarkSlateBlue*/);
            }
            static /*Color */ get DarkSlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(63/*KnownColor.DarkSlateGray*/);
            }
            static /*Color */ get DarkTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(64/*KnownColor.DarkTurquoise*/);
            }
            static /*Color */ get DarkViolet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(65/*KnownColor.DarkViolet*/);
            }
            static /*Color */ get DeepPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(66/*KnownColor.DeepPink*/);
            }
            static /*Color */ get DeepSkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(67/*KnownColor.DeepSkyBlue*/);
            }
            static /*Color */ get DimGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(68/*KnownColor.DimGray*/);
            }
            static /*Color */ get DodgerBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(69/*KnownColor.DodgerBlue*/);
            }
            static /*Color */ get Firebrick()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(70/*KnownColor.Firebrick*/);
            }
            static /*Color */ get FloralWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(71/*KnownColor.FloralWhite*/);
            }
            static /*Color */ get ForestGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(72/*KnownColor.ForestGreen*/);
            }
            static /*Color */ get Fuchsia()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(73/*KnownColor.Fuchsia*/);
            }
            static /*Color */ get Gainsboro()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(74/*KnownColor.Gainsboro*/);
            }
            static /*Color */ get GhostWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(75/*KnownColor.GhostWhite*/);
            }
            static /*Color */ get Gold()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(76/*KnownColor.Gold*/);
            }
            static /*Color */ get Goldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(77/*KnownColor.Goldenrod*/);
            }
            static /*Color */ get Gray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(78/*KnownColor.Gray*/);
            }
            static /*Color */ get Green()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(79/*KnownColor.Green*/);
            }
            static /*Color */ get GreenYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(80/*KnownColor.GreenYellow*/);
            }
            static /*Color */ get Honeydew()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(81/*KnownColor.Honeydew*/);
            }
            static /*Color */ get HotPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(82/*KnownColor.HotPink*/);
            }
            static /*Color */ get IndianRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(83/*KnownColor.IndianRed*/);
            }
            static /*Color */ get Indigo()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(84/*KnownColor.Indigo*/);
            }
            static /*Color */ get Ivory()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(85/*KnownColor.Ivory*/);
            }
            static /*Color */ get Khaki()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(86/*KnownColor.Khaki*/);
            }
            static /*Color */ get Lavender()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(87/*KnownColor.Lavender*/);
            }
            static /*Color */ get LavenderBlush()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(88/*KnownColor.LavenderBlush*/);
            }
            static /*Color */ get LawnGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(89/*KnownColor.LawnGreen*/);
            }
            static /*Color */ get LemonChiffon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(90/*KnownColor.LemonChiffon*/);
            }
            static /*Color */ get LightBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(91/*KnownColor.LightBlue*/);
            }
            static /*Color */ get LightCoral()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(92/*KnownColor.LightCoral*/);
            }
            static /*Color */ get LightCyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(93/*KnownColor.LightCyan*/);
            }
            static /*Color */ get LightGoldenrodYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(94/*KnownColor.LightGoldenrodYellow*/);
            }
            static /*Color */ get LightGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(96/*KnownColor.LightGreen*/);
            }
            static /*Color */ get LightGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(95/*KnownColor.LightGray*/);
            }
            static /*Color */ get LightPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(97/*KnownColor.LightPink*/);
            }
            static /*Color */ get LightSalmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(98/*KnownColor.LightSalmon*/);
            }
            static /*Color */ get LightSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(99/*KnownColor.LightSeaGreen*/);
            }
            static /*Color */ get LightSkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(100/*KnownColor.LightSkyBlue*/);
            }
            static /*Color */ get LightSlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(101/*KnownColor.LightSlateGray*/);
            }
            static /*Color */ get LightSteelBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(102/*KnownColor.LightSteelBlue*/);
            }
            static /*Color */ get LightYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(103/*KnownColor.LightYellow*/);
            }
            static /*Color */ get Lime()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(104/*KnownColor.Lime*/);
            }
            static /*Color */ get LimeGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(105/*KnownColor.LimeGreen*/);
            }
            static /*Color */ get Linen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(106/*KnownColor.Linen*/);
            }
            static /*Color */ get Magenta()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(107/*KnownColor.Magenta*/);
            }
            static /*Color */ get Maroon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(108/*KnownColor.Maroon*/);
            }
            static /*Color */ get MediumAquamarine()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(109/*KnownColor.MediumAquamarine*/);
            }
            static /*Color */ get MediumBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(110/*KnownColor.MediumBlue*/);
            }
            static /*Color */ get MediumOrchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(111/*KnownColor.MediumOrchid*/);
            }
            static /*Color */ get MediumPurple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(112/*KnownColor.MediumPurple*/);
            }
            static /*Color */ get MediumSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(113/*KnownColor.MediumSeaGreen*/);
            }
            static /*Color */ get MediumSlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(114/*KnownColor.MediumSlateBlue*/);
            }
            static /*Color */ get MediumSpringGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(115/*KnownColor.MediumSpringGreen*/);
            }
            static /*Color */ get MediumTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(116/*KnownColor.MediumTurquoise*/);
            }
            static /*Color */ get MediumVioletRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(117/*KnownColor.MediumVioletRed*/);
            }
            static /*Color */ get MidnightBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(118/*KnownColor.MidnightBlue*/);
            }
            static /*Color */ get MintCream()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(119/*KnownColor.MintCream*/);
            }
            static /*Color */ get MistyRose()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(120/*KnownColor.MistyRose*/);
            }
            static /*Color */ get Moccasin()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(121/*KnownColor.Moccasin*/);
            }
            static /*Color */ get NavajoWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(122/*KnownColor.NavajoWhite*/);
            }
            static /*Color */ get Navy()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(123/*KnownColor.Navy*/);
            }
            static /*Color */ get OldLace()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(124/*KnownColor.OldLace*/);
            }
            static /*Color */ get Olive()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(125/*KnownColor.Olive*/);
            }
            static /*Color */ get OliveDrab()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(126/*KnownColor.OliveDrab*/);
            }
            static /*Color */ get Orange()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(127/*KnownColor.Orange*/);
            }
            static /*Color */ get OrangeRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(128/*KnownColor.OrangeRed*/);
            }
            static /*Color */ get Orchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(129/*KnownColor.Orchid*/);
            }
            static /*Color */ get PaleGoldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(130/*KnownColor.PaleGoldenrod*/);
            }
            static /*Color */ get PaleGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(131/*KnownColor.PaleGreen*/);
            }
            static /*Color */ get PaleTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(132/*KnownColor.PaleTurquoise*/);
            }
            static /*Color */ get PaleVioletRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(133/*KnownColor.PaleVioletRed*/);
            }
            static /*Color */ get PapayaWhip()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(134/*KnownColor.PapayaWhip*/);
            }
            static /*Color */ get PeachPuff()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(135/*KnownColor.PeachPuff*/);
            }
            static /*Color */ get Peru()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(136/*KnownColor.Peru*/);
            }
            static /*Color */ get Pink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(137/*KnownColor.Pink*/);
            }
            static /*Color */ get Plum()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(138/*KnownColor.Plum*/);
            }
            static /*Color */ get PowderBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(139/*KnownColor.PowderBlue*/);
            }
            static /*Color */ get Purple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(140/*KnownColor.Purple*/);
            }
            static /*Color */ get RebeccaPurple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(175/*KnownColor.RebeccaPurple*/);
            }
            static /*Color */ get Red()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(141/*KnownColor.Red*/);
            }
            static /*Color */ get RosyBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(142/*KnownColor.RosyBrown*/);
            }
            static /*Color */ get RoyalBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(143/*KnownColor.RoyalBlue*/);
            }
            static /*Color */ get SaddleBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(144/*KnownColor.SaddleBrown*/);
            }
            static /*Color */ get Salmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(145/*KnownColor.Salmon*/);
            }
            static /*Color */ get SandyBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(146/*KnownColor.SandyBrown*/);
            }
            static /*Color */ get SeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(147/*KnownColor.SeaGreen*/);
            }
            static /*Color */ get SeaShell()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(148/*KnownColor.SeaShell*/);
            }
            static /*Color */ get Sienna()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(149/*KnownColor.Sienna*/);
            }
            static /*Color */ get Silver()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(150/*KnownColor.Silver*/);
            }
            static /*Color */ get SkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(151/*KnownColor.SkyBlue*/);
            }
            static /*Color */ get SlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(152/*KnownColor.SlateBlue*/);
            }
            static /*Color */ get SlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(153/*KnownColor.SlateGray*/);
            }
            static /*Color */ get Snow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(154/*KnownColor.Snow*/);
            }
            static /*Color */ get SpringGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(155/*KnownColor.SpringGreen*/);
            }
            static /*Color */ get SteelBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(156/*KnownColor.SteelBlue*/);
            }
            static /*Color */ get Tan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(157/*KnownColor.Tan*/);
            }
            static /*Color */ get Teal()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(158/*KnownColor.Teal*/);
            }
            static /*Color */ get Thistle()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(159/*KnownColor.Thistle*/);
            }
            static /*Color */ get Tomato()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(160/*KnownColor.Tomato*/);
            }
            static /*Color */ get Turquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(161/*KnownColor.Turquoise*/);
            }
            static /*Color */ get Violet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(162/*KnownColor.Violet*/);
            }
            static /*Color */ get Wheat()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(163/*KnownColor.Wheat*/);
            }
            static /*Color */ get White()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(164/*KnownColor.White*/);
            }
            static /*Color */ get WhiteSmoke()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(165/*KnownColor.WhiteSmoke*/);
            }
            static /*Color */ get Yellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(166/*KnownColor.Yellow*/);
            }
            static /*Color */ get YellowGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(167/*KnownColor.YellowGreen*/);
            }
            /*short*/ static StateKnownColorValid = 1;
            /*short*/ static StateARGBValueValid = 2;
            /*short*/ static StateValueMask = 2;
            /*short*/ static StateNameValid = 8;
            /*long*/ static NotDefinedValue = 0n;
            /*int*/ static ARGBAlphaShift = 24;
            /*int*/ static ARGBRedShift = 16;
            /*int*/ static ARGBGreenShift = 8;
            /*int*/ static ARGBBlueShift = 0;
            /*uint*/ static ARGBAlphaMask = 4278190080;
            /*uint*/ static ARGBRedMask = 16711680;
            /*uint*/ static ARGBGreenMask = 65280;
            /*uint*/ static ARGBBlueMask = 255;
            /*string?*/  get name() { return this.$getField(0, 4); }
            /*string?*/  set name(value) { this.$setField(0, 4, value); }
            /*long*/  get value() { return this.$getField(4, 8); }
            /*long*/  set value(value) { this.$setField(4, 8, value); }
            /*short*/  get knownColor() { return this.$getField(12, 2); }
            /*short*/  set knownColor(value) { this.$setField(12, 2, value); }
            /*short*/  get state() { return this.$getField(14, 2); }
            /*short*/  set state(value) { this.$setField(14, 2, value); }
            $ctor$2(/*KnownColor*/ knownColor)
            {
                super.$ctor$1();
                {
                    this.value = 0n;
                    this.state = 1/*StateKnownColorValid*/;
                    this.name = null;
                    this.knownColor = $.$cast(knownColor, $.$spc.System.Int16);
                }
                return this;
            }
            $ctor$3(/*long*/ value, /*short*/ state, /*string?*/ name, /*KnownColor*/ knownColor)
            {
                super.$ctor$1();
                {
                    this.value = value;
                    this.state = state;
                    this.name = name;
                    this.knownColor = $.$cast(knownColor, $.$spc.System.Int16);
                }
                return this;
            }
            /*byte */ get R()
            {
                return $.$cast((this.Value >> BigInt(16/*ARGBRedShift*/)), $.$spc.System.Byte);
            }
            /*byte */ get G()
            {
                return $.$cast((this.Value >> BigInt(8/*ARGBGreenShift*/)), $.$spc.System.Byte);
            }
            /*byte */ get B()
            {
                return $.$cast((this.Value >> BigInt(0/*ARGBBlueShift*/)), $.$spc.System.Byte);
            }
            /*byte */ get A()
            {
                return $.$cast((this.Value >> BigInt(24/*ARGBAlphaShift*/)), $.$spc.System.Byte);
            }
            /*bool */ get IsKnownColor()
            {
                return (this.state & 1/*StateKnownColorValid*/) !== 0;
            }
            /*bool */ get IsEmpty()
            {
                return this.state === 0;
            }
            /*bool */ get IsNamedColor()
            {
                return ((this.state & 8/*StateNameValid*/) !== 0) || this.IsKnownColor;
            }
            /*bool */ get IsSystemColor()
            {
                return this.IsKnownColor && $.$sdp.System.Drawing.Color.IsKnownColorSystem($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor));
            }
            static /*bool */ IsKnownColorSystem(/*KnownColor*/ knownColor)
            {
                return $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(knownColor).$v === 0/*KnownColorTable.KnownColorKindSystem*/;
            }
            /*string */ get NameAndARGBValue()
            {
                return `{{Name = ${this.Name}, ARGB = (${this.A}, ${this.R}, ${this.G}, ${this.B})}}`;
            }
            /*string */ get Name()
            {
                if ((this.state & 8/*StateNameValid*/) !== 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(this.name, null), "name != null");
                    return this.name;
                }
                if (this.IsKnownColor)
                {
                    /*string*/ let tablename = $.$sdp.System.Drawing.KnownColorNames.KnownColorToName($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor));
                    $.$spc.System.Diagnostics.Debug.Assert$2($.$spc.System.String.op_Inequality(tablename, null), `Could not find known color '${$.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor)}' in the KnownColorTable`);
                    return tablename;
                }
                return $.$spc.System.Int64.ToString$2.call(this.value, "x");
            }
            /*long */ get Value()
            {
                if ((this.state & 2/*StateValueMask*/) !== 0)
                {
                    return this.value;
                }
                if (this.IsKnownColor)
                {
                    return BigInt($.$sdp.System.Drawing.KnownColorTable.KnownColorToArgb($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor)));
                }
                return 0n;
            }
            static /*void */ CheckByte(/*int*/ value, /*string*/ name)
            {
                /*static void*/  function ThrowOutOfByteRange(/*int*/ v, /*string*/ n)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sdp.System.SR.Format$3($.$sdp.System.SR.InvalidEx2BoundArgument, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ n, $.$box(v, $.$spc.System.Int32), $.$box(0/*byte.MinValue*/, $.$spc.System.Byte), $.$box(255/*byte.MaxValue*/, $.$spc.System.Byte) ], null, null)));
                }
                if ((value >>> 0) > 255/*byte.MaxValue*/)
                {
                    ThrowOutOfByteRange(value, name);
                }
            }
            static /*Color */ FromArgb(/*uint*/ argb)
            {
                return new $.$sdp.System.Drawing.Color().$ctor$3(BigInt(argb), 2/*StateARGBValueValid*/, null, $.$cast(0, $.$sdp.System.Drawing.KnownColor));
            }
            static /*Color */ FromArgb$1(/*int*/ argb)
            {
                return $.$sdp.System.Drawing.Color.FromArgb((argb >>> 0));
            }
            static /*Color */ FromArgb$2(/*int*/ alpha, /*int*/ red, /*int*/ green, /*int*/ blue)
            {
                $.$sdp.System.Drawing.Color.CheckByte(alpha, "alpha");
                $.$sdp.System.Drawing.Color.CheckByte(red, "red");
                $.$sdp.System.Drawing.Color.CheckByte(green, "green");
                $.$sdp.System.Drawing.Color.CheckByte(blue, "blue");
                return $.$sdp.System.Drawing.Color.FromArgb(((alpha >>> 0) << 24/*ARGBAlphaShift*/) >>> 0 | ((red >>> 0) << 16/*ARGBRedShift*/) >>> 0 | ((green >>> 0) << 8/*ARGBGreenShift*/) >>> 0 | ((blue >>> 0) << 0/*ARGBBlueShift*/) >>> 0);
            }
            static /*Color */ FromArgb$3(/*int*/ alpha, /*Color*/ baseColor)
            {
                $.$sdp.System.Drawing.Color.CheckByte(alpha, "alpha");
                return $.$sdp.System.Drawing.Color.FromArgb(((alpha >>> 0) << 24/*ARGBAlphaShift*/) >>> 0 | $.$cast(baseColor.Value, $.$spc.System.UInt32) & ~4278190080/*ARGBAlphaMask*/);
            }
            static /*Color */ FromArgb$4(/*int*/ red, /*int*/ green, /*int*/ blue)
            {
                return $.$sdp.System.Drawing.Color.FromArgb$2(255/*byte.MaxValue*/, red, green, blue);
            }
            static /*Color */ FromKnownColor(/*KnownColor*/ color)
            {
                return color <= 0 || color > 175/*KnownColor.RebeccaPurple*/ ? $.$sdp.System.Drawing.Color.FromName($.$spc.System.Enum.ToStringT($.$sdp.System.Drawing.KnownColor, $.$spc.System.UInt32, color)) : new $.$sdp.System.Drawing.Color().$ctor$2(color);
            }
            static /*Color */ FromName(/*string*/ name)
            {
                /*Color*/ let color;
                if ($.$sdp.System.Drawing.ColorTable.TryGetNamedColor(name, $.$ref(() => color, ($v) => color = $v, $.$sdp.System.Drawing.Color)))
                {
                    return color;
                }
                return new $.$sdp.System.Drawing.Color().$ctor$3(0n, 8/*StateNameValid*/, name, $.$cast(0, $.$sdp.System.Drawing.KnownColor));
            }
            /*void */ GetRgbValues(/*out int*/ r, /*out int*/ g, /*out int*/ b)
            {
                /*uint*/ let value = $.$cast(this.Value, $.$spc.System.UInt32);
                r.$v = ((value & 16711680/*ARGBRedMask*/) | 0) >> 16/*ARGBRedShift*/;
                g.$v = ((value & 65280/*ARGBGreenMask*/) | 0) >> 8/*ARGBGreenShift*/;
                b.$v = ((value & 255/*ARGBBlueMask*/) | 0) >> 0/*ARGBBlueShift*/;
            }
            static /*void */ MinMaxRgb(/*out int*/ min, /*out int*/ max, /*int*/ r, /*int*/ g, /*int*/ b)
            {
                if (r > g)
                {
                    max.$v = r;
                    min.$v = g;
                }
                else 
                {
                    max.$v = g;
                    min.$v = r;
                }
                if (b > max.$v)
                {
                    max.$v = b;
                }
                else if (b < min.$v)
                {
                    min.$v = b;
                }
            }
            /*float */ GetBrightness()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$spc.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$spc.System.Int32), r, g, b);
                return (((max + min) | 0)) / (255/*byte.MaxValue*/ * 2);
            }
            /*float */ GetHue()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                if (r === g && g === b)
                {
                    return 0;
                }
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$spc.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$spc.System.Int32), r, g, b);
                /*float*/ let delta = ((max - min) | 0);
                /*float*/ let hue;
                if (r === max)
                {
                    hue = (((g - b) | 0)) / delta;
                }
                else if (g === max)
                {
                    hue = (((b - r) | 0)) / delta + 2;
                }
                else 
                {
                    hue = (((r - g) | 0)) / delta + 4;
                }
                hue *= 60;
                if (hue < 0)
                {
                    hue += 360;
                }
                return hue;
            }
            /*float */ GetSaturation()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                if (r === g && g === b)
                {
                    return 0;
                }
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$spc.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$spc.System.Int32), r, g, b);
                /*int*/ let div = ((max + min) | 0);
                if (div > 255/*byte.MaxValue*/)
                {
                    div = ((((((255/*byte.MaxValue*/ * 2) | 0) - max) | 0) - min) | 0);
                }
                return (((max - min) | 0)) / $.$cast(div, $.$spc.System.Single);
            }
            /*int */ ToArgb()
            {
                return $.$cast(this.Value, $.$spc.System.Int32);
            }
            /*KnownColor */ ToKnownColor()
            {
                return $.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.IsNamedColor ? `${"Color"} [${this.Name}]` : (this.state & 2/*StateValueMask*/) !== 0 ? `${"Color"} [A=${this.A}, R=${this.R}, G=${this.G}, B=${this.B}]` : `${"Color"} [Empty]`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Color.ToString.apply(this, arguments); }
            static /*bool */ op_Equality(/*Color*/ left, /*Color*/ right)
            {
                return left.value === right.value && left.state === right.state && left.knownColor === right.knownColor && $.$spc.System.String.op_Equality(left.name, right.name);
            }
            static /*bool */ op_Inequality(/*Color*/ left, /*Color*/ right)
            {
                return !($.$sdp.System.Drawing.Color.op_Equality(left, right));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$sdp.System.Drawing.Color, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Color.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Color*/ other)
            {
                return $.$sdp.System.Drawing.Color.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                if ($.$spc.System.String.op_Inequality(this.name, null) && !this.IsKnownColor)
                {
                    return $.$spc.System.String.GetHashCode.call(this.name);
                }
                return $.$spc.System.HashCode.Combine$2($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int64.GetHashCode.call(this.value), $.$spc.System.Int16.GetHashCode.call(this.state), $.$spc.System.Int16.GetHashCode.call(this.knownColor));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Color.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Color>.Equals(System.Drawing.Color)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.name = this.name;
                copy.value = this.value;
                copy.knownColor = this.knownColor;
                copy.state = this.state;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.name = null;
                this.value = 0n;
                this.knownColor = 0;
                this.state = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Color);
                }
            }
            static $h = 114475;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":114475,"g":{"r":0,"d":0,"h":12885016363,"f":33},"n":"Transparent","d":114475,"h":8590049067,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":21474950955,"f":33},"n":"AliceBlue","d":114475,"h":17179983659,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":30064885547,"f":33},"n":"AntiqueWhite","d":114475,"h":25769918251,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":38654820139,"f":33},"n":"Aqua","d":114475,"h":34359852843,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":47244754731,"f":33},"n":"Aquamarine","d":114475,"h":42949787435,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":55834689323,"f":33},"n":"Azure","d":114475,"h":51539722027,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":64424623915,"f":33},"n":"Beige","d":114475,"h":60129656619,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":73014558507,"f":33},"n":"Bisque","d":114475,"h":68719591211,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":81604493099,"f":33},"n":"Black","d":114475,"h":77309525803,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":90194427691,"f":33},"n":"BlanchedAlmond","d":114475,"h":85899460395,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":98784362283,"f":33},"n":"Blue","d":114475,"h":94489394987,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":107374296875,"f":33},"n":"BlueViolet","d":114475,"h":103079329579,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":115964231467,"f":33},"n":"Brown","d":114475,"h":111669264171,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":124554166059,"f":33},"n":"BurlyWood","d":114475,"h":120259198763,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":133144100651,"f":33},"n":"CadetBlue","d":114475,"h":128849133355,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":141734035243,"f":33},"n":"Chartreuse","d":114475,"h":137439067947,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":150323969835,"f":33},"n":"Chocolate","d":114475,"h":146029002539,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":158913904427,"f":33},"n":"Coral","d":114475,"h":154618937131,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":167503839019,"f":33},"n":"CornflowerBlue","d":114475,"h":163208871723,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":176093773611,"f":33},"n":"Cornsilk","d":114475,"h":171798806315,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":184683708203,"f":33},"n":"Crimson","d":114475,"h":180388740907,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":193273642795,"f":33},"n":"Cyan","d":114475,"h":188978675499,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":201863577387,"f":33},"n":"DarkBlue","d":114475,"h":197568610091,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":210453511979,"f":33},"n":"DarkCyan","d":114475,"h":206158544683,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":219043446571,"f":33},"n":"DarkGoldenrod","d":114475,"h":214748479275,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":227633381163,"f":33},"n":"DarkGray","d":114475,"h":223338413867,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":236223315755,"f":33},"n":"DarkGreen","d":114475,"h":231928348459,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":244813250347,"f":33},"n":"DarkKhaki","d":114475,"h":240518283051,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":253403184939,"f":33},"n":"DarkMagenta","d":114475,"h":249108217643,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":261993119531,"f":33},"n":"DarkOliveGreen","d":114475,"h":257698152235,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":270583054123,"f":33},"n":"DarkOrange","d":114475,"h":266288086827,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":279172988715,"f":33},"n":"DarkOrchid","d":114475,"h":274878021419,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":287762923307,"f":33},"n":"DarkRed","d":114475,"h":283467956011,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":296352857899,"f":33},"n":"DarkSalmon","d":114475,"h":292057890603,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":304942792491,"f":33},"n":"DarkSeaGreen","d":114475,"h":300647825195,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":313532727083,"f":33},"n":"DarkSlateBlue","d":114475,"h":309237759787,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":322122661675,"f":33},"n":"DarkSlateGray","d":114475,"h":317827694379,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":330712596267,"f":33},"n":"DarkTurquoise","d":114475,"h":326417628971,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":339302530859,"f":33},"n":"DarkViolet","d":114475,"h":335007563563,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":347892465451,"f":33},"n":"DeepPink","d":114475,"h":343597498155,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":356482400043,"f":33},"n":"DeepSkyBlue","d":114475,"h":352187432747,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":365072334635,"f":33},"n":"DimGray","d":114475,"h":360777367339,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":373662269227,"f":33},"n":"DodgerBlue","d":114475,"h":369367301931,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":382252203819,"f":33},"n":"Firebrick","d":114475,"h":377957236523,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":390842138411,"f":33},"n":"FloralWhite","d":114475,"h":386547171115,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":399432073003,"f":33},"n":"ForestGreen","d":114475,"h":395137105707,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":408022007595,"f":33},"n":"Fuchsia","d":114475,"h":403727040299,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":416611942187,"f":33},"n":"Gainsboro","d":114475,"h":412316974891,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":425201876779,"f":33},"n":"GhostWhite","d":114475,"h":420906909483,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":433791811371,"f":33},"n":"Gold","d":114475,"h":429496844075,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":442381745963,"f":33},"n":"Goldenrod","d":114475,"h":438086778667,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":450971680555,"f":33},"n":"Gray","d":114475,"h":446676713259,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":459561615147,"f":33},"n":"Green","d":114475,"h":455266647851,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":468151549739,"f":33},"n":"GreenYellow","d":114475,"h":463856582443,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":476741484331,"f":33},"n":"Honeydew","d":114475,"h":472446517035,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":485331418923,"f":33},"n":"HotPink","d":114475,"h":481036451627,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":493921353515,"f":33},"n":"IndianRed","d":114475,"h":489626386219,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":502511288107,"f":33},"n":"Indigo","d":114475,"h":498216320811,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":511101222699,"f":33},"n":"Ivory","d":114475,"h":506806255403,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":519691157291,"f":33},"n":"Khaki","d":114475,"h":515396189995,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":528281091883,"f":33},"n":"Lavender","d":114475,"h":523986124587,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":536871026475,"f":33},"n":"LavenderBlush","d":114475,"h":532576059179,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":545460961067,"f":33},"n":"LawnGreen","d":114475,"h":541165993771,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":554050895659,"f":33},"n":"LemonChiffon","d":114475,"h":549755928363,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":562640830251,"f":33},"n":"LightBlue","d":114475,"h":558345862955,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":571230764843,"f":33},"n":"LightCoral","d":114475,"h":566935797547,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":579820699435,"f":33},"n":"LightCyan","d":114475,"h":575525732139,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":588410634027,"f":33},"n":"LightGoldenrodYellow","d":114475,"h":584115666731,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":597000568619,"f":33},"n":"LightGreen","d":114475,"h":592705601323,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":605590503211,"f":33},"n":"LightGray","d":114475,"h":601295535915,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":614180437803,"f":33},"n":"LightPink","d":114475,"h":609885470507,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":622770372395,"f":33},"n":"LightSalmon","d":114475,"h":618475405099,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":631360306987,"f":33},"n":"LightSeaGreen","d":114475,"h":627065339691,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":639950241579,"f":33},"n":"LightSkyBlue","d":114475,"h":635655274283,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":648540176171,"f":33},"n":"LightSlateGray","d":114475,"h":644245208875,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":657130110763,"f":33},"n":"LightSteelBlue","d":114475,"h":652835143467,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":665720045355,"f":33},"n":"LightYellow","d":114475,"h":661425078059,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":674309979947,"f":33},"n":"Lime","d":114475,"h":670015012651,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":682899914539,"f":33},"n":"LimeGreen","d":114475,"h":678604947243,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":691489849131,"f":33},"n":"Linen","d":114475,"h":687194881835,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":700079783723,"f":33},"n":"Magenta","d":114475,"h":695784816427,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":708669718315,"f":33},"n":"Maroon","d":114475,"h":704374751019,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":717259652907,"f":33},"n":"MediumAquamarine","d":114475,"h":712964685611,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":725849587499,"f":33},"n":"MediumBlue","d":114475,"h":721554620203,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":734439522091,"f":33},"n":"MediumOrchid","d":114475,"h":730144554795,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":743029456683,"f":33},"n":"MediumPurple","d":114475,"h":738734489387,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":751619391275,"f":33},"n":"MediumSeaGreen","d":114475,"h":747324423979,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":760209325867,"f":33},"n":"MediumSlateBlue","d":114475,"h":755914358571,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":768799260459,"f":33},"n":"MediumSpringGreen","d":114475,"h":764504293163,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":777389195051,"f":33},"n":"MediumTurquoise","d":114475,"h":773094227755,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":785979129643,"f":33},"n":"MediumVioletRed","d":114475,"h":781684162347,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":794569064235,"f":33},"n":"MidnightBlue","d":114475,"h":790274096939,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":803158998827,"f":33},"n":"MintCream","d":114475,"h":798864031531,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":811748933419,"f":33},"n":"MistyRose","d":114475,"h":807453966123,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":820338868011,"f":33},"n":"Moccasin","d":114475,"h":816043900715,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":828928802603,"f":33},"n":"NavajoWhite","d":114475,"h":824633835307,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":837518737195,"f":33},"n":"Navy","d":114475,"h":833223769899,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":846108671787,"f":33},"n":"OldLace","d":114475,"h":841813704491,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":854698606379,"f":33},"n":"Olive","d":114475,"h":850403639083,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":863288540971,"f":33},"n":"OliveDrab","d":114475,"h":858993573675,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":871878475563,"f":33},"n":"Orange","d":114475,"h":867583508267,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":880468410155,"f":33},"n":"OrangeRed","d":114475,"h":876173442859,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":889058344747,"f":33},"n":"Orchid","d":114475,"h":884763377451,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":897648279339,"f":33},"n":"PaleGoldenrod","d":114475,"h":893353312043,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":906238213931,"f":33},"n":"PaleGreen","d":114475,"h":901943246635,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":914828148523,"f":33},"n":"PaleTurquoise","d":114475,"h":910533181227,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":923418083115,"f":33},"n":"PaleVioletRed","d":114475,"h":919123115819,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":932008017707,"f":33},"n":"PapayaWhip","d":114475,"h":927713050411,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":940597952299,"f":33},"n":"PeachPuff","d":114475,"h":936302985003,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":949187886891,"f":33},"n":"Peru","d":114475,"h":944892919595,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":957777821483,"f":33},"n":"Pink","d":114475,"h":953482854187,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":966367756075,"f":33},"n":"Plum","d":114475,"h":962072788779,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":974957690667,"f":33},"n":"PowderBlue","d":114475,"h":970662723371,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":983547625259,"f":33},"n":"Purple","d":114475,"h":979252657963,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":992137559851,"f":33},"n":"RebeccaPurple","d":114475,"h":987842592555,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1000727494443,"f":33},"n":"Red","d":114475,"h":996432527147,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1009317429035,"f":33},"n":"RosyBrown","d":114475,"h":1005022461739,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1017907363627,"f":33},"n":"RoyalBlue","d":114475,"h":1013612396331,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1026497298219,"f":33},"n":"SaddleBrown","d":114475,"h":1022202330923,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1035087232811,"f":33},"n":"Salmon","d":114475,"h":1030792265515,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1043677167403,"f":33},"n":"SandyBrown","d":114475,"h":1039382200107,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1052267101995,"f":33},"n":"SeaGreen","d":114475,"h":1047972134699,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1060857036587,"f":33},"n":"SeaShell","d":114475,"h":1056562069291,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1069446971179,"f":33},"n":"Sienna","d":114475,"h":1065152003883,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1078036905771,"f":33},"n":"Silver","d":114475,"h":1073741938475,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1086626840363,"f":33},"n":"SkyBlue","d":114475,"h":1082331873067,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1095216774955,"f":33},"n":"SlateBlue","d":114475,"h":1090921807659,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1103806709547,"f":33},"n":"SlateGray","d":114475,"h":1099511742251,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1112396644139,"f":33},"n":"Snow","d":114475,"h":1108101676843,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1120986578731,"f":33},"n":"SpringGreen","d":114475,"h":1116691611435,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1129576513323,"f":33},"n":"SteelBlue","d":114475,"h":1125281546027,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1138166447915,"f":33},"n":"Tan","d":114475,"h":1133871480619,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1146756382507,"f":33},"n":"Teal","d":114475,"h":1142461415211,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1155346317099,"f":33},"n":"Thistle","d":114475,"h":1151051349803,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1163936251691,"f":33},"n":"Tomato","d":114475,"h":1159641284395,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1172526186283,"f":33},"n":"Turquoise","d":114475,"h":1168231218987,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1181116120875,"f":33},"n":"Violet","d":114475,"h":1176821153579,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1189706055467,"f":33},"n":"Wheat","d":114475,"h":1185411088171,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1198295990059,"f":33},"n":"White","d":114475,"h":1194001022763,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1206885924651,"f":33},"n":"WhiteSmoke","d":114475,"h":1202590957355,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1215475859243,"f":33},"n":"Yellow","d":114475,"h":1211180891947,"f":33},{"p":114475,"g":{"r":0,"d":0,"h":1224065793835,"f":33},"n":"YellowGreen","d":114475,"h":1219770826539,"f":33},{"p":393217,"g":{"r":0,"d":0,"h":1314260107051,"f":1},"n":"R","d":114475,"h":1309965139755,"f":1},{"p":393217,"g":{"r":0,"d":0,"h":1322850041643,"f":1},"n":"G","d":114475,"h":1318555074347,"f":1},{"p":393217,"g":{"r":0,"d":0,"h":1331439976235,"f":1},"n":"B","d":114475,"h":1327145008939,"f":1},{"p":393217,"g":{"r":0,"d":0,"h":1340029910827,"f":1},"n":"A","d":114475,"h":1335734943531,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1348619845419,"f":1},"n":"IsKnownColor","d":114475,"h":1344324878123,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1357209780011,"f":1},"n":"IsEmpty","d":114475,"h":1352914812715,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1365799714603,"f":1},"n":"IsNamedColor","d":114475,"h":1361504747307,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1374389649195,"f":1},"n":"IsSystemColor","d":114475,"h":1370094681899,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":1387274551083,"f":2},"n":"NameAndARGBValue","d":114475,"h":1382979583787,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":1395864485675,"f":1},"n":"Name","d":114475,"h":1391569518379,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":1404454420267,"f":2},"n":"Value","d":114475,"h":1400159452971,"f":2}],"m":[{"r":262145,"p":[{"n":"knownColor","p":376619}],"n":"IsKnownColorSystem","d":114475,"h":1378684616491,"f":40},{"r":65537,"p":[{"n":"value","p":655361},{"n":"name","p":1310721}],"n":"CheckByte","d":114475,"h":1408749387563,"f":34},{"r":114475,"p":[{"n":"argb","p":720897}],"n":"FromArgb","d":114475,"h":1413044354859,"f":34},{"r":114475,"p":[{"n":"argb","p":655361}],"n":"FromArgb","o":"@$1","d":114475,"h":1417339322155,"f":33},{"r":114475,"p":[{"n":"alpha","p":655361},{"n":"red","p":655361},{"n":"green","p":655361},{"n":"blue","p":655361}],"n":"FromArgb","o":"@$2","d":114475,"h":1421634289451,"f":33},{"r":114475,"p":[{"n":"alpha","p":655361},{"n":"baseColor","p":114475}],"n":"FromArgb","o":"@$3","d":114475,"h":1425929256747,"f":33},{"r":114475,"p":[{"n":"red","p":655361},{"n":"green","p":655361},{"n":"blue","p":655361}],"n":"FromArgb","o":"@$4","d":114475,"h":1430224224043,"f":33},{"r":114475,"p":[{"n":"color","p":376619}],"n":"FromKnownColor","d":114475,"h":1434519191339,"f":33},{"r":114475,"p":[{"n":"name","p":1310721}],"n":"FromName","d":114475,"h":1438814158635,"f":33},{"r":65537,"p":[{"n":"r","p":655361,"f":2},{"n":"g","p":655361,"f":2},{"n":"b","p":655361,"f":2}],"n":"GetRgbValues","d":114475,"h":1443109125931,"f":8},{"r":65537,"p":[{"n":"min","p":655361,"f":2},{"n":"max","p":655361,"f":2},{"n":"r","p":655361},{"n":"g","p":655361},{"n":"b","p":655361}],"n":"MinMaxRgb","d":114475,"h":1447404093227,"f":34},{"r":1114113,"n":"GetBrightness","d":114475,"h":1451699060523,"f":1},{"r":1114113,"n":"GetHue","d":114475,"h":1455994027819,"f":1},{"r":1114113,"n":"GetSaturation","d":114475,"h":1460288995115,"f":1},{"r":655361,"n":"ToArgb","d":114475,"h":1464583962411,"f":1},{"r":376619,"n":"ToKnownColor","d":114475,"h":1468878929707,"f":1},{"r":1310721,"n":"ToString","d":114475,"h":1473173897003,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":114475,"h":1486058798891,"f":32769},{"r":262145,"p":[{"n":"other","p":114475}],"n":"Equals","o":"@$2","d":114475,"h":1490353766187,"f":1},{"r":655361,"n":"GetHashCode","d":114475,"h":1494648733483,"f":32769}],"l":[{"t":114475,"n":"Empty","d":114475,"h":4295081771,"f":33},{"t":524289,"n":"StateKnownColorValid","d":114475,"h":1228360761131,"f":34},{"t":524289,"n":"StateARGBValueValid","d":114475,"h":1232655728427,"f":34},{"t":524289,"n":"StateValueMask","d":114475,"h":1236950695723,"f":34},{"t":524289,"n":"StateNameValid","d":114475,"h":1241245663019,"f":34},{"t":917505,"n":"NotDefinedValue","d":114475,"h":1245540630315,"f":34},{"t":655361,"n":"ARGBAlphaShift","d":114475,"h":1249835597611,"f":40},{"t":655361,"n":"ARGBRedShift","d":114475,"h":1254130564907,"f":40},{"t":655361,"n":"ARGBGreenShift","d":114475,"h":1258425532203,"f":40},{"t":655361,"n":"ARGBBlueShift","d":114475,"h":1262720499499,"f":40},{"t":720897,"n":"ARGBAlphaMask","d":114475,"h":1267015466795,"f":40},{"t":720897,"n":"ARGBRedMask","d":114475,"h":1271310434091,"f":40},{"t":720897,"n":"ARGBGreenMask","d":114475,"h":1275605401387,"f":40},{"t":720897,"n":"ARGBBlueMask","d":114475,"h":1279900368683,"f":40},{"t":1310721,"n":"name","d":114475,"h":1284195335979,"f":2},{"t":917505,"n":"value","d":114475,"h":1288490303275,"f":2},{"t":524289,"n":"knownColor","d":114475,"h":1292785270571,"f":2},{"t":524289,"n":"state","d":114475,"h":1297080237867,"f":2}],"c":[{"p":[{"n":"knownColor","p":376619}],"n":".ctor","o":"$ctor$2","d":114475,"h":1301375205163,"f":8},{"p":[{"n":"value","p":917505},{"n":"state","p":524289},{"n":"name","p":1310721},{"n":"knownColor","p":376619}],"n":".ctor","o":"$ctor$3","d":114475,"h":1305670172459,"f":2},{"n":".ctor","o":"$ctor$4","d":114475,"h":1498943700779,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Color).$h],"h":114475,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{NameAndARGBValue}","t":1310721}]},{"t":852007,"c":12885753895,"a":[{"v":"System.Drawing.Design.ColorEditor, System.Drawing.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":118226945,"c":4413194241},{"t":1505155,"c":17181374339,"a":[{"v":"System.Drawing.ColorConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Color) ]; }
            static get $fullName() { return `System.Drawing.Color`; }
        });
        
        $asm.$str("$sdp.System.Drawing.KnownColor", ($self) => class KnownColor extends $.$spc.System.Enum
        {
            static ActiveBorder = 1;
            static ActiveCaption = 2;
            static ActiveCaptionText = 3;
            static AppWorkspace = 4;
            static Control = 5;
            static ControlDark = 6;
            static ControlDarkDark = 7;
            static ControlLight = 8;
            static ControlLightLight = 9;
            static ControlText = 10;
            static Desktop = 11;
            static GrayText = 12;
            static Highlight = 13;
            static HighlightText = 14;
            static HotTrack = 15;
            static InactiveBorder = 16;
            static InactiveCaption = 17;
            static InactiveCaptionText = 18;
            static Info = 19;
            static InfoText = 20;
            static Menu = 21;
            static MenuText = 22;
            static ScrollBar = 23;
            static Window = 24;
            static WindowFrame = 25;
            static WindowText = 26;
            static Transparent = 27;
            static AliceBlue = 28;
            static AntiqueWhite = 29;
            static Aqua = 30;
            static Aquamarine = 31;
            static Azure = 32;
            static Beige = 33;
            static Bisque = 34;
            static Black = 35;
            static BlanchedAlmond = 36;
            static Blue = 37;
            static BlueViolet = 38;
            static Brown = 39;
            static BurlyWood = 40;
            static CadetBlue = 41;
            static Chartreuse = 42;
            static Chocolate = 43;
            static Coral = 44;
            static CornflowerBlue = 45;
            static Cornsilk = 46;
            static Crimson = 47;
            static Cyan = 48;
            static DarkBlue = 49;
            static DarkCyan = 50;
            static DarkGoldenrod = 51;
            static DarkGray = 52;
            static DarkGreen = 53;
            static DarkKhaki = 54;
            static DarkMagenta = 55;
            static DarkOliveGreen = 56;
            static DarkOrange = 57;
            static DarkOrchid = 58;
            static DarkRed = 59;
            static DarkSalmon = 60;
            static DarkSeaGreen = 61;
            static DarkSlateBlue = 62;
            static DarkSlateGray = 63;
            static DarkTurquoise = 64;
            static DarkViolet = 65;
            static DeepPink = 66;
            static DeepSkyBlue = 67;
            static DimGray = 68;
            static DodgerBlue = 69;
            static Firebrick = 70;
            static FloralWhite = 71;
            static ForestGreen = 72;
            static Fuchsia = 73;
            static Gainsboro = 74;
            static GhostWhite = 75;
            static Gold = 76;
            static Goldenrod = 77;
            static Gray = 78;
            static Green = 79;
            static GreenYellow = 80;
            static Honeydew = 81;
            static HotPink = 82;
            static IndianRed = 83;
            static Indigo = 84;
            static Ivory = 85;
            static Khaki = 86;
            static Lavender = 87;
            static LavenderBlush = 88;
            static LawnGreen = 89;
            static LemonChiffon = 90;
            static LightBlue = 91;
            static LightCoral = 92;
            static LightCyan = 93;
            static LightGoldenrodYellow = 94;
            static LightGray = 95;
            static LightGreen = 96;
            static LightPink = 97;
            static LightSalmon = 98;
            static LightSeaGreen = 99;
            static LightSkyBlue = 100;
            static LightSlateGray = 101;
            static LightSteelBlue = 102;
            static LightYellow = 103;
            static Lime = 104;
            static LimeGreen = 105;
            static Linen = 106;
            static Magenta = 107;
            static Maroon = 108;
            static MediumAquamarine = 109;
            static MediumBlue = 110;
            static MediumOrchid = 111;
            static MediumPurple = 112;
            static MediumSeaGreen = 113;
            static MediumSlateBlue = 114;
            static MediumSpringGreen = 115;
            static MediumTurquoise = 116;
            static MediumVioletRed = 117;
            static MidnightBlue = 118;
            static MintCream = 119;
            static MistyRose = 120;
            static Moccasin = 121;
            static NavajoWhite = 122;
            static Navy = 123;
            static OldLace = 124;
            static Olive = 125;
            static OliveDrab = 126;
            static Orange = 127;
            static OrangeRed = 128;
            static Orchid = 129;
            static PaleGoldenrod = 130;
            static PaleGreen = 131;
            static PaleTurquoise = 132;
            static PaleVioletRed = 133;
            static PapayaWhip = 134;
            static PeachPuff = 135;
            static Peru = 136;
            static Pink = 137;
            static Plum = 138;
            static PowderBlue = 139;
            static Purple = 140;
            static Red = 141;
            static RosyBrown = 142;
            static RoyalBlue = 143;
            static SaddleBrown = 144;
            static Salmon = 145;
            static SandyBrown = 146;
            static SeaGreen = 147;
            static SeaShell = 148;
            static Sienna = 149;
            static Silver = 150;
            static SkyBlue = 151;
            static SlateBlue = 152;
            static SlateGray = 153;
            static Snow = 154;
            static SpringGreen = 155;
            static SteelBlue = 156;
            static Tan = 157;
            static Teal = 158;
            static Thistle = 159;
            static Tomato = 160;
            static Turquoise = 161;
            static Violet = 162;
            static Wheat = 163;
            static White = 164;
            static WhiteSmoke = 165;
            static Yellow = 166;
            static YellowGreen = 167;
            static ButtonFace = 168;
            static ButtonHighlight = 169;
            static ButtonShadow = 170;
            static GradientActiveCaption = 171;
            static GradientInactiveCaption = 172;
            static MenuBar = 173;
            static MenuHighlight = 174;
            static RebeccaPurple = 175;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ActiveBorder": 1n,
                    "ActiveCaption": 2n,
                    "ActiveCaptionText": 3n,
                    "AppWorkspace": 4n,
                    "Control": 5n,
                    "ControlDark": 6n,
                    "ControlDarkDark": 7n,
                    "ControlLight": 8n,
                    "ControlLightLight": 9n,
                    "ControlText": 10n,
                    "Desktop": 11n,
                    "GrayText": 12n,
                    "Highlight": 13n,
                    "HighlightText": 14n,
                    "HotTrack": 15n,
                    "InactiveBorder": 16n,
                    "InactiveCaption": 17n,
                    "InactiveCaptionText": 18n,
                    "Info": 19n,
                    "InfoText": 20n,
                    "Menu": 21n,
                    "MenuText": 22n,
                    "ScrollBar": 23n,
                    "Window": 24n,
                    "WindowFrame": 25n,
                    "WindowText": 26n,
                    "Transparent": 27n,
                    "AliceBlue": 28n,
                    "AntiqueWhite": 29n,
                    "Aqua": 30n,
                    "Aquamarine": 31n,
                    "Azure": 32n,
                    "Beige": 33n,
                    "Bisque": 34n,
                    "Black": 35n,
                    "BlanchedAlmond": 36n,
                    "Blue": 37n,
                    "BlueViolet": 38n,
                    "Brown": 39n,
                    "BurlyWood": 40n,
                    "CadetBlue": 41n,
                    "Chartreuse": 42n,
                    "Chocolate": 43n,
                    "Coral": 44n,
                    "CornflowerBlue": 45n,
                    "Cornsilk": 46n,
                    "Crimson": 47n,
                    "Cyan": 48n,
                    "DarkBlue": 49n,
                    "DarkCyan": 50n,
                    "DarkGoldenrod": 51n,
                    "DarkGray": 52n,
                    "DarkGreen": 53n,
                    "DarkKhaki": 54n,
                    "DarkMagenta": 55n,
                    "DarkOliveGreen": 56n,
                    "DarkOrange": 57n,
                    "DarkOrchid": 58n,
                    "DarkRed": 59n,
                    "DarkSalmon": 60n,
                    "DarkSeaGreen": 61n,
                    "DarkSlateBlue": 62n,
                    "DarkSlateGray": 63n,
                    "DarkTurquoise": 64n,
                    "DarkViolet": 65n,
                    "DeepPink": 66n,
                    "DeepSkyBlue": 67n,
                    "DimGray": 68n,
                    "DodgerBlue": 69n,
                    "Firebrick": 70n,
                    "FloralWhite": 71n,
                    "ForestGreen": 72n,
                    "Fuchsia": 73n,
                    "Gainsboro": 74n,
                    "GhostWhite": 75n,
                    "Gold": 76n,
                    "Goldenrod": 77n,
                    "Gray": 78n,
                    "Green": 79n,
                    "GreenYellow": 80n,
                    "Honeydew": 81n,
                    "HotPink": 82n,
                    "IndianRed": 83n,
                    "Indigo": 84n,
                    "Ivory": 85n,
                    "Khaki": 86n,
                    "Lavender": 87n,
                    "LavenderBlush": 88n,
                    "LawnGreen": 89n,
                    "LemonChiffon": 90n,
                    "LightBlue": 91n,
                    "LightCoral": 92n,
                    "LightCyan": 93n,
                    "LightGoldenrodYellow": 94n,
                    "LightGray": 95n,
                    "LightGreen": 96n,
                    "LightPink": 97n,
                    "LightSalmon": 98n,
                    "LightSeaGreen": 99n,
                    "LightSkyBlue": 100n,
                    "LightSlateGray": 101n,
                    "LightSteelBlue": 102n,
                    "LightYellow": 103n,
                    "Lime": 104n,
                    "LimeGreen": 105n,
                    "Linen": 106n,
                    "Magenta": 107n,
                    "Maroon": 108n,
                    "MediumAquamarine": 109n,
                    "MediumBlue": 110n,
                    "MediumOrchid": 111n,
                    "MediumPurple": 112n,
                    "MediumSeaGreen": 113n,
                    "MediumSlateBlue": 114n,
                    "MediumSpringGreen": 115n,
                    "MediumTurquoise": 116n,
                    "MediumVioletRed": 117n,
                    "MidnightBlue": 118n,
                    "MintCream": 119n,
                    "MistyRose": 120n,
                    "Moccasin": 121n,
                    "NavajoWhite": 122n,
                    "Navy": 123n,
                    "OldLace": 124n,
                    "Olive": 125n,
                    "OliveDrab": 126n,
                    "Orange": 127n,
                    "OrangeRed": 128n,
                    "Orchid": 129n,
                    "PaleGoldenrod": 130n,
                    "PaleGreen": 131n,
                    "PaleTurquoise": 132n,
                    "PaleVioletRed": 133n,
                    "PapayaWhip": 134n,
                    "PeachPuff": 135n,
                    "Peru": 136n,
                    "Pink": 137n,
                    "Plum": 138n,
                    "PowderBlue": 139n,
                    "Purple": 140n,
                    "Red": 141n,
                    "RosyBrown": 142n,
                    "RoyalBlue": 143n,
                    "SaddleBrown": 144n,
                    "Salmon": 145n,
                    "SandyBrown": 146n,
                    "SeaGreen": 147n,
                    "SeaShell": 148n,
                    "Sienna": 149n,
                    "Silver": 150n,
                    "SkyBlue": 151n,
                    "SlateBlue": 152n,
                    "SlateGray": 153n,
                    "Snow": 154n,
                    "SpringGreen": 155n,
                    "SteelBlue": 156n,
                    "Tan": 157n,
                    "Teal": 158n,
                    "Thistle": 159n,
                    "Tomato": 160n,
                    "Turquoise": 161n,
                    "Violet": 162n,
                    "Wheat": 163n,
                    "White": 164n,
                    "WhiteSmoke": 165n,
                    "Yellow": 166n,
                    "YellowGreen": 167n,
                    "ButtonFace": 168n,
                    "ButtonHighlight": 169n,
                    "ButtonShadow": 170n,
                    "GradientActiveCaption": 171n,
                    "GradientInactiveCaption": 172n,
                    "MenuBar": 173n,
                    "MenuHighlight": 174n,
                    "RebeccaPurple": 175n
                };
            }
            static $h = 376619;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":376619,"n":"ActiveBorder","d":376619,"h":4295343915,"f":33},{"t":376619,"n":"ActiveCaption","d":376619,"h":8590311211,"f":33},{"t":376619,"n":"ActiveCaptionText","d":376619,"h":12885278507,"f":33},{"t":376619,"n":"AppWorkspace","d":376619,"h":17180245803,"f":33},{"t":376619,"n":"Control","d":376619,"h":21475213099,"f":33},{"t":376619,"n":"ControlDark","d":376619,"h":25770180395,"f":33},{"t":376619,"n":"ControlDarkDark","d":376619,"h":30065147691,"f":33},{"t":376619,"n":"ControlLight","d":376619,"h":34360114987,"f":33},{"t":376619,"n":"ControlLightLight","d":376619,"h":38655082283,"f":33},{"t":376619,"n":"ControlText","d":376619,"h":42950049579,"f":33},{"t":376619,"n":"Desktop","d":376619,"h":47245016875,"f":33},{"t":376619,"n":"GrayText","d":376619,"h":51539984171,"f":33},{"t":376619,"n":"Highlight","d":376619,"h":55834951467,"f":33},{"t":376619,"n":"HighlightText","d":376619,"h":60129918763,"f":33},{"t":376619,"n":"HotTrack","d":376619,"h":64424886059,"f":33},{"t":376619,"n":"InactiveBorder","d":376619,"h":68719853355,"f":33},{"t":376619,"n":"InactiveCaption","d":376619,"h":73014820651,"f":33},{"t":376619,"n":"InactiveCaptionText","d":376619,"h":77309787947,"f":33},{"t":376619,"n":"Info","d":376619,"h":81604755243,"f":33},{"t":376619,"n":"InfoText","d":376619,"h":85899722539,"f":33},{"t":376619,"n":"Menu","d":376619,"h":90194689835,"f":33},{"t":376619,"n":"MenuText","d":376619,"h":94489657131,"f":33},{"t":376619,"n":"ScrollBar","d":376619,"h":98784624427,"f":33},{"t":376619,"n":"Window","d":376619,"h":103079591723,"f":33},{"t":376619,"n":"WindowFrame","d":376619,"h":107374559019,"f":33},{"t":376619,"n":"WindowText","d":376619,"h":111669526315,"f":33},{"t":376619,"n":"Transparent","d":376619,"h":115964493611,"f":33},{"t":376619,"n":"AliceBlue","d":376619,"h":120259460907,"f":33},{"t":376619,"n":"AntiqueWhite","d":376619,"h":124554428203,"f":33},{"t":376619,"n":"Aqua","d":376619,"h":128849395499,"f":33},{"t":376619,"n":"Aquamarine","d":376619,"h":133144362795,"f":33},{"t":376619,"n":"Azure","d":376619,"h":137439330091,"f":33},{"t":376619,"n":"Beige","d":376619,"h":141734297387,"f":33},{"t":376619,"n":"Bisque","d":376619,"h":146029264683,"f":33},{"t":376619,"n":"Black","d":376619,"h":150324231979,"f":33},{"t":376619,"n":"BlanchedAlmond","d":376619,"h":154619199275,"f":33},{"t":376619,"n":"Blue","d":376619,"h":158914166571,"f":33},{"t":376619,"n":"BlueViolet","d":376619,"h":163209133867,"f":33},{"t":376619,"n":"Brown","d":376619,"h":167504101163,"f":33},{"t":376619,"n":"BurlyWood","d":376619,"h":171799068459,"f":33},{"t":376619,"n":"CadetBlue","d":376619,"h":176094035755,"f":33},{"t":376619,"n":"Chartreuse","d":376619,"h":180389003051,"f":33},{"t":376619,"n":"Chocolate","d":376619,"h":184683970347,"f":33},{"t":376619,"n":"Coral","d":376619,"h":188978937643,"f":33},{"t":376619,"n":"CornflowerBlue","d":376619,"h":193273904939,"f":33},{"t":376619,"n":"Cornsilk","d":376619,"h":197568872235,"f":33},{"t":376619,"n":"Crimson","d":376619,"h":201863839531,"f":33},{"t":376619,"n":"Cyan","d":376619,"h":206158806827,"f":33},{"t":376619,"n":"DarkBlue","d":376619,"h":210453774123,"f":33},{"t":376619,"n":"DarkCyan","d":376619,"h":214748741419,"f":33},{"t":376619,"n":"DarkGoldenrod","d":376619,"h":219043708715,"f":33},{"t":376619,"n":"DarkGray","d":376619,"h":223338676011,"f":33},{"t":376619,"n":"DarkGreen","d":376619,"h":227633643307,"f":33},{"t":376619,"n":"DarkKhaki","d":376619,"h":231928610603,"f":33},{"t":376619,"n":"DarkMagenta","d":376619,"h":236223577899,"f":33},{"t":376619,"n":"DarkOliveGreen","d":376619,"h":240518545195,"f":33},{"t":376619,"n":"DarkOrange","d":376619,"h":244813512491,"f":33},{"t":376619,"n":"DarkOrchid","d":376619,"h":249108479787,"f":33},{"t":376619,"n":"DarkRed","d":376619,"h":253403447083,"f":33},{"t":376619,"n":"DarkSalmon","d":376619,"h":257698414379,"f":33},{"t":376619,"n":"DarkSeaGreen","d":376619,"h":261993381675,"f":33},{"t":376619,"n":"DarkSlateBlue","d":376619,"h":266288348971,"f":33},{"t":376619,"n":"DarkSlateGray","d":376619,"h":270583316267,"f":33},{"t":376619,"n":"DarkTurquoise","d":376619,"h":274878283563,"f":33},{"t":376619,"n":"DarkViolet","d":376619,"h":279173250859,"f":33},{"t":376619,"n":"DeepPink","d":376619,"h":283468218155,"f":33},{"t":376619,"n":"DeepSkyBlue","d":376619,"h":287763185451,"f":33},{"t":376619,"n":"DimGray","d":376619,"h":292058152747,"f":33},{"t":376619,"n":"DodgerBlue","d":376619,"h":296353120043,"f":33},{"t":376619,"n":"Firebrick","d":376619,"h":300648087339,"f":33},{"t":376619,"n":"FloralWhite","d":376619,"h":304943054635,"f":33},{"t":376619,"n":"ForestGreen","d":376619,"h":309238021931,"f":33},{"t":376619,"n":"Fuchsia","d":376619,"h":313532989227,"f":33},{"t":376619,"n":"Gainsboro","d":376619,"h":317827956523,"f":33},{"t":376619,"n":"GhostWhite","d":376619,"h":322122923819,"f":33},{"t":376619,"n":"Gold","d":376619,"h":326417891115,"f":33},{"t":376619,"n":"Goldenrod","d":376619,"h":330712858411,"f":33},{"t":376619,"n":"Gray","d":376619,"h":335007825707,"f":33},{"t":376619,"n":"Green","d":376619,"h":339302793003,"f":33},{"t":376619,"n":"GreenYellow","d":376619,"h":343597760299,"f":33},{"t":376619,"n":"Honeydew","d":376619,"h":347892727595,"f":33},{"t":376619,"n":"HotPink","d":376619,"h":352187694891,"f":33},{"t":376619,"n":"IndianRed","d":376619,"h":356482662187,"f":33},{"t":376619,"n":"Indigo","d":376619,"h":360777629483,"f":33},{"t":376619,"n":"Ivory","d":376619,"h":365072596779,"f":33},{"t":376619,"n":"Khaki","d":376619,"h":369367564075,"f":33},{"t":376619,"n":"Lavender","d":376619,"h":373662531371,"f":33},{"t":376619,"n":"LavenderBlush","d":376619,"h":377957498667,"f":33},{"t":376619,"n":"LawnGreen","d":376619,"h":382252465963,"f":33},{"t":376619,"n":"LemonChiffon","d":376619,"h":386547433259,"f":33},{"t":376619,"n":"LightBlue","d":376619,"h":390842400555,"f":33},{"t":376619,"n":"LightCoral","d":376619,"h":395137367851,"f":33},{"t":376619,"n":"LightCyan","d":376619,"h":399432335147,"f":33},{"t":376619,"n":"LightGoldenrodYellow","d":376619,"h":403727302443,"f":33},{"t":376619,"n":"LightGray","d":376619,"h":408022269739,"f":33},{"t":376619,"n":"LightGreen","d":376619,"h":412317237035,"f":33},{"t":376619,"n":"LightPink","d":376619,"h":416612204331,"f":33},{"t":376619,"n":"LightSalmon","d":376619,"h":420907171627,"f":33},{"t":376619,"n":"LightSeaGreen","d":376619,"h":425202138923,"f":33},{"t":376619,"n":"LightSkyBlue","d":376619,"h":429497106219,"f":33},{"t":376619,"n":"LightSlateGray","d":376619,"h":433792073515,"f":33},{"t":376619,"n":"LightSteelBlue","d":376619,"h":438087040811,"f":33},{"t":376619,"n":"LightYellow","d":376619,"h":442382008107,"f":33},{"t":376619,"n":"Lime","d":376619,"h":446676975403,"f":33},{"t":376619,"n":"LimeGreen","d":376619,"h":450971942699,"f":33},{"t":376619,"n":"Linen","d":376619,"h":455266909995,"f":33},{"t":376619,"n":"Magenta","d":376619,"h":459561877291,"f":33},{"t":376619,"n":"Maroon","d":376619,"h":463856844587,"f":33},{"t":376619,"n":"MediumAquamarine","d":376619,"h":468151811883,"f":33},{"t":376619,"n":"MediumBlue","d":376619,"h":472446779179,"f":33},{"t":376619,"n":"MediumOrchid","d":376619,"h":476741746475,"f":33},{"t":376619,"n":"MediumPurple","d":376619,"h":481036713771,"f":33},{"t":376619,"n":"MediumSeaGreen","d":376619,"h":485331681067,"f":33},{"t":376619,"n":"MediumSlateBlue","d":376619,"h":489626648363,"f":33},{"t":376619,"n":"MediumSpringGreen","d":376619,"h":493921615659,"f":33},{"t":376619,"n":"MediumTurquoise","d":376619,"h":498216582955,"f":33},{"t":376619,"n":"MediumVioletRed","d":376619,"h":502511550251,"f":33},{"t":376619,"n":"MidnightBlue","d":376619,"h":506806517547,"f":33},{"t":376619,"n":"MintCream","d":376619,"h":511101484843,"f":33},{"t":376619,"n":"MistyRose","d":376619,"h":515396452139,"f":33},{"t":376619,"n":"Moccasin","d":376619,"h":519691419435,"f":33},{"t":376619,"n":"NavajoWhite","d":376619,"h":523986386731,"f":33},{"t":376619,"n":"Navy","d":376619,"h":528281354027,"f":33},{"t":376619,"n":"OldLace","d":376619,"h":532576321323,"f":33},{"t":376619,"n":"Olive","d":376619,"h":536871288619,"f":33},{"t":376619,"n":"OliveDrab","d":376619,"h":541166255915,"f":33},{"t":376619,"n":"Orange","d":376619,"h":545461223211,"f":33},{"t":376619,"n":"OrangeRed","d":376619,"h":549756190507,"f":33},{"t":376619,"n":"Orchid","d":376619,"h":554051157803,"f":33},{"t":376619,"n":"PaleGoldenrod","d":376619,"h":558346125099,"f":33},{"t":376619,"n":"PaleGreen","d":376619,"h":562641092395,"f":33},{"t":376619,"n":"PaleTurquoise","d":376619,"h":566936059691,"f":33},{"t":376619,"n":"PaleVioletRed","d":376619,"h":571231026987,"f":33},{"t":376619,"n":"PapayaWhip","d":376619,"h":575525994283,"f":33},{"t":376619,"n":"PeachPuff","d":376619,"h":579820961579,"f":33},{"t":376619,"n":"Peru","d":376619,"h":584115928875,"f":33},{"t":376619,"n":"Pink","d":376619,"h":588410896171,"f":33},{"t":376619,"n":"Plum","d":376619,"h":592705863467,"f":33},{"t":376619,"n":"PowderBlue","d":376619,"h":597000830763,"f":33},{"t":376619,"n":"Purple","d":376619,"h":601295798059,"f":33},{"t":376619,"n":"Red","d":376619,"h":605590765355,"f":33},{"t":376619,"n":"RosyBrown","d":376619,"h":609885732651,"f":33},{"t":376619,"n":"RoyalBlue","d":376619,"h":614180699947,"f":33},{"t":376619,"n":"SaddleBrown","d":376619,"h":618475667243,"f":33},{"t":376619,"n":"Salmon","d":376619,"h":622770634539,"f":33},{"t":376619,"n":"SandyBrown","d":376619,"h":627065601835,"f":33},{"t":376619,"n":"SeaGreen","d":376619,"h":631360569131,"f":33},{"t":376619,"n":"SeaShell","d":376619,"h":635655536427,"f":33},{"t":376619,"n":"Sienna","d":376619,"h":639950503723,"f":33},{"t":376619,"n":"Silver","d":376619,"h":644245471019,"f":33},{"t":376619,"n":"SkyBlue","d":376619,"h":648540438315,"f":33},{"t":376619,"n":"SlateBlue","d":376619,"h":652835405611,"f":33},{"t":376619,"n":"SlateGray","d":376619,"h":657130372907,"f":33},{"t":376619,"n":"Snow","d":376619,"h":661425340203,"f":33},{"t":376619,"n":"SpringGreen","d":376619,"h":665720307499,"f":33},{"t":376619,"n":"SteelBlue","d":376619,"h":670015274795,"f":33},{"t":376619,"n":"Tan","d":376619,"h":674310242091,"f":33},{"t":376619,"n":"Teal","d":376619,"h":678605209387,"f":33},{"t":376619,"n":"Thistle","d":376619,"h":682900176683,"f":33},{"t":376619,"n":"Tomato","d":376619,"h":687195143979,"f":33},{"t":376619,"n":"Turquoise","d":376619,"h":691490111275,"f":33},{"t":376619,"n":"Violet","d":376619,"h":695785078571,"f":33},{"t":376619,"n":"Wheat","d":376619,"h":700080045867,"f":33},{"t":376619,"n":"White","d":376619,"h":704375013163,"f":33},{"t":376619,"n":"WhiteSmoke","d":376619,"h":708669980459,"f":33},{"t":376619,"n":"Yellow","d":376619,"h":712964947755,"f":33},{"t":376619,"n":"YellowGreen","d":376619,"h":717259915051,"f":33},{"t":376619,"n":"ButtonFace","d":376619,"h":721554882347,"f":33},{"t":376619,"n":"ButtonHighlight","d":376619,"h":725849849643,"f":33},{"t":376619,"n":"ButtonShadow","d":376619,"h":730144816939,"f":33},{"t":376619,"n":"GradientActiveCaption","d":376619,"h":734439784235,"f":33},{"t":376619,"n":"GradientInactiveCaption","d":376619,"h":738734751531,"f":33},{"t":376619,"n":"MenuBar","d":376619,"h":743029718827,"f":33},{"t":376619,"n":"MenuHighlight","d":376619,"h":747324686123,"f":33},{"t":376619,"n":"RebeccaPurple","d":376619,"h":751619653419,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":376619,"h":755914620715,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":376619,"a":[{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Drawing.KnownColor`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.InteropServices"))