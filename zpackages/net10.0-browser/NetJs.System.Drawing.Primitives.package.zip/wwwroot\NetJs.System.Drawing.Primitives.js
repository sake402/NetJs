
(function ($global, $, $spc, $sc, $sdt, $sm, $snv, $spu, $st, $sr, $scc, $scn, $scm, $so, $sris, $scp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Drawing.Primitives", 
    {"h":63442,"f":"System.Drawing.Primitives","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Drawing.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Drawing.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdp.System.Drawing.KnownColorNames", ($self) => class KnownColorNames
        {
            /*string[]*/ static s_colorNameTable = null;
            static /*string */ KnownColorToName(/*KnownColor*/ color)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(color > 0 && color <= 175/*KnownColor.RebeccaPurple*/, "color > 0 && color <= KnownColor.RebeccaPurple");
                return $.$spc.System.Array.$ReadT1.call($.$sdp.System.Drawing.KnownColorNames.s_colorNameTable, ((color - 1) | 0));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_colorNameTable = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), ["ActiveBorder", "ActiveCaption", "ActiveCaptionText", "AppWorkspace", "Control", "ControlDark", "ControlDarkDark", "ControlLight", "ControlLightLight", "ControlText", "Desktop", "GrayText", "Highlight", "HighlightText", "HotTrack", "InactiveBorder", "InactiveCaption", "InactiveCaptionText", "Info", "InfoText", "Menu", "MenuText", "ScrollBar", "Window", "WindowFrame", "WindowText", "Transparent", "AliceBlue", "AntiqueWhite", "Aqua", "Aquamarine", "Azure", "Beige", "Bisque", "Black", "BlanchedAlmond", "Blue", "BlueViolet", "Brown", "BurlyWood", "CadetBlue", "Chartreuse", "Chocolate", "Coral", "CornflowerBlue", "Cornsilk", "Crimson", "Cyan", "DarkBlue", "DarkCyan", "DarkGoldenrod", "DarkGray", "DarkGreen", "DarkKhaki", "DarkMagenta", "DarkOliveGreen", "DarkOrange", "DarkOrchid", "DarkRed", "DarkSalmon", "DarkSeaGreen", "DarkSlateBlue", "DarkSlateGray", "DarkTurquoise", "DarkViolet", "DeepPink", "DeepSkyBlue", "DimGray", "DodgerBlue", "Firebrick", "FloralWhite", "ForestGreen", "Fuchsia", "Gainsboro", "GhostWhite", "Gold", "Goldenrod", "Gray", "Green", "GreenYellow", "Honeydew", "HotPink", "IndianRed", "Indigo", "Ivory", "Khaki", "Lavender", "LavenderBlush", "LawnGreen", "LemonChiffon", "LightBlue", "LightCoral", "LightCyan", "LightGoldenrodYellow", "LightGray", "LightGreen", "LightPink", "LightSalmon", "LightSeaGreen", "LightSkyBlue", "LightSlateGray", "LightSteelBlue", "LightYellow", "Lime", "LimeGreen", "Linen", "Magenta", "Maroon", "MediumAquamarine", "MediumBlue", "MediumOrchid", "MediumPurple", "MediumSeaGreen", "MediumSlateBlue", "MediumSpringGreen", "MediumTurquoise", "MediumVioletRed", "MidnightBlue", "MintCream", "MistyRose", "Moccasin", "NavajoWhite", "Navy", "OldLace", "Olive", "OliveDrab", "Orange", "OrangeRed", "Orchid", "PaleGoldenrod", "PaleGreen", "PaleTurquoise", "PaleVioletRed", "PapayaWhip", "PeachPuff", "Peru", "Pink", "Plum", "PowderBlue", "Purple", "Red", "RosyBrown", "RoyalBlue", "SaddleBrown", "Salmon", "SandyBrown", "SeaGreen", "SeaShell", "Sienna", "Silver", "SkyBlue", "SlateBlue", "SlateGray", "Snow", "SpringGreen", "SteelBlue", "Tan", "Teal", "Thistle", "Tomato", "Turquoise", "Violet", "Wheat", "White", "WhiteSmoke", "Yellow", "YellowGreen", "ButtonFace", "ButtonHighlight", "ButtonShadow", "GradientActiveCaption", "GradientInactiveCaption", "MenuBar", "MenuHighlight", "RebeccaPurple"], [-1], null);
                }
            }
            static $h = 456658;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"color","p":391122}],"n":"KnownColorToName","d":456658,"h":8590391250,"f":33}],"l":[{"t":0,"n":"s_colorNameTable","d":456658,"h":4295423954,"f":34}],"h":456658}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.KnownColorNames`; }
        });
        
        $asm.$cls("$sdp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sdp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Drawing.Primitives", $.$sdp.System.SR.$type.Assembly);
                    $.$sdp.System.SR.s_resourceManager = temp;
                }
                return $.$sdp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sdp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sdp.System.SR.resourceCulture = value;
            }
            static /*string */ get ConvertInvalidPrimitive()
            {
                return "{0} is not a valid value for {1}.";
            }
            static /*string */ FormatConvertInvalidPrimitive(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("{0} is not a valid value for {1}.", arg1, arg2);
            }
            static /*string */ get InvalidColor()
            {
                return "Color '{0}' is not valid.";
            }
            static /*string */ FormatInvalidColor(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Color '{0}' is not valid.", arg1);
            }
            static /*string */ get InvalidEx2BoundArgument()
            {
                return "Value of '{1}' is not valid for '{0}'. '{0}' should be greater than or equal to {2} and less than or equal to {3}.";
            }
            static /*string */ FormatInvalidEx2BoundArgument(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4, /*object*/ arg5)
            {
                return $.$spc.System.String.Format$4("Value of '{1}' is not valid for '{0}'. '{0}' should be greater than or equal to {2} and less than or equal to {3}.", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg1, arg2, arg3, arg4, arg5 ]));
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sdp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sdp.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sdp.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sdp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1112018;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1112018}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorTranslator", ($self) => class ColorTranslator
        {
            /*int*/ static COLORREF_RedShift = 0;
            /*int*/ static COLORREF_GreenShift = 8;
            /*int*/ static COLORREF_BlueShift = 16;
            /*int*/ static OleSystemColorFlag = -2147483648;
            /*Dictionary<string, Color>?*/ static s_htmlSysColorTable = null;
            static /*uint */ COLORREFToARGB(/*uint*/ value)
            {
                return (((value >>> 0/*COLORREF_RedShift*/) & 255) << 16/*Color.ARGBRedShift*/) >>> 0 | (((value >>> 8/*COLORREF_GreenShift*/) & 255) << 8/*Color.ARGBGreenShift*/) >>> 0 | (((value >>> 16/*COLORREF_BlueShift*/) & 255) << 0/*Color.ARGBBlueShift*/) >>> 0 | 4278190080/*Color.ARGBAlphaMask*/;
            }
            static /*int */ ToWin32(/*Color*/ c)
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                c.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                return r << 0/*COLORREF_RedShift*/ | g << 8/*COLORREF_GreenShift*/ | b << 16/*COLORREF_BlueShift*/;
            }
            static /*int */ ToOle(/*Color*/ c)
            {
                if (c.IsKnownColor && c.IsSystemColor)
                {
                    let $switch1 = c.ToKnownColor();
                    switch($switch1)
                    {
                        case 1/*KnownColor.ActiveBorder*/:
                        return (2147483658 | 0);
                        case 2/*KnownColor.ActiveCaption*/:
                        return (2147483650 | 0);
                        case 3/*KnownColor.ActiveCaptionText*/:
                        return (2147483657 | 0);
                        case 4/*KnownColor.AppWorkspace*/:
                        return (2147483660 | 0);
                        case 168/*KnownColor.ButtonFace*/:
                        return (2147483663 | 0);
                        case 169/*KnownColor.ButtonHighlight*/:
                        return (2147483668 | 0);
                        case 170/*KnownColor.ButtonShadow*/:
                        return (2147483664 | 0);
                        case 5/*KnownColor.Control*/:
                        return (2147483663 | 0);
                        case 6/*KnownColor.ControlDark*/:
                        return (2147483664 | 0);
                        case 7/*KnownColor.ControlDarkDark*/:
                        return (2147483669 | 0);
                        case 8/*KnownColor.ControlLight*/:
                        return (2147483670 | 0);
                        case 9/*KnownColor.ControlLightLight*/:
                        return (2147483668 | 0);
                        case 10/*KnownColor.ControlText*/:
                        return (2147483666 | 0);
                        case 11/*KnownColor.Desktop*/:
                        return (2147483649 | 0);
                        case 171/*KnownColor.GradientActiveCaption*/:
                        return (2147483675 | 0);
                        case 172/*KnownColor.GradientInactiveCaption*/:
                        return (2147483676 | 0);
                        case 12/*KnownColor.GrayText*/:
                        return (2147483665 | 0);
                        case 13/*KnownColor.Highlight*/:
                        return (2147483661 | 0);
                        case 14/*KnownColor.HighlightText*/:
                        return (2147483662 | 0);
                        case 15/*KnownColor.HotTrack*/:
                        return (2147483674 | 0);
                        case 16/*KnownColor.InactiveBorder*/:
                        return (2147483659 | 0);
                        case 17/*KnownColor.InactiveCaption*/:
                        return (2147483651 | 0);
                        case 18/*KnownColor.InactiveCaptionText*/:
                        return (2147483667 | 0);
                        case 19/*KnownColor.Info*/:
                        return (2147483672 | 0);
                        case 20/*KnownColor.InfoText*/:
                        return (2147483671 | 0);
                        case 21/*KnownColor.Menu*/:
                        return (2147483652 | 0);
                        case 173/*KnownColor.MenuBar*/:
                        return (2147483678 | 0);
                        case 174/*KnownColor.MenuHighlight*/:
                        return (2147483677 | 0);
                        case 22/*KnownColor.MenuText*/:
                        return (2147483655 | 0);
                        case 23/*KnownColor.ScrollBar*/:
                        return (2147483648 | 0);
                        case 24/*KnownColor.Window*/:
                        return (2147483653 | 0);
                        case 25/*KnownColor.WindowFrame*/:
                        return (2147483654 | 0);
                        case 26/*KnownColor.WindowText*/:
                        return (2147483656 | 0);
                    }
                }
                return $.$sdp.System.Drawing.ColorTranslator.ToWin32(c);
            }
            static /*Color */ FromOle(/*int*/ oleColor)
            {
                if ((oleColor & -2147483648/*OleSystemColorFlag*/) !== 0)
                {
                    switch(oleColor)
                    {
                        case (2147483658 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/);
                        case (2147483650 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/);
                        case (2147483657 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/);
                        case (2147483660 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/);
                        case (2147483663 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/);
                        case (2147483664 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/);
                        case (2147483669 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/);
                        case (2147483670 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/);
                        case (2147483668 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/);
                        case (2147483666 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/);
                        case (2147483649 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/);
                        case (2147483675 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(171/*KnownColor.GradientActiveCaption*/);
                        case (2147483676 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(172/*KnownColor.GradientInactiveCaption*/);
                        case (2147483665 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/);
                        case (2147483661 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/);
                        case (2147483662 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/);
                        case (2147483674 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(15/*KnownColor.HotTrack*/);
                        case (2147483659 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/);
                        case (2147483651 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/);
                        case (2147483667 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/);
                        case (2147483672 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/);
                        case (2147483671 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/);
                        case (2147483652 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/);
                        case (2147483678 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(173/*KnownColor.MenuBar*/);
                        case (2147483677 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(174/*KnownColor.MenuHighlight*/);
                        case (2147483655 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/);
                        case (2147483648 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/);
                        case (2147483653 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/);
                        case (2147483654 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/);
                        case (2147483656 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/);
                    }
                }
                return $.$sdp.System.Drawing.KnownColorTable.ArgbToKnownColor($.$sdp.System.Drawing.ColorTranslator.COLORREFToARGB((oleColor >>> 0)));
            }
            static /*Color */ FromWin32(/*int*/ win32Color)
            {
                return $.$sdp.System.Drawing.ColorTranslator.FromOle(win32Color);
            }
            static /*Color */ FromHtml(/*string*/ htmlColor)
            {
                /*Color*/ let c = $.$sdp.System.Drawing.Color.Empty;
                if (($.$spc.System.String.op_Equality(htmlColor, null)) || (htmlColor.length === 0))
                {
                    return c;
                }
                if (($.$spc.System.String.get_Chars.call(htmlColor, 0) === /*#*/ 35) && ((htmlColor.length === 7) || (htmlColor.length === 4)))
                {
                    if (htmlColor.length === 7)
                    {
                        c = $.$sdp.System.Drawing.Color.FromArgb$4($.$spc.System.Convert.ToInt32$18($.$spc.System.String.Substring$1.call(htmlColor, 1, 2), 16), $.$spc.System.Convert.ToInt32$18($.$spc.System.String.Substring$1.call(htmlColor, 3, 2), 16), $.$spc.System.Convert.ToInt32$18($.$spc.System.String.Substring$1.call(htmlColor, 5, 2), 16));
                    }
                    else 
                    {
                        /*string*/ let r = $.$spc.System.Char.ToString$2($.$spc.System.String.get_Chars.call(htmlColor, 1));
                        /*string*/ let g = $.$spc.System.Char.ToString$2($.$spc.System.String.get_Chars.call(htmlColor, 2));
                        /*string*/ let b = $.$spc.System.Char.ToString$2($.$spc.System.String.get_Chars.call(htmlColor, 3));
                        c = $.$sdp.System.Drawing.Color.FromArgb$4($.$spc.System.Convert.ToInt32$18(r + r, 16), $.$spc.System.Convert.ToInt32$18(g + g, 16), $.$spc.System.Convert.ToInt32$18(b + b, 16));
                    }
                }
                if (c.IsEmpty && $.$spc.System.String.Equals$5(htmlColor, "LightGrey", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    c = $.$sdp.System.Drawing.Color.LightGray;
                }
                if (c.IsEmpty)
                {
                    if ($.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable === null)
                    {
                        $.$sdp.System.Drawing.ColorTranslator.InitializeHtmlSysColorTable();
                    }
                    $.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable.TryGetValue($.$spc.System.String.ToLowerInvariant.call(htmlColor), $.$ref(() => c, ($v) => c = $v, $.$sdp.System.Drawing.Color));
                }
                if (c.IsEmpty)
                {
                    try
                    {
                        c = $.$sdp.System.Drawing.ColorConverterCommon.ConvertFromString(htmlColor, $.$spc.System.Globalization.CultureInfo.CurrentCulture);
                    }
                    catch(ex)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$12(ex.Message, "htmlColor", ex);
                    }
                }
                return c;
            }
            static /*string */ ToHtml(/*Color*/ c)
            {
                /*string*/ let colorString = $.$spc.System.String.Empty;
                if (c.IsEmpty)
                {
                    return colorString;
                }
                if (c.IsSystemColor)
                {
                    let $switch1 = c.ToKnownColor();
                    switch($switch1)
                    {
                        case 1/*KnownColor.ActiveBorder*/:
                        colorString = "activeborder";
                        break;
                        case 171/*KnownColor.GradientActiveCaption*/:
                        case 2/*KnownColor.ActiveCaption*/:
                        colorString = "activecaption";
                        break;
                        case 4/*KnownColor.AppWorkspace*/:
                        colorString = "appworkspace";
                        break;
                        case 11/*KnownColor.Desktop*/:
                        colorString = "background";
                        break;
                        case 5/*KnownColor.Control*/:
                        case 8/*KnownColor.ControlLight*/:
                        colorString = "buttonface";
                        break;
                        case 6/*KnownColor.ControlDark*/:
                        colorString = "buttonshadow";
                        break;
                        case 10/*KnownColor.ControlText*/:
                        colorString = "buttontext";
                        break;
                        case 3/*KnownColor.ActiveCaptionText*/:
                        colorString = "captiontext";
                        break;
                        case 12/*KnownColor.GrayText*/:
                        colorString = "graytext";
                        break;
                        case 15/*KnownColor.HotTrack*/:
                        case 13/*KnownColor.Highlight*/:
                        colorString = "highlight";
                        break;
                        case 174/*KnownColor.MenuHighlight*/:
                        case 14/*KnownColor.HighlightText*/:
                        colorString = "highlighttext";
                        break;
                        case 16/*KnownColor.InactiveBorder*/:
                        colorString = "inactiveborder";
                        break;
                        case 172/*KnownColor.GradientInactiveCaption*/:
                        case 17/*KnownColor.InactiveCaption*/:
                        colorString = "inactivecaption";
                        break;
                        case 18/*KnownColor.InactiveCaptionText*/:
                        colorString = "inactivecaptiontext";
                        break;
                        case 19/*KnownColor.Info*/:
                        colorString = "infobackground";
                        break;
                        case 20/*KnownColor.InfoText*/:
                        colorString = "infotext";
                        break;
                        case 173/*KnownColor.MenuBar*/:
                        case 21/*KnownColor.Menu*/:
                        colorString = "menu";
                        break;
                        case 22/*KnownColor.MenuText*/:
                        colorString = "menutext";
                        break;
                        case 23/*KnownColor.ScrollBar*/:
                        colorString = "scrollbar";
                        break;
                        case 7/*KnownColor.ControlDarkDark*/:
                        colorString = "threeddarkshadow";
                        break;
                        case 9/*KnownColor.ControlLightLight*/:
                        colorString = "buttonhighlight";
                        break;
                        case 24/*KnownColor.Window*/:
                        colorString = "window";
                        break;
                        case 25/*KnownColor.WindowFrame*/:
                        colorString = "windowframe";
                        break;
                        case 26/*KnownColor.WindowText*/:
                        colorString = "windowtext";
                        break;
                    }
                }
                else if (c.IsNamedColor)
                {
                    if ($.$sdp.System.Drawing.Color.op_Equality(c, $.$sdp.System.Drawing.Color.LightGray))
                    {
                        colorString = "LightGrey";
                    }
                    else 
                    {
                        colorString = c.Name;
                    }
                }
                else 
                {
                    /*int*/ let r;
                    /*int*/ let g;
                    /*int*/ let b;
                    c.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                    colorString = (() =>
                    {
                        var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(1, 3);
                        $handler.AppendLiteral("#");
                        $handler.AppendFormatted$8($.$box(r, $.$spc.System.Int32), null, "X2");
                        $handler.AppendFormatted$8($.$box(g, $.$spc.System.Int32), null, "X2");
                        $handler.AppendFormatted$8($.$box(b, $.$spc.System.Int32), null, "X2");
                        return $handler.ToStringAndClear();
                    })();
                }
                return colorString;
            }
            static /*void */ InitializeHtmlSysColorTable()
            {
                $.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable = (() =>
                {
                    //new $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)()
                    const $t1 = $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color);
                    const $i1 = new $t1();
                    $i1.$ctor$2(27);
                    $i1.Add("activeborder", $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/));
                    $i1.Add("activecaption", $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/));
                    $i1.Add("appworkspace", $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/));
                    $i1.Add("background", $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/));
                    $i1.Add("buttonface", $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/));
                    $i1.Add("buttonhighlight", $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/));
                    $i1.Add("buttonshadow", $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/));
                    $i1.Add("buttontext", $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/));
                    $i1.Add("captiontext", $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/));
                    $i1.Add("graytext", $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/));
                    $i1.Add("highlight", $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/));
                    $i1.Add("highlighttext", $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/));
                    $i1.Add("inactiveborder", $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/));
                    $i1.Add("inactivecaption", $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/));
                    $i1.Add("inactivecaptiontext", $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/));
                    $i1.Add("infobackground", $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/));
                    $i1.Add("infotext", $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/));
                    $i1.Add("menu", $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/));
                    $i1.Add("menutext", $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/));
                    $i1.Add("scrollbar", $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/));
                    $i1.Add("threeddarkshadow", $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/));
                    $i1.Add("threedface", $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/));
                    $i1.Add("threedhighlight", $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/));
                    $i1.Add("threedlightshadow", $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/));
                    $i1.Add("window", $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/));
                    $i1.Add("windowframe", $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/));
                    $i1.Add("windowtext", $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/));
                    return $i1;
                })();
            }
            static $h = 325586;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":720897,"p":[{"n":"value","p":720897}],"n":"COLORREFToARGB","d":325586,"h":25770129362,"f":40},{"r":655361,"p":[{"n":"c","p":128978}],"n":"ToWin32","d":325586,"h":30065096658,"f":33},{"r":655361,"p":[{"n":"c","p":128978}],"n":"ToOle","d":325586,"h":34360063954,"f":33},{"r":128978,"p":[{"n":"oleColor","p":655361}],"n":"FromOle","d":325586,"h":38655031250,"f":33},{"r":128978,"p":[{"n":"win32Color","p":655361}],"n":"FromWin32","d":325586,"h":42949998546,"f":33},{"r":128978,"p":[{"n":"htmlColor","p":1310721}],"n":"FromHtml","d":325586,"h":47244965842,"f":33},{"r":1310721,"p":[{"n":"c","p":128978}],"n":"ToHtml","d":325586,"h":51539933138,"f":33},{"r":65537,"n":"InitializeHtmlSysColorTable","d":325586,"h":55834900434,"f":34}],"l":[{"t":655361,"n":"COLORREF_RedShift","d":325586,"h":4295292882,"f":40},{"t":655361,"n":"COLORREF_GreenShift","d":325586,"h":8590260178,"f":40},{"t":655361,"n":"COLORREF_BlueShift","d":325586,"h":12885227474,"f":40},{"t":655361,"n":"OleSystemColorFlag","d":325586,"h":17180194770,"f":34},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h,"n":"s_htmlSysColorTable","d":325586,"h":21475162066,"f":34}],"h":325586}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.ColorTranslator`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.KnownColorTable", ($self) => class KnownColorTable
        {
            /*byte*/ static KnownColorKindSystem = 0;
            /*byte*/ static KnownColorKindWeb = 1;
            /*byte*/ static KnownColorKindUnknown = 2;
            static /*ReadOnlySpan<uint> */ get ColorValueTable()
            {
                return this.$cacheColorValueTable ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$2([ 0, 4292137160, 4278211811, 4294967295, 4286611584, 4293716440, 4289505433, 4285624164, 4294045666, 4294967295, 4278190080, 4278210200, 4289505433, 4281428677, 4294967295, 4278190208, 4292137160, 4286224095, 4292404472, 4294967265, 4278190080, 4294967295, 4278190080, 4292137160, 4294967295, 4278190080, 4278190080, 16777215, 4293982463, 4294634455, 4278255615, 4286578644, 4293984255, 4294309340, 4294960324, 4278190080, 4294962125, 4278190335, 4287245282, 4289014314, 4292786311, 4284456608, 4286578432, 4291979550, 4294934352, 4284782061, 4294965468, 4292613180, 4278255615, 4278190219, 4278225803, 4290283019, 4289309097, 4278215680, 4290623339, 4287299723, 4283788079, 4294937600, 4288230092, 4287299584, 4293498490, 4287609999, 4282924427, 4281290575, 4278243025, 4287889619, 4294907027, 4278239231, 4285098345, 4280193279, 4289864226, 4294966000, 4280453922, 4294902015, 4292664540, 4294506751, 4294956800, 4292519200, 4286611584, 4278222848, 4289593135, 4293984240, 4294928820, 4291648604, 4283105410, 4294967280, 4293977740, 4293322490, 4294963445, 4286381056, 4294965965, 4289583334, 4293951616, 4292935679, 4294638290, 4292072403, 4287688336, 4294948545, 4294942842, 4280332970, 4287090426, 4286023833, 4289774814, 4294967264, 4278255360, 4281519410, 4294635750, 4294902015, 4286578688, 4284927402, 4278190285, 4290401747, 4287852763, 4282168177, 4286277870, 4278254234, 4282962380, 4291237253, 4279834992, 4294311930, 4294960353, 4294960309, 4294958765, 4278190208, 4294833638, 4286611456, 4285238819, 4294944000, 4294919424, 4292505814, 4293847210, 4288215960, 4289720046, 4292571283, 4294963157, 4294957753, 4291659071, 4294951115, 4292714717, 4289781990, 4286578816, 4294901760, 4290547599, 4282477025, 4287317267, 4294606962, 4294222944, 4281240407, 4294964718, 4288696877, 4290822336, 4287090411, 4285160141, 4285563024, 4294966010, 4278255487, 4282811060, 4291998860, 4278222976, 4292394968, 4294927175, 4282441936, 4293821166, 4294303411, 4294967295, 4294309365, 4294967040, 4288335154, 4293980400, 4294967295, 4288716960, 4290367978, 4292338930, 4293980400, 4281571839, 4284887961 ]);
            }
            static /*ReadOnlySpan<byte> */ get ColorKindTable()
            {
                return this.$cacheColorKindTable ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 2/*KnownColorKindUnknown*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 1/*KnownColorKindWeb*/ ]);
            }
            static /*ReadOnlySpan<uint> */ get AlternateSystemColors()
            {
                return this.$cacheAlternateSystemColors ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$2([ 0, 4282795590, 4282146680, 4294967295, 4282137660, 4280295456, 4283058762, 4284111450, 4281216558, 4280229663, 4294967295, 4279242768, 4288059030, 4280837300, 4278190080, 4281163695, 4282138433, 4281813850, 4290690750, 4283453500, 4290690750, 4281808695, 4293980400, 4283453520, 4281479730, 4280821800, 4293980400, 4280295456, 4279242768, 4282795590, 4282475650, 4283790230, 4281808695, 4280975570 ]);
            }
            static /*Color */ ArgbToKnownColor(/*uint*/ argb)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((argb & 4278190080/*Color.ARGBAlphaMask*/) === 4278190080/*Color.ARGBAlphaMask*/, "(argb & Color.ARGBAlphaMask) == Color.ARGBAlphaMask");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$sdp.System.Drawing.KnownColorTable.ColorValueTable.Length === $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.Length, "ColorValueTable.Length == ColorKindTable.Length");
                /*ReadOnlySpan<uint>*/ let colorValueTable = $.$sdp.System.Drawing.KnownColorTable.ColorValueTable;
                for(/*int*/ let index = 1; index < colorValueTable.Length; ++index)
                {
                    if ($.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(index).$v === 1/*KnownColorKindWeb*/ && colorValueTable.get_Item(index).$v === argb)
                    {
                        return $.$sdp.System.Drawing.Color.FromKnownColor($.$cast(index, $.$sdp.System.Drawing.KnownColor));
                    }
                }
                return $.$sdp.System.Drawing.Color.FromArgb$1((argb | 0));
            }
            static /*uint */ KnownColorToArgb(/*KnownColor*/ color)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(color > 0 && color <= 175/*KnownColor.RebeccaPurple*/, "color > 0 && color <= KnownColor.RebeccaPurple");
                return $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(color).$v === 0/*KnownColorKindSystem*/ ? $.$sdp.System.Drawing.KnownColorTable.GetSystemColorArgb(color) : $.$sdp.System.Drawing.KnownColorTable.ColorValueTable.get_Item(color).$v;
            }
            static /*uint */ GetAlternateSystemColorArgb(/*KnownColor*/ color)
            {
                /*int*/ let index = color <= 26/*KnownColor.WindowText*/ ? color : ((((((color - 168/*KnownColor.ButtonFace*/) | 0) + 26/*KnownColor.WindowText*/) | 0) + 1) | 0);
                return $.$sdp.System.Drawing.KnownColorTable.AlternateSystemColors.get_Item(index).$v;
            }
            static /*uint */ GetSystemColorArgb(/*KnownColor*/ color)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$sdp.System.Drawing.Color.IsKnownColorSystem(color), "Color.IsKnownColorSystem(color)");
                return (!$.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet) ? $.$sdp.System.Drawing.KnownColorTable.ColorValueTable.get_Item(color).$v : $.$sdp.System.Drawing.KnownColorTable.GetAlternateSystemColorArgb(color);
            }
            static $h = 522194;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"g":{"r":0,"d":0,"h":21475358674,"f":33},"n":"ColorValueTable","d":522194,"h":17180391378,"f":33},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":30065293266,"f":33},"n":"ColorKindTable","d":522194,"h":25770325970,"f":33},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"g":{"r":0,"d":0,"h":38655227858,"f":34},"n":"AlternateSystemColors","d":522194,"h":34360260562,"f":34}],"m":[{"r":128978,"p":[{"n":"argb","p":720897}],"n":"ArgbToKnownColor","d":522194,"h":42950195154,"f":40},{"r":720897,"p":[{"n":"color","p":391122}],"n":"KnownColorToArgb","d":522194,"h":47245162450,"f":33},{"r":720897,"p":[{"n":"color","p":391122}],"n":"GetAlternateSystemColorArgb","d":522194,"h":51540129746,"f":34},{"r":720897,"p":[{"n":"color","p":391122}],"n":"GetSystemColorArgb","d":522194,"h":55835097042,"f":33}],"l":[{"t":393217,"n":"KnownColorKindSystem","d":522194,"h":4295489490,"f":33},{"t":393217,"n":"KnownColorKindWeb","d":522194,"h":8590456786,"f":33},{"t":393217,"n":"KnownColorKindUnknown","d":522194,"h":12885424082,"f":33}],"h":522194}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.KnownColorTable`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.SystemColors", ($self) => class SystemColors
        {
            /*bool*/ static s_useAlternativeColorSet = false;
            static /*Color */ get ActiveBorder()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/);
            }
            static /*Color */ get ActiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/);
            }
            static /*Color */ get ActiveCaptionText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/);
            }
            static /*Color */ get AppWorkspace()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/);
            }
            static /*Color */ get ButtonFace()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(168/*KnownColor.ButtonFace*/);
            }
            static /*Color */ get ButtonHighlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(169/*KnownColor.ButtonHighlight*/);
            }
            static /*Color */ get ButtonShadow()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(170/*KnownColor.ButtonShadow*/);
            }
            static /*Color */ get Control()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/);
            }
            static /*Color */ get ControlDark()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/);
            }
            static /*Color */ get ControlDarkDark()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/);
            }
            static /*Color */ get ControlLight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/);
            }
            static /*Color */ get ControlLightLight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/);
            }
            static /*Color */ get ControlText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/);
            }
            static /*Color */ get Desktop()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/);
            }
            static /*Color */ get GradientActiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(171/*KnownColor.GradientActiveCaption*/);
            }
            static /*Color */ get GradientInactiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(172/*KnownColor.GradientInactiveCaption*/);
            }
            static /*Color */ get GrayText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/);
            }
            static /*Color */ get Highlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/);
            }
            static /*Color */ get HighlightText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/);
            }
            static /*Color */ get HotTrack()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(15/*KnownColor.HotTrack*/);
            }
            static /*Color */ get InactiveBorder()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/);
            }
            static /*Color */ get InactiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/);
            }
            static /*Color */ get InactiveCaptionText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/);
            }
            static /*Color */ get Info()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/);
            }
            static /*Color */ get InfoText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/);
            }
            static /*Color */ get Menu()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/);
            }
            static /*Color */ get MenuBar()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(173/*KnownColor.MenuBar*/);
            }
            static /*Color */ get MenuHighlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(174/*KnownColor.MenuHighlight*/);
            }
            static /*Color */ get MenuText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/);
            }
            static /*Color */ get ScrollBar()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/);
            }
            static /*Color */ get Window()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/);
            }
            static /*Color */ get WindowFrame()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/);
            }
            static /*Color */ get WindowText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/);
            }
            static /*bool */ get UseAlternativeColorSet()
            {
                return $.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet;
            }
            static /*bool */ set UseAlternativeColorSet(value)
            {
                $.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet = value;
            }
            static $h = 980946;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":128978,"g":{"r":0,"d":0,"h":12885882834,"f":33},"n":"ActiveBorder","d":980946,"h":8590915538,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":21475817426,"f":33},"n":"ActiveCaption","d":980946,"h":17180850130,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":30065752018,"f":33},"n":"ActiveCaptionText","d":980946,"h":25770784722,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":38655686610,"f":33},"n":"AppWorkspace","d":980946,"h":34360719314,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":47245621202,"f":33},"n":"ButtonFace","d":980946,"h":42950653906,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":55835555794,"f":33},"n":"ButtonHighlight","d":980946,"h":51540588498,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":64425490386,"f":33},"n":"ButtonShadow","d":980946,"h":60130523090,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":73015424978,"f":33},"n":"Control","d":980946,"h":68720457682,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":81605359570,"f":33},"n":"ControlDark","d":980946,"h":77310392274,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":90195294162,"f":33},"n":"ControlDarkDark","d":980946,"h":85900326866,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":98785228754,"f":33},"n":"ControlLight","d":980946,"h":94490261458,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":107375163346,"f":33},"n":"ControlLightLight","d":980946,"h":103080196050,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":115965097938,"f":33},"n":"ControlText","d":980946,"h":111670130642,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":124555032530,"f":33},"n":"Desktop","d":980946,"h":120260065234,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":133144967122,"f":33},"n":"GradientActiveCaption","d":980946,"h":128849999826,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":141734901714,"f":33},"n":"GradientInactiveCaption","d":980946,"h":137439934418,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":150324836306,"f":33},"n":"GrayText","d":980946,"h":146029869010,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":158914770898,"f":33},"n":"Highlight","d":980946,"h":154619803602,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":167504705490,"f":33},"n":"HighlightText","d":980946,"h":163209738194,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":176094640082,"f":33},"n":"HotTrack","d":980946,"h":171799672786,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":184684574674,"f":33},"n":"InactiveBorder","d":980946,"h":180389607378,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":193274509266,"f":33},"n":"InactiveCaption","d":980946,"h":188979541970,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":201864443858,"f":33},"n":"InactiveCaptionText","d":980946,"h":197569476562,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":210454378450,"f":33},"n":"Info","d":980946,"h":206159411154,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":219044313042,"f":33},"n":"InfoText","d":980946,"h":214749345746,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":227634247634,"f":33},"n":"Menu","d":980946,"h":223339280338,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":236224182226,"f":33},"n":"MenuBar","d":980946,"h":231929214930,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":244814116818,"f":33},"n":"MenuHighlight","d":980946,"h":240519149522,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":253404051410,"f":33},"n":"MenuText","d":980946,"h":249109084114,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":261993986002,"f":33},"n":"ScrollBar","d":980946,"h":257699018706,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":270583920594,"f":33},"n":"Window","d":980946,"h":266288953298,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":279173855186,"f":33},"n":"WindowFrame","d":980946,"h":274878887890,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":287763789778,"f":33},"n":"WindowText","d":980946,"h":283468822482,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":296353724370,"f":33},"s":{"r":0,"d":0,"h":300648691666,"f":33},"n":"UseAlternativeColorSet","d":980946,"h":292058757074,"f":33}],"l":[{"t":262145,"n":"s_useAlternativeColorSet","d":980946,"h":4295948242,"f":40}],"h":980946}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.SystemColors`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorConverterCommon", ($self) => class ColorConverterCommon
        {
            static /*Color */ ConvertFromString(/*string*/ strValue, /*CultureInfo*/ culture)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(culture !== null, "culture != null");
                /*string*/ let text = $.$spc.System.String.Trim.call(strValue);
                if (text.length === 0)
                {
                    return $.$sdp.System.Drawing.Color.Empty;
                }
                {
                    /*Color*/ let c;
                    if ($.$sdp.System.Drawing.ColorTable.TryGetNamedColor(text, $.$ref(() => c, ($v) => c = $v, $.$sdp.System.Drawing.Color)))
                    {
                        return c;
                    }
                }
                /*char*/ let sep = $.$spc.System.String.get_Chars.call(culture.TextInfo.ListSeparator, 0);
                if (!$.$spc.System.String.Contains$2.call(text, sep))
                {
                    if (text.length >= 2 && ($.$spc.System.String.get_Chars.call(text, 0) === /*'*/ 39 || $.$spc.System.String.get_Chars.call(text, 0) === /*\"*/ 34) && $.$spc.System.String.get_Chars.call(text, 0) === $.$spc.System.String.get_Chars.call(text, ((text.length - 1) | 0)))
                    {
                        /*string*/ let colorName = $.$spc.System.String.Substring$1.call(text, 1, ((text.length - 2) | 0));
                        return $.$sdp.System.Drawing.Color.FromName(colorName);
                    }
                    else if ((text.length === 7 && $.$spc.System.String.get_Chars.call(text, 0) === /*#*/ 35) || (text.length === 8 && ($.$spc.System.String.StartsWith.call(text, "0x") || $.$spc.System.String.StartsWith.call(text, "0X"))) || (text.length === 8 && ($.$spc.System.String.StartsWith.call(text, "&h") || $.$spc.System.String.StartsWith.call(text, "&H"))))
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$1(((4278190080 | ($.$sdp.System.Drawing.ColorConverterCommon.IntFromString($.$spc.System.String.op_Implicit(text), culture) >>> 0)) | 0)));
                    }
                }
                /*ReadOnlySpan<char>*/ let textSpan = $.$spc.System.String.op_Implicit(text);
                /*Span<Range>*/ let tokens = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Range, 5, null);
                return (() =>
                {
                    let $switch1 = $.$spc.System.MemoryExtensions.Split$2(textSpan, tokens, sep, 0);
                    if ($switch1 === 1)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$1($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture)));
                    }
                    if ($switch1 === 3)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$4($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(1).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(2).$v], culture)));
                    }
                    if ($switch1 === 4)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$2($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(1).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(2).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(3).$v], culture)));
                    }
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sdp.System.SR.Format($.$sdp.System.SR.InvalidColor, text));
                })();
            }
            static /*Color */ PossibleKnownColor(/*Color*/ color)
            {
                /*int*/ let targetARGB = color.ToArgb();
                var $en2 = $.$sdp.System.Drawing.ColorTable.Colors.Values.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current;
                    {
                        if (c.ToArgb() === targetARGB)
                        {
                            return c;
                        }
                    }
                }
                return color;
            }
            static /*int */ IntFromString(/*ReadOnlySpan<char>*/ text, /*CultureInfo*/ culture)
            {
                text = $.$spc.System.MemoryExtensions.Trim$10(text);
                try
                {
                    if (text.get_Item(0).$v === /*#*/ 35)
                    {
                        return $.$spc.System.Convert.ToInt32$18($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(text.Slice(1)), 16);
                    }
                    else if ($.$spc.System.MemoryExtensions.StartsWith$5(text, $.$spc.System.String.op_Implicit("0x"), 5/*StringComparison.OrdinalIgnoreCase*/) || $.$spc.System.MemoryExtensions.StartsWith$5(text, $.$spc.System.String.op_Implicit("&h"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spc.System.Convert.ToInt32$18($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(text.Slice(2)), 16);
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(culture !== null, "culture != null");
                        /*var*/ let formatInfo = $.$cast(culture.GetFormat($.$spc.System.Globalization.NumberFormatInfo.$type), $.$spc.System.Globalization.NumberFormatInfo);
                        return $.$spc.System.Int32.Parse$5(text, formatInfo);
                    }
                }
                catch(e)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$11($.$sdp.System.SR.Format$1($.$sdp.System.SR.ConvertInvalidPrimitive, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(text), "Int32"), e);
                }
            }
            static $h = 194514;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":128978,"p":[{"n":"strValue","p":1310721},{"n":"culture","p":51118081}],"n":"ConvertFromString","d":194514,"h":4295161810,"f":33},{"r":128978,"p":[{"n":"color","p":128978}],"n":"PossibleKnownColor","d":194514,"h":8590129106,"f":34},{"r":655361,"p":[{"n":"text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"culture","p":51118081}],"n":"IntFromString","d":194514,"h":12885096402,"f":34}],"h":194514}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.ColorConverterCommon`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorTable", ($self) => class ColorTable
        {
            /*Lazy<Dictionary<string, Color>>*/ static s_colorConstants = null;
            static /*Dictionary<string, Color> */ GetColors()
            {
                /*var*/ let colors = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color))().$ctor$3($.$spc.System.StringComparer.OrdinalIgnoreCase);
                $.$sdp.System.Drawing.ColorTable.FillWithProperties(colors, $.$sdp.System.Drawing.Color.$type);
                $.$sdp.System.Drawing.ColorTable.FillWithProperties(colors, $.$sdp.System.Drawing.SystemColors.$type);
                return colors;
            }
            static /*void */ FillWithProperties(/*Dictionary<string, Color>*/ dictionary, /*Type*/ typeWithColors)
            {
                let $i1 = 0;
                let $arr1 = typeWithColors.GetProperties$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/);
                while ($i1 < $arr1.length)
                {
                    let prop = $arr1[$i1++];
                    if ($.$spc.System.Type.op_Equality$1(prop.PropertyType, $.$sdp.System.Drawing.Color.$type))
                    {
                        dictionary.set_Item(prop.Name, $.$cast(prop.GetValue$1(null, null), $.$sdp.System.Drawing.Color));
                    }
                }
            }
            static /*Dictionary<string, Color> */ get Colors()
            {
                return $.$sdp.System.Drawing.ColorTable.s_colorConstants.Value;
            }
            static /*bool */ TryGetNamedColor(/*string*/ name, /*out Color*/ result)
            {
                return $.$sdp.System.Drawing.ColorTable.Colors.TryGetValue(name, result);
            }
            static /*bool */ IsKnownNamedColor(/*string*/ name)
            {
                return $.$sdp.System.Drawing.ColorTable.Colors.TryGetValue(name, $.$discardRef());
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_colorConstants = new ($.$spc.System.Lazy$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)))().$ctor$3(new ($.$spc.System.Func$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)))().$ctor(null, $.$sdp.System.Drawing.ColorTable.GetColors));
                }
            }
            static $h = 260050;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h,"g":{"r":0,"d":0,"h":21475096530,"f":40},"n":"Colors","d":260050,"h":17180129234,"f":40}],"m":[{"r":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h,"n":"GetColors","d":260050,"h":8590194642,"f":34},{"r":65537,"p":[{"n":"dictionary","p":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h},{"n":"typeWithColors","p":142606337}],"n":"FillWithProperties","d":260050,"h":12885161938,"f":34},{"r":262145,"p":[{"n":"name","p":1310721},{"n":"result","p":128978,"f":2}],"n":"TryGetNamedColor","d":260050,"h":25770063826,"f":40},{"r":262145,"p":[{"n":"name","p":1310721}],"n":"IsKnownNamedColor","d":260050,"h":30065031122,"f":40}],"l":[{"t":$.$spc.System.Lazy$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)).$h,"n":"s_colorConstants","d":260050,"h":4295227346,"f":34}],"h":260050}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.ColorTable`; }
        });
        
        $asm.$cls("$sdp.System.Experimentals", ($self) => class Experimentals
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static TensorTDiagId = null;
            /*string*/ static SystemColorsDiagId = null;
            /*string*/ static ArmSveDiagId = null;
            /*string*/ static X86BaseDivRemDiagId = null;
            /*string*/ static PostQuantumCryptographyDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.TensorTDiagId = "SYSLIB5001";
                }
                {
                    this.SystemColorsDiagId = "SYSLIB5002";
                }
                {
                    this.ArmSveDiagId = "SYSLIB5003";
                }
                {
                    this.X86BaseDivRemDiagId = "SYSLIB5004";
                }
                {
                    this.PostQuantumCryptographyDiagId = "SYSLIB5006";
                }
            }
            static $h = 1046482;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":1046482,"h":4296013778,"f":40},{"t":1310721,"n":"TensorTDiagId","d":1046482,"h":8590981074,"f":40},{"t":1310721,"n":"SystemColorsDiagId","d":1046482,"h":12885948370,"f":40},{"t":1310721,"n":"ArmSveDiagId","d":1046482,"h":17180915666,"f":40},{"t":1310721,"n":"X86BaseDivRemDiagId","d":1046482,"h":21475882962,"f":40},{"t":1310721,"n":"PostQuantumCryptographyDiagId","d":1046482,"h":25770850258,"f":40}],"h":1046482}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Experimentals`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Point", ($self) => class Point extends $.$spc.System.ValueType
        {
            /*Point*/ static Empty;
            /*int*/  get x() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set x(value) { this.$setField(0, $.$spc.System.Int32, value); }
            /*int*/  get y() { return this.$getField(4, $.$spc.System.Int32); }
            /*int*/  set y(value) { this.$setField(4, $.$spc.System.Int32, value); }
            $ctor$2(/*int*/ x, /*int*/ y)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                }
                return this;
            }
            $ctor$3(/*Size*/ sz)
            {
                super.$ctor$1();
                {
                    this.x = sz.Width;
                    this.y = sz.Height;
                }
                return this;
            }
            $ctor$4(/*int*/ dw)
            {
                super.$ctor$1();
                {
                    this.x = $.$sdp.System.Drawing.Point.LowInt16(dw);
                    this.y = $.$sdp.System.Drawing.Point.HighInt16(dw);
                }
                return this;
            }
            /*bool */ get IsEmpty()
            {
                return this.x === 0 && this.y === 0;
            }
            /*int */ get X()
            {
                return this.x;
            }
            /*int */ set X(value)
            {
                this.x = value;
            }
            /*int */ get Y()
            {
                return this.y;
            }
            /*int */ set Y(value)
            {
                this.y = value;
            }
            static /*PointF */ op_Implicit(/*Point*/ p)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(p.X, p.Y);
            }
            static /*Size */ op_Explicit(/*Point*/ p)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(p.X, p.Y);
            }
            static /*Point */ op_Addition(/*Point*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.Point.Add(pt.Clone(), sz.Clone());
            }
            static /*Point */ op_Subtraction(/*Point*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.Point.Subtract(pt.Clone(), sz.Clone());
            }
            static /*bool */ op_Equality(/*Point*/ left, /*Point*/ right)
            {
                return left.X === right.X && left.Y === right.Y;
            }
            static /*bool */ op_Inequality(/*Point*/ left, /*Point*/ right)
            {
                return !($.$sdp.System.Drawing.Point.op_Equality(left, right));
            }
            static /*Point */ Add(/*Point*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(((pt.X + sz.Width) | 0), ((pt.Y + sz.Height) | 0));
            }
            static /*Point */ Subtract(/*Point*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(((pt.X - sz.Width) | 0), ((pt.Y - sz.Height) | 0));
            }
            static /*Point */ Ceiling(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2($.$cast(Math.ceil(value.X), $.$spc.System.Int32), $.$cast(Math.ceil(value.Y), $.$spc.System.Int32));
            }
            static /*Point */ Truncate(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2($.$cast(value.X, $.$spc.System.Int32), $.$cast(value.Y, $.$spc.System.Int32));
            }
            static /*Point */ Round(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2($.$cast($.$spc.System.Math.Round$4(value.X), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Y), $.$spc.System.Int32));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Point) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Point));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Point.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Point*/ other)
            {
                return $.$sdp.System.Drawing.Point.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Int32, $.$spc.System.Int32, this.X, this.Y);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Point.GetHashCode.apply(this, arguments); }
            /*void */ Offset(/*int*/ dx, /*int*/ dy)
            {
                //unchecked
                {
                    this.X += dx;
                    this.Y += dy;
                }
            }
            /*void */ Offset$1(/*Point*/ p)
            {
                return this.Offset(p.X, p.Y);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Point.ToString.apply(this, arguments); }
            static /*short */ HighInt16(/*int*/ n)
            {
                return $.$cast(((n >> 16) & 65535), $.$spc.System.Int16);
            }
            static /*short */ LowInt16(/*int*/ n)
            {
                return $.$cast((n & 65535), $.$spc.System.Int16);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Point>.Equals(System.Drawing.Point)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$5()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Point);
                }
            }
            static $h = 587730;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360326098,"f":1},"n":"IsEmpty","d":587730,"h":30065358802,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":42950260690,"f":1},"s":{"r":0,"d":0,"h":47245227986,"f":1},"n":"X","d":587730,"h":38655293394,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55835162578,"f":1},"s":{"r":0,"d":0,"h":60130129874,"f":1},"n":"Y","d":587730,"h":51540195282,"f":1}],"m":[{"r":587730,"p":[{"n":"pt","p":587730},{"n":"sz","p":849874}],"n":"Add","d":587730,"h":90194900946,"f":33},{"r":587730,"p":[{"n":"pt","p":587730},{"n":"sz","p":849874}],"n":"Subtract","d":587730,"h":94489868242,"f":33},{"r":587730,"p":[{"n":"value","p":653266}],"n":"Ceiling","d":587730,"h":98784835538,"f":33},{"r":587730,"p":[{"n":"value","p":653266}],"n":"Truncate","d":587730,"h":103079802834,"f":33},{"r":587730,"p":[{"n":"value","p":653266}],"n":"Round","d":587730,"h":107374770130,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":587730,"h":111669737426,"f":32769},{"r":262145,"p":[{"n":"other","p":587730}],"n":"Equals","o":"@$2","d":587730,"h":115964704722,"f":1},{"r":655361,"n":"GetHashCode","d":587730,"h":120259672018,"f":32769},{"r":65537,"p":[{"n":"dx","p":655361},{"n":"dy","p":655361}],"n":"Offset","d":587730,"h":124554639314,"f":1},{"r":65537,"p":[{"n":"p","p":587730}],"n":"Offset","o":"@$1","d":587730,"h":128849606610,"f":1},{"r":1310721,"n":"ToString","d":587730,"h":133144573906,"f":32769},{"r":524289,"p":[{"n":"n","p":655361}],"n":"HighInt16","d":587730,"h":137439541202,"f":34},{"r":524289,"p":[{"n":"n","p":655361}],"n":"LowInt16","d":587730,"h":141734508498,"f":34}],"l":[{"t":587730,"n":"Empty","d":587730,"h":4295555026,"f":33},{"t":655361,"n":"x","d":587730,"h":8590522322,"f":2},{"t":655361,"n":"y","d":587730,"h":12885489618,"f":2}],"c":[{"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":".ctor","o":"$ctor$2","d":587730,"h":17180456914,"f":1},{"p":[{"n":"sz","p":849874}],"n":".ctor","o":"$ctor$3","d":587730,"h":21475424210,"f":1},{"p":[{"n":"dw","p":655361}],"n":".ctor","o":"$ctor$4","d":587730,"h":25770391506,"f":1},{"n":".ctor","o":"$ctor$5","d":587730,"h":146029475794,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Point).$h],"h":587730,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1481253,"c":17181350437,"a":[{"v":"System.Drawing.PointConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Point) ]; }
            static get $fullName() { return `System.Drawing.Point`; }
        });
        
        $asm.$str("$sdp.System.Drawing.PointF", ($self) => class PointF extends $.$spc.System.ValueType
        {
            /*PointF*/ static Empty;
            /*float*/  get x() { return this.$getField(0, $.$spc.System.Single); }
            /*float*/  set x(value) { this.$setField(0, $.$spc.System.Single, value); }
            /*float*/  get y() { return this.$getField(4, $.$spc.System.Single); }
            /*float*/  set y(value) { this.$setField(4, $.$spc.System.Single, value); }
            $ctor$2(/*float*/ x, /*float*/ y)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                }
                return this;
            }
            $ctor$3(/*Vector2*/ vector)
            {
                super.$ctor$1();
                {
                    this.x = vector.X;
                    this.y = vector.Y;
                }
                return this;
            }
            /*Vector2 */ ToVector2()
            {
                return new $.$spc.System.Numerics.Vector2().$ctor$3(this.x, this.y);
            }
            /*bool */ get IsEmpty()
            {
                return this.x === 0 && this.y === 0;
            }
            /*float */ get X()
            {
                return this.x;
            }
            /*float */ set X(value)
            {
                this.x = value;
            }
            /*float */ get Y()
            {
                return this.y;
            }
            /*float */ set Y(value)
            {
                this.y = value;
            }
            static /*Vector2 */ op_Explicit(/*PointF*/ point)
            {
                return point.ToVector2();
            }
            static /*PointF */ op_Explicit$1(/*Vector2*/ vector)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$3(vector.Clone());
            }
            static /*PointF */ op_Addition(/*PointF*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Add(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Subtraction(/*PointF*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Subtract(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Addition$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Add$1(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Subtraction$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Subtract$1(pt.Clone(), sz.Clone());
            }
            static /*bool */ op_Equality(/*PointF*/ left, /*PointF*/ right)
            {
                return left.X === right.X && left.Y === right.Y;
            }
            static /*bool */ op_Inequality(/*PointF*/ left, /*PointF*/ right)
            {
                return !($.$sdp.System.Drawing.PointF.op_Equality(left, right));
            }
            static /*PointF */ Add(/*PointF*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X + sz.Width, pt.Y + sz.Height);
            }
            static /*PointF */ Subtract(/*PointF*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X - sz.Width, pt.Y - sz.Height);
            }
            static /*PointF */ Add$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X + sz.Width, pt.Y + sz.Height);
            }
            static /*PointF */ Subtract$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X - sz.Width, pt.Y - sz.Height);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.PointF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.PointF));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.PointF.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*PointF*/ other)
            {
                return $.$sdp.System.Drawing.PointF.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Single.GetHashCode.call(this.X), $.$spc.System.Single.GetHashCode.call(this.Y));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.PointF.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.x}, Y=${this.y}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.PointF.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.PointF>.Equals(System.Drawing.PointF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.PointF);
                }
            }
            static $h = 653266;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360391634,"f":1},"n":"IsEmpty","d":653266,"h":30065424338,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":42950326226,"f":1},"s":{"r":0,"d":0,"h":47245293522,"f":1},"n":"X","d":653266,"h":38655358930,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":55835228114,"f":1},"s":{"r":0,"d":0,"h":60130195410,"f":1},"n":"Y","d":653266,"h":51540260818,"f":1}],"m":[{"r":70582273,"n":"ToVector2","d":653266,"h":25770457042,"f":1},{"r":653266,"p":[{"n":"pt","p":653266},{"n":"sz","p":849874}],"n":"Add","d":653266,"h":98784901074,"f":33},{"r":653266,"p":[{"n":"pt","p":653266},{"n":"sz","p":849874}],"n":"Subtract","d":653266,"h":103079868370,"f":33},{"r":653266,"p":[{"n":"pt","p":653266},{"n":"sz","p":915410}],"n":"Add","o":"@$1","d":653266,"h":107374835666,"f":33},{"r":653266,"p":[{"n":"pt","p":653266},{"n":"sz","p":915410}],"n":"Subtract","o":"@$1","d":653266,"h":111669802962,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":653266,"h":115964770258,"f":32769},{"r":262145,"p":[{"n":"other","p":653266}],"n":"Equals","o":"@$2","d":653266,"h":120259737554,"f":1},{"r":655361,"n":"GetHashCode","d":653266,"h":124554704850,"f":32769},{"r":1310721,"n":"ToString","d":653266,"h":128849672146,"f":32769}],"l":[{"t":653266,"n":"Empty","d":653266,"h":4295620562,"f":33},{"t":1114113,"n":"x","d":653266,"h":8590587858,"f":2},{"t":1114113,"n":"y","d":653266,"h":12885555154,"f":2}],"c":[{"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":".ctor","o":"$ctor$2","d":653266,"h":17180522450,"f":1},{"p":[{"n":"vector","p":70582273}],"n":".ctor","o":"$ctor$3","d":653266,"h":21475489746,"f":1},{"n":".ctor","o":"$ctor$4","d":653266,"h":133144639442,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.PointF).$h],"h":653266,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.PointF) ]; }
            static get $fullName() { return `System.Drawing.PointF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Rectangle", ($self) => class Rectangle extends $.$spc.System.ValueType
        {
            /*Rectangle*/ static Empty;
            /*int*/  get x() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set x(value) { this.$setField(0, $.$spc.System.Int32, value); }
            /*int*/  get y() { return this.$getField(4, $.$spc.System.Int32); }
            /*int*/  set y(value) { this.$setField(4, $.$spc.System.Int32, value); }
            /*int*/  get width() { return this.$getField(8, $.$spc.System.Int32); }
            /*int*/  set width(value) { this.$setField(8, $.$spc.System.Int32, value); }
            /*int*/  get height() { return this.$getField(12, $.$spc.System.Int32); }
            /*int*/  set height(value) { this.$setField(12, $.$spc.System.Int32, value); }
            $ctor$2(/*int*/ x, /*int*/ y, /*int*/ width, /*int*/ height)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            $ctor$3(/*Point*/ location, /*Size*/ size)
            {
                super.$ctor$1();
                {
                    this.x = location.X;
                    this.y = location.Y;
                    this.width = size.Width;
                    this.height = size.Height;
                }
                return this;
            }
            static /*Rectangle */ FromLTRB(/*int*/ left, /*int*/ top, /*int*/ right, /*int*/ bottom)
            {
                return new $.$sdp.System.Drawing.Rectangle().$ctor$2(left, top, ((right - left) | 0), ((bottom - top) | 0));
            }
            /*Point */ get Location()
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(this.X, this.Y);
            }
            /*Point */ set Location(value)
            {
                this.X = value.X;
                this.Y = value.Y;
            }
            /*Size */ get Size()
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(this.Width, this.Height);
            }
            /*Size */ set Size(value)
            {
                this.Width = value.Width;
                this.Height = value.Height;
            }
            /*int */ get X()
            {
                return this.x;
            }
            /*int */ set X(value)
            {
                this.x = value;
            }
            /*int */ get Y()
            {
                return this.y;
            }
            /*int */ set Y(value)
            {
                this.y = value;
            }
            /*int */ get Width()
            {
                return this.width;
            }
            /*int */ set Width(value)
            {
                this.width = value;
            }
            /*int */ get Height()
            {
                return this.height;
            }
            /*int */ set Height(value)
            {
                this.height = value;
            }
            /*int */ get Left()
            {
                return this.X;
            }
            /*int */ get Top()
            {
                return this.Y;
            }
            /*int */ get Right()
            {
                return ((this.X + this.Width) | 0);
            }
            /*int */ get Bottom()
            {
                return ((this.Y + this.Height) | 0);
            }
            /*bool */ get IsEmpty()
            {
                return this.height === 0 && this.width === 0 && this.x === 0 && this.y === 0;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Rectangle) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Rectangle));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Rectangle.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Rectangle*/ other)
            {
                return $.$sdp.System.Drawing.Rectangle.op_Equality(this, other);
            }
            static /*bool */ op_Equality(/*Rectangle*/ left, /*Rectangle*/ right)
            {
                return left.X === right.X && left.Y === right.Y && left.Width === right.Width && left.Height === right.Height;
            }
            static /*bool */ op_Inequality(/*Rectangle*/ left, /*Rectangle*/ right)
            {
                return !($.$sdp.System.Drawing.Rectangle.op_Equality(left, right));
            }
            static /*Rectangle */ Ceiling(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2($.$cast(Math.ceil(value.X), $.$spc.System.Int32), $.$cast(Math.ceil(value.Y), $.$spc.System.Int32), $.$cast(Math.ceil(value.Width), $.$spc.System.Int32), $.$cast(Math.ceil(value.Height), $.$spc.System.Int32));
                }
            }
            static /*Rectangle */ Truncate(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2($.$cast(value.X, $.$spc.System.Int32), $.$cast(value.Y, $.$spc.System.Int32), $.$cast(value.Width, $.$spc.System.Int32), $.$cast(value.Height, $.$spc.System.Int32));
                }
            }
            static /*Rectangle */ Round(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2($.$cast($.$spc.System.Math.Round$4(value.X), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Y), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Width), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Height), $.$spc.System.Int32));
                }
            }
            /*bool */ Contains(/*int*/ x, /*int*/ y)
            {
                return this.X <= x && x < ((this.X + this.Width) | 0) && this.Y <= y && y < ((this.Y + this.Height) | 0);
            }
            /*bool */ Contains$1(/*Point*/ pt)
            {
                return this.Contains(pt.X, pt.Y);
            }
            /*bool */ Contains$2(/*Rectangle*/ rect)
            {
                return (this.X <= rect.X) && (((rect.X + rect.Width) | 0) <= ((this.X + this.Width) | 0)) && (this.Y <= rect.Y) && (((rect.Y + rect.Height) | 0) <= ((this.Y + this.Height) | 0));
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$3($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, this.X, this.Y, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Rectangle.GetHashCode.apply(this, arguments); }
            /*void */ Inflate(/*int*/ width, /*int*/ height)
            {
                //unchecked
                {
                    this.X -= width;
                    this.Y -= height;
                    this.Width += ((2 * width) | 0);
                    this.Height += ((2 * height) | 0);
                }
            }
            /*void */ Inflate$1(/*Size*/ size)
            {
                return this.Inflate(size.Width, size.Height);
            }
            static /*Rectangle */ Inflate$2(/*Rectangle*/ rect, /*int*/ x, /*int*/ y)
            {
                /*Rectangle*/ let r = rect;
                r.Inflate(x, y);
                return r;
            }
            /*void */ Intersect(/*Rectangle*/ rect)
            {
                /*Rectangle*/ let result = $.$sdp.System.Drawing.Rectangle.Intersect$1(rect.Clone(), this);
                this.X = result.X;
                this.Y = result.Y;
                this.Width = result.Width;
                this.Height = result.Height;
            }
            static /*Rectangle */ Intersect$1(/*Rectangle*/ a, /*Rectangle*/ b)
            {
                /*int*/ let x1 = $.$spc.System.Math.Max$4(a.X, b.X);
                /*int*/ let x2 = $.$spc.System.Math.Min$4(((a.X + a.Width) | 0), ((b.X + b.Width) | 0));
                /*int*/ let y1 = $.$spc.System.Math.Max$4(a.Y, b.Y);
                /*int*/ let y2 = $.$spc.System.Math.Min$4(((a.Y + a.Height) | 0), ((b.Y + b.Height) | 0));
                if (x2 >= x1 && y2 >= y1)
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2(x1, y1, ((x2 - x1) | 0), ((y2 - y1) | 0));
                }
                return $.$sdp.System.Drawing.Rectangle.Empty;
            }
            /*bool */ IntersectsWith(/*Rectangle*/ rect)
            {
                return (rect.X < ((this.X + this.Width) | 0)) && (this.X < ((rect.X + rect.Width) | 0)) && (rect.Y < ((this.Y + this.Height) | 0)) && (this.Y < ((rect.Y + rect.Height) | 0));
            }
            static /*Rectangle */ Union(/*Rectangle*/ a, /*Rectangle*/ b)
            {
                /*int*/ let x1 = $.$spc.System.Math.Min$4(a.X, b.X);
                /*int*/ let x2 = $.$spc.System.Math.Max$4(((a.X + a.Width) | 0), ((b.X + b.Width) | 0));
                /*int*/ let y1 = $.$spc.System.Math.Min$4(a.Y, b.Y);
                /*int*/ let y2 = $.$spc.System.Math.Max$4(((a.Y + a.Height) | 0), ((b.Y + b.Height) | 0));
                return new $.$sdp.System.Drawing.Rectangle().$ctor$2(x1, y1, ((x2 - x1) | 0), ((y2 - y1) | 0));
            }
            /*void */ Offset(/*Point*/ pos)
            {
                return this.Offset$1(pos.X, pos.Y);
            }
            /*void */ Offset$1(/*int*/ x, /*int*/ y)
            {
                //unchecked
                {
                    this.X += x;
                    this.Y += y;
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y},Width=${this.Width},Height=${this.Height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Rectangle.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Rectangle>.Equals(System.Drawing.Rectangle)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Rectangle);
                }
            }
            static $h = 718802;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":587730,"g":{"r":0,"d":0,"h":42950391762,"f":1},"s":{"r":0,"d":0,"h":47245359058,"f":1},"n":"Location","d":718802,"h":38655424466,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":849874,"g":{"r":0,"d":0,"h":55835293650,"f":1},"s":{"r":0,"d":0,"h":60130260946,"f":1},"n":"Size","d":718802,"h":51540326354,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":68720195538,"f":1},"s":{"r":0,"d":0,"h":73015162834,"f":1},"n":"X","d":718802,"h":64425228242,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":81605097426,"f":1},"s":{"r":0,"d":0,"h":85900064722,"f":1},"n":"Y","d":718802,"h":77310130130,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":94489999314,"f":1},"s":{"r":0,"d":0,"h":98784966610,"f":1},"n":"Width","d":718802,"h":90195032018,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":107374901202,"f":1},"s":{"r":0,"d":0,"h":111669868498,"f":1},"n":"Height","d":718802,"h":103079933906,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":120259803090,"f":1},"n":"Left","d":718802,"h":115964835794,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":128849737682,"f":1},"n":"Top","d":718802,"h":124554770386,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":137439672274,"f":1},"n":"Right","d":718802,"h":133144704978,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":146029606866,"f":1},"n":"Bottom","d":718802,"h":141734639570,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":262145,"g":{"r":0,"d":0,"h":154619541458,"f":1},"n":"IsEmpty","d":718802,"h":150324574162,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]}],"m":[{"r":718802,"p":[{"n":"left","p":655361},{"n":"top","p":655361},{"n":"right","p":655361},{"n":"bottom","p":655361}],"n":"FromLTRB","d":718802,"h":34360457170,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":718802,"h":158914508754,"f":32769},{"r":262145,"p":[{"n":"other","p":718802}],"n":"Equals","o":"@$2","d":718802,"h":163209476050,"f":1},{"r":718802,"p":[{"n":"value","p":784338}],"n":"Ceiling","d":718802,"h":176094377938,"f":33},{"r":718802,"p":[{"n":"value","p":784338}],"n":"Truncate","d":718802,"h":180389345234,"f":33},{"r":718802,"p":[{"n":"value","p":784338}],"n":"Round","d":718802,"h":184684312530,"f":33},{"r":262145,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Contains","d":718802,"h":188979279826,"f":1},{"r":262145,"p":[{"n":"pt","p":587730}],"n":"Contains","o":"@$1","d":718802,"h":193274247122,"f":1},{"r":262145,"p":[{"n":"rect","p":718802}],"n":"Contains","o":"@$2","d":718802,"h":197569214418,"f":1},{"r":655361,"n":"GetHashCode","d":718802,"h":201864181714,"f":32769},{"r":65537,"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":"Inflate","d":718802,"h":206159149010,"f":1},{"r":65537,"p":[{"n":"size","p":849874}],"n":"Inflate","o":"@$1","d":718802,"h":210454116306,"f":1},{"r":718802,"p":[{"n":"rect","p":718802},{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Inflate","o":"@$2","d":718802,"h":214749083602,"f":33},{"r":65537,"p":[{"n":"rect","p":718802}],"n":"Intersect","d":718802,"h":219044050898,"f":1},{"r":718802,"p":[{"n":"a","p":718802},{"n":"b","p":718802}],"n":"Intersect","o":"@$1","d":718802,"h":223339018194,"f":33},{"r":262145,"p":[{"n":"rect","p":718802}],"n":"IntersectsWith","d":718802,"h":227633985490,"f":1},{"r":718802,"p":[{"n":"a","p":718802},{"n":"b","p":718802}],"n":"Union","d":718802,"h":231928952786,"f":33},{"r":65537,"p":[{"n":"pos","p":587730}],"n":"Offset","d":718802,"h":236223920082,"f":1},{"r":65537,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Offset","o":"@$1","d":718802,"h":240518887378,"f":1},{"r":1310721,"n":"ToString","d":718802,"h":244813854674,"f":32769}],"l":[{"t":718802,"n":"Empty","d":718802,"h":4295686098,"f":33},{"t":655361,"n":"x","d":718802,"h":8590653394,"f":2},{"t":655361,"n":"y","d":718802,"h":12885620690,"f":2},{"t":655361,"n":"width","d":718802,"h":17180587986,"f":2},{"t":655361,"n":"height","d":718802,"h":21475555282,"f":2}],"c":[{"p":[{"n":"x","p":655361},{"n":"y","p":655361},{"n":"width","p":655361},{"n":"height","p":655361}],"n":".ctor","o":"$ctor$2","d":718802,"h":25770522578,"f":1},{"p":[{"n":"location","p":587730},{"n":"size","p":849874}],"n":".ctor","o":"$ctor$3","d":718802,"h":30065489874,"f":1},{"n":".ctor","o":"$ctor$4","d":718802,"h":249108821970,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Rectangle).$h],"h":718802,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1481253,"c":17181350437,"a":[{"v":"System.Drawing.RectangleConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Rectangle) ]; }
            static get $fullName() { return `System.Drawing.Rectangle`; }
        });
        
        $asm.$str("$sdp.System.Drawing.RectangleF", ($self) => class RectangleF extends $.$spc.System.ValueType
        {
            /*RectangleF*/ static Empty;
            /*float*/  get x() { return this.$getField(0, $.$spc.System.Single); }
            /*float*/  set x(value) { this.$setField(0, $.$spc.System.Single, value); }
            /*float*/  get y() { return this.$getField(4, $.$spc.System.Single); }
            /*float*/  set y(value) { this.$setField(4, $.$spc.System.Single, value); }
            /*float*/  get width() { return this.$getField(8, $.$spc.System.Single); }
            /*float*/  set width(value) { this.$setField(8, $.$spc.System.Single, value); }
            /*float*/  get height() { return this.$getField(12, $.$spc.System.Single); }
            /*float*/  set height(value) { this.$setField(12, $.$spc.System.Single, value); }
            $ctor$2(/*float*/ x, /*float*/ y, /*float*/ width, /*float*/ height)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            $ctor$3(/*PointF*/ location, /*SizeF*/ size)
            {
                super.$ctor$1();
                {
                    this.x = location.X;
                    this.y = location.Y;
                    this.width = size.Width;
                    this.height = size.Height;
                }
                return this;
            }
            $ctor$4(/*Vector4*/ vector)
            {
                super.$ctor$1();
                {
                    this.x = vector.X;
                    this.y = vector.Y;
                    this.width = vector.Z;
                    this.height = vector.W;
                }
                return this;
            }
            /*Vector4 */ ToVector4()
            {
                return new $.$spc.System.Numerics.Vector4().$ctor$5(this.x, this.y, this.width, this.height);
            }
            static /*Vector4 */ op_Explicit(/*RectangleF*/ rectangle)
            {
                return rectangle.ToVector4();
            }
            static /*RectangleF */ op_Explicit$1(/*Vector4*/ vector)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$4(vector.Clone());
            }
            static /*RectangleF */ FromLTRB(/*float*/ left, /*float*/ top, /*float*/ right, /*float*/ bottom)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$2(left, top, right - left, bottom - top);
            }
            /*PointF */ get Location()
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(this.X, this.Y);
            }
            /*PointF */ set Location(value)
            {
                this.X = value.X;
                this.Y = value.Y;
            }
            /*SizeF */ get Size()
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(this.Width, this.Height);
            }
            /*SizeF */ set Size(value)
            {
                this.Width = value.Width;
                this.Height = value.Height;
            }
            /*float */ get X()
            {
                return this.x;
            }
            /*float */ set X(value)
            {
                this.x = value;
            }
            /*float */ get Y()
            {
                return this.y;
            }
            /*float */ set Y(value)
            {
                this.y = value;
            }
            /*float */ get Width()
            {
                return this.width;
            }
            /*float */ set Width(value)
            {
                this.width = value;
            }
            /*float */ get Height()
            {
                return this.height;
            }
            /*float */ set Height(value)
            {
                this.height = value;
            }
            /*float */ get Left()
            {
                return this.X;
            }
            /*float */ get Top()
            {
                return this.Y;
            }
            /*float */ get Right()
            {
                return this.X + this.Width;
            }
            /*float */ get Bottom()
            {
                return this.Y + this.Height;
            }
            /*bool */ get IsEmpty()
            {
                return (this.Width <= 0) || (this.Height <= 0);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.RectangleF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.RectangleF));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.RectangleF.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*RectangleF*/ other)
            {
                return $.$sdp.System.Drawing.RectangleF.op_Equality(this, other);
            }
            static /*bool */ op_Equality(/*RectangleF*/ left, /*RectangleF*/ right)
            {
                return left.X === right.X && left.Y === right.Y && left.Width === right.Width && left.Height === right.Height;
            }
            static /*bool */ op_Inequality(/*RectangleF*/ left, /*RectangleF*/ right)
            {
                return !($.$sdp.System.Drawing.RectangleF.op_Equality(left, right));
            }
            /*bool */ Contains(/*float*/ x, /*float*/ y)
            {
                return this.X <= x && x < this.X + this.Width && this.Y <= y && y < this.Y + this.Height;
            }
            /*bool */ Contains$1(/*PointF*/ pt)
            {
                return this.Contains(pt.X, pt.Y);
            }
            /*bool */ Contains$2(/*RectangleF*/ rect)
            {
                return (this.X <= rect.X) && (rect.X + rect.Width <= this.X + this.Width) && (this.Y <= rect.Y) && (rect.Y + rect.Height <= this.Y + this.Height);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$3($.$spc.System.Single, $.$spc.System.Single, $.$spc.System.Single, $.$spc.System.Single, this.X, this.Y, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.RectangleF.GetHashCode.apply(this, arguments); }
            /*void */ Inflate(/*float*/ x, /*float*/ y)
            {
                this.X -= x;
                this.Y -= y;
                this.Width += 2 * x;
                this.Height += 2 * y;
            }
            /*void */ Inflate$1(/*SizeF*/ size)
            {
                return this.Inflate(size.Width, size.Height);
            }
            static /*RectangleF */ Inflate$2(/*RectangleF*/ rect, /*float*/ x, /*float*/ y)
            {
                /*RectangleF*/ let r = rect;
                r.Inflate(x, y);
                return r;
            }
            /*void */ Intersect(/*RectangleF*/ rect)
            {
                /*RectangleF*/ let result = $.$sdp.System.Drawing.RectangleF.Intersect$1(rect.Clone(), this);
                this.X = result.X;
                this.Y = result.Y;
                this.Width = result.Width;
                this.Height = result.Height;
            }
            static /*RectangleF */ Intersect$1(/*RectangleF*/ a, /*RectangleF*/ b)
            {
                /*float*/ let x1 = $.$spc.System.Math.Max$8(a.X, b.X);
                /*float*/ let x2 = $.$spc.System.Math.Min$8(a.X + a.Width, b.X + b.Width);
                /*float*/ let y1 = $.$spc.System.Math.Max$8(a.Y, b.Y);
                /*float*/ let y2 = $.$spc.System.Math.Min$8(a.Y + a.Height, b.Y + b.Height);
                if (x2 >= x1 && y2 >= y1)
                {
                    return new $.$sdp.System.Drawing.RectangleF().$ctor$2(x1, y1, x2 - x1, y2 - y1);
                }
                return $.$sdp.System.Drawing.RectangleF.Empty;
            }
            /*bool */ IntersectsWith(/*RectangleF*/ rect)
            {
                return (rect.X < this.X + this.Width) && (this.X < rect.X + rect.Width) && (rect.Y < this.Y + this.Height) && (this.Y < rect.Y + rect.Height);
            }
            static /*RectangleF */ Union(/*RectangleF*/ a, /*RectangleF*/ b)
            {
                /*float*/ let x1 = $.$spc.System.Math.Min$8(a.X, b.X);
                /*float*/ let x2 = $.$spc.System.Math.Max$8(a.X + a.Width, b.X + b.Width);
                /*float*/ let y1 = $.$spc.System.Math.Min$8(a.Y, b.Y);
                /*float*/ let y2 = $.$spc.System.Math.Max$8(a.Y + a.Height, b.Y + b.Height);
                return new $.$sdp.System.Drawing.RectangleF().$ctor$2(x1, y1, x2 - x1, y2 - y1);
            }
            /*void */ Offset(/*PointF*/ pos)
            {
                return this.Offset$1(pos.X, pos.Y);
            }
            /*void */ Offset$1(/*float*/ x, /*float*/ y)
            {
                this.X += x;
                this.Y += y;
            }
            static /*RectangleF */ op_Implicit(/*Rectangle*/ r)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$2(r.X, r.Y, r.Width, r.Height);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y},Width=${this.Width},Height=${this.Height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.RectangleF.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.RectangleF>.Equals(System.Drawing.RectangleF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$5()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.RectangleF);
                }
            }
            static $h = 784338;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":653266,"g":{"r":0,"d":0,"h":60130326482,"f":1},"s":{"r":0,"d":0,"h":64425293778,"f":1},"n":"Location","d":784338,"h":55835359186,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":915410,"g":{"r":0,"d":0,"h":73015228370,"f":1},"s":{"r":0,"d":0,"h":77310195666,"f":1},"n":"Size","d":784338,"h":68720261074,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":85900130258,"f":1},"s":{"r":0,"d":0,"h":90195097554,"f":1},"n":"X","d":784338,"h":81605162962,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":98785032146,"f":1},"s":{"r":0,"d":0,"h":103079999442,"f":1},"n":"Y","d":784338,"h":94490064850,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":111669934034,"f":1},"s":{"r":0,"d":0,"h":115964901330,"f":1},"n":"Width","d":784338,"h":107374966738,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":124554835922,"f":1},"s":{"r":0,"d":0,"h":128849803218,"f":1},"n":"Height","d":784338,"h":120259868626,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":137439737810,"f":1},"n":"Left","d":784338,"h":133144770514,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":146029672402,"f":1},"n":"Top","d":784338,"h":141734705106,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":154619606994,"f":1},"n":"Right","d":784338,"h":150324639698,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":163209541586,"f":1},"n":"Bottom","d":784338,"h":158914574290,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":262145,"g":{"r":0,"d":0,"h":171799476178,"f":1},"n":"IsEmpty","d":784338,"h":167504508882,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]}],"m":[{"r":70713345,"n":"ToVector4","d":784338,"h":38655490002,"f":1},{"r":784338,"p":[{"n":"left","p":1114113},{"n":"top","p":1114113},{"n":"right","p":1114113},{"n":"bottom","p":1114113}],"n":"FromLTRB","d":784338,"h":51540391890,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":784338,"h":176094443474,"f":32769},{"r":262145,"p":[{"n":"other","p":784338}],"n":"Equals","o":"@$2","d":784338,"h":180389410770,"f":1},{"r":262145,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Contains","d":784338,"h":193274312658,"f":1},{"r":262145,"p":[{"n":"pt","p":653266}],"n":"Contains","o":"@$1","d":784338,"h":197569279954,"f":1},{"r":262145,"p":[{"n":"rect","p":784338}],"n":"Contains","o":"@$2","d":784338,"h":201864247250,"f":1},{"r":655361,"n":"GetHashCode","d":784338,"h":206159214546,"f":32769},{"r":65537,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Inflate","d":784338,"h":210454181842,"f":1},{"r":65537,"p":[{"n":"size","p":915410}],"n":"Inflate","o":"@$1","d":784338,"h":214749149138,"f":1},{"r":784338,"p":[{"n":"rect","p":784338},{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Inflate","o":"@$2","d":784338,"h":219044116434,"f":33},{"r":65537,"p":[{"n":"rect","p":784338}],"n":"Intersect","d":784338,"h":223339083730,"f":1},{"r":784338,"p":[{"n":"a","p":784338},{"n":"b","p":784338}],"n":"Intersect","o":"@$1","d":784338,"h":227634051026,"f":33},{"r":262145,"p":[{"n":"rect","p":784338}],"n":"IntersectsWith","d":784338,"h":231929018322,"f":1},{"r":784338,"p":[{"n":"a","p":784338},{"n":"b","p":784338}],"n":"Union","d":784338,"h":236223985618,"f":33},{"r":65537,"p":[{"n":"pos","p":653266}],"n":"Offset","d":784338,"h":240518952914,"f":1},{"r":65537,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Offset","o":"@$1","d":784338,"h":244813920210,"f":1},{"r":1310721,"n":"ToString","d":784338,"h":253403854802,"f":32769}],"l":[{"t":784338,"n":"Empty","d":784338,"h":4295751634,"f":33},{"t":1114113,"n":"x","d":784338,"h":8590718930,"f":2},{"t":1114113,"n":"y","d":784338,"h":12885686226,"f":2},{"t":1114113,"n":"width","d":784338,"h":17180653522,"f":2},{"t":1114113,"n":"height","d":784338,"h":21475620818,"f":2}],"c":[{"p":[{"n":"x","p":1114113},{"n":"y","p":1114113},{"n":"width","p":1114113},{"n":"height","p":1114113}],"n":".ctor","o":"$ctor$2","d":784338,"h":25770588114,"f":1},{"p":[{"n":"location","p":653266},{"n":"size","p":915410}],"n":".ctor","o":"$ctor$3","d":784338,"h":30065555410,"f":1},{"p":[{"n":"vector","p":70713345}],"n":".ctor","o":"$ctor$4","d":784338,"h":34360522706,"f":1},{"n":".ctor","o":"$ctor$5","d":784338,"h":257698822098,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.RectangleF).$h],"h":784338,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.RectangleF) ]; }
            static get $fullName() { return `System.Drawing.RectangleF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Size", ($self) => class Size extends $.$spc.System.ValueType
        {
            /*Size*/ static Empty;
            /*int*/  get width() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set width(value) { this.$setField(0, $.$spc.System.Int32, value); }
            /*int*/  get height() { return this.$getField(4, $.$spc.System.Int32); }
            /*int*/  set height(value) { this.$setField(4, $.$spc.System.Int32, value); }
            $ctor$2(/*Point*/ pt)
            {
                super.$ctor$1();
                {
                    this.width = pt.X;
                    this.height = pt.Y;
                }
                return this;
            }
            $ctor$3(/*int*/ width, /*int*/ height)
            {
                super.$ctor$1();
                {
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            static /*SizeF */ op_Implicit(/*Size*/ p)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(p.Width, p.Height);
            }
            static /*Size */ op_Addition(/*Size*/ sz1, /*Size*/ sz2)
            {
                return $.$sdp.System.Drawing.Size.Add(sz1.Clone(), sz2.Clone());
            }
            static /*Size */ op_Subtraction(/*Size*/ sz1, /*Size*/ sz2)
            {
                return $.$sdp.System.Drawing.Size.Subtract(sz1.Clone(), sz2.Clone());
            }
            static /*Size */ op_Multiply(/*int*/ left, /*Size*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply(right.Clone(), left);
            }
            static /*Size */ op_Multiply$1(/*Size*/ left, /*int*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply(left.Clone(), right);
            }
            static /*Size */ op_Division(/*Size*/ left, /*int*/ right)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.trunc(left.width / right), $.trunc(left.height / right));
            }
            static /*SizeF */ op_Multiply$2(/*float*/ left, /*Size*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply$1(right.Clone(), left);
            }
            static /*SizeF */ op_Multiply$3(/*Size*/ left, /*float*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply$1(left.Clone(), right);
            }
            static /*SizeF */ op_Division$1(/*Size*/ left, /*float*/ right)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(left.width / right, left.height / right);
            }
            static /*bool */ op_Equality(/*Size*/ sz1, /*Size*/ sz2)
            {
                return sz1.Width === sz2.Width && sz1.Height === sz2.Height;
            }
            static /*bool */ op_Inequality(/*Size*/ sz1, /*Size*/ sz2)
            {
                return !($.$sdp.System.Drawing.Size.op_Equality(sz1, sz2));
            }
            static /*Point */ op_Explicit(/*Size*/ size)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(size.Width, size.Height);
            }
            /*bool */ get IsEmpty()
            {
                return this.width === 0 && this.height === 0;
            }
            /*int */ get Width()
            {
                return this.width;
            }
            /*int */ set Width(value)
            {
                this.width = value;
            }
            /*int */ get Height()
            {
                return this.height;
            }
            /*int */ set Height(value)
            {
                this.height = value;
            }
            static /*Size */ Add(/*Size*/ sz1, /*Size*/ sz2)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((sz1.Width + sz2.Width) | 0), ((sz1.Height + sz2.Height) | 0));
            }
            static /*Size */ Ceiling(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast(Math.ceil(value.Width), $.$spc.System.Int32), $.$cast(Math.ceil(value.Height), $.$spc.System.Int32));
            }
            static /*Size */ Subtract(/*Size*/ sz1, /*Size*/ sz2)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((sz1.Width - sz2.Width) | 0), ((sz1.Height - sz2.Height) | 0));
            }
            static /*Size */ Truncate(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast(value.Width, $.$spc.System.Int32), $.$cast(value.Height, $.$spc.System.Int32));
            }
            static /*Size */ Round(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast($.$spc.System.Math.Round$4(value.Width), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Height), $.$spc.System.Int32));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Size) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Size));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Size.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Size*/ other)
            {
                return $.$sdp.System.Drawing.Size.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Int32, $.$spc.System.Int32, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Size.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{Width=${this.width}, Height=${this.height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Size.ToString.apply(this, arguments); }
            static /*Size */ Multiply(/*Size*/ size, /*int*/ multiplier)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((size.width * multiplier) | 0), ((size.height * multiplier) | 0));
            }
            static /*SizeF */ Multiply$1(/*Size*/ size, /*float*/ multiplier)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(size.width * multiplier, size.height * multiplier);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Size>.Equals(System.Drawing.Size)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Size);
                }
            }
            static $h = 849874;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":81605228498,"f":1},"n":"IsEmpty","d":849874,"h":77310261202,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":90195163090,"f":1},"s":{"r":0,"d":0,"h":94490130386,"f":1},"n":"Width","d":849874,"h":85900195794,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103080064978,"f":1},"s":{"r":0,"d":0,"h":107375032274,"f":1},"n":"Height","d":849874,"h":98785097682,"f":1}],"m":[{"r":849874,"p":[{"n":"sz1","p":849874},{"n":"sz2","p":849874}],"n":"Add","d":849874,"h":111669999570,"f":33},{"r":849874,"p":[{"n":"value","p":915410}],"n":"Ceiling","d":849874,"h":115964966866,"f":33},{"r":849874,"p":[{"n":"sz1","p":849874},{"n":"sz2","p":849874}],"n":"Subtract","d":849874,"h":120259934162,"f":33},{"r":849874,"p":[{"n":"value","p":915410}],"n":"Truncate","d":849874,"h":124554901458,"f":33},{"r":849874,"p":[{"n":"value","p":915410}],"n":"Round","d":849874,"h":128849868754,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":849874,"h":133144836050,"f":32769},{"r":262145,"p":[{"n":"other","p":849874}],"n":"Equals","o":"@$2","d":849874,"h":137439803346,"f":1},{"r":655361,"n":"GetHashCode","d":849874,"h":141734770642,"f":32769},{"r":1310721,"n":"ToString","d":849874,"h":146029737938,"f":32769},{"r":849874,"p":[{"n":"size","p":849874},{"n":"multiplier","p":655361}],"n":"Multiply","d":849874,"h":150324705234,"f":34},{"r":915410,"p":[{"n":"size","p":849874},{"n":"multiplier","p":1114113}],"n":"Multiply","o":"@$1","d":849874,"h":154619672530,"f":34}],"l":[{"t":849874,"n":"Empty","d":849874,"h":4295817170,"f":33},{"t":655361,"n":"width","d":849874,"h":8590784466,"f":2},{"t":655361,"n":"height","d":849874,"h":12885751762,"f":2}],"c":[{"p":[{"n":"pt","p":587730}],"n":".ctor","o":"$ctor$2","d":849874,"h":17180719058,"f":1},{"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":".ctor","o":"$ctor$3","d":849874,"h":21475686354,"f":1},{"n":".ctor","o":"$ctor$4","d":849874,"h":158914639826,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Size).$h],"h":849874,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1481253,"c":17181350437,"a":[{"v":"System.Drawing.SizeConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Size) ]; }
            static get $fullName() { return `System.Drawing.Size`; }
        });
        
        $asm.$str("$sdp.System.Drawing.SizeF", ($self) => class SizeF extends $.$spc.System.ValueType
        {
            /*SizeF*/ static Empty;
            /*float*/  get width() { return this.$getField(0, $.$spc.System.Single); }
            /*float*/  set width(value) { this.$setField(0, $.$spc.System.Single, value); }
            /*float*/  get height() { return this.$getField(4, $.$spc.System.Single); }
            /*float*/  set height(value) { this.$setField(4, $.$spc.System.Single, value); }
            $ctor$2(/*SizeF*/ size)
            {
                super.$ctor$1();
                {
                    this.width = size.width;
                    this.height = size.height;
                }
                return this;
            }
            $ctor$3(/*PointF*/ pt)
            {
                super.$ctor$1();
                {
                    this.width = pt.X;
                    this.height = pt.Y;
                }
                return this;
            }
            $ctor$4(/*Vector2*/ vector)
            {
                super.$ctor$1();
                {
                    this.width = vector.X;
                    this.height = vector.Y;
                }
                return this;
            }
            /*Vector2 */ ToVector2()
            {
                return new $.$spc.System.Numerics.Vector2().$ctor$3(this.width, this.height);
            }
            $ctor$5(/*float*/ width, /*float*/ height)
            {
                super.$ctor$1();
                {
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            static /*Vector2 */ op_Explicit(/*SizeF*/ size)
            {
                return size.ToVector2();
            }
            static /*SizeF */ op_Explicit$1(/*Vector2*/ vector)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$4(vector.Clone());
            }
            static /*SizeF */ op_Addition(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return $.$sdp.System.Drawing.SizeF.Add(sz1.Clone(), sz2.Clone());
            }
            static /*SizeF */ op_Subtraction(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return $.$sdp.System.Drawing.SizeF.Subtract(sz1.Clone(), sz2.Clone());
            }
            static /*SizeF */ op_Multiply(/*float*/ left, /*SizeF*/ right)
            {
                return $.$sdp.System.Drawing.SizeF.Multiply(right.Clone(), left);
            }
            static /*SizeF */ op_Multiply$1(/*SizeF*/ left, /*float*/ right)
            {
                return $.$sdp.System.Drawing.SizeF.Multiply(left.Clone(), right);
            }
            static /*SizeF */ op_Division(/*SizeF*/ left, /*float*/ right)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(left.width / right, left.height / right);
            }
            static /*bool */ op_Equality(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return sz1.Width === sz2.Width && sz1.Height === sz2.Height;
            }
            static /*bool */ op_Inequality(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return !($.$sdp.System.Drawing.SizeF.op_Equality(sz1, sz2));
            }
            static /*PointF */ op_Explicit$2(/*SizeF*/ size)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(size.Width, size.Height);
            }
            /*bool */ get IsEmpty()
            {
                return this.width === 0 && this.height === 0;
            }
            /*float */ get Width()
            {
                return this.width;
            }
            /*float */ set Width(value)
            {
                this.width = value;
            }
            /*float */ get Height()
            {
                return this.height;
            }
            /*float */ set Height(value)
            {
                this.height = value;
            }
            static /*SizeF */ Add(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(sz1.Width + sz2.Width, sz1.Height + sz2.Height);
            }
            static /*SizeF */ Subtract(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(sz1.Width - sz2.Width, sz1.Height - sz2.Height);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.SizeF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.SizeF));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.SizeF.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*SizeF*/ other)
            {
                return $.$sdp.System.Drawing.SizeF.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Single, $.$spc.System.Single, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.SizeF.GetHashCode.apply(this, arguments); }
            /*PointF */ ToPointF()
            {
                return $.$sdp.System.Drawing.SizeF.op_Explicit$2(this);
            }
            /*Size */ ToSize()
            {
                return $.$sdp.System.Drawing.Size.Truncate(this);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{Width=${this.width}, Height=${this.height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.SizeF.ToString.apply(this, arguments); }
            static /*SizeF */ Multiply(/*SizeF*/ size, /*float*/ multiplier)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(size.width * multiplier, size.height * multiplier);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.SizeF>.Equals(System.Drawing.SizeF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$6()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.SizeF);
                }
            }
            static $h = 915410;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":85900261330,"f":1},"n":"IsEmpty","d":915410,"h":81605294034,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":94490195922,"f":1},"s":{"r":0,"d":0,"h":98785163218,"f":1},"n":"Width","d":915410,"h":90195228626,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":107375097810,"f":1},"s":{"r":0,"d":0,"h":111670065106,"f":1},"n":"Height","d":915410,"h":103080130514,"f":1}],"m":[{"r":70582273,"n":"ToVector2","d":915410,"h":30065686482,"f":1},{"r":915410,"p":[{"n":"sz1","p":915410},{"n":"sz2","p":915410}],"n":"Add","d":915410,"h":115965032402,"f":33},{"r":915410,"p":[{"n":"sz1","p":915410},{"n":"sz2","p":915410}],"n":"Subtract","d":915410,"h":120259999698,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":915410,"h":124554966994,"f":32769},{"r":262145,"p":[{"n":"other","p":915410}],"n":"Equals","o":"@$2","d":915410,"h":128849934290,"f":1},{"r":655361,"n":"GetHashCode","d":915410,"h":133144901586,"f":32769},{"r":653266,"n":"ToPointF","d":915410,"h":137439868882,"f":1},{"r":849874,"n":"ToSize","d":915410,"h":141734836178,"f":1},{"r":1310721,"n":"ToString","d":915410,"h":146029803474,"f":32769},{"r":915410,"p":[{"n":"size","p":915410},{"n":"multiplier","p":1114113}],"n":"Multiply","d":915410,"h":150324770770,"f":34}],"l":[{"t":915410,"n":"Empty","d":915410,"h":4295882706,"f":33},{"t":1114113,"n":"width","d":915410,"h":8590850002,"f":2},{"t":1114113,"n":"height","d":915410,"h":12885817298,"f":2}],"c":[{"p":[{"n":"size","p":915410}],"n":".ctor","o":"$ctor$2","d":915410,"h":17180784594,"f":1},{"p":[{"n":"pt","p":653266}],"n":".ctor","o":"$ctor$3","d":915410,"h":21475751890,"f":1},{"p":[{"n":"vector","p":70582273}],"n":".ctor","o":"$ctor$4","d":915410,"h":25770719186,"f":1},{"p":[{"n":"width","p":1114113},{"n":"height","p":1114113}],"n":".ctor","o":"$ctor$5","d":915410,"h":34360653778,"f":1},{"n":".ctor","o":"$ctor$6","d":915410,"h":154619738066,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.SizeF).$h],"h":915410,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1481253,"c":17181350437,"a":[{"v":"System.Drawing.SizeFConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.SizeF) ]; }
            static get $fullName() { return `System.Drawing.SizeF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Color", ($self) => class Color extends $.$spc.System.ValueType
        {
            /*Color*/ static Empty;
            static /*Color */ get Transparent()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(27/*KnownColor.Transparent*/);
            }
            static /*Color */ get AliceBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(28/*KnownColor.AliceBlue*/);
            }
            static /*Color */ get AntiqueWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(29/*KnownColor.AntiqueWhite*/);
            }
            static /*Color */ get Aqua()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(30/*KnownColor.Aqua*/);
            }
            static /*Color */ get Aquamarine()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(31/*KnownColor.Aquamarine*/);
            }
            static /*Color */ get Azure()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(32/*KnownColor.Azure*/);
            }
            static /*Color */ get Beige()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(33/*KnownColor.Beige*/);
            }
            static /*Color */ get Bisque()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(34/*KnownColor.Bisque*/);
            }
            static /*Color */ get Black()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(35/*KnownColor.Black*/);
            }
            static /*Color */ get BlanchedAlmond()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(36/*KnownColor.BlanchedAlmond*/);
            }
            static /*Color */ get Blue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(37/*KnownColor.Blue*/);
            }
            static /*Color */ get BlueViolet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(38/*KnownColor.BlueViolet*/);
            }
            static /*Color */ get Brown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(39/*KnownColor.Brown*/);
            }
            static /*Color */ get BurlyWood()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(40/*KnownColor.BurlyWood*/);
            }
            static /*Color */ get CadetBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(41/*KnownColor.CadetBlue*/);
            }
            static /*Color */ get Chartreuse()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(42/*KnownColor.Chartreuse*/);
            }
            static /*Color */ get Chocolate()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(43/*KnownColor.Chocolate*/);
            }
            static /*Color */ get Coral()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(44/*KnownColor.Coral*/);
            }
            static /*Color */ get CornflowerBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(45/*KnownColor.CornflowerBlue*/);
            }
            static /*Color */ get Cornsilk()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(46/*KnownColor.Cornsilk*/);
            }
            static /*Color */ get Crimson()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(47/*KnownColor.Crimson*/);
            }
            static /*Color */ get Cyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(48/*KnownColor.Cyan*/);
            }
            static /*Color */ get DarkBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(49/*KnownColor.DarkBlue*/);
            }
            static /*Color */ get DarkCyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(50/*KnownColor.DarkCyan*/);
            }
            static /*Color */ get DarkGoldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(51/*KnownColor.DarkGoldenrod*/);
            }
            static /*Color */ get DarkGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(52/*KnownColor.DarkGray*/);
            }
            static /*Color */ get DarkGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(53/*KnownColor.DarkGreen*/);
            }
            static /*Color */ get DarkKhaki()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(54/*KnownColor.DarkKhaki*/);
            }
            static /*Color */ get DarkMagenta()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(55/*KnownColor.DarkMagenta*/);
            }
            static /*Color */ get DarkOliveGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(56/*KnownColor.DarkOliveGreen*/);
            }
            static /*Color */ get DarkOrange()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(57/*KnownColor.DarkOrange*/);
            }
            static /*Color */ get DarkOrchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(58/*KnownColor.DarkOrchid*/);
            }
            static /*Color */ get DarkRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(59/*KnownColor.DarkRed*/);
            }
            static /*Color */ get DarkSalmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(60/*KnownColor.DarkSalmon*/);
            }
            static /*Color */ get DarkSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(61/*KnownColor.DarkSeaGreen*/);
            }
            static /*Color */ get DarkSlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(62/*KnownColor.DarkSlateBlue*/);
            }
            static /*Color */ get DarkSlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(63/*KnownColor.DarkSlateGray*/);
            }
            static /*Color */ get DarkTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(64/*KnownColor.DarkTurquoise*/);
            }
            static /*Color */ get DarkViolet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(65/*KnownColor.DarkViolet*/);
            }
            static /*Color */ get DeepPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(66/*KnownColor.DeepPink*/);
            }
            static /*Color */ get DeepSkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(67/*KnownColor.DeepSkyBlue*/);
            }
            static /*Color */ get DimGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(68/*KnownColor.DimGray*/);
            }
            static /*Color */ get DodgerBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(69/*KnownColor.DodgerBlue*/);
            }
            static /*Color */ get Firebrick()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(70/*KnownColor.Firebrick*/);
            }
            static /*Color */ get FloralWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(71/*KnownColor.FloralWhite*/);
            }
            static /*Color */ get ForestGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(72/*KnownColor.ForestGreen*/);
            }
            static /*Color */ get Fuchsia()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(73/*KnownColor.Fuchsia*/);
            }
            static /*Color */ get Gainsboro()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(74/*KnownColor.Gainsboro*/);
            }
            static /*Color */ get GhostWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(75/*KnownColor.GhostWhite*/);
            }
            static /*Color */ get Gold()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(76/*KnownColor.Gold*/);
            }
            static /*Color */ get Goldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(77/*KnownColor.Goldenrod*/);
            }
            static /*Color */ get Gray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(78/*KnownColor.Gray*/);
            }
            static /*Color */ get Green()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(79/*KnownColor.Green*/);
            }
            static /*Color */ get GreenYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(80/*KnownColor.GreenYellow*/);
            }
            static /*Color */ get Honeydew()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(81/*KnownColor.Honeydew*/);
            }
            static /*Color */ get HotPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(82/*KnownColor.HotPink*/);
            }
            static /*Color */ get IndianRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(83/*KnownColor.IndianRed*/);
            }
            static /*Color */ get Indigo()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(84/*KnownColor.Indigo*/);
            }
            static /*Color */ get Ivory()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(85/*KnownColor.Ivory*/);
            }
            static /*Color */ get Khaki()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(86/*KnownColor.Khaki*/);
            }
            static /*Color */ get Lavender()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(87/*KnownColor.Lavender*/);
            }
            static /*Color */ get LavenderBlush()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(88/*KnownColor.LavenderBlush*/);
            }
            static /*Color */ get LawnGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(89/*KnownColor.LawnGreen*/);
            }
            static /*Color */ get LemonChiffon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(90/*KnownColor.LemonChiffon*/);
            }
            static /*Color */ get LightBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(91/*KnownColor.LightBlue*/);
            }
            static /*Color */ get LightCoral()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(92/*KnownColor.LightCoral*/);
            }
            static /*Color */ get LightCyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(93/*KnownColor.LightCyan*/);
            }
            static /*Color */ get LightGoldenrodYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(94/*KnownColor.LightGoldenrodYellow*/);
            }
            static /*Color */ get LightGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(96/*KnownColor.LightGreen*/);
            }
            static /*Color */ get LightGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(95/*KnownColor.LightGray*/);
            }
            static /*Color */ get LightPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(97/*KnownColor.LightPink*/);
            }
            static /*Color */ get LightSalmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(98/*KnownColor.LightSalmon*/);
            }
            static /*Color */ get LightSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(99/*KnownColor.LightSeaGreen*/);
            }
            static /*Color */ get LightSkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(100/*KnownColor.LightSkyBlue*/);
            }
            static /*Color */ get LightSlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(101/*KnownColor.LightSlateGray*/);
            }
            static /*Color */ get LightSteelBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(102/*KnownColor.LightSteelBlue*/);
            }
            static /*Color */ get LightYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(103/*KnownColor.LightYellow*/);
            }
            static /*Color */ get Lime()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(104/*KnownColor.Lime*/);
            }
            static /*Color */ get LimeGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(105/*KnownColor.LimeGreen*/);
            }
            static /*Color */ get Linen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(106/*KnownColor.Linen*/);
            }
            static /*Color */ get Magenta()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(107/*KnownColor.Magenta*/);
            }
            static /*Color */ get Maroon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(108/*KnownColor.Maroon*/);
            }
            static /*Color */ get MediumAquamarine()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(109/*KnownColor.MediumAquamarine*/);
            }
            static /*Color */ get MediumBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(110/*KnownColor.MediumBlue*/);
            }
            static /*Color */ get MediumOrchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(111/*KnownColor.MediumOrchid*/);
            }
            static /*Color */ get MediumPurple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(112/*KnownColor.MediumPurple*/);
            }
            static /*Color */ get MediumSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(113/*KnownColor.MediumSeaGreen*/);
            }
            static /*Color */ get MediumSlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(114/*KnownColor.MediumSlateBlue*/);
            }
            static /*Color */ get MediumSpringGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(115/*KnownColor.MediumSpringGreen*/);
            }
            static /*Color */ get MediumTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(116/*KnownColor.MediumTurquoise*/);
            }
            static /*Color */ get MediumVioletRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(117/*KnownColor.MediumVioletRed*/);
            }
            static /*Color */ get MidnightBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(118/*KnownColor.MidnightBlue*/);
            }
            static /*Color */ get MintCream()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(119/*KnownColor.MintCream*/);
            }
            static /*Color */ get MistyRose()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(120/*KnownColor.MistyRose*/);
            }
            static /*Color */ get Moccasin()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(121/*KnownColor.Moccasin*/);
            }
            static /*Color */ get NavajoWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(122/*KnownColor.NavajoWhite*/);
            }
            static /*Color */ get Navy()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(123/*KnownColor.Navy*/);
            }
            static /*Color */ get OldLace()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(124/*KnownColor.OldLace*/);
            }
            static /*Color */ get Olive()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(125/*KnownColor.Olive*/);
            }
            static /*Color */ get OliveDrab()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(126/*KnownColor.OliveDrab*/);
            }
            static /*Color */ get Orange()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(127/*KnownColor.Orange*/);
            }
            static /*Color */ get OrangeRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(128/*KnownColor.OrangeRed*/);
            }
            static /*Color */ get Orchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(129/*KnownColor.Orchid*/);
            }
            static /*Color */ get PaleGoldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(130/*KnownColor.PaleGoldenrod*/);
            }
            static /*Color */ get PaleGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(131/*KnownColor.PaleGreen*/);
            }
            static /*Color */ get PaleTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(132/*KnownColor.PaleTurquoise*/);
            }
            static /*Color */ get PaleVioletRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(133/*KnownColor.PaleVioletRed*/);
            }
            static /*Color */ get PapayaWhip()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(134/*KnownColor.PapayaWhip*/);
            }
            static /*Color */ get PeachPuff()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(135/*KnownColor.PeachPuff*/);
            }
            static /*Color */ get Peru()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(136/*KnownColor.Peru*/);
            }
            static /*Color */ get Pink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(137/*KnownColor.Pink*/);
            }
            static /*Color */ get Plum()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(138/*KnownColor.Plum*/);
            }
            static /*Color */ get PowderBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(139/*KnownColor.PowderBlue*/);
            }
            static /*Color */ get Purple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(140/*KnownColor.Purple*/);
            }
            static /*Color */ get RebeccaPurple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(175/*KnownColor.RebeccaPurple*/);
            }
            static /*Color */ get Red()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(141/*KnownColor.Red*/);
            }
            static /*Color */ get RosyBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(142/*KnownColor.RosyBrown*/);
            }
            static /*Color */ get RoyalBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(143/*KnownColor.RoyalBlue*/);
            }
            static /*Color */ get SaddleBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(144/*KnownColor.SaddleBrown*/);
            }
            static /*Color */ get Salmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(145/*KnownColor.Salmon*/);
            }
            static /*Color */ get SandyBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(146/*KnownColor.SandyBrown*/);
            }
            static /*Color */ get SeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(147/*KnownColor.SeaGreen*/);
            }
            static /*Color */ get SeaShell()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(148/*KnownColor.SeaShell*/);
            }
            static /*Color */ get Sienna()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(149/*KnownColor.Sienna*/);
            }
            static /*Color */ get Silver()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(150/*KnownColor.Silver*/);
            }
            static /*Color */ get SkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(151/*KnownColor.SkyBlue*/);
            }
            static /*Color */ get SlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(152/*KnownColor.SlateBlue*/);
            }
            static /*Color */ get SlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(153/*KnownColor.SlateGray*/);
            }
            static /*Color */ get Snow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(154/*KnownColor.Snow*/);
            }
            static /*Color */ get SpringGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(155/*KnownColor.SpringGreen*/);
            }
            static /*Color */ get SteelBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(156/*KnownColor.SteelBlue*/);
            }
            static /*Color */ get Tan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(157/*KnownColor.Tan*/);
            }
            static /*Color */ get Teal()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(158/*KnownColor.Teal*/);
            }
            static /*Color */ get Thistle()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(159/*KnownColor.Thistle*/);
            }
            static /*Color */ get Tomato()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(160/*KnownColor.Tomato*/);
            }
            static /*Color */ get Turquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(161/*KnownColor.Turquoise*/);
            }
            static /*Color */ get Violet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(162/*KnownColor.Violet*/);
            }
            static /*Color */ get Wheat()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(163/*KnownColor.Wheat*/);
            }
            static /*Color */ get White()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(164/*KnownColor.White*/);
            }
            static /*Color */ get WhiteSmoke()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(165/*KnownColor.WhiteSmoke*/);
            }
            static /*Color */ get Yellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(166/*KnownColor.Yellow*/);
            }
            static /*Color */ get YellowGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(167/*KnownColor.YellowGreen*/);
            }
            /*short*/ static StateKnownColorValid = 1;
            /*short*/ static StateARGBValueValid = 2;
            /*short*/ static StateValueMask = 2;
            /*short*/ static StateNameValid = 8;
            /*long*/ static NotDefinedValue = 0n;
            /*int*/ static ARGBAlphaShift = 24;
            /*int*/ static ARGBRedShift = 16;
            /*int*/ static ARGBGreenShift = 8;
            /*int*/ static ARGBBlueShift = 0;
            /*uint*/ static ARGBAlphaMask = 4278190080;
            /*uint*/ static ARGBRedMask = 16711680;
            /*uint*/ static ARGBGreenMask = 65280;
            /*uint*/ static ARGBBlueMask = 255;
            /*string?*/  get name() { return this.$getField(0, 4); }
            /*string?*/  set name(value) { this.$setField(0, 4, value); }
            /*long*/  get value() { return this.$getField(4, 8); }
            /*long*/  set value(value) { this.$setField(4, 8, value); }
            /*short*/  get knownColor() { return this.$getField(12, 2); }
            /*short*/  set knownColor(value) { this.$setField(12, 2, value); }
            /*short*/  get state() { return this.$getField(14, 2); }
            /*short*/  set state(value) { this.$setField(14, 2, value); }
            $ctor$2(/*KnownColor*/ knownColor)
            {
                super.$ctor$1();
                {
                    this.value = 0n;
                    this.state = 1/*StateKnownColorValid*/;
                    this.name = null;
                    this.knownColor = $.$cast(knownColor, $.$spc.System.Int16);
                }
                return this;
            }
            $ctor$3(/*long*/ value, /*short*/ state, /*string?*/ name, /*KnownColor*/ knownColor)
            {
                super.$ctor$1();
                {
                    this.value = value;
                    this.state = state;
                    this.name = name;
                    this.knownColor = $.$cast(knownColor, $.$spc.System.Int16);
                }
                return this;
            }
            /*byte */ get R()
            {
                return $.$cast((this.Value >> BigInt(16/*ARGBRedShift*/)), $.$spc.System.Byte);
            }
            /*byte */ get G()
            {
                return $.$cast((this.Value >> BigInt(8/*ARGBGreenShift*/)), $.$spc.System.Byte);
            }
            /*byte */ get B()
            {
                return $.$cast((this.Value >> BigInt(0/*ARGBBlueShift*/)), $.$spc.System.Byte);
            }
            /*byte */ get A()
            {
                return $.$cast((this.Value >> BigInt(24/*ARGBAlphaShift*/)), $.$spc.System.Byte);
            }
            /*bool */ get IsKnownColor()
            {
                return (this.state & 1/*StateKnownColorValid*/) !== 0;
            }
            /*bool */ get IsEmpty()
            {
                return this.state === 0;
            }
            /*bool */ get IsNamedColor()
            {
                return ((this.state & 8/*StateNameValid*/) !== 0) || this.IsKnownColor;
            }
            /*bool */ get IsSystemColor()
            {
                return this.IsKnownColor && $.$sdp.System.Drawing.Color.IsKnownColorSystem($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor));
            }
            static /*bool */ IsKnownColorSystem(/*KnownColor*/ knownColor)
            {
                return $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(knownColor).$v === 0/*KnownColorTable.KnownColorKindSystem*/;
            }
            /*string */ get NameAndARGBValue()
            {
                return `{{Name = ${this.Name}, ARGB = (${this.A}, ${this.R}, ${this.G}, ${this.B})}}`;
            }
            /*string */ get Name()
            {
                if ((this.state & 8/*StateNameValid*/) !== 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(this.name, null), "name != null");
                    return this.name;
                }
                if (this.IsKnownColor)
                {
                    /*string*/ let tablename = $.$sdp.System.Drawing.KnownColorNames.KnownColorToName($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor));
                    $.$spc.System.Diagnostics.Debug.Assert$2($.$spc.System.String.op_Inequality(tablename, null), `Could not find known color '${$.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor)}' in the KnownColorTable`);
                    return tablename;
                }
                return $.$spc.System.Int64.ToString$2.call(this.value, "x");
            }
            /*long */ get Value()
            {
                if ((this.state & 2/*StateValueMask*/) !== 0)
                {
                    return this.value;
                }
                if (this.IsKnownColor)
                {
                    return BigInt($.$sdp.System.Drawing.KnownColorTable.KnownColorToArgb($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor)));
                }
                return 0n;
            }
            static /*void */ CheckByte(/*int*/ value, /*string*/ name)
            {
                /*static void*/  function ThrowOutOfByteRange(/*int*/ v, /*string*/ n)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sdp.System.SR.Format$3($.$sdp.System.SR.InvalidEx2BoundArgument, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ n, $.$box(v, $.$spc.System.Int32), $.$box(0/*byte.MinValue*/, $.$spc.System.Byte), $.$box(255/*byte.MaxValue*/, $.$spc.System.Byte) ], null, null)));
                }
                if ((value >>> 0) > 255/*byte.MaxValue*/)
                {
                    ThrowOutOfByteRange(value, name);
                }
            }
            static /*Color */ FromArgb(/*uint*/ argb)
            {
                return new $.$sdp.System.Drawing.Color().$ctor$3(BigInt(argb), 2/*StateARGBValueValid*/, null, $.$cast(0, $.$sdp.System.Drawing.KnownColor));
            }
            static /*Color */ FromArgb$1(/*int*/ argb)
            {
                return $.$sdp.System.Drawing.Color.FromArgb((argb >>> 0));
            }
            static /*Color */ FromArgb$2(/*int*/ alpha, /*int*/ red, /*int*/ green, /*int*/ blue)
            {
                $.$sdp.System.Drawing.Color.CheckByte(alpha, "alpha");
                $.$sdp.System.Drawing.Color.CheckByte(red, "red");
                $.$sdp.System.Drawing.Color.CheckByte(green, "green");
                $.$sdp.System.Drawing.Color.CheckByte(blue, "blue");
                return $.$sdp.System.Drawing.Color.FromArgb(((alpha >>> 0) << 24/*ARGBAlphaShift*/) >>> 0 | ((red >>> 0) << 16/*ARGBRedShift*/) >>> 0 | ((green >>> 0) << 8/*ARGBGreenShift*/) >>> 0 | ((blue >>> 0) << 0/*ARGBBlueShift*/) >>> 0);
            }
            static /*Color */ FromArgb$3(/*int*/ alpha, /*Color*/ baseColor)
            {
                $.$sdp.System.Drawing.Color.CheckByte(alpha, "alpha");
                return $.$sdp.System.Drawing.Color.FromArgb(((alpha >>> 0) << 24/*ARGBAlphaShift*/) >>> 0 | $.$cast(baseColor.Value, $.$spc.System.UInt32) & ~4278190080/*ARGBAlphaMask*/);
            }
            static /*Color */ FromArgb$4(/*int*/ red, /*int*/ green, /*int*/ blue)
            {
                return $.$sdp.System.Drawing.Color.FromArgb$2(255/*byte.MaxValue*/, red, green, blue);
            }
            static /*Color */ FromKnownColor(/*KnownColor*/ color)
            {
                return color <= 0 || color > 175/*KnownColor.RebeccaPurple*/ ? $.$sdp.System.Drawing.Color.FromName($.$spc.System.Enum.ToStringT($.$sdp.System.Drawing.KnownColor, $.$spc.System.UInt32, color)) : new $.$sdp.System.Drawing.Color().$ctor$2(color);
            }
            static /*Color */ FromName(/*string*/ name)
            {
                /*Color*/ let color;
                if ($.$sdp.System.Drawing.ColorTable.TryGetNamedColor(name, $.$ref(() => color, ($v) => color = $v, $.$sdp.System.Drawing.Color)))
                {
                    return color;
                }
                return new $.$sdp.System.Drawing.Color().$ctor$3(0n, 8/*StateNameValid*/, name, $.$cast(0, $.$sdp.System.Drawing.KnownColor));
            }
            /*void */ GetRgbValues(/*out int*/ r, /*out int*/ g, /*out int*/ b)
            {
                /*uint*/ let value = $.$cast(this.Value, $.$spc.System.UInt32);
                r.$v = ((value & 16711680/*ARGBRedMask*/) | 0) >> 16/*ARGBRedShift*/;
                g.$v = ((value & 65280/*ARGBGreenMask*/) | 0) >> 8/*ARGBGreenShift*/;
                b.$v = ((value & 255/*ARGBBlueMask*/) | 0) >> 0/*ARGBBlueShift*/;
            }
            static /*void */ MinMaxRgb(/*out int*/ min, /*out int*/ max, /*int*/ r, /*int*/ g, /*int*/ b)
            {
                if (r > g)
                {
                    max.$v = r;
                    min.$v = g;
                }
                else 
                {
                    max.$v = g;
                    min.$v = r;
                }
                if (b > max.$v)
                {
                    max.$v = b;
                }
                else if (b < min.$v)
                {
                    min.$v = b;
                }
            }
            /*float */ GetBrightness()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$spc.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$spc.System.Int32), r, g, b);
                return (((max + min) | 0)) / (255/*byte.MaxValue*/ * 2);
            }
            /*float */ GetHue()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                if (r === g && g === b)
                {
                    return 0;
                }
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$spc.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$spc.System.Int32), r, g, b);
                /*float*/ let delta = ((max - min) | 0);
                /*float*/ let hue;
                if (r === max)
                {
                    hue = (((g - b) | 0)) / delta;
                }
                else if (g === max)
                {
                    hue = (((b - r) | 0)) / delta + 2;
                }
                else 
                {
                    hue = (((r - g) | 0)) / delta + 4;
                }
                hue *= 60;
                if (hue < 0)
                {
                    hue += 360;
                }
                return hue;
            }
            /*float */ GetSaturation()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                if (r === g && g === b)
                {
                    return 0;
                }
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$spc.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$spc.System.Int32), r, g, b);
                /*int*/ let div = ((max + min) | 0);
                if (div > 255/*byte.MaxValue*/)
                {
                    div = ((((((255/*byte.MaxValue*/ * 2) | 0) - max) | 0) - min) | 0);
                }
                return (((max - min) | 0)) / $.$cast(div, $.$spc.System.Single);
            }
            /*int */ ToArgb()
            {
                return $.$cast(this.Value, $.$spc.System.Int32);
            }
            /*KnownColor */ ToKnownColor()
            {
                return $.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.IsNamedColor ? `${"Color"} [${this.Name}]` : (this.state & 2/*StateValueMask*/) !== 0 ? `${"Color"} [A=${this.A}, R=${this.R}, G=${this.G}, B=${this.B}]` : `${"Color"} [Empty]`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Color.ToString.apply(this, arguments); }
            static /*bool */ op_Equality(/*Color*/ left, /*Color*/ right)
            {
                return left.value === right.value && left.state === right.state && left.knownColor === right.knownColor && $.$spc.System.String.op_Equality(left.name, right.name);
            }
            static /*bool */ op_Inequality(/*Color*/ left, /*Color*/ right)
            {
                return !($.$sdp.System.Drawing.Color.op_Equality(left, right));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$sdp.System.Drawing.Color, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Color.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Color*/ other)
            {
                return $.$sdp.System.Drawing.Color.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                if ($.$spc.System.String.op_Inequality(this.name, null) && !this.IsKnownColor)
                {
                    return $.$spc.System.String.GetHashCode.call(this.name);
                }
                return $.$spc.System.HashCode.Combine$2($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int64.GetHashCode.call(this.value), $.$spc.System.Int16.GetHashCode.call(this.state), $.$spc.System.Int16.GetHashCode.call(this.knownColor));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Color.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Color>.Equals(System.Drawing.Color)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.name = this.name;
                copy.value = this.value;
                copy.knownColor = this.knownColor;
                copy.state = this.state;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.name = null;
                this.value = 0n;
                this.knownColor = 0;
                this.state = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Color);
                }
            }
            static $h = 128978;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":128978,"g":{"r":0,"d":0,"h":12885030866,"f":33},"n":"Transparent","d":128978,"h":8590063570,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":21474965458,"f":33},"n":"AliceBlue","d":128978,"h":17179998162,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":30064900050,"f":33},"n":"AntiqueWhite","d":128978,"h":25769932754,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":38654834642,"f":33},"n":"Aqua","d":128978,"h":34359867346,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":47244769234,"f":33},"n":"Aquamarine","d":128978,"h":42949801938,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":55834703826,"f":33},"n":"Azure","d":128978,"h":51539736530,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":64424638418,"f":33},"n":"Beige","d":128978,"h":60129671122,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":73014573010,"f":33},"n":"Bisque","d":128978,"h":68719605714,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":81604507602,"f":33},"n":"Black","d":128978,"h":77309540306,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":90194442194,"f":33},"n":"BlanchedAlmond","d":128978,"h":85899474898,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":98784376786,"f":33},"n":"Blue","d":128978,"h":94489409490,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":107374311378,"f":33},"n":"BlueViolet","d":128978,"h":103079344082,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":115964245970,"f":33},"n":"Brown","d":128978,"h":111669278674,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":124554180562,"f":33},"n":"BurlyWood","d":128978,"h":120259213266,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":133144115154,"f":33},"n":"CadetBlue","d":128978,"h":128849147858,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":141734049746,"f":33},"n":"Chartreuse","d":128978,"h":137439082450,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":150323984338,"f":33},"n":"Chocolate","d":128978,"h":146029017042,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":158913918930,"f":33},"n":"Coral","d":128978,"h":154618951634,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":167503853522,"f":33},"n":"CornflowerBlue","d":128978,"h":163208886226,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":176093788114,"f":33},"n":"Cornsilk","d":128978,"h":171798820818,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":184683722706,"f":33},"n":"Crimson","d":128978,"h":180388755410,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":193273657298,"f":33},"n":"Cyan","d":128978,"h":188978690002,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":201863591890,"f":33},"n":"DarkBlue","d":128978,"h":197568624594,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":210453526482,"f":33},"n":"DarkCyan","d":128978,"h":206158559186,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":219043461074,"f":33},"n":"DarkGoldenrod","d":128978,"h":214748493778,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":227633395666,"f":33},"n":"DarkGray","d":128978,"h":223338428370,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":236223330258,"f":33},"n":"DarkGreen","d":128978,"h":231928362962,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":244813264850,"f":33},"n":"DarkKhaki","d":128978,"h":240518297554,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":253403199442,"f":33},"n":"DarkMagenta","d":128978,"h":249108232146,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":261993134034,"f":33},"n":"DarkOliveGreen","d":128978,"h":257698166738,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":270583068626,"f":33},"n":"DarkOrange","d":128978,"h":266288101330,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":279173003218,"f":33},"n":"DarkOrchid","d":128978,"h":274878035922,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":287762937810,"f":33},"n":"DarkRed","d":128978,"h":283467970514,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":296352872402,"f":33},"n":"DarkSalmon","d":128978,"h":292057905106,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":304942806994,"f":33},"n":"DarkSeaGreen","d":128978,"h":300647839698,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":313532741586,"f":33},"n":"DarkSlateBlue","d":128978,"h":309237774290,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":322122676178,"f":33},"n":"DarkSlateGray","d":128978,"h":317827708882,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":330712610770,"f":33},"n":"DarkTurquoise","d":128978,"h":326417643474,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":339302545362,"f":33},"n":"DarkViolet","d":128978,"h":335007578066,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":347892479954,"f":33},"n":"DeepPink","d":128978,"h":343597512658,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":356482414546,"f":33},"n":"DeepSkyBlue","d":128978,"h":352187447250,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":365072349138,"f":33},"n":"DimGray","d":128978,"h":360777381842,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":373662283730,"f":33},"n":"DodgerBlue","d":128978,"h":369367316434,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":382252218322,"f":33},"n":"Firebrick","d":128978,"h":377957251026,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":390842152914,"f":33},"n":"FloralWhite","d":128978,"h":386547185618,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":399432087506,"f":33},"n":"ForestGreen","d":128978,"h":395137120210,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":408022022098,"f":33},"n":"Fuchsia","d":128978,"h":403727054802,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":416611956690,"f":33},"n":"Gainsboro","d":128978,"h":412316989394,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":425201891282,"f":33},"n":"GhostWhite","d":128978,"h":420906923986,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":433791825874,"f":33},"n":"Gold","d":128978,"h":429496858578,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":442381760466,"f":33},"n":"Goldenrod","d":128978,"h":438086793170,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":450971695058,"f":33},"n":"Gray","d":128978,"h":446676727762,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":459561629650,"f":33},"n":"Green","d":128978,"h":455266662354,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":468151564242,"f":33},"n":"GreenYellow","d":128978,"h":463856596946,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":476741498834,"f":33},"n":"Honeydew","d":128978,"h":472446531538,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":485331433426,"f":33},"n":"HotPink","d":128978,"h":481036466130,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":493921368018,"f":33},"n":"IndianRed","d":128978,"h":489626400722,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":502511302610,"f":33},"n":"Indigo","d":128978,"h":498216335314,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":511101237202,"f":33},"n":"Ivory","d":128978,"h":506806269906,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":519691171794,"f":33},"n":"Khaki","d":128978,"h":515396204498,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":528281106386,"f":33},"n":"Lavender","d":128978,"h":523986139090,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":536871040978,"f":33},"n":"LavenderBlush","d":128978,"h":532576073682,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":545460975570,"f":33},"n":"LawnGreen","d":128978,"h":541166008274,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":554050910162,"f":33},"n":"LemonChiffon","d":128978,"h":549755942866,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":562640844754,"f":33},"n":"LightBlue","d":128978,"h":558345877458,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":571230779346,"f":33},"n":"LightCoral","d":128978,"h":566935812050,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":579820713938,"f":33},"n":"LightCyan","d":128978,"h":575525746642,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":588410648530,"f":33},"n":"LightGoldenrodYellow","d":128978,"h":584115681234,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":597000583122,"f":33},"n":"LightGreen","d":128978,"h":592705615826,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":605590517714,"f":33},"n":"LightGray","d":128978,"h":601295550418,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":614180452306,"f":33},"n":"LightPink","d":128978,"h":609885485010,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":622770386898,"f":33},"n":"LightSalmon","d":128978,"h":618475419602,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":631360321490,"f":33},"n":"LightSeaGreen","d":128978,"h":627065354194,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":639950256082,"f":33},"n":"LightSkyBlue","d":128978,"h":635655288786,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":648540190674,"f":33},"n":"LightSlateGray","d":128978,"h":644245223378,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":657130125266,"f":33},"n":"LightSteelBlue","d":128978,"h":652835157970,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":665720059858,"f":33},"n":"LightYellow","d":128978,"h":661425092562,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":674309994450,"f":33},"n":"Lime","d":128978,"h":670015027154,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":682899929042,"f":33},"n":"LimeGreen","d":128978,"h":678604961746,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":691489863634,"f":33},"n":"Linen","d":128978,"h":687194896338,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":700079798226,"f":33},"n":"Magenta","d":128978,"h":695784830930,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":708669732818,"f":33},"n":"Maroon","d":128978,"h":704374765522,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":717259667410,"f":33},"n":"MediumAquamarine","d":128978,"h":712964700114,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":725849602002,"f":33},"n":"MediumBlue","d":128978,"h":721554634706,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":734439536594,"f":33},"n":"MediumOrchid","d":128978,"h":730144569298,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":743029471186,"f":33},"n":"MediumPurple","d":128978,"h":738734503890,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":751619405778,"f":33},"n":"MediumSeaGreen","d":128978,"h":747324438482,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":760209340370,"f":33},"n":"MediumSlateBlue","d":128978,"h":755914373074,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":768799274962,"f":33},"n":"MediumSpringGreen","d":128978,"h":764504307666,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":777389209554,"f":33},"n":"MediumTurquoise","d":128978,"h":773094242258,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":785979144146,"f":33},"n":"MediumVioletRed","d":128978,"h":781684176850,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":794569078738,"f":33},"n":"MidnightBlue","d":128978,"h":790274111442,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":803159013330,"f":33},"n":"MintCream","d":128978,"h":798864046034,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":811748947922,"f":33},"n":"MistyRose","d":128978,"h":807453980626,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":820338882514,"f":33},"n":"Moccasin","d":128978,"h":816043915218,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":828928817106,"f":33},"n":"NavajoWhite","d":128978,"h":824633849810,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":837518751698,"f":33},"n":"Navy","d":128978,"h":833223784402,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":846108686290,"f":33},"n":"OldLace","d":128978,"h":841813718994,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":854698620882,"f":33},"n":"Olive","d":128978,"h":850403653586,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":863288555474,"f":33},"n":"OliveDrab","d":128978,"h":858993588178,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":871878490066,"f":33},"n":"Orange","d":128978,"h":867583522770,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":880468424658,"f":33},"n":"OrangeRed","d":128978,"h":876173457362,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":889058359250,"f":33},"n":"Orchid","d":128978,"h":884763391954,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":897648293842,"f":33},"n":"PaleGoldenrod","d":128978,"h":893353326546,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":906238228434,"f":33},"n":"PaleGreen","d":128978,"h":901943261138,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":914828163026,"f":33},"n":"PaleTurquoise","d":128978,"h":910533195730,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":923418097618,"f":33},"n":"PaleVioletRed","d":128978,"h":919123130322,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":932008032210,"f":33},"n":"PapayaWhip","d":128978,"h":927713064914,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":940597966802,"f":33},"n":"PeachPuff","d":128978,"h":936302999506,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":949187901394,"f":33},"n":"Peru","d":128978,"h":944892934098,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":957777835986,"f":33},"n":"Pink","d":128978,"h":953482868690,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":966367770578,"f":33},"n":"Plum","d":128978,"h":962072803282,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":974957705170,"f":33},"n":"PowderBlue","d":128978,"h":970662737874,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":983547639762,"f":33},"n":"Purple","d":128978,"h":979252672466,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":992137574354,"f":33},"n":"RebeccaPurple","d":128978,"h":987842607058,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1000727508946,"f":33},"n":"Red","d":128978,"h":996432541650,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1009317443538,"f":33},"n":"RosyBrown","d":128978,"h":1005022476242,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1017907378130,"f":33},"n":"RoyalBlue","d":128978,"h":1013612410834,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1026497312722,"f":33},"n":"SaddleBrown","d":128978,"h":1022202345426,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1035087247314,"f":33},"n":"Salmon","d":128978,"h":1030792280018,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1043677181906,"f":33},"n":"SandyBrown","d":128978,"h":1039382214610,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1052267116498,"f":33},"n":"SeaGreen","d":128978,"h":1047972149202,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1060857051090,"f":33},"n":"SeaShell","d":128978,"h":1056562083794,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1069446985682,"f":33},"n":"Sienna","d":128978,"h":1065152018386,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1078036920274,"f":33},"n":"Silver","d":128978,"h":1073741952978,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1086626854866,"f":33},"n":"SkyBlue","d":128978,"h":1082331887570,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1095216789458,"f":33},"n":"SlateBlue","d":128978,"h":1090921822162,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1103806724050,"f":33},"n":"SlateGray","d":128978,"h":1099511756754,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1112396658642,"f":33},"n":"Snow","d":128978,"h":1108101691346,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1120986593234,"f":33},"n":"SpringGreen","d":128978,"h":1116691625938,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1129576527826,"f":33},"n":"SteelBlue","d":128978,"h":1125281560530,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1138166462418,"f":33},"n":"Tan","d":128978,"h":1133871495122,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1146756397010,"f":33},"n":"Teal","d":128978,"h":1142461429714,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1155346331602,"f":33},"n":"Thistle","d":128978,"h":1151051364306,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1163936266194,"f":33},"n":"Tomato","d":128978,"h":1159641298898,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1172526200786,"f":33},"n":"Turquoise","d":128978,"h":1168231233490,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1181116135378,"f":33},"n":"Violet","d":128978,"h":1176821168082,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1189706069970,"f":33},"n":"Wheat","d":128978,"h":1185411102674,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1198296004562,"f":33},"n":"White","d":128978,"h":1194001037266,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1206885939154,"f":33},"n":"WhiteSmoke","d":128978,"h":1202590971858,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1215475873746,"f":33},"n":"Yellow","d":128978,"h":1211180906450,"f":33},{"p":128978,"g":{"r":0,"d":0,"h":1224065808338,"f":33},"n":"YellowGreen","d":128978,"h":1219770841042,"f":33},{"p":393217,"g":{"r":0,"d":0,"h":1314260121554,"f":1},"n":"R","d":128978,"h":1309965154258,"f":1},{"p":393217,"g":{"r":0,"d":0,"h":1322850056146,"f":1},"n":"G","d":128978,"h":1318555088850,"f":1},{"p":393217,"g":{"r":0,"d":0,"h":1331439990738,"f":1},"n":"B","d":128978,"h":1327145023442,"f":1},{"p":393217,"g":{"r":0,"d":0,"h":1340029925330,"f":1},"n":"A","d":128978,"h":1335734958034,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1348619859922,"f":1},"n":"IsKnownColor","d":128978,"h":1344324892626,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1357209794514,"f":1},"n":"IsEmpty","d":128978,"h":1352914827218,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1365799729106,"f":1},"n":"IsNamedColor","d":128978,"h":1361504761810,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1374389663698,"f":1},"n":"IsSystemColor","d":128978,"h":1370094696402,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":1387274565586,"f":2},"n":"NameAndARGBValue","d":128978,"h":1382979598290,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":1395864500178,"f":1},"n":"Name","d":128978,"h":1391569532882,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":1404454434770,"f":2},"n":"Value","d":128978,"h":1400159467474,"f":2}],"m":[{"r":262145,"p":[{"n":"knownColor","p":391122}],"n":"IsKnownColorSystem","d":128978,"h":1378684630994,"f":40},{"r":65537,"p":[{"n":"value","p":655361},{"n":"name","p":1310721}],"n":"CheckByte","d":128978,"h":1408749402066,"f":34},{"r":128978,"p":[{"n":"argb","p":720897}],"n":"FromArgb","d":128978,"h":1413044369362,"f":34},{"r":128978,"p":[{"n":"argb","p":655361}],"n":"FromArgb","o":"@$1","d":128978,"h":1417339336658,"f":33},{"r":128978,"p":[{"n":"alpha","p":655361},{"n":"red","p":655361},{"n":"green","p":655361},{"n":"blue","p":655361}],"n":"FromArgb","o":"@$2","d":128978,"h":1421634303954,"f":33},{"r":128978,"p":[{"n":"alpha","p":655361},{"n":"baseColor","p":128978}],"n":"FromArgb","o":"@$3","d":128978,"h":1425929271250,"f":33},{"r":128978,"p":[{"n":"red","p":655361},{"n":"green","p":655361},{"n":"blue","p":655361}],"n":"FromArgb","o":"@$4","d":128978,"h":1430224238546,"f":33},{"r":128978,"p":[{"n":"color","p":391122}],"n":"FromKnownColor","d":128978,"h":1434519205842,"f":33},{"r":128978,"p":[{"n":"name","p":1310721}],"n":"FromName","d":128978,"h":1438814173138,"f":33},{"r":65537,"p":[{"n":"r","p":655361,"f":2},{"n":"g","p":655361,"f":2},{"n":"b","p":655361,"f":2}],"n":"GetRgbValues","d":128978,"h":1443109140434,"f":8},{"r":65537,"p":[{"n":"min","p":655361,"f":2},{"n":"max","p":655361,"f":2},{"n":"r","p":655361},{"n":"g","p":655361},{"n":"b","p":655361}],"n":"MinMaxRgb","d":128978,"h":1447404107730,"f":34},{"r":1114113,"n":"GetBrightness","d":128978,"h":1451699075026,"f":1},{"r":1114113,"n":"GetHue","d":128978,"h":1455994042322,"f":1},{"r":1114113,"n":"GetSaturation","d":128978,"h":1460289009618,"f":1},{"r":655361,"n":"ToArgb","d":128978,"h":1464583976914,"f":1},{"r":391122,"n":"ToKnownColor","d":128978,"h":1468878944210,"f":1},{"r":1310721,"n":"ToString","d":128978,"h":1473173911506,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":128978,"h":1486058813394,"f":32769},{"r":262145,"p":[{"n":"other","p":128978}],"n":"Equals","o":"@$2","d":128978,"h":1490353780690,"f":1},{"r":655361,"n":"GetHashCode","d":128978,"h":1494648747986,"f":32769}],"l":[{"t":128978,"n":"Empty","d":128978,"h":4295096274,"f":33},{"t":524289,"n":"StateKnownColorValid","d":128978,"h":1228360775634,"f":34},{"t":524289,"n":"StateARGBValueValid","d":128978,"h":1232655742930,"f":34},{"t":524289,"n":"StateValueMask","d":128978,"h":1236950710226,"f":34},{"t":524289,"n":"StateNameValid","d":128978,"h":1241245677522,"f":34},{"t":917505,"n":"NotDefinedValue","d":128978,"h":1245540644818,"f":34},{"t":655361,"n":"ARGBAlphaShift","d":128978,"h":1249835612114,"f":40},{"t":655361,"n":"ARGBRedShift","d":128978,"h":1254130579410,"f":40},{"t":655361,"n":"ARGBGreenShift","d":128978,"h":1258425546706,"f":40},{"t":655361,"n":"ARGBBlueShift","d":128978,"h":1262720514002,"f":40},{"t":720897,"n":"ARGBAlphaMask","d":128978,"h":1267015481298,"f":40},{"t":720897,"n":"ARGBRedMask","d":128978,"h":1271310448594,"f":40},{"t":720897,"n":"ARGBGreenMask","d":128978,"h":1275605415890,"f":40},{"t":720897,"n":"ARGBBlueMask","d":128978,"h":1279900383186,"f":40},{"t":1310721,"n":"name","d":128978,"h":1284195350482,"f":2},{"t":917505,"n":"value","d":128978,"h":1288490317778,"f":2},{"t":524289,"n":"knownColor","d":128978,"h":1292785285074,"f":2},{"t":524289,"n":"state","d":128978,"h":1297080252370,"f":2}],"c":[{"p":[{"n":"knownColor","p":391122}],"n":".ctor","o":"$ctor$2","d":128978,"h":1301375219666,"f":8},{"p":[{"n":"value","p":917505},{"n":"state","p":524289},{"n":"name","p":1310721},{"n":"knownColor","p":391122}],"n":".ctor","o":"$ctor$3","d":128978,"h":1305670186962,"f":2},{"n":".ctor","o":"$ctor$4","d":128978,"h":1498943715282,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Color).$h],"h":128978,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{NameAndARGBValue}","t":1310721}]},{"t":852007,"c":12885753895,"a":[{"v":"System.Drawing.Design.ColorEditor, System.Drawing.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":118226945,"c":4413194241},{"t":1481253,"c":17181350437,"a":[{"v":"System.Drawing.ColorConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Color) ]; }
            static get $fullName() { return `System.Drawing.Color`; }
        });
        
        $asm.$str("$sdp.System.Drawing.KnownColor", ($self) => class KnownColor extends $.$spc.System.Enum
        {
            static ActiveBorder = 1;
            static ActiveCaption = 2;
            static ActiveCaptionText = 3;
            static AppWorkspace = 4;
            static Control = 5;
            static ControlDark = 6;
            static ControlDarkDark = 7;
            static ControlLight = 8;
            static ControlLightLight = 9;
            static ControlText = 10;
            static Desktop = 11;
            static GrayText = 12;
            static Highlight = 13;
            static HighlightText = 14;
            static HotTrack = 15;
            static InactiveBorder = 16;
            static InactiveCaption = 17;
            static InactiveCaptionText = 18;
            static Info = 19;
            static InfoText = 20;
            static Menu = 21;
            static MenuText = 22;
            static ScrollBar = 23;
            static Window = 24;
            static WindowFrame = 25;
            static WindowText = 26;
            static Transparent = 27;
            static AliceBlue = 28;
            static AntiqueWhite = 29;
            static Aqua = 30;
            static Aquamarine = 31;
            static Azure = 32;
            static Beige = 33;
            static Bisque = 34;
            static Black = 35;
            static BlanchedAlmond = 36;
            static Blue = 37;
            static BlueViolet = 38;
            static Brown = 39;
            static BurlyWood = 40;
            static CadetBlue = 41;
            static Chartreuse = 42;
            static Chocolate = 43;
            static Coral = 44;
            static CornflowerBlue = 45;
            static Cornsilk = 46;
            static Crimson = 47;
            static Cyan = 48;
            static DarkBlue = 49;
            static DarkCyan = 50;
            static DarkGoldenrod = 51;
            static DarkGray = 52;
            static DarkGreen = 53;
            static DarkKhaki = 54;
            static DarkMagenta = 55;
            static DarkOliveGreen = 56;
            static DarkOrange = 57;
            static DarkOrchid = 58;
            static DarkRed = 59;
            static DarkSalmon = 60;
            static DarkSeaGreen = 61;
            static DarkSlateBlue = 62;
            static DarkSlateGray = 63;
            static DarkTurquoise = 64;
            static DarkViolet = 65;
            static DeepPink = 66;
            static DeepSkyBlue = 67;
            static DimGray = 68;
            static DodgerBlue = 69;
            static Firebrick = 70;
            static FloralWhite = 71;
            static ForestGreen = 72;
            static Fuchsia = 73;
            static Gainsboro = 74;
            static GhostWhite = 75;
            static Gold = 76;
            static Goldenrod = 77;
            static Gray = 78;
            static Green = 79;
            static GreenYellow = 80;
            static Honeydew = 81;
            static HotPink = 82;
            static IndianRed = 83;
            static Indigo = 84;
            static Ivory = 85;
            static Khaki = 86;
            static Lavender = 87;
            static LavenderBlush = 88;
            static LawnGreen = 89;
            static LemonChiffon = 90;
            static LightBlue = 91;
            static LightCoral = 92;
            static LightCyan = 93;
            static LightGoldenrodYellow = 94;
            static LightGray = 95;
            static LightGreen = 96;
            static LightPink = 97;
            static LightSalmon = 98;
            static LightSeaGreen = 99;
            static LightSkyBlue = 100;
            static LightSlateGray = 101;
            static LightSteelBlue = 102;
            static LightYellow = 103;
            static Lime = 104;
            static LimeGreen = 105;
            static Linen = 106;
            static Magenta = 107;
            static Maroon = 108;
            static MediumAquamarine = 109;
            static MediumBlue = 110;
            static MediumOrchid = 111;
            static MediumPurple = 112;
            static MediumSeaGreen = 113;
            static MediumSlateBlue = 114;
            static MediumSpringGreen = 115;
            static MediumTurquoise = 116;
            static MediumVioletRed = 117;
            static MidnightBlue = 118;
            static MintCream = 119;
            static MistyRose = 120;
            static Moccasin = 121;
            static NavajoWhite = 122;
            static Navy = 123;
            static OldLace = 124;
            static Olive = 125;
            static OliveDrab = 126;
            static Orange = 127;
            static OrangeRed = 128;
            static Orchid = 129;
            static PaleGoldenrod = 130;
            static PaleGreen = 131;
            static PaleTurquoise = 132;
            static PaleVioletRed = 133;
            static PapayaWhip = 134;
            static PeachPuff = 135;
            static Peru = 136;
            static Pink = 137;
            static Plum = 138;
            static PowderBlue = 139;
            static Purple = 140;
            static Red = 141;
            static RosyBrown = 142;
            static RoyalBlue = 143;
            static SaddleBrown = 144;
            static Salmon = 145;
            static SandyBrown = 146;
            static SeaGreen = 147;
            static SeaShell = 148;
            static Sienna = 149;
            static Silver = 150;
            static SkyBlue = 151;
            static SlateBlue = 152;
            static SlateGray = 153;
            static Snow = 154;
            static SpringGreen = 155;
            static SteelBlue = 156;
            static Tan = 157;
            static Teal = 158;
            static Thistle = 159;
            static Tomato = 160;
            static Turquoise = 161;
            static Violet = 162;
            static Wheat = 163;
            static White = 164;
            static WhiteSmoke = 165;
            static Yellow = 166;
            static YellowGreen = 167;
            static ButtonFace = 168;
            static ButtonHighlight = 169;
            static ButtonShadow = 170;
            static GradientActiveCaption = 171;
            static GradientInactiveCaption = 172;
            static MenuBar = 173;
            static MenuHighlight = 174;
            static RebeccaPurple = 175;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ActiveBorder": 1n,
                    "ActiveCaption": 2n,
                    "ActiveCaptionText": 3n,
                    "AppWorkspace": 4n,
                    "Control": 5n,
                    "ControlDark": 6n,
                    "ControlDarkDark": 7n,
                    "ControlLight": 8n,
                    "ControlLightLight": 9n,
                    "ControlText": 10n,
                    "Desktop": 11n,
                    "GrayText": 12n,
                    "Highlight": 13n,
                    "HighlightText": 14n,
                    "HotTrack": 15n,
                    "InactiveBorder": 16n,
                    "InactiveCaption": 17n,
                    "InactiveCaptionText": 18n,
                    "Info": 19n,
                    "InfoText": 20n,
                    "Menu": 21n,
                    "MenuText": 22n,
                    "ScrollBar": 23n,
                    "Window": 24n,
                    "WindowFrame": 25n,
                    "WindowText": 26n,
                    "Transparent": 27n,
                    "AliceBlue": 28n,
                    "AntiqueWhite": 29n,
                    "Aqua": 30n,
                    "Aquamarine": 31n,
                    "Azure": 32n,
                    "Beige": 33n,
                    "Bisque": 34n,
                    "Black": 35n,
                    "BlanchedAlmond": 36n,
                    "Blue": 37n,
                    "BlueViolet": 38n,
                    "Brown": 39n,
                    "BurlyWood": 40n,
                    "CadetBlue": 41n,
                    "Chartreuse": 42n,
                    "Chocolate": 43n,
                    "Coral": 44n,
                    "CornflowerBlue": 45n,
                    "Cornsilk": 46n,
                    "Crimson": 47n,
                    "Cyan": 48n,
                    "DarkBlue": 49n,
                    "DarkCyan": 50n,
                    "DarkGoldenrod": 51n,
                    "DarkGray": 52n,
                    "DarkGreen": 53n,
                    "DarkKhaki": 54n,
                    "DarkMagenta": 55n,
                    "DarkOliveGreen": 56n,
                    "DarkOrange": 57n,
                    "DarkOrchid": 58n,
                    "DarkRed": 59n,
                    "DarkSalmon": 60n,
                    "DarkSeaGreen": 61n,
                    "DarkSlateBlue": 62n,
                    "DarkSlateGray": 63n,
                    "DarkTurquoise": 64n,
                    "DarkViolet": 65n,
                    "DeepPink": 66n,
                    "DeepSkyBlue": 67n,
                    "DimGray": 68n,
                    "DodgerBlue": 69n,
                    "Firebrick": 70n,
                    "FloralWhite": 71n,
                    "ForestGreen": 72n,
                    "Fuchsia": 73n,
                    "Gainsboro": 74n,
                    "GhostWhite": 75n,
                    "Gold": 76n,
                    "Goldenrod": 77n,
                    "Gray": 78n,
                    "Green": 79n,
                    "GreenYellow": 80n,
                    "Honeydew": 81n,
                    "HotPink": 82n,
                    "IndianRed": 83n,
                    "Indigo": 84n,
                    "Ivory": 85n,
                    "Khaki": 86n,
                    "Lavender": 87n,
                    "LavenderBlush": 88n,
                    "LawnGreen": 89n,
                    "LemonChiffon": 90n,
                    "LightBlue": 91n,
                    "LightCoral": 92n,
                    "LightCyan": 93n,
                    "LightGoldenrodYellow": 94n,
                    "LightGray": 95n,
                    "LightGreen": 96n,
                    "LightPink": 97n,
                    "LightSalmon": 98n,
                    "LightSeaGreen": 99n,
                    "LightSkyBlue": 100n,
                    "LightSlateGray": 101n,
                    "LightSteelBlue": 102n,
                    "LightYellow": 103n,
                    "Lime": 104n,
                    "LimeGreen": 105n,
                    "Linen": 106n,
                    "Magenta": 107n,
                    "Maroon": 108n,
                    "MediumAquamarine": 109n,
                    "MediumBlue": 110n,
                    "MediumOrchid": 111n,
                    "MediumPurple": 112n,
                    "MediumSeaGreen": 113n,
                    "MediumSlateBlue": 114n,
                    "MediumSpringGreen": 115n,
                    "MediumTurquoise": 116n,
                    "MediumVioletRed": 117n,
                    "MidnightBlue": 118n,
                    "MintCream": 119n,
                    "MistyRose": 120n,
                    "Moccasin": 121n,
                    "NavajoWhite": 122n,
                    "Navy": 123n,
                    "OldLace": 124n,
                    "Olive": 125n,
                    "OliveDrab": 126n,
                    "Orange": 127n,
                    "OrangeRed": 128n,
                    "Orchid": 129n,
                    "PaleGoldenrod": 130n,
                    "PaleGreen": 131n,
                    "PaleTurquoise": 132n,
                    "PaleVioletRed": 133n,
                    "PapayaWhip": 134n,
                    "PeachPuff": 135n,
                    "Peru": 136n,
                    "Pink": 137n,
                    "Plum": 138n,
                    "PowderBlue": 139n,
                    "Purple": 140n,
                    "Red": 141n,
                    "RosyBrown": 142n,
                    "RoyalBlue": 143n,
                    "SaddleBrown": 144n,
                    "Salmon": 145n,
                    "SandyBrown": 146n,
                    "SeaGreen": 147n,
                    "SeaShell": 148n,
                    "Sienna": 149n,
                    "Silver": 150n,
                    "SkyBlue": 151n,
                    "SlateBlue": 152n,
                    "SlateGray": 153n,
                    "Snow": 154n,
                    "SpringGreen": 155n,
                    "SteelBlue": 156n,
                    "Tan": 157n,
                    "Teal": 158n,
                    "Thistle": 159n,
                    "Tomato": 160n,
                    "Turquoise": 161n,
                    "Violet": 162n,
                    "Wheat": 163n,
                    "White": 164n,
                    "WhiteSmoke": 165n,
                    "Yellow": 166n,
                    "YellowGreen": 167n,
                    "ButtonFace": 168n,
                    "ButtonHighlight": 169n,
                    "ButtonShadow": 170n,
                    "GradientActiveCaption": 171n,
                    "GradientInactiveCaption": 172n,
                    "MenuBar": 173n,
                    "MenuHighlight": 174n,
                    "RebeccaPurple": 175n
                };
            }
            static $h = 391122;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":391122,"n":"ActiveBorder","d":391122,"h":4295358418,"f":33},{"t":391122,"n":"ActiveCaption","d":391122,"h":8590325714,"f":33},{"t":391122,"n":"ActiveCaptionText","d":391122,"h":12885293010,"f":33},{"t":391122,"n":"AppWorkspace","d":391122,"h":17180260306,"f":33},{"t":391122,"n":"Control","d":391122,"h":21475227602,"f":33},{"t":391122,"n":"ControlDark","d":391122,"h":25770194898,"f":33},{"t":391122,"n":"ControlDarkDark","d":391122,"h":30065162194,"f":33},{"t":391122,"n":"ControlLight","d":391122,"h":34360129490,"f":33},{"t":391122,"n":"ControlLightLight","d":391122,"h":38655096786,"f":33},{"t":391122,"n":"ControlText","d":391122,"h":42950064082,"f":33},{"t":391122,"n":"Desktop","d":391122,"h":47245031378,"f":33},{"t":391122,"n":"GrayText","d":391122,"h":51539998674,"f":33},{"t":391122,"n":"Highlight","d":391122,"h":55834965970,"f":33},{"t":391122,"n":"HighlightText","d":391122,"h":60129933266,"f":33},{"t":391122,"n":"HotTrack","d":391122,"h":64424900562,"f":33},{"t":391122,"n":"InactiveBorder","d":391122,"h":68719867858,"f":33},{"t":391122,"n":"InactiveCaption","d":391122,"h":73014835154,"f":33},{"t":391122,"n":"InactiveCaptionText","d":391122,"h":77309802450,"f":33},{"t":391122,"n":"Info","d":391122,"h":81604769746,"f":33},{"t":391122,"n":"InfoText","d":391122,"h":85899737042,"f":33},{"t":391122,"n":"Menu","d":391122,"h":90194704338,"f":33},{"t":391122,"n":"MenuText","d":391122,"h":94489671634,"f":33},{"t":391122,"n":"ScrollBar","d":391122,"h":98784638930,"f":33},{"t":391122,"n":"Window","d":391122,"h":103079606226,"f":33},{"t":391122,"n":"WindowFrame","d":391122,"h":107374573522,"f":33},{"t":391122,"n":"WindowText","d":391122,"h":111669540818,"f":33},{"t":391122,"n":"Transparent","d":391122,"h":115964508114,"f":33},{"t":391122,"n":"AliceBlue","d":391122,"h":120259475410,"f":33},{"t":391122,"n":"AntiqueWhite","d":391122,"h":124554442706,"f":33},{"t":391122,"n":"Aqua","d":391122,"h":128849410002,"f":33},{"t":391122,"n":"Aquamarine","d":391122,"h":133144377298,"f":33},{"t":391122,"n":"Azure","d":391122,"h":137439344594,"f":33},{"t":391122,"n":"Beige","d":391122,"h":141734311890,"f":33},{"t":391122,"n":"Bisque","d":391122,"h":146029279186,"f":33},{"t":391122,"n":"Black","d":391122,"h":150324246482,"f":33},{"t":391122,"n":"BlanchedAlmond","d":391122,"h":154619213778,"f":33},{"t":391122,"n":"Blue","d":391122,"h":158914181074,"f":33},{"t":391122,"n":"BlueViolet","d":391122,"h":163209148370,"f":33},{"t":391122,"n":"Brown","d":391122,"h":167504115666,"f":33},{"t":391122,"n":"BurlyWood","d":391122,"h":171799082962,"f":33},{"t":391122,"n":"CadetBlue","d":391122,"h":176094050258,"f":33},{"t":391122,"n":"Chartreuse","d":391122,"h":180389017554,"f":33},{"t":391122,"n":"Chocolate","d":391122,"h":184683984850,"f":33},{"t":391122,"n":"Coral","d":391122,"h":188978952146,"f":33},{"t":391122,"n":"CornflowerBlue","d":391122,"h":193273919442,"f":33},{"t":391122,"n":"Cornsilk","d":391122,"h":197568886738,"f":33},{"t":391122,"n":"Crimson","d":391122,"h":201863854034,"f":33},{"t":391122,"n":"Cyan","d":391122,"h":206158821330,"f":33},{"t":391122,"n":"DarkBlue","d":391122,"h":210453788626,"f":33},{"t":391122,"n":"DarkCyan","d":391122,"h":214748755922,"f":33},{"t":391122,"n":"DarkGoldenrod","d":391122,"h":219043723218,"f":33},{"t":391122,"n":"DarkGray","d":391122,"h":223338690514,"f":33},{"t":391122,"n":"DarkGreen","d":391122,"h":227633657810,"f":33},{"t":391122,"n":"DarkKhaki","d":391122,"h":231928625106,"f":33},{"t":391122,"n":"DarkMagenta","d":391122,"h":236223592402,"f":33},{"t":391122,"n":"DarkOliveGreen","d":391122,"h":240518559698,"f":33},{"t":391122,"n":"DarkOrange","d":391122,"h":244813526994,"f":33},{"t":391122,"n":"DarkOrchid","d":391122,"h":249108494290,"f":33},{"t":391122,"n":"DarkRed","d":391122,"h":253403461586,"f":33},{"t":391122,"n":"DarkSalmon","d":391122,"h":257698428882,"f":33},{"t":391122,"n":"DarkSeaGreen","d":391122,"h":261993396178,"f":33},{"t":391122,"n":"DarkSlateBlue","d":391122,"h":266288363474,"f":33},{"t":391122,"n":"DarkSlateGray","d":391122,"h":270583330770,"f":33},{"t":391122,"n":"DarkTurquoise","d":391122,"h":274878298066,"f":33},{"t":391122,"n":"DarkViolet","d":391122,"h":279173265362,"f":33},{"t":391122,"n":"DeepPink","d":391122,"h":283468232658,"f":33},{"t":391122,"n":"DeepSkyBlue","d":391122,"h":287763199954,"f":33},{"t":391122,"n":"DimGray","d":391122,"h":292058167250,"f":33},{"t":391122,"n":"DodgerBlue","d":391122,"h":296353134546,"f":33},{"t":391122,"n":"Firebrick","d":391122,"h":300648101842,"f":33},{"t":391122,"n":"FloralWhite","d":391122,"h":304943069138,"f":33},{"t":391122,"n":"ForestGreen","d":391122,"h":309238036434,"f":33},{"t":391122,"n":"Fuchsia","d":391122,"h":313533003730,"f":33},{"t":391122,"n":"Gainsboro","d":391122,"h":317827971026,"f":33},{"t":391122,"n":"GhostWhite","d":391122,"h":322122938322,"f":33},{"t":391122,"n":"Gold","d":391122,"h":326417905618,"f":33},{"t":391122,"n":"Goldenrod","d":391122,"h":330712872914,"f":33},{"t":391122,"n":"Gray","d":391122,"h":335007840210,"f":33},{"t":391122,"n":"Green","d":391122,"h":339302807506,"f":33},{"t":391122,"n":"GreenYellow","d":391122,"h":343597774802,"f":33},{"t":391122,"n":"Honeydew","d":391122,"h":347892742098,"f":33},{"t":391122,"n":"HotPink","d":391122,"h":352187709394,"f":33},{"t":391122,"n":"IndianRed","d":391122,"h":356482676690,"f":33},{"t":391122,"n":"Indigo","d":391122,"h":360777643986,"f":33},{"t":391122,"n":"Ivory","d":391122,"h":365072611282,"f":33},{"t":391122,"n":"Khaki","d":391122,"h":369367578578,"f":33},{"t":391122,"n":"Lavender","d":391122,"h":373662545874,"f":33},{"t":391122,"n":"LavenderBlush","d":391122,"h":377957513170,"f":33},{"t":391122,"n":"LawnGreen","d":391122,"h":382252480466,"f":33},{"t":391122,"n":"LemonChiffon","d":391122,"h":386547447762,"f":33},{"t":391122,"n":"LightBlue","d":391122,"h":390842415058,"f":33},{"t":391122,"n":"LightCoral","d":391122,"h":395137382354,"f":33},{"t":391122,"n":"LightCyan","d":391122,"h":399432349650,"f":33},{"t":391122,"n":"LightGoldenrodYellow","d":391122,"h":403727316946,"f":33},{"t":391122,"n":"LightGray","d":391122,"h":408022284242,"f":33},{"t":391122,"n":"LightGreen","d":391122,"h":412317251538,"f":33},{"t":391122,"n":"LightPink","d":391122,"h":416612218834,"f":33},{"t":391122,"n":"LightSalmon","d":391122,"h":420907186130,"f":33},{"t":391122,"n":"LightSeaGreen","d":391122,"h":425202153426,"f":33},{"t":391122,"n":"LightSkyBlue","d":391122,"h":429497120722,"f":33},{"t":391122,"n":"LightSlateGray","d":391122,"h":433792088018,"f":33},{"t":391122,"n":"LightSteelBlue","d":391122,"h":438087055314,"f":33},{"t":391122,"n":"LightYellow","d":391122,"h":442382022610,"f":33},{"t":391122,"n":"Lime","d":391122,"h":446676989906,"f":33},{"t":391122,"n":"LimeGreen","d":391122,"h":450971957202,"f":33},{"t":391122,"n":"Linen","d":391122,"h":455266924498,"f":33},{"t":391122,"n":"Magenta","d":391122,"h":459561891794,"f":33},{"t":391122,"n":"Maroon","d":391122,"h":463856859090,"f":33},{"t":391122,"n":"MediumAquamarine","d":391122,"h":468151826386,"f":33},{"t":391122,"n":"MediumBlue","d":391122,"h":472446793682,"f":33},{"t":391122,"n":"MediumOrchid","d":391122,"h":476741760978,"f":33},{"t":391122,"n":"MediumPurple","d":391122,"h":481036728274,"f":33},{"t":391122,"n":"MediumSeaGreen","d":391122,"h":485331695570,"f":33},{"t":391122,"n":"MediumSlateBlue","d":391122,"h":489626662866,"f":33},{"t":391122,"n":"MediumSpringGreen","d":391122,"h":493921630162,"f":33},{"t":391122,"n":"MediumTurquoise","d":391122,"h":498216597458,"f":33},{"t":391122,"n":"MediumVioletRed","d":391122,"h":502511564754,"f":33},{"t":391122,"n":"MidnightBlue","d":391122,"h":506806532050,"f":33},{"t":391122,"n":"MintCream","d":391122,"h":511101499346,"f":33},{"t":391122,"n":"MistyRose","d":391122,"h":515396466642,"f":33},{"t":391122,"n":"Moccasin","d":391122,"h":519691433938,"f":33},{"t":391122,"n":"NavajoWhite","d":391122,"h":523986401234,"f":33},{"t":391122,"n":"Navy","d":391122,"h":528281368530,"f":33},{"t":391122,"n":"OldLace","d":391122,"h":532576335826,"f":33},{"t":391122,"n":"Olive","d":391122,"h":536871303122,"f":33},{"t":391122,"n":"OliveDrab","d":391122,"h":541166270418,"f":33},{"t":391122,"n":"Orange","d":391122,"h":545461237714,"f":33},{"t":391122,"n":"OrangeRed","d":391122,"h":549756205010,"f":33},{"t":391122,"n":"Orchid","d":391122,"h":554051172306,"f":33},{"t":391122,"n":"PaleGoldenrod","d":391122,"h":558346139602,"f":33},{"t":391122,"n":"PaleGreen","d":391122,"h":562641106898,"f":33},{"t":391122,"n":"PaleTurquoise","d":391122,"h":566936074194,"f":33},{"t":391122,"n":"PaleVioletRed","d":391122,"h":571231041490,"f":33},{"t":391122,"n":"PapayaWhip","d":391122,"h":575526008786,"f":33},{"t":391122,"n":"PeachPuff","d":391122,"h":579820976082,"f":33},{"t":391122,"n":"Peru","d":391122,"h":584115943378,"f":33},{"t":391122,"n":"Pink","d":391122,"h":588410910674,"f":33},{"t":391122,"n":"Plum","d":391122,"h":592705877970,"f":33},{"t":391122,"n":"PowderBlue","d":391122,"h":597000845266,"f":33},{"t":391122,"n":"Purple","d":391122,"h":601295812562,"f":33},{"t":391122,"n":"Red","d":391122,"h":605590779858,"f":33},{"t":391122,"n":"RosyBrown","d":391122,"h":609885747154,"f":33},{"t":391122,"n":"RoyalBlue","d":391122,"h":614180714450,"f":33},{"t":391122,"n":"SaddleBrown","d":391122,"h":618475681746,"f":33},{"t":391122,"n":"Salmon","d":391122,"h":622770649042,"f":33},{"t":391122,"n":"SandyBrown","d":391122,"h":627065616338,"f":33},{"t":391122,"n":"SeaGreen","d":391122,"h":631360583634,"f":33},{"t":391122,"n":"SeaShell","d":391122,"h":635655550930,"f":33},{"t":391122,"n":"Sienna","d":391122,"h":639950518226,"f":33},{"t":391122,"n":"Silver","d":391122,"h":644245485522,"f":33},{"t":391122,"n":"SkyBlue","d":391122,"h":648540452818,"f":33},{"t":391122,"n":"SlateBlue","d":391122,"h":652835420114,"f":33},{"t":391122,"n":"SlateGray","d":391122,"h":657130387410,"f":33},{"t":391122,"n":"Snow","d":391122,"h":661425354706,"f":33},{"t":391122,"n":"SpringGreen","d":391122,"h":665720322002,"f":33},{"t":391122,"n":"SteelBlue","d":391122,"h":670015289298,"f":33},{"t":391122,"n":"Tan","d":391122,"h":674310256594,"f":33},{"t":391122,"n":"Teal","d":391122,"h":678605223890,"f":33},{"t":391122,"n":"Thistle","d":391122,"h":682900191186,"f":33},{"t":391122,"n":"Tomato","d":391122,"h":687195158482,"f":33},{"t":391122,"n":"Turquoise","d":391122,"h":691490125778,"f":33},{"t":391122,"n":"Violet","d":391122,"h":695785093074,"f":33},{"t":391122,"n":"Wheat","d":391122,"h":700080060370,"f":33},{"t":391122,"n":"White","d":391122,"h":704375027666,"f":33},{"t":391122,"n":"WhiteSmoke","d":391122,"h":708669994962,"f":33},{"t":391122,"n":"Yellow","d":391122,"h":712964962258,"f":33},{"t":391122,"n":"YellowGreen","d":391122,"h":717259929554,"f":33},{"t":391122,"n":"ButtonFace","d":391122,"h":721554896850,"f":33},{"t":391122,"n":"ButtonHighlight","d":391122,"h":725849864146,"f":33},{"t":391122,"n":"ButtonShadow","d":391122,"h":730144831442,"f":33},{"t":391122,"n":"GradientActiveCaption","d":391122,"h":734439798738,"f":33},{"t":391122,"n":"GradientInactiveCaption","d":391122,"h":738734766034,"f":33},{"t":391122,"n":"MenuBar","d":391122,"h":743029733330,"f":33},{"t":391122,"n":"MenuHighlight","d":391122,"h":747324700626,"f":33},{"t":391122,"n":"RebeccaPurple","d":391122,"h":751619667922,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":391122,"h":755914635218,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":391122,"a":[{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Drawing.KnownColor`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.InteropServices", "NetJs.System.ComponentModel.Primitives"))