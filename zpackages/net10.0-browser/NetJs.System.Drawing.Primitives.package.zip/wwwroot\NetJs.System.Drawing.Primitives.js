
(function ($global, $, $spc, $sc, $sdt, $sm, $snv, $spu, $st, $sr, $scc, $scn, $scm, $so, $sris, $scp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Drawing.Primitives", 
    {"h":59049,"f":"System.Drawing.Primitives","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Drawing.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Drawing.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdp.System.Drawing.KnownColorNames", ($self) => class KnownColorNames
        {
            /*string[]*/ static s_colorNameTable = null;
            static /*string */ KnownColorToName(/*KnownColor*/ color)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(color > 0 && color <= 175/*KnownColor.RebeccaPurple*/, "color > 0 && color <= KnownColor.RebeccaPurple");
                return $.$spc.System.Array.$ReadT1.call($.$sdp.System.Drawing.KnownColorNames.s_colorNameTable, ((color - 1) | 0));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_colorNameTable = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), ["ActiveBorder", "ActiveCaption", "ActiveCaptionText", "AppWorkspace", "Control", "ControlDark", "ControlDarkDark", "ControlLight", "ControlLightLight", "ControlText", "Desktop", "GrayText", "Highlight", "HighlightText", "HotTrack", "InactiveBorder", "InactiveCaption", "InactiveCaptionText", "Info", "InfoText", "Menu", "MenuText", "ScrollBar", "Window", "WindowFrame", "WindowText", "Transparent", "AliceBlue", "AntiqueWhite", "Aqua", "Aquamarine", "Azure", "Beige", "Bisque", "Black", "BlanchedAlmond", "Blue", "BlueViolet", "Brown", "BurlyWood", "CadetBlue", "Chartreuse", "Chocolate", "Coral", "CornflowerBlue", "Cornsilk", "Crimson", "Cyan", "DarkBlue", "DarkCyan", "DarkGoldenrod", "DarkGray", "DarkGreen", "DarkKhaki", "DarkMagenta", "DarkOliveGreen", "DarkOrange", "DarkOrchid", "DarkRed", "DarkSalmon", "DarkSeaGreen", "DarkSlateBlue", "DarkSlateGray", "DarkTurquoise", "DarkViolet", "DeepPink", "DeepSkyBlue", "DimGray", "DodgerBlue", "Firebrick", "FloralWhite", "ForestGreen", "Fuchsia", "Gainsboro", "GhostWhite", "Gold", "Goldenrod", "Gray", "Green", "GreenYellow", "Honeydew", "HotPink", "IndianRed", "Indigo", "Ivory", "Khaki", "Lavender", "LavenderBlush", "LawnGreen", "LemonChiffon", "LightBlue", "LightCoral", "LightCyan", "LightGoldenrodYellow", "LightGray", "LightGreen", "LightPink", "LightSalmon", "LightSeaGreen", "LightSkyBlue", "LightSlateGray", "LightSteelBlue", "LightYellow", "Lime", "LimeGreen", "Linen", "Magenta", "Maroon", "MediumAquamarine", "MediumBlue", "MediumOrchid", "MediumPurple", "MediumSeaGreen", "MediumSlateBlue", "MediumSpringGreen", "MediumTurquoise", "MediumVioletRed", "MidnightBlue", "MintCream", "MistyRose", "Moccasin", "NavajoWhite", "Navy", "OldLace", "Olive", "OliveDrab", "Orange", "OrangeRed", "Orchid", "PaleGoldenrod", "PaleGreen", "PaleTurquoise", "PaleVioletRed", "PapayaWhip", "PeachPuff", "Peru", "Pink", "Plum", "PowderBlue", "Purple", "Red", "RosyBrown", "RoyalBlue", "SaddleBrown", "Salmon", "SandyBrown", "SeaGreen", "SeaShell", "Sienna", "Silver", "SkyBlue", "SlateBlue", "SlateGray", "Snow", "SpringGreen", "SteelBlue", "Tan", "Teal", "Thistle", "Tomato", "Turquoise", "Violet", "Wheat", "White", "WhiteSmoke", "Yellow", "YellowGreen", "ButtonFace", "ButtonHighlight", "ButtonShadow", "GradientActiveCaption", "GradientInactiveCaption", "MenuBar", "MenuHighlight", "RebeccaPurple"], [-1], null);
                }
            }
            static $h = 452265;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"color","p":386729}],"n":"KnownColorToName","d":452265,"h":8590386857,"f":33}],"l":[{"t":0,"n":"s_colorNameTable","d":452265,"h":4295419561,"f":34}],"h":452265}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.KnownColorNames`; }
        });
        
        $asm.$cls("$sdp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sdp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Drawing.Primitives", $.$sdp.System.SR.$type.Assembly);
                    $.$sdp.System.SR.s_resourceManager = temp;
                }
                return $.$sdp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sdp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sdp.System.SR.resourceCulture = value;
            }
            static /*string */ get ConvertInvalidPrimitive()
            {
                return "{0} is not a valid value for {1}.";
            }
            static /*string */ FormatConvertInvalidPrimitive(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("{0} is not a valid value for {1}.", arg1, arg2);
            }
            static /*string */ get InvalidColor()
            {
                return "Color '{0}' is not valid.";
            }
            static /*string */ FormatInvalidColor(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Color '{0}' is not valid.", arg1);
            }
            static /*string */ get InvalidEx2BoundArgument()
            {
                return "Value of '{1}' is not valid for '{0}'. '{0}' should be greater than or equal to {2} and less than or equal to {3}.";
            }
            static /*string */ FormatInvalidEx2BoundArgument(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4, /*object*/ arg5)
            {
                return $.$spc.System.String.Format$4("Value of '{1}' is not valid for '{0}'. '{0}' should be greater than or equal to {2} and less than or equal to {3}.", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg1, arg2, arg3, arg4, arg5 ]));
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sdp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sdp.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sdp.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sdp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1107625;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1107625}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorTranslator", ($self) => class ColorTranslator
        {
            /*int*/ static COLORREF_RedShift = 0;
            /*int*/ static COLORREF_GreenShift = 8;
            /*int*/ static COLORREF_BlueShift = 16;
            /*int*/ static OleSystemColorFlag = -2147483648;
            /*Dictionary<string, Color>?*/ static s_htmlSysColorTable = null;
            static /*uint */ COLORREFToARGB(/*uint*/ value)
            {
                return (((value >>> 0/*COLORREF_RedShift*/) & 255) << 16/*Color.ARGBRedShift*/) >>> 0 | (((value >>> 8/*COLORREF_GreenShift*/) & 255) << 8/*Color.ARGBGreenShift*/) >>> 0 | (((value >>> 16/*COLORREF_BlueShift*/) & 255) << 0/*Color.ARGBBlueShift*/) >>> 0 | 4278190080/*Color.ARGBAlphaMask*/;
            }
            static /*int */ ToWin32(/*Color*/ c)
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                c.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                return r << 0/*COLORREF_RedShift*/ | g << 8/*COLORREF_GreenShift*/ | b << 16/*COLORREF_BlueShift*/;
            }
            static /*int */ ToOle(/*Color*/ c)
            {
                if (c.IsKnownColor && c.IsSystemColor)
                {
                    let $switch1 = c.ToKnownColor();
                    switch($switch1)
                    {
                        case 1/*KnownColor.ActiveBorder*/:
                        return (2147483658 | 0);
                        case 2/*KnownColor.ActiveCaption*/:
                        return (2147483650 | 0);
                        case 3/*KnownColor.ActiveCaptionText*/:
                        return (2147483657 | 0);
                        case 4/*KnownColor.AppWorkspace*/:
                        return (2147483660 | 0);
                        case 168/*KnownColor.ButtonFace*/:
                        return (2147483663 | 0);
                        case 169/*KnownColor.ButtonHighlight*/:
                        return (2147483668 | 0);
                        case 170/*KnownColor.ButtonShadow*/:
                        return (2147483664 | 0);
                        case 5/*KnownColor.Control*/:
                        return (2147483663 | 0);
                        case 6/*KnownColor.ControlDark*/:
                        return (2147483664 | 0);
                        case 7/*KnownColor.ControlDarkDark*/:
                        return (2147483669 | 0);
                        case 8/*KnownColor.ControlLight*/:
                        return (2147483670 | 0);
                        case 9/*KnownColor.ControlLightLight*/:
                        return (2147483668 | 0);
                        case 10/*KnownColor.ControlText*/:
                        return (2147483666 | 0);
                        case 11/*KnownColor.Desktop*/:
                        return (2147483649 | 0);
                        case 171/*KnownColor.GradientActiveCaption*/:
                        return (2147483675 | 0);
                        case 172/*KnownColor.GradientInactiveCaption*/:
                        return (2147483676 | 0);
                        case 12/*KnownColor.GrayText*/:
                        return (2147483665 | 0);
                        case 13/*KnownColor.Highlight*/:
                        return (2147483661 | 0);
                        case 14/*KnownColor.HighlightText*/:
                        return (2147483662 | 0);
                        case 15/*KnownColor.HotTrack*/:
                        return (2147483674 | 0);
                        case 16/*KnownColor.InactiveBorder*/:
                        return (2147483659 | 0);
                        case 17/*KnownColor.InactiveCaption*/:
                        return (2147483651 | 0);
                        case 18/*KnownColor.InactiveCaptionText*/:
                        return (2147483667 | 0);
                        case 19/*KnownColor.Info*/:
                        return (2147483672 | 0);
                        case 20/*KnownColor.InfoText*/:
                        return (2147483671 | 0);
                        case 21/*KnownColor.Menu*/:
                        return (2147483652 | 0);
                        case 173/*KnownColor.MenuBar*/:
                        return (2147483678 | 0);
                        case 174/*KnownColor.MenuHighlight*/:
                        return (2147483677 | 0);
                        case 22/*KnownColor.MenuText*/:
                        return (2147483655 | 0);
                        case 23/*KnownColor.ScrollBar*/:
                        return (2147483648 | 0);
                        case 24/*KnownColor.Window*/:
                        return (2147483653 | 0);
                        case 25/*KnownColor.WindowFrame*/:
                        return (2147483654 | 0);
                        case 26/*KnownColor.WindowText*/:
                        return (2147483656 | 0);
                    }
                }
                return $.$sdp.System.Drawing.ColorTranslator.ToWin32(c);
            }
            static /*Color */ FromOle(/*int*/ oleColor)
            {
                if ((oleColor & -2147483648/*OleSystemColorFlag*/) !== 0)
                {
                    switch(oleColor)
                    {
                        case (2147483658 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/);
                        case (2147483650 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/);
                        case (2147483657 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/);
                        case (2147483660 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/);
                        case (2147483663 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/);
                        case (2147483664 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/);
                        case (2147483669 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/);
                        case (2147483670 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/);
                        case (2147483668 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/);
                        case (2147483666 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/);
                        case (2147483649 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/);
                        case (2147483675 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(171/*KnownColor.GradientActiveCaption*/);
                        case (2147483676 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(172/*KnownColor.GradientInactiveCaption*/);
                        case (2147483665 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/);
                        case (2147483661 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/);
                        case (2147483662 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/);
                        case (2147483674 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(15/*KnownColor.HotTrack*/);
                        case (2147483659 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/);
                        case (2147483651 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/);
                        case (2147483667 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/);
                        case (2147483672 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/);
                        case (2147483671 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/);
                        case (2147483652 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/);
                        case (2147483678 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(173/*KnownColor.MenuBar*/);
                        case (2147483677 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(174/*KnownColor.MenuHighlight*/);
                        case (2147483655 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/);
                        case (2147483648 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/);
                        case (2147483653 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/);
                        case (2147483654 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/);
                        case (2147483656 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/);
                    }
                }
                return $.$sdp.System.Drawing.KnownColorTable.ArgbToKnownColor($.$sdp.System.Drawing.ColorTranslator.COLORREFToARGB((oleColor >>> 0)));
            }
            static /*Color */ FromWin32(/*int*/ win32Color)
            {
                return $.$sdp.System.Drawing.ColorTranslator.FromOle(win32Color);
            }
            static /*Color */ FromHtml(/*string*/ htmlColor)
            {
                /*Color*/ let c = $.$sdp.System.Drawing.Color.Empty;
                if (($.$spc.System.String.op_Equality(htmlColor, null)) || (htmlColor.length === 0))
                {
                    return c;
                }
                if (($.$spc.System.String.get_Chars.call(htmlColor, 0) === /*#*/ 35) && ((htmlColor.length === 7) || (htmlColor.length === 4)))
                {
                    if (htmlColor.length === 7)
                    {
                        c = $.$sdp.System.Drawing.Color.FromArgb$4($.$spc.System.Convert.ToInt32$18($.$spc.System.String.Substring$1.call(htmlColor, 1, 2), 16), $.$spc.System.Convert.ToInt32$18($.$spc.System.String.Substring$1.call(htmlColor, 3, 2), 16), $.$spc.System.Convert.ToInt32$18($.$spc.System.String.Substring$1.call(htmlColor, 5, 2), 16));
                    }
                    else 
                    {
                        /*string*/ let r = $.$spc.System.Char.ToString$2($.$spc.System.String.get_Chars.call(htmlColor, 1));
                        /*string*/ let g = $.$spc.System.Char.ToString$2($.$spc.System.String.get_Chars.call(htmlColor, 2));
                        /*string*/ let b = $.$spc.System.Char.ToString$2($.$spc.System.String.get_Chars.call(htmlColor, 3));
                        c = $.$sdp.System.Drawing.Color.FromArgb$4($.$spc.System.Convert.ToInt32$18(r + r, 16), $.$spc.System.Convert.ToInt32$18(g + g, 16), $.$spc.System.Convert.ToInt32$18(b + b, 16));
                    }
                }
                if (c.IsEmpty && $.$spc.System.String.Equals$5(htmlColor, "LightGrey", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    c = $.$sdp.System.Drawing.Color.LightGray;
                }
                if (c.IsEmpty)
                {
                    if ($.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable === null)
                    {
                        $.$sdp.System.Drawing.ColorTranslator.InitializeHtmlSysColorTable();
                    }
                    $.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable.TryGetValue($.$spc.System.String.ToLowerInvariant.call(htmlColor), $.$ref(() => c, ($v) => c = $v, $.$sdp.System.Drawing.Color));
                }
                if (c.IsEmpty)
                {
                    try
                    {
                        c = $.$sdp.System.Drawing.ColorConverterCommon.ConvertFromString(htmlColor, $.$spc.System.Globalization.CultureInfo.CurrentCulture);
                    }
                    catch(ex)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$12(ex.Message, "htmlColor", ex);
                    }
                }
                return c;
            }
            static /*string */ ToHtml(/*Color*/ c)
            {
                /*string*/ let colorString = $.$spc.System.String.Empty;
                if (c.IsEmpty)
                {
                    return colorString;
                }
                if (c.IsSystemColor)
                {
                    let $switch1 = c.ToKnownColor();
                    switch($switch1)
                    {
                        case 1/*KnownColor.ActiveBorder*/:
                        colorString = "activeborder";
                        break;
                        case 171/*KnownColor.GradientActiveCaption*/:
                        case 2/*KnownColor.ActiveCaption*/:
                        colorString = "activecaption";
                        break;
                        case 4/*KnownColor.AppWorkspace*/:
                        colorString = "appworkspace";
                        break;
                        case 11/*KnownColor.Desktop*/:
                        colorString = "background";
                        break;
                        case 5/*KnownColor.Control*/:
                        case 8/*KnownColor.ControlLight*/:
                        colorString = "buttonface";
                        break;
                        case 6/*KnownColor.ControlDark*/:
                        colorString = "buttonshadow";
                        break;
                        case 10/*KnownColor.ControlText*/:
                        colorString = "buttontext";
                        break;
                        case 3/*KnownColor.ActiveCaptionText*/:
                        colorString = "captiontext";
                        break;
                        case 12/*KnownColor.GrayText*/:
                        colorString = "graytext";
                        break;
                        case 15/*KnownColor.HotTrack*/:
                        case 13/*KnownColor.Highlight*/:
                        colorString = "highlight";
                        break;
                        case 174/*KnownColor.MenuHighlight*/:
                        case 14/*KnownColor.HighlightText*/:
                        colorString = "highlighttext";
                        break;
                        case 16/*KnownColor.InactiveBorder*/:
                        colorString = "inactiveborder";
                        break;
                        case 172/*KnownColor.GradientInactiveCaption*/:
                        case 17/*KnownColor.InactiveCaption*/:
                        colorString = "inactivecaption";
                        break;
                        case 18/*KnownColor.InactiveCaptionText*/:
                        colorString = "inactivecaptiontext";
                        break;
                        case 19/*KnownColor.Info*/:
                        colorString = "infobackground";
                        break;
                        case 20/*KnownColor.InfoText*/:
                        colorString = "infotext";
                        break;
                        case 173/*KnownColor.MenuBar*/:
                        case 21/*KnownColor.Menu*/:
                        colorString = "menu";
                        break;
                        case 22/*KnownColor.MenuText*/:
                        colorString = "menutext";
                        break;
                        case 23/*KnownColor.ScrollBar*/:
                        colorString = "scrollbar";
                        break;
                        case 7/*KnownColor.ControlDarkDark*/:
                        colorString = "threeddarkshadow";
                        break;
                        case 9/*KnownColor.ControlLightLight*/:
                        colorString = "buttonhighlight";
                        break;
                        case 24/*KnownColor.Window*/:
                        colorString = "window";
                        break;
                        case 25/*KnownColor.WindowFrame*/:
                        colorString = "windowframe";
                        break;
                        case 26/*KnownColor.WindowText*/:
                        colorString = "windowtext";
                        break;
                    }
                }
                else if (c.IsNamedColor)
                {
                    if ($.$sdp.System.Drawing.Color.op_Equality(c, $.$sdp.System.Drawing.Color.LightGray))
                    {
                        colorString = "LightGrey";
                    }
                    else 
                    {
                        colorString = c.Name;
                    }
                }
                else 
                {
                    /*int*/ let r;
                    /*int*/ let g;
                    /*int*/ let b;
                    c.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                    colorString = (() =>
                    {
                        var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(1, 3);
                        $handler.AppendLiteral("#");
                        $handler.AppendFormatted$8($.$box(r, $.$spc.System.Int32), null, "X2");
                        $handler.AppendFormatted$8($.$box(g, $.$spc.System.Int32), null, "X2");
                        $handler.AppendFormatted$8($.$box(b, $.$spc.System.Int32), null, "X2");
                        return $handler.ToStringAndClear();
                    })();
                }
                return colorString;
            }
            static /*void */ InitializeHtmlSysColorTable()
            {
                $.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable = (() =>
                {
                    //new $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)()
                    const $t1 = $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color);
                    const $i1 = new $t1();
                    $i1.$ctor$2(27);
                    $i1.Add("activeborder", $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/));
                    $i1.Add("activecaption", $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/));
                    $i1.Add("appworkspace", $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/));
                    $i1.Add("background", $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/));
                    $i1.Add("buttonface", $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/));
                    $i1.Add("buttonhighlight", $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/));
                    $i1.Add("buttonshadow", $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/));
                    $i1.Add("buttontext", $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/));
                    $i1.Add("captiontext", $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/));
                    $i1.Add("graytext", $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/));
                    $i1.Add("highlight", $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/));
                    $i1.Add("highlighttext", $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/));
                    $i1.Add("inactiveborder", $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/));
                    $i1.Add("inactivecaption", $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/));
                    $i1.Add("inactivecaptiontext", $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/));
                    $i1.Add("infobackground", $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/));
                    $i1.Add("infotext", $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/));
                    $i1.Add("menu", $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/));
                    $i1.Add("menutext", $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/));
                    $i1.Add("scrollbar", $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/));
                    $i1.Add("threeddarkshadow", $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/));
                    $i1.Add("threedface", $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/));
                    $i1.Add("threedhighlight", $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/));
                    $i1.Add("threedlightshadow", $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/));
                    $i1.Add("window", $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/));
                    $i1.Add("windowframe", $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/));
                    $i1.Add("windowtext", $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/));
                    return $i1;
                })();
            }
            static $h = 321193;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":720897,"p":[{"n":"value","p":720897}],"n":"COLORREFToARGB","d":321193,"h":25770124969,"f":40},{"r":655361,"p":[{"n":"c","p":124585}],"n":"ToWin32","d":321193,"h":30065092265,"f":33},{"r":655361,"p":[{"n":"c","p":124585}],"n":"ToOle","d":321193,"h":34360059561,"f":33},{"r":124585,"p":[{"n":"oleColor","p":655361}],"n":"FromOle","d":321193,"h":38655026857,"f":33},{"r":124585,"p":[{"n":"win32Color","p":655361}],"n":"FromWin32","d":321193,"h":42949994153,"f":33},{"r":124585,"p":[{"n":"htmlColor","p":1310721}],"n":"FromHtml","d":321193,"h":47244961449,"f":33},{"r":1310721,"p":[{"n":"c","p":124585}],"n":"ToHtml","d":321193,"h":51539928745,"f":33},{"r":65537,"n":"InitializeHtmlSysColorTable","d":321193,"h":55834896041,"f":34}],"l":[{"t":655361,"n":"COLORREF_RedShift","d":321193,"h":4295288489,"f":40},{"t":655361,"n":"COLORREF_GreenShift","d":321193,"h":8590255785,"f":40},{"t":655361,"n":"COLORREF_BlueShift","d":321193,"h":12885223081,"f":40},{"t":655361,"n":"OleSystemColorFlag","d":321193,"h":17180190377,"f":34},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h,"n":"s_htmlSysColorTable","d":321193,"h":21475157673,"f":34}],"h":321193}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.ColorTranslator`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.KnownColorTable", ($self) => class KnownColorTable
        {
            /*byte*/ static KnownColorKindSystem = 0;
            /*byte*/ static KnownColorKindWeb = 1;
            /*byte*/ static KnownColorKindUnknown = 2;
            static /*ReadOnlySpan<uint> */ get ColorValueTable()
            {
                return this.$cacheColorValueTable ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$2([ 0, 4292137160, 4278211811, 4294967295, 4286611584, 4293716440, 4289505433, 4285624164, 4294045666, 4294967295, 4278190080, 4278210200, 4289505433, 4281428677, 4294967295, 4278190208, 4292137160, 4286224095, 4292404472, 4294967265, 4278190080, 4294967295, 4278190080, 4292137160, 4294967295, 4278190080, 4278190080, 16777215, 4293982463, 4294634455, 4278255615, 4286578644, 4293984255, 4294309340, 4294960324, 4278190080, 4294962125, 4278190335, 4287245282, 4289014314, 4292786311, 4284456608, 4286578432, 4291979550, 4294934352, 4284782061, 4294965468, 4292613180, 4278255615, 4278190219, 4278225803, 4290283019, 4289309097, 4278215680, 4290623339, 4287299723, 4283788079, 4294937600, 4288230092, 4287299584, 4293498490, 4287609999, 4282924427, 4281290575, 4278243025, 4287889619, 4294907027, 4278239231, 4285098345, 4280193279, 4289864226, 4294966000, 4280453922, 4294902015, 4292664540, 4294506751, 4294956800, 4292519200, 4286611584, 4278222848, 4289593135, 4293984240, 4294928820, 4291648604, 4283105410, 4294967280, 4293977740, 4293322490, 4294963445, 4286381056, 4294965965, 4289583334, 4293951616, 4292935679, 4294638290, 4292072403, 4287688336, 4294948545, 4294942842, 4280332970, 4287090426, 4286023833, 4289774814, 4294967264, 4278255360, 4281519410, 4294635750, 4294902015, 4286578688, 4284927402, 4278190285, 4290401747, 4287852763, 4282168177, 4286277870, 4278254234, 4282962380, 4291237253, 4279834992, 4294311930, 4294960353, 4294960309, 4294958765, 4278190208, 4294833638, 4286611456, 4285238819, 4294944000, 4294919424, 4292505814, 4293847210, 4288215960, 4289720046, 4292571283, 4294963157, 4294957753, 4291659071, 4294951115, 4292714717, 4289781990, 4286578816, 4294901760, 4290547599, 4282477025, 4287317267, 4294606962, 4294222944, 4281240407, 4294964718, 4288696877, 4290822336, 4287090411, 4285160141, 4285563024, 4294966010, 4278255487, 4282811060, 4291998860, 4278222976, 4292394968, 4294927175, 4282441936, 4293821166, 4294303411, 4294967295, 4294309365, 4294967040, 4288335154, 4293980400, 4294967295, 4288716960, 4290367978, 4292338930, 4293980400, 4281571839, 4284887961 ]);
            }
            static /*ReadOnlySpan<byte> */ get ColorKindTable()
            {
                return this.$cacheColorKindTable ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 2/*KnownColorKindUnknown*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 1/*KnownColorKindWeb*/ ]);
            }
            static /*ReadOnlySpan<uint> */ get AlternateSystemColors()
            {
                return this.$cacheAlternateSystemColors ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$2([ 0, 4282795590, 4282146680, 4294967295, 4282137660, 4280295456, 4283058762, 4284111450, 4281216558, 4280229663, 4294967295, 4279242768, 4288059030, 4280837300, 4278190080, 4281163695, 4282138433, 4281813850, 4290690750, 4283453500, 4290690750, 4281808695, 4293980400, 4283453520, 4281479730, 4280821800, 4293980400, 4280295456, 4279242768, 4282795590, 4282475650, 4283790230, 4281808695, 4280975570 ]);
            }
            static /*Color */ ArgbToKnownColor(/*uint*/ argb)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((argb & 4278190080/*Color.ARGBAlphaMask*/) === 4278190080/*Color.ARGBAlphaMask*/, "(argb & Color.ARGBAlphaMask) == Color.ARGBAlphaMask");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$sdp.System.Drawing.KnownColorTable.ColorValueTable.Length === $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.Length, "ColorValueTable.Length == ColorKindTable.Length");
                /*ReadOnlySpan<uint>*/ let colorValueTable = $.$sdp.System.Drawing.KnownColorTable.ColorValueTable;
                for(/*int*/ let index = 1; index < colorValueTable.Length; ++index)
                {
                    if ($.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(index).$v === 1/*KnownColorKindWeb*/ && colorValueTable.get_Item(index).$v === argb)
                    {
                        return $.$sdp.System.Drawing.Color.FromKnownColor($.$cast(index, $.$sdp.System.Drawing.KnownColor));
                    }
                }
                return $.$sdp.System.Drawing.Color.FromArgb$1((argb | 0));
            }
            static /*uint */ KnownColorToArgb(/*KnownColor*/ color)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(color > 0 && color <= 175/*KnownColor.RebeccaPurple*/, "color > 0 && color <= KnownColor.RebeccaPurple");
                return $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(color).$v === 0/*KnownColorKindSystem*/ ? $.$sdp.System.Drawing.KnownColorTable.GetSystemColorArgb(color) : $.$sdp.System.Drawing.KnownColorTable.ColorValueTable.get_Item(color).$v;
            }
            static /*uint */ GetAlternateSystemColorArgb(/*KnownColor*/ color)
            {
                /*int*/ let index = color <= 26/*KnownColor.WindowText*/ ? color : ((((((color - 168/*KnownColor.ButtonFace*/) | 0) + 26/*KnownColor.WindowText*/) | 0) + 1) | 0);
                return $.$sdp.System.Drawing.KnownColorTable.AlternateSystemColors.get_Item(index).$v;
            }
            static /*uint */ GetSystemColorArgb(/*KnownColor*/ color)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$sdp.System.Drawing.Color.IsKnownColorSystem(color), "Color.IsKnownColorSystem(color)");
                return (!$.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet) ? $.$sdp.System.Drawing.KnownColorTable.ColorValueTable.get_Item(color).$v : $.$sdp.System.Drawing.KnownColorTable.GetAlternateSystemColorArgb(color);
            }
            static $h = 517801;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"g":{"r":0,"d":0,"h":21475354281,"f":33},"n":"ColorValueTable","d":517801,"h":17180386985,"f":33},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":30065288873,"f":33},"n":"ColorKindTable","d":517801,"h":25770321577,"f":33},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"g":{"r":0,"d":0,"h":38655223465,"f":34},"n":"AlternateSystemColors","d":517801,"h":34360256169,"f":34}],"m":[{"r":124585,"p":[{"n":"argb","p":720897}],"n":"ArgbToKnownColor","d":517801,"h":42950190761,"f":40},{"r":720897,"p":[{"n":"color","p":386729}],"n":"KnownColorToArgb","d":517801,"h":47245158057,"f":33},{"r":720897,"p":[{"n":"color","p":386729}],"n":"GetAlternateSystemColorArgb","d":517801,"h":51540125353,"f":34},{"r":720897,"p":[{"n":"color","p":386729}],"n":"GetSystemColorArgb","d":517801,"h":55835092649,"f":33}],"l":[{"t":393217,"n":"KnownColorKindSystem","d":517801,"h":4295485097,"f":33},{"t":393217,"n":"KnownColorKindWeb","d":517801,"h":8590452393,"f":33},{"t":393217,"n":"KnownColorKindUnknown","d":517801,"h":12885419689,"f":33}],"h":517801}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.KnownColorTable`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.SystemColors", ($self) => class SystemColors
        {
            /*bool*/ static s_useAlternativeColorSet = false;
            static /*Color */ get ActiveBorder()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/);
            }
            static /*Color */ get ActiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/);
            }
            static /*Color */ get ActiveCaptionText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/);
            }
            static /*Color */ get AppWorkspace()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/);
            }
            static /*Color */ get ButtonFace()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(168/*KnownColor.ButtonFace*/);
            }
            static /*Color */ get ButtonHighlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(169/*KnownColor.ButtonHighlight*/);
            }
            static /*Color */ get ButtonShadow()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(170/*KnownColor.ButtonShadow*/);
            }
            static /*Color */ get Control()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/);
            }
            static /*Color */ get ControlDark()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/);
            }
            static /*Color */ get ControlDarkDark()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/);
            }
            static /*Color */ get ControlLight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/);
            }
            static /*Color */ get ControlLightLight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/);
            }
            static /*Color */ get ControlText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/);
            }
            static /*Color */ get Desktop()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/);
            }
            static /*Color */ get GradientActiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(171/*KnownColor.GradientActiveCaption*/);
            }
            static /*Color */ get GradientInactiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(172/*KnownColor.GradientInactiveCaption*/);
            }
            static /*Color */ get GrayText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/);
            }
            static /*Color */ get Highlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/);
            }
            static /*Color */ get HighlightText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/);
            }
            static /*Color */ get HotTrack()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(15/*KnownColor.HotTrack*/);
            }
            static /*Color */ get InactiveBorder()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/);
            }
            static /*Color */ get InactiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/);
            }
            static /*Color */ get InactiveCaptionText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/);
            }
            static /*Color */ get Info()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/);
            }
            static /*Color */ get InfoText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/);
            }
            static /*Color */ get Menu()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/);
            }
            static /*Color */ get MenuBar()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(173/*KnownColor.MenuBar*/);
            }
            static /*Color */ get MenuHighlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(174/*KnownColor.MenuHighlight*/);
            }
            static /*Color */ get MenuText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/);
            }
            static /*Color */ get ScrollBar()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/);
            }
            static /*Color */ get Window()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/);
            }
            static /*Color */ get WindowFrame()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/);
            }
            static /*Color */ get WindowText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/);
            }
            static /*bool */ get UseAlternativeColorSet()
            {
                return $.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet;
            }
            static /*bool */ set UseAlternativeColorSet(value)
            {
                $.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet = value;
            }
            static $h = 976553;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":124585,"g":{"r":0,"d":0,"h":12885878441,"f":33},"n":"ActiveBorder","d":976553,"h":8590911145,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":21475813033,"f":33},"n":"ActiveCaption","d":976553,"h":17180845737,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":30065747625,"f":33},"n":"ActiveCaptionText","d":976553,"h":25770780329,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":38655682217,"f":33},"n":"AppWorkspace","d":976553,"h":34360714921,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":47245616809,"f":33},"n":"ButtonFace","d":976553,"h":42950649513,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":55835551401,"f":33},"n":"ButtonHighlight","d":976553,"h":51540584105,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":64425485993,"f":33},"n":"ButtonShadow","d":976553,"h":60130518697,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":73015420585,"f":33},"n":"Control","d":976553,"h":68720453289,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":81605355177,"f":33},"n":"ControlDark","d":976553,"h":77310387881,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":90195289769,"f":33},"n":"ControlDarkDark","d":976553,"h":85900322473,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":98785224361,"f":33},"n":"ControlLight","d":976553,"h":94490257065,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":107375158953,"f":33},"n":"ControlLightLight","d":976553,"h":103080191657,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":115965093545,"f":33},"n":"ControlText","d":976553,"h":111670126249,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":124555028137,"f":33},"n":"Desktop","d":976553,"h":120260060841,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":133144962729,"f":33},"n":"GradientActiveCaption","d":976553,"h":128849995433,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":141734897321,"f":33},"n":"GradientInactiveCaption","d":976553,"h":137439930025,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":150324831913,"f":33},"n":"GrayText","d":976553,"h":146029864617,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":158914766505,"f":33},"n":"Highlight","d":976553,"h":154619799209,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":167504701097,"f":33},"n":"HighlightText","d":976553,"h":163209733801,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":176094635689,"f":33},"n":"HotTrack","d":976553,"h":171799668393,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":184684570281,"f":33},"n":"InactiveBorder","d":976553,"h":180389602985,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":193274504873,"f":33},"n":"InactiveCaption","d":976553,"h":188979537577,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":201864439465,"f":33},"n":"InactiveCaptionText","d":976553,"h":197569472169,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":210454374057,"f":33},"n":"Info","d":976553,"h":206159406761,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":219044308649,"f":33},"n":"InfoText","d":976553,"h":214749341353,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":227634243241,"f":33},"n":"Menu","d":976553,"h":223339275945,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":236224177833,"f":33},"n":"MenuBar","d":976553,"h":231929210537,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":244814112425,"f":33},"n":"MenuHighlight","d":976553,"h":240519145129,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":253404047017,"f":33},"n":"MenuText","d":976553,"h":249109079721,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":261993981609,"f":33},"n":"ScrollBar","d":976553,"h":257699014313,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":270583916201,"f":33},"n":"Window","d":976553,"h":266288948905,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":279173850793,"f":33},"n":"WindowFrame","d":976553,"h":274878883497,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":287763785385,"f":33},"n":"WindowText","d":976553,"h":283468818089,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":296353719977,"f":33},"s":{"r":0,"d":0,"h":300648687273,"f":33},"n":"UseAlternativeColorSet","d":976553,"h":292058752681,"f":33}],"l":[{"t":262145,"n":"s_useAlternativeColorSet","d":976553,"h":4295943849,"f":40}],"h":976553}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.SystemColors`; }
        });
        
        $asm.$cls("$sdp.System.Experimentals", ($self) => class Experimentals
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static TensorTDiagId = null;
            /*string*/ static SystemColorsDiagId = null;
            /*string*/ static ArmSveDiagId = null;
            /*string*/ static X86BaseDivRemDiagId = null;
            /*string*/ static PostQuantumCryptographyDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.TensorTDiagId = "SYSLIB5001";
                }
                {
                    this.SystemColorsDiagId = "SYSLIB5002";
                }
                {
                    this.ArmSveDiagId = "SYSLIB5003";
                }
                {
                    this.X86BaseDivRemDiagId = "SYSLIB5004";
                }
                {
                    this.PostQuantumCryptographyDiagId = "SYSLIB5006";
                }
            }
            static $h = 1042089;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":1042089,"h":4296009385,"f":40},{"t":1310721,"n":"TensorTDiagId","d":1042089,"h":8590976681,"f":40},{"t":1310721,"n":"SystemColorsDiagId","d":1042089,"h":12885943977,"f":40},{"t":1310721,"n":"ArmSveDiagId","d":1042089,"h":17180911273,"f":40},{"t":1310721,"n":"X86BaseDivRemDiagId","d":1042089,"h":21475878569,"f":40},{"t":1310721,"n":"PostQuantumCryptographyDiagId","d":1042089,"h":25770845865,"f":40}],"h":1042089}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Experimentals`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorTable", ($self) => class ColorTable
        {
            /*Lazy<Dictionary<string, Color>>*/ static s_colorConstants = null;
            static /*Dictionary<string, Color> */ GetColors()
            {
                /*var*/ let colors = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color))().$ctor$3($.$spc.System.StringComparer.OrdinalIgnoreCase);
                $.$sdp.System.Drawing.ColorTable.FillWithProperties(colors, $.$sdp.System.Drawing.Color.$type);
                $.$sdp.System.Drawing.ColorTable.FillWithProperties(colors, $.$sdp.System.Drawing.SystemColors.$type);
                return colors;
            }
            static /*void */ FillWithProperties(/*Dictionary<string, Color>*/ dictionary, /*Type*/ typeWithColors)
            {
                let $i1 = 0;
                let $arr1 = typeWithColors.GetProperties$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/);
                while ($i1 < $arr1.length)
                {
                    let prop = $arr1[$i1++];
                    if ($.$spc.System.Type.op_Equality$1(prop.PropertyType, $.$sdp.System.Drawing.Color.$type))
                    {
                        dictionary.set_Item(prop.Name, $.$cast(prop.GetValue$1(null, null), $.$sdp.System.Drawing.Color));
                    }
                }
            }
            static /*Dictionary<string, Color> */ get Colors()
            {
                return $.$sdp.System.Drawing.ColorTable.s_colorConstants.Value;
            }
            static /*bool */ TryGetNamedColor(/*string*/ name, /*out Color*/ result)
            {
                return $.$sdp.System.Drawing.ColorTable.Colors.TryGetValue(name, result);
            }
            static /*bool */ IsKnownNamedColor(/*string*/ name)
            {
                return $.$sdp.System.Drawing.ColorTable.Colors.TryGetValue(name, $.$discardRef());
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_colorConstants = new ($.$spc.System.Lazy$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)))().$ctor$3(new ($.$spc.System.Func$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)))().$ctor(null, $.$sdp.System.Drawing.ColorTable.GetColors));
                }
            }
            static $h = 255657;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h,"g":{"r":0,"d":0,"h":21475092137,"f":40},"n":"Colors","d":255657,"h":17180124841,"f":40}],"m":[{"r":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h,"n":"GetColors","d":255657,"h":8590190249,"f":34},{"r":65537,"p":[{"n":"dictionary","p":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h},{"n":"typeWithColors","p":142606337}],"n":"FillWithProperties","d":255657,"h":12885157545,"f":34},{"r":262145,"p":[{"n":"name","p":1310721},{"n":"result","p":124585,"f":2}],"n":"TryGetNamedColor","d":255657,"h":25770059433,"f":40},{"r":262145,"p":[{"n":"name","p":1310721}],"n":"IsKnownNamedColor","d":255657,"h":30065026729,"f":40}],"l":[{"t":$.$spc.System.Lazy$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)).$h,"n":"s_colorConstants","d":255657,"h":4295222953,"f":34}],"h":255657}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.ColorTable`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorConverterCommon", ($self) => class ColorConverterCommon
        {
            static /*Color */ ConvertFromString(/*string*/ strValue, /*CultureInfo*/ culture)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(culture !== null, "culture != null");
                /*string*/ let text = $.$spc.System.String.Trim.call(strValue);
                if (text.length === 0)
                {
                    return $.$sdp.System.Drawing.Color.Empty;
                }
                {
                    /*Color*/ let c;
                    if ($.$sdp.System.Drawing.ColorTable.TryGetNamedColor(text, $.$ref(() => c, ($v) => c = $v, $.$sdp.System.Drawing.Color)))
                    {
                        return c;
                    }
                }
                /*char*/ let sep = $.$spc.System.String.get_Chars.call(culture.TextInfo.ListSeparator, 0);
                if (!$.$spc.System.String.Contains$2.call(text, sep))
                {
                    if (text.length >= 2 && ($.$spc.System.String.get_Chars.call(text, 0) === /*'*/ 39 || $.$spc.System.String.get_Chars.call(text, 0) === /*\"*/ 34) && $.$spc.System.String.get_Chars.call(text, 0) === $.$spc.System.String.get_Chars.call(text, ((text.length - 1) | 0)))
                    {
                        /*string*/ let colorName = $.$spc.System.String.Substring$1.call(text, 1, ((text.length - 2) | 0));
                        return $.$sdp.System.Drawing.Color.FromName(colorName);
                    }
                    else if ((text.length === 7 && $.$spc.System.String.get_Chars.call(text, 0) === /*#*/ 35) || (text.length === 8 && ($.$spc.System.String.StartsWith.call(text, "0x") || $.$spc.System.String.StartsWith.call(text, "0X"))) || (text.length === 8 && ($.$spc.System.String.StartsWith.call(text, "&h") || $.$spc.System.String.StartsWith.call(text, "&H"))))
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$1(((4278190080 | ($.$sdp.System.Drawing.ColorConverterCommon.IntFromString($.$spc.System.String.op_Implicit(text), culture) >>> 0)) | 0)));
                    }
                }
                /*ReadOnlySpan<char>*/ let textSpan = $.$spc.System.String.op_Implicit(text);
                /*Span<Range>*/ let tokens = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Range, 5, null);
                return (() =>
                {
                    let $switch1 = $.$spc.System.MemoryExtensions.Split$2(textSpan, tokens, sep, 0);
                    if ($switch1 === 1)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$1($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture)));
                    }
                    if ($switch1 === 3)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$4($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(1).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(2).$v], culture)));
                    }
                    if ($switch1 === 4)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$2($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(1).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(2).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(3).$v], culture)));
                    }
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sdp.System.SR.Format($.$sdp.System.SR.InvalidColor, text));
                })();
            }
            static /*Color */ PossibleKnownColor(/*Color*/ color)
            {
                /*int*/ let targetARGB = color.ToArgb();
                var $en2 = $.$sdp.System.Drawing.ColorTable.Colors.Values.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current;
                    {
                        if (c.ToArgb() === targetARGB)
                        {
                            return c;
                        }
                    }
                }
                return color;
            }
            static /*int */ IntFromString(/*ReadOnlySpan<char>*/ text, /*CultureInfo*/ culture)
            {
                text = $.$spc.System.MemoryExtensions.Trim$10(text);
                try
                {
                    if (text.get_Item(0).$v === /*#*/ 35)
                    {
                        return $.$spc.System.Convert.ToInt32$18($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(text.Slice(1)), 16);
                    }
                    else if ($.$spc.System.MemoryExtensions.StartsWith$5(text, $.$spc.System.String.op_Implicit("0x"), 5/*StringComparison.OrdinalIgnoreCase*/) || $.$spc.System.MemoryExtensions.StartsWith$5(text, $.$spc.System.String.op_Implicit("&h"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spc.System.Convert.ToInt32$18($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(text.Slice(2)), 16);
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(culture !== null, "culture != null");
                        /*var*/ let formatInfo = $.$cast(culture.GetFormat($.$spc.System.Globalization.NumberFormatInfo.$type), $.$spc.System.Globalization.NumberFormatInfo);
                        return $.$spc.System.Int32.Parse$5(text, formatInfo);
                    }
                }
                catch(e)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$11($.$sdp.System.SR.Format$1($.$sdp.System.SR.ConvertInvalidPrimitive, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(text), "Int32"), e);
                }
            }
            static $h = 190121;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":124585,"p":[{"n":"strValue","p":1310721},{"n":"culture","p":51118081}],"n":"ConvertFromString","d":190121,"h":4295157417,"f":33},{"r":124585,"p":[{"n":"color","p":124585}],"n":"PossibleKnownColor","d":190121,"h":8590124713,"f":34},{"r":655361,"p":[{"n":"text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"culture","p":51118081}],"n":"IntFromString","d":190121,"h":12885092009,"f":34}],"h":190121}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.ColorConverterCommon`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Point", ($self) => class Point extends $.$spc.System.ValueType
        {
            /*Point*/ static Empty;
            /*int*/  get x() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set x(value) { this.$setField(0, $.$spc.System.Int32, value); }
            /*int*/  get y() { return this.$getField(4, $.$spc.System.Int32); }
            /*int*/  set y(value) { this.$setField(4, $.$spc.System.Int32, value); }
            $ctor$2(/*int*/ x, /*int*/ y)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                }
                return this;
            }
            $ctor$3(/*Size*/ sz)
            {
                super.$ctor$1();
                {
                    this.x = sz.Width;
                    this.y = sz.Height;
                }
                return this;
            }
            $ctor$4(/*int*/ dw)
            {
                super.$ctor$1();
                {
                    this.x = $.$sdp.System.Drawing.Point.LowInt16(dw);
                    this.y = $.$sdp.System.Drawing.Point.HighInt16(dw);
                }
                return this;
            }
            /*bool */ get IsEmpty()
            {
                return this.x === 0 && this.y === 0;
            }
            /*int */ get X()
            {
                return this.x;
            }
            /*int */ set X(value)
            {
                this.x = value;
            }
            /*int */ get Y()
            {
                return this.y;
            }
            /*int */ set Y(value)
            {
                this.y = value;
            }
            static /*PointF */ op_Implicit(/*Point*/ p)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(p.X, p.Y);
            }
            static /*Size */ op_Explicit(/*Point*/ p)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(p.X, p.Y);
            }
            static /*Point */ op_Addition(/*Point*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.Point.Add(pt.Clone(), sz.Clone());
            }
            static /*Point */ op_Subtraction(/*Point*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.Point.Subtract(pt.Clone(), sz.Clone());
            }
            static /*bool */ op_Equality(/*Point*/ left, /*Point*/ right)
            {
                return left.X === right.X && left.Y === right.Y;
            }
            static /*bool */ op_Inequality(/*Point*/ left, /*Point*/ right)
            {
                return !($.$sdp.System.Drawing.Point.op_Equality(left, right));
            }
            static /*Point */ Add(/*Point*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(((pt.X + sz.Width) | 0), ((pt.Y + sz.Height) | 0));
            }
            static /*Point */ Subtract(/*Point*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(((pt.X - sz.Width) | 0), ((pt.Y - sz.Height) | 0));
            }
            static /*Point */ Ceiling(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2($.$cast(Math.ceil(value.X), $.$spc.System.Int32), $.$cast(Math.ceil(value.Y), $.$spc.System.Int32));
            }
            static /*Point */ Truncate(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2($.$cast(value.X, $.$spc.System.Int32), $.$cast(value.Y, $.$spc.System.Int32));
            }
            static /*Point */ Round(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2($.$cast($.$spc.System.Math.Round$4(value.X), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Y), $.$spc.System.Int32));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Point) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Point));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Point.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Point*/ other)
            {
                return $.$sdp.System.Drawing.Point.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Int32, $.$spc.System.Int32, this.X, this.Y);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Point.GetHashCode.apply(this, arguments); }
            /*void */ Offset(/*int*/ dx, /*int*/ dy)
            {
                //unchecked
                {
                    this.X += dx;
                    this.Y += dy;
                }
            }
            /*void */ Offset$1(/*Point*/ p)
            {
                return this.Offset(p.X, p.Y);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Point.ToString.apply(this, arguments); }
            static /*short */ HighInt16(/*int*/ n)
            {
                return $.$cast(((n >> 16) & 65535), $.$spc.System.Int16);
            }
            static /*short */ LowInt16(/*int*/ n)
            {
                return $.$cast((n & 65535), $.$spc.System.Int16);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Point>.Equals(System.Drawing.Point)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$5()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Point);
                }
            }
            static $h = 583337;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360321705,"f":1},"n":"IsEmpty","d":583337,"h":30065354409,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":42950256297,"f":1},"s":{"r":0,"d":0,"h":47245223593,"f":1},"n":"X","d":583337,"h":38655289001,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55835158185,"f":1},"s":{"r":0,"d":0,"h":60130125481,"f":1},"n":"Y","d":583337,"h":51540190889,"f":1}],"m":[{"r":583337,"p":[{"n":"pt","p":583337},{"n":"sz","p":845481}],"n":"Add","d":583337,"h":90194896553,"f":33},{"r":583337,"p":[{"n":"pt","p":583337},{"n":"sz","p":845481}],"n":"Subtract","d":583337,"h":94489863849,"f":33},{"r":583337,"p":[{"n":"value","p":648873}],"n":"Ceiling","d":583337,"h":98784831145,"f":33},{"r":583337,"p":[{"n":"value","p":648873}],"n":"Truncate","d":583337,"h":103079798441,"f":33},{"r":583337,"p":[{"n":"value","p":648873}],"n":"Round","d":583337,"h":107374765737,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":583337,"h":111669733033,"f":32769},{"r":262145,"p":[{"n":"other","p":583337}],"n":"Equals","o":"@$2","d":583337,"h":115964700329,"f":1},{"r":655361,"n":"GetHashCode","d":583337,"h":120259667625,"f":32769},{"r":65537,"p":[{"n":"dx","p":655361},{"n":"dy","p":655361}],"n":"Offset","d":583337,"h":124554634921,"f":1},{"r":65537,"p":[{"n":"p","p":583337}],"n":"Offset","o":"@$1","d":583337,"h":128849602217,"f":1},{"r":1310721,"n":"ToString","d":583337,"h":133144569513,"f":32769},{"r":524289,"p":[{"n":"n","p":655361}],"n":"HighInt16","d":583337,"h":137439536809,"f":34},{"r":524289,"p":[{"n":"n","p":655361}],"n":"LowInt16","d":583337,"h":141734504105,"f":34}],"l":[{"t":583337,"n":"Empty","d":583337,"h":4295550633,"f":33},{"t":655361,"n":"x","d":583337,"h":8590517929,"f":2},{"t":655361,"n":"y","d":583337,"h":12885485225,"f":2}],"c":[{"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":".ctor","o":"$ctor$2","d":583337,"h":17180452521,"f":1},{"p":[{"n":"sz","p":845481}],"n":".ctor","o":"$ctor$3","d":583337,"h":21475419817,"f":1},{"p":[{"n":"dw","p":655361}],"n":".ctor","o":"$ctor$4","d":583337,"h":25770387113,"f":1},{"n":".ctor","o":"$ctor$5","d":583337,"h":146029471401,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Point).$h],"h":583337,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1496073,"c":17181365257,"a":[{"v":"System.Drawing.PointConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Point) ]; }
            static get $fullName() { return `System.Drawing.Point`; }
        });
        
        $asm.$str("$sdp.System.Drawing.PointF", ($self) => class PointF extends $.$spc.System.ValueType
        {
            /*PointF*/ static Empty;
            /*float*/  get x() { return this.$getField(0, $.$spc.System.Single); }
            /*float*/  set x(value) { this.$setField(0, $.$spc.System.Single, value); }
            /*float*/  get y() { return this.$getField(4, $.$spc.System.Single); }
            /*float*/  set y(value) { this.$setField(4, $.$spc.System.Single, value); }
            $ctor$2(/*float*/ x, /*float*/ y)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                }
                return this;
            }
            $ctor$3(/*Vector2*/ vector)
            {
                super.$ctor$1();
                {
                    this.x = vector.X;
                    this.y = vector.Y;
                }
                return this;
            }
            /*Vector2 */ ToVector2()
            {
                return new $.$spc.System.Numerics.Vector2().$ctor$3(this.x, this.y);
            }
            /*bool */ get IsEmpty()
            {
                return this.x === 0 && this.y === 0;
            }
            /*float */ get X()
            {
                return this.x;
            }
            /*float */ set X(value)
            {
                this.x = value;
            }
            /*float */ get Y()
            {
                return this.y;
            }
            /*float */ set Y(value)
            {
                this.y = value;
            }
            static /*Vector2 */ op_Explicit(/*PointF*/ point)
            {
                return point.ToVector2();
            }
            static /*PointF */ op_Explicit$1(/*Vector2*/ vector)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$3(vector.Clone());
            }
            static /*PointF */ op_Addition(/*PointF*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Add(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Subtraction(/*PointF*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Subtract(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Addition$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Add$1(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Subtraction$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Subtract$1(pt.Clone(), sz.Clone());
            }
            static /*bool */ op_Equality(/*PointF*/ left, /*PointF*/ right)
            {
                return left.X === right.X && left.Y === right.Y;
            }
            static /*bool */ op_Inequality(/*PointF*/ left, /*PointF*/ right)
            {
                return !($.$sdp.System.Drawing.PointF.op_Equality(left, right));
            }
            static /*PointF */ Add(/*PointF*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X + sz.Width, pt.Y + sz.Height);
            }
            static /*PointF */ Subtract(/*PointF*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X - sz.Width, pt.Y - sz.Height);
            }
            static /*PointF */ Add$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X + sz.Width, pt.Y + sz.Height);
            }
            static /*PointF */ Subtract$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X - sz.Width, pt.Y - sz.Height);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.PointF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.PointF));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.PointF.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*PointF*/ other)
            {
                return $.$sdp.System.Drawing.PointF.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Single.GetHashCode.call(this.X), $.$spc.System.Single.GetHashCode.call(this.Y));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.PointF.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.x}, Y=${this.y}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.PointF.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.PointF>.Equals(System.Drawing.PointF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.PointF);
                }
            }
            static $h = 648873;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360387241,"f":1},"n":"IsEmpty","d":648873,"h":30065419945,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":42950321833,"f":1},"s":{"r":0,"d":0,"h":47245289129,"f":1},"n":"X","d":648873,"h":38655354537,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":55835223721,"f":1},"s":{"r":0,"d":0,"h":60130191017,"f":1},"n":"Y","d":648873,"h":51540256425,"f":1}],"m":[{"r":70582273,"n":"ToVector2","d":648873,"h":25770452649,"f":1},{"r":648873,"p":[{"n":"pt","p":648873},{"n":"sz","p":845481}],"n":"Add","d":648873,"h":98784896681,"f":33},{"r":648873,"p":[{"n":"pt","p":648873},{"n":"sz","p":845481}],"n":"Subtract","d":648873,"h":103079863977,"f":33},{"r":648873,"p":[{"n":"pt","p":648873},{"n":"sz","p":911017}],"n":"Add","o":"@$1","d":648873,"h":107374831273,"f":33},{"r":648873,"p":[{"n":"pt","p":648873},{"n":"sz","p":911017}],"n":"Subtract","o":"@$1","d":648873,"h":111669798569,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":648873,"h":115964765865,"f":32769},{"r":262145,"p":[{"n":"other","p":648873}],"n":"Equals","o":"@$2","d":648873,"h":120259733161,"f":1},{"r":655361,"n":"GetHashCode","d":648873,"h":124554700457,"f":32769},{"r":1310721,"n":"ToString","d":648873,"h":128849667753,"f":32769}],"l":[{"t":648873,"n":"Empty","d":648873,"h":4295616169,"f":33},{"t":1114113,"n":"x","d":648873,"h":8590583465,"f":2},{"t":1114113,"n":"y","d":648873,"h":12885550761,"f":2}],"c":[{"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":".ctor","o":"$ctor$2","d":648873,"h":17180518057,"f":1},{"p":[{"n":"vector","p":70582273}],"n":".ctor","o":"$ctor$3","d":648873,"h":21475485353,"f":1},{"n":".ctor","o":"$ctor$4","d":648873,"h":133144635049,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.PointF).$h],"h":648873,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.PointF) ]; }
            static get $fullName() { return `System.Drawing.PointF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.RectangleF", ($self) => class RectangleF extends $.$spc.System.ValueType
        {
            /*RectangleF*/ static Empty;
            /*float*/  get x() { return this.$getField(0, $.$spc.System.Single); }
            /*float*/  set x(value) { this.$setField(0, $.$spc.System.Single, value); }
            /*float*/  get y() { return this.$getField(4, $.$spc.System.Single); }
            /*float*/  set y(value) { this.$setField(4, $.$spc.System.Single, value); }
            /*float*/  get width() { return this.$getField(8, $.$spc.System.Single); }
            /*float*/  set width(value) { this.$setField(8, $.$spc.System.Single, value); }
            /*float*/  get height() { return this.$getField(12, $.$spc.System.Single); }
            /*float*/  set height(value) { this.$setField(12, $.$spc.System.Single, value); }
            $ctor$2(/*float*/ x, /*float*/ y, /*float*/ width, /*float*/ height)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            $ctor$3(/*PointF*/ location, /*SizeF*/ size)
            {
                super.$ctor$1();
                {
                    this.x = location.X;
                    this.y = location.Y;
                    this.width = size.Width;
                    this.height = size.Height;
                }
                return this;
            }
            $ctor$4(/*Vector4*/ vector)
            {
                super.$ctor$1();
                {
                    this.x = vector.X;
                    this.y = vector.Y;
                    this.width = vector.Z;
                    this.height = vector.W;
                }
                return this;
            }
            /*Vector4 */ ToVector4()
            {
                return new $.$spc.System.Numerics.Vector4().$ctor$5(this.x, this.y, this.width, this.height);
            }
            static /*Vector4 */ op_Explicit(/*RectangleF*/ rectangle)
            {
                return rectangle.ToVector4();
            }
            static /*RectangleF */ op_Explicit$1(/*Vector4*/ vector)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$4(vector.Clone());
            }
            static /*RectangleF */ FromLTRB(/*float*/ left, /*float*/ top, /*float*/ right, /*float*/ bottom)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$2(left, top, right - left, bottom - top);
            }
            /*PointF */ get Location()
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(this.X, this.Y);
            }
            /*PointF */ set Location(value)
            {
                this.X = value.X;
                this.Y = value.Y;
            }
            /*SizeF */ get Size()
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(this.Width, this.Height);
            }
            /*SizeF */ set Size(value)
            {
                this.Width = value.Width;
                this.Height = value.Height;
            }
            /*float */ get X()
            {
                return this.x;
            }
            /*float */ set X(value)
            {
                this.x = value;
            }
            /*float */ get Y()
            {
                return this.y;
            }
            /*float */ set Y(value)
            {
                this.y = value;
            }
            /*float */ get Width()
            {
                return this.width;
            }
            /*float */ set Width(value)
            {
                this.width = value;
            }
            /*float */ get Height()
            {
                return this.height;
            }
            /*float */ set Height(value)
            {
                this.height = value;
            }
            /*float */ get Left()
            {
                return this.X;
            }
            /*float */ get Top()
            {
                return this.Y;
            }
            /*float */ get Right()
            {
                return this.X + this.Width;
            }
            /*float */ get Bottom()
            {
                return this.Y + this.Height;
            }
            /*bool */ get IsEmpty()
            {
                return (this.Width <= 0) || (this.Height <= 0);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.RectangleF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.RectangleF));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.RectangleF.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*RectangleF*/ other)
            {
                return $.$sdp.System.Drawing.RectangleF.op_Equality(this, other);
            }
            static /*bool */ op_Equality(/*RectangleF*/ left, /*RectangleF*/ right)
            {
                return left.X === right.X && left.Y === right.Y && left.Width === right.Width && left.Height === right.Height;
            }
            static /*bool */ op_Inequality(/*RectangleF*/ left, /*RectangleF*/ right)
            {
                return !($.$sdp.System.Drawing.RectangleF.op_Equality(left, right));
            }
            /*bool */ Contains(/*float*/ x, /*float*/ y)
            {
                return this.X <= x && x < this.X + this.Width && this.Y <= y && y < this.Y + this.Height;
            }
            /*bool */ Contains$1(/*PointF*/ pt)
            {
                return this.Contains(pt.X, pt.Y);
            }
            /*bool */ Contains$2(/*RectangleF*/ rect)
            {
                return (this.X <= rect.X) && (rect.X + rect.Width <= this.X + this.Width) && (this.Y <= rect.Y) && (rect.Y + rect.Height <= this.Y + this.Height);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$3($.$spc.System.Single, $.$spc.System.Single, $.$spc.System.Single, $.$spc.System.Single, this.X, this.Y, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.RectangleF.GetHashCode.apply(this, arguments); }
            /*void */ Inflate(/*float*/ x, /*float*/ y)
            {
                this.X -= x;
                this.Y -= y;
                this.Width += 2 * x;
                this.Height += 2 * y;
            }
            /*void */ Inflate$1(/*SizeF*/ size)
            {
                return this.Inflate(size.Width, size.Height);
            }
            static /*RectangleF */ Inflate$2(/*RectangleF*/ rect, /*float*/ x, /*float*/ y)
            {
                /*RectangleF*/ let r = rect;
                r.Inflate(x, y);
                return r;
            }
            /*void */ Intersect(/*RectangleF*/ rect)
            {
                /*RectangleF*/ let result = $.$sdp.System.Drawing.RectangleF.Intersect$1(rect.Clone(), this);
                this.X = result.X;
                this.Y = result.Y;
                this.Width = result.Width;
                this.Height = result.Height;
            }
            static /*RectangleF */ Intersect$1(/*RectangleF*/ a, /*RectangleF*/ b)
            {
                /*float*/ let x1 = $.$spc.System.Math.Max$8(a.X, b.X);
                /*float*/ let x2 = $.$spc.System.Math.Min$8(a.X + a.Width, b.X + b.Width);
                /*float*/ let y1 = $.$spc.System.Math.Max$8(a.Y, b.Y);
                /*float*/ let y2 = $.$spc.System.Math.Min$8(a.Y + a.Height, b.Y + b.Height);
                if (x2 >= x1 && y2 >= y1)
                {
                    return new $.$sdp.System.Drawing.RectangleF().$ctor$2(x1, y1, x2 - x1, y2 - y1);
                }
                return $.$sdp.System.Drawing.RectangleF.Empty;
            }
            /*bool */ IntersectsWith(/*RectangleF*/ rect)
            {
                return (rect.X < this.X + this.Width) && (this.X < rect.X + rect.Width) && (rect.Y < this.Y + this.Height) && (this.Y < rect.Y + rect.Height);
            }
            static /*RectangleF */ Union(/*RectangleF*/ a, /*RectangleF*/ b)
            {
                /*float*/ let x1 = $.$spc.System.Math.Min$8(a.X, b.X);
                /*float*/ let x2 = $.$spc.System.Math.Max$8(a.X + a.Width, b.X + b.Width);
                /*float*/ let y1 = $.$spc.System.Math.Min$8(a.Y, b.Y);
                /*float*/ let y2 = $.$spc.System.Math.Max$8(a.Y + a.Height, b.Y + b.Height);
                return new $.$sdp.System.Drawing.RectangleF().$ctor$2(x1, y1, x2 - x1, y2 - y1);
            }
            /*void */ Offset(/*PointF*/ pos)
            {
                return this.Offset$1(pos.X, pos.Y);
            }
            /*void */ Offset$1(/*float*/ x, /*float*/ y)
            {
                this.X += x;
                this.Y += y;
            }
            static /*RectangleF */ op_Implicit(/*Rectangle*/ r)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$2(r.X, r.Y, r.Width, r.Height);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y},Width=${this.Width},Height=${this.Height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.RectangleF.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.RectangleF>.Equals(System.Drawing.RectangleF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$5()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.RectangleF);
                }
            }
            static $h = 779945;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":648873,"g":{"r":0,"d":0,"h":60130322089,"f":1},"s":{"r":0,"d":0,"h":64425289385,"f":1},"n":"Location","d":779945,"h":55835354793,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":911017,"g":{"r":0,"d":0,"h":73015223977,"f":1},"s":{"r":0,"d":0,"h":77310191273,"f":1},"n":"Size","d":779945,"h":68720256681,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":85900125865,"f":1},"s":{"r":0,"d":0,"h":90195093161,"f":1},"n":"X","d":779945,"h":81605158569,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":98785027753,"f":1},"s":{"r":0,"d":0,"h":103079995049,"f":1},"n":"Y","d":779945,"h":94490060457,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":111669929641,"f":1},"s":{"r":0,"d":0,"h":115964896937,"f":1},"n":"Width","d":779945,"h":107374962345,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":124554831529,"f":1},"s":{"r":0,"d":0,"h":128849798825,"f":1},"n":"Height","d":779945,"h":120259864233,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":137439733417,"f":1},"n":"Left","d":779945,"h":133144766121,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":146029668009,"f":1},"n":"Top","d":779945,"h":141734700713,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":154619602601,"f":1},"n":"Right","d":779945,"h":150324635305,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":163209537193,"f":1},"n":"Bottom","d":779945,"h":158914569897,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":262145,"g":{"r":0,"d":0,"h":171799471785,"f":1},"n":"IsEmpty","d":779945,"h":167504504489,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]}],"m":[{"r":70713345,"n":"ToVector4","d":779945,"h":38655485609,"f":1},{"r":779945,"p":[{"n":"left","p":1114113},{"n":"top","p":1114113},{"n":"right","p":1114113},{"n":"bottom","p":1114113}],"n":"FromLTRB","d":779945,"h":51540387497,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":779945,"h":176094439081,"f":32769},{"r":262145,"p":[{"n":"other","p":779945}],"n":"Equals","o":"@$2","d":779945,"h":180389406377,"f":1},{"r":262145,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Contains","d":779945,"h":193274308265,"f":1},{"r":262145,"p":[{"n":"pt","p":648873}],"n":"Contains","o":"@$1","d":779945,"h":197569275561,"f":1},{"r":262145,"p":[{"n":"rect","p":779945}],"n":"Contains","o":"@$2","d":779945,"h":201864242857,"f":1},{"r":655361,"n":"GetHashCode","d":779945,"h":206159210153,"f":32769},{"r":65537,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Inflate","d":779945,"h":210454177449,"f":1},{"r":65537,"p":[{"n":"size","p":911017}],"n":"Inflate","o":"@$1","d":779945,"h":214749144745,"f":1},{"r":779945,"p":[{"n":"rect","p":779945},{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Inflate","o":"@$2","d":779945,"h":219044112041,"f":33},{"r":65537,"p":[{"n":"rect","p":779945}],"n":"Intersect","d":779945,"h":223339079337,"f":1},{"r":779945,"p":[{"n":"a","p":779945},{"n":"b","p":779945}],"n":"Intersect","o":"@$1","d":779945,"h":227634046633,"f":33},{"r":262145,"p":[{"n":"rect","p":779945}],"n":"IntersectsWith","d":779945,"h":231929013929,"f":1},{"r":779945,"p":[{"n":"a","p":779945},{"n":"b","p":779945}],"n":"Union","d":779945,"h":236223981225,"f":33},{"r":65537,"p":[{"n":"pos","p":648873}],"n":"Offset","d":779945,"h":240518948521,"f":1},{"r":65537,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Offset","o":"@$1","d":779945,"h":244813915817,"f":1},{"r":1310721,"n":"ToString","d":779945,"h":253403850409,"f":32769}],"l":[{"t":779945,"n":"Empty","d":779945,"h":4295747241,"f":33},{"t":1114113,"n":"x","d":779945,"h":8590714537,"f":2},{"t":1114113,"n":"y","d":779945,"h":12885681833,"f":2},{"t":1114113,"n":"width","d":779945,"h":17180649129,"f":2},{"t":1114113,"n":"height","d":779945,"h":21475616425,"f":2}],"c":[{"p":[{"n":"x","p":1114113},{"n":"y","p":1114113},{"n":"width","p":1114113},{"n":"height","p":1114113}],"n":".ctor","o":"$ctor$2","d":779945,"h":25770583721,"f":1},{"p":[{"n":"location","p":648873},{"n":"size","p":911017}],"n":".ctor","o":"$ctor$3","d":779945,"h":30065551017,"f":1},{"p":[{"n":"vector","p":70713345}],"n":".ctor","o":"$ctor$4","d":779945,"h":34360518313,"f":1},{"n":".ctor","o":"$ctor$5","d":779945,"h":257698817705,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.RectangleF).$h],"h":779945,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.RectangleF) ]; }
            static get $fullName() { return `System.Drawing.RectangleF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Size", ($self) => class Size extends $.$spc.System.ValueType
        {
            /*Size*/ static Empty;
            /*int*/  get width() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set width(value) { this.$setField(0, $.$spc.System.Int32, value); }
            /*int*/  get height() { return this.$getField(4, $.$spc.System.Int32); }
            /*int*/  set height(value) { this.$setField(4, $.$spc.System.Int32, value); }
            $ctor$2(/*Point*/ pt)
            {
                super.$ctor$1();
                {
                    this.width = pt.X;
                    this.height = pt.Y;
                }
                return this;
            }
            $ctor$3(/*int*/ width, /*int*/ height)
            {
                super.$ctor$1();
                {
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            static /*SizeF */ op_Implicit(/*Size*/ p)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(p.Width, p.Height);
            }
            static /*Size */ op_Addition(/*Size*/ sz1, /*Size*/ sz2)
            {
                return $.$sdp.System.Drawing.Size.Add(sz1.Clone(), sz2.Clone());
            }
            static /*Size */ op_Subtraction(/*Size*/ sz1, /*Size*/ sz2)
            {
                return $.$sdp.System.Drawing.Size.Subtract(sz1.Clone(), sz2.Clone());
            }
            static /*Size */ op_Multiply(/*int*/ left, /*Size*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply(right.Clone(), left);
            }
            static /*Size */ op_Multiply$1(/*Size*/ left, /*int*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply(left.Clone(), right);
            }
            static /*Size */ op_Division(/*Size*/ left, /*int*/ right)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.trunc(left.width / right), $.trunc(left.height / right));
            }
            static /*SizeF */ op_Multiply$2(/*float*/ left, /*Size*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply$1(right.Clone(), left);
            }
            static /*SizeF */ op_Multiply$3(/*Size*/ left, /*float*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply$1(left.Clone(), right);
            }
            static /*SizeF */ op_Division$1(/*Size*/ left, /*float*/ right)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(left.width / right, left.height / right);
            }
            static /*bool */ op_Equality(/*Size*/ sz1, /*Size*/ sz2)
            {
                return sz1.Width === sz2.Width && sz1.Height === sz2.Height;
            }
            static /*bool */ op_Inequality(/*Size*/ sz1, /*Size*/ sz2)
            {
                return !($.$sdp.System.Drawing.Size.op_Equality(sz1, sz2));
            }
            static /*Point */ op_Explicit(/*Size*/ size)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(size.Width, size.Height);
            }
            /*bool */ get IsEmpty()
            {
                return this.width === 0 && this.height === 0;
            }
            /*int */ get Width()
            {
                return this.width;
            }
            /*int */ set Width(value)
            {
                this.width = value;
            }
            /*int */ get Height()
            {
                return this.height;
            }
            /*int */ set Height(value)
            {
                this.height = value;
            }
            static /*Size */ Add(/*Size*/ sz1, /*Size*/ sz2)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((sz1.Width + sz2.Width) | 0), ((sz1.Height + sz2.Height) | 0));
            }
            static /*Size */ Ceiling(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast(Math.ceil(value.Width), $.$spc.System.Int32), $.$cast(Math.ceil(value.Height), $.$spc.System.Int32));
            }
            static /*Size */ Subtract(/*Size*/ sz1, /*Size*/ sz2)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((sz1.Width - sz2.Width) | 0), ((sz1.Height - sz2.Height) | 0));
            }
            static /*Size */ Truncate(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast(value.Width, $.$spc.System.Int32), $.$cast(value.Height, $.$spc.System.Int32));
            }
            static /*Size */ Round(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast($.$spc.System.Math.Round$4(value.Width), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Height), $.$spc.System.Int32));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Size) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Size));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Size.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Size*/ other)
            {
                return $.$sdp.System.Drawing.Size.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Int32, $.$spc.System.Int32, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Size.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{Width=${this.width}, Height=${this.height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Size.ToString.apply(this, arguments); }
            static /*Size */ Multiply(/*Size*/ size, /*int*/ multiplier)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((size.width * multiplier) | 0), ((size.height * multiplier) | 0));
            }
            static /*SizeF */ Multiply$1(/*Size*/ size, /*float*/ multiplier)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(size.width * multiplier, size.height * multiplier);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Size>.Equals(System.Drawing.Size)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Size);
                }
            }
            static $h = 845481;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":81605224105,"f":1},"n":"IsEmpty","d":845481,"h":77310256809,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":90195158697,"f":1},"s":{"r":0,"d":0,"h":94490125993,"f":1},"n":"Width","d":845481,"h":85900191401,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103080060585,"f":1},"s":{"r":0,"d":0,"h":107375027881,"f":1},"n":"Height","d":845481,"h":98785093289,"f":1}],"m":[{"r":845481,"p":[{"n":"sz1","p":845481},{"n":"sz2","p":845481}],"n":"Add","d":845481,"h":111669995177,"f":33},{"r":845481,"p":[{"n":"value","p":911017}],"n":"Ceiling","d":845481,"h":115964962473,"f":33},{"r":845481,"p":[{"n":"sz1","p":845481},{"n":"sz2","p":845481}],"n":"Subtract","d":845481,"h":120259929769,"f":33},{"r":845481,"p":[{"n":"value","p":911017}],"n":"Truncate","d":845481,"h":124554897065,"f":33},{"r":845481,"p":[{"n":"value","p":911017}],"n":"Round","d":845481,"h":128849864361,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":845481,"h":133144831657,"f":32769},{"r":262145,"p":[{"n":"other","p":845481}],"n":"Equals","o":"@$2","d":845481,"h":137439798953,"f":1},{"r":655361,"n":"GetHashCode","d":845481,"h":141734766249,"f":32769},{"r":1310721,"n":"ToString","d":845481,"h":146029733545,"f":32769},{"r":845481,"p":[{"n":"size","p":845481},{"n":"multiplier","p":655361}],"n":"Multiply","d":845481,"h":150324700841,"f":34},{"r":911017,"p":[{"n":"size","p":845481},{"n":"multiplier","p":1114113}],"n":"Multiply","o":"@$1","d":845481,"h":154619668137,"f":34}],"l":[{"t":845481,"n":"Empty","d":845481,"h":4295812777,"f":33},{"t":655361,"n":"width","d":845481,"h":8590780073,"f":2},{"t":655361,"n":"height","d":845481,"h":12885747369,"f":2}],"c":[{"p":[{"n":"pt","p":583337}],"n":".ctor","o":"$ctor$2","d":845481,"h":17180714665,"f":1},{"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":".ctor","o":"$ctor$3","d":845481,"h":21475681961,"f":1},{"n":".ctor","o":"$ctor$4","d":845481,"h":158914635433,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Size).$h],"h":845481,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1496073,"c":17181365257,"a":[{"v":"System.Drawing.SizeConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Size) ]; }
            static get $fullName() { return `System.Drawing.Size`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Rectangle", ($self) => class Rectangle extends $.$spc.System.ValueType
        {
            /*Rectangle*/ static Empty;
            /*int*/  get x() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set x(value) { this.$setField(0, $.$spc.System.Int32, value); }
            /*int*/  get y() { return this.$getField(4, $.$spc.System.Int32); }
            /*int*/  set y(value) { this.$setField(4, $.$spc.System.Int32, value); }
            /*int*/  get width() { return this.$getField(8, $.$spc.System.Int32); }
            /*int*/  set width(value) { this.$setField(8, $.$spc.System.Int32, value); }
            /*int*/  get height() { return this.$getField(12, $.$spc.System.Int32); }
            /*int*/  set height(value) { this.$setField(12, $.$spc.System.Int32, value); }
            $ctor$2(/*int*/ x, /*int*/ y, /*int*/ width, /*int*/ height)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            $ctor$3(/*Point*/ location, /*Size*/ size)
            {
                super.$ctor$1();
                {
                    this.x = location.X;
                    this.y = location.Y;
                    this.width = size.Width;
                    this.height = size.Height;
                }
                return this;
            }
            static /*Rectangle */ FromLTRB(/*int*/ left, /*int*/ top, /*int*/ right, /*int*/ bottom)
            {
                return new $.$sdp.System.Drawing.Rectangle().$ctor$2(left, top, ((right - left) | 0), ((bottom - top) | 0));
            }
            /*Point */ get Location()
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(this.X, this.Y);
            }
            /*Point */ set Location(value)
            {
                this.X = value.X;
                this.Y = value.Y;
            }
            /*Size */ get Size()
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(this.Width, this.Height);
            }
            /*Size */ set Size(value)
            {
                this.Width = value.Width;
                this.Height = value.Height;
            }
            /*int */ get X()
            {
                return this.x;
            }
            /*int */ set X(value)
            {
                this.x = value;
            }
            /*int */ get Y()
            {
                return this.y;
            }
            /*int */ set Y(value)
            {
                this.y = value;
            }
            /*int */ get Width()
            {
                return this.width;
            }
            /*int */ set Width(value)
            {
                this.width = value;
            }
            /*int */ get Height()
            {
                return this.height;
            }
            /*int */ set Height(value)
            {
                this.height = value;
            }
            /*int */ get Left()
            {
                return this.X;
            }
            /*int */ get Top()
            {
                return this.Y;
            }
            /*int */ get Right()
            {
                return ((this.X + this.Width) | 0);
            }
            /*int */ get Bottom()
            {
                return ((this.Y + this.Height) | 0);
            }
            /*bool */ get IsEmpty()
            {
                return this.height === 0 && this.width === 0 && this.x === 0 && this.y === 0;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Rectangle) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Rectangle));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Rectangle.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Rectangle*/ other)
            {
                return $.$sdp.System.Drawing.Rectangle.op_Equality(this, other);
            }
            static /*bool */ op_Equality(/*Rectangle*/ left, /*Rectangle*/ right)
            {
                return left.X === right.X && left.Y === right.Y && left.Width === right.Width && left.Height === right.Height;
            }
            static /*bool */ op_Inequality(/*Rectangle*/ left, /*Rectangle*/ right)
            {
                return !($.$sdp.System.Drawing.Rectangle.op_Equality(left, right));
            }
            static /*Rectangle */ Ceiling(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2($.$cast(Math.ceil(value.X), $.$spc.System.Int32), $.$cast(Math.ceil(value.Y), $.$spc.System.Int32), $.$cast(Math.ceil(value.Width), $.$spc.System.Int32), $.$cast(Math.ceil(value.Height), $.$spc.System.Int32));
                }
            }
            static /*Rectangle */ Truncate(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2($.$cast(value.X, $.$spc.System.Int32), $.$cast(value.Y, $.$spc.System.Int32), $.$cast(value.Width, $.$spc.System.Int32), $.$cast(value.Height, $.$spc.System.Int32));
                }
            }
            static /*Rectangle */ Round(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2($.$cast($.$spc.System.Math.Round$4(value.X), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Y), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Width), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Height), $.$spc.System.Int32));
                }
            }
            /*bool */ Contains(/*int*/ x, /*int*/ y)
            {
                return this.X <= x && x < ((this.X + this.Width) | 0) && this.Y <= y && y < ((this.Y + this.Height) | 0);
            }
            /*bool */ Contains$1(/*Point*/ pt)
            {
                return this.Contains(pt.X, pt.Y);
            }
            /*bool */ Contains$2(/*Rectangle*/ rect)
            {
                return (this.X <= rect.X) && (((rect.X + rect.Width) | 0) <= ((this.X + this.Width) | 0)) && (this.Y <= rect.Y) && (((rect.Y + rect.Height) | 0) <= ((this.Y + this.Height) | 0));
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$3($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, this.X, this.Y, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Rectangle.GetHashCode.apply(this, arguments); }
            /*void */ Inflate(/*int*/ width, /*int*/ height)
            {
                //unchecked
                {
                    this.X -= width;
                    this.Y -= height;
                    this.Width += ((2 * width) | 0);
                    this.Height += ((2 * height) | 0);
                }
            }
            /*void */ Inflate$1(/*Size*/ size)
            {
                return this.Inflate(size.Width, size.Height);
            }
            static /*Rectangle */ Inflate$2(/*Rectangle*/ rect, /*int*/ x, /*int*/ y)
            {
                /*Rectangle*/ let r = rect;
                r.Inflate(x, y);
                return r;
            }
            /*void */ Intersect(/*Rectangle*/ rect)
            {
                /*Rectangle*/ let result = $.$sdp.System.Drawing.Rectangle.Intersect$1(rect.Clone(), this);
                this.X = result.X;
                this.Y = result.Y;
                this.Width = result.Width;
                this.Height = result.Height;
            }
            static /*Rectangle */ Intersect$1(/*Rectangle*/ a, /*Rectangle*/ b)
            {
                /*int*/ let x1 = $.$spc.System.Math.Max$4(a.X, b.X);
                /*int*/ let x2 = $.$spc.System.Math.Min$4(((a.X + a.Width) | 0), ((b.X + b.Width) | 0));
                /*int*/ let y1 = $.$spc.System.Math.Max$4(a.Y, b.Y);
                /*int*/ let y2 = $.$spc.System.Math.Min$4(((a.Y + a.Height) | 0), ((b.Y + b.Height) | 0));
                if (x2 >= x1 && y2 >= y1)
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2(x1, y1, ((x2 - x1) | 0), ((y2 - y1) | 0));
                }
                return $.$sdp.System.Drawing.Rectangle.Empty;
            }
            /*bool */ IntersectsWith(/*Rectangle*/ rect)
            {
                return (rect.X < ((this.X + this.Width) | 0)) && (this.X < ((rect.X + rect.Width) | 0)) && (rect.Y < ((this.Y + this.Height) | 0)) && (this.Y < ((rect.Y + rect.Height) | 0));
            }
            static /*Rectangle */ Union(/*Rectangle*/ a, /*Rectangle*/ b)
            {
                /*int*/ let x1 = $.$spc.System.Math.Min$4(a.X, b.X);
                /*int*/ let x2 = $.$spc.System.Math.Max$4(((a.X + a.Width) | 0), ((b.X + b.Width) | 0));
                /*int*/ let y1 = $.$spc.System.Math.Min$4(a.Y, b.Y);
                /*int*/ let y2 = $.$spc.System.Math.Max$4(((a.Y + a.Height) | 0), ((b.Y + b.Height) | 0));
                return new $.$sdp.System.Drawing.Rectangle().$ctor$2(x1, y1, ((x2 - x1) | 0), ((y2 - y1) | 0));
            }
            /*void */ Offset(/*Point*/ pos)
            {
                return this.Offset$1(pos.X, pos.Y);
            }
            /*void */ Offset$1(/*int*/ x, /*int*/ y)
            {
                //unchecked
                {
                    this.X += x;
                    this.Y += y;
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y},Width=${this.Width},Height=${this.Height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Rectangle.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Rectangle>.Equals(System.Drawing.Rectangle)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Rectangle);
                }
            }
            static $h = 714409;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":583337,"g":{"r":0,"d":0,"h":42950387369,"f":1},"s":{"r":0,"d":0,"h":47245354665,"f":1},"n":"Location","d":714409,"h":38655420073,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":845481,"g":{"r":0,"d":0,"h":55835289257,"f":1},"s":{"r":0,"d":0,"h":60130256553,"f":1},"n":"Size","d":714409,"h":51540321961,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":68720191145,"f":1},"s":{"r":0,"d":0,"h":73015158441,"f":1},"n":"X","d":714409,"h":64425223849,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":81605093033,"f":1},"s":{"r":0,"d":0,"h":85900060329,"f":1},"n":"Y","d":714409,"h":77310125737,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":94489994921,"f":1},"s":{"r":0,"d":0,"h":98784962217,"f":1},"n":"Width","d":714409,"h":90195027625,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":107374896809,"f":1},"s":{"r":0,"d":0,"h":111669864105,"f":1},"n":"Height","d":714409,"h":103079929513,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":120259798697,"f":1},"n":"Left","d":714409,"h":115964831401,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":128849733289,"f":1},"n":"Top","d":714409,"h":124554765993,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":137439667881,"f":1},"n":"Right","d":714409,"h":133144700585,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":146029602473,"f":1},"n":"Bottom","d":714409,"h":141734635177,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":262145,"g":{"r":0,"d":0,"h":154619537065,"f":1},"n":"IsEmpty","d":714409,"h":150324569769,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]}],"m":[{"r":714409,"p":[{"n":"left","p":655361},{"n":"top","p":655361},{"n":"right","p":655361},{"n":"bottom","p":655361}],"n":"FromLTRB","d":714409,"h":34360452777,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":714409,"h":158914504361,"f":32769},{"r":262145,"p":[{"n":"other","p":714409}],"n":"Equals","o":"@$2","d":714409,"h":163209471657,"f":1},{"r":714409,"p":[{"n":"value","p":779945}],"n":"Ceiling","d":714409,"h":176094373545,"f":33},{"r":714409,"p":[{"n":"value","p":779945}],"n":"Truncate","d":714409,"h":180389340841,"f":33},{"r":714409,"p":[{"n":"value","p":779945}],"n":"Round","d":714409,"h":184684308137,"f":33},{"r":262145,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Contains","d":714409,"h":188979275433,"f":1},{"r":262145,"p":[{"n":"pt","p":583337}],"n":"Contains","o":"@$1","d":714409,"h":193274242729,"f":1},{"r":262145,"p":[{"n":"rect","p":714409}],"n":"Contains","o":"@$2","d":714409,"h":197569210025,"f":1},{"r":655361,"n":"GetHashCode","d":714409,"h":201864177321,"f":32769},{"r":65537,"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":"Inflate","d":714409,"h":206159144617,"f":1},{"r":65537,"p":[{"n":"size","p":845481}],"n":"Inflate","o":"@$1","d":714409,"h":210454111913,"f":1},{"r":714409,"p":[{"n":"rect","p":714409},{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Inflate","o":"@$2","d":714409,"h":214749079209,"f":33},{"r":65537,"p":[{"n":"rect","p":714409}],"n":"Intersect","d":714409,"h":219044046505,"f":1},{"r":714409,"p":[{"n":"a","p":714409},{"n":"b","p":714409}],"n":"Intersect","o":"@$1","d":714409,"h":223339013801,"f":33},{"r":262145,"p":[{"n":"rect","p":714409}],"n":"IntersectsWith","d":714409,"h":227633981097,"f":1},{"r":714409,"p":[{"n":"a","p":714409},{"n":"b","p":714409}],"n":"Union","d":714409,"h":231928948393,"f":33},{"r":65537,"p":[{"n":"pos","p":583337}],"n":"Offset","d":714409,"h":236223915689,"f":1},{"r":65537,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Offset","o":"@$1","d":714409,"h":240518882985,"f":1},{"r":1310721,"n":"ToString","d":714409,"h":244813850281,"f":32769}],"l":[{"t":714409,"n":"Empty","d":714409,"h":4295681705,"f":33},{"t":655361,"n":"x","d":714409,"h":8590649001,"f":2},{"t":655361,"n":"y","d":714409,"h":12885616297,"f":2},{"t":655361,"n":"width","d":714409,"h":17180583593,"f":2},{"t":655361,"n":"height","d":714409,"h":21475550889,"f":2}],"c":[{"p":[{"n":"x","p":655361},{"n":"y","p":655361},{"n":"width","p":655361},{"n":"height","p":655361}],"n":".ctor","o":"$ctor$2","d":714409,"h":25770518185,"f":1},{"p":[{"n":"location","p":583337},{"n":"size","p":845481}],"n":".ctor","o":"$ctor$3","d":714409,"h":30065485481,"f":1},{"n":".ctor","o":"$ctor$4","d":714409,"h":249108817577,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Rectangle).$h],"h":714409,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1496073,"c":17181365257,"a":[{"v":"System.Drawing.RectangleConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Rectangle) ]; }
            static get $fullName() { return `System.Drawing.Rectangle`; }
        });
        
        $asm.$str("$sdp.System.Drawing.SizeF", ($self) => class SizeF extends $.$spc.System.ValueType
        {
            /*SizeF*/ static Empty;
            /*float*/  get width() { return this.$getField(0, $.$spc.System.Single); }
            /*float*/  set width(value) { this.$setField(0, $.$spc.System.Single, value); }
            /*float*/  get height() { return this.$getField(4, $.$spc.System.Single); }
            /*float*/  set height(value) { this.$setField(4, $.$spc.System.Single, value); }
            $ctor$2(/*SizeF*/ size)
            {
                super.$ctor$1();
                {
                    this.width = size.width;
                    this.height = size.height;
                }
                return this;
            }
            $ctor$3(/*PointF*/ pt)
            {
                super.$ctor$1();
                {
                    this.width = pt.X;
                    this.height = pt.Y;
                }
                return this;
            }
            $ctor$4(/*Vector2*/ vector)
            {
                super.$ctor$1();
                {
                    this.width = vector.X;
                    this.height = vector.Y;
                }
                return this;
            }
            /*Vector2 */ ToVector2()
            {
                return new $.$spc.System.Numerics.Vector2().$ctor$3(this.width, this.height);
            }
            $ctor$5(/*float*/ width, /*float*/ height)
            {
                super.$ctor$1();
                {
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            static /*Vector2 */ op_Explicit(/*SizeF*/ size)
            {
                return size.ToVector2();
            }
            static /*SizeF */ op_Explicit$1(/*Vector2*/ vector)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$4(vector.Clone());
            }
            static /*SizeF */ op_Addition(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return $.$sdp.System.Drawing.SizeF.Add(sz1.Clone(), sz2.Clone());
            }
            static /*SizeF */ op_Subtraction(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return $.$sdp.System.Drawing.SizeF.Subtract(sz1.Clone(), sz2.Clone());
            }
            static /*SizeF */ op_Multiply(/*float*/ left, /*SizeF*/ right)
            {
                return $.$sdp.System.Drawing.SizeF.Multiply(right.Clone(), left);
            }
            static /*SizeF */ op_Multiply$1(/*SizeF*/ left, /*float*/ right)
            {
                return $.$sdp.System.Drawing.SizeF.Multiply(left.Clone(), right);
            }
            static /*SizeF */ op_Division(/*SizeF*/ left, /*float*/ right)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(left.width / right, left.height / right);
            }
            static /*bool */ op_Equality(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return sz1.Width === sz2.Width && sz1.Height === sz2.Height;
            }
            static /*bool */ op_Inequality(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return !($.$sdp.System.Drawing.SizeF.op_Equality(sz1, sz2));
            }
            static /*PointF */ op_Explicit$2(/*SizeF*/ size)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(size.Width, size.Height);
            }
            /*bool */ get IsEmpty()
            {
                return this.width === 0 && this.height === 0;
            }
            /*float */ get Width()
            {
                return this.width;
            }
            /*float */ set Width(value)
            {
                this.width = value;
            }
            /*float */ get Height()
            {
                return this.height;
            }
            /*float */ set Height(value)
            {
                this.height = value;
            }
            static /*SizeF */ Add(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(sz1.Width + sz2.Width, sz1.Height + sz2.Height);
            }
            static /*SizeF */ Subtract(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(sz1.Width - sz2.Width, sz1.Height - sz2.Height);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.SizeF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.SizeF));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.SizeF.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*SizeF*/ other)
            {
                return $.$sdp.System.Drawing.SizeF.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Single, $.$spc.System.Single, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.SizeF.GetHashCode.apply(this, arguments); }
            /*PointF */ ToPointF()
            {
                return $.$sdp.System.Drawing.SizeF.op_Explicit$2(this);
            }
            /*Size */ ToSize()
            {
                return $.$sdp.System.Drawing.Size.Truncate(this);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{Width=${this.width}, Height=${this.height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.SizeF.ToString.apply(this, arguments); }
            static /*SizeF */ Multiply(/*SizeF*/ size, /*float*/ multiplier)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(size.width * multiplier, size.height * multiplier);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.SizeF>.Equals(System.Drawing.SizeF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$6()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.SizeF);
                }
            }
            static $h = 911017;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":85900256937,"f":1},"n":"IsEmpty","d":911017,"h":81605289641,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":94490191529,"f":1},"s":{"r":0,"d":0,"h":98785158825,"f":1},"n":"Width","d":911017,"h":90195224233,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":107375093417,"f":1},"s":{"r":0,"d":0,"h":111670060713,"f":1},"n":"Height","d":911017,"h":103080126121,"f":1}],"m":[{"r":70582273,"n":"ToVector2","d":911017,"h":30065682089,"f":1},{"r":911017,"p":[{"n":"sz1","p":911017},{"n":"sz2","p":911017}],"n":"Add","d":911017,"h":115965028009,"f":33},{"r":911017,"p":[{"n":"sz1","p":911017},{"n":"sz2","p":911017}],"n":"Subtract","d":911017,"h":120259995305,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":911017,"h":124554962601,"f":32769},{"r":262145,"p":[{"n":"other","p":911017}],"n":"Equals","o":"@$2","d":911017,"h":128849929897,"f":1},{"r":655361,"n":"GetHashCode","d":911017,"h":133144897193,"f":32769},{"r":648873,"n":"ToPointF","d":911017,"h":137439864489,"f":1},{"r":845481,"n":"ToSize","d":911017,"h":141734831785,"f":1},{"r":1310721,"n":"ToString","d":911017,"h":146029799081,"f":32769},{"r":911017,"p":[{"n":"size","p":911017},{"n":"multiplier","p":1114113}],"n":"Multiply","d":911017,"h":150324766377,"f":34}],"l":[{"t":911017,"n":"Empty","d":911017,"h":4295878313,"f":33},{"t":1114113,"n":"width","d":911017,"h":8590845609,"f":2},{"t":1114113,"n":"height","d":911017,"h":12885812905,"f":2}],"c":[{"p":[{"n":"size","p":911017}],"n":".ctor","o":"$ctor$2","d":911017,"h":17180780201,"f":1},{"p":[{"n":"pt","p":648873}],"n":".ctor","o":"$ctor$3","d":911017,"h":21475747497,"f":1},{"p":[{"n":"vector","p":70582273}],"n":".ctor","o":"$ctor$4","d":911017,"h":25770714793,"f":1},{"p":[{"n":"width","p":1114113},{"n":"height","p":1114113}],"n":".ctor","o":"$ctor$5","d":911017,"h":34360649385,"f":1},{"n":".ctor","o":"$ctor$6","d":911017,"h":154619733673,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.SizeF).$h],"h":911017,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1496073,"c":17181365257,"a":[{"v":"System.Drawing.SizeFConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.SizeF) ]; }
            static get $fullName() { return `System.Drawing.SizeF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Color", ($self) => class Color extends $.$spc.System.ValueType
        {
            /*Color*/ static Empty;
            static /*Color */ get Transparent()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(27/*KnownColor.Transparent*/);
            }
            static /*Color */ get AliceBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(28/*KnownColor.AliceBlue*/);
            }
            static /*Color */ get AntiqueWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(29/*KnownColor.AntiqueWhite*/);
            }
            static /*Color */ get Aqua()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(30/*KnownColor.Aqua*/);
            }
            static /*Color */ get Aquamarine()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(31/*KnownColor.Aquamarine*/);
            }
            static /*Color */ get Azure()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(32/*KnownColor.Azure*/);
            }
            static /*Color */ get Beige()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(33/*KnownColor.Beige*/);
            }
            static /*Color */ get Bisque()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(34/*KnownColor.Bisque*/);
            }
            static /*Color */ get Black()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(35/*KnownColor.Black*/);
            }
            static /*Color */ get BlanchedAlmond()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(36/*KnownColor.BlanchedAlmond*/);
            }
            static /*Color */ get Blue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(37/*KnownColor.Blue*/);
            }
            static /*Color */ get BlueViolet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(38/*KnownColor.BlueViolet*/);
            }
            static /*Color */ get Brown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(39/*KnownColor.Brown*/);
            }
            static /*Color */ get BurlyWood()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(40/*KnownColor.BurlyWood*/);
            }
            static /*Color */ get CadetBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(41/*KnownColor.CadetBlue*/);
            }
            static /*Color */ get Chartreuse()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(42/*KnownColor.Chartreuse*/);
            }
            static /*Color */ get Chocolate()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(43/*KnownColor.Chocolate*/);
            }
            static /*Color */ get Coral()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(44/*KnownColor.Coral*/);
            }
            static /*Color */ get CornflowerBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(45/*KnownColor.CornflowerBlue*/);
            }
            static /*Color */ get Cornsilk()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(46/*KnownColor.Cornsilk*/);
            }
            static /*Color */ get Crimson()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(47/*KnownColor.Crimson*/);
            }
            static /*Color */ get Cyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(48/*KnownColor.Cyan*/);
            }
            static /*Color */ get DarkBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(49/*KnownColor.DarkBlue*/);
            }
            static /*Color */ get DarkCyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(50/*KnownColor.DarkCyan*/);
            }
            static /*Color */ get DarkGoldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(51/*KnownColor.DarkGoldenrod*/);
            }
            static /*Color */ get DarkGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(52/*KnownColor.DarkGray*/);
            }
            static /*Color */ get DarkGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(53/*KnownColor.DarkGreen*/);
            }
            static /*Color */ get DarkKhaki()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(54/*KnownColor.DarkKhaki*/);
            }
            static /*Color */ get DarkMagenta()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(55/*KnownColor.DarkMagenta*/);
            }
            static /*Color */ get DarkOliveGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(56/*KnownColor.DarkOliveGreen*/);
            }
            static /*Color */ get DarkOrange()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(57/*KnownColor.DarkOrange*/);
            }
            static /*Color */ get DarkOrchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(58/*KnownColor.DarkOrchid*/);
            }
            static /*Color */ get DarkRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(59/*KnownColor.DarkRed*/);
            }
            static /*Color */ get DarkSalmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(60/*KnownColor.DarkSalmon*/);
            }
            static /*Color */ get DarkSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(61/*KnownColor.DarkSeaGreen*/);
            }
            static /*Color */ get DarkSlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(62/*KnownColor.DarkSlateBlue*/);
            }
            static /*Color */ get DarkSlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(63/*KnownColor.DarkSlateGray*/);
            }
            static /*Color */ get DarkTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(64/*KnownColor.DarkTurquoise*/);
            }
            static /*Color */ get DarkViolet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(65/*KnownColor.DarkViolet*/);
            }
            static /*Color */ get DeepPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(66/*KnownColor.DeepPink*/);
            }
            static /*Color */ get DeepSkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(67/*KnownColor.DeepSkyBlue*/);
            }
            static /*Color */ get DimGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(68/*KnownColor.DimGray*/);
            }
            static /*Color */ get DodgerBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(69/*KnownColor.DodgerBlue*/);
            }
            static /*Color */ get Firebrick()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(70/*KnownColor.Firebrick*/);
            }
            static /*Color */ get FloralWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(71/*KnownColor.FloralWhite*/);
            }
            static /*Color */ get ForestGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(72/*KnownColor.ForestGreen*/);
            }
            static /*Color */ get Fuchsia()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(73/*KnownColor.Fuchsia*/);
            }
            static /*Color */ get Gainsboro()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(74/*KnownColor.Gainsboro*/);
            }
            static /*Color */ get GhostWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(75/*KnownColor.GhostWhite*/);
            }
            static /*Color */ get Gold()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(76/*KnownColor.Gold*/);
            }
            static /*Color */ get Goldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(77/*KnownColor.Goldenrod*/);
            }
            static /*Color */ get Gray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(78/*KnownColor.Gray*/);
            }
            static /*Color */ get Green()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(79/*KnownColor.Green*/);
            }
            static /*Color */ get GreenYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(80/*KnownColor.GreenYellow*/);
            }
            static /*Color */ get Honeydew()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(81/*KnownColor.Honeydew*/);
            }
            static /*Color */ get HotPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(82/*KnownColor.HotPink*/);
            }
            static /*Color */ get IndianRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(83/*KnownColor.IndianRed*/);
            }
            static /*Color */ get Indigo()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(84/*KnownColor.Indigo*/);
            }
            static /*Color */ get Ivory()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(85/*KnownColor.Ivory*/);
            }
            static /*Color */ get Khaki()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(86/*KnownColor.Khaki*/);
            }
            static /*Color */ get Lavender()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(87/*KnownColor.Lavender*/);
            }
            static /*Color */ get LavenderBlush()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(88/*KnownColor.LavenderBlush*/);
            }
            static /*Color */ get LawnGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(89/*KnownColor.LawnGreen*/);
            }
            static /*Color */ get LemonChiffon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(90/*KnownColor.LemonChiffon*/);
            }
            static /*Color */ get LightBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(91/*KnownColor.LightBlue*/);
            }
            static /*Color */ get LightCoral()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(92/*KnownColor.LightCoral*/);
            }
            static /*Color */ get LightCyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(93/*KnownColor.LightCyan*/);
            }
            static /*Color */ get LightGoldenrodYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(94/*KnownColor.LightGoldenrodYellow*/);
            }
            static /*Color */ get LightGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(96/*KnownColor.LightGreen*/);
            }
            static /*Color */ get LightGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(95/*KnownColor.LightGray*/);
            }
            static /*Color */ get LightPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(97/*KnownColor.LightPink*/);
            }
            static /*Color */ get LightSalmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(98/*KnownColor.LightSalmon*/);
            }
            static /*Color */ get LightSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(99/*KnownColor.LightSeaGreen*/);
            }
            static /*Color */ get LightSkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(100/*KnownColor.LightSkyBlue*/);
            }
            static /*Color */ get LightSlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(101/*KnownColor.LightSlateGray*/);
            }
            static /*Color */ get LightSteelBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(102/*KnownColor.LightSteelBlue*/);
            }
            static /*Color */ get LightYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(103/*KnownColor.LightYellow*/);
            }
            static /*Color */ get Lime()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(104/*KnownColor.Lime*/);
            }
            static /*Color */ get LimeGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(105/*KnownColor.LimeGreen*/);
            }
            static /*Color */ get Linen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(106/*KnownColor.Linen*/);
            }
            static /*Color */ get Magenta()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(107/*KnownColor.Magenta*/);
            }
            static /*Color */ get Maroon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(108/*KnownColor.Maroon*/);
            }
            static /*Color */ get MediumAquamarine()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(109/*KnownColor.MediumAquamarine*/);
            }
            static /*Color */ get MediumBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(110/*KnownColor.MediumBlue*/);
            }
            static /*Color */ get MediumOrchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(111/*KnownColor.MediumOrchid*/);
            }
            static /*Color */ get MediumPurple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(112/*KnownColor.MediumPurple*/);
            }
            static /*Color */ get MediumSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(113/*KnownColor.MediumSeaGreen*/);
            }
            static /*Color */ get MediumSlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(114/*KnownColor.MediumSlateBlue*/);
            }
            static /*Color */ get MediumSpringGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(115/*KnownColor.MediumSpringGreen*/);
            }
            static /*Color */ get MediumTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(116/*KnownColor.MediumTurquoise*/);
            }
            static /*Color */ get MediumVioletRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(117/*KnownColor.MediumVioletRed*/);
            }
            static /*Color */ get MidnightBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(118/*KnownColor.MidnightBlue*/);
            }
            static /*Color */ get MintCream()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(119/*KnownColor.MintCream*/);
            }
            static /*Color */ get MistyRose()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(120/*KnownColor.MistyRose*/);
            }
            static /*Color */ get Moccasin()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(121/*KnownColor.Moccasin*/);
            }
            static /*Color */ get NavajoWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(122/*KnownColor.NavajoWhite*/);
            }
            static /*Color */ get Navy()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(123/*KnownColor.Navy*/);
            }
            static /*Color */ get OldLace()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(124/*KnownColor.OldLace*/);
            }
            static /*Color */ get Olive()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(125/*KnownColor.Olive*/);
            }
            static /*Color */ get OliveDrab()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(126/*KnownColor.OliveDrab*/);
            }
            static /*Color */ get Orange()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(127/*KnownColor.Orange*/);
            }
            static /*Color */ get OrangeRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(128/*KnownColor.OrangeRed*/);
            }
            static /*Color */ get Orchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(129/*KnownColor.Orchid*/);
            }
            static /*Color */ get PaleGoldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(130/*KnownColor.PaleGoldenrod*/);
            }
            static /*Color */ get PaleGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(131/*KnownColor.PaleGreen*/);
            }
            static /*Color */ get PaleTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(132/*KnownColor.PaleTurquoise*/);
            }
            static /*Color */ get PaleVioletRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(133/*KnownColor.PaleVioletRed*/);
            }
            static /*Color */ get PapayaWhip()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(134/*KnownColor.PapayaWhip*/);
            }
            static /*Color */ get PeachPuff()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(135/*KnownColor.PeachPuff*/);
            }
            static /*Color */ get Peru()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(136/*KnownColor.Peru*/);
            }
            static /*Color */ get Pink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(137/*KnownColor.Pink*/);
            }
            static /*Color */ get Plum()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(138/*KnownColor.Plum*/);
            }
            static /*Color */ get PowderBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(139/*KnownColor.PowderBlue*/);
            }
            static /*Color */ get Purple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(140/*KnownColor.Purple*/);
            }
            static /*Color */ get RebeccaPurple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(175/*KnownColor.RebeccaPurple*/);
            }
            static /*Color */ get Red()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(141/*KnownColor.Red*/);
            }
            static /*Color */ get RosyBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(142/*KnownColor.RosyBrown*/);
            }
            static /*Color */ get RoyalBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(143/*KnownColor.RoyalBlue*/);
            }
            static /*Color */ get SaddleBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(144/*KnownColor.SaddleBrown*/);
            }
            static /*Color */ get Salmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(145/*KnownColor.Salmon*/);
            }
            static /*Color */ get SandyBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(146/*KnownColor.SandyBrown*/);
            }
            static /*Color */ get SeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(147/*KnownColor.SeaGreen*/);
            }
            static /*Color */ get SeaShell()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(148/*KnownColor.SeaShell*/);
            }
            static /*Color */ get Sienna()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(149/*KnownColor.Sienna*/);
            }
            static /*Color */ get Silver()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(150/*KnownColor.Silver*/);
            }
            static /*Color */ get SkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(151/*KnownColor.SkyBlue*/);
            }
            static /*Color */ get SlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(152/*KnownColor.SlateBlue*/);
            }
            static /*Color */ get SlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(153/*KnownColor.SlateGray*/);
            }
            static /*Color */ get Snow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(154/*KnownColor.Snow*/);
            }
            static /*Color */ get SpringGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(155/*KnownColor.SpringGreen*/);
            }
            static /*Color */ get SteelBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(156/*KnownColor.SteelBlue*/);
            }
            static /*Color */ get Tan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(157/*KnownColor.Tan*/);
            }
            static /*Color */ get Teal()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(158/*KnownColor.Teal*/);
            }
            static /*Color */ get Thistle()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(159/*KnownColor.Thistle*/);
            }
            static /*Color */ get Tomato()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(160/*KnownColor.Tomato*/);
            }
            static /*Color */ get Turquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(161/*KnownColor.Turquoise*/);
            }
            static /*Color */ get Violet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(162/*KnownColor.Violet*/);
            }
            static /*Color */ get Wheat()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(163/*KnownColor.Wheat*/);
            }
            static /*Color */ get White()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(164/*KnownColor.White*/);
            }
            static /*Color */ get WhiteSmoke()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(165/*KnownColor.WhiteSmoke*/);
            }
            static /*Color */ get Yellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(166/*KnownColor.Yellow*/);
            }
            static /*Color */ get YellowGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(167/*KnownColor.YellowGreen*/);
            }
            /*short*/ static StateKnownColorValid = 1;
            /*short*/ static StateARGBValueValid = 2;
            /*short*/ static StateValueMask = 2;
            /*short*/ static StateNameValid = 8;
            /*long*/ static NotDefinedValue = 0n;
            /*int*/ static ARGBAlphaShift = 24;
            /*int*/ static ARGBRedShift = 16;
            /*int*/ static ARGBGreenShift = 8;
            /*int*/ static ARGBBlueShift = 0;
            /*uint*/ static ARGBAlphaMask = 4278190080;
            /*uint*/ static ARGBRedMask = 16711680;
            /*uint*/ static ARGBGreenMask = 65280;
            /*uint*/ static ARGBBlueMask = 255;
            /*string?*/  get name() { return this.$getField(0, 4); }
            /*string?*/  set name(value) { this.$setField(0, 4, value); }
            /*long*/  get value() { return this.$getField(4, 8); }
            /*long*/  set value(value) { this.$setField(4, 8, value); }
            /*short*/  get knownColor() { return this.$getField(12, 2); }
            /*short*/  set knownColor(value) { this.$setField(12, 2, value); }
            /*short*/  get state() { return this.$getField(14, 2); }
            /*short*/  set state(value) { this.$setField(14, 2, value); }
            $ctor$2(/*KnownColor*/ knownColor)
            {
                super.$ctor$1();
                {
                    this.value = 0n;
                    this.state = 1/*StateKnownColorValid*/;
                    this.name = null;
                    this.knownColor = $.$cast(knownColor, $.$spc.System.Int16);
                }
                return this;
            }
            $ctor$3(/*long*/ value, /*short*/ state, /*string?*/ name, /*KnownColor*/ knownColor)
            {
                super.$ctor$1();
                {
                    this.value = value;
                    this.state = state;
                    this.name = name;
                    this.knownColor = $.$cast(knownColor, $.$spc.System.Int16);
                }
                return this;
            }
            /*byte */ get R()
            {
                return $.$cast((this.Value >> BigInt(16/*ARGBRedShift*/)), $.$spc.System.Byte);
            }
            /*byte */ get G()
            {
                return $.$cast((this.Value >> BigInt(8/*ARGBGreenShift*/)), $.$spc.System.Byte);
            }
            /*byte */ get B()
            {
                return $.$cast((this.Value >> BigInt(0/*ARGBBlueShift*/)), $.$spc.System.Byte);
            }
            /*byte */ get A()
            {
                return $.$cast((this.Value >> BigInt(24/*ARGBAlphaShift*/)), $.$spc.System.Byte);
            }
            /*bool */ get IsKnownColor()
            {
                return (this.state & 1/*StateKnownColorValid*/) !== 0;
            }
            /*bool */ get IsEmpty()
            {
                return this.state === 0;
            }
            /*bool */ get IsNamedColor()
            {
                return ((this.state & 8/*StateNameValid*/) !== 0) || this.IsKnownColor;
            }
            /*bool */ get IsSystemColor()
            {
                return this.IsKnownColor && $.$sdp.System.Drawing.Color.IsKnownColorSystem($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor));
            }
            static /*bool */ IsKnownColorSystem(/*KnownColor*/ knownColor)
            {
                return $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(knownColor).$v === 0/*KnownColorTable.KnownColorKindSystem*/;
            }
            /*string */ get NameAndARGBValue()
            {
                return `{{Name = ${this.Name}, ARGB = (${this.A}, ${this.R}, ${this.G}, ${this.B})}}`;
            }
            /*string */ get Name()
            {
                if ((this.state & 8/*StateNameValid*/) !== 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(this.name, null), "name != null");
                    return this.name;
                }
                if (this.IsKnownColor)
                {
                    /*string*/ let tablename = $.$sdp.System.Drawing.KnownColorNames.KnownColorToName($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor));
                    $.$spc.System.Diagnostics.Debug.Assert$2($.$spc.System.String.op_Inequality(tablename, null), `Could not find known color '${$.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor)}' in the KnownColorTable`);
                    return tablename;
                }
                return $.$spc.System.Int64.ToString$2.call(this.value, "x");
            }
            /*long */ get Value()
            {
                if ((this.state & 2/*StateValueMask*/) !== 0)
                {
                    return this.value;
                }
                if (this.IsKnownColor)
                {
                    return BigInt($.$sdp.System.Drawing.KnownColorTable.KnownColorToArgb($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor)));
                }
                return 0n;
            }
            static /*void */ CheckByte(/*int*/ value, /*string*/ name)
            {
                /*static void*/  function ThrowOutOfByteRange(/*int*/ v, /*string*/ n)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sdp.System.SR.Format$3($.$sdp.System.SR.InvalidEx2BoundArgument, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ n, $.$box(v, $.$spc.System.Int32), $.$box(0/*byte.MinValue*/, $.$spc.System.Byte), $.$box(255/*byte.MaxValue*/, $.$spc.System.Byte) ], null, null)));
                }
                if ((value >>> 0) > 255/*byte.MaxValue*/)
                {
                    ThrowOutOfByteRange(value, name);
                }
            }
            static /*Color */ FromArgb(/*uint*/ argb)
            {
                return new $.$sdp.System.Drawing.Color().$ctor$3(BigInt(argb), 2/*StateARGBValueValid*/, null, $.$cast(0, $.$sdp.System.Drawing.KnownColor));
            }
            static /*Color */ FromArgb$1(/*int*/ argb)
            {
                return $.$sdp.System.Drawing.Color.FromArgb((argb >>> 0));
            }
            static /*Color */ FromArgb$2(/*int*/ alpha, /*int*/ red, /*int*/ green, /*int*/ blue)
            {
                $.$sdp.System.Drawing.Color.CheckByte(alpha, "alpha");
                $.$sdp.System.Drawing.Color.CheckByte(red, "red");
                $.$sdp.System.Drawing.Color.CheckByte(green, "green");
                $.$sdp.System.Drawing.Color.CheckByte(blue, "blue");
                return $.$sdp.System.Drawing.Color.FromArgb(((alpha >>> 0) << 24/*ARGBAlphaShift*/) >>> 0 | ((red >>> 0) << 16/*ARGBRedShift*/) >>> 0 | ((green >>> 0) << 8/*ARGBGreenShift*/) >>> 0 | ((blue >>> 0) << 0/*ARGBBlueShift*/) >>> 0);
            }
            static /*Color */ FromArgb$3(/*int*/ alpha, /*Color*/ baseColor)
            {
                $.$sdp.System.Drawing.Color.CheckByte(alpha, "alpha");
                return $.$sdp.System.Drawing.Color.FromArgb(((alpha >>> 0) << 24/*ARGBAlphaShift*/) >>> 0 | $.$cast(baseColor.Value, $.$spc.System.UInt32) & ~4278190080/*ARGBAlphaMask*/);
            }
            static /*Color */ FromArgb$4(/*int*/ red, /*int*/ green, /*int*/ blue)
            {
                return $.$sdp.System.Drawing.Color.FromArgb$2(255/*byte.MaxValue*/, red, green, blue);
            }
            static /*Color */ FromKnownColor(/*KnownColor*/ color)
            {
                return color <= 0 || color > 175/*KnownColor.RebeccaPurple*/ ? $.$sdp.System.Drawing.Color.FromName($.$spc.System.Enum.ToStringT($.$sdp.System.Drawing.KnownColor, $.$spc.System.UInt32, color)) : new $.$sdp.System.Drawing.Color().$ctor$2(color);
            }
            static /*Color */ FromName(/*string*/ name)
            {
                /*Color*/ let color;
                if ($.$sdp.System.Drawing.ColorTable.TryGetNamedColor(name, $.$ref(() => color, ($v) => color = $v, $.$sdp.System.Drawing.Color)))
                {
                    return color;
                }
                return new $.$sdp.System.Drawing.Color().$ctor$3(0n, 8/*StateNameValid*/, name, $.$cast(0, $.$sdp.System.Drawing.KnownColor));
            }
            /*void */ GetRgbValues(/*out int*/ r, /*out int*/ g, /*out int*/ b)
            {
                /*uint*/ let value = $.$cast(this.Value, $.$spc.System.UInt32);
                r.$v = ((value & 16711680/*ARGBRedMask*/) | 0) >> 16/*ARGBRedShift*/;
                g.$v = ((value & 65280/*ARGBGreenMask*/) | 0) >> 8/*ARGBGreenShift*/;
                b.$v = ((value & 255/*ARGBBlueMask*/) | 0) >> 0/*ARGBBlueShift*/;
            }
            static /*void */ MinMaxRgb(/*out int*/ min, /*out int*/ max, /*int*/ r, /*int*/ g, /*int*/ b)
            {
                if (r > g)
                {
                    max.$v = r;
                    min.$v = g;
                }
                else 
                {
                    max.$v = g;
                    min.$v = r;
                }
                if (b > max.$v)
                {
                    max.$v = b;
                }
                else if (b < min.$v)
                {
                    min.$v = b;
                }
            }
            /*float */ GetBrightness()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$spc.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$spc.System.Int32), r, g, b);
                return (((max + min) | 0)) / (255/*byte.MaxValue*/ * 2);
            }
            /*float */ GetHue()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                if (r === g && g === b)
                {
                    return 0;
                }
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$spc.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$spc.System.Int32), r, g, b);
                /*float*/ let delta = ((max - min) | 0);
                /*float*/ let hue;
                if (r === max)
                {
                    hue = (((g - b) | 0)) / delta;
                }
                else if (g === max)
                {
                    hue = (((b - r) | 0)) / delta + 2;
                }
                else 
                {
                    hue = (((r - g) | 0)) / delta + 4;
                }
                hue *= 60;
                if (hue < 0)
                {
                    hue += 360;
                }
                return hue;
            }
            /*float */ GetSaturation()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                if (r === g && g === b)
                {
                    return 0;
                }
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$spc.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$spc.System.Int32), r, g, b);
                /*int*/ let div = ((max + min) | 0);
                if (div > 255/*byte.MaxValue*/)
                {
                    div = ((((((255/*byte.MaxValue*/ * 2) | 0) - max) | 0) - min) | 0);
                }
                return (((max - min) | 0)) / $.$cast(div, $.$spc.System.Single);
            }
            /*int */ ToArgb()
            {
                return $.$cast(this.Value, $.$spc.System.Int32);
            }
            /*KnownColor */ ToKnownColor()
            {
                return $.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.IsNamedColor ? `${"Color"} [${this.Name}]` : (this.state & 2/*StateValueMask*/) !== 0 ? `${"Color"} [A=${this.A}, R=${this.R}, G=${this.G}, B=${this.B}]` : `${"Color"} [Empty]`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Color.ToString.apply(this, arguments); }
            static /*bool */ op_Equality(/*Color*/ left, /*Color*/ right)
            {
                return left.value === right.value && left.state === right.state && left.knownColor === right.knownColor && $.$spc.System.String.op_Equality(left.name, right.name);
            }
            static /*bool */ op_Inequality(/*Color*/ left, /*Color*/ right)
            {
                return !($.$sdp.System.Drawing.Color.op_Equality(left, right));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$sdp.System.Drawing.Color, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Color.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Color*/ other)
            {
                return $.$sdp.System.Drawing.Color.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                if ($.$spc.System.String.op_Inequality(this.name, null) && !this.IsKnownColor)
                {
                    return $.$spc.System.String.GetHashCode.call(this.name);
                }
                return $.$spc.System.HashCode.Combine$2($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int64.GetHashCode.call(this.value), $.$spc.System.Int16.GetHashCode.call(this.state), $.$spc.System.Int16.GetHashCode.call(this.knownColor));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Color.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Color>.Equals(System.Drawing.Color)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.name = this.name;
                copy.value = this.value;
                copy.knownColor = this.knownColor;
                copy.state = this.state;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.name = null;
                this.value = 0n;
                this.knownColor = 0;
                this.state = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Color);
                }
            }
            static $h = 124585;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":124585,"g":{"r":0,"d":0,"h":12885026473,"f":33},"n":"Transparent","d":124585,"h":8590059177,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":21474961065,"f":33},"n":"AliceBlue","d":124585,"h":17179993769,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":30064895657,"f":33},"n":"AntiqueWhite","d":124585,"h":25769928361,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":38654830249,"f":33},"n":"Aqua","d":124585,"h":34359862953,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":47244764841,"f":33},"n":"Aquamarine","d":124585,"h":42949797545,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":55834699433,"f":33},"n":"Azure","d":124585,"h":51539732137,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":64424634025,"f":33},"n":"Beige","d":124585,"h":60129666729,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":73014568617,"f":33},"n":"Bisque","d":124585,"h":68719601321,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":81604503209,"f":33},"n":"Black","d":124585,"h":77309535913,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":90194437801,"f":33},"n":"BlanchedAlmond","d":124585,"h":85899470505,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":98784372393,"f":33},"n":"Blue","d":124585,"h":94489405097,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":107374306985,"f":33},"n":"BlueViolet","d":124585,"h":103079339689,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":115964241577,"f":33},"n":"Brown","d":124585,"h":111669274281,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":124554176169,"f":33},"n":"BurlyWood","d":124585,"h":120259208873,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":133144110761,"f":33},"n":"CadetBlue","d":124585,"h":128849143465,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":141734045353,"f":33},"n":"Chartreuse","d":124585,"h":137439078057,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":150323979945,"f":33},"n":"Chocolate","d":124585,"h":146029012649,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":158913914537,"f":33},"n":"Coral","d":124585,"h":154618947241,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":167503849129,"f":33},"n":"CornflowerBlue","d":124585,"h":163208881833,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":176093783721,"f":33},"n":"Cornsilk","d":124585,"h":171798816425,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":184683718313,"f":33},"n":"Crimson","d":124585,"h":180388751017,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":193273652905,"f":33},"n":"Cyan","d":124585,"h":188978685609,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":201863587497,"f":33},"n":"DarkBlue","d":124585,"h":197568620201,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":210453522089,"f":33},"n":"DarkCyan","d":124585,"h":206158554793,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":219043456681,"f":33},"n":"DarkGoldenrod","d":124585,"h":214748489385,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":227633391273,"f":33},"n":"DarkGray","d":124585,"h":223338423977,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":236223325865,"f":33},"n":"DarkGreen","d":124585,"h":231928358569,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":244813260457,"f":33},"n":"DarkKhaki","d":124585,"h":240518293161,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":253403195049,"f":33},"n":"DarkMagenta","d":124585,"h":249108227753,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":261993129641,"f":33},"n":"DarkOliveGreen","d":124585,"h":257698162345,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":270583064233,"f":33},"n":"DarkOrange","d":124585,"h":266288096937,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":279172998825,"f":33},"n":"DarkOrchid","d":124585,"h":274878031529,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":287762933417,"f":33},"n":"DarkRed","d":124585,"h":283467966121,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":296352868009,"f":33},"n":"DarkSalmon","d":124585,"h":292057900713,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":304942802601,"f":33},"n":"DarkSeaGreen","d":124585,"h":300647835305,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":313532737193,"f":33},"n":"DarkSlateBlue","d":124585,"h":309237769897,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":322122671785,"f":33},"n":"DarkSlateGray","d":124585,"h":317827704489,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":330712606377,"f":33},"n":"DarkTurquoise","d":124585,"h":326417639081,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":339302540969,"f":33},"n":"DarkViolet","d":124585,"h":335007573673,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":347892475561,"f":33},"n":"DeepPink","d":124585,"h":343597508265,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":356482410153,"f":33},"n":"DeepSkyBlue","d":124585,"h":352187442857,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":365072344745,"f":33},"n":"DimGray","d":124585,"h":360777377449,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":373662279337,"f":33},"n":"DodgerBlue","d":124585,"h":369367312041,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":382252213929,"f":33},"n":"Firebrick","d":124585,"h":377957246633,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":390842148521,"f":33},"n":"FloralWhite","d":124585,"h":386547181225,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":399432083113,"f":33},"n":"ForestGreen","d":124585,"h":395137115817,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":408022017705,"f":33},"n":"Fuchsia","d":124585,"h":403727050409,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":416611952297,"f":33},"n":"Gainsboro","d":124585,"h":412316985001,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":425201886889,"f":33},"n":"GhostWhite","d":124585,"h":420906919593,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":433791821481,"f":33},"n":"Gold","d":124585,"h":429496854185,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":442381756073,"f":33},"n":"Goldenrod","d":124585,"h":438086788777,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":450971690665,"f":33},"n":"Gray","d":124585,"h":446676723369,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":459561625257,"f":33},"n":"Green","d":124585,"h":455266657961,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":468151559849,"f":33},"n":"GreenYellow","d":124585,"h":463856592553,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":476741494441,"f":33},"n":"Honeydew","d":124585,"h":472446527145,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":485331429033,"f":33},"n":"HotPink","d":124585,"h":481036461737,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":493921363625,"f":33},"n":"IndianRed","d":124585,"h":489626396329,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":502511298217,"f":33},"n":"Indigo","d":124585,"h":498216330921,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":511101232809,"f":33},"n":"Ivory","d":124585,"h":506806265513,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":519691167401,"f":33},"n":"Khaki","d":124585,"h":515396200105,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":528281101993,"f":33},"n":"Lavender","d":124585,"h":523986134697,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":536871036585,"f":33},"n":"LavenderBlush","d":124585,"h":532576069289,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":545460971177,"f":33},"n":"LawnGreen","d":124585,"h":541166003881,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":554050905769,"f":33},"n":"LemonChiffon","d":124585,"h":549755938473,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":562640840361,"f":33},"n":"LightBlue","d":124585,"h":558345873065,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":571230774953,"f":33},"n":"LightCoral","d":124585,"h":566935807657,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":579820709545,"f":33},"n":"LightCyan","d":124585,"h":575525742249,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":588410644137,"f":33},"n":"LightGoldenrodYellow","d":124585,"h":584115676841,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":597000578729,"f":33},"n":"LightGreen","d":124585,"h":592705611433,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":605590513321,"f":33},"n":"LightGray","d":124585,"h":601295546025,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":614180447913,"f":33},"n":"LightPink","d":124585,"h":609885480617,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":622770382505,"f":33},"n":"LightSalmon","d":124585,"h":618475415209,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":631360317097,"f":33},"n":"LightSeaGreen","d":124585,"h":627065349801,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":639950251689,"f":33},"n":"LightSkyBlue","d":124585,"h":635655284393,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":648540186281,"f":33},"n":"LightSlateGray","d":124585,"h":644245218985,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":657130120873,"f":33},"n":"LightSteelBlue","d":124585,"h":652835153577,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":665720055465,"f":33},"n":"LightYellow","d":124585,"h":661425088169,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":674309990057,"f":33},"n":"Lime","d":124585,"h":670015022761,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":682899924649,"f":33},"n":"LimeGreen","d":124585,"h":678604957353,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":691489859241,"f":33},"n":"Linen","d":124585,"h":687194891945,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":700079793833,"f":33},"n":"Magenta","d":124585,"h":695784826537,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":708669728425,"f":33},"n":"Maroon","d":124585,"h":704374761129,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":717259663017,"f":33},"n":"MediumAquamarine","d":124585,"h":712964695721,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":725849597609,"f":33},"n":"MediumBlue","d":124585,"h":721554630313,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":734439532201,"f":33},"n":"MediumOrchid","d":124585,"h":730144564905,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":743029466793,"f":33},"n":"MediumPurple","d":124585,"h":738734499497,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":751619401385,"f":33},"n":"MediumSeaGreen","d":124585,"h":747324434089,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":760209335977,"f":33},"n":"MediumSlateBlue","d":124585,"h":755914368681,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":768799270569,"f":33},"n":"MediumSpringGreen","d":124585,"h":764504303273,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":777389205161,"f":33},"n":"MediumTurquoise","d":124585,"h":773094237865,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":785979139753,"f":33},"n":"MediumVioletRed","d":124585,"h":781684172457,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":794569074345,"f":33},"n":"MidnightBlue","d":124585,"h":790274107049,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":803159008937,"f":33},"n":"MintCream","d":124585,"h":798864041641,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":811748943529,"f":33},"n":"MistyRose","d":124585,"h":807453976233,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":820338878121,"f":33},"n":"Moccasin","d":124585,"h":816043910825,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":828928812713,"f":33},"n":"NavajoWhite","d":124585,"h":824633845417,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":837518747305,"f":33},"n":"Navy","d":124585,"h":833223780009,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":846108681897,"f":33},"n":"OldLace","d":124585,"h":841813714601,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":854698616489,"f":33},"n":"Olive","d":124585,"h":850403649193,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":863288551081,"f":33},"n":"OliveDrab","d":124585,"h":858993583785,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":871878485673,"f":33},"n":"Orange","d":124585,"h":867583518377,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":880468420265,"f":33},"n":"OrangeRed","d":124585,"h":876173452969,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":889058354857,"f":33},"n":"Orchid","d":124585,"h":884763387561,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":897648289449,"f":33},"n":"PaleGoldenrod","d":124585,"h":893353322153,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":906238224041,"f":33},"n":"PaleGreen","d":124585,"h":901943256745,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":914828158633,"f":33},"n":"PaleTurquoise","d":124585,"h":910533191337,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":923418093225,"f":33},"n":"PaleVioletRed","d":124585,"h":919123125929,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":932008027817,"f":33},"n":"PapayaWhip","d":124585,"h":927713060521,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":940597962409,"f":33},"n":"PeachPuff","d":124585,"h":936302995113,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":949187897001,"f":33},"n":"Peru","d":124585,"h":944892929705,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":957777831593,"f":33},"n":"Pink","d":124585,"h":953482864297,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":966367766185,"f":33},"n":"Plum","d":124585,"h":962072798889,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":974957700777,"f":33},"n":"PowderBlue","d":124585,"h":970662733481,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":983547635369,"f":33},"n":"Purple","d":124585,"h":979252668073,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":992137569961,"f":33},"n":"RebeccaPurple","d":124585,"h":987842602665,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1000727504553,"f":33},"n":"Red","d":124585,"h":996432537257,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1009317439145,"f":33},"n":"RosyBrown","d":124585,"h":1005022471849,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1017907373737,"f":33},"n":"RoyalBlue","d":124585,"h":1013612406441,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1026497308329,"f":33},"n":"SaddleBrown","d":124585,"h":1022202341033,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1035087242921,"f":33},"n":"Salmon","d":124585,"h":1030792275625,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1043677177513,"f":33},"n":"SandyBrown","d":124585,"h":1039382210217,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1052267112105,"f":33},"n":"SeaGreen","d":124585,"h":1047972144809,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1060857046697,"f":33},"n":"SeaShell","d":124585,"h":1056562079401,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1069446981289,"f":33},"n":"Sienna","d":124585,"h":1065152013993,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1078036915881,"f":33},"n":"Silver","d":124585,"h":1073741948585,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1086626850473,"f":33},"n":"SkyBlue","d":124585,"h":1082331883177,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1095216785065,"f":33},"n":"SlateBlue","d":124585,"h":1090921817769,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1103806719657,"f":33},"n":"SlateGray","d":124585,"h":1099511752361,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1112396654249,"f":33},"n":"Snow","d":124585,"h":1108101686953,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1120986588841,"f":33},"n":"SpringGreen","d":124585,"h":1116691621545,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1129576523433,"f":33},"n":"SteelBlue","d":124585,"h":1125281556137,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1138166458025,"f":33},"n":"Tan","d":124585,"h":1133871490729,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1146756392617,"f":33},"n":"Teal","d":124585,"h":1142461425321,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1155346327209,"f":33},"n":"Thistle","d":124585,"h":1151051359913,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1163936261801,"f":33},"n":"Tomato","d":124585,"h":1159641294505,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1172526196393,"f":33},"n":"Turquoise","d":124585,"h":1168231229097,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1181116130985,"f":33},"n":"Violet","d":124585,"h":1176821163689,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1189706065577,"f":33},"n":"Wheat","d":124585,"h":1185411098281,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1198296000169,"f":33},"n":"White","d":124585,"h":1194001032873,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1206885934761,"f":33},"n":"WhiteSmoke","d":124585,"h":1202590967465,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1215475869353,"f":33},"n":"Yellow","d":124585,"h":1211180902057,"f":33},{"p":124585,"g":{"r":0,"d":0,"h":1224065803945,"f":33},"n":"YellowGreen","d":124585,"h":1219770836649,"f":33},{"p":393217,"g":{"r":0,"d":0,"h":1314260117161,"f":1},"n":"R","d":124585,"h":1309965149865,"f":1},{"p":393217,"g":{"r":0,"d":0,"h":1322850051753,"f":1},"n":"G","d":124585,"h":1318555084457,"f":1},{"p":393217,"g":{"r":0,"d":0,"h":1331439986345,"f":1},"n":"B","d":124585,"h":1327145019049,"f":1},{"p":393217,"g":{"r":0,"d":0,"h":1340029920937,"f":1},"n":"A","d":124585,"h":1335734953641,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1348619855529,"f":1},"n":"IsKnownColor","d":124585,"h":1344324888233,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1357209790121,"f":1},"n":"IsEmpty","d":124585,"h":1352914822825,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1365799724713,"f":1},"n":"IsNamedColor","d":124585,"h":1361504757417,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1374389659305,"f":1},"n":"IsSystemColor","d":124585,"h":1370094692009,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":1387274561193,"f":2},"n":"NameAndARGBValue","d":124585,"h":1382979593897,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":1395864495785,"f":1},"n":"Name","d":124585,"h":1391569528489,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":1404454430377,"f":2},"n":"Value","d":124585,"h":1400159463081,"f":2}],"m":[{"r":262145,"p":[{"n":"knownColor","p":386729}],"n":"IsKnownColorSystem","d":124585,"h":1378684626601,"f":40},{"r":65537,"p":[{"n":"value","p":655361},{"n":"name","p":1310721}],"n":"CheckByte","d":124585,"h":1408749397673,"f":34},{"r":124585,"p":[{"n":"argb","p":720897}],"n":"FromArgb","d":124585,"h":1413044364969,"f":34},{"r":124585,"p":[{"n":"argb","p":655361}],"n":"FromArgb","o":"@$1","d":124585,"h":1417339332265,"f":33},{"r":124585,"p":[{"n":"alpha","p":655361},{"n":"red","p":655361},{"n":"green","p":655361},{"n":"blue","p":655361}],"n":"FromArgb","o":"@$2","d":124585,"h":1421634299561,"f":33},{"r":124585,"p":[{"n":"alpha","p":655361},{"n":"baseColor","p":124585}],"n":"FromArgb","o":"@$3","d":124585,"h":1425929266857,"f":33},{"r":124585,"p":[{"n":"red","p":655361},{"n":"green","p":655361},{"n":"blue","p":655361}],"n":"FromArgb","o":"@$4","d":124585,"h":1430224234153,"f":33},{"r":124585,"p":[{"n":"color","p":386729}],"n":"FromKnownColor","d":124585,"h":1434519201449,"f":33},{"r":124585,"p":[{"n":"name","p":1310721}],"n":"FromName","d":124585,"h":1438814168745,"f":33},{"r":65537,"p":[{"n":"r","p":655361,"f":2},{"n":"g","p":655361,"f":2},{"n":"b","p":655361,"f":2}],"n":"GetRgbValues","d":124585,"h":1443109136041,"f":8},{"r":65537,"p":[{"n":"min","p":655361,"f":2},{"n":"max","p":655361,"f":2},{"n":"r","p":655361},{"n":"g","p":655361},{"n":"b","p":655361}],"n":"MinMaxRgb","d":124585,"h":1447404103337,"f":34},{"r":1114113,"n":"GetBrightness","d":124585,"h":1451699070633,"f":1},{"r":1114113,"n":"GetHue","d":124585,"h":1455994037929,"f":1},{"r":1114113,"n":"GetSaturation","d":124585,"h":1460289005225,"f":1},{"r":655361,"n":"ToArgb","d":124585,"h":1464583972521,"f":1},{"r":386729,"n":"ToKnownColor","d":124585,"h":1468878939817,"f":1},{"r":1310721,"n":"ToString","d":124585,"h":1473173907113,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":124585,"h":1486058809001,"f":32769},{"r":262145,"p":[{"n":"other","p":124585}],"n":"Equals","o":"@$2","d":124585,"h":1490353776297,"f":1},{"r":655361,"n":"GetHashCode","d":124585,"h":1494648743593,"f":32769}],"l":[{"t":124585,"n":"Empty","d":124585,"h":4295091881,"f":33},{"t":524289,"n":"StateKnownColorValid","d":124585,"h":1228360771241,"f":34},{"t":524289,"n":"StateARGBValueValid","d":124585,"h":1232655738537,"f":34},{"t":524289,"n":"StateValueMask","d":124585,"h":1236950705833,"f":34},{"t":524289,"n":"StateNameValid","d":124585,"h":1241245673129,"f":34},{"t":917505,"n":"NotDefinedValue","d":124585,"h":1245540640425,"f":34},{"t":655361,"n":"ARGBAlphaShift","d":124585,"h":1249835607721,"f":40},{"t":655361,"n":"ARGBRedShift","d":124585,"h":1254130575017,"f":40},{"t":655361,"n":"ARGBGreenShift","d":124585,"h":1258425542313,"f":40},{"t":655361,"n":"ARGBBlueShift","d":124585,"h":1262720509609,"f":40},{"t":720897,"n":"ARGBAlphaMask","d":124585,"h":1267015476905,"f":40},{"t":720897,"n":"ARGBRedMask","d":124585,"h":1271310444201,"f":40},{"t":720897,"n":"ARGBGreenMask","d":124585,"h":1275605411497,"f":40},{"t":720897,"n":"ARGBBlueMask","d":124585,"h":1279900378793,"f":40},{"t":1310721,"n":"name","d":124585,"h":1284195346089,"f":2},{"t":917505,"n":"value","d":124585,"h":1288490313385,"f":2},{"t":524289,"n":"knownColor","d":124585,"h":1292785280681,"f":2},{"t":524289,"n":"state","d":124585,"h":1297080247977,"f":2}],"c":[{"p":[{"n":"knownColor","p":386729}],"n":".ctor","o":"$ctor$2","d":124585,"h":1301375215273,"f":8},{"p":[{"n":"value","p":917505},{"n":"state","p":524289},{"n":"name","p":1310721},{"n":"knownColor","p":386729}],"n":".ctor","o":"$ctor$3","d":124585,"h":1305670182569,"f":2},{"n":".ctor","o":"$ctor$4","d":124585,"h":1498943710889,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Color).$h],"h":124585,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{NameAndARGBValue}","t":1310721}]},{"t":852007,"c":12885753895,"a":[{"v":"System.Drawing.Design.ColorEditor, System.Drawing.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":118226945,"c":4413194241},{"t":1496073,"c":17181365257,"a":[{"v":"System.Drawing.ColorConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Color) ]; }
            static get $fullName() { return `System.Drawing.Color`; }
        });
        
        $asm.$str("$sdp.System.Drawing.KnownColor", ($self) => class KnownColor extends $.$spc.System.Enum
        {
            static ActiveBorder = 1;
            static ActiveCaption = 2;
            static ActiveCaptionText = 3;
            static AppWorkspace = 4;
            static Control = 5;
            static ControlDark = 6;
            static ControlDarkDark = 7;
            static ControlLight = 8;
            static ControlLightLight = 9;
            static ControlText = 10;
            static Desktop = 11;
            static GrayText = 12;
            static Highlight = 13;
            static HighlightText = 14;
            static HotTrack = 15;
            static InactiveBorder = 16;
            static InactiveCaption = 17;
            static InactiveCaptionText = 18;
            static Info = 19;
            static InfoText = 20;
            static Menu = 21;
            static MenuText = 22;
            static ScrollBar = 23;
            static Window = 24;
            static WindowFrame = 25;
            static WindowText = 26;
            static Transparent = 27;
            static AliceBlue = 28;
            static AntiqueWhite = 29;
            static Aqua = 30;
            static Aquamarine = 31;
            static Azure = 32;
            static Beige = 33;
            static Bisque = 34;
            static Black = 35;
            static BlanchedAlmond = 36;
            static Blue = 37;
            static BlueViolet = 38;
            static Brown = 39;
            static BurlyWood = 40;
            static CadetBlue = 41;
            static Chartreuse = 42;
            static Chocolate = 43;
            static Coral = 44;
            static CornflowerBlue = 45;
            static Cornsilk = 46;
            static Crimson = 47;
            static Cyan = 48;
            static DarkBlue = 49;
            static DarkCyan = 50;
            static DarkGoldenrod = 51;
            static DarkGray = 52;
            static DarkGreen = 53;
            static DarkKhaki = 54;
            static DarkMagenta = 55;
            static DarkOliveGreen = 56;
            static DarkOrange = 57;
            static DarkOrchid = 58;
            static DarkRed = 59;
            static DarkSalmon = 60;
            static DarkSeaGreen = 61;
            static DarkSlateBlue = 62;
            static DarkSlateGray = 63;
            static DarkTurquoise = 64;
            static DarkViolet = 65;
            static DeepPink = 66;
            static DeepSkyBlue = 67;
            static DimGray = 68;
            static DodgerBlue = 69;
            static Firebrick = 70;
            static FloralWhite = 71;
            static ForestGreen = 72;
            static Fuchsia = 73;
            static Gainsboro = 74;
            static GhostWhite = 75;
            static Gold = 76;
            static Goldenrod = 77;
            static Gray = 78;
            static Green = 79;
            static GreenYellow = 80;
            static Honeydew = 81;
            static HotPink = 82;
            static IndianRed = 83;
            static Indigo = 84;
            static Ivory = 85;
            static Khaki = 86;
            static Lavender = 87;
            static LavenderBlush = 88;
            static LawnGreen = 89;
            static LemonChiffon = 90;
            static LightBlue = 91;
            static LightCoral = 92;
            static LightCyan = 93;
            static LightGoldenrodYellow = 94;
            static LightGray = 95;
            static LightGreen = 96;
            static LightPink = 97;
            static LightSalmon = 98;
            static LightSeaGreen = 99;
            static LightSkyBlue = 100;
            static LightSlateGray = 101;
            static LightSteelBlue = 102;
            static LightYellow = 103;
            static Lime = 104;
            static LimeGreen = 105;
            static Linen = 106;
            static Magenta = 107;
            static Maroon = 108;
            static MediumAquamarine = 109;
            static MediumBlue = 110;
            static MediumOrchid = 111;
            static MediumPurple = 112;
            static MediumSeaGreen = 113;
            static MediumSlateBlue = 114;
            static MediumSpringGreen = 115;
            static MediumTurquoise = 116;
            static MediumVioletRed = 117;
            static MidnightBlue = 118;
            static MintCream = 119;
            static MistyRose = 120;
            static Moccasin = 121;
            static NavajoWhite = 122;
            static Navy = 123;
            static OldLace = 124;
            static Olive = 125;
            static OliveDrab = 126;
            static Orange = 127;
            static OrangeRed = 128;
            static Orchid = 129;
            static PaleGoldenrod = 130;
            static PaleGreen = 131;
            static PaleTurquoise = 132;
            static PaleVioletRed = 133;
            static PapayaWhip = 134;
            static PeachPuff = 135;
            static Peru = 136;
            static Pink = 137;
            static Plum = 138;
            static PowderBlue = 139;
            static Purple = 140;
            static Red = 141;
            static RosyBrown = 142;
            static RoyalBlue = 143;
            static SaddleBrown = 144;
            static Salmon = 145;
            static SandyBrown = 146;
            static SeaGreen = 147;
            static SeaShell = 148;
            static Sienna = 149;
            static Silver = 150;
            static SkyBlue = 151;
            static SlateBlue = 152;
            static SlateGray = 153;
            static Snow = 154;
            static SpringGreen = 155;
            static SteelBlue = 156;
            static Tan = 157;
            static Teal = 158;
            static Thistle = 159;
            static Tomato = 160;
            static Turquoise = 161;
            static Violet = 162;
            static Wheat = 163;
            static White = 164;
            static WhiteSmoke = 165;
            static Yellow = 166;
            static YellowGreen = 167;
            static ButtonFace = 168;
            static ButtonHighlight = 169;
            static ButtonShadow = 170;
            static GradientActiveCaption = 171;
            static GradientInactiveCaption = 172;
            static MenuBar = 173;
            static MenuHighlight = 174;
            static RebeccaPurple = 175;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ActiveBorder": 1n,
                    "ActiveCaption": 2n,
                    "ActiveCaptionText": 3n,
                    "AppWorkspace": 4n,
                    "Control": 5n,
                    "ControlDark": 6n,
                    "ControlDarkDark": 7n,
                    "ControlLight": 8n,
                    "ControlLightLight": 9n,
                    "ControlText": 10n,
                    "Desktop": 11n,
                    "GrayText": 12n,
                    "Highlight": 13n,
                    "HighlightText": 14n,
                    "HotTrack": 15n,
                    "InactiveBorder": 16n,
                    "InactiveCaption": 17n,
                    "InactiveCaptionText": 18n,
                    "Info": 19n,
                    "InfoText": 20n,
                    "Menu": 21n,
                    "MenuText": 22n,
                    "ScrollBar": 23n,
                    "Window": 24n,
                    "WindowFrame": 25n,
                    "WindowText": 26n,
                    "Transparent": 27n,
                    "AliceBlue": 28n,
                    "AntiqueWhite": 29n,
                    "Aqua": 30n,
                    "Aquamarine": 31n,
                    "Azure": 32n,
                    "Beige": 33n,
                    "Bisque": 34n,
                    "Black": 35n,
                    "BlanchedAlmond": 36n,
                    "Blue": 37n,
                    "BlueViolet": 38n,
                    "Brown": 39n,
                    "BurlyWood": 40n,
                    "CadetBlue": 41n,
                    "Chartreuse": 42n,
                    "Chocolate": 43n,
                    "Coral": 44n,
                    "CornflowerBlue": 45n,
                    "Cornsilk": 46n,
                    "Crimson": 47n,
                    "Cyan": 48n,
                    "DarkBlue": 49n,
                    "DarkCyan": 50n,
                    "DarkGoldenrod": 51n,
                    "DarkGray": 52n,
                    "DarkGreen": 53n,
                    "DarkKhaki": 54n,
                    "DarkMagenta": 55n,
                    "DarkOliveGreen": 56n,
                    "DarkOrange": 57n,
                    "DarkOrchid": 58n,
                    "DarkRed": 59n,
                    "DarkSalmon": 60n,
                    "DarkSeaGreen": 61n,
                    "DarkSlateBlue": 62n,
                    "DarkSlateGray": 63n,
                    "DarkTurquoise": 64n,
                    "DarkViolet": 65n,
                    "DeepPink": 66n,
                    "DeepSkyBlue": 67n,
                    "DimGray": 68n,
                    "DodgerBlue": 69n,
                    "Firebrick": 70n,
                    "FloralWhite": 71n,
                    "ForestGreen": 72n,
                    "Fuchsia": 73n,
                    "Gainsboro": 74n,
                    "GhostWhite": 75n,
                    "Gold": 76n,
                    "Goldenrod": 77n,
                    "Gray": 78n,
                    "Green": 79n,
                    "GreenYellow": 80n,
                    "Honeydew": 81n,
                    "HotPink": 82n,
                    "IndianRed": 83n,
                    "Indigo": 84n,
                    "Ivory": 85n,
                    "Khaki": 86n,
                    "Lavender": 87n,
                    "LavenderBlush": 88n,
                    "LawnGreen": 89n,
                    "LemonChiffon": 90n,
                    "LightBlue": 91n,
                    "LightCoral": 92n,
                    "LightCyan": 93n,
                    "LightGoldenrodYellow": 94n,
                    "LightGray": 95n,
                    "LightGreen": 96n,
                    "LightPink": 97n,
                    "LightSalmon": 98n,
                    "LightSeaGreen": 99n,
                    "LightSkyBlue": 100n,
                    "LightSlateGray": 101n,
                    "LightSteelBlue": 102n,
                    "LightYellow": 103n,
                    "Lime": 104n,
                    "LimeGreen": 105n,
                    "Linen": 106n,
                    "Magenta": 107n,
                    "Maroon": 108n,
                    "MediumAquamarine": 109n,
                    "MediumBlue": 110n,
                    "MediumOrchid": 111n,
                    "MediumPurple": 112n,
                    "MediumSeaGreen": 113n,
                    "MediumSlateBlue": 114n,
                    "MediumSpringGreen": 115n,
                    "MediumTurquoise": 116n,
                    "MediumVioletRed": 117n,
                    "MidnightBlue": 118n,
                    "MintCream": 119n,
                    "MistyRose": 120n,
                    "Moccasin": 121n,
                    "NavajoWhite": 122n,
                    "Navy": 123n,
                    "OldLace": 124n,
                    "Olive": 125n,
                    "OliveDrab": 126n,
                    "Orange": 127n,
                    "OrangeRed": 128n,
                    "Orchid": 129n,
                    "PaleGoldenrod": 130n,
                    "PaleGreen": 131n,
                    "PaleTurquoise": 132n,
                    "PaleVioletRed": 133n,
                    "PapayaWhip": 134n,
                    "PeachPuff": 135n,
                    "Peru": 136n,
                    "Pink": 137n,
                    "Plum": 138n,
                    "PowderBlue": 139n,
                    "Purple": 140n,
                    "Red": 141n,
                    "RosyBrown": 142n,
                    "RoyalBlue": 143n,
                    "SaddleBrown": 144n,
                    "Salmon": 145n,
                    "SandyBrown": 146n,
                    "SeaGreen": 147n,
                    "SeaShell": 148n,
                    "Sienna": 149n,
                    "Silver": 150n,
                    "SkyBlue": 151n,
                    "SlateBlue": 152n,
                    "SlateGray": 153n,
                    "Snow": 154n,
                    "SpringGreen": 155n,
                    "SteelBlue": 156n,
                    "Tan": 157n,
                    "Teal": 158n,
                    "Thistle": 159n,
                    "Tomato": 160n,
                    "Turquoise": 161n,
                    "Violet": 162n,
                    "Wheat": 163n,
                    "White": 164n,
                    "WhiteSmoke": 165n,
                    "Yellow": 166n,
                    "YellowGreen": 167n,
                    "ButtonFace": 168n,
                    "ButtonHighlight": 169n,
                    "ButtonShadow": 170n,
                    "GradientActiveCaption": 171n,
                    "GradientInactiveCaption": 172n,
                    "MenuBar": 173n,
                    "MenuHighlight": 174n,
                    "RebeccaPurple": 175n
                };
            }
            static $h = 386729;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":386729,"n":"ActiveBorder","d":386729,"h":4295354025,"f":33},{"t":386729,"n":"ActiveCaption","d":386729,"h":8590321321,"f":33},{"t":386729,"n":"ActiveCaptionText","d":386729,"h":12885288617,"f":33},{"t":386729,"n":"AppWorkspace","d":386729,"h":17180255913,"f":33},{"t":386729,"n":"Control","d":386729,"h":21475223209,"f":33},{"t":386729,"n":"ControlDark","d":386729,"h":25770190505,"f":33},{"t":386729,"n":"ControlDarkDark","d":386729,"h":30065157801,"f":33},{"t":386729,"n":"ControlLight","d":386729,"h":34360125097,"f":33},{"t":386729,"n":"ControlLightLight","d":386729,"h":38655092393,"f":33},{"t":386729,"n":"ControlText","d":386729,"h":42950059689,"f":33},{"t":386729,"n":"Desktop","d":386729,"h":47245026985,"f":33},{"t":386729,"n":"GrayText","d":386729,"h":51539994281,"f":33},{"t":386729,"n":"Highlight","d":386729,"h":55834961577,"f":33},{"t":386729,"n":"HighlightText","d":386729,"h":60129928873,"f":33},{"t":386729,"n":"HotTrack","d":386729,"h":64424896169,"f":33},{"t":386729,"n":"InactiveBorder","d":386729,"h":68719863465,"f":33},{"t":386729,"n":"InactiveCaption","d":386729,"h":73014830761,"f":33},{"t":386729,"n":"InactiveCaptionText","d":386729,"h":77309798057,"f":33},{"t":386729,"n":"Info","d":386729,"h":81604765353,"f":33},{"t":386729,"n":"InfoText","d":386729,"h":85899732649,"f":33},{"t":386729,"n":"Menu","d":386729,"h":90194699945,"f":33},{"t":386729,"n":"MenuText","d":386729,"h":94489667241,"f":33},{"t":386729,"n":"ScrollBar","d":386729,"h":98784634537,"f":33},{"t":386729,"n":"Window","d":386729,"h":103079601833,"f":33},{"t":386729,"n":"WindowFrame","d":386729,"h":107374569129,"f":33},{"t":386729,"n":"WindowText","d":386729,"h":111669536425,"f":33},{"t":386729,"n":"Transparent","d":386729,"h":115964503721,"f":33},{"t":386729,"n":"AliceBlue","d":386729,"h":120259471017,"f":33},{"t":386729,"n":"AntiqueWhite","d":386729,"h":124554438313,"f":33},{"t":386729,"n":"Aqua","d":386729,"h":128849405609,"f":33},{"t":386729,"n":"Aquamarine","d":386729,"h":133144372905,"f":33},{"t":386729,"n":"Azure","d":386729,"h":137439340201,"f":33},{"t":386729,"n":"Beige","d":386729,"h":141734307497,"f":33},{"t":386729,"n":"Bisque","d":386729,"h":146029274793,"f":33},{"t":386729,"n":"Black","d":386729,"h":150324242089,"f":33},{"t":386729,"n":"BlanchedAlmond","d":386729,"h":154619209385,"f":33},{"t":386729,"n":"Blue","d":386729,"h":158914176681,"f":33},{"t":386729,"n":"BlueViolet","d":386729,"h":163209143977,"f":33},{"t":386729,"n":"Brown","d":386729,"h":167504111273,"f":33},{"t":386729,"n":"BurlyWood","d":386729,"h":171799078569,"f":33},{"t":386729,"n":"CadetBlue","d":386729,"h":176094045865,"f":33},{"t":386729,"n":"Chartreuse","d":386729,"h":180389013161,"f":33},{"t":386729,"n":"Chocolate","d":386729,"h":184683980457,"f":33},{"t":386729,"n":"Coral","d":386729,"h":188978947753,"f":33},{"t":386729,"n":"CornflowerBlue","d":386729,"h":193273915049,"f":33},{"t":386729,"n":"Cornsilk","d":386729,"h":197568882345,"f":33},{"t":386729,"n":"Crimson","d":386729,"h":201863849641,"f":33},{"t":386729,"n":"Cyan","d":386729,"h":206158816937,"f":33},{"t":386729,"n":"DarkBlue","d":386729,"h":210453784233,"f":33},{"t":386729,"n":"DarkCyan","d":386729,"h":214748751529,"f":33},{"t":386729,"n":"DarkGoldenrod","d":386729,"h":219043718825,"f":33},{"t":386729,"n":"DarkGray","d":386729,"h":223338686121,"f":33},{"t":386729,"n":"DarkGreen","d":386729,"h":227633653417,"f":33},{"t":386729,"n":"DarkKhaki","d":386729,"h":231928620713,"f":33},{"t":386729,"n":"DarkMagenta","d":386729,"h":236223588009,"f":33},{"t":386729,"n":"DarkOliveGreen","d":386729,"h":240518555305,"f":33},{"t":386729,"n":"DarkOrange","d":386729,"h":244813522601,"f":33},{"t":386729,"n":"DarkOrchid","d":386729,"h":249108489897,"f":33},{"t":386729,"n":"DarkRed","d":386729,"h":253403457193,"f":33},{"t":386729,"n":"DarkSalmon","d":386729,"h":257698424489,"f":33},{"t":386729,"n":"DarkSeaGreen","d":386729,"h":261993391785,"f":33},{"t":386729,"n":"DarkSlateBlue","d":386729,"h":266288359081,"f":33},{"t":386729,"n":"DarkSlateGray","d":386729,"h":270583326377,"f":33},{"t":386729,"n":"DarkTurquoise","d":386729,"h":274878293673,"f":33},{"t":386729,"n":"DarkViolet","d":386729,"h":279173260969,"f":33},{"t":386729,"n":"DeepPink","d":386729,"h":283468228265,"f":33},{"t":386729,"n":"DeepSkyBlue","d":386729,"h":287763195561,"f":33},{"t":386729,"n":"DimGray","d":386729,"h":292058162857,"f":33},{"t":386729,"n":"DodgerBlue","d":386729,"h":296353130153,"f":33},{"t":386729,"n":"Firebrick","d":386729,"h":300648097449,"f":33},{"t":386729,"n":"FloralWhite","d":386729,"h":304943064745,"f":33},{"t":386729,"n":"ForestGreen","d":386729,"h":309238032041,"f":33},{"t":386729,"n":"Fuchsia","d":386729,"h":313532999337,"f":33},{"t":386729,"n":"Gainsboro","d":386729,"h":317827966633,"f":33},{"t":386729,"n":"GhostWhite","d":386729,"h":322122933929,"f":33},{"t":386729,"n":"Gold","d":386729,"h":326417901225,"f":33},{"t":386729,"n":"Goldenrod","d":386729,"h":330712868521,"f":33},{"t":386729,"n":"Gray","d":386729,"h":335007835817,"f":33},{"t":386729,"n":"Green","d":386729,"h":339302803113,"f":33},{"t":386729,"n":"GreenYellow","d":386729,"h":343597770409,"f":33},{"t":386729,"n":"Honeydew","d":386729,"h":347892737705,"f":33},{"t":386729,"n":"HotPink","d":386729,"h":352187705001,"f":33},{"t":386729,"n":"IndianRed","d":386729,"h":356482672297,"f":33},{"t":386729,"n":"Indigo","d":386729,"h":360777639593,"f":33},{"t":386729,"n":"Ivory","d":386729,"h":365072606889,"f":33},{"t":386729,"n":"Khaki","d":386729,"h":369367574185,"f":33},{"t":386729,"n":"Lavender","d":386729,"h":373662541481,"f":33},{"t":386729,"n":"LavenderBlush","d":386729,"h":377957508777,"f":33},{"t":386729,"n":"LawnGreen","d":386729,"h":382252476073,"f":33},{"t":386729,"n":"LemonChiffon","d":386729,"h":386547443369,"f":33},{"t":386729,"n":"LightBlue","d":386729,"h":390842410665,"f":33},{"t":386729,"n":"LightCoral","d":386729,"h":395137377961,"f":33},{"t":386729,"n":"LightCyan","d":386729,"h":399432345257,"f":33},{"t":386729,"n":"LightGoldenrodYellow","d":386729,"h":403727312553,"f":33},{"t":386729,"n":"LightGray","d":386729,"h":408022279849,"f":33},{"t":386729,"n":"LightGreen","d":386729,"h":412317247145,"f":33},{"t":386729,"n":"LightPink","d":386729,"h":416612214441,"f":33},{"t":386729,"n":"LightSalmon","d":386729,"h":420907181737,"f":33},{"t":386729,"n":"LightSeaGreen","d":386729,"h":425202149033,"f":33},{"t":386729,"n":"LightSkyBlue","d":386729,"h":429497116329,"f":33},{"t":386729,"n":"LightSlateGray","d":386729,"h":433792083625,"f":33},{"t":386729,"n":"LightSteelBlue","d":386729,"h":438087050921,"f":33},{"t":386729,"n":"LightYellow","d":386729,"h":442382018217,"f":33},{"t":386729,"n":"Lime","d":386729,"h":446676985513,"f":33},{"t":386729,"n":"LimeGreen","d":386729,"h":450971952809,"f":33},{"t":386729,"n":"Linen","d":386729,"h":455266920105,"f":33},{"t":386729,"n":"Magenta","d":386729,"h":459561887401,"f":33},{"t":386729,"n":"Maroon","d":386729,"h":463856854697,"f":33},{"t":386729,"n":"MediumAquamarine","d":386729,"h":468151821993,"f":33},{"t":386729,"n":"MediumBlue","d":386729,"h":472446789289,"f":33},{"t":386729,"n":"MediumOrchid","d":386729,"h":476741756585,"f":33},{"t":386729,"n":"MediumPurple","d":386729,"h":481036723881,"f":33},{"t":386729,"n":"MediumSeaGreen","d":386729,"h":485331691177,"f":33},{"t":386729,"n":"MediumSlateBlue","d":386729,"h":489626658473,"f":33},{"t":386729,"n":"MediumSpringGreen","d":386729,"h":493921625769,"f":33},{"t":386729,"n":"MediumTurquoise","d":386729,"h":498216593065,"f":33},{"t":386729,"n":"MediumVioletRed","d":386729,"h":502511560361,"f":33},{"t":386729,"n":"MidnightBlue","d":386729,"h":506806527657,"f":33},{"t":386729,"n":"MintCream","d":386729,"h":511101494953,"f":33},{"t":386729,"n":"MistyRose","d":386729,"h":515396462249,"f":33},{"t":386729,"n":"Moccasin","d":386729,"h":519691429545,"f":33},{"t":386729,"n":"NavajoWhite","d":386729,"h":523986396841,"f":33},{"t":386729,"n":"Navy","d":386729,"h":528281364137,"f":33},{"t":386729,"n":"OldLace","d":386729,"h":532576331433,"f":33},{"t":386729,"n":"Olive","d":386729,"h":536871298729,"f":33},{"t":386729,"n":"OliveDrab","d":386729,"h":541166266025,"f":33},{"t":386729,"n":"Orange","d":386729,"h":545461233321,"f":33},{"t":386729,"n":"OrangeRed","d":386729,"h":549756200617,"f":33},{"t":386729,"n":"Orchid","d":386729,"h":554051167913,"f":33},{"t":386729,"n":"PaleGoldenrod","d":386729,"h":558346135209,"f":33},{"t":386729,"n":"PaleGreen","d":386729,"h":562641102505,"f":33},{"t":386729,"n":"PaleTurquoise","d":386729,"h":566936069801,"f":33},{"t":386729,"n":"PaleVioletRed","d":386729,"h":571231037097,"f":33},{"t":386729,"n":"PapayaWhip","d":386729,"h":575526004393,"f":33},{"t":386729,"n":"PeachPuff","d":386729,"h":579820971689,"f":33},{"t":386729,"n":"Peru","d":386729,"h":584115938985,"f":33},{"t":386729,"n":"Pink","d":386729,"h":588410906281,"f":33},{"t":386729,"n":"Plum","d":386729,"h":592705873577,"f":33},{"t":386729,"n":"PowderBlue","d":386729,"h":597000840873,"f":33},{"t":386729,"n":"Purple","d":386729,"h":601295808169,"f":33},{"t":386729,"n":"Red","d":386729,"h":605590775465,"f":33},{"t":386729,"n":"RosyBrown","d":386729,"h":609885742761,"f":33},{"t":386729,"n":"RoyalBlue","d":386729,"h":614180710057,"f":33},{"t":386729,"n":"SaddleBrown","d":386729,"h":618475677353,"f":33},{"t":386729,"n":"Salmon","d":386729,"h":622770644649,"f":33},{"t":386729,"n":"SandyBrown","d":386729,"h":627065611945,"f":33},{"t":386729,"n":"SeaGreen","d":386729,"h":631360579241,"f":33},{"t":386729,"n":"SeaShell","d":386729,"h":635655546537,"f":33},{"t":386729,"n":"Sienna","d":386729,"h":639950513833,"f":33},{"t":386729,"n":"Silver","d":386729,"h":644245481129,"f":33},{"t":386729,"n":"SkyBlue","d":386729,"h":648540448425,"f":33},{"t":386729,"n":"SlateBlue","d":386729,"h":652835415721,"f":33},{"t":386729,"n":"SlateGray","d":386729,"h":657130383017,"f":33},{"t":386729,"n":"Snow","d":386729,"h":661425350313,"f":33},{"t":386729,"n":"SpringGreen","d":386729,"h":665720317609,"f":33},{"t":386729,"n":"SteelBlue","d":386729,"h":670015284905,"f":33},{"t":386729,"n":"Tan","d":386729,"h":674310252201,"f":33},{"t":386729,"n":"Teal","d":386729,"h":678605219497,"f":33},{"t":386729,"n":"Thistle","d":386729,"h":682900186793,"f":33},{"t":386729,"n":"Tomato","d":386729,"h":687195154089,"f":33},{"t":386729,"n":"Turquoise","d":386729,"h":691490121385,"f":33},{"t":386729,"n":"Violet","d":386729,"h":695785088681,"f":33},{"t":386729,"n":"Wheat","d":386729,"h":700080055977,"f":33},{"t":386729,"n":"White","d":386729,"h":704375023273,"f":33},{"t":386729,"n":"WhiteSmoke","d":386729,"h":708669990569,"f":33},{"t":386729,"n":"Yellow","d":386729,"h":712964957865,"f":33},{"t":386729,"n":"YellowGreen","d":386729,"h":717259925161,"f":33},{"t":386729,"n":"ButtonFace","d":386729,"h":721554892457,"f":33},{"t":386729,"n":"ButtonHighlight","d":386729,"h":725849859753,"f":33},{"t":386729,"n":"ButtonShadow","d":386729,"h":730144827049,"f":33},{"t":386729,"n":"GradientActiveCaption","d":386729,"h":734439794345,"f":33},{"t":386729,"n":"GradientInactiveCaption","d":386729,"h":738734761641,"f":33},{"t":386729,"n":"MenuBar","d":386729,"h":743029728937,"f":33},{"t":386729,"n":"MenuHighlight","d":386729,"h":747324696233,"f":33},{"t":386729,"n":"RebeccaPurple","d":386729,"h":751619663529,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":386729,"h":755914630825,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":386729,"a":[{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Drawing.KnownColor`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.InteropServices", "NetJs.System.ComponentModel.Primitives"))