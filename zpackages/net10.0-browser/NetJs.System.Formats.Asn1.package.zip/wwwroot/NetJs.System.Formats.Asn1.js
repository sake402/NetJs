
//--TRIMMABLE-BOUNDARY-START(19)
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $sri, $srn, $stee) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Formats.Asn1", 
    {
  "h": 19,
  "f": "System.Formats.Asn1",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.Formats.Asn1",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.Formats.Asn1",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1376275)
        $asm.$cls("$sfa.System.Formats.Asn1.SpanBasedEncoding", ($self) => class SpanBasedEncoding extends $.$$.System.Text.Encoding
        {
            //--TRIMMABLE-BOUNDARY-START(4296343571)
            $ctor$4()
            {
                super.$ctor$2(0, $.$$.System.Text.EncoderFallback.ExceptionFallback, $.$$.System.Text.DecoderFallback.ExceptionFallback);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296343571);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343571)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 8591310867, 408187699201)
            /*int */ GetByteCount(/*char[]*/ chars, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591310867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetByteCount$4(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$3(chars, index, count));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8591310867, 408187699201)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12886278163, 416777633793)
            /*int */ GetByteCount$3(/*char**/ chars, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886278163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetByteCount$4(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(chars, count));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12886278163, 416777633793)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17181245459, 403892731905)
            /*int */ GetByteCount$6(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181245459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetByteCount$4($.$$.System.MemoryExtensions.AsSpan$4(s));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17181245459, 403892731905)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21476212755, 421072601089)
            /*int */ GetByteCount$4(/*ReadOnlySpan<char>*/ chars)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476212755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetBytes$9(chars, $.$$.System.Span$$($.$$.System.Byte).Empty, false);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21476212755, 421072601089)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30066147347, 455432339457)
            /*int */ GetBytes(/*char[]*/ chars, /*int*/ charIndex, /*int*/ charCount, /*byte[]*/ bytes, /*int*/ byteIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066147347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetBytes$9(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$3(chars, charIndex, charCount), new ($.$$.System.Span$$($.$$.System.Byte))().$ctor$3(bytes, byteIndex, ((bytes.length - byteIndex) | 0)), true);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30066147347, 455432339457)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 34361114643, 472612208641)
            /*int */ GetBytes$4(/*char**/ chars, /*int*/ charCount, /*byte**/ bytes, /*int*/ byteCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361114643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetBytes$9(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(chars, charCount), new ($.$$.System.Span$$($.$$.System.Byte))().$ctor$5(bytes, byteCount), true);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 34361114643, 472612208641)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38656081939, 506971947009)
            /*int */ GetCharCount(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656081939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCharCount$4(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$3(bytes, index, count));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38656081939, 506971947009)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 42951049235, 511266914305)
            /*int */ GetCharCount$3(/*byte**/ bytes, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951049235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCharCount$4(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$5(bytes, count));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 42951049235, 511266914305)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 47246016531, 515561881601)
            /*int */ GetCharCount$4(/*ReadOnlySpan<byte>*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246016531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChars$6(bytes, $.$$.System.Span$$($.$$.System.Char).Empty, false);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 47246016531, 515561881601)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 55835951123, 549921619969)
            /*int */ GetChars(/*byte[]*/ bytes, /*int*/ byteIndex, /*int*/ byteCount, /*char[]*/ chars, /*int*/ charIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835951123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChars$6(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$3(bytes, byteIndex, byteCount), new ($.$$.System.Span$$($.$$.System.Char))().$ctor$3(chars, charIndex, ((chars.length - charIndex) | 0)), true);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 55835951123, 549921619969)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 60130918419, 554216587265)
            /*int */ GetChars$4(/*byte**/ bytes, /*int*/ byteCount, /*char**/ chars, /*int*/ charCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130918419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChars$6(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$5(bytes, byteCount), new ($.$$.System.Span$$($.$$.System.Char))().$ctor$5(chars, charCount), true);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 60130918419, 554216587265)
            
            static $h = 1376275;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 165806081,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771180051),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "bytes",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "write",
          "p": 262145
        }
      ],
      "n": "GetBytes",
      "o": "@$9",
      "d": 1376275,
      "h": 25771180051,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(25771180051),
//--TRIMMABLE-BOUNDARY-START(51540983827),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "chars",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "write",
          "p": 262145
        }
      ],
      "n": "GetChars",
      "o": "@$6",
      "d": 1376275,
      "h": 51540983827,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(51540983827),
//--TRIMMABLE-BOUNDARY-START(ALL, 8591310867, 408187699201),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetByteCount",
      "d": 1376275,
      "h": 8591310867,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8591310867, 408187699201),
//--TRIMMABLE-BOUNDARY-START(ALL, 12886278163, 416777633793),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetByteCount",
      "o": "@$3",
      "d": 1376275,
      "h": 12886278163,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12886278163, 416777633793),
//--TRIMMABLE-BOUNDARY-START(ALL, 17181245459, 403892731905),
    {
      "r": 655361,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "GetByteCount",
      "o": "@$6",
      "d": 1376275,
      "h": 17181245459,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17181245459, 403892731905),
//--TRIMMABLE-BOUNDARY-START(ALL, 21476212755, 421072601089),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "GetByteCount",
      "o": "@$4",
      "d": 1376275,
      "h": 21476212755,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21476212755, 421072601089),
//--TRIMMABLE-BOUNDARY-START(ALL, 30066147347, 455432339457),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "charIndex",
          "p": 655361
        },
        {
          "n": "charCount",
          "p": 655361
        },
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "byteIndex",
          "p": 655361
        }
      ],
      "n": "GetBytes",
      "d": 1376275,
      "h": 30066147347,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30066147347, 455432339457),
//--TRIMMABLE-BOUNDARY-START(ALL, 34361114643, 472612208641),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "charCount",
          "p": 655361
        },
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.System.Byte).$h
        },
        {
          "n": "byteCount",
          "p": 655361
        }
      ],
      "n": "GetBytes",
      "o": "@$4",
      "d": 1376275,
      "h": 34361114643,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 34361114643, 472612208641),
//--TRIMMABLE-BOUNDARY-START(ALL, 38656081939, 506971947009),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetCharCount",
      "d": 1376275,
      "h": 38656081939,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38656081939, 506971947009),
//--TRIMMABLE-BOUNDARY-START(ALL, 42951049235, 511266914305),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.System.Byte).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetCharCount",
      "o": "@$3",
      "d": 1376275,
      "h": 42951049235,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42951049235, 511266914305),
//--TRIMMABLE-BOUNDARY-START(ALL, 47246016531, 515561881601),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "GetCharCount",
      "o": "@$4",
      "d": 1376275,
      "h": 47246016531,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47246016531, 515561881601),
//--TRIMMABLE-BOUNDARY-START(ALL, 55835951123, 549921619969),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "byteIndex",
          "p": 655361
        },
        {
          "n": "byteCount",
          "p": 655361
        },
        {
          "n": "chars",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "charIndex",
          "p": 655361
        }
      ],
      "n": "GetChars",
      "d": 1376275,
      "h": 55835951123,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55835951123, 549921619969),
//--TRIMMABLE-BOUNDARY-START(ALL, 60130918419, 554216587265),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.System.Byte).$h
        },
        {
          "n": "byteCount",
          "p": 655361
        },
        {
          "n": "chars",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "charCount",
          "p": 655361
        }
      ],
      "n": "GetChars",
      "o": "@$4",
      "d": 1376275,
      "h": 60130918419,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 60130918419, 554216587265)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343571),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1376275,
      "h": 4296343571,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296343571)
  ],
  "i": [89849857
  ],
  "h": 1376275
}; }
            static get $b() { return $.$$.System.Text.Encoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.SpanBasedEncoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376275)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245203)
        $asm.$cls("$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding", ($self) => class RestrictedAsciiStringEncoding extends $.$sfa.System.Formats.Asn1.SpanBasedEncoding
        {
            //--TRIMMABLE-BOUNDARY-START(4296212499)
            /*bool[]*/ _isAllowed = null;
            //--TRIMMABLE-BOUNDARY-END(4296212499)
            
            //--TRIMMABLE-BOUNDARY-START(8591179795)
            $ctor$5(/*byte*/ minCharAllowed, /*byte*/ maxCharAllowed)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591179795);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(minCharAllowed <= maxCharAllowed, "minCharAllowed <= maxCharAllowed");
                    $.$$.System.Diagnostics.Debug.Assert$2(maxCharAllowed <= 127, "maxCharAllowed <= 0x7F");
                    /*bool[]*/ let isAllowed = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Boolean), null, [128], null);
                    $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Boolean, isAllowed, minCharAllowed, ((maxCharAllowed - minCharAllowed + 1) | 0)).Fill(true);
                    this._isAllowed = isAllowed;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179795)
            
            //--TRIMMABLE-BOUNDARY-START(12886147091)
            $ctor$6(/*string*/ allowedChars)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886147091);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool[]*/ let isAllowed = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Boolean), null, [127], null);
                    var $en3 = $.$$.System.String.GetEnumerator.call(allowedChars);
                    while ($en3.MoveNext())
                    {
                        var c = $en3.Current;
                        {
                            if (c >= isAllowed.length)
                            {
                                throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("allowedChars");
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Array.$ReadT1.call(isAllowed, c) === false, "isAllowed[c] == false");
                            $.$$.System.Array.$WriteT1.call(isAllowed, true, c);
                        }
                    }
                    this._isAllowed = isAllowed;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886147091)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25771048979, 622936064001)
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771048979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return charCount;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25771048979, 622936064001)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30066016275, 627231031297)
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066016275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return byteCount;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30066016275, 627231031297)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17181114387, 25771180051)
            /*int */ GetBytes$9(/*ReadOnlySpan<char>*/ chars, /*Span<byte>*/ bytes, /*bool*/ write)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181114387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (chars.IsEmpty)
                {
                    return 0;
                }
                for(/*int*/ let i = 0; i < chars.Length; i++)
                {
                    /*char*/ let c = chars.get_Item(i).$v;
                    if (c >= (this._isAllowed.length >>> 0) || !$.$$.System.Array.$ReadT1.call(this._isAllowed, c))
                    {
                        this.EncoderFallback.CreateFallbackBuffer().Fallback$1(c, i);
                        $.$$.System.Diagnostics.Debug.Fail$1("Fallback should have thrown");
                        throw new $.$$.System.InvalidOperationException().$ctor$9();
                    }
                    if (write)
                    {
                        bytes.get_Item(i).$v = $.$cast(c, $.$$.System.Byte);
                    }
                }
                return chars.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17181114387, 25771180051)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21476081683, 51540983827)
            /*int */ GetChars$6(/*ReadOnlySpan<byte>*/ bytes, /*Span<char>*/ chars, /*bool*/ write)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476081683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (bytes.IsEmpty)
                {
                    return 0;
                }
                for(/*int*/ let i = 0; i < bytes.Length; i++)
                {
                    /*byte*/ let b = bytes.get_Item(i).$v;
                    if (b >= (this._isAllowed.length >>> 0) || !$.$$.System.Array.$ReadT1.call(this._isAllowed, b))
                    {
                        this.DecoderFallback.CreateFallbackBuffer().Fallback($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), [b], null, null), i);
                        $.$$.System.Diagnostics.Debug.Fail$1("Fallback should have thrown");
                        throw new $.$$.System.InvalidOperationException().$ctor$9();
                    }
                    if (write)
                    {
                        chars.get_Item(i).$v = b;
                    }
                }
                return bytes.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21476081683, 51540983827)
            
            static $h = 1245203;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1376275,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 25771048979, 622936064001),
    {
      "r": 655361,
      "p": [
        {
          "n": "charCount",
          "p": 655361
        }
      ],
      "n": "GetMaxByteCount",
      "d": 1245203,
      "h": 25771048979,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25771048979, 622936064001),
//--TRIMMABLE-BOUNDARY-START(ALL, 30066016275, 627231031297),
    {
      "r": 655361,
      "p": [
        {
          "n": "byteCount",
          "p": 655361
        }
      ],
      "n": "GetMaxCharCount",
      "d": 1245203,
      "h": 30066016275,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30066016275, 627231031297),
//--TRIMMABLE-BOUNDARY-START(ALL, 17181114387, 25771180051),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "bytes",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "write",
          "p": 262145
        }
      ],
      "n": "GetBytes",
      "o": "@$9",
      "d": 1245203,
      "h": 17181114387,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17181114387, 25771180051),
//--TRIMMABLE-BOUNDARY-START(ALL, 21476081683, 51540983827),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "chars",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "write",
          "p": 262145
        }
      ],
      "n": "GetChars",
      "o": "@$6",
      "d": 1245203,
      "h": 21476081683,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21476081683, 51540983827)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296212499),
    {
      "t": $.$typeArray($.$$.System.Boolean).$h,
      "n": "_isAllowed",
      "d": 1245203,
      "h": 4296212499,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212499)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591179795),
    {
      "p": [
        {
          "n": "minCharAllowed",
          "p": 393217
        },
        {
          "n": "maxCharAllowed",
          "p": 393217
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1245203,
      "h": 8591179795,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591179795),
//--TRIMMABLE-BOUNDARY-START(12886147091),
    {
      "p": [
        {
          "n": "allowedChars",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1245203,
      "h": 12886147091,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12886147091)
  ],
  "i": [89849857
  ],
  "h": 1245203
}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.SpanBasedEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.RestrictedAsciiStringEncoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245203)
        
        
        //--TRIMMABLE-BOUNDARY-START(262163)
        $asm.$cls("$sfa.System.Formats.Asn1.AsnDecoder", ($self) => class AsnDecoder
        {
            //--TRIMMABLE-BOUNDARY-START(133144248339)
            static /*bool */ ReadBoolean(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144248339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Boolean, 1/*UniversalTagNumber.Boolean*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (contents.Length !== 1)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*byte*/ let val = contents.get_Item(0).$v;
                if (val === 0)
                {
                    bytesConsumed.$v = consumed;
                    return false;
                }
                if (val !== 255 && (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/))
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                bytesConsumed.$v = consumed;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(133144248339)
            
            //--TRIMMABLE-BOUNDARY-START(193273790483)
            static /*void */ ReadNull(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273790483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Null, 5/*UniversalTagNumber.Null*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (contents.Length !== 0)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                bytesConsumed.$v = consumed;
            }
            //--TRIMMABLE-BOUNDARY-END(193273790483)
            
            //--TRIMMABLE-BOUNDARY-START(150324117523)
            static /*ReadOnlySpan<byte> */ ReadEnumeratedBytes(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324117523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Enumerated, 10/*UniversalTagNumber.Enumerated*/, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(150324117523)
            
            //--TRIMMABLE-BOUNDARY-START(154619084819)
            static /*TEnum */ ReadEnumeratedValue$1(TEnum, /*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619084819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let tEnum = TEnum.$type;
                return $.$cast($.$$.System.Enum.ToObject$4(tEnum, $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEnumeratedValue(source, ruleSet, tEnum, bytesConsumed, expectedTag?.Clone() ?? null)), TEnum);
            }
            //--TRIMMABLE-BOUNDARY-END(154619084819)
            
            //--TRIMMABLE-BOUNDARY-START(158914052115)
            static /*Enum */ ReadEnumeratedValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Type*/ enumType, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914052115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Equality$1(enumType, null))
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("enumType");
                }
                /*UniversalTagNumber*/ let TagNumber = 10/*UniversalTagNumber.Enumerated*/;
                /*Asn1Tag*/ let localTag = expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Enumerated;
                /*Type*/ let backingType = enumType.GetEnumUnderlyingType();
                if (enumType.IsDefined($.$$.System.FlagsAttribute.$type, false))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_EnumeratedValueRequiresNonFlagsEnum, "enumType");
                }
                /*int*/ let sizeLimit = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveIntegerSize(backingType);
                if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.Int32.$type) || $.$$.System.Type.op_Equality$1(backingType, $.$$.System.Int64.$type) || $.$$.System.Type.op_Equality$1(backingType, $.$$.System.Int16.$type) || $.$$.System.Type.op_Equality$1(backingType, $.$$.System.SByte.$type))
                {
                    /*long*/ let value;
                    /*int*/ let consumed;
                    if (!$.$sfa.System.Formats.Asn1.AsnDecoder.TryReadSignedInteger(source, ruleSet, sizeLimit, localTag, TagNumber, $.$ref(() => value, ($v) => value = $v, $.$$.System.Int64), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32)))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_EnumeratedValueTooBig);
                    }
                    bytesConsumed.$v = consumed;
                    return $.$cast($.$$.System.Enum.ToObject$3(enumType, value), $.$$.System.Enum);
                }
                if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.UInt32.$type) || $.$$.System.Type.op_Equality$1(backingType, $.$$.System.UInt64.$type) || $.$$.System.Type.op_Equality$1(backingType, $.$$.System.UInt16.$type) || $.$$.System.Type.op_Equality$1(backingType, $.$$.System.Byte.$type))
                {
                    /*ulong*/ let value;
                    /*int*/ let consumed;
                    if (!$.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUnsignedInteger(source, ruleSet, sizeLimit, localTag, TagNumber, $.$ref(() => value, ($v) => value = $v, $.$$.System.UInt64), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32)))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_EnumeratedValueTooBig);
                    }
                    bytesConsumed.$v = consumed;
                    return $.$cast($.$$.System.Enum.ToObject$8(enumType, value), $.$$.System.Enum);
                }
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.Format$6($.$sfa.System.SR.Argument_EnumeratedValueBackingTypeNotSupported, backingType.FullName));
            }
            //--TRIMMABLE-BOUNDARY-END(158914052115)
            
            //--TRIMMABLE-BOUNDARY-START(214748626963)
            static /*void */ ReadSetOf(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed, /*bool*/ skipSortOrderValidation, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748626963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int?*/ let length;
                /*int*/ let headerLength;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(source, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32));
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(tag, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.SetOf, 17/*UniversalTagNumber.SetOf*/);
                if (!tag.IsConstructed)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.Format$6($.$sfa.System.SR.ContentException_ConstructedEncodingRequired, $.$box(17/*UniversalTagNumber.SetOf*/, $.$sfa.System.Formats.Asn1.UniversalTagNumber)));
                }
                /*int*/ let suffix;
                /*ReadOnlySpan<byte>*/ let contents;
                if ($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(length))
                {
                    suffix = 0;
                    contents = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(source, headerLength, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length));
                }
                else 
                {
                    /*int*/ let actualLength = $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(source.Slice$1(headerLength), ruleSet);
                    contents = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(source, headerLength, actualLength);
                    suffix = 2/*EndOfContentsEncodedLength*/;
                }
                if (!skipSortOrderValidation)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                    {
                        /*ReadOnlySpan<byte>*/ let remaining = contents;
                        /*ReadOnlySpan<byte>*/ let previous = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))();
                        while(!remaining.IsEmpty)
                        {
                            /*int*/ let consumed;
                            $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEncodedValue(remaining, ruleSet, $.$discardRef(), $.$discardRef(), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                            /*ReadOnlySpan<byte>*/ let current = remaining.Slice(0, consumed);
                            remaining = remaining.Slice$1(consumed);
                            if ($.$sfa.System.Formats.Asn1.SetOfValueComparer.Compare$1(current, previous) < 0)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_SetOfNotSorted);
                            }
                            previous = current;
                        }
                    }
                }
                contentOffset.$v = headerLength;
                contentLength.$v = contents.Length;
                bytesConsumed.$v = ((((headerLength + contents.Length) | 0) + suffix) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(214748626963)
            
            //--TRIMMABLE-BOUNDARY-START(197568757779)
            static /*string */ ReadObjectIdentifier(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568757779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ObjectIdentifier, 6/*UniversalTagNumber.ObjectIdentifier*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                /*string?*/ let wellKnown = $.$sfa.System.Formats.Asn1.WellKnownOids.GetValue(contents);
                if (!(wellKnown === null))
                {
                    bytesConsumed.$v = consumed;
                    return wellKnown;
                }
                /*string*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadObjectIdentifier$1(contents);
                bytesConsumed.$v = consumed;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(197568757779)
            
            //--TRIMMABLE-BOUNDARY-START(219043594259)
            static /*void */ ReadSubIdentifier(/*ReadOnlySpan<byte>*/ source, /*out int*/ bytesRead, /*out long?*/ smallValue, /*out BigInteger?*/ largeValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043594259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(source.Length > 0, "source.Length > 0");
                if (source.get_Item(0).$v === 128)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*int*/ let semanticBits = (() =>
                {
                    let $switch1 = source.get_Item(0).$v;
                    if ($switch1 >= 192)
                    {
                        return 0;
                    }
                    if ($switch1 >= 160)
                    {
                        return -1;
                    }
                    if ($switch1 >= 144)
                    {
                        return -2;
                    }
                    if ($switch1 >= 136)
                    {
                        return -3;
                    }
                    if ($switch1 >= 132)
                    {
                        return -4;
                    }
                    if ($switch1 >= 130)
                    {
                        return -5;
                    }
                    if ($switch1 >= 129)
                    {
                        return -6;
                    }
                    return 0;
                })();
                /*int*/ let end = -1;
                /*int*/ let idx;
                /*int*/ let MaxAllowedBits = 128;
                for(idx = 0; idx < source.Length; idx++)
                {
                    semanticBits += 7;
                    if (semanticBits > MaxAllowedBits)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_OidTooBig);
                    }
                    /*bool*/ let endOfIdentifier = (source.get_Item(idx).$v & 128) === 0;
                    if (endOfIdentifier)
                    {
                        end = idx;
                        break;
                    }
                }
                if (end < 0)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                bytesRead.$v = ((end + 1) | 0);
                /*long*/ let accum = 0n;
                if (bytesRead.$v <= 9)
                {
                    for(idx = 0; idx < bytesRead.$v; idx++)
                    {
                        /*byte*/ let cur = source.get_Item(idx).$v;
                        accum <<= 7n;
                        accum |= BigInt($.$cast((cur & 127), $.$$.System.Byte));
                    }
                    largeValue.$v = null;
                    smallValue.$v = accum;
                    return;
                }
                /*int*/ let SemanticByteCount = 7;
                /*int*/ let ContentByteCount = 8;
                /*int*/ let bytesRequired = (((((($.trunc(bytesRead.$v / ContentByteCount)) + 1) | 0)) * SemanticByteCount) | 0);
                /*byte[]*/ let tmpBytes = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(bytesRequired);
                $.$$.System.Array.Clear(tmpBytes, 0, tmpBytes.length);
                /*Span<byte>*/ let writeSpan = $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(tmpBytes);
                /*Span<byte>*/ let accumValueBytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, $.$$.System.Int64.$z, null);
                /*int*/ let nextStop = bytesRead.$v;
                idx = ((bytesRead.$v - ContentByteCount) | 0);
                while(nextStop > 0)
                {
                    /*byte*/ let cur = source.get_Item(idx).$v;
                    accum <<= 7n;
                    accum |= BigInt($.$cast((cur & 127), $.$$.System.Byte));
                    idx++;
                    if (idx >= nextStop)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(idx === nextStop, "idx == nextStop");
                        $.$$.System.Diagnostics.Debug.Assert$2(writeSpan.Length >= SemanticByteCount, "writeSpan.Length >= SemanticByteCount");
                        $.$$.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian(accumValueBytes, accum);
                        $.$$.System.Diagnostics.Debug.Assert$2(accumValueBytes.get_Item(7).$v === 0, "accumValueBytes[7] == 0");
                        accumValueBytes.Slice(0, SemanticByteCount).CopyTo(writeSpan);
                        writeSpan = writeSpan.Slice$1(SemanticByteCount);
                        accum = 0n;
                        nextStop -= ContentByteCount;
                        idx = $.$$.System.Math.Max$4(0, ((nextStop - ContentByteCount) | 0));
                    }
                }
                /*int*/ let bytesWritten = ((tmpBytes.length - writeSpan.Length) | 0);
                /*int*/ let paddingByteCount = ((bytesRequired - bytesWritten) | 0);
                $.$$.System.Diagnostics.Debug.Assert$2(paddingByteCount >= 0 && paddingByteCount < $.$$.System.Int64.$z, "paddingByteCount >= 0 && paddingByteCount < sizeof(long)");
                largeValue.$v = new $.$srn.System.Numerics.BigInteger().$ctor$3(tmpBytes);
                smallValue.$v = null;
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(tmpBytes, bytesWritten);
            }
            //--TRIMMABLE-BOUNDARY-END(219043594259)
            
            //--TRIMMABLE-BOUNDARY-START(201863725075)
            static /*string */ ReadObjectIdentifier$1(/*ReadOnlySpan<byte>*/ contents)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863725075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (contents.Length < 1)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*StringBuilder*/ let builder = new $.$$.System.Text.StringBuilder().$ctor$4(((($.$cast(contents.Length, $.$$.System.Byte)) * 4) | 0));
                /*int*/ let bytesRead;
                /*long?*/ let smallValue;
                /*BigInteger?*/ let largeValue;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadSubIdentifier(contents, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => smallValue, ($v) => smallValue = $v, $.$typeNullable($.$$.System.Int64)), $.$ref(() => largeValue, ($v) => largeValue = $v, $.$typeNullable($.$srn.System.Numerics.BigInteger)));
                /*byte*/ let firstArc;
                if (smallValue !== null)
                {
                    /*long*/ let firstIdentifier = $.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(smallValue);
                    if (firstIdentifier < 40n)
                    {
                        firstArc = 0;
                    }
                    else if (firstIdentifier < 80n)
                    {
                        firstArc = 1;
                        firstIdentifier -= 40n;
                    }
                    else 
                    {
                        firstArc = 2;
                        firstIdentifier -= 80n;
                    }
                    builder.Append$1(firstArc);
                    builder.Append$3(/*.*/ 46);
                    builder.Append$12(firstIdentifier);
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(largeValue !== null, "largeValue != null");
                    /*BigInteger*/ let firstIdentifier = $.$$.System.Nullable$$($.$srn.System.Numerics.BigInteger).Value$get.call(largeValue);
                    $.$$.System.Diagnostics.Debug.Assert$2($.$srn.System.Numerics.BigInteger.op_GreaterThan$2(firstIdentifier, 9223372036854775807n), "firstIdentifier > long.MaxValue");
                    firstArc = 2;
                    firstIdentifier = $.$srn.System.Numerics.BigInteger.op_Subtraction(firstIdentifier, $.$srn.System.Numerics.BigInteger.op_Implicit$4(80));
                    builder.Append$1(firstArc);
                    builder.Append$3(/*.*/ 46);
                    builder.Append$19($.$srn.System.Numerics.BigInteger.ToString.call(firstIdentifier));
                }
                contents = contents.Slice$1(bytesRead);
                /*int*/ let MaxArcs = 64;
                /*int*/ let remainingArcs = ((MaxArcs - 2) | 0);
                while(!contents.IsEmpty)
                {
                    if (remainingArcs <= 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_OidTooBig);
                    }
                    remainingArcs--;
                    $.$sfa.System.Formats.Asn1.AsnDecoder.ReadSubIdentifier(contents, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => smallValue, ($v) => smallValue = $v, $.$typeNullable($.$$.System.Int64)), $.$ref(() => largeValue, ($v) => largeValue = $v, $.$typeNullable($.$srn.System.Numerics.BigInteger)));
                    $.$$.System.Diagnostics.Debug.Assert$2((smallValue === null) !== (largeValue === null), "(smallValue == null) != (largeValue == null)");
                    builder.Append$3(/*.*/ 46);
                    if (smallValue !== null)
                    {
                        builder.Append$12($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(smallValue));
                    }
                    else 
                    {
                        builder.Append$19($.$srn.System.Numerics.BigInteger.ToString.call($.$$.System.Nullable$$($.$srn.System.Numerics.BigInteger).Value$get.call(largeValue)));
                    }
                    contents = contents.Slice$1(bytesRead);
                }
                return $.$$.System.Text.StringBuilder.ToString.call(builder);
            }
            //--TRIMMABLE-BOUNDARY-END(201863725075)
            
            //--TRIMMABLE-BOUNDARY-START(313532874771)
            static /*bool */ TryReadOctetString(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532874771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Byte, source, $.$$.System.Span$$($.$$.System.Byte).op_Implicit(destination)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_SourceOverlapsDestination, "destination");
                }
                /*int?*/ let contentLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let contents;
                /*int*/ let consumed;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString, 4/*UniversalTagNumber.OctetString*/, $.$ref(() => contentLength, ($v) => contentLength = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32), $.$ref(() => contents, ($v) => contents = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32)))
                {
                    if (contents.Length > destination.Length)
                    {
                        bytesWritten.$v = 0;
                        bytesConsumed.$v = 0;
                        return false;
                    }
                    contents.CopyTo(destination);
                    bytesWritten.$v = contents.Length;
                    bytesConsumed.$v = consumed;
                    return true;
                }
                /*int*/ let bytesRead;
                /*bool*/ let copied = $.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedOctetStringContents($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength, contentLength), ruleSet, destination, contentLength === null, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), bytesWritten);
                if (copied)
                {
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                }
                else 
                {
                    bytesConsumed.$v = 0;
                }
                return copied;
            }
            //--TRIMMABLE-BOUNDARY-END(313532874771)
            
            //--TRIMMABLE-BOUNDARY-START(206158692371)
            static /*byte[] */ ReadOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158692371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]?*/ let rented = null;
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString, 4/*UniversalTagNumber.OctetString*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.System.Byte)), new ($.$$.System.Span$$($.$$.System.Byte))());
                /*byte[]*/ let ret = contents.ToArray();
                if (rented !== null)
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = consumed;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(206158692371)
            
            //--TRIMMABLE-BOUNDARY-START(335007711251)
            static /*bool */ TryReadPrimitiveOctetStringCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*out int?*/ contentLength, /*out int*/ headerLength, /*out ReadOnlySpan<byte>*/ contents, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007711251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Asn1Tag*/ let actualTag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(source, ruleSet, contentLength, headerLength);
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(actualTag, expectedTag, universalTagNumber);
                /*ReadOnlySpan<byte>*/ let encodedValue = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength.$v, contentLength.$v);
                if (actualTag.IsConstructed)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderDer_TryBerOrCer);
                    }
                    contents.$v = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))();
                    bytesConsumed.$v = 0;
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(contentLength.$v), "contentLength.HasValue");
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && encodedValue.Length > 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCer_TryBerOrDer);
                }
                contents.$v = encodedValue;
                bytesConsumed.$v = ((headerLength.$v + encodedValue.Length) | 0);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(335007711251)
            
            //--TRIMMABLE-BOUNDARY-START(330712743955)
            static /*bool */ TryReadPrimitiveOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712743955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString, 4/*UniversalTagNumber.OctetString*/, $.$discardRef(), $.$discardRef(), value, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(330712743955)
            
            //--TRIMMABLE-BOUNDARY-START(42949935123)
            static /*int */ CountConstructedOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*bool*/ isIndefinite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let contentLength = $.$sfa.System.Formats.Asn1.AsnDecoder.CopyConstructedOctetString(source, ruleSet, $.$$.System.Span$$($.$$.System.Byte).Empty, false, isIndefinite, $.$discardRef());
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && contentLength <= 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                return contentLength;
            }
            //--TRIMMABLE-BOUNDARY-END(42949935123)
            
            //--TRIMMABLE-BOUNDARY-START(30065033235)
            static /*void */ CopyConstructedOctetString$1(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*bool*/ isIndefinite, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bytesWritten.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.CopyConstructedOctetString(source, ruleSet, destination, true, isIndefinite, bytesRead);
            }
            //--TRIMMABLE-BOUNDARY-END(30065033235)
            
            //--TRIMMABLE-BOUNDARY-START(34360000531)
            static /*int */ CopyConstructedOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*bool*/ write, /*bool*/ isIndefinite, /*out int*/ bytesRead)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bytesRead.$v = 0;
                /*int*/ let lastSegmentLength = 1000/*MaxCERSegmentSize*/;
                /*ReadOnlySpan<byte>*/ let cur = source;
                /*Stack<(int Offset, int Length, bool IsIndefinite, int BytesRead)>?*/ let readerStack = null;
                /*int*/ let totalLength = 0;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedBitString;
                /*Span<byte>*/ let curDest = destination;
                while(true)
                {
                    while(!cur.IsEmpty)
                    {
                        /*int?*/ let length;
                        /*int*/ let headerLength;
                        tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(cur, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32));
                        if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString))
                        {
                            if (ruleSet === 1/*AsnEncodingRules.CER*/ && lastSegmentLength !== 1000/*MaxCERSegmentSize*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(length !== null, "length != null");
                            /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(cur, headerLength, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length));
                            /*int*/ let localLen = ((headerLength + contents.Length) | 0);
                            cur = cur.Slice$1(localLen);
                            bytesRead.$v += localLen;
                            totalLength += contents.Length;
                            lastSegmentLength = contents.Length;
                            if (ruleSet === 1/*AsnEncodingRules.CER*/ && lastSegmentLength > 1000/*MaxCERSegmentSize*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            if (write)
                            {
                                contents.CopyTo(curDest);
                                curDest = curDest.Slice$1(contents.Length);
                            }
                        }
                        else if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents) && isIndefinite)
                        {
                            $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateEndOfContents(tag, length, headerLength);
                            bytesRead.$v += headerLength;
                            if ($.$$.System.Int32.op_GreaterThan$1((readerStack?.Count ?? null), 0))
                            {
                                const { Item1: topOffset, Item2: topLength, Item3: wasIndefinite, Item4: pushedBytesRead } = readerStack.Pop();
                                /*ReadOnlySpan<byte>*/ let topSpan = source.Slice(topOffset, topLength);
                                cur = topSpan.Slice$1(bytesRead.$v);
                                bytesRead.$v += pushedBytesRead;
                                isIndefinite = wasIndefinite;
                            }
                            else 
                            {
                                break;
                            }
                        }
                        else if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedOctetString))
                        {
                            if (ruleSet === 1/*AsnEncodingRules.CER*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            readerStack ??= new ($.$sc.System.Collections.Generic.Stack$$($.$$.System.ValueTuple$$$$$($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Boolean, $.$$.System.Int32)))().$ctor$1();
                            /*int*/ let curOffset;
                            if (!$.$$.System.MemoryExtensions.Overlaps($.$$.System.Byte, source, cur, $.$ref(() => curOffset, ($v) => curOffset = $v, $.$$.System.Int32)))
                            {
                                $.$$.System.Diagnostics.Debug.Fail$1("Non-overlapping data encountered...");
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                            }
                            readerStack.Push(new ($.$$.System.ValueTuple$$$$$($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Boolean, $.$$.System.Int32))().$ctor$3(curOffset, cur.Length, isIndefinite, bytesRead.$v));
                            cur = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(cur, headerLength, length);
                            bytesRead.$v = headerLength;
                            isIndefinite = (length === null);
                        }
                        else 
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                    }
                    if (isIndefinite && $.$sfa.System.Formats.Asn1.Asn1Tag.op_Inequality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    if ($.$$.System.Int32.op_GreaterThan$1((readerStack?.Count ?? null), 0))
                    {
                        const { Item1: topOffset, Item2: topLength, Item3: wasIndefinite, Item4: pushedBytesRead } = readerStack.Pop();
                        /*ReadOnlySpan<byte>*/ let topSpan = source.Slice(topOffset, topLength);
                        cur = topSpan.Slice$1(bytesRead.$v);
                        isIndefinite = wasIndefinite;
                        bytesRead.$v += pushedBytesRead;
                    }
                    else 
                    {
                        return totalLength;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360000531)
            
            //--TRIMMABLE-BOUNDARY-START(261993267219)
            static /*bool */ TryCopyConstructedOctetStringContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ dest, /*bool*/ isIndefinite, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993267219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bytesRead.$v = 0;
                /*int*/ let contentLength = $.$sfa.System.Formats.Asn1.AsnDecoder.CountConstructedOctetString(source, ruleSet, isIndefinite);
                if (dest.Length < contentLength)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                $.$sfa.System.Formats.Asn1.AsnDecoder.CopyConstructedOctetString$1(source, ruleSet, dest, isIndefinite, bytesRead, bytesWritten);
                $.$$.System.Diagnostics.Debug.Assert$2(bytesWritten.$v === contentLength, "bytesWritten == contentLength");
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(261993267219)
            
            //--TRIMMABLE-BOUNDARY-START(64424771603)
            static /*ReadOnlySpan<byte> */ GetOctetStringContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*out int*/ bytesConsumed, /*ref byte[]?*/ rented, /*Span<byte>*/ tmpSpace)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424771603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(rented.$v === null, "rented == null");
                /*int?*/ let contentLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let contents;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => contentLength, ($v) => contentLength = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32), $.$ref(() => contents, ($v) => contents = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), bytesConsumed))
                {
                    return contents;
                }
                contents = source.Slice$1(headerLength);
                /*int*/ let tooBig = contentLength ?? $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(contents, ruleSet);
                if (tmpSpace.Length > 0 && tooBig > tmpSpace.Length)
                {
                    /*bool*/ let isIndefinite = contentLength === null;
                    tooBig = $.$sfa.System.Formats.Asn1.AsnDecoder.CountConstructedOctetString(contents, ruleSet, isIndefinite);
                }
                if (tooBig > tmpSpace.Length)
                {
                    rented.$v = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(tooBig);
                    tmpSpace = $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rented.$v);
                }
                /*int*/ let bytesRead;
                /*int*/ let bytesWritten;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedOctetStringContents($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength, contentLength), ruleSet, tmpSpace, contentLength === null, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32)))
                {
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                    return $.$$.System.Span$$($.$$.System.Byte).op_Implicit(tmpSpace.Slice(0, bytesWritten));
                }
                $.$$.System.Diagnostics.Debug.Fail$1("TryCopyConstructedOctetStringContents failed with a pre-allocated buffer");
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(64424771603)
            
            //--TRIMMABLE-BOUNDARY-START(184683855891)
            static /*TFlagsEnum */ ReadNamedBitListValue$1(TFlagsEnum, /*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683855891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let tFlagsEnum = TFlagsEnum.$type;
                /*int*/ let consumed;
                /*TFlagsEnum*/ let ret = $.$cast($.$$.System.Enum.ToObject$4(tFlagsEnum, $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNamedBitListValue(source, ruleSet, tFlagsEnum, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null)), TFlagsEnum);
                bytesConsumed.$v = consumed;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(184683855891)
            
            //--TRIMMABLE-BOUNDARY-START(188978823187)
            static /*Enum */ ReadNamedBitListValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Type*/ flagsEnumType, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978823187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Equality$1(flagsEnumType, null))
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("flagsEnumType");
                }
                /*Type*/ let backingType = flagsEnumType.GetEnumUnderlyingType();
                if (!flagsEnumType.IsDefined($.$$.System.FlagsAttribute.$type, false))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_NamedBitListRequiresFlagsEnum, "flagsEnumType");
                }
                /*Span<byte>*/ let stackSpan = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, $.$$.System.UInt64.$z, null);
                /*int*/ let sizeLimit = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveIntegerSize(backingType);
                stackSpan = stackSpan.Slice(0, sizeLimit);
                /*int*/ let unusedBitCount;
                /*int*/ let consumed;
                /*int*/ let bytesWritten;
                /*bool*/ let read = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadBitString(source, stackSpan, ruleSet, $.$ref(() => unusedBitCount, ($v) => unusedBitCount = $v, $.$$.System.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                if (!read)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.Format$6($.$sfa.System.SR.ContentException_NamedBitListValueTooBig, flagsEnumType.Name));
                }
                /*Enum*/ let ret;
                if (bytesWritten === 0)
                {
                    ret = $.$cast($.$$.System.Enum.ToObject$2(flagsEnumType, 0), $.$$.System.Enum);
                    bytesConsumed.$v = consumed;
                    return ret;
                }
                /*ReadOnlySpan<byte>*/ let valueSpan = $.$$.System.Span$$($.$$.System.Byte).op_Implicit(stackSpan.Slice(0, bytesWritten));
                if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                {
                    /*byte*/ let lastByte = valueSpan.get_Item(((bytesWritten - 1) | 0)).$v;
                    /*byte*/ let testBit = $.$cast((1 << unusedBitCount), $.$$.System.Byte);
                    if ((lastByte & testBit) === 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                ret = $.$cast($.$$.System.Enum.ToObject$3(flagsEnumType, $.$sfa.System.Formats.Asn1.AsnDecoder.InterpretNamedBitListReversed(valueSpan)), $.$$.System.Enum);
                bytesConsumed.$v = consumed;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(188978823187)
            
            //--TRIMMABLE-BOUNDARY-START(180388888595)
            static /*BitArray */ ReadNamedBitList(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388888595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let contentLength;
                /*Asn1Tag*/ let actualTag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEncodedValue(source, ruleSet, $.$discardRef(), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$$.System.Int32), $.$discardRef());
                if (expectedTag !== null)
                {
                    $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(actualTag, $.$$.System.Nullable$$($.$sfa.System.Formats.Asn1.Asn1Tag).Value$get.call(expectedTag), 3/*UniversalTagNumber.BitString*/);
                }
                /*byte[]*/ let rented = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(contentLength);
                /*int*/ let unusedBitCount;
                /*int*/ let consumed;
                /*int*/ let written;
                if (!$.$sfa.System.Formats.Asn1.AsnDecoder.TryReadBitString(source, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rented), ruleSet, $.$ref(() => unusedBitCount, ($v) => unusedBitCount = $v, $.$$.System.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), $.$ref(() => written, ($v) => written = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null))
                {
                    $.$$.System.Diagnostics.Debug.Fail$1("TryReadBitString failed with an over-allocated buffer");
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                /*int*/ let validBitCount = $.$checked($.$checked(written * 8, 1) - unusedBitCount, 1);
                /*Span<byte>*/ let valueSpan = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, rented, 0, written);
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReverseBitsPerByte(valueSpan);
                /*BitArray*/ let ret = new $.$$.System.Collections.BitArray().$ctor$2(rented);
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, written);
                ret.Length = validBitCount;
                bytesConsumed.$v = consumed;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(180388888595)
            
            //--TRIMMABLE-BOUNDARY-START(81604640787)
            static /*long */ InterpretNamedBitListReversed(/*ReadOnlySpan<byte>*/ valueSpan)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(valueSpan.Length <= $.$$.System.Int64.$z, "valueSpan.Length <= sizeof(long)");
                /*long*/ let accum = 0n;
                /*long*/ let currentBitValue = 1n;
                for(/*int*/ let byteIdx = 0; byteIdx < valueSpan.Length; byteIdx++)
                {
                    /*byte*/ let byteVal = valueSpan.get_Item(byteIdx).$v;
                    for(/*int*/ let bitIndex = 7; bitIndex >= 0; bitIndex--)
                    {
                        /*int*/ let test = 1 << bitIndex;
                        if ((byteVal & test) !== 0)
                        {
                            accum |= currentBitValue;
                        }
                        currentBitValue <<= 1n;
                    }
                }
                return accum;
            }
            //--TRIMMABLE-BOUNDARY-END(81604640787)
            
            //--TRIMMABLE-BOUNDARY-START(231928496147)
            static /*void */ ReverseBitsPerByte(/*Span<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928496147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let byteIdx = 0; byteIdx < value.Length; byteIdx++)
                {
                    value.get_Item(byteIdx).$v = $.$cast(((BigInt(value.get_Item(byteIdx).$v) * 8623620610n & 1136090292240n) % 1023n), $.$$.System.Byte);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231928496147)
            
            //--TRIMMABLE-BOUNDARY-START(210453659667)
            static /*void */ ReadSequence(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453659667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int?*/ let length;
                /*int*/ let headerLength;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(source, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32));
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(tag, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Sequence, 16/*UniversalTagNumber.Sequence*/);
                if (!tag.IsConstructed)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.Format$6($.$sfa.System.SR.ContentException_ConstructedEncodingRequired, $.$box(16/*UniversalTagNumber.Sequence*/, $.$sfa.System.Formats.Asn1.UniversalTagNumber)));
                }
                if ($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(length))
                {
                    if ($.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length) > ((source.Length - headerLength) | 0))
                    {
                        throw $.$sfa.System.Formats.Asn1.AsnDecoder.GetValidityException(2/*LengthValidity.LengthExceedsInput*/);
                    }
                    contentLength.$v = $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length);
                    contentOffset.$v = headerLength;
                    bytesConsumed.$v = ((contentLength.$v + headerLength) | 0);
                }
                else 
                {
                    /*int*/ let len = $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(source.Slice$1(headerLength), ruleSet);
                    contentLength.$v = len;
                    contentOffset.$v = headerLength;
                    bytesConsumed.$v = ((((len + headerLength) | 0) + 2/*EndOfContentsEncodedLength*/) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(210453659667)
            
            //--TRIMMABLE-BOUNDARY-START(163209019411)
            static /*DateTimeOffset */ ReadGeneralizedTime(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209019411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]?*/ let rented = null;
                /*int*/ let StackBufSize = 64;
                /*Span<byte>*/ let tmpSpace = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, StackBufSize, null);
                /*int*/ let bytesRead;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.GeneralizedTime, 24/*UniversalTagNumber.GeneralizedTime*/, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.System.Byte)), tmpSpace);
                /*DateTimeOffset*/ let value = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseGeneralizedTime(ruleSet, contents);
                if (rented !== null)
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = bytesRead;
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(163209019411)
            
            //--TRIMMABLE-BOUNDARY-START(103079477267)
            static /*DateTimeOffset */ ParseGeneralizedTime(/*AsnEncodingRules*/ ruleSet, /*ReadOnlySpan<byte>*/ contentOctets)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079477267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let strict = ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/;
                if (strict && contentOctets.Length < 15)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                else if (contentOctets.Length < 10)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*ReadOnlySpan<byte>*/ let contents = contentOctets;
                /*int*/ let year = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 4);
                /*int*/ let month = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let day = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let hour = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int?*/ let minute = null;
                /*int?*/ let second = null;
                /*ulong*/ let fraction = 0n;
                /*ulong*/ let fractionScale = 1n;
                /*byte*/ let lastFracDigit = 255;
                /*TimeSpan?*/ let timeOffset = null;
                /*bool*/ let isZulu = false;
                /*byte*/ let HmsState = 0;
                /*byte*/ let FracState = 1;
                /*byte*/ let SuffixState = 2;
                /*byte*/ let state = HmsState;
                /*static byte?*/  function GetNextState(/*byte*/ octet)
                {
                    if (octet === /*Z*/ 90 || octet === /*-*/ 45 || octet === /*+*/ 43)
                    {
                        return SuffixState;
                    }
                    if (octet === /*.*/ 46 || octet === /*,*/ 44)
                    {
                        return FracState;
                    }
                    return null;
                }
                while(state === HmsState && contents.Length !== 0)
                {
                    /*byte?*/ let nextState = GetNextState(contents.get_Item(0).$v);
                    if (nextState === null)
                    {
                        if (minute === null)
                        {
                            minute = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                        }
                        else if (second === null)
                        {
                            second = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                        }
                        else 
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                    }
                    else 
                    {
                        state = $.$$.System.Nullable$$($.$$.System.Byte).Value$get.call(nextState);
                    }
                }
                if (state === FracState)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!contents.IsEmpty, "!contents.IsEmpty");
                    /*byte*/ let octet = contents.get_Item(0).$v;
                    $.$$.System.Diagnostics.Debug.Assert$2(state === GetNextState(octet), "state == GetNextState(octet)");
                    if (octet === /*.*/ 46)
                    {
                    }
                    else if (octet === /*,*/ 44)
                    {
                        if (strict)
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                        }
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Fail$1((() =>
                        {
                            var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(2, 2);
                            $handler.AppendLiteral("Unhandled value '");
                            $handler.AppendFormatted($.$box(octet, $.$$.System.Byte), null, "X2");
                            $handler.AppendLiteral("' in ");
                            $handler.AppendFormatted($.$box("FracState", $.$$.System.String), null, null);
                            return $handler.ToStringAndClear                    ();
                        })());
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    contents = contents.Slice$1(1);
                    if (contents.IsEmpty)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    /*int*/ let fracLength;
                    if (!$.$$.System.Buffers.Text.Utf8Parser.TryParse$15($.$sfa.System.Formats.Asn1.AsnDecoder.SliceAtMost(contents, 12), $.$ref(() => fraction, ($v) => fraction = $v, $.$$.System.UInt64), $.$ref(() => fracLength, ($v) => fracLength = $v, $.$$.System.Int32), /*\u0000*/ 0) || fracLength === 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    lastFracDigit = $.$cast((fraction % 10n), $.$$.System.Byte);
                    for(/*int*/ let i = 0; i < fracLength; i++)
                    {
                        fractionScale *= 10n;
                    }
                    contents = contents.Slice$1(fracLength);
                    /*uint*/ let nonSemantic;
                    while($.$$.System.Buffers.Text.Utf8Parser.TryParse$14($.$sfa.System.Formats.Asn1.AsnDecoder.SliceAtMost(contents, 9), $.$ref(() => nonSemantic, ($v) => nonSemantic = $v, $.$$.System.UInt32), $.$ref(() => fracLength, ($v) => fracLength = $v, $.$$.System.Int32), /*\u0000*/ 0))
                    {
                        contents = contents.Slice$1(fracLength);
                        lastFracDigit = $.$cast((nonSemantic % 10), $.$$.System.Byte);
                    }
                    if (contents.Length !== 0)
                    {
                        /*byte?*/ let nextState = GetNextState(contents.get_Item(0).$v);
                        if (nextState === null)
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                        state = $.$$.System.Nullable$$($.$$.System.Byte).Value$get.call(nextState);
                    }
                }
                if (state === SuffixState)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!contents.IsEmpty, "!contents.IsEmpty");
                    /*byte*/ let octet = contents.get_Item(0).$v;
                    $.$$.System.Diagnostics.Debug.Assert$2(state === GetNextState(octet), "state == GetNextState(octet)");
                    contents = contents.Slice$1(1);
                    if (octet === /*Z*/ 90)
                    {
                        timeOffset = $.$$.System.TimeSpan.Zero;
                        isZulu = true;
                    }
                    else 
                    {
                        /*bool*/ let isMinus;
                        if (octet === /*+*/ 43)
                        {
                            isMinus = false;
                        }
                        else if (octet === /*-*/ 45)
                        {
                            isMinus = true;
                        }
                        else 
                        {
                            $.$$.System.Diagnostics.Debug.Fail$1((() =>
                            {
                                var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(2, 2);
                                $handler.AppendLiteral("Unhandled value '");
                                $handler.AppendFormatted($.$box(octet, $.$$.System.Byte), null, "X2");
                                $handler.AppendLiteral("' in ");
                                $handler.AppendFormatted($.$box("SuffixState", $.$$.System.String), null, null);
                                return $handler.ToStringAndClear                        ();
                            })());
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                        if (contents.IsEmpty)
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                        /*int*/ let offsetHour = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                        /*int*/ let offsetMinute = 0;
                        if (contents.Length !== 0)
                        {
                            offsetMinute = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                        }
                        if (offsetMinute > 59)
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                        /*TimeSpan*/ let tmp = new $.$$.System.TimeSpan().$ctor$6(offsetHour, offsetMinute, 0);
                        if (isMinus)
                        {
                            tmp = $.$$.System.TimeSpan.op_UnaryNegation(tmp);
                        }
                        timeOffset = tmp;
                    }
                }
                if (!contents.IsEmpty)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                if (strict)
                {
                    if (!isZulu || !$.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(second))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                    if (lastFracDigit === 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                /*double*/ let frac = $.$cast(fraction, $.$$.System.Double) / Number(fractionScale);
                /*TimeSpan*/ let fractionSpan = $.$$.System.TimeSpan.Zero;
                if (!$.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(minute))
                {
                    minute = 0;
                    second = 0;
                    if (fraction !== 0n)
                    {
                        fractionSpan = new $.$$.System.TimeSpan().$ctor$7($.$cast((frac * Number(36000000000n)), $.$$.System.Int64));
                    }
                }
                else if (!$.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(second))
                {
                    second = 0;
                    if (fraction !== 0n)
                    {
                        fractionSpan = new $.$$.System.TimeSpan().$ctor$7($.$cast((frac * Number(600000000n)), $.$$.System.Int64));
                    }
                }
                else if (fraction !== 0n)
                {
                    fractionSpan = new $.$$.System.TimeSpan().$ctor$7($.$cast((frac * Number(10000000n)), $.$$.System.Int64));
                }
                /*DateTimeOffset*/ let value;
                try
                {
                    if (timeOffset === null)
                    {
                        value = new $.$$.System.DateTimeOffset().$ctor$5(new $.$$.System.DateTime().$ctor$16(year, month, day, hour, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(minute), $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(second)));
                    }
                    else 
                    {
                        value = new $.$$.System.DateTimeOffset().$ctor$11(year, month, day, hour, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(minute), $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(second), $.$$.System.Nullable$$($.$$.System.TimeSpan).Value$get.call(timeOffset));
                    }
                    value = $.$$.System.DateTimeOffset.op_Addition(value, fractionSpan);
                    return value;
                }
                catch(e)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$7($.$sfa.System.SR.ContentException_DefaultMessage, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079477267)
            
            //--TRIMMABLE-BOUNDARY-START(171798954003)
            static /*ReadOnlySpan<byte> */ ReadIntegerBytes(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798954003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(171798954003)
            
            //--TRIMMABLE-BOUNDARY-START(167503986707)
            static /*BigInteger */ ReadInteger(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503986707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadIntegerBytes(source, ruleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                /*BigInteger*/ let value = new $.$srn.System.Numerics.BigInteger().$ctor$9(contents, false, true);
                bytesConsumed.$v = consumed;
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(167503986707)
            
            //--TRIMMABLE-BOUNDARY-START(300647972883)
            static /*bool */ TryReadInt32(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300647972883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let longValue;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadSignedInteger(source, ruleSet, $.$$.System.Int32.$z, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, $.$ref(() => longValue, ($v) => longValue = $v, $.$$.System.Int64), bytesConsumed))
                {
                    value.$v = $.$cast(longValue, $.$$.System.Int32);
                    return true;
                }
                value.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(300647972883)
            
            //--TRIMMABLE-BOUNDARY-START(343597645843)
            static /*bool */ TryReadUInt32(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out uint*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597645843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ulong*/ let ulongValue;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUnsignedInteger(source, ruleSet, $.$$.System.UInt32.$z, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, $.$ref(() => ulongValue, ($v) => ulongValue = $v, $.$$.System.UInt64), bytesConsumed))
                {
                    value.$v = $.$cast(ulongValue, $.$$.System.UInt32);
                    return true;
                }
                value.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(343597645843)
            
            //--TRIMMABLE-BOUNDARY-START(304942940179)
            static /*bool */ TryReadInt64(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out long*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304942940179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadSignedInteger(source, ruleSet, $.$$.System.Int64.$z, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, value, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(304942940179)
            
            //--TRIMMABLE-BOUNDARY-START(347892613139)
            static /*bool */ TryReadUInt64(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out ulong*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892613139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUnsignedInteger(source, ruleSet, $.$$.System.UInt64.$z, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, value, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(347892613139)
            
            //--TRIMMABLE-BOUNDARY-START(60129804307)
            static /*ReadOnlySpan<byte> */ GetIntegerContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129804307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag, tagNumber, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (contents.IsEmpty)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*ushort*/ let bigEndianValue;
                if ($.$$.System.Buffers.Binary.BinaryPrimitives.TryReadUInt16BigEndian(contents, $.$ref(() => bigEndianValue, ($v) => bigEndianValue = $v, $.$$.System.UInt16)))
                {
                    /*ushort*/ let RedundancyMask = 65408;
                    /*ushort*/ let masked = $.$cast((bigEndianValue & RedundancyMask), $.$$.System.UInt16);
                    if (masked === 0 || masked === RedundancyMask)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                }
                bytesConsumed.$v = consumed;
                return contents;
            }
            //--TRIMMABLE-BOUNDARY-END(60129804307)
            
            //--TRIMMABLE-BOUNDARY-START(339302678547)
            static /*bool */ TryReadSignedInteger(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*int*/ sizeLimit, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out long*/ value, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339302678547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(sizeLimit <= $.$$.System.Int64.$z, "sizeLimit <= sizeof(long)");
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag, tagNumber, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (contents.Length > sizeLimit)
                {
                    value.$v = 0n;
                    bytesConsumed.$v = 0;
                    return false;
                }
                /*bool*/ let isNegative = (contents.get_Item(0).$v & 128) !== 0;
                /*long*/ let accum = BigInt(isNegative ? -1 : 0);
                for(/*int*/ let i = 0; i < contents.Length; i++)
                {
                    accum <<= 8n;
                    accum |= BigInt(contents.get_Item(i).$v);
                }
                bytesConsumed.$v = consumed;
                value.$v = accum;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(339302678547)
            
            //--TRIMMABLE-BOUNDARY-START(352187580435)
            static /*bool */ TryReadUnsignedInteger(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*int*/ sizeLimit, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out ulong*/ value, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187580435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(sizeLimit <= $.$$.System.UInt64.$z, "sizeLimit <= sizeof(ulong)");
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag, tagNumber, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                /*bool*/ let isNegative = (contents.get_Item(0).$v & 128) !== 0;
                if (isNegative)
                {
                    bytesConsumed.$v = 0;
                    value.$v = 0n;
                    return false;
                }
                if (contents.Length > 1 && contents.get_Item(0).$v === 0)
                {
                    contents = contents.Slice$1(1);
                }
                if (contents.Length > sizeLimit)
                {
                    bytesConsumed.$v = 0;
                    value.$v = 0n;
                    return false;
                }
                /*ulong*/ let accum = 0n;
                for(/*int*/ let i = 0; i < contents.Length; i++)
                {
                    accum <<= 8n;
                    accum |= BigInt(contents.get_Item(i).$v);
                }
                bytesConsumed.$v = consumed;
                value.$v = accum;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(352187580435)
            
            //--TRIMMABLE-BOUNDARY-START(227633528851)
            static /*DateTimeOffset */ ReadUtcTime(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*int*/ twoDigitYearMax, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633528851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (twoDigitYearMax < 1 || twoDigitYearMax > 9999)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("twoDigitYearMax");
                }
                /*Span<byte>*/ let tmpSpace = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 17, null);
                /*byte[]?*/ let rented = null;
                /*int*/ let bytesRead;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.UtcTime, 23/*UniversalTagNumber.UtcTime*/, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.System.Byte)), tmpSpace);
                /*DateTimeOffset*/ let value = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseUtcTime(contents, ruleSet, twoDigitYearMax);
                if (rented !== null)
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`UtcTime did not fit in tmpSpace (${contents.Length} total)`);
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = bytesRead;
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(227633528851)
            
            //--TRIMMABLE-BOUNDARY-START(120259346451)
            static /*DateTimeOffset */ ParseUtcTime(/*ReadOnlySpan<byte>*/ contentOctets, /*AsnEncodingRules*/ ruleSet, /*int*/ twoDigitYearMax)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259346451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let NoSecondsZulu = 11;
                /*int*/ let NoSecondsOffset = 15;
                /*int*/ let HasSecondsZulu = 13;
                /*int*/ let HasSecondsOffset = 17;
                if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (contentOctets.Length !== HasSecondsZulu)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                if (contentOctets.Length < NoSecondsZulu || contentOctets.Length > HasSecondsOffset || (contentOctets.Length & 1) !== 1)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*ReadOnlySpan<byte>*/ let contents = contentOctets;
                /*int*/ let year = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let month = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let day = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let hour = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let minute = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let second = 0;
                /*int*/ let offsetHour = 0;
                /*int*/ let offsetMinute = 0;
                /*bool*/ let minus = false;
                if (contentOctets.Length === HasSecondsOffset || contentOctets.Length === HasSecondsZulu)
                {
                    second = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                }
                if (contentOctets.Length === NoSecondsZulu || contentOctets.Length === HasSecondsZulu)
                {
                    if (contents.get_Item(0).$v !== /*Z*/ 90)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(contentOctets.Length === NoSecondsOffset || contentOctets.Length === HasSecondsOffset, "contentOctets.Length == NoSecondsOffset ||\r\n                    contentOctets.Length == HasSecondsOffset");
                    if (contents.get_Item(0).$v === /*-*/ 45)
                    {
                        minus = true;
                    }
                    else if (contents.get_Item(0).$v !== /*+*/ 43)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    contents = contents.Slice$1(1);
                    offsetHour = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                    offsetMinute = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                    $.$$.System.Diagnostics.Debug.Assert$2(contents.IsEmpty, "contents.IsEmpty");
                }
                if (offsetMinute > 59)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*TimeSpan*/ let offset = new $.$$.System.TimeSpan().$ctor$6(offsetHour, offsetMinute, 0);
                if (minus)
                {
                    offset = $.$$.System.TimeSpan.op_UnaryNegation(offset);
                }
                /*int*/ let century = $.trunc(twoDigitYearMax / 100);
                if (year > twoDigitYearMax % 100)
                {
                    century--;
                }
                /*int*/ let scaledYear = ((((century * 100) | 0) + year) | 0);
                try
                {
                    return new $.$$.System.DateTimeOffset().$ctor$11(scaledYear, month, day, hour, minute, second, offset);
                }
                catch(e)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$7($.$sfa.System.SR.ContentException_DefaultMessage, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259346451)
            
            //--TRIMMABLE-BOUNDARY-START(326417776659)
            static /*bool */ TryReadPrimitiveCharacterStringBytes(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326417776659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*UniversalTagNumber*/ let universalTagNumber = 22/*UniversalTagNumber.IA5String*/;
                if (expectedTag.TagClass === 0/*TagClass.Universal*/)
                {
                    universalTagNumber = $.$cast(expectedTag.TagValue, $.$sfa.System.Formats.Asn1.UniversalTagNumber);
                    if (!$.$sfa.System.Formats.Asn1.AsnDecoder.IsCharacterStringEncodingType(universalTagNumber))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_Tag_NotCharacterString, "expectedTag");
                    }
                }
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag, universalTagNumber, $.$discardRef(), $.$discardRef(), value, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(326417776659)
            
            //--TRIMMABLE-BOUNDARY-START(279173136403)
            static /*bool */ TryReadCharacterStringBytes(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*out int*/ bytesConsumed, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173136403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Byte, source, $.$$.System.Span$$($.$$.System.Byte).op_Implicit(destination)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_SourceOverlapsDestination, "destination");
                }
                /*UniversalTagNumber*/ let universalTagNumber = 22/*UniversalTagNumber.IA5String*/;
                if (expectedTag.TagClass === 0/*TagClass.Universal*/)
                {
                    universalTagNumber = $.$cast(expectedTag.TagValue, $.$sfa.System.Formats.Asn1.UniversalTagNumber);
                    if (!$.$sfa.System.Formats.Asn1.AsnDecoder.IsCharacterStringEncodingType(universalTagNumber))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_Tag_NotCharacterString, "expectedTag");
                    }
                }
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterStringBytesCore(source, ruleSet, expectedTag, universalTagNumber, destination, bytesConsumed, bytesWritten);
            }
            //--TRIMMABLE-BOUNDARY-END(279173136403)
            
            //--TRIMMABLE-BOUNDARY-START(274878169107)
            static /*bool */ TryReadCharacterString(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*AsnEncodingRules*/ ruleSet, /*UniversalTagNumber*/ encodingType, /*out int*/ bytesConsumed, /*out int*/ charsWritten, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878169107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Text.Encoding*/ let encoding = $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.GetEncoding(encodingType);
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterStringCore$1(source, ruleSet, expectedTag ?? new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$5(encodingType, false), encodingType, encoding, destination, bytesConsumed, charsWritten);
            }
            //--TRIMMABLE-BOUNDARY-END(274878169107)
            
            //--TRIMMABLE-BOUNDARY-START(137439215635)
            static /*string */ ReadCharacterString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*UniversalTagNumber*/ encodingType, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439215635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Text.Encoding*/ let encoding = $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.GetEncoding(encodingType);
                return $.$sfa.System.Formats.Asn1.AsnDecoder.ReadCharacterStringCore(source, ruleSet, expectedTag ?? new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$5(encodingType, false), encodingType, encoding, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(137439215635)
            
            //--TRIMMABLE-BOUNDARY-START(283468103699)
            static /*bool */ TryReadCharacterStringBytesCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468103699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int?*/ let contentLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let contents;
                /*int*/ let consumed;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => contentLength, ($v) => contentLength = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32), $.$ref(() => contents, ($v) => contents = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32)))
                {
                    if (contents.Length > destination.Length)
                    {
                        bytesWritten.$v = 0;
                        bytesConsumed.$v = 0;
                        return false;
                    }
                    contents.CopyTo(destination);
                    bytesWritten.$v = contents.Length;
                    bytesConsumed.$v = consumed;
                    return true;
                }
                /*int*/ let bytesRead;
                /*bool*/ let copied = $.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedOctetStringContents($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength, contentLength), ruleSet, destination, contentLength === null, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), bytesWritten);
                if (copied)
                {
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                }
                else 
                {
                    bytesConsumed.$v = 0;
                }
                return copied;
            }
            //--TRIMMABLE-BOUNDARY-END(283468103699)
            
            //--TRIMMABLE-BOUNDARY-START(287763070995)
            static /*bool */ TryReadCharacterStringCore(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Text.Encoding*/ encoding, /*out int*/ charsWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763070995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return encoding.TryGetChars(source, destination, charsWritten);
                }
                catch(e)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$7($.$sfa.System.SR.ContentException_DefaultMessage, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(287763070995)
            
            //--TRIMMABLE-BOUNDARY-START(141734182931)
            static /*string */ ReadCharacterStringCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*Text.Encoding*/ encoding, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734182931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]?*/ let rented = null;
                /*int*/ let bytesRead;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.System.Byte)), new ($.$$.System.Span$$($.$$.System.Byte))());
                /*string*/ let str;
                if (contents.Length === 0)
                {
                    str = $.$$.System.String.Empty;
                }
                else 
                {
                    {
                        /*fixed*/ 
                        {
                            /*byte**/ let bytePtr = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Byte, contents);
                            try
                            {
                                str = encoding.GetString$2(bytePtr, contents.Length);
                            }
                            catch(e)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$7($.$sfa.System.SR.ContentException_DefaultMessage, e);
                            }
                        }
                    }
                }
                if (rented !== null)
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = bytesRead;
                return str;
            }
            //--TRIMMABLE-BOUNDARY-END(141734182931)
            
            //--TRIMMABLE-BOUNDARY-START(292058038291)
            static /*bool */ TryReadCharacterStringCore$1(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*Text.Encoding*/ encoding, /*Span<char>*/ destination, /*out int*/ bytesConsumed, /*out int*/ charsWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058038291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]?*/ let rented = null;
                /*int*/ let bytesRead;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.System.Byte)), new ($.$$.System.Span$$($.$$.System.Byte))());
                /*bool*/ let copied = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterStringCore(contents, destination, encoding, charsWritten);
                if (rented !== null)
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                if (copied)
                {
                    bytesConsumed.$v = bytesRead;
                }
                else 
                {
                    bytesConsumed.$v = 0;
                }
                return copied;
            }
            //--TRIMMABLE-BOUNDARY-END(292058038291)
            
            //--TRIMMABLE-BOUNDARY-START(85899608083)
            static /*bool */ IsCharacterStringEncodingType(/*UniversalTagNumber*/ encodingType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899608083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(encodingType)
                {
                    case 30/*UniversalTagNumber.BMPString*/:
                    case 27/*UniversalTagNumber.GeneralString*/:
                    case 25/*UniversalTagNumber.GraphicString*/:
                    case 22/*UniversalTagNumber.IA5String*/:
                    case 26/*UniversalTagNumber.ISO646String*/:
                    case 18/*UniversalTagNumber.NumericString*/:
                    case 19/*UniversalTagNumber.PrintableString*/:
                    case 20/*UniversalTagNumber.TeletexString*/:
                    case 28/*UniversalTagNumber.UniversalString*/:
                    case 12/*UniversalTagNumber.UTF8String*/:
                    case 21/*UniversalTagNumber.VideotexString*/:
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(85899608083)
            
            //--TRIMMABLE-BOUNDARY-START(317827842067)
            static /*bool */ TryReadPrimitiveBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317827842067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let localUbc;
                /*ReadOnlySpan<byte>*/ let localValue;
                /*int*/ let consumed;
                /*byte*/ let normalizedLastByte;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveBitStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString, $.$discardRef(), $.$discardRef(), $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.System.Int32), $.$ref(() => localValue, ($v) => localValue = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$$.System.Byte)))
                {
                    if (localValue.Length === 0 || normalizedLastByte === localValue.get_Item(((localValue.Length - 1) | 0)).$v)
                    {
                        unusedBitCount.$v = localUbc;
                        value.$v = localValue;
                        bytesConsumed.$v = consumed;
                        return true;
                    }
                }
                unusedBitCount.$v = 0;
                value.$v = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))();
                bytesConsumed.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(317827842067)
            
            //--TRIMMABLE-BOUNDARY-START(270583201811)
            static /*bool */ TryReadBitString(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583201811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Byte, source, $.$$.System.Span$$($.$$.System.Byte).op_Implicit(destination)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_SourceOverlapsDestination, "destination");
                }
                /*int*/ let localUbc;
                /*byte*/ let normalizedLastByte;
                /*int*/ let consumed;
                /*int?*/ let contentsLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let value;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveBitStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString, $.$ref(() => contentsLength, ($v) => contentsLength = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32), $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.System.Int32), $.$ref(() => value, ($v) => value = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$$.System.Byte)))
                {
                    if (value.Length > destination.Length)
                    {
                        bytesConsumed.$v = 0;
                        bytesWritten.$v = 0;
                        unusedBitCount.$v = 0;
                        return false;
                    }
                    $.$sfa.System.Formats.Asn1.AsnDecoder.CopyBitStringValue(value, normalizedLastByte, destination);
                    bytesWritten.$v = value.Length;
                    bytesConsumed.$v = consumed;
                    unusedBitCount.$v = localUbc;
                    return true;
                }
                /*int*/ let bytesRead;
                /*int*/ let written;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedBitStringValue($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength, contentsLength), ruleSet, destination, contentsLength === null, $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.System.Int32), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => written, ($v) => written = $v, $.$$.System.Int32)))
                {
                    unusedBitCount.$v = localUbc;
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                    bytesWritten.$v = written;
                    return true;
                }
                bytesWritten.$v = bytesConsumed.$v = unusedBitCount.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(270583201811)
            
            //--TRIMMABLE-BOUNDARY-START(128849281043)
            static /*byte[] */ ReadBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849281043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int?*/ let contentsLength;
                /*int*/ let headerLength;
                /*int*/ let localUbc;
                /*ReadOnlySpan<byte>*/ let localValue;
                /*int*/ let consumed;
                /*byte*/ let normalizedLastByte;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveBitStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString, $.$ref(() => contentsLength, ($v) => contentsLength = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32), $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.System.Int32), $.$ref(() => localValue, ($v) => localValue = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$$.System.Byte)))
                {
                    /*byte[]*/ let ret = localValue.ToArray();
                    if (localValue.Length > 0)
                    {
                        $.$$.System.Array.$WriteT1.call(ret, normalizedLastByte, ((ret.length - 1) | 0));
                    }
                    unusedBitCount.$v = localUbc;
                    bytesConsumed.$v = consumed;
                    return ret;
                }
                /*int*/ let tooBig = contentsLength ?? $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(source.Slice$1(headerLength), ruleSet);
                /*byte[]*/ let rented = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(tooBig);
                /*int*/ let bytesRead;
                /*int*/ let written;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedBitStringValue($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength, contentsLength), ruleSet, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rented), contentsLength === null, $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.System.Int32), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => written, ($v) => written = $v, $.$$.System.Int32)))
                {
                    /*byte[]*/ let ret = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, rented, 0, written).ToArray();
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, written);
                    unusedBitCount.$v = localUbc;
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                    return ret;
                }
                $.$$.System.Diagnostics.Debug.Fail$1("TryCopyConstructedBitStringValue failed with a pre-allocated buffer");
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(128849281043)
            
            //--TRIMMABLE-BOUNDARY-START(115964379155)
            static /*void */ ParsePrimitiveBitStringContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out ReadOnlySpan<byte>*/ value, /*out byte*/ normalizedLastByte)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964379155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && source.Length > 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCer_TryBerOrDer);
                }
                if (source.Length === 0)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                unusedBitCount.$v = source.get_Item(0).$v;
                if (unusedBitCount.$v > 7)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                if (source.Length === 1)
                {
                    if (unusedBitCount.$v > 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(unusedBitCount.$v === 0, "unusedBitCount == 0");
                    value.$v = $.$$.System.ReadOnlySpan$$($.$$.System.Byte).Empty;
                    normalizedLastByte.$v = 0;
                    return;
                }
                /*int*/ let mask = -1 << unusedBitCount.$v;
                /*byte*/ let lastByte = source.get_Item(((source.Length - 1) | 0)).$v;
                /*byte*/ let maskedByte = $.$cast((lastByte & mask), $.$$.System.Byte);
                if (maskedByte !== lastByte)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                normalizedLastByte.$v = maskedByte;
                value.$v = source.Slice$1(1);
            }
            //--TRIMMABLE-BOUNDARY-END(115964379155)
            
            //--TRIMMABLE-BOUNDARY-START(327699)
            static $_BitStringCopyAction;
            static get BitStringCopyAction()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnDecoder;
                return $cls.$_BitStringCopyAction ??= $asm.$ncls("$sfa.System.Formats.Asn1.AsnDecoder.BitStringCopyAction", ($self) => class BitStringCopyAction extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ value, /*$.$$.System.Byte*/ normalizedLastByte, /**/ destination)
                    {
                        return this.$nativeFunction.call(this.$target, value, normalizedLastByte, destination);
                    }
                    static $h = 327699;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 98828289,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180196883),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "normalizedLastByte",
          "p": 393217
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "Invoke",
      "d": 327699,
      "h": 17180196883,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180196883),
//--TRIMMABLE-BOUNDARY-START(8590262291),
    {
      "r": 89653249,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "normalizedLastByte",
          "p": 393217
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "callback",
          "p": 45154305
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 327699,
      "h": 8590262291,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590262291),
//--TRIMMABLE-BOUNDARY-START(12885229587),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 89653249
        }
      ],
      "n": "EndInvoke",
      "d": 327699,
      "h": 12885229587,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885229587)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295294995),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 327699,
      "h": 4295294995,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295294995)
  ],
  "i": [89849857,157351937
  ],
  "d": 262163,
  "h": 327699
}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnDecoder.BitStringCopyAction`; }
                }, $cls, ($v) => $cls.$_BitStringCopyAction = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327699)
            
            //--TRIMMABLE-BOUNDARY-START(21475098643)
            static /*void */ CopyBitStringValue(/*ReadOnlySpan<byte>*/ value, /*byte*/ normalizedLastByte, /*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.Length === 0)
                {
                    return;
                }
                value.CopyTo(destination);
                destination.get_Item(((value.Length - 1) | 0)).$v = normalizedLastByte;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098643)
            
            //--TRIMMABLE-BOUNDARY-START(38654967827)
            static /*int */ CountConstructedBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*bool*/ isIndefinite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Span<byte>*/ let destination = $.$$.System.Span$$($.$$.System.Byte).Empty;
                return $.$sfa.System.Formats.Asn1.AsnDecoder.ProcessConstructedBitString(source, ruleSet, destination, null, isIndefinite, $.$discardRef(), $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(38654967827)
            
            //--TRIMMABLE-BOUNDARY-START(25770065939)
            static /*void */ CopyConstructedBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*bool*/ isIndefinite, /*out int*/ unusedBitCount, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770065939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Span<byte>*/ let tmpDest = destination;
                bytesWritten.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.ProcessConstructedBitString(source, ruleSet, tmpDest, new $.$sfa.System.Formats.Asn1.AsnDecoder.BitStringCopyAction().$ctor($.$sfa.System.Formats.Asn1.AsnDecoder, $.$sfa.System.Formats.Asn1.AsnDecoder.CopyBitStringValue), isIndefinite, unusedBitCount, bytesRead);
            }
            //--TRIMMABLE-BOUNDARY-END(25770065939)
            
            //--TRIMMABLE-BOUNDARY-START(124554313747)
            static /*int */ ProcessConstructedBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*BitStringCopyAction?*/ copyAction, /*bool*/ isIndefinite, /*out int*/ lastUnusedBitCount, /*out int*/ bytesRead)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554313747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                lastUnusedBitCount.$v = 0;
                bytesRead.$v = 0;
                /*int*/ let lastSegmentLength = 1000/*MaxCERSegmentSize*/;
                /*ReadOnlySpan<byte>*/ let cur = source;
                /*Stack<(int Offset, int Length, bool Indefinite, int BytesRead)>?*/ let readerStack = null;
                /*int*/ let totalLength = 0;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedBitString;
                /*Span<byte>*/ let curDest = destination;
                while(true)
                {
                    while(!cur.IsEmpty)
                    {
                        /*int?*/ let length;
                        /*int*/ let headerLength;
                        tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(cur, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32));
                        if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString))
                        {
                            if (lastUnusedBitCount.$v !== 0)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                            }
                            if (ruleSet === 1/*AsnEncodingRules.CER*/ && lastSegmentLength !== 1000/*MaxCERSegmentSize*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCer_TryBerOrDer);
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(length !== null, "length != null");
                            /*ReadOnlySpan<byte>*/ let encodedValue = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(cur, headerLength, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length));
                            /*ReadOnlySpan<byte>*/ let contents;
                            /*byte*/ let normalizedLastByte;
                            $.$sfa.System.Formats.Asn1.AsnDecoder.ParsePrimitiveBitStringContents(encodedValue, ruleSet, lastUnusedBitCount, $.$ref(() => contents, ($v) => contents = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$$.System.Byte));
                            /*int*/ let localLen = ((headerLength + encodedValue.Length) | 0);
                            cur = cur.Slice$1(localLen);
                            bytesRead.$v += localLen;
                            totalLength += contents.Length;
                            lastSegmentLength = encodedValue.Length;
                            if (copyAction !== null)
                            {
                                copyAction.Invoke(contents, normalizedLastByte, curDest);
                                curDest = curDest.Slice$1(contents.Length);
                            }
                        }
                        else if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents) && isIndefinite)
                        {
                            $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateEndOfContents(tag, length, headerLength);
                            bytesRead.$v += headerLength;
                            if ($.$$.System.Int32.op_GreaterThan$1((readerStack?.Count ?? null), 0))
                            {
                                const { Item1: topOffset, Item2: topLength, Item3: wasIndefinite, Item4: pushedBytesRead } = readerStack.Pop();
                                /*ReadOnlySpan<byte>*/ let topSpan = source.Slice(topOffset, topLength);
                                cur = topSpan.Slice$1(bytesRead.$v);
                                bytesRead.$v += pushedBytesRead;
                                isIndefinite = wasIndefinite;
                            }
                            else 
                            {
                                break;
                            }
                        }
                        else if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedBitString))
                        {
                            if (ruleSet === 1/*AsnEncodingRules.CER*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            readerStack ??= new ($.$sc.System.Collections.Generic.Stack$$($.$$.System.ValueTuple$$$$$($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Boolean, $.$$.System.Int32)))().$ctor$1();
                            /*int*/ let curOffset;
                            if (!$.$$.System.MemoryExtensions.Overlaps($.$$.System.Byte, source, cur, $.$ref(() => curOffset, ($v) => curOffset = $v, $.$$.System.Int32)))
                            {
                                $.$$.System.Diagnostics.Debug.Fail$1("Non-overlapping data encountered...");
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                            }
                            readerStack.Push(new ($.$$.System.ValueTuple$$$$$($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Boolean, $.$$.System.Int32))().$ctor$3(curOffset, cur.Length, isIndefinite, bytesRead.$v));
                            cur = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(cur, headerLength, length);
                            bytesRead.$v = headerLength;
                            isIndefinite = (length === null);
                        }
                        else 
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                    }
                    if (isIndefinite && $.$sfa.System.Formats.Asn1.Asn1Tag.op_Inequality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    if ($.$$.System.Int32.op_GreaterThan$1((readerStack?.Count ?? null), 0))
                    {
                        const { Item1: topOffset, Item2: topLength, Item3: wasIndefinite, Item4: pushedBytesRead } = readerStack.Pop();
                        /*ReadOnlySpan<byte>*/ let tmpSpan = source.Slice(topOffset, topLength);
                        cur = tmpSpan.Slice$1(bytesRead.$v);
                        isIndefinite = wasIndefinite;
                        bytesRead.$v += pushedBytesRead;
                    }
                    else 
                    {
                        return totalLength;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554313747)
            
            //--TRIMMABLE-BOUNDARY-START(257698299923)
            static /*bool */ TryCopyConstructedBitStringValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ dest, /*bool*/ isIndefinite, /*out int*/ unusedBitCount, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698299923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let contentLength = $.$sfa.System.Formats.Asn1.AsnDecoder.CountConstructedBitString(source, ruleSet, isIndefinite);
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && contentLength < 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                if (dest.Length < contentLength)
                {
                    unusedBitCount.$v = 0;
                    bytesRead.$v = 0;
                    bytesWritten.$v = 0;
                    return false;
                }
                $.$sfa.System.Formats.Asn1.AsnDecoder.CopyConstructedBitString(source, ruleSet, dest, isIndefinite, unusedBitCount, bytesRead, bytesWritten);
                $.$$.System.Diagnostics.Debug.Assert$2(bytesWritten.$v === contentLength, "bytesWritten == contentLength");
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(257698299923)
            
            //--TRIMMABLE-BOUNDARY-START(322122809363)
            static /*bool */ TryReadPrimitiveBitStringCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*out int?*/ contentsLength, /*out int*/ headerLength, /*out int*/ unusedBitCount, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed, /*out byte*/ normalizedLastByte)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322122809363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Asn1Tag*/ let actualTag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(source, ruleSet, contentsLength, headerLength);
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(actualTag, expectedTag, 3/*UniversalTagNumber.BitString*/);
                /*ReadOnlySpan<byte>*/ let encodedValue = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength.$v, contentsLength.$v);
                if (actualTag.IsConstructed)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderDer_TryBerOrCer);
                    }
                    unusedBitCount.$v = 0;
                    value.$v = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))();
                    normalizedLastByte.$v = 0;
                    bytesConsumed.$v = 0;
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(contentsLength.$v), "contentsLength.HasValue");
                $.$sfa.System.Formats.Asn1.AsnDecoder.ParsePrimitiveBitStringContents(encodedValue, ruleSet, unusedBitCount, value, normalizedLastByte);
                bytesConsumed.$v = ((headerLength.$v + encodedValue.Length) | 0);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(322122809363)
            
            //--TRIMMABLE-BOUNDARY-START(98784509971)
            /*int*/ static MaxCERSegmentSize = 1000;
            //--TRIMMABLE-BOUNDARY-END(98784509971)
            
            //--TRIMMABLE-BOUNDARY-START(55834837011)
            /*int*/ static EndOfContentsEncodedLength = 2;
            //--TRIMMABLE-BOUNDARY-END(55834837011)
            
            //--TRIMMABLE-BOUNDARY-START(296353005587)
            static /*bool */ TryReadEncodedValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out Asn1Tag*/ tag, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353005587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*Asn1Tag*/ let localTag;
                /*int*/ let tagLength;
                /*int?*/ let encodedLength;
                /*int*/ let lengthLength;
                if ($.$sfa.System.Formats.Asn1.Asn1Tag.TryDecode(source, $.$ref(() => localTag, ($v) => localTag = $v, $.$sfa.System.Formats.Asn1.Asn1Tag), $.$ref(() => tagLength, ($v) => tagLength = $v, $.$$.System.Int32)) && $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadLength(source.Slice$1(tagLength), ruleSet, $.$ref(() => encodedLength, ($v) => encodedLength = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$$.System.Int32)))
                {
                    /*int*/ let headerLength = ((tagLength + lengthLength) | 0);
                    /*int*/ let len;
                    /*int*/ let consumed;
                    /*LengthValidity*/ let validity = $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateLength(source.Slice$1(headerLength), ruleSet, localTag, encodedLength, $.$ref(() => len, ($v) => len = $v, $.$$.System.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                    if (validity === 3/*LengthValidity.Valid*/)
                    {
                        tag.$v = localTag;
                        contentOffset.$v = headerLength;
                        contentLength.$v = len;
                        bytesConsumed.$v = ((headerLength + consumed) | 0);
                        return true;
                    }
                }
                tag.$v = new $.$sfa.System.Formats.Asn1.Asn1Tag();
                contentOffset.$v = contentLength.$v = bytesConsumed.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(296353005587)
            
            //--TRIMMABLE-BOUNDARY-START(146029150227)
            static /*Asn1Tag */ ReadEncodedValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029150227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*int*/ let tagLength;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.Asn1Tag.Decode(source, $.$ref(() => tagLength, ($v) => tagLength = $v, $.$$.System.Int32));
                /*int*/ let lengthLength;
                /*int?*/ let encodedLength = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadLength(source.Slice$1(tagLength), ruleSet, $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$$.System.Int32));
                /*int*/ let headerLength = ((tagLength + lengthLength) | 0);
                /*int*/ let len;
                /*int*/ let consumed;
                /*LengthValidity*/ let validity = $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateLength(source.Slice$1(headerLength), ruleSet, tag, encodedLength, $.$ref(() => len, ($v) => len = $v, $.$$.System.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (validity === 3/*LengthValidity.Valid*/)
                {
                    contentOffset.$v = headerLength;
                    contentLength.$v = len;
                    bytesConsumed.$v = ((headerLength + consumed) | 0);
                    return tag;
                }
                throw $.$sfa.System.Formats.Asn1.AsnDecoder.GetValidityException(validity);
            }
            //--TRIMMABLE-BOUNDARY-END(146029150227)
            
            //--TRIMMABLE-BOUNDARY-START(68719738899)
            static /*ReadOnlySpan<byte> */ GetPrimitiveContentSpan(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719738899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*int*/ let tagLength;
                /*Asn1Tag*/ let localTag = $.$sfa.System.Formats.Asn1.Asn1Tag.Decode(source, $.$ref(() => tagLength, ($v) => tagLength = $v, $.$$.System.Int32));
                /*int*/ let lengthLength;
                /*int?*/ let encodedLength = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadLength(source.Slice$1(tagLength), ruleSet, $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$$.System.Int32));
                /*int*/ let headerLength = ((tagLength + lengthLength) | 0);
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(localTag, expectedTag, tagNumber);
                if (localTag.IsConstructed)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.Format$6($.$sfa.System.SR.ContentException_PrimitiveEncodingRequired, $.$box(tagNumber, $.$sfa.System.Formats.Asn1.UniversalTagNumber)));
                }
                if (encodedLength === null)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*ReadOnlySpan<byte>*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(source, headerLength, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(encodedLength));
                bytesConsumed.$v = ((headerLength + ret.Length) | 0);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(68719738899)
            
            //--TRIMMABLE-BOUNDARY-START(47244902419)
            static /*int? */ DecodeLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244902419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*int*/ let read;
                /*int?*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadLength(source, ruleSet, $.$ref(() => read, ($v) => read = $v, $.$$.System.Int32));
                bytesConsumed.$v = read;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(47244902419)
            
            //--TRIMMABLE-BOUNDARY-START(266288234515)
            static /*bool */ TryDecodeLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ decodedLength, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288234515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*int?*/ let decoded;
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadLength(source, ruleSet, $.$ref(() => decoded, ($v) => decoded = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => read, ($v) => read = $v, $.$$.System.Int32));
                bytesConsumed.$v = read;
                decodedLength.$v = decoded;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(266288234515)
            
            //--TRIMMABLE-BOUNDARY-START(309237907475)
            static /*bool */ TryReadLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ length, /*out int*/ bytesRead)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309237907475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.AsnDecoder.DecodeLength$1(source, ruleSet, length, bytesRead) === 5/*LengthDecodeStatus.Success*/;
            }
            //--TRIMMABLE-BOUNDARY-END(309237907475)
            
            //--TRIMMABLE-BOUNDARY-START(176093921299)
            static /*int? */ ReadLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093921299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int?*/ let length;
                /*LengthDecodeStatus*/ let status = $.$sfa.System.Formats.Asn1.AsnDecoder.DecodeLength$1(source, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.System.Int32)), bytesConsumed);
                let $switchJumpState3;
                $switchJumpStart3: while(true)
                {
                    switch($switchJumpState3 ?? status)
                    {
                        case 5/*LengthDecodeStatus.Success*/:
                        return length;
                        case 3/*LengthDecodeStatus.LengthTooBig*/:
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_LengthTooBig);
                        case 4/*LengthDecodeStatus.LaxEncodingProhibited*/:
                        case 1/*LengthDecodeStatus.DerIndefinite*/:
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_LengthRuleSetConstraint);
                        case 0/*LengthDecodeStatus.NeedMoreData*/:
                        case 2/*LengthDecodeStatus.ReservedValue*/:
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        default:
                        $.$$.System.Diagnostics.Debug.Fail$1(`No handler is present for status ${status}.`);
                        $switchJumpState3 = 0/*LengthDecodeStatus.NeedMoreData*/; /*goto case LengthDecodeStatus.NeedMoreData*/
                        continue $switchJumpStart3;
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176093921299)
            
            //--TRIMMABLE-BOUNDARY-START(51539869715)
            static /*LengthDecodeStatus */ DecodeLength$1(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ length, /*out int*/ bytesRead)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539869715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                length.$v = null;
                bytesRead.$v = 0;
                $.$sfa.System.Formats.Asn1.AsnDecoder.AssertEncodingRules(ruleSet);
                if (source.IsEmpty)
                {
                    return 0/*LengthDecodeStatus.NeedMoreData*/;
                }
                /*byte*/ let lengthOrLengthLength = source.get_Item(bytesRead.$v).$v;
                bytesRead.$v++;
                /*byte*/ let MultiByteMarker = 128;
                if (lengthOrLengthLength === MultiByteMarker)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/)
                    {
                        bytesRead.$v = 0;
                        return 1/*LengthDecodeStatus.DerIndefinite*/;
                    }
                    return 5/*LengthDecodeStatus.Success*/;
                }
                if (lengthOrLengthLength < MultiByteMarker)
                {
                    length.$v = lengthOrLengthLength;
                    return 5/*LengthDecodeStatus.Success*/;
                }
                if (lengthOrLengthLength === 255)
                {
                    bytesRead.$v = 0;
                    return 2/*LengthDecodeStatus.ReservedValue*/;
                }
                /*byte*/ let lengthLength = $.$cast((lengthOrLengthLength & ~MultiByteMarker), $.$$.System.Byte);
                if (((lengthLength + 1) | 0) > source.Length)
                {
                    bytesRead.$v = 0;
                    return 0/*LengthDecodeStatus.NeedMoreData*/;
                }
                /*bool*/ let minimalRepresentation = ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/;
                if (minimalRepresentation && lengthLength > $.$$.System.Int32.$z)
                {
                    bytesRead.$v = 0;
                    return 3/*LengthDecodeStatus.LengthTooBig*/;
                }
                /*uint*/ let parsedLength = 0;
                for(/*int*/ let i = 0; i < lengthLength; i++)
                {
                    /*byte*/ let current = source.get_Item(bytesRead.$v).$v;
                    bytesRead.$v++;
                    if (parsedLength === 0)
                    {
                        if (minimalRepresentation && current === 0)
                        {
                            bytesRead.$v = 0;
                            return 4/*LengthDecodeStatus.LaxEncodingProhibited*/;
                        }
                        if (!minimalRepresentation && current !== 0)
                        {
                            if (((lengthLength - i) | 0) > $.$$.System.Int32.$z)
                            {
                                bytesRead.$v = 0;
                                return 3/*LengthDecodeStatus.LengthTooBig*/;
                            }
                        }
                    }
                    parsedLength <<= 8;
                    parsedLength |= current;
                }
                if (parsedLength > 2147483647/*int.MaxValue*/)
                {
                    bytesRead.$v = 0;
                    return 3/*LengthDecodeStatus.LengthTooBig*/;
                }
                if (minimalRepresentation && parsedLength < MultiByteMarker)
                {
                    bytesRead.$v = 0;
                    return 4/*LengthDecodeStatus.LaxEncodingProhibited*/;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(bytesRead.$v > 0, "bytesRead > 0");
                length.$v = (parsedLength | 0);
                return 5/*LengthDecodeStatus.Success*/;
            }
            //--TRIMMABLE-BOUNDARY-END(51539869715)
            
            //--TRIMMABLE-BOUNDARY-START(223338561555)
            static /*Asn1Tag */ ReadTagAndLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ contentsLength, /*out int*/ bytesRead)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338561555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let tagBytesRead;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.Asn1Tag.Decode(source, $.$ref(() => tagBytesRead, ($v) => tagBytesRead = $v, $.$$.System.Int32));
                /*int*/ let lengthBytesRead;
                /*int?*/ let length = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadLength(source.Slice$1(tagBytesRead), ruleSet, $.$ref(() => lengthBytesRead, ($v) => lengthBytesRead = $v, $.$$.System.Int32));
                /*int*/ let allBytesRead = ((tagBytesRead + lengthBytesRead) | 0);
                if (tag.IsConstructed)
                {
                    if (ruleSet === 1/*AsnEncodingRules.CER*/ && length !== null)
                    {
                        throw $.$sfa.System.Formats.Asn1.AsnDecoder.GetValidityException(0/*LengthValidity.CerRequiresIndefinite*/);
                    }
                }
                else if (length === null)
                {
                    throw $.$sfa.System.Formats.Asn1.AsnDecoder.GetValidityException(1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/);
                }
                bytesRead.$v = allBytesRead;
                contentsLength.$v = length;
                return tag;
            }
            //--TRIMMABLE-BOUNDARY-END(223338561555)
            
            //--TRIMMABLE-BOUNDARY-START(356482547731)
            static /*void */ ValidateEndOfContents(/*Asn1Tag*/ tag, /*int?*/ length, /*int*/ headerLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482547731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tag.IsConstructed || length !== 0 || headerLength !== 2/*EndOfContentsEncodedLength*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(356482547731)
            
            //--TRIMMABLE-BOUNDARY-START(360777515027)
            static /*LengthValidity */ ValidateLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ localTag, /*int?*/ encodedLength, /*out int*/ actualLength, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777515027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (localTag.IsConstructed)
                {
                    if (ruleSet === 1/*AsnEncodingRules.CER*/ && encodedLength !== null)
                    {
                        actualLength.$v = bytesConsumed.$v = 0;
                        return 0/*LengthValidity.CerRequiresIndefinite*/;
                    }
                }
                else if (encodedLength === null)
                {
                    actualLength.$v = bytesConsumed.$v = 0;
                    return 1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/;
                }
                if (encodedLength !== null)
                {
                    /*int*/ let len = $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(encodedLength);
                    /*int*/ let totalLength = len;
                    if (totalLength > source.Length)
                    {
                        actualLength.$v = bytesConsumed.$v = 0;
                        return 2/*LengthValidity.LengthExceedsInput*/;
                    }
                    actualLength.$v = len;
                    bytesConsumed.$v = len;
                    return 3/*LengthValidity.Valid*/;
                }
                actualLength.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(source, ruleSet);
                bytesConsumed.$v = ((actualLength.$v + 2/*EndOfContentsEncodedLength*/) | 0);
                return 3/*LengthValidity.Valid*/;
            }
            //--TRIMMABLE-BOUNDARY-END(360777515027)
            
            //--TRIMMABLE-BOUNDARY-START(77309673491)
            static /*AsnContentException */ GetValidityException(/*LengthValidity*/ validity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309673491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(validity !== 3/*LengthValidity.Valid*/, "validity != LengthValidity.Valid");
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    switch($switchJumpState1 ?? validity)
                    {
                        case 0/*LengthValidity.CerRequiresIndefinite*/:
                        return new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_CerRequiresIndefiniteLength);
                        case 2/*LengthValidity.LengthExceedsInput*/:
                        return new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_LengthExceedsPayload);
                        case 1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/:
                        return new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        default:
                        $.$$.System.Diagnostics.Debug.Fail$1(`No handler for validity ${validity}.`);
                        $switchJumpState1 = 1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/; /*goto case LengthValidity.PrimitiveEncodingRequiresDefinite*/
                        continue $switchJumpStart1;
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309673491)
            
            //--TRIMMABLE-BOUNDARY-START(73014706195)
            static /*int */ GetPrimitiveIntegerSize(/*Type*/ primitiveType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.Byte.$type) || $.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.SByte.$type))
                {
                    return 1;
                }
                if ($.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.Int16.$type) || $.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.UInt16.$type))
                {
                    return 2;
                }
                if ($.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.Int32.$type) || $.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.UInt32.$type))
                {
                    return 4;
                }
                if ($.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.Int64.$type) || $.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.UInt64.$type))
                {
                    return 8;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(73014706195)
            
            //--TRIMMABLE-BOUNDARY-START(236223463443)
            static /*int */ SeekEndOfContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223463443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let cur = source;
                /*int*/ let totalLen = 0;
                /*int*/ let depth = 1;
                while(!cur.IsEmpty)
                {
                    /*int?*/ let length;
                    /*int*/ let bytesRead;
                    /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(cur, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32));
                    if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents))
                    {
                        $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateEndOfContents(tag, length, bytesRead);
                        depth--;
                        if (depth === 0)
                        {
                            return totalLen;
                        }
                    }
                    if (length === null)
                    {
                        depth++;
                        cur = cur.Slice$1(bytesRead);
                        totalLen += bytesRead;
                    }
                    else 
                    {
                        /*ReadOnlySpan<byte>*/ let tlv = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(cur, 0, ((bytesRead + $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length)) | 0));
                        cur = cur.Slice$1(tlv.Length);
                        totalLen += tlv.Length;
                    }
                }
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(236223463443)
            
            //--TRIMMABLE-BOUNDARY-START(111669411859)
            static /*int */ ParseNonNegativeIntAndSlice(/*ref ReadOnlySpan<byte>*/ data, /*int*/ bytesToRead)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669411859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let value = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeInt($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(data.$v, 0, bytesToRead));
                data.$v = data.$v.Slice$1(bytesToRead);
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(111669411859)
            
            //--TRIMMABLE-BOUNDARY-START(107374444563)
            static /*int */ ParseNonNegativeInt(/*ReadOnlySpan<byte>*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374444563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let value;
                /*int*/ let consumed;
                if ($.$$.System.Buffers.Text.Utf8Parser.TryParse$14(data, $.$ref(() => value, ($v) => value = $v, $.$$.System.UInt32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), /*\u0000*/ 0) && value <= 2147483647/*int.MaxValue*/ && consumed === data.Length)
                {
                    return (value | 0);
                }
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(107374444563)
            
            //--TRIMMABLE-BOUNDARY-START(253403332627)
            static /*ReadOnlySpan<byte> */ SliceAtMost(/*ReadOnlySpan<byte>*/ source, /*int*/ longestPermitted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403332627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let len = $.$$.System.Math.Min$4(longestPermitted, source.Length);
                return source.Slice(0, len);
            }
            //--TRIMMABLE-BOUNDARY-END(253403332627)
            
            //--TRIMMABLE-BOUNDARY-START(240518430739)
            static /*ReadOnlySpan<byte> */ Slice$1(/*ReadOnlySpan<byte>*/ source, /*int*/ offset, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518430739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(offset >= 0, "offset >= 0");
                if (length < 0 || ((source.Length - offset) | 0) < length)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_LengthExceedsPayload);
                }
                return source.Slice(offset, length);
            }
            //--TRIMMABLE-BOUNDARY-END(240518430739)
            
            //--TRIMMABLE-BOUNDARY-START(244813398035)
            static /*ReadOnlySpan<byte> */ Slice$2(/*ReadOnlySpan<byte>*/ source, /*int*/ offset, /*int?*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813398035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(offset >= 0, "offset >= 0");
                if (length === null)
                {
                    return source.Slice$1(offset);
                }
                /*int*/ let lengthVal = $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length);
                if (lengthVal < 0 || ((source.Length - offset) | 0) < lengthVal)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_LengthExceedsPayload);
                }
                return source.Slice(offset, lengthVal);
            }
            //--TRIMMABLE-BOUNDARY-END(244813398035)
            
            //--TRIMMABLE-BOUNDARY-START(249108365331)
            static /*ReadOnlyMemory<byte> */ Slice(/*ReadOnlyMemory<byte>*/ bigger, /*ReadOnlySpan<byte>*/ smaller)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108365331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (smaller.IsEmpty)
                {
                    return new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))();
                }
                /*int*/ let offset;
                if ($.$$.System.MemoryExtensions.Overlaps($.$$.System.Byte, bigger.Span, smaller, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                {
                    return bigger.Slice(offset, smaller.Length);
                }
                $.$$.System.Diagnostics.Debug.Fail$1("AsnReader asked for a matching slice from a non-overlapping input");
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(249108365331)
            
            //--TRIMMABLE-BOUNDARY-START(4295229459)
            static /*void */ AssertEncodingRules(/*AsnEncodingRules*/ ruleSet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(ruleSet >= 0/*AsnEncodingRules.BER*/ && ruleSet <= 2/*AsnEncodingRules.DER*/, "ruleSet >= AsnEncodingRules.BER && ruleSet <= AsnEncodingRules.DER");
            }
            //--TRIMMABLE-BOUNDARY-END(4295229459)
            
            //--TRIMMABLE-BOUNDARY-START(12885164051)
            static /*void */ CheckEncodingRules(/*AsnEncodingRules*/ ruleSet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (ruleSet !== 0/*AsnEncodingRules.BER*/ && ruleSet !== 1/*AsnEncodingRules.CER*/ && ruleSet !== 2/*AsnEncodingRules.DER*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("ruleSet");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885164051)
            
            //--TRIMMABLE-BOUNDARY-START(17180131347)
            static /*void */ CheckExpectedTag(/*Asn1Tag*/ tag, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (expectedTag.TagClass === 0/*TagClass.Universal*/ && expectedTag.TagValue !== tagNumber)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_UniversalValueIsFixed, "expectedTag");
                }
                if (expectedTag.TagClass !== tag.TagClass || expectedTag.TagValue !== tag.TagValue)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.Format$7($.$sfa.System.SR.ContentException_WrongTag, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$box(tag.TagClass, $.$sfa.System.Formats.Asn1.TagClass), $.$box(tag.TagValue, $.$$.System.Int32), $.$box(expectedTag.TagClass, $.$sfa.System.Formats.Asn1.TagClass), $.$box(expectedTag.TagValue, $.$$.System.Int32) ], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180131347)
            
            //--TRIMMABLE-BOUNDARY-START(393235)
            static $_LengthDecodeStatus;
            static get LengthDecodeStatus()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnDecoder;
                return $cls.$_LengthDecodeStatus ??= $asm.$nstr("$sfa.System.Formats.Asn1.AsnDecoder.LengthDecodeStatus", ($self) => class LengthDecodeStatus extends $.$$.System.Enum
                {
                    static NeedMoreData = 0;
                    static DerIndefinite = 1;
                    static ReservedValue = 2;
                    static LengthTooBig = 3;
                    static LaxEncodingProhibited = 4;
                    static Success = 5;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(393235);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "NeedMoreData": 0n,
                            "DerIndefinite": 1n,
                            "ReservedValue": 2n,
                            "LengthTooBig": 3n,
                            "LaxEncodingProhibited": 4n,
                            "Success": 5n
                        };
                    }
                    static $h = 393235;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475229715),
    {
      "t": 393235,
      "n": "NeedMoreData",
      "d": 393235,
      "h": 21475229715,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475229715),
//--TRIMMABLE-BOUNDARY-START(8590327827),
    {
      "t": 393235,
      "n": "DerIndefinite",
      "d": 393235,
      "h": 8590327827,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590327827),
//--TRIMMABLE-BOUNDARY-START(25770197011),
    {
      "t": 393235,
      "n": "ReservedValue",
      "d": 393235,
      "h": 25770197011,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770197011),
//--TRIMMABLE-BOUNDARY-START(17180262419),
    {
      "t": 393235,
      "n": "LengthTooBig",
      "d": 393235,
      "h": 17180262419,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180262419),
//--TRIMMABLE-BOUNDARY-START(12885295123),
    {
      "t": 393235,
      "n": "LaxEncodingProhibited",
      "d": 393235,
      "h": 12885295123,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885295123),
//--TRIMMABLE-BOUNDARY-START(30065164307),
    {
      "t": 393235,
      "n": "Success",
      "d": 393235,
      "h": 30065164307,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065164307)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360531),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393235,
      "h": 4295360531,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360531)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "d": 262163,
  "h": 393235
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnDecoder.LengthDecodeStatus`; }
                }, $cls, ($v) => $cls.$_LengthDecodeStatus = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393235)
            
            //--TRIMMABLE-BOUNDARY-START(458771)
            static $_LengthValidity;
            static get LengthValidity()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnDecoder;
                return $cls.$_LengthValidity ??= $asm.$nstr("$sfa.System.Formats.Asn1.AsnDecoder.LengthValidity", ($self) => class LengthValidity extends $.$$.System.Enum
                {
                    static CerRequiresIndefinite = 0;
                    static PrimitiveEncodingRequiresDefinite = 1;
                    static LengthExceedsInput = 2;
                    static Valid = 3;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(458771);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "CerRequiresIndefinite": 0n,
                            "PrimitiveEncodingRequiresDefinite": 1n,
                            "LengthExceedsInput": 2n,
                            "Valid": 3n
                        };
                    }
                    static $h = 458771;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393363),
    {
      "t": 458771,
      "n": "CerRequiresIndefinite",
      "d": 458771,
      "h": 8590393363,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393363),
//--TRIMMABLE-BOUNDARY-START(17180327955),
    {
      "t": 458771,
      "n": "PrimitiveEncodingRequiresDefinite",
      "d": 458771,
      "h": 17180327955,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180327955),
//--TRIMMABLE-BOUNDARY-START(12885360659),
    {
      "t": 458771,
      "n": "LengthExceedsInput",
      "d": 458771,
      "h": 12885360659,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360659),
//--TRIMMABLE-BOUNDARY-START(21475295251),
    {
      "t": 458771,
      "n": "Valid",
      "d": 458771,
      "h": 21475295251,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475295251)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426067),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458771,
      "h": 4295426067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426067)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "d": 262163,
  "h": 458771
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnDecoder.LengthValidity`; }
                }, $cls, ($v) => $cls.$_LengthValidity = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(458771)
            
            static $h = 262163;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(133144248339),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadBoolean",
      "d": 262163,
      "h": 133144248339,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(133144248339),
//--TRIMMABLE-BOUNDARY-START(193273790483),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadNull",
      "d": 262163,
      "h": 193273790483,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(193273790483),
//--TRIMMABLE-BOUNDARY-START(150324117523),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadEnumeratedBytes",
      "d": 262163,
      "h": 150324117523,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(150324117523),
//--TRIMMABLE-BOUNDARY-START(154619084819),
    {
      "r": (TEnum) => TEnum.$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "g": [
        "TEnum"
      ],
      "n": "ReadEnumeratedValue",
      "o": "@$1",
      "d": 262163,
      "h": 154619084819,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(154619084819),
//--TRIMMABLE-BOUNDARY-START(158914052115),
    {
      "r": 1048577,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "enumType",
          "p": 187629569
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadEnumeratedValue",
      "d": 262163,
      "h": 158914052115,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(158914052115),
//--TRIMMABLE-BOUNDARY-START(214748626963),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "contentOffset",
          "p": 655361,
          "f": 2
        },
        {
          "n": "contentLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "skipSortOrderValidation",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadSetOf",
      "d": 262163,
      "h": 214748626963,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(214748626963),
//--TRIMMABLE-BOUNDARY-START(197568757779),
    {
      "r": 1310721,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadObjectIdentifier",
      "d": 262163,
      "h": 197568757779,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(197568757779),
//--TRIMMABLE-BOUNDARY-START(219043594259),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        },
        {
          "n": "smallValue",
          "p": $.$typeNullable($.$$.System.Int64).$h,
          "f": 2
        },
        {
          "n": "largeValue",
          "p": $.$typeNullable($.$srn.System.Numerics.BigInteger).$h,
          "f": 2
        }
      ],
      "n": "ReadSubIdentifier",
      "d": 262163,
      "h": 219043594259,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(219043594259),
//--TRIMMABLE-BOUNDARY-START(201863725075),
    {
      "r": 1310721,
      "p": [
        {
          "n": "contents",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "ReadObjectIdentifier",
      "o": "@$1",
      "d": 262163,
      "h": 201863725075,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(201863725075),
//--TRIMMABLE-BOUNDARY-START(313532874771),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadOctetString",
      "d": 262163,
      "h": 313532874771,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(313532874771),
//--TRIMMABLE-BOUNDARY-START(206158692371),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadOctetString",
      "d": 262163,
      "h": 206158692371,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(206158692371),
//--TRIMMABLE-BOUNDARY-START(335007711251),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "universalTagNumber",
          "p": 1572883
        },
        {
          "n": "contentLength",
          "p": $.$typeNullable($.$$.System.Int32).$h,
          "f": 2
        },
        {
          "n": "headerLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "contents",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadPrimitiveOctetStringCore",
      "d": 262163,
      "h": 335007711251,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(335007711251),
//--TRIMMABLE-BOUNDARY-START(330712743955),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadPrimitiveOctetString",
      "d": 262163,
      "h": 330712743955,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(330712743955),
//--TRIMMABLE-BOUNDARY-START(42949935123),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "isIndefinite",
          "p": 262145
        }
      ],
      "n": "CountConstructedOctetString",
      "d": 262163,
      "h": 42949935123,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42949935123),
//--TRIMMABLE-BOUNDARY-START(30065033235),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "isIndefinite",
          "p": 262145
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "CopyConstructedOctetString",
      "o": "@$1",
      "d": 262163,
      "h": 30065033235,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065033235),
//--TRIMMABLE-BOUNDARY-START(34360000531),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "write",
          "p": 262145
        },
        {
          "n": "isIndefinite",
          "p": 262145
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "CopyConstructedOctetString",
      "d": 262163,
      "h": 34360000531,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34360000531),
//--TRIMMABLE-BOUNDARY-START(261993267219),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "dest",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "isIndefinite",
          "p": 262145
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryCopyConstructedOctetStringContents",
      "d": 262163,
      "h": 261993267219,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(261993267219),
//--TRIMMABLE-BOUNDARY-START(64424771603),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "universalTagNumber",
          "p": 1572883
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "rented",
          "p": $.$typeArray($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "tmpSpace",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h,
          "f": 65
        }
      ],
      "n": "GetOctetStringContents",
      "d": 262163,
      "h": 64424771603,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424771603),
//--TRIMMABLE-BOUNDARY-START(184683855891),
    {
      "r": (TFlagsEnum) => TFlagsEnum.$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "g": [
        "TFlagsEnum"
      ],
      "n": "ReadNamedBitListValue",
      "o": "@$1",
      "d": 262163,
      "h": 184683855891,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(184683855891),
//--TRIMMABLE-BOUNDARY-START(188978823187),
    {
      "r": 1048577,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "flagsEnumType",
          "p": 187629569
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadNamedBitListValue",
      "d": 262163,
      "h": 188978823187,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(188978823187),
//--TRIMMABLE-BOUNDARY-START(180388888595),
    {
      "r": 55181313,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadNamedBitList",
      "d": 262163,
      "h": 180388888595,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(180388888595),
//--TRIMMABLE-BOUNDARY-START(81604640787),
    {
      "r": 917505,
      "p": [
        {
          "n": "valueSpan",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "InterpretNamedBitListReversed",
      "d": 262163,
      "h": 81604640787,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604640787),
//--TRIMMABLE-BOUNDARY-START(231928496147),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "ReverseBitsPerByte",
      "d": 262163,
      "h": 231928496147,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(231928496147),
//--TRIMMABLE-BOUNDARY-START(210453659667),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "contentOffset",
          "p": 655361,
          "f": 2
        },
        {
          "n": "contentLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadSequence",
      "d": 262163,
      "h": 210453659667,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(210453659667),
//--TRIMMABLE-BOUNDARY-START(163209019411),
    {
      "r": 65339393,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadGeneralizedTime",
      "d": 262163,
      "h": 163209019411,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(163209019411),
//--TRIMMABLE-BOUNDARY-START(103079477267),
    {
      "r": 65339393,
      "p": [
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "contentOctets",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "ParseGeneralizedTime",
      "d": 262163,
      "h": 103079477267,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103079477267),
//--TRIMMABLE-BOUNDARY-START(171798954003),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadIntegerBytes",
      "d": 262163,
      "h": 171798954003,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(171798954003),
//--TRIMMABLE-BOUNDARY-START(167503986707),
    {
      "r": 786438,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadInteger",
      "d": 262163,
      "h": 167503986707,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(167503986707),
//--TRIMMABLE-BOUNDARY-START(300647972883),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "value",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadInt32",
      "d": 262163,
      "h": 300647972883,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(300647972883),
//--TRIMMABLE-BOUNDARY-START(343597645843),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "value",
          "p": 720897,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadUInt32",
      "d": 262163,
      "h": 343597645843,
      "f": 16777249,
      "a": [
        {
          "t": 54132737,
          "c": 8644067329,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(343597645843),
//--TRIMMABLE-BOUNDARY-START(304942940179),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "value",
          "p": 917505,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadInt64",
      "d": 262163,
      "h": 304942940179,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(304942940179),
//--TRIMMABLE-BOUNDARY-START(347892613139),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "value",
          "p": 983041,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadUInt64",
      "d": 262163,
      "h": 347892613139,
      "f": 16777249,
      "a": [
        {
          "t": 54132737,
          "c": 8644067329,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(347892613139),
//--TRIMMABLE-BOUNDARY-START(60129804307),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "tagNumber",
          "p": 1572883
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetIntegerContents",
      "d": 262163,
      "h": 60129804307,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60129804307),
//--TRIMMABLE-BOUNDARY-START(339302678547),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "sizeLimit",
          "p": 655361
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "tagNumber",
          "p": 1572883
        },
        {
          "n": "value",
          "p": 917505,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadSignedInteger",
      "d": 262163,
      "h": 339302678547,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(339302678547),
//--TRIMMABLE-BOUNDARY-START(352187580435),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "sizeLimit",
          "p": 655361
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "tagNumber",
          "p": 1572883
        },
        {
          "n": "value",
          "p": 983041,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadUnsignedInteger",
      "d": 262163,
      "h": 352187580435,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(352187580435),
//--TRIMMABLE-BOUNDARY-START(227633528851),
    {
      "r": 65339393,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "twoDigitYearMax",
          "p": 655361,
          "f": 65,
          "v": 2049
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadUtcTime",
      "d": 262163,
      "h": 227633528851,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(227633528851),
//--TRIMMABLE-BOUNDARY-START(120259346451),
    {
      "r": 65339393,
      "p": [
        {
          "n": "contentOctets",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "twoDigitYearMax",
          "p": 655361
        }
      ],
      "n": "ParseUtcTime",
      "d": 262163,
      "h": 120259346451,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120259346451),
//--TRIMMABLE-BOUNDARY-START(326417776659),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadPrimitiveCharacterStringBytes",
      "d": 262163,
      "h": 326417776659,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(326417776659),
//--TRIMMABLE-BOUNDARY-START(279173136403),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadCharacterStringBytes",
      "d": 262163,
      "h": 279173136403,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(279173136403),
//--TRIMMABLE-BOUNDARY-START(274878169107),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "encodingType",
          "p": 1572883
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadCharacterString",
      "d": 262163,
      "h": 274878169107,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(274878169107),
//--TRIMMABLE-BOUNDARY-START(137439215635),
    {
      "r": 1310721,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "encodingType",
          "p": 1572883
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadCharacterString",
      "d": 262163,
      "h": 137439215635,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(137439215635),
//--TRIMMABLE-BOUNDARY-START(283468103699),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "universalTagNumber",
          "p": 1572883
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadCharacterStringBytesCore",
      "d": 262163,
      "h": 283468103699,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(283468103699),
//--TRIMMABLE-BOUNDARY-START(287763070995),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadCharacterStringCore",
      "d": 262163,
      "h": 287763070995,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(287763070995),
//--TRIMMABLE-BOUNDARY-START(141734182931),
    {
      "r": 1310721,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "universalTagNumber",
          "p": 1572883
        },
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ReadCharacterStringCore",
      "d": 262163,
      "h": 141734182931,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(141734182931),
//--TRIMMABLE-BOUNDARY-START(292058038291),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "universalTagNumber",
          "p": 1572883
        },
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadCharacterStringCore",
      "o": "@$1",
      "d": 262163,
      "h": 292058038291,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(292058038291),
//--TRIMMABLE-BOUNDARY-START(85899608083),
    {
      "r": 262145,
      "p": [
        {
          "n": "encodingType",
          "p": 1572883
        }
      ],
      "n": "IsCharacterStringEncodingType",
      "d": 262163,
      "h": 85899608083,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85899608083),
//--TRIMMABLE-BOUNDARY-START(317827842067),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadPrimitiveBitString",
      "d": 262163,
      "h": 317827842067,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(317827842067),
//--TRIMMABLE-BOUNDARY-START(270583201811),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadBitString",
      "d": 262163,
      "h": 270583201811,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(270583201811),
//--TRIMMABLE-BOUNDARY-START(128849281043),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadBitString",
      "d": 262163,
      "h": 128849281043,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128849281043),
//--TRIMMABLE-BOUNDARY-START(115964379155),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
          "f": 2
        },
        {
          "n": "normalizedLastByte",
          "p": 393217,
          "f": 2
        }
      ],
      "n": "ParsePrimitiveBitStringContents",
      "d": 262163,
      "h": 115964379155,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(115964379155),
//--TRIMMABLE-BOUNDARY-START(21475098643),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "normalizedLastByte",
          "p": 393217
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "CopyBitStringValue",
      "d": 262163,
      "h": 21475098643,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475098643),
//--TRIMMABLE-BOUNDARY-START(38654967827),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "isIndefinite",
          "p": 262145
        }
      ],
      "n": "CountConstructedBitString",
      "d": 262163,
      "h": 38654967827,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38654967827),
//--TRIMMABLE-BOUNDARY-START(25770065939),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "isIndefinite",
          "p": 262145
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "CopyConstructedBitString",
      "d": 262163,
      "h": 25770065939,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770065939),
//--TRIMMABLE-BOUNDARY-START(124554313747),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "copyAction",
          "p": 327699
        },
        {
          "n": "isIndefinite",
          "p": 262145
        },
        {
          "n": "lastUnusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ProcessConstructedBitString",
      "d": 262163,
      "h": 124554313747,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(124554313747),
//--TRIMMABLE-BOUNDARY-START(257698299923),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "dest",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "isIndefinite",
          "p": 262145
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryCopyConstructedBitStringValue",
      "d": 262163,
      "h": 257698299923,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(257698299923),
//--TRIMMABLE-BOUNDARY-START(322122809363),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "contentsLength",
          "p": $.$typeNullable($.$$.System.Int32).$h,
          "f": 2
        },
        {
          "n": "headerLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "normalizedLastByte",
          "p": 393217,
          "f": 2
        }
      ],
      "n": "TryReadPrimitiveBitStringCore",
      "d": 262163,
      "h": 322122809363,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(322122809363),
//--TRIMMABLE-BOUNDARY-START(296353005587),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "tag",
          "p": 65555,
          "f": 2
        },
        {
          "n": "contentOffset",
          "p": 655361,
          "f": 2
        },
        {
          "n": "contentLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadEncodedValue",
      "d": 262163,
      "h": 296353005587,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(296353005587),
//--TRIMMABLE-BOUNDARY-START(146029150227),
    {
      "r": 65555,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "contentOffset",
          "p": 655361,
          "f": 2
        },
        {
          "n": "contentLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ReadEncodedValue",
      "d": 262163,
      "h": 146029150227,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(146029150227),
//--TRIMMABLE-BOUNDARY-START(68719738899),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "tagNumber",
          "p": 1572883
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetPrimitiveContentSpan",
      "d": 262163,
      "h": 68719738899,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68719738899),
//--TRIMMABLE-BOUNDARY-START(47244902419),
    {
      "r": $.$typeNullable($.$$.System.Int32).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "DecodeLength",
      "d": 262163,
      "h": 47244902419,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47244902419),
//--TRIMMABLE-BOUNDARY-START(266288234515),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "decodedLength",
          "p": $.$typeNullable($.$$.System.Int32).$h,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeLength",
      "d": 262163,
      "h": 266288234515,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(266288234515),
//--TRIMMABLE-BOUNDARY-START(309237907475),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "length",
          "p": $.$typeNullable($.$$.System.Int32).$h,
          "f": 2
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadLength",
      "d": 262163,
      "h": 309237907475,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(309237907475),
//--TRIMMABLE-BOUNDARY-START(176093921299),
    {
      "r": $.$typeNullable($.$$.System.Int32).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ReadLength",
      "d": 262163,
      "h": 176093921299,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(176093921299),
//--TRIMMABLE-BOUNDARY-START(51539869715),
    {
      "r": 393235,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "length",
          "p": $.$typeNullable($.$$.System.Int32).$h,
          "f": 2
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "DecodeLength",
      "o": "@$1",
      "d": 262163,
      "h": 51539869715,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51539869715),
//--TRIMMABLE-BOUNDARY-START(223338561555),
    {
      "r": 65555,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "contentsLength",
          "p": $.$typeNullable($.$$.System.Int32).$h,
          "f": 2
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ReadTagAndLength",
      "d": 262163,
      "h": 223338561555,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(223338561555),
//--TRIMMABLE-BOUNDARY-START(356482547731),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "length",
          "p": $.$typeNullable($.$$.System.Int32).$h
        },
        {
          "n": "headerLength",
          "p": 655361
        }
      ],
      "n": "ValidateEndOfContents",
      "d": 262163,
      "h": 356482547731,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(356482547731),
//--TRIMMABLE-BOUNDARY-START(360777515027),
    {
      "r": 458771,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "localTag",
          "p": 65555
        },
        {
          "n": "encodedLength",
          "p": $.$typeNullable($.$$.System.Int32).$h
        },
        {
          "n": "actualLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ValidateLength",
      "d": 262163,
      "h": 360777515027,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(360777515027),
//--TRIMMABLE-BOUNDARY-START(77309673491),
    {
      "r": 196627,
      "p": [
        {
          "n": "validity",
          "p": 458771
        }
      ],
      "n": "GetValidityException",
      "d": 262163,
      "h": 77309673491,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77309673491),
//--TRIMMABLE-BOUNDARY-START(73014706195),
    {
      "r": 655361,
      "p": [
        {
          "n": "primitiveType",
          "p": 187629569
        }
      ],
      "n": "GetPrimitiveIntegerSize",
      "d": 262163,
      "h": 73014706195,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73014706195),
//--TRIMMABLE-BOUNDARY-START(236223463443),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        }
      ],
      "n": "SeekEndOfContents",
      "d": 262163,
      "h": 236223463443,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(236223463443),
//--TRIMMABLE-BOUNDARY-START(111669411859),
    {
      "r": 655361,
      "p": [
        {
          "n": "data",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "bytesToRead",
          "p": 655361
        }
      ],
      "n": "ParseNonNegativeIntAndSlice",
      "d": 262163,
      "h": 111669411859,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(111669411859),
//--TRIMMABLE-BOUNDARY-START(107374444563),
    {
      "r": 655361,
      "p": [
        {
          "n": "data",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "ParseNonNegativeInt",
      "d": 262163,
      "h": 107374444563,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107374444563),
//--TRIMMABLE-BOUNDARY-START(253403332627),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "longestPermitted",
          "p": 655361
        }
      ],
      "n": "SliceAtMost",
      "d": 262163,
      "h": 253403332627,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(253403332627),
//--TRIMMABLE-BOUNDARY-START(240518430739),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "Slice",
      "o": "@$1",
      "d": 262163,
      "h": 240518430739,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(240518430739),
//--TRIMMABLE-BOUNDARY-START(244813398035),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "length",
          "p": $.$typeNullable($.$$.System.Int32).$h
        }
      ],
      "n": "Slice",
      "o": "@$2",
      "d": 262163,
      "h": 244813398035,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(244813398035),
//--TRIMMABLE-BOUNDARY-START(249108365331),
    {
      "r": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,
      "p": [
        {
          "n": "bigger",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "smaller",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "Slice",
      "d": 262163,
      "h": 249108365331,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(249108365331),
//--TRIMMABLE-BOUNDARY-START(4295229459),
    {
      "r": 65537,
      "p": [
        {
          "n": "ruleSet",
          "p": 524307
        }
      ],
      "n": "AssertEncodingRules",
      "d": 262163,
      "h": 4295229459,
      "f": 16777250,
      "a": [
        {
          "t": 68616193,
          "c": 4363583489,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295229459),
//--TRIMMABLE-BOUNDARY-START(12885164051),
    {
      "r": 65537,
      "p": [
        {
          "n": "ruleSet",
          "p": 524307
        }
      ],
      "n": "CheckEncodingRules",
      "d": 262163,
      "h": 12885164051,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885164051),
//--TRIMMABLE-BOUNDARY-START(17180131347),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "tagNumber",
          "p": 1572883
        }
      ],
      "n": "CheckExpectedTag",
      "d": 262163,
      "h": 17180131347,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180131347)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(98784509971),
    {
      "t": 655361,
      "n": "MaxCERSegmentSize",
      "d": 262163,
      "h": 98784509971,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784509971),
//--TRIMMABLE-BOUNDARY-START(55834837011),
    {
      "t": 655361,
      "n": "EndOfContentsEncodedLength",
      "d": 262163,
      "h": 55834837011,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834837011)
  ],
  "j": [327699,393235,458771
  ],
  "h": 262163
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.AsnDecoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262163)
        
        
        //--TRIMMABLE-BOUNDARY-START(589843)
        $asm.$cls("$sfa.System.Formats.Asn1.AsnReader", ($self) => class AsnReader extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(73015033875)
            /*bool */ ReadBoolean(/*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let bytesConsumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadBoolean(this._data.Span, this.RuleSet, $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(bytesConsumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(73015033875)
            
            //--TRIMMABLE-BOUNDARY-START(124554641427)
            /*void */ ReadNull(/*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554641427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNull(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
            }
            //--TRIMMABLE-BOUNDARY-END(124554641427)
            
            //--TRIMMABLE-BOUNDARY-START(85899935763)
            /*ReadOnlyMemory<byte> */ ReadEnumeratedBytes(/*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let bytes = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEnumeratedBytes(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                /*ReadOnlyMemory<byte>*/ let memory = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(this._data, bytes);
                this._data = this._data.Slice$1(consumed);
                return memory;
            }
            //--TRIMMABLE-BOUNDARY-END(85899935763)
            
            //--TRIMMABLE-BOUNDARY-START(90194903059)
            /*TEnum */ ReadEnumeratedValue$1(TEnum, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*TEnum*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEnumeratedValue$1(TEnum, this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(90194903059)
            
            //--TRIMMABLE-BOUNDARY-START(94489870355)
            /*Enum */ ReadEnumeratedValue(/*Type*/ enumType, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489870355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*Enum*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEnumeratedValue(this._data.Span, this.RuleSet, enumType, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(94489870355)
            
            //--TRIMMABLE-BOUNDARY-START(141734510611)
            /*AsnReader */ ReadSetOf$1(/*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734510611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadSetOf(this._options.SkipSetSortOrderVerification, expectedTag?.Clone() ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(141734510611)
            
            //--TRIMMABLE-BOUNDARY-START(146029477907)
            /*AsnReader */ ReadSetOf(/*bool*/ skipSortOrderValidation, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029477907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let contentOffset;
                /*int*/ let contentLength;
                /*int*/ let bytesConsumed;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadSetOf(this._data.Span, this.RuleSet, $.$ref(() => contentOffset, ($v) => contentOffset = $v, $.$$.System.Int32), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$$.System.Int32), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32), skipSortOrderValidation, expectedTag?.Clone() ?? null);
                /*AsnReader*/ let ret = this.CloneAtSlice(contentOffset, contentLength);
                this._data = this._data.Slice$1(bytesConsumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(146029477907)
            
            //--TRIMMABLE-BOUNDARY-START(128849608723)
            /*string */ ReadObjectIdentifier(/*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849608723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*string*/ let oidValue = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadObjectIdentifier(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return oidValue;
            }
            //--TRIMMABLE-BOUNDARY-END(128849608723)
            
            //--TRIMMABLE-BOUNDARY-START(188979150867)
            /*bool */ TryReadOctetString(/*Span<byte>*/ destination, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979150867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let bytesConsumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadOctetString(this._data.Span, destination, this.RuleSet, $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32), bytesWritten, expectedTag?.Clone() ?? null);
                if (ret)
                {
                    this._data = this._data.Slice$1(bytesConsumed);
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(188979150867)
            
            //--TRIMMABLE-BOUNDARY-START(133144576019)
            /*byte[] */ ReadOctetString(/*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144576019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*byte[]*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadOctetString(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(133144576019)
            
            //--TRIMMABLE-BOUNDARY-START(201864052755)
            /*bool */ TryReadPrimitiveOctetString(/*out ReadOnlyMemory<byte>*/ contents, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864052755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let span;
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetString(this._data.Span, this.RuleSet, $.$ref(() => span, ($v) => span = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                if (ret)
                {
                    contents.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(this._data, span);
                    this._data = this._data.Slice$1(consumed);
                }
                else 
                {
                    contents.$v = new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))();
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(201864052755)
            
            //--TRIMMABLE-BOUNDARY-START(115964706835)
            /*TFlagsEnum */ ReadNamedBitListValue$1(TFlagsEnum, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*TFlagsEnum*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNamedBitListValue$1(TFlagsEnum, this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(115964706835)
            
            //--TRIMMABLE-BOUNDARY-START(120259674131)
            /*Enum */ ReadNamedBitListValue(/*Type*/ flagsEnumType, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259674131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*Enum*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNamedBitListValue(this._data.Span, this.RuleSet, flagsEnumType, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(120259674131)
            
            //--TRIMMABLE-BOUNDARY-START(111669739539)
            /*BitArray */ ReadNamedBitList(/*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669739539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*BitArray*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNamedBitList(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(111669739539)
            
            //--TRIMMABLE-BOUNDARY-START(137439543315)
            /*AsnReader */ ReadSequence(/*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439543315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let contentStart;
                /*int*/ let contentLength;
                /*int*/ let bytesConsumed;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadSequence(this._data.Span, this.RuleSet, $.$ref(() => contentStart, ($v) => contentStart = $v, $.$$.System.Int32), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$$.System.Int32), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                /*AsnReader*/ let ret = this.CloneAtSlice(contentStart, contentLength);
                this._data = this._data.Slice$1(bytesConsumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(137439543315)
            
            //--TRIMMABLE-BOUNDARY-START(98784837651)
            /*DateTimeOffset */ ReadGeneralizedTime(/*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784837651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*DateTimeOffset*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadGeneralizedTime(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(98784837651)
            
            //--TRIMMABLE-BOUNDARY-START(107374772243)
            /*ReadOnlyMemory<byte> */ ReadIntegerBytes(/*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374772243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let bytes = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadIntegerBytes(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                /*ReadOnlyMemory<byte>*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(this._data, bytes);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(107374772243)
            
            //--TRIMMABLE-BOUNDARY-START(103079804947)
            /*BigInteger */ ReadInteger(/*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079804947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*BigInteger*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadInteger(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(103079804947)
            
            //--TRIMMABLE-BOUNDARY-START(180389216275)
            /*bool */ TryReadInt32(/*out int*/ value, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389216275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadInt32(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(read);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(180389216275)
            
            //--TRIMMABLE-BOUNDARY-START(206159020051)
            /*bool */ TryReadUInt32(/*out uint*/ value, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159020051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUInt32(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(read);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(206159020051)
            
            //--TRIMMABLE-BOUNDARY-START(184684183571)
            /*bool */ TryReadInt64(/*out long*/ value, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684183571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadInt64(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(read);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(184684183571)
            
            //--TRIMMABLE-BOUNDARY-START(210453987347)
            /*bool */ TryReadUInt64(/*out ulong*/ value, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453987347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUInt64(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(read);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(210453987347)
            
            //--TRIMMABLE-BOUNDARY-START(150324445203)
            /*DateTimeOffset */ ReadUtcTime$1(/*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324445203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*DateTimeOffset*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadUtcTime(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), this._options.UtcTimeTwoDigitYearMax, expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(150324445203)
            
            //--TRIMMABLE-BOUNDARY-START(154619412499)
            /*DateTimeOffset */ ReadUtcTime(/*int*/ twoDigitYearMax, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619412499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*DateTimeOffset*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadUtcTime(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), twoDigitYearMax, expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(154619412499)
            
            //--TRIMMABLE-BOUNDARY-START(197569085459)
            /*bool */ TryReadPrimitiveCharacterStringBytes(/*Asn1Tag*/ expectedTag, /*out ReadOnlyMemory<byte>*/ contents)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569085459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let span;
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveCharacterStringBytes(this._data.Span, this.RuleSet, expectedTag, $.$ref(() => span, ($v) => span = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (ret)
                {
                    contents.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(this._data, span);
                    this._data = this._data.Slice$1(consumed);
                }
                else 
                {
                    contents.$v = new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))();
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(197569085459)
            
            //--TRIMMABLE-BOUNDARY-START(176094248979)
            /*bool */ TryReadCharacterStringBytes(/*Span<byte>*/ destination, /*Asn1Tag*/ expectedTag, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094248979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterStringBytes(this._data.Span, destination, this.RuleSet, expectedTag, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), bytesWritten);
                if (ret)
                {
                    this._data = this._data.Slice$1(consumed);
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(176094248979)
            
            //--TRIMMABLE-BOUNDARY-START(171799281683)
            /*bool */ TryReadCharacterString(/*Span<char>*/ destination, /*UniversalTagNumber*/ encodingType, /*out int*/ charsWritten, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799281683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterString(this._data.Span, destination, this.RuleSet, encodingType, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), charsWritten, expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(171799281683)
            
            //--TRIMMABLE-BOUNDARY-START(77310001171)
            /*string */ ReadCharacterString(/*UniversalTagNumber*/ encodingType, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*string*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadCharacterString(this._data.Span, this.RuleSet, encodingType, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(77310001171)
            
            //--TRIMMABLE-BOUNDARY-START(193274118163)
            /*bool */ TryReadPrimitiveBitString(/*out int*/ unusedBitCount, /*out ReadOnlyMemory<byte>*/ value, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274118163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let span;
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveBitString(this._data.Span, this.RuleSet, unusedBitCount, $.$ref(() => span, ($v) => span = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                if (ret)
                {
                    value.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(this._data, span);
                    this._data = this._data.Slice$1(consumed);
                }
                else 
                {
                    value.$v = new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))();
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(193274118163)
            
            //--TRIMMABLE-BOUNDARY-START(167504314387)
            /*bool */ TryReadBitString(/*Span<byte>*/ destination, /*out int*/ unusedBitCount, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504314387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadBitString(this._data.Span, destination, this.RuleSet, unusedBitCount, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), bytesWritten, expectedTag?.Clone() ?? null);
                if (ret)
                {
                    this._data = this._data.Slice$1(consumed);
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(167504314387)
            
            //--TRIMMABLE-BOUNDARY-START(68720066579)
            /*byte[] */ ReadBitString(/*out int*/ unusedBitCount, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*byte[]*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadBitString(this._data.Span, this.RuleSet, unusedBitCount, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(68720066579)
            
            //--TRIMMABLE-BOUNDARY-START(51540197395)
            /*int*/ static MaxCERSegmentSize = 1000;
            //--TRIMMABLE-BOUNDARY-END(51540197395)
            
            //--TRIMMABLE-BOUNDARY-START(4295557139)
            /*ReadOnlyMemory<byte>*/ _data;
            //--TRIMMABLE-BOUNDARY-END(4295557139)
            
            //--TRIMMABLE-BOUNDARY-START(8590524435)
            /*AsnReaderOptions*/ _options;
            //--TRIMMABLE-BOUNDARY-END(8590524435)
            
            //--TRIMMABLE-BOUNDARY-START(158914379795)
            /*AsnEncodingRules*/ RuleSet = 0;
            //--TRIMMABLE-BOUNDARY-END(158914379795)
            
            //--TRIMMABLE-BOUNDARY-START(47245230099)
            /*bool */ get HasData()
            {
                return !this._data.IsEmpty;
            }
            //--TRIMMABLE-BOUNDARY-END(47245230099)
            
            //--TRIMMABLE-BOUNDARY-START(12885491731)
            $ctor$1(/*ReadOnlyMemory<byte>*/ data, /*AsnEncodingRules*/ ruleSet, /*AsnReaderOptions*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885491731);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                    this._data = data;
                    this.RuleSet = ruleSet;
                    this._options = options.Clone();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491731)
            
            //--TRIMMABLE-BOUNDARY-START(163209347091)
            /*void */ ThrowIfNotEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209347091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.HasData)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_TooMuchData);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209347091)
            
            //--TRIMMABLE-BOUNDARY-START(64425099283)
            /*Asn1Tag */ PeekTag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425099283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.Asn1Tag.Decode(this._data.Span, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(64425099283)
            
            //--TRIMMABLE-BOUNDARY-START(60130131987)
            /*ReadOnlyMemory<byte> */ PeekEncodedValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130131987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let bytesConsumed;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEncodedValue(this._data.Span, this.RuleSet, $.$discardRef(), $.$discardRef(), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32));
                return this._data.Slice(0, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(60130131987)
            
            //--TRIMMABLE-BOUNDARY-START(55835164691)
            /*ReadOnlyMemory<byte> */ PeekContentBytes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835164691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let contentOffset;
                /*int*/ let contentLength;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEncodedValue(this._data.Span, this.RuleSet, $.$ref(() => contentOffset, ($v) => contentOffset = $v, $.$$.System.Int32), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$$.System.Int32), $.$discardRef());
                return this._data.Slice(contentOffset, contentLength);
            }
            //--TRIMMABLE-BOUNDARY-END(55835164691)
            
            //--TRIMMABLE-BOUNDARY-START(81604968467)
            /*ReadOnlyMemory<byte> */ ReadEncodedValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604968467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlyMemory<byte>*/ let encodedValue = this.PeekEncodedValue();
                this._data = this._data.Slice$1(encodedValue.Length);
                return encodedValue;
            }
            //--TRIMMABLE-BOUNDARY-END(81604968467)
            
            //--TRIMMABLE-BOUNDARY-START(21475426323)
            /*AsnReader */ Clone()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426323);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sfa.System.Formats.Asn1.AsnReader().$ctor$1(this._data, this.RuleSet, this._options.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475426323)
            
            //--TRIMMABLE-BOUNDARY-START(25770393619)
            /*AsnReader */ CloneAtSlice(/*int*/ start, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sfa.System.Formats.Asn1.AsnReader().$ctor$1(this._data.Slice(start, length), this.RuleSet, this._options.Clone());
            }
            //--TRIMMABLE-BOUNDARY-END(25770393619)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295557139)
                this._data = $.$default($.$$.System.ReadOnlyMemory$$($.$$.System.Byte));
                //--TRIMMABLE-BOUNDARY-END(4295557139)
                
                //--TRIMMABLE-BOUNDARY-START(8590524435)
                this._options = $.$default($.$sfa.System.Formats.Asn1.AsnReaderOptions);
                //--TRIMMABLE-BOUNDARY-END(8590524435)
                
            }
            static $h = 589843;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(158914379795),
    {
      "p": 524307,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262803,
        "f": 50331649
      },
      "n": "RuleSet",
      "d": 589843,
      "h": 158914379795,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914379795),
//--TRIMMABLE-BOUNDARY-START(47245230099),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360328211,
        "f": 50331649
      },
      "n": "HasData",
      "d": 589843,
      "h": 47245230099,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245230099)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015033875),
    {
      "r": 262145,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadBoolean",
      "d": 589843,
      "h": 73015033875,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015033875),
//--TRIMMABLE-BOUNDARY-START(124554641427),
    {
      "r": 65537,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadNull",
      "d": 589843,
      "h": 124554641427,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124554641427),
//--TRIMMABLE-BOUNDARY-START(85899935763),
    {
      "r": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadEnumeratedBytes",
      "d": 589843,
      "h": 85899935763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899935763),
//--TRIMMABLE-BOUNDARY-START(90194903059),
    {
      "r": (TEnum) => TEnum.$h,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "g": [
        "TEnum"
      ],
      "n": "ReadEnumeratedValue",
      "o": "@$1",
      "d": 589843,
      "h": 90194903059,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(90194903059),
//--TRIMMABLE-BOUNDARY-START(94489870355),
    {
      "r": 1048577,
      "p": [
        {
          "n": "enumType",
          "p": 187629569
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadEnumeratedValue",
      "d": 589843,
      "h": 94489870355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489870355),
//--TRIMMABLE-BOUNDARY-START(141734510611),
    {
      "r": 589843,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadSetOf",
      "o": "@$1",
      "d": 589843,
      "h": 141734510611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141734510611),
//--TRIMMABLE-BOUNDARY-START(146029477907),
    {
      "r": 589843,
      "p": [
        {
          "n": "skipSortOrderValidation",
          "p": 262145
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadSetOf",
      "d": 589843,
      "h": 146029477907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029477907),
//--TRIMMABLE-BOUNDARY-START(128849608723),
    {
      "r": 1310721,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadObjectIdentifier",
      "d": 589843,
      "h": 128849608723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128849608723),
//--TRIMMABLE-BOUNDARY-START(188979150867),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadOctetString",
      "d": 589843,
      "h": 188979150867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188979150867),
//--TRIMMABLE-BOUNDARY-START(133144576019),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadOctetString",
      "d": 589843,
      "h": 133144576019,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133144576019),
//--TRIMMABLE-BOUNDARY-START(201864052755),
    {
      "r": 262145,
      "p": [
        {
          "n": "contents",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadPrimitiveOctetString",
      "d": 589843,
      "h": 201864052755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201864052755),
//--TRIMMABLE-BOUNDARY-START(115964706835),
    {
      "r": (TFlagsEnum) => TFlagsEnum.$h,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "g": [
        "TFlagsEnum"
      ],
      "n": "ReadNamedBitListValue",
      "o": "@$1",
      "d": 589843,
      "h": 115964706835,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(115964706835),
//--TRIMMABLE-BOUNDARY-START(120259674131),
    {
      "r": 1048577,
      "p": [
        {
          "n": "flagsEnumType",
          "p": 187629569
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadNamedBitListValue",
      "d": 589843,
      "h": 120259674131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120259674131),
//--TRIMMABLE-BOUNDARY-START(111669739539),
    {
      "r": 55181313,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadNamedBitList",
      "d": 589843,
      "h": 111669739539,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669739539),
//--TRIMMABLE-BOUNDARY-START(137439543315),
    {
      "r": 589843,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadSequence",
      "d": 589843,
      "h": 137439543315,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439543315),
//--TRIMMABLE-BOUNDARY-START(98784837651),
    {
      "r": 65339393,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadGeneralizedTime",
      "d": 589843,
      "h": 98784837651,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784837651),
//--TRIMMABLE-BOUNDARY-START(107374772243),
    {
      "r": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadIntegerBytes",
      "d": 589843,
      "h": 107374772243,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374772243),
//--TRIMMABLE-BOUNDARY-START(103079804947),
    {
      "r": 786438,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadInteger",
      "d": 589843,
      "h": 103079804947,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079804947),
//--TRIMMABLE-BOUNDARY-START(180389216275),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadInt32",
      "d": 589843,
      "h": 180389216275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180389216275),
//--TRIMMABLE-BOUNDARY-START(206159020051),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadUInt32",
      "d": 589843,
      "h": 206159020051,
      "f": 16777217,
      "a": [
        {
          "t": 54132737,
          "c": 8644067329,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206159020051),
//--TRIMMABLE-BOUNDARY-START(184684183571),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 917505,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadInt64",
      "d": 589843,
      "h": 184684183571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684183571),
//--TRIMMABLE-BOUNDARY-START(210453987347),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 983041,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadUInt64",
      "d": 589843,
      "h": 210453987347,
      "f": 16777217,
      "a": [
        {
          "t": 54132737,
          "c": 8644067329,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210453987347),
//--TRIMMABLE-BOUNDARY-START(150324445203),
    {
      "r": 65339393,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadUtcTime",
      "o": "@$1",
      "d": 589843,
      "h": 150324445203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324445203),
//--TRIMMABLE-BOUNDARY-START(154619412499),
    {
      "r": 65339393,
      "p": [
        {
          "n": "twoDigitYearMax",
          "p": 655361
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadUtcTime",
      "d": 589843,
      "h": 154619412499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154619412499),
//--TRIMMABLE-BOUNDARY-START(197569085459),
    {
      "r": 262145,
      "p": [
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "contents",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,
          "f": 2
        }
      ],
      "n": "TryReadPrimitiveCharacterStringBytes",
      "d": 589843,
      "h": 197569085459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197569085459),
//--TRIMMABLE-BOUNDARY-START(176094248979),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadCharacterStringBytes",
      "d": 589843,
      "h": 176094248979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094248979),
//--TRIMMABLE-BOUNDARY-START(171799281683),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "encodingType",
          "p": 1572883
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadCharacterString",
      "d": 589843,
      "h": 171799281683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171799281683),
//--TRIMMABLE-BOUNDARY-START(77310001171),
    {
      "r": 1310721,
      "p": [
        {
          "n": "encodingType",
          "p": 1572883
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadCharacterString",
      "d": 589843,
      "h": 77310001171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310001171),
//--TRIMMABLE-BOUNDARY-START(193274118163),
    {
      "r": 262145,
      "p": [
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "value",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadPrimitiveBitString",
      "d": 589843,
      "h": 193274118163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193274118163),
//--TRIMMABLE-BOUNDARY-START(167504314387),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadBitString",
      "d": 589843,
      "h": 167504314387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167504314387),
//--TRIMMABLE-BOUNDARY-START(68720066579),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadBitString",
      "d": 589843,
      "h": 68720066579,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720066579),
//--TRIMMABLE-BOUNDARY-START(163209347091),
    {
      "r": 65537,
      "n": "ThrowIfNotEmpty",
      "d": 589843,
      "h": 163209347091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209347091),
//--TRIMMABLE-BOUNDARY-START(64425099283),
    {
      "r": 65555,
      "n": "PeekTag",
      "d": 589843,
      "h": 64425099283,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425099283),
//--TRIMMABLE-BOUNDARY-START(60130131987),
    {
      "r": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,
      "n": "PeekEncodedValue",
      "d": 589843,
      "h": 60130131987,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130131987),
//--TRIMMABLE-BOUNDARY-START(55835164691),
    {
      "r": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,
      "n": "PeekContentBytes",
      "d": 589843,
      "h": 55835164691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835164691),
//--TRIMMABLE-BOUNDARY-START(81604968467),
    {
      "r": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,
      "n": "ReadEncodedValue",
      "d": 589843,
      "h": 81604968467,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604968467),
//--TRIMMABLE-BOUNDARY-START(21475426323),
    {
      "r": 589843,
      "n": "Clone",
      "d": 589843,
      "h": 21475426323,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426323),
//--TRIMMABLE-BOUNDARY-START(25770393619),
    {
      "r": 589843,
      "p": [
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "CloneAtSlice",
      "d": 589843,
      "h": 25770393619,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770393619)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540197395),
    {
      "t": 655361,
      "n": "MaxCERSegmentSize",
      "d": 589843,
      "h": 51540197395,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51540197395),
//--TRIMMABLE-BOUNDARY-START(4295557139),
    {
      "t": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,
      "n": "_data",
      "d": 589843,
      "h": 4295557139,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557139),
//--TRIMMABLE-BOUNDARY-START(8590524435),
    {
      "t": 655379,
      "n": "_options",
      "d": 589843,
      "h": 8590524435,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524435)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885491731),
    {
      "p": [
        {
          "n": "data",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "options",
          "p": 655379,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589843,
      "h": 12885491731,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885491731)
  ],
  "h": 589843
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.AsnReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589843)
        
        
        //--TRIMMABLE-BOUNDARY-START(131091)
        $asm.$cls("$sfa.System.Formats.Asn1.AsnCharacterStringEncodings", ($self) => class AsnCharacterStringEncodings
        {
            //--TRIMMABLE-BOUNDARY-START(42949804051)
            /*UTF8Encoding*/ static s_utf8Encoding = null;
            //--TRIMMABLE-BOUNDARY-END(42949804051)
            
            //--TRIMMABLE-BOUNDARY-START(21474967571)
            /*BMPEncoding*/ static s_bmpEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(21474967571)
            
            //--TRIMMABLE-BOUNDARY-START(25769934867)
            /*IA5Encoding*/ static s_ia5Encoding = null;
            //--TRIMMABLE-BOUNDARY-END(25769934867)
            
            //--TRIMMABLE-BOUNDARY-START(47244771347)
            /*VisibleStringEncoding*/ static s_visibleStringEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(47244771347)
            
            //--TRIMMABLE-BOUNDARY-START(30064902163)
            /*NumericStringEncoding*/ static s_numericStringEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(30064902163)
            
            //--TRIMMABLE-BOUNDARY-START(34359869459)
            /*PrintableStringEncoding*/ static s_printableStringEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(34359869459)
            
            //--TRIMMABLE-BOUNDARY-START(38654836755)
            /*T61Encoding*/ static s_t61Encoding = null;
            //--TRIMMABLE-BOUNDARY-END(38654836755)
            
            //--TRIMMABLE-BOUNDARY-START(17180000275)
            static /*Encoding */ GetEncoding(/*UniversalTagNumber*/ encodingType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180000275);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        if (encodingType === 12/*UniversalTagNumber.UTF8String*/)
                        {
                            return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_utf8Encoding;
                        }
                        if (encodingType === 18/*UniversalTagNumber.NumericString*/)
                        {
                            return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_numericStringEncoding;
                        }
                        if (encodingType === 19/*UniversalTagNumber.PrintableString*/)
                        {
                            return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_printableStringEncoding;
                        }
                        if (encodingType === 22/*UniversalTagNumber.IA5String*/)
                        {
                            return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_ia5Encoding;
                        }
                        if (encodingType === 26/*UniversalTagNumber.VisibleString*/)
                        {
                            return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_visibleStringEncoding;
                        }
                        if (encodingType === 30/*UniversalTagNumber.BMPString*/)
                        {
                            return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_bmpEncoding;
                        }
                        if (encodingType === 20/*UniversalTagNumber.T61String*/)
                        {
                            return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_t61Encoding;
                        }
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("encodingType", $.$box(encodingType, $.$sfa.System.Formats.Asn1.UniversalTagNumber), null);
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180000275)
            
            //--TRIMMABLE-BOUNDARY-START(8590065683)
            static /*int */ GetByteCount(/*this Encoding*/ encoding, /*ReadOnlySpan<char>*/ str)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (str.IsEmpty)
                {
                    str = $.$$.System.MemoryExtensions.AsSpan$4($.$$.System.String.Empty);
                }
                {
                    /*fixed*/ 
                    {
                        /*char**/ let strPtr = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Char, str);
                        return encoding.GetByteCount$3(strPtr, str.Length);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590065683)
            
            //--TRIMMABLE-BOUNDARY-START(12885032979)
            static /*int */ GetBytes(/*this Encoding*/ encoding, /*ReadOnlySpan<char>*/ chars, /*Span<byte>*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885032979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (chars.IsEmpty)
                {
                    chars = $.$$.System.MemoryExtensions.AsSpan$4($.$$.System.String.Empty);
                }
                if (bytes.IsEmpty)
                {
                    bytes = $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2($.$$.System.Array.Empty($.$$.System.Byte));
                }
                {
                    /*fixed*/ 
                    {
                        /*char**/ let charsPtr = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Char, chars);
                        /*fixed*/ 
                        {
                            /*byte**/ let bytesPtr = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Byte, bytes);
                            return encoding.GetBytes$4(charsPtr, chars.Length, bytesPtr, bytes.Length);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885032979)
            
            //--TRIMMABLE-BOUNDARY-START(4295098387)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(42949804051)
                    this.s_utf8Encoding = new $.$$.System.Text.UTF8Encoding().$ctor$5(false, true);
                    //--TRIMMABLE-BOUNDARY-END(42949804051)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474967571)
                    this.s_bmpEncoding = new $.$sfa.System.Formats.Asn1.BMPEncoding().$ctor$5();
                    //--TRIMMABLE-BOUNDARY-END(21474967571)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769934867)
                    this.s_ia5Encoding = new $.$sfa.System.Formats.Asn1.IA5Encoding().$ctor$7();
                    //--TRIMMABLE-BOUNDARY-END(25769934867)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244771347)
                    this.s_visibleStringEncoding = new $.$sfa.System.Formats.Asn1.VisibleStringEncoding().$ctor$7();
                    //--TRIMMABLE-BOUNDARY-END(47244771347)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30064902163)
                    this.s_numericStringEncoding = new $.$sfa.System.Formats.Asn1.NumericStringEncoding().$ctor$7();
                    //--TRIMMABLE-BOUNDARY-END(30064902163)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359869459)
                    this.s_printableStringEncoding = new $.$sfa.System.Formats.Asn1.PrintableStringEncoding().$ctor$7();
                    //--TRIMMABLE-BOUNDARY-END(34359869459)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654836755)
                    this.s_t61Encoding = new $.$sfa.System.Formats.Asn1.T61Encoding().$ctor$4();
                    //--TRIMMABLE-BOUNDARY-END(38654836755)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295098387)
            
            static $h = 131091;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180000275),
    {
      "r": 165806081,
      "p": [
        {
          "n": "encodingType",
          "p": 1572883
        }
      ],
      "n": "GetEncoding",
      "d": 131091,
      "h": 17180000275,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180000275),
//--TRIMMABLE-BOUNDARY-START(8590065683),
    {
      "r": 655361,
      "p": [
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "str",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "GetByteCount",
      "d": 131091,
      "h": 8590065683,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590065683),
//--TRIMMABLE-BOUNDARY-START(12885032979),
    {
      "r": 655361,
      "p": [
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "chars",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "bytes",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "GetBytes",
      "d": 131091,
      "h": 12885032979,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885032979)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42949804051),
    {
      "t": 168689665,
      "n": "s_utf8Encoding",
      "d": 131091,
      "h": 42949804051,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42949804051),
//--TRIMMABLE-BOUNDARY-START(21474967571),
    {
      "t": 983059,
      "n": "s_bmpEncoding",
      "d": 131091,
      "h": 21474967571,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21474967571),
//--TRIMMABLE-BOUNDARY-START(25769934867),
    {
      "t": 1048595,
      "n": "s_ia5Encoding",
      "d": 131091,
      "h": 25769934867,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25769934867),
//--TRIMMABLE-BOUNDARY-START(47244771347),
    {
      "t": 1638419,
      "n": "s_visibleStringEncoding",
      "d": 131091,
      "h": 47244771347,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47244771347),
//--TRIMMABLE-BOUNDARY-START(30064902163),
    {
      "t": 1114131,
      "n": "s_numericStringEncoding",
      "d": 131091,
      "h": 30064902163,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30064902163),
//--TRIMMABLE-BOUNDARY-START(34359869459),
    {
      "t": 1179667,
      "n": "s_printableStringEncoding",
      "d": 131091,
      "h": 34359869459,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34359869459),
//--TRIMMABLE-BOUNDARY-START(38654836755),
    {
      "t": 1441811,
      "n": "s_t61Encoding",
      "d": 131091,
      "h": 38654836755,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38654836755)
  ],
  "h": 131091
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.AsnCharacterStringEncodings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131091)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835027)
        $asm.$cls("$sfa.System.Security.Cryptography.CryptoPool", ($self) => class CryptoPool
        {
            //--TRIMMABLE-BOUNDARY-START(4296802323)
            /*int*/ static ClearAll = -1;
            //--TRIMMABLE-BOUNDARY-END(4296802323)
            
            //--TRIMMABLE-BOUNDARY-START(8591769619)
            static /*byte[] */ Rent(/*int*/ minimumLength)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591769619);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(minimumLength);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591769619)
            
            //--TRIMMABLE-BOUNDARY-START(12886736915)
            static /*void */ Return(/*ArraySegment<byte>*/ arraySegment, /*int*/ clearSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886736915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(arraySegment.Array !== null, "arraySegment.Array != null");
                $.$$.System.Diagnostics.Debug.Assert$2(arraySegment.Offset === 0, "arraySegment.Offset == 0");
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(arraySegment.Array, clearSize === -1/*ClearAll*/ ? arraySegment.Count : clearSize);
            }
            //--TRIMMABLE-BOUNDARY-END(12886736915)
            
            //--TRIMMABLE-BOUNDARY-START(17181704211)
            static /*void */ Return$1(/*byte[]*/ array, /*int*/ clearSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181704211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(clearSize <= array.length, "clearSize <= array.Length");
                /*bool*/ let clearWholeArray = clearSize < 0;
                if (!clearWholeArray && clearSize !== 0)
                {
                    $.$$.System.Array.Clear(array, 0, clearSize);
                }
                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(array, clearWholeArray);
            }
            //--TRIMMABLE-BOUNDARY-END(17181704211)
            
            static $h = 1835027;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591769619),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "minimumLength",
          "p": 655361
        }
      ],
      "n": "Rent",
      "d": 1835027,
      "h": 8591769619,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591769619),
//--TRIMMABLE-BOUNDARY-START(12886736915),
    {
      "r": 65537,
      "p": [
        {
          "n": "arraySegment",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "clearSize",
          "p": 655361,
          "f": 65,
          "v": -1
        }
      ],
      "n": "Return",
      "d": 1835027,
      "h": 12886736915,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886736915),
//--TRIMMABLE-BOUNDARY-START(17181704211),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "clearSize",
          "p": 655361,
          "f": 65,
          "v": -1
        }
      ],
      "n": "Return",
      "o": "@$1",
      "d": 1835027,
      "h": 17181704211,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17181704211)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296802323),
    {
      "t": 655361,
      "n": "ClearAll",
      "d": 1835027,
      "h": 4296802323,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4296802323)
  ],
  "h": 1835027
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.Cryptography.CryptoPool`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835027)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966099)
        $asm.$cls("$sfa.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(562642681875)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(562642681875)
            
            //--TRIMMABLE-BOUNDARY-START(554052747283)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(554052747283)
            
            //--TRIMMABLE-BOUNDARY-START(558347714579)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536872878099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$sfa.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Formats.Asn1", $.$sfa.System.SR.$type.Assembly);
                    $.$sfa.System.SR.s_resourceManager = temp;
                }
                return $.$sfa.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(558347714579)
            
            //--TRIMMABLE-BOUNDARY-START(158915756051)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528282943507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575527583763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(158915756051)
            
            //--TRIMMABLE-BOUNDARY-START(8591900691)
            static /*string */ get Argument_DestinationTooShort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635232787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Destination is too short.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591900691)
            
            //--TRIMMABLE-BOUNDARY-START(17181835283)
            static /*string */ get Argument_EnumeratedValueRequiresNonFlagsEnum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815101971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "ASN.1 Enumerated values only apply to enum types without the [Flags] attribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(17181835283)
            
            //--TRIMMABLE-BOUNDARY-START(12886867987)
            static /*string */ get Argument_EnumeratedValueBackingTypeNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225167379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Enumerations with a backing type of '{0}' are not supported for ReadEnumeratedValue.";
            }
            //--TRIMMABLE-BOUNDARY-END(12886867987)
            
            //--TRIMMABLE-BOUNDARY-START(197570461715)
            static /*string */ FormatArgument_EnumeratedValueBackingTypeNotSupported(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570461715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Enumerations with a backing type of '{0}' are not supported for ReadEnumeratedValue.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(197570461715)
            
            //--TRIMMABLE-BOUNDARY-START(30066737171)
            static /*string */ get Argument_InvalidOidValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584905747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The OID value is invalid.";
            }
            //--TRIMMABLE-BOUNDARY-END(30066737171)
            
            //--TRIMMABLE-BOUNDARY-START(34361704467)
            static /*string */ get Argument_NamedBitListRequiresFlagsEnum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174840339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Named bit list operations require an enum with the [Flags] attribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(34361704467)
            
            //--TRIMMABLE-BOUNDARY-START(38656671763)
            static /*string */ get Argument_SourceOverlapsDestination()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764774931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The destination buffer overlaps the source buffer.";
            }
            //--TRIMMABLE-BOUNDARY-END(38656671763)
            
            //--TRIMMABLE-BOUNDARY-START(42951639059)
            static /*string */ get Argument_Tag_NotCharacterString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354709523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified tag has the Universal TagClass, but the TagValue does not correspond with a known character string type.";
            }
            //--TRIMMABLE-BOUNDARY-END(42951639059)
            
            //--TRIMMABLE-BOUNDARY-START(21476802579)
            static /*string */ get Argument_IntegerCannotBeEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405036563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An integer value cannot be empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(21476802579)
            
            //--TRIMMABLE-BOUNDARY-START(25771769875)
            static /*string */ get Argument_IntegerRedundantByte()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994971155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The first 9 bits of the integer value all have the same value. Ensure the input is in big-endian byte order and that all redundant leading bytes have been removed.";
            }
            //--TRIMMABLE-BOUNDARY-END(25771769875)
            
            //--TRIMMABLE-BOUNDARY-START(47246606355)
            static /*string */ get Argument_UniversalValueIsFixed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304944644115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Tags with TagClass Universal must have the appropriate TagValue value for the data type being read or written.";
            }
            //--TRIMMABLE-BOUNDARY-END(47246606355)
            
            //--TRIMMABLE-BOUNDARY-START(51541573651)
            static /*string */ get Argument_UnusedBitCountMustBeZero()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313534578707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unused bit count must be 0 when the bit string is empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(51541573651)
            
            //--TRIMMABLE-BOUNDARY-START(55836540947)
            static /*string */ get Argument_UnusedBitCountRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124513299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unused bit count must be between 0 and 7, inclusive.";
            }
            //--TRIMMABLE-BOUNDARY-END(55836540947)
            
            //--TRIMMABLE-BOUNDARY-START(60131508243)
            static /*string */ get Argument_UnusedBitWasSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714447891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "One or more of the bits covered by the provided unusedBitCount value is set. All unused bits must be cleared.";
            }
            //--TRIMMABLE-BOUNDARY-END(60131508243)
            
            //--TRIMMABLE-BOUNDARY-START(64426475539)
            static /*string */ get Argument_WriteEncodedValue_OneValueAtATime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304382483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The input to WriteEncodedValue must represent a single encoded value with no trailing data.";
            }
            //--TRIMMABLE-BOUNDARY-END(64426475539)
            
            //--TRIMMABLE-BOUNDARY-START(68721442835)
            static /*string */ get ArgumentOutOfRange_NeedNonNegNum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894317075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Non-negative number required.";
            }
            //--TRIMMABLE-BOUNDARY-END(68721442835)
            
            //--TRIMMABLE-BOUNDARY-START(73016410131)
            static /*string */ get AsnWriter_EncodeUnbalancedStack()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356484251667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Encode cannot be called while a Sequence, Set-Of, or Octet String is still open.";
            }
            //--TRIMMABLE-BOUNDARY-END(73016410131)
            
            //--TRIMMABLE-BOUNDARY-START(77311377427)
            static /*string */ get AsnWriter_ModifyingWhileEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365074186259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The AsnWriter cannot be written to while performing the Encode callback.";
            }
            //--TRIMMABLE-BOUNDARY-END(77311377427)
            
            //--TRIMMABLE-BOUNDARY-START(81606344723)
            static /*string */ get AsnWriter_PopWrongTag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373664120851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot pop the requested tag as it is not currently in progress.";
            }
            //--TRIMMABLE-BOUNDARY-END(81606344723)
            
            //--TRIMMABLE-BOUNDARY-START(85901312019)
            static /*string */ get ContentException_CerRequiresIndefiniteLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382254055443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A constructed tag used a definite length encoding, which is invalid for CER data. The input may be encoded with BER or DER.";
            }
            //--TRIMMABLE-BOUNDARY-END(85901312019)
            
            //--TRIMMABLE-BOUNDARY-START(90196279315)
            static /*string */ get ContentException_ConstructedEncodingRequired()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390843990035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded value uses a primitive encoding, which is invalid for '{0}' values.";
            }
            //--TRIMMABLE-BOUNDARY-END(90196279315)
            
            //--TRIMMABLE-BOUNDARY-START(201865429011)
            static /*string */ FormatContentException_ConstructedEncodingRequired(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865429011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The encoded value uses a primitive encoding, which is invalid for '{0}' values.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(201865429011)
            
            //--TRIMMABLE-BOUNDARY-START(94491246611)
            static /*string */ get ContentException_DefaultMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399433924627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The ASN.1 value is invalid.";
            }
            //--TRIMMABLE-BOUNDARY-END(94491246611)
            
            //--TRIMMABLE-BOUNDARY-START(98786213907)
            static /*string */ get ContentException_EnumeratedValueTooBig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408023859219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded enumerated value is larger than the value size of the '{0}' enum.";
            }
            //--TRIMMABLE-BOUNDARY-END(98786213907)
            
            //--TRIMMABLE-BOUNDARY-START(206160396307)
            static /*string */ FormatContentException_EnumeratedValueTooBig(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160396307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The encoded enumerated value is larger than the value size of the '{0}' enum.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(206160396307)
            
            //--TRIMMABLE-BOUNDARY-START(107376148499)
            static /*string */ get ContentException_InvalidUnderCer_TryBerOrDer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425203728403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded value is not valid under the selected encoding, but it may be valid under the BER or DER encoding.";
            }
            //--TRIMMABLE-BOUNDARY-END(107376148499)
            
            //--TRIMMABLE-BOUNDARY-START(111671115795)
            static /*string */ get ContentException_InvalidUnderCerOrDer_TryBer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433793662995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded value is not valid under the selected encoding, but it may be valid under the BER encoding.";
            }
            //--TRIMMABLE-BOUNDARY-END(111671115795)
            
            //--TRIMMABLE-BOUNDARY-START(115966083091)
            static /*string */ get ContentException_InvalidUnderDer_TryBerOrCer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442383597587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded value is not valid under the selected encoding, but it may be valid under the BER or CER encoding.";
            }
            //--TRIMMABLE-BOUNDARY-END(115966083091)
            
            //--TRIMMABLE-BOUNDARY-START(103081181203)
            static /*string */ get ContentException_InvalidTag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416613793811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The provided data does not represent a valid tag.";
            }
            //--TRIMMABLE-BOUNDARY-END(103081181203)
            
            //--TRIMMABLE-BOUNDARY-START(120261050387)
            static /*string */ get ContentException_LengthExceedsPayload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450973532179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded length exceeds the number of bytes remaining in the input buffer.";
            }
            //--TRIMMABLE-BOUNDARY-END(120261050387)
            
            //--TRIMMABLE-BOUNDARY-START(124556017683)
            static /*string */ get ContentException_LengthRuleSetConstraint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459563466771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded length is not valid under the requested encoding rules, the value may be valid under the BER encoding.";
            }
            //--TRIMMABLE-BOUNDARY-END(124556017683)
            
            //--TRIMMABLE-BOUNDARY-START(128850984979)
            static /*string */ get ContentException_LengthTooBig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468153401363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded length exceeds the maximum supported by this library (Int32.MaxValue).";
            }
            //--TRIMMABLE-BOUNDARY-END(128850984979)
            
            //--TRIMMABLE-BOUNDARY-START(133145952275)
            static /*string */ get ContentException_NamedBitListValueTooBig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476743335955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded named bit list value is larger than the value size of the '{0}' enum.";
            }
            //--TRIMMABLE-BOUNDARY-END(133145952275)
            
            //--TRIMMABLE-BOUNDARY-START(210455363603)
            static /*string */ FormatContentException_NamedBitListValueTooBig(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455363603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The encoded named bit list value is larger than the value size of the '{0}' enum.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(210455363603)
            
            //--TRIMMABLE-BOUNDARY-START(137440919571)
            static /*string */ get ContentException_OidTooBig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485333270547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded object identifier (OID) exceeds the limits supported by this library. Supported OIDs are limited to 64 arcs and each subidentifier is limited to a 128-bit value.";
            }
            //--TRIMMABLE-BOUNDARY-END(137440919571)
            
            //--TRIMMABLE-BOUNDARY-START(141735886867)
            static /*string */ get ContentException_PrimitiveEncodingRequired()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493923205139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded value uses a constructed encoding, which is invalid for '{0}' values.";
            }
            //--TRIMMABLE-BOUNDARY-END(141735886867)
            
            //--TRIMMABLE-BOUNDARY-START(214750330899)
            static /*string */ FormatContentException_PrimitiveEncodingRequired(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750330899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The encoded value uses a constructed encoding, which is invalid for '{0}' values.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(214750330899)
            
            //--TRIMMABLE-BOUNDARY-START(146030854163)
            static /*string */ get ContentException_SetOfNotSorted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502513139731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded set is not sorted as required by the current encoding rules. The value may be valid under the BER encoding, or you can ignore the sort validation by specifying skipSortValidation=true.";
            }
            //--TRIMMABLE-BOUNDARY-END(146030854163)
            
            //--TRIMMABLE-BOUNDARY-START(150325821459)
            static /*string */ get ContentException_TooMuchData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511103074323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The last expected value has been read, but the reader still has pending data. This value may be from a newer schema, or is corrupt.";
            }
            //--TRIMMABLE-BOUNDARY-END(150325821459)
            
            //--TRIMMABLE-BOUNDARY-START(154620788755)
            static /*string */ get ContentException_WrongTag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519693008915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The provided data is tagged with '{0}' class value '{1}', but it should have been '{2}' class value '{3}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(154620788755)
            
            //--TRIMMABLE-BOUNDARY-START(219045298195)
            static /*string */ FormatContentException_WrongTag(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045298195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$11("The provided data is tagged with '{0}' class value '{1}', but it should have been '{2}' class value '{3}'.", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ arg1, arg2, arg3, arg4 ]));
            }
            //--TRIMMABLE-BOUNDARY-END(219045298195)
            
            //--TRIMMABLE-BOUNDARY-START(566937649171)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(566937649171)
            
            //--TRIMMABLE-BOUNDARY-START(549757779987)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(549757779987);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(549757779987)
            
            //--TRIMMABLE-BOUNDARY-START(579822551059)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(579822551059);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sfa.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(579822551059)
            
            //--TRIMMABLE-BOUNDARY-START(541167845395)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541167845395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sfa.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(541167845395)
            
            //--TRIMMABLE-BOUNDARY-START(545462812691)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545462812691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sfa.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(545462812691)
            
            //--TRIMMABLE-BOUNDARY-START(163210723347)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210723347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(163210723347)
            
            //--TRIMMABLE-BOUNDARY-START(167505690643)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505690643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(167505690643)
            
            //--TRIMMABLE-BOUNDARY-START(171800657939)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800657939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(171800657939)
            
            //--TRIMMABLE-BOUNDARY-START(176095625235)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095625235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sfa.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(176095625235)
            
            //--TRIMMABLE-BOUNDARY-START(180390592531)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390592531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(180390592531)
            
            //--TRIMMABLE-BOUNDARY-START(184685559827)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685559827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(184685559827)
            
            //--TRIMMABLE-BOUNDARY-START(188980527123)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980527123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(188980527123)
            
            //--TRIMMABLE-BOUNDARY-START(193275494419)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275494419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sfa.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(193275494419)
            
            //--TRIMMABLE-BOUNDARY-START(4296933395)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(566937649171)
                    this.s_usingResourceKeys = $.$sfa.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(566937649171)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296933395)
            
            static $h = 1966099;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 1966099
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966099)
        
        
        //--TRIMMABLE-BOUNDARY-START(720915)
        $asm.$cls("$sfa.System.Formats.Asn1.AsnWriter", ($self) => class AsnWriter extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(322123268115)
            /*void */ WriteNamedBitList$1(/*Enum*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123268115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 3/*UniversalTagNumber.BitString*/);
                this.WriteNamedBitList$2(tag?.Clone() ?? null, $.$$.System.Object.GetType.call(value), value);
            }
            //--TRIMMABLE-BOUNDARY-END(322123268115)
            
            //--TRIMMABLE-BOUNDARY-START(326418235411)
            /*void */ WriteNamedBitList$4(TEnum, /*TEnum*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418235411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 3/*UniversalTagNumber.BitString*/);
                this.WriteNamedBitList$2(tag?.Clone() ?? null, TEnum.$type, value);
            }
            //--TRIMMABLE-BOUNDARY-END(326418235411)
            
            //--TRIMMABLE-BOUNDARY-START(330713202707)
            /*void */ WriteNamedBitList(/*BitArray*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713202707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 3/*UniversalTagNumber.BitString*/);
                this.WriteBitArray(value, tag?.Clone() ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(330713202707)
            
            //--TRIMMABLE-BOUNDARY-START(335008170003)
            /*void */ WriteNamedBitList$2(/*Asn1Tag?*/ tag, /*Type*/ tEnum, /*Enum*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008170003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let backingType = tEnum.GetEnumUnderlyingType();
                if (!tEnum.IsDefined($.$$.System.FlagsAttribute.$type, false))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_NamedBitListRequiresFlagsEnum, "tEnum");
                }
                /*ulong*/ let integralValue;
                if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.SByte.$type))
                {
                    integralValue = BigInt($.$cast($.$$.System.Convert.ToSByte$10(value), $.$$.System.Byte));
                }
                else if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.Int16.$type))
                {
                    integralValue = BigInt($.$cast($.$$.System.Convert.ToInt16$10(value), $.$$.System.UInt16));
                }
                else if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.Int32.$type))
                {
                    integralValue = BigInt(($.$$.System.Convert.ToInt32$10(value) >>> 0));
                }
                else if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.UInt64.$type))
                {
                    integralValue = $.$$.System.Convert.ToUInt64$10(value);
                }
                else 
                {
                    integralValue = $.$cast($.$$.System.Convert.ToInt64$10(value), $.$$.System.UInt64);
                }
                this.WriteNamedBitList$3(tag?.Clone() ?? null, integralValue);
            }
            //--TRIMMABLE-BOUNDARY-END(335008170003)
            
            //--TRIMMABLE-BOUNDARY-START(339303137299)
            /*void */ WriteNamedBitList$3(/*Asn1Tag?*/ tag, /*ulong*/ integralValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303137299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Span<byte>*/ let temp = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, $.$$.System.UInt64.$z, null);
                temp.Clear();
                /*int*/ let indexOfHighestSetBit = -1;
                for(/*int*/ let i = 0; integralValue !== 0n; integralValue >>= 1n, i++)
                {
                    if ((integralValue & 1n) !== 0n)
                    {
                        temp.get_Item($.trunc(i / 8)).$v |= $.$cast((128 >> (i % 8)), $.$$.System.Byte);
                        indexOfHighestSetBit = i;
                    }
                }
                if (indexOfHighestSetBit < 0)
                {
                    this.WriteBitString($.$$.System.ReadOnlySpan$$($.$$.System.Byte).Empty, 0, tag?.Clone() ?? null);
                }
                else 
                {
                    /*int*/ let byteLen = ((($.trunc(indexOfHighestSetBit / 8)) + 1) | 0);
                    /*int*/ let unusedBitCount = ((7 - (indexOfHighestSetBit % 8)) | 0);
                    this.WriteBitString($.$$.System.Span$$($.$$.System.Byte).op_Implicit(temp.Slice(0, byteLen)), unusedBitCount, tag?.Clone() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(339303137299)
            
            //--TRIMMABLE-BOUNDARY-START(201864183827)
            /*void */ WriteBitArray(/*BitArray*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864183827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.Count === 0)
                {
                    this.WriteBitString($.$$.System.ReadOnlySpan$$($.$$.System.Byte).Empty, 0, tag?.Clone() ?? null);
                    return;
                }
                /*int*/ let requiredBytes = $.trunc(($.$checked(value.Count + 7, 1)) / 8);
                /*int*/ let unusedBits = ((((requiredBytes * 8) | 0) - value.Count) | 0);
                /*byte[]*/ let rented = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(requiredBytes);
                value.CopyTo(rented, 0);
                /*Span<byte>*/ let valueSpan = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, rented, 0, requiredBytes);
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReverseBitsPerByte(valueSpan);
                this.WriteBitString($.$$.System.Span$$($.$$.System.Byte).op_Implicit(valueSpan), unusedBits, tag?.Clone() ?? null);
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, requiredBytes);
            }
            //--TRIMMABLE-BOUNDARY-END(201864183827)
            
            //--TRIMMABLE-BOUNDARY-START(223339020307)
            /*void */ WriteCharacterString$1(/*UniversalTagNumber*/ encodingType, /*string*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339020307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.WriteCharacterString(encodingType, $.$$.System.MemoryExtensions.AsSpan$4(value), tag?.Clone() ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(223339020307)
            
            //--TRIMMABLE-BOUNDARY-START(227633987603)
            /*void */ WriteCharacterString(/*UniversalTagNumber*/ encodingType, /*ReadOnlySpan<char>*/ str, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633987603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, encodingType);
                /*Text.Encoding*/ let encoding = $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.GetEncoding(encodingType);
                this.WriteCharacterStringCore(tag ?? new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$5(encodingType, false), encoding, str);
            }
            //--TRIMMABLE-BOUNDARY-END(227633987603)
            
            //--TRIMMABLE-BOUNDARY-START(231928954899)
            /*void */ WriteCharacterStringCore(/*Asn1Tag*/ tag, /*Text.Encoding*/ encoding, /*ReadOnlySpan<char>*/ str)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928954899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let size = encoding.GetByteCount$4(str);
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (size > 1000/*AsnReader.MaxCERSegmentSize*/)
                    {
                        this.WriteConstructedCerCharacterString(tag, encoding, str, size);
                        return;
                    }
                }
                this.WriteTag(tag.AsPrimitive());
                this.WriteLength(size);
                /*Span<byte>*/ let dest = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, this._offset, size);
                /*int*/ let written = encoding.GetBytes$5(str, dest);
                if (written !== size)
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`Encoding produced different answer for GetByteCount (${size}) and GetBytes (${written})`);
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                this._offset += size;
            }
            //--TRIMMABLE-BOUNDARY-END(231928954899)
            
            //--TRIMMABLE-BOUNDARY-START(240518889491)
            /*void */ WriteConstructedCerCharacterString(/*Asn1Tag*/ tag, /*Text.Encoding*/ encoding, /*ReadOnlySpan<char>*/ str, /*int*/ size)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518889491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(size > 1000/*AsnReader.MaxCERSegmentSize*/, "size > AsnReader.MaxCERSegmentSize");
                /*byte[]*/ let tmp = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(size);
                /*int*/ let written = encoding.GetBytes$5(str, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(tmp));
                if (written !== size)
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`Encoding produced different answer for GetByteCount (${size}) and GetBytes (${written})`);
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                this.WriteConstructedCerOctetString(tag, $.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, tmp, 0, size)));
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(tmp, size);
            }
            //--TRIMMABLE-BOUNDARY-END(240518889491)
            
            //--TRIMMABLE-BOUNDARY-START(347893071891)
            /*void */ WriteNull(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893071891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 5/*UniversalTagNumber.Null*/);
                this.WriteNullCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Null);
            }
            //--TRIMMABLE-BOUNDARY-END(347893071891)
            
            //--TRIMMABLE-BOUNDARY-START(352188039187)
            /*void */ WriteNullCore(/*Asn1Tag*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188039187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(0);
            }
            //--TRIMMABLE-BOUNDARY-END(352188039187)
            
            //--TRIMMABLE-BOUNDARY-START(214749085715)
            /*void */ WriteBoolean(/*bool*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749085715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 1/*UniversalTagNumber.Boolean*/);
                this.WriteBooleanCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Boolean, value);
            }
            //--TRIMMABLE-BOUNDARY-END(214749085715)
            
            //--TRIMMABLE-BOUNDARY-START(219044053011)
            /*void */ WriteBooleanCore(/*Asn1Tag*/ tag, /*bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044053011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(1);
                $.$$.System.Diagnostics.Debug.Assert$2(this._offset < this._buffer.length, "_offset < _buffer.Length");
                $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast((value ? 255 : 0), $.$$.System.Byte), this._offset);
                this._offset++;
            }
            //--TRIMMABLE-BOUNDARY-END(219044053011)
            
            //--TRIMMABLE-BOUNDARY-START(154619543571)
            /*Scope */ PushSequence(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619543571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 16/*UniversalTagNumber.Sequence*/);
                return this.PushSequenceCore((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Sequence);
            }
            //--TRIMMABLE-BOUNDARY-END(154619543571)
            
            //--TRIMMABLE-BOUNDARY-START(128849739795)
            /*void */ PopSequence(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849739795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 16/*UniversalTagNumber.Sequence*/);
                this.PopSequenceCore((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Sequence);
            }
            //--TRIMMABLE-BOUNDARY-END(128849739795)
            
            //--TRIMMABLE-BOUNDARY-START(158914510867)
            /*Scope */ PushSequenceCore(/*Asn1Tag*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914510867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(tag.IsConstructed, "tag.IsConstructed");
                return this.PushTag(tag, 16/*UniversalTagNumber.Sequence*/);
            }
            //--TRIMMABLE-BOUNDARY-END(158914510867)
            
            //--TRIMMABLE-BOUNDARY-START(133144707091)
            /*void */ PopSequenceCore(/*Asn1Tag*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144707091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(tag.IsConstructed, "tag.IsConstructed");
                this.PopTag(tag, 16/*UniversalTagNumber.Sequence*/, false);
            }
            //--TRIMMABLE-BOUNDARY-END(133144707091)
            
            //--TRIMMABLE-BOUNDARY-START(163209478163)
            /*Scope */ PushSetOf(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209478163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 17/*UniversalTagNumber.SetOf*/);
                return this.PushSetOfCore((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.SetOf);
            }
            //--TRIMMABLE-BOUNDARY-END(163209478163)
            
            //--TRIMMABLE-BOUNDARY-START(137439674387)
            /*void */ PopSetOf(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439674387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 17/*UniversalTagNumber.SetOf*/);
                this.PopSetOfCore((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.SetOf);
            }
            //--TRIMMABLE-BOUNDARY-END(137439674387)
            
            //--TRIMMABLE-BOUNDARY-START(167504445459)
            /*Scope */ PushSetOfCore(/*Asn1Tag*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504445459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(tag.IsConstructed, "tag.IsConstructed");
                return this.PushTag(tag, 17/*UniversalTagNumber.SetOf*/);
            }
            //--TRIMMABLE-BOUNDARY-END(167504445459)
            
            //--TRIMMABLE-BOUNDARY-START(141734641683)
            /*void */ PopSetOfCore(/*Asn1Tag*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734641683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(tag.IsConstructed, "tag.IsConstructed");
                /*bool*/ let sortContents = this.RuleSet === 1/*AsnEncodingRules.CER*/ || this.RuleSet === 2/*AsnEncodingRules.DER*/;
                this.PopTag(tag, 17/*UniversalTagNumber.SetOf*/, sortContents);
            }
            //--TRIMMABLE-BOUNDARY-END(141734641683)
            
            //--TRIMMABLE-BOUNDARY-START(356483006483)
            /*void */ WriteObjectIdentifier$1(/*string*/ oidValue, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483006483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(oidValue, "oidValue");
                this.WriteObjectIdentifier($.$$.System.MemoryExtensions.AsSpan$4(oidValue), tag?.Clone() ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(356483006483)
            
            //--TRIMMABLE-BOUNDARY-START(360777973779)
            /*void */ WriteObjectIdentifier(/*ReadOnlySpan<char>*/ oidValue, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777973779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 6/*UniversalTagNumber.ObjectIdentifier*/);
                /*ReadOnlySpan<byte>*/ let wellKnownContents = $.$sfa.System.Formats.Asn1.WellKnownOids.GetContents(oidValue);
                if (!wellKnownContents.IsEmpty)
                {
                    this.WriteTag((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ObjectIdentifier);
                    this.WriteLength(wellKnownContents.Length);
                    wellKnownContents.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset));
                    this._offset += wellKnownContents.Length;
                    return;
                }
                this.WriteObjectIdentifierCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ObjectIdentifier, oidValue);
            }
            //--TRIMMABLE-BOUNDARY-END(360777973779)
            
            //--TRIMMABLE-BOUNDARY-START(365072941075)
            /*void */ WriteObjectIdentifierCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<char>*/ oidValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072941075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (oidValue.Length < 3)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                }
                if (oidValue.get_Item(1).$v !== /*.*/ 46)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                }
                /*byte[]*/ let tmp = $.$sfa.System.Security.Cryptography.CryptoPool.Rent($.trunc(oidValue.Length / 2));
                /*int*/ let tmpOffset = 0;
                try
                {
                    /*int*/ let firstComponent = (() =>
                    {
                        let $switch1 = oidValue.get_Item(0).$v;
                        if ($switch1 === /*0*/ 48)
                        {
                            return 0;
                        }
                        if ($switch1 === /*1*/ 49)
                        {
                            return 1;
                        }
                        if ($switch1 === /*2*/ 50)
                        {
                            return 2;
                        }
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                    })();
                    /*ReadOnlySpan<char>*/ let remaining = oidValue.Slice$1(2);
                    /*BigInteger*/ let subIdentifier = $.$sfa.System.Formats.Asn1.AsnWriter.ParseSubIdentifier($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Char), () => remaining, ($v) => remaining = $v, null));
                    if (firstComponent <= 1 && $.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual$2(subIdentifier, 40n))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                    }
                    subIdentifier = $.$srn.System.Numerics.BigInteger.op_Addition(subIdentifier, $.$srn.System.Numerics.BigInteger.op_Implicit$4(((40 * firstComponent) | 0)));
                    /*int*/ let localLen = $.$sfa.System.Formats.Asn1.AsnWriter.EncodeSubIdentifier($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, tmp, tmpOffset), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Numerics.BigInteger, () => subIdentifier, ($v) => subIdentifier = $v, null));
                    tmpOffset += localLen;
                    while(!remaining.IsEmpty)
                    {
                        subIdentifier = $.$sfa.System.Formats.Asn1.AsnWriter.ParseSubIdentifier($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Char), () => remaining, ($v) => remaining = $v, null));
                        localLen = $.$sfa.System.Formats.Asn1.AsnWriter.EncodeSubIdentifier($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, tmp, tmpOffset), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Numerics.BigInteger, () => subIdentifier, ($v) => subIdentifier = $v, null));
                        tmpOffset += localLen;
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                    this.WriteTag(tag);
                    this.WriteLength(tmpOffset);
                    $.$$.System.Buffer.BlockCopy(tmp, 0, this._buffer, this._offset, tmpOffset);
                    this._offset += tmpOffset;
                }
                finally
                {
                    {
                        $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(tmp, tmpOffset);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(365072941075)
            
            //--TRIMMABLE-BOUNDARY-START(120259805203)
            static /*BigInteger */ ParseSubIdentifier(/*ref ReadOnlySpan<char>*/ oidValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259805203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let endIndex = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, oidValue.$v, /*.*/ 46);
                if (endIndex === -1)
                {
                    endIndex = oidValue.$v.Length;
                }
                else if (endIndex === 0 || endIndex === ((oidValue.$v.Length - 1) | 0))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                }
                /*BigInteger*/ let value = $.$srn.System.Numerics.BigInteger.Zero;
                for(/*int*/ let position = 0; position < endIndex; position++)
                {
                    if (position > 0 && $.$srn.System.Numerics.BigInteger.op_Equality$2(value, 0n))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                    }
                    value = $.$srn.System.Numerics.BigInteger.op_Multiply(value, $.$srn.System.Numerics.BigInteger.op_Implicit$4(10));
                    value = $.$srn.System.Numerics.BigInteger.op_Addition(value, $.$srn.System.Numerics.BigInteger.op_Implicit$4($.$sfa.System.Formats.Asn1.AsnWriter.AtoI(oidValue.$v.get_Item(position).$v)));
                }
                oidValue.$v = oidValue.$v.Slice$1($.$$.System.Math.Min$4(oidValue.$v.Length, ((endIndex + 1) | 0)));
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(120259805203)
            
            //--TRIMMABLE-BOUNDARY-START(38655426579)
            static /*int */ AtoI(/*char*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655426579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (c >= /*0*/ 48 && c <= /*9*/ 57)
                {
                    return c - /*0*/ 48;
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
            }
            //--TRIMMABLE-BOUNDARY-END(38655426579)
            
            //--TRIMMABLE-BOUNDARY-START(94490001427)
            static /*int */ EncodeSubIdentifier(/*Span<byte>*/ dest, /*ref BigInteger*/ subIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490001427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(dest.Length > 0, "dest.Length > 0");
                if (subIdentifier.$v.IsZero)
                {
                    dest.get_Item(0).$v = 0;
                    return 1;
                }
                /*BigInteger*/ let unencoded = subIdentifier.$v;
                /*int*/ let idx = 0;
                do
                {
                    /*BigInteger*/ let cur = $.$srn.System.Numerics.BigInteger.op_BitwiseAnd(unencoded, $.$srn.System.Numerics.BigInteger.op_Implicit$4(127));
                    /*byte*/ let curByte = $.$srn.System.Numerics.BigInteger.op_Explicit(cur);
                    if ($.$srn.System.Numerics.BigInteger.op_Inequality$4(subIdentifier.$v, unencoded))
                    {
                        curByte |= 128;
                    }
                    unencoded = $.$srn.System.Numerics.BigInteger.op_RightShift(unencoded, 7);
                    dest.get_Item(idx).$v = curByte;
                    idx++;
                }
                while($.$srn.System.Numerics.BigInteger.op_Inequality$4(unencoded, $.$srn.System.Numerics.BigInteger.Zero));
                $.$$.System.MemoryExtensions.Reverse($.$$.System.Byte, dest.Slice(0, idx));
                return idx;
            }
            //--TRIMMABLE-BOUNDARY-END(94490001427)
            
            //--TRIMMABLE-BOUNDARY-START(270583660563)
            /*void */ WriteGeneralizedTime(/*DateTimeOffset*/ value, /*bool*/ omitFractionalSeconds, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583660563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 24/*UniversalTagNumber.GeneralizedTime*/);
                this.WriteGeneralizedTimeCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.GeneralizedTime, value, omitFractionalSeconds);
            }
            //--TRIMMABLE-BOUNDARY-END(270583660563)
            
            //--TRIMMABLE-BOUNDARY-START(274878627859)
            /*void */ WriteGeneralizedTimeCore(/*Asn1Tag*/ tag, /*DateTimeOffset*/ value, /*bool*/ omitFractionalSeconds)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878627859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*DateTimeOffset*/ let normalized = value.ToUniversalTime();
                $.$$.System.Diagnostics.Debug.Assert$2(normalized.Year <= 9999, "DateTimeOffset guards against this internally");
                /*scoped Span<byte>*/ let fraction = new ($.$$.System.Span$$($.$$.System.Byte))();
                if (!omitFractionalSeconds)
                {
                    /*long*/ let floatingTicks = normalized.Ticks % 10000000n;
                    if (floatingTicks !== 0n)
                    {
                        fraction = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 9, null);
                        /*decimal*/ let decimalTicks = $.$$.System.Decimal.op_Implicit$4(floatingTicks);
                        decimalTicks = $.$$.System.Decimal.op_Division(decimalTicks, $.$$.System.Decimal.op_Implicit$4(10000000n));
                        /*int*/ let bytesWritten;
                        if (!$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$4(decimalTicks, fraction, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32), new $.$$.System.Buffers.StandardFormat().$ctor$3(/*G*/ 71, 255)))
                        {
                            $.$$.System.Diagnostics.Debug.Fail$1(`Utf8Formatter.TryFormat could not format ${floatingTicks} / TicksPerSecond`);
                            throw new $.$$.System.InvalidOperationException().$ctor$9();
                        }
                        $.$$.System.Diagnostics.Debug.Assert$4(bytesWritten > 2, `${bytesWritten} should be > 2`);
                        $.$$.System.Diagnostics.Debug.Assert$2(fraction.get_Item(0).$v === /*0*/ 48, "fraction[0] == (byte)'0'");
                        $.$$.System.Diagnostics.Debug.Assert$2(fraction.get_Item(1).$v === /*.*/ 46, "fraction[1] == (byte)'.'");
                        fraction = fraction.Slice(1, ((bytesWritten - 1) | 0));
                    }
                }
                /*int*/ let IntegerPortionLength = ((((((((((4 + 2) | 0) + 2) | 0) + 2) | 0) + 2) | 0) + 2) | 0);
                /*int*/ let totalLength = ((((IntegerPortionLength + 1) | 0) + fraction.Length) | 0);
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(totalLength);
                /*int*/ let year = normalized.Year;
                /*int*/ let month = normalized.Month;
                /*int*/ let day = normalized.Day;
                /*int*/ let hour = normalized.Hour;
                /*int*/ let minute = normalized.Minute;
                /*int*/ let second = normalized.Second;
                /*Span<byte>*/ let baseSpan = $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset);
                /*StandardFormat*/ let d4 = new $.$$.System.Buffers.StandardFormat().$ctor$3(/*D*/ 68, 4);
                /*StandardFormat*/ let d2 = new $.$$.System.Buffers.StandardFormat().$ctor$3(/*D*/ 68, 2);
                if (!$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(year, baseSpan.Slice(0, 4), $.$discardRef(), d4) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(month, baseSpan.Slice(4, 2), $.$discardRef(), d2) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(day, baseSpan.Slice(6, 2), $.$discardRef(), d2) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(hour, baseSpan.Slice(8, 2), $.$discardRef(), d2) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(minute, baseSpan.Slice(10, 2), $.$discardRef(), d2) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(second, baseSpan.Slice(12, 2), $.$discardRef(), d2))
                {
                    $.$$.System.Diagnostics.Debug.Fail$1((() =>
                    {
                        var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendLiteral("Utf8Formatter.TryFormat failed to build components of ");
                        $handler.AppendFormatted($.$box(normalized, $.$$.System.DateTimeOffset), null, "O");
                        return $handler.ToStringAndClear                ();
                    })());
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                this._offset += IntegerPortionLength;
                fraction.CopyTo(baseSpan.Slice$1(IntegerPortionLength));
                this._offset += fraction.Length;
                $.$$.System.Array.$WriteT1.call(this._buffer, /*Z*/ 90, this._offset);
                this._offset++;
            }
            //--TRIMMABLE-BOUNDARY-END(274878627859)
            
            //--TRIMMABLE-BOUNDARY-START(382252810259)
            /*void */ WriteUtcTime$1(/*DateTimeOffset*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252810259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 23/*UniversalTagNumber.UtcTime*/);
                this.WriteUtcTimeCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.UtcTime, value);
            }
            //--TRIMMABLE-BOUNDARY-END(382252810259)
            
            //--TRIMMABLE-BOUNDARY-START(386547777555)
            /*void */ WriteUtcTime(/*DateTimeOffset*/ value, /*int*/ twoDigitYearMax, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547777555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 23/*UniversalTagNumber.UtcTime*/);
                value = value.ToUniversalTime();
                if (value.Year > twoDigitYearMax || value.Year <= ((twoDigitYearMax - 100) | 0))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("value");
                }
                this.WriteUtcTimeCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.UtcTime, value);
            }
            //--TRIMMABLE-BOUNDARY-END(386547777555)
            
            //--TRIMMABLE-BOUNDARY-START(390842744851)
            /*void */ WriteUtcTimeCore(/*Asn1Tag*/ tag, /*DateTimeOffset*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842744851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                /*int*/ let UtcTimeValueLength = 13;
                this.WriteLength(UtcTimeValueLength);
                /*DateTimeOffset*/ let normalized = value.ToUniversalTime();
                /*int*/ let year = normalized.Year;
                /*int*/ let month = normalized.Month;
                /*int*/ let day = normalized.Day;
                /*int*/ let hour = normalized.Hour;
                /*int*/ let minute = normalized.Minute;
                /*int*/ let second = normalized.Second;
                /*Span<byte>*/ let baseSpan = $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset);
                /*StandardFormat*/ let format = new $.$$.System.Buffers.StandardFormat().$ctor$3(/*D*/ 68, 2);
                if (!$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(year % 100, baseSpan.Slice(0, 2), $.$discardRef(), format) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(month, baseSpan.Slice(2, 2), $.$discardRef(), format) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(day, baseSpan.Slice(4, 2), $.$discardRef(), format) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(hour, baseSpan.Slice(6, 2), $.$discardRef(), format) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(minute, baseSpan.Slice(8, 2), $.$discardRef(), format) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(second, baseSpan.Slice(10, 2), $.$discardRef(), format))
                {
                    $.$$.System.Diagnostics.Debug.Fail$1((() =>
                    {
                        var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendLiteral("Utf8Formatter.TryFormat failed to build components of ");
                        $handler.AppendFormatted($.$box(normalized, $.$$.System.DateTimeOffset), null, "O");
                        return $handler.ToStringAndClear                ();
                    })());
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                $.$$.System.Array.$WriteT1.call(this._buffer, /*Z*/ 90, ((this._offset + 12) | 0));
                this._offset += UtcTimeValueLength;
            }
            //--TRIMMABLE-BOUNDARY-END(390842744851)
            
            //--TRIMMABLE-BOUNDARY-START(150324576275)
            /*Scope */ PushOctetString(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324576275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 4/*UniversalTagNumber.OctetString*/);
                return this.PushTag((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedOctetString, 4/*UniversalTagNumber.OctetString*/);
            }
            //--TRIMMABLE-BOUNDARY-END(150324576275)
            
            //--TRIMMABLE-BOUNDARY-START(124554772499)
            /*void */ PopOctetString(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554772499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 4/*UniversalTagNumber.OctetString*/);
                this.PopTag((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedOctetString, 4/*UniversalTagNumber.OctetString*/, false);
            }
            //--TRIMMABLE-BOUNDARY-END(124554772499)
            
            //--TRIMMABLE-BOUNDARY-START(369367908371)
            /*void */ WriteOctetString(/*ReadOnlySpan<byte>*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367908371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 4/*UniversalTagNumber.OctetString*/);
                this.WriteOctetStringCore(tag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString, value);
            }
            //--TRIMMABLE-BOUNDARY-END(369367908371)
            
            //--TRIMMABLE-BOUNDARY-START(373662875667)
            /*void */ WriteOctetStringCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ octetString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662875667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (octetString.Length > 1000/*AsnReader.MaxCERSegmentSize*/)
                    {
                        this.WriteConstructedCerOctetString(tag, octetString);
                        return;
                    }
                }
                this.WriteTag(tag.AsPrimitive());
                this.WriteLength(octetString.Length);
                octetString.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset));
                this._offset += octetString.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(373662875667)
            
            //--TRIMMABLE-BOUNDARY-START(244813856787)
            /*void */ WriteConstructedCerOctetString(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ payload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813856787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let MaxCERSegmentSize = 1000/*AsnReader.MaxCERSegmentSize*/;
                $.$$.System.Diagnostics.Debug.Assert$2(payload.Length > MaxCERSegmentSize, "payload.Length > MaxCERSegmentSize");
                this.WriteTag(tag.AsConstructed());
                this.WriteLength(-1);
                /*int*/ let lastSegmentSize;
                /*int*/ let fullSegments = $.$$.System.Math.DivRem$2(payload.Length, MaxCERSegmentSize, $.$ref(() => lastSegmentSize, ($v) => lastSegmentSize = $v, $.$$.System.Int32));
                /*int*/ let FullSegmentEncodedSize = 1004;
                $.$$.System.Diagnostics.Debug.Assert$2(FullSegmentEncodedSize === ((((((1 + 1) | 0) + MaxCERSegmentSize) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)) | 0), "FullSegmentEncodedSize == 1 + 1 + MaxCERSegmentSize + GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)");
                /*int*/ let remainingEncodedSize;
                if (lastSegmentSize === 0)
                {
                    remainingEncodedSize = 0;
                }
                else 
                {
                    remainingEncodedSize = ((((2 + lastSegmentSize) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(lastSegmentSize)) | 0);
                }
                /*int*/ let expectedSize = ((((((fullSegments * FullSegmentEncodedSize) | 0) + remainingEncodedSize) | 0) + 2) | 0);
                this.EnsureWriteCapacity(expectedSize);
                /*byte[]*/ let ensureNoExtraCopy = this._buffer;
                /*int*/ let savedOffset = this._offset;
                /*ReadOnlySpan<byte>*/ let remainingData = payload;
                /*Span<byte>*/ let dest;
                /*Asn1Tag*/ let primitiveOctetString = $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString;
                while(remainingData.Length > MaxCERSegmentSize)
                {
                    this.WriteTag(primitiveOctetString);
                    this.WriteLength(MaxCERSegmentSize);
                    dest = $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset);
                    remainingData.Slice(0, MaxCERSegmentSize).CopyTo(dest);
                    this._offset += MaxCERSegmentSize;
                    remainingData = remainingData.Slice$1(MaxCERSegmentSize);
                }
                this.WriteTag(primitiveOctetString);
                this.WriteLength(remainingData.Length);
                dest = $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset);
                remainingData.CopyTo(dest);
                this._offset += remainingData.Length;
                this.WriteEndOfContents();
                $.$$.System.Diagnostics.Debug.Assert$4(((this._offset - savedOffset) | 0) === expectedSize, `expected size was ${expectedSize}, actual was ${((this._offset - savedOffset) | 0)}`);
                $.$$.System.Diagnostics.Debug.Assert$2(this._buffer === ensureNoExtraCopy, `_buffer was replaced during ${"WriteConstructedCerOctetString"}`);
            }
            //--TRIMMABLE-BOUNDARY-END(244813856787)
            
            //--TRIMMABLE-BOUNDARY-START(257698758675)
            /*void */ WriteEnumeratedValue(/*Enum*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698758675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.WriteEnumeratedValue$1((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Enumerated, $.$$.System.Object.GetType.call(value), value);
            }
            //--TRIMMABLE-BOUNDARY-END(257698758675)
            
            //--TRIMMABLE-BOUNDARY-START(261993725971)
            /*void */ WriteEnumeratedValue$2(TEnum, /*TEnum*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993725971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteEnumeratedValue$1((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Enumerated, TEnum.$type, $.$box(value, TEnum));
            }
            //--TRIMMABLE-BOUNDARY-END(261993725971)
            
            //--TRIMMABLE-BOUNDARY-START(266288693267)
            /*void */ WriteEnumeratedValue$1(/*Asn1Tag*/ tag, /*Type*/ tEnum, /*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288693267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag, 10/*UniversalTagNumber.Enumerated*/);
                /*Type*/ let backingType = tEnum.GetEnumUnderlyingType();
                if (tEnum.IsDefined($.$$.System.FlagsAttribute.$type, false))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_EnumeratedValueRequiresNonFlagsEnum, "tEnum");
                }
                if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.UInt64.$type))
                {
                    /*ulong*/ let numericValue = $.$$.System.Convert.ToUInt64$10(value);
                    this.WriteNonNegativeIntegerCore(tag, numericValue);
                }
                else 
                {
                    /*long*/ let numericValue = $.$$.System.Convert.ToInt64$10(value);
                    this.WriteIntegerCore(tag, numericValue);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266288693267)
            
            //--TRIMMABLE-BOUNDARY-START(279173595155)
            /*void */ WriteInteger(/*long*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173595155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            //--TRIMMABLE-BOUNDARY-END(279173595155)
            
            //--TRIMMABLE-BOUNDARY-START(283468562451)
            /*void */ WriteInteger$2(/*ulong*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468562451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 2/*UniversalTagNumber.Integer*/);
                this.WriteNonNegativeIntegerCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            //--TRIMMABLE-BOUNDARY-END(283468562451)
            
            //--TRIMMABLE-BOUNDARY-START(287763529747)
            /*void */ WriteInteger$3(/*BigInteger*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763529747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerCore$2((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            //--TRIMMABLE-BOUNDARY-END(287763529747)
            
            //--TRIMMABLE-BOUNDARY-START(292058497043)
            /*void */ WriteInteger$1(/*ReadOnlySpan<byte>*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058497043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerCore$1((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            //--TRIMMABLE-BOUNDARY-END(292058497043)
            
            //--TRIMMABLE-BOUNDARY-START(309238366227)
            /*void */ WriteIntegerUnsigned(/*ReadOnlySpan<byte>*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238366227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerUnsignedCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            //--TRIMMABLE-BOUNDARY-END(309238366227)
            
            //--TRIMMABLE-BOUNDARY-START(296353464339)
            /*void */ WriteIntegerCore(/*Asn1Tag*/ tag, /*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353464339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value >= 0n)
                {
                    this.WriteNonNegativeIntegerCore(tag, $.$cast(value, $.$$.System.UInt64));
                    return;
                }
                /*int*/ let valueLength;
                if (value >= BigInt(-128/*sbyte.MinValue*/))
                {
                    valueLength = 1;
                }
                else if (value >= BigInt(-32768/*short.MinValue*/))
                {
                    valueLength = 2;
                }
                else if (value >= $.$cast(18446744073701163008n, $.$$.System.Int64))
                {
                    valueLength = 3;
                }
                else if (value >= BigInt(-2147483648/*int.MinValue*/))
                {
                    valueLength = 4;
                }
                else if (value >= $.$cast(18446743523953737728n, $.$$.System.Int64))
                {
                    valueLength = 5;
                }
                else if (value >= $.$cast(18446603336221196288n, $.$$.System.Int64))
                {
                    valueLength = 6;
                }
                else if (value >= $.$cast(18410715276690587648n, $.$$.System.Int64))
                {
                    valueLength = 7;
                }
                else 
                {
                    valueLength = 8;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(valueLength);
                /*long*/ let remaining = value;
                /*int*/ let idx = ((((this._offset + valueLength) | 0) - 1) | 0);
                do
                {
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(remaining, $.$$.System.Byte), idx);
                    remaining >>= 8n;
                    idx--;
                }
                while(idx >= this._offset);
                if (valueLength > 1)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Array.$ReadT1.call(this._buffer, this._offset) !== 255 || $.$$.System.Array.$ReadT1.call(this._buffer, ((this._offset + 1) | 0)) < 128, "_buffer[_offset] != 0xFF || _buffer[_offset + 1] < 0x80");
                }
                this._offset += valueLength;
            }
            //--TRIMMABLE-BOUNDARY-END(296353464339)
            
            //--TRIMMABLE-BOUNDARY-START(343598104595)
            /*void */ WriteNonNegativeIntegerCore(/*Asn1Tag*/ tag, /*ulong*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343598104595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let valueLength;
                if (value < 128n)
                {
                    valueLength = 1;
                }
                else if (value < 32768n)
                {
                    valueLength = 2;
                }
                else if (value < 8388608n)
                {
                    valueLength = 3;
                }
                else if (value < 2147483648n)
                {
                    valueLength = 4;
                }
                else if (value < 549755813888n)
                {
                    valueLength = 5;
                }
                else if (value < 140737488355328n)
                {
                    valueLength = 6;
                }
                else if (value < 36028797018963968n)
                {
                    valueLength = 7;
                }
                else if (value < 9223372036854775808n)
                {
                    valueLength = 8;
                }
                else 
                {
                    valueLength = 9;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(valueLength);
                /*ulong*/ let remaining = value;
                /*int*/ let idx = ((((this._offset + valueLength) | 0) - 1) | 0);
                do
                {
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(remaining, $.$$.System.Byte), idx);
                    remaining >>= 8n;
                    idx--;
                }
                while(idx >= this._offset);
                if (valueLength > 1)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Array.$ReadT1.call(this._buffer, this._offset) !== 0 || $.$$.System.Array.$ReadT1.call(this._buffer, ((this._offset + 1) | 0)) > 127, "_buffer[_offset] != 0 || _buffer[_offset + 1] > 0x7F");
                }
                this._offset += valueLength;
            }
            //--TRIMMABLE-BOUNDARY-END(343598104595)
            
            //--TRIMMABLE-BOUNDARY-START(313533333523)
            /*void */ WriteIntegerUnsignedCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533333523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.IsEmpty)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_IntegerCannotBeEmpty, "value");
                }
                if (value.Length > 1 && value.get_Item(0).$v === 0 && value.get_Item(1).$v < 128)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_IntegerRedundantByte, "value");
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                if (value.get_Item(0).$v >= 128)
                {
                    this.WriteLength($.$checked(value.Length + 1, 1));
                    $.$$.System.Array.$WriteT1.call(this._buffer, 0, this._offset);
                    this._offset++;
                }
                else 
                {
                    this.WriteLength(value.Length);
                }
                value.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset));
                this._offset += value.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(313533333523)
            
            //--TRIMMABLE-BOUNDARY-START(300648431635)
            /*void */ WriteIntegerCore$1(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648431635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.IsEmpty)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_IntegerCannotBeEmpty, "value");
                }
                /*ushort*/ let bigEndianValue;
                if ($.$$.System.Buffers.Binary.BinaryPrimitives.TryReadUInt16BigEndian(value, $.$ref(() => bigEndianValue, ($v) => bigEndianValue = $v, $.$$.System.UInt16)))
                {
                    /*ushort*/ let RedundancyMask = 65408;
                    /*ushort*/ let masked = $.$cast((bigEndianValue & RedundancyMask), $.$$.System.UInt16);
                    if (masked === 0 || masked === RedundancyMask)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_IntegerRedundantByte, "value");
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(value.Length);
                value.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset));
                this._offset += value.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(300648431635)
            
            //--TRIMMABLE-BOUNDARY-START(304943398931)
            /*void */ WriteIntegerCore$2(/*Asn1Tag*/ tag, /*BigInteger*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943398931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(value.GetByteCount(false));
                /*int*/ let bytesWritten;
                value.TryWriteBytes($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32), false, true);
                this._offset += bytesWritten;
            }
            //--TRIMMABLE-BOUNDARY-END(304943398931)
            
            //--TRIMMABLE-BOUNDARY-START(4295688211)
            /*byte[]*/ _buffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295688211)
            
            //--TRIMMABLE-BOUNDARY-START(17180590099)
            /*int*/ _offset = 0;
            //--TRIMMABLE-BOUNDARY-END(17180590099)
            
            //--TRIMMABLE-BOUNDARY-START(12885622803)
            /*Stack<StackFrame>?*/ _nestingStack = null;
            //--TRIMMABLE-BOUNDARY-END(12885622803)
            
            //--TRIMMABLE-BOUNDARY-START(8590655507)
            /*int*/ _encodeDepth = 0;
            //--TRIMMABLE-BOUNDARY-END(8590655507)
            
            //--TRIMMABLE-BOUNDARY-START(180389347347)
            /*AsnEncodingRules*/ RuleSet = 0;
            //--TRIMMABLE-BOUNDARY-END(180389347347)
            
            //--TRIMMABLE-BOUNDARY-START(21475557395)
            $ctor$2(/*AsnEncodingRules*/ ruleSet)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557395);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (ruleSet !== 0/*AsnEncodingRules.BER*/ && ruleSet !== 1/*AsnEncodingRules.CER*/ && ruleSet !== 2/*AsnEncodingRules.DER*/)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("ruleSet");
                    }
                    this.RuleSet = ruleSet;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557395)
            
            //--TRIMMABLE-BOUNDARY-START(25770524691)
            $ctor$1(/*AsnEncodingRules*/ ruleSet, /*int*/ initialCapacity)
            {
                this.$ctor$2(ruleSet);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770524691);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (initialCapacity < 0)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("initialCapacity", $.$sfa.System.SR.ArgumentOutOfRange_NeedNonNegNum);
                    }
                    if (initialCapacity > 0)
                    {
                        this._buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [initialCapacity], null);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770524691)
            
            //--TRIMMABLE-BOUNDARY-START(176094380051)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094380051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._encodeDepth !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_ModifyingWhileEncoding);
                }
                if (this._offset > 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._buffer !== null, "_buffer != null");
                    $.$$.System.Array.Clear(this._buffer, 0, this._offset);
                    this._offset = 0;
                    this._nestingStack?.Clear();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176094380051)
            
            //--TRIMMABLE-BOUNDARY-START(111669870611)
            /*int */ GetEncodedLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669870611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_EncodeUnbalancedStack);
                }
                return this._offset;
            }
            //--TRIMMABLE-BOUNDARY-END(111669870611)
            
            //--TRIMMABLE-BOUNDARY-START(197569216531)
            /*bool */ TryEncode(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569216531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_EncodeUnbalancedStack);
                }
                if (destination.Length < this._offset)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                if (this._offset === 0)
                {
                    bytesWritten.$v = 0;
                    return true;
                }
                bytesWritten.$v = this._offset;
                $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, 0, this._offset).CopyTo(destination);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(197569216531)
            
            //--TRIMMABLE-BOUNDARY-START(60130263059)
            /*int */ Encode$1(/*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let bytesWritten;
                if (!this.TryEncode(destination, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_DestinationTooShort, "destination");
                }
                $.$$.System.Diagnostics.Debug.Assert$2(bytesWritten === this._offset, "bytesWritten == _offset");
                return bytesWritten;
            }
            //--TRIMMABLE-BOUNDARY-END(60130263059)
            
            //--TRIMMABLE-BOUNDARY-START(64425230355)
            /*byte[] */ Encode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_EncodeUnbalancedStack);
                }
                if (this._offset === 0)
                {
                    return $.$$.System.Array.Empty($.$$.System.Byte);
                }
                return $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, 0, this._offset).ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(64425230355)
            
            //--TRIMMABLE-BOUNDARY-START(68720197651)
            /*TReturn */ Encode$2(TReturn, /*Func<ReadOnlySpan<byte>, TReturn>*/ encodeCallback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encodeCallback, "encodeCallback");
                this._encodeDepth = $.$checked(this._encodeDepth + 1, 1);
                try
                {
                    /*ReadOnlySpan<byte>*/ let encoded = this.EncodeAsSpan();
                    return encodeCallback.Invoke(encoded);
                }
                finally
                {
                    {
                        this._encodeDepth--;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720197651)
            
            //--TRIMMABLE-BOUNDARY-START(73015164947)
            /*TReturn */ Encode$3(TState, TReturn, /*TState*/ state, /*Func<TState, ReadOnlySpan<byte>, TReturn>*/ encodeCallback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015164947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encodeCallback, "encodeCallback");
                this._encodeDepth = $.$checked(this._encodeDepth + 1, 1);
                try
                {
                    /*ReadOnlySpan<byte>*/ let encoded = this.EncodeAsSpan();
                    return encodeCallback.Invoke(state, encoded);
                }
                finally
                {
                    {
                        this._encodeDepth--;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015164947)
            
            //--TRIMMABLE-BOUNDARY-START(77310132243)
            /*void */ Encode$4(TState, /*TState*/ state, /*Action<TState, ReadOnlySpan<byte>>*/ encodeCallback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310132243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encodeCallback, "encodeCallback");
                this._encodeDepth = $.$checked(this._encodeDepth + 1, 1);
                try
                {
                    /*ReadOnlySpan<byte>*/ let encoded = this.EncodeAsSpan();
                    encodeCallback.Invoke(state, encoded);
                }
                finally
                {
                    {
                        this._encodeDepth--;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310132243)
            
            //--TRIMMABLE-BOUNDARY-START(81605099539)
            /*ReadOnlySpan<byte> */ EncodeAsSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_EncodeUnbalancedStack);
                }
                if (this._offset === 0)
                {
                    return $.$$.System.ReadOnlySpan$$($.$$.System.Byte).Empty;
                }
                return new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$3(this._buffer, 0, this._offset);
            }
            //--TRIMMABLE-BOUNDARY-END(81605099539)
            
            //--TRIMMABLE-BOUNDARY-START(85900066835)
            /*bool */ EncodedValueEquals(/*ReadOnlySpan<byte>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900066835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.MemoryExtensions.SequenceEqual$1($.$$.System.Byte, this.EncodeAsSpan(), other);
            }
            //--TRIMMABLE-BOUNDARY-END(85900066835)
            
            //--TRIMMABLE-BOUNDARY-START(90195034131)
            /*bool */ EncodedValueEquals$1(/*AsnWriter*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                return $.$$.System.MemoryExtensions.SequenceEqual$1($.$$.System.Byte, this.EncodeAsSpan(), other.EncodeAsSpan());
            }
            //--TRIMMABLE-BOUNDARY-END(90195034131)
            
            //--TRIMMABLE-BOUNDARY-START(98784968723)
            /*void */ EnsureWriteCapacity(/*int*/ pendingCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (pendingCount < 0)
                {
                    throw new $.$$.System.OverflowException().$ctor$13();
                }
                if (this._encodeDepth !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_ModifyingWhileEncoding);
                }
                if (this._buffer === null || ((this._buffer.length - this._offset) | 0) < pendingCount)
                {
                    /*int*/ let BlockSize = 1024;
                    /*int*/ let blocks = $.trunc($.$checked($.$checked(this._offset + pendingCount, 1) + ($.$checked(BlockSize - 1, 1)), 1) / BlockSize);
                    /*byte[]?*/ let oldBytes = this._buffer;
                    $.$$.System.Array.Resize($.$$.System.Byte, $.$ref(() => this._buffer, ($v) => this._buffer = $v, $.$typeArray($.$$.System.Byte)), ((BlockSize * blocks) | 0));
                    /*byte[]?*/ let __ca1__;
                    if ((__ca1__ = oldBytes) !== null)
                    {
                        $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, __ca1__, 0, this._offset).Clear();
                    }
                    $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset).Fill(202);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784968723)
            
            //--TRIMMABLE-BOUNDARY-START(377957842963)
            /*void */ WriteTag(/*Asn1Tag*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957842963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let spaceRequired = tag.CalculateEncodedSize();
                this.EnsureWriteCapacity(spaceRequired);
                /*int*/ let written;
                if (!tag.TryEncode($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, this._offset, spaceRequired), $.$ref(() => written, ($v) => written = $v, $.$$.System.Int32)) || written !== spaceRequired)
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`TryWrite failed or written was wrong value (${written} vs ${spaceRequired})`);
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                this._offset += spaceRequired;
            }
            //--TRIMMABLE-BOUNDARY-END(377957842963)
            
            //--TRIMMABLE-BOUNDARY-START(317828300819)
            /*void */ WriteLength(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828300819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte*/ let MultiByteMarker = 128;
                $.$$.System.Diagnostics.Debug.Assert$2(length >= -1, "length >= -1");
                if (length === -1)
                {
                    this.EnsureWriteCapacity(1);
                    $.$$.System.Array.$WriteT1.call(this._buffer, MultiByteMarker, this._offset);
                    this._offset++;
                    return;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(length >= 0, "length >= 0");
                if (length < MultiByteMarker)
                {
                    this.EnsureWriteCapacity(((1 + length) | 0));
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(length, $.$$.System.Byte), this._offset);
                    this._offset++;
                    return;
                }
                /*int*/ let lengthLength = $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(length);
                this.EnsureWriteCapacity(((((lengthLength + 1) | 0) + length) | 0));
                $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast((MultiByteMarker | lengthLength), $.$$.System.Byte), this._offset);
                /*int*/ let idx = ((this._offset + lengthLength) | 0);
                /*int*/ let remaining = length;
                do
                {
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(remaining, $.$$.System.Byte), idx);
                    remaining >>= 8;
                    idx--;
                }
                while(remaining > 0);
                $.$$.System.Diagnostics.Debug.Assert$2(idx === this._offset, "idx == _offset");
                this._offset += ((lengthLength + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(317828300819)
            
            //--TRIMMABLE-BOUNDARY-START(115964837907)
            static /*int */ GetEncodedLengthSubsequentByteCount(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964837907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (length < 0)
                {
                    throw new $.$$.System.OverflowException().$ctor$13();
                }
                if (length <= 127)
                {
                    return 0;
                }
                if (length <= 255/*byte.MaxValue*/)
                {
                    return 1;
                }
                if (length <= 65535/*ushort.MaxValue*/)
                {
                    return 2;
                }
                if (length <= 16777215)
                {
                    return 3;
                }
                return 4;
            }
            //--TRIMMABLE-BOUNDARY-END(115964837907)
            
            //--TRIMMABLE-BOUNDARY-START(51540328467)
            /*void */ CopyTo(/*AsnWriter*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(destination, "destination");
                try
                {
                    destination.WriteEncodedValue(this.EncodeAsSpan());
                }
                catch(e)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$11(new $.$$.System.InvalidOperationException().$ctor$9().Message, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540328467)
            
            //--TRIMMABLE-BOUNDARY-START(249108824083)
            /*void */ WriteEncodedValue(/*ReadOnlySpan<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108824083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let consumed;
                /*bool*/ let read = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadEncodedValue(value, this.RuleSet, $.$discardRef(), $.$discardRef(), $.$discardRef(), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (!read || consumed !== value.Length)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_WriteEncodedValue_OneValueAtATime, "value");
                }
                this.EnsureWriteCapacity(value.Length);
                value.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset));
                this._offset += value.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(249108824083)
            
            //--TRIMMABLE-BOUNDARY-START(253403791379)
            /*void */ WriteEndOfContents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403791379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureWriteCapacity(2);
                $.$$.System.Array.$WriteT1.call(this._buffer, 0, this._offset++);
                $.$$.System.Array.$WriteT1.call(this._buffer, 0, this._offset++);
            }
            //--TRIMMABLE-BOUNDARY-END(253403791379)
            
            //--TRIMMABLE-BOUNDARY-START(171799412755)
            /*Scope */ PushTag(/*Asn1Tag*/ tag, /*UniversalTagNumber*/ tagType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799412755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._nestingStack ??= new ($.$sc.System.Collections.Generic.Stack$$($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame))().$ctor$1();
                $.$$.System.Diagnostics.Debug.Assert$2(tag.IsConstructed, "tag.IsConstructed");
                this.WriteTag(tag);
                this._nestingStack.Push(new $.$sfa.System.Formats.Asn1.AsnWriter.StackFrame().$ctor$3(tag, this._offset, tagType));
                this.WriteLength(-1);
                return new $.$sfa.System.Formats.Asn1.AsnWriter.Scope().$ctor$3(this);
            }
            //--TRIMMABLE-BOUNDARY-END(171799412755)
            
            //--TRIMMABLE-BOUNDARY-START(146029608979)
            /*void */ PopTag(/*Asn1Tag*/ tag, /*UniversalTagNumber*/ tagType, /*bool*/ sortContents)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029608979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._nestingStack === null || this._nestingStack.Count === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_PopWrongTag);
                }
                const { Item1: stackTag, Item2: lenOffset, Item3: stackTagType } = this._nestingStack.Peek();
                $.$$.System.Diagnostics.Debug.Assert$2(tag.IsConstructed, "tag.IsConstructed");
                if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Inequality(stackTag, tag) || stackTagType !== tagType)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_PopWrongTag);
                }
                this._nestingStack.Pop();
                if (sortContents)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(tagType === 17/*UniversalTagNumber.SetOf*/, "tagType == UniversalTagNumber.SetOf");
                    $.$sfa.System.Formats.Asn1.AsnWriter.SortContents(this._buffer, ((lenOffset + 1) | 0), this._offset);
                }
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/ && tagType !== 4/*UniversalTagNumber.OctetString*/)
                {
                    this.WriteEndOfContents();
                    return;
                }
                /*int*/ let containedLength = ((((this._offset - 1) | 0) - lenOffset) | 0);
                $.$$.System.Diagnostics.Debug.Assert$2(containedLength >= 0, "containedLength >= 0");
                /*int*/ let start = ((lenOffset + 1) | 0);
                if (tagType === 4/*UniversalTagNumber.OctetString*/)
                {
                    if (this.RuleSet !== 1/*AsnEncodingRules.CER*/ || containedLength <= 1000/*AsnDecoder.MaxCERSegmentSize*/)
                    {
                        /*int*/ let tagLen = tag.CalculateEncodedSize();
                        tag.AsPrimitive().Encode($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, ((lenOffset - tagLen) | 0), tagLen));
                    }
                    else 
                    {
                        /*int*/ let lastSegmentSize;
                        /*int*/ let fullSegments = $.$$.System.Math.DivRem$2(containedLength, 1000/*AsnDecoder.MaxCERSegmentSize*/, $.$ref(() => lastSegmentSize, ($v) => lastSegmentSize = $v, $.$$.System.Int32));
                        /*int*/ let requiredPadding = ((((((4 * fullSegments) | 0) + 2) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(lastSegmentSize)) | 0);
                        this.EnsureWriteCapacity(((requiredPadding + 2) | 0));
                        /*ReadOnlySpan<byte>*/ let src = $.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, start, containedLength));
                        /*Span<byte>*/ let dest = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, ((start + requiredPadding) | 0), containedLength);
                        src.CopyTo(dest);
                        /*int*/ let expectedEnd = ((((((start + containedLength) | 0) + requiredPadding) | 0) + 2) | 0);
                        this._offset = ((lenOffset - tag.CalculateEncodedSize()) | 0);
                        this.WriteConstructedCerOctetString(tag, $.$$.System.Span$$($.$$.System.Byte).op_Implicit(dest));
                        $.$$.System.Diagnostics.Debug.Assert$2(this._offset === expectedEnd, "_offset == expectedEnd");
                        return;
                    }
                }
                /*int*/ let shiftSize = $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(containedLength);
                if (shiftSize === 0)
                {
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(containedLength, $.$$.System.Byte), lenOffset);
                    return;
                }
                this.EnsureWriteCapacity(shiftSize);
                $.$$.System.Buffer.BlockCopy(this._buffer, start, this._buffer, ((start + shiftSize) | 0), containedLength);
                /*int*/ let tmp = this._offset;
                this._offset = lenOffset;
                this.WriteLength(containedLength);
                $.$$.System.Diagnostics.Debug.Assert$2(((((this._offset - lenOffset) | 0) - 1) | 0) === shiftSize, "_offset - lenOffset - 1 == shiftSize");
                this._offset = ((tmp + shiftSize) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(146029608979)
            
            //--TRIMMABLE-BOUNDARY-START(188979281939)
            static /*void */ SortContents(/*byte[]*/ buffer, /*int*/ start, /*int*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979281939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(buffer !== null, "buffer != null");
                $.$$.System.Diagnostics.Debug.Assert$2(end >= start, "end >= start");
                /*int*/ let len = ((end - start) | 0);
                if (len === 0)
                {
                    return;
                }
                /*var*/ let reader = new $.$sfa.System.Formats.Asn1.AsnReader().$ctor$1(new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))().$ctor$4(buffer, start, len), 0/*AsnEncodingRules.BER*/, new $.$sfa.System.Formats.Asn1.AsnReaderOptions());
                /*int*/ let pos = start;
                /*ReadOnlyMemory<byte>*/ let encoded = reader.ReadEncodedValue();
                if (!reader.HasData)
                {
                    return;
                }
                /*List<(int, int)>*/ let positions = new ($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32)))().$ctor$1();
                positions.Add(new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(pos, encoded.Length));
                pos += encoded.Length;
                do
                {
                    encoded = reader.ReadEncodedValue();
                    positions.Add(new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(pos, encoded.Length));
                    pos += encoded.Length;
                }
                while(reader.HasData);
                $.$$.System.Diagnostics.Debug.Assert$2(pos === end, "pos == end");
                /*var*/ let comparer = new $.$sfa.System.Formats.Asn1.AsnWriter.ArrayIndexSetOfValueComparer().$ctor$1(buffer);
                positions.Sort$1(comparer);
                /*byte[]*/ let tmp = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(len);
                pos = 0;
                var $en2 = positions.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var $t1 = $en2.Current;
                    /*int*/ let offset = $t1.Item1;
                    /*int*/ let length = $t1.Item2;
                    {
                        $.$$.System.Buffer.BlockCopy(buffer, offset, tmp, pos, length);
                        pos += length;
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(pos === len, "pos == len");
                $.$$.System.Buffer.BlockCopy(tmp, 0, buffer, start, len);
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(tmp, len);
            }
            //--TRIMMABLE-BOUNDARY-END(188979281939)
            
            //--TRIMMABLE-BOUNDARY-START(42950393875)
            static /*void */ CheckUniversalTag(/*Asn1Tag?*/ tag, /*UniversalTagNumber*/ universalTagNumber)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tag !== null)
                {
                    /*Asn1Tag*/ let value = $.$$.System.Nullable$$($.$sfa.System.Formats.Asn1.Asn1Tag).Value$get.call(tag);
                    if (value.TagClass === 0/*TagClass.Universal*/ && value.TagValue !== universalTagNumber)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_UniversalValueIsFixed, "tag");
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950393875)
            
            //--TRIMMABLE-BOUNDARY-START(786451)
            static $_ArrayIndexSetOfValueComparer;
            static get ArrayIndexSetOfValueComparer()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnWriter;
                return $cls.$_ArrayIndexSetOfValueComparer ??= $asm.$ncls("$sfa.System.Formats.Asn1.AsnWriter.ArrayIndexSetOfValueComparer", ($self) => class ArrayIndexSetOfValueComparer extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295753747)
                    /*byte[]*/ _data = null;
                    //--TRIMMABLE-BOUNDARY-END(4295753747)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590721043)
                    $ctor$1(/*byte[]*/ data)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590721043);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._data = data;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590721043)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885688339)
                    /*int */ Compare(/*(int, int)*/ x, /*(int, int)*/ y)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885688339);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        const { Item1: xOffset, Item2: xLength } = x.Clone();
                        const { Item1: yOffset, Item2: yLength } = y.Clone();
                        /*int*/ let value = $.$sfa.System.Formats.Asn1.SetOfValueComparer.Instance.Compare(new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))().$ctor$4(this._data, xOffset, xLength), new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))().$ctor$4(this._data, yOffset, yLength));
                        if (value === 0)
                        {
                            return ((xOffset - yOffset) | 0);
                        }
                        return value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885688339)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354277377)
                    //Generated interface implemetation for System.Collections.Generic.IComparer<(int, int)>.Compare((int, int), (int, int))
                    System$Collections$Generic$IComparer$$$Compare()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354277377);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Compare(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354277377)
                    
                    static $h = 786451;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885688339),
    {
      "r": 655361,
      "p": [
        {
          "n": "x",
          "p": $.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32).$h
        },
        {
          "n": "y",
          "p": $.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32).$h
        }
      ],
      "n": "Compare",
      "d": 786451,
      "h": 12885688339,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688339)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295753747),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_data",
      "d": 786451,
      "h": 4295753747,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753747)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590721043),
    {
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786451,
      "h": 8590721043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590721043)
  ],
  "i": [$.$$.System.Collections.Generic.IComparer$$($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32)).$h
  ],
  "d": 720915,
  "h": 786451
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IComparer$$($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32)) ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnWriter.ArrayIndexSetOfValueComparer`; }
                }, $cls, ($v) => $cls.$_ArrayIndexSetOfValueComparer = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786451)
            
            //--TRIMMABLE-BOUNDARY-START(917523)
            static $_StackFrame;
            static get StackFrame()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnWriter;
                return $cls.$_StackFrame ??= $asm.$nstr("$sfa.System.Formats.Asn1.AsnWriter.StackFrame", ($self) => class StackFrame extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(85900263443)
                    /*Asn1Tag*/ Tag;
                    //--TRIMMABLE-BOUNDARY-END(85900263443)
                    
                    //--TRIMMABLE-BOUNDARY-START(73015361555)
                    /*int*/ Offset = 0;
                    //--TRIMMABLE-BOUNDARY-END(73015361555)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720394259)
                    /*UniversalTagNumber*/ ItemType = 0;
                    //--TRIMMABLE-BOUNDARY-END(68720394259)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295884819)
                    $ctor$3(/*Asn1Tag*/ tag, /*int*/ offset, /*UniversalTagNumber*/ itemType)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295884819);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Tag = tag;
                            this.Offset = offset;
                            this.ItemType = itemType;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295884819)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770721299)
                    /*void */ Deconstruct(/*out Asn1Tag*/ tag, /*out int*/ offset, /*out UniversalTagNumber*/ itemType)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770721299);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        tag.$v = this.Tag;
                        offset.$v = this.Offset;
                        itemType.$v = this.ItemType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770721299)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065688595)
                    /*bool */ Equals$2(/*StackFrame*/ other)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065688595);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Tag.Equals$2(other.Tag) && this.Offset === other.Offset && this.ItemType === other.ItemType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065688595)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 34360655891, 34359869441)
                    static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34360655891);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let other;
                            return $.$is(obj, $.$sfa.System.Formats.Asn1.AsnWriter.StackFrame, { set $v(v){ other = v; } }) && this.Equals$2(other);
                        }
                    }
                    //Static convention instance redirect
                    /*bool */ Equals$1() { return $.$sfa.System.Formats.Asn1.AsnWriter.StackFrame.Equals$1.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 34360655891, 34359869441)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 64425426963, 184683724801)
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64425426963);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$$.System.ValueTuple$$$$($.$sfa.System.Formats.Asn1.Asn1Tag, $.$$.System.Int32, $.$sfa.System.Formats.Asn1.UniversalTagNumber).GetHashCode.call(new ($.$$.System.ValueTuple$$$$($.$sfa.System.Formats.Asn1.Asn1Tag, $.$$.System.Int32, $.$sfa.System.Formats.Asn1.UniversalTagNumber))().$ctor$3(this.Tag, this.Offset, this.ItemType));
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$sfa.System.Formats.Asn1.AsnWriter.StackFrame.GetHashCode.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 64425426963, 184683724801)
                    
                    //--TRIMMABLE-BOUNDARY-START(77310328851)
                    static /*bool */ op_Equality(/*StackFrame*/ left, /*StackFrame*/ right)
                    {
                        {
                            return left.Equals$2(right);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(77310328851)
                    
                    //--TRIMMABLE-BOUNDARY-START(81605296147)
                    static /*bool */ op_Inequality(/*StackFrame*/ left, /*StackFrame*/ right)
                    {
                        {
                            return !left.Equals$2(right);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(81605296147)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385210369)
                    //Generated interface implemetation for System.IEquatable<System.Formats.Asn1.AsnWriter.StackFrame>.Equals(System.Formats.Asn1.AsnWriter.StackFrame)
                    System$IEquatable$$$Equals()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385210369);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Equals$2(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385210369)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Tag = this.Tag.Clone();
                        copy.Offset = this.Offset;
                        copy.ItemType = this.ItemType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Tag = $.$default($.$sfa.System.Formats.Asn1.Asn1Tag);
                    }
                    static $h = 917523;
                    static $z = 13;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(85900263443),
    {
      "p": 65555,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130459667,
        "f": 50331649
      },
      "n": "Tag",
      "d": 917523,
      "h": 85900263443,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900263443),
//--TRIMMABLE-BOUNDARY-START(73015361555),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540525075,
        "f": 50331649
      },
      "n": "Offset",
      "d": 917523,
      "h": 73015361555,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015361555),
//--TRIMMABLE-BOUNDARY-START(68720394259),
    {
      "p": 1572883,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950590483,
        "f": 50331649
      },
      "n": "ItemType",
      "d": 917523,
      "h": 68720394259,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720394259)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770721299),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555,
          "f": 2
        },
        {
          "n": "offset",
          "p": 655361,
          "f": 2
        },
        {
          "n": "itemType",
          "p": 1572883,
          "f": 2
        }
      ],
      "n": "Deconstruct",
      "d": 917523,
      "h": 25770721299,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770721299),
//--TRIMMABLE-BOUNDARY-START(30065688595),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 917523
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 917523,
      "h": 30065688595,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065688595),
//--TRIMMABLE-BOUNDARY-START(ALL, 34360655891, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 917523,
      "h": 34360655891,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 34360655891, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 64425426963, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 917523,
      "h": 64425426963,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 64425426963, 184683724801)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884819),
    {
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "itemType",
          "p": 1572883
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917523,
      "h": 4295884819,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295884819),
//--TRIMMABLE-BOUNDARY-START(8590852115),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917523,
      "h": 8590852115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590852115)
  ],
  "i": [$.$$.System.IEquatable$$($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame).$h
  ],
  "d": 720915,
  "h": 917523
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame) ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnWriter.StackFrame`; }
                }, $cls, ($v) => $cls.$_StackFrame = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917523)
            
            //--TRIMMABLE-BOUNDARY-START(851987)
            static $_Scope;
            static get Scope()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnWriter;
                return $cls.$_Scope ??= $asm.$nstr("$sfa.System.Formats.Asn1.AsnWriter.Scope", ($self) => class Scope extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885753875)
                    /*AsnWriter*/  get _writer() { return this.$getField(0, 4); }
                    /*AsnWriter*/  set _writer(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885753875)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590786579)
                    /*StackFrame*/  get _frame() { return this.$getField(4, 13); }
                    /*StackFrame*/  set _frame(value) { this.$setField(4, 13, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590786579)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295819283)
                    /*int*/  get _depth() { return this.$getField(17, 4); }
                    /*int*/  set _depth(value) { this.$setField(17, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295819283)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180721171)
                    $ctor$3(/*AsnWriter*/ writer)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180721171);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.System.Diagnostics.Debug.Assert$2(writer._nestingStack !== null, "writer._nestingStack != null");
                            this._writer = writer;
                            this._frame = this._writer._nestingStack.Peek();
                            this._depth = this._writer._nestingStack.Count;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180721171)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770655763)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770655763);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(this._writer === null || this._writer._nestingStack !== null, "_writer == null || _writer._nestingStack != null");
                        if (this._writer === null || this._writer._nestingStack.Count === 0)
                        {
                            return;
                        }
                        if ($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame.op_Equality(this._writer._nestingStack.Peek(), this._frame))
                        {
                            let $switch1 = this._frame.ItemType;
                            switch($switch1)
                            {
                                case 17/*UniversalTagNumber.SetOf*/:
                                this._writer.PopSetOf(this._frame.Tag);
                                break;
                                case 16/*UniversalTagNumber.Sequence*/:
                                this._writer.PopSequence(this._frame.Tag);
                                break;
                                case 4/*UniversalTagNumber.OctetString*/:
                                this._writer.PopOctetString(this._frame.Tag);
                                break;
                                default:
                                $.$$.System.Diagnostics.Debug.Fail$1(`No handler for ${this._frame.ItemType}`);
                                throw new $.$$.System.InvalidOperationException().$ctor$9();
                            }
                        }
                        else if (this._writer._nestingStack.Count > this._depth && this._writer._nestingStack.Contains(this._frame))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_PopWrongTag);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770655763)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385144833)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385144833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385144833)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._writer = this._writer;
                        copy._frame = this._frame.Clone();
                        copy._depth = this._depth;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(12885753875)
                        this._writer = null;
                        //--TRIMMABLE-BOUNDARY-END(12885753875)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590786579)
                        this._frame = $.$default($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame);
                        //--TRIMMABLE-BOUNDARY-END(8590786579)
                        
                        //--TRIMMABLE-BOUNDARY-START(4295819283)
                        this._depth = 0;
                        //--TRIMMABLE-BOUNDARY-END(4295819283)
                        
                    }
                    static $h = 851987;
                    static $z = 21;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770655763),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 851987,
      "h": 25770655763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770655763)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885753875),
    {
      "t": 720915,
      "n": "_writer",
      "d": 851987,
      "h": 12885753875,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885753875),
//--TRIMMABLE-BOUNDARY-START(8590786579),
    {
      "t": 917523,
      "n": "_frame",
      "d": 851987,
      "h": 8590786579,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590786579),
//--TRIMMABLE-BOUNDARY-START(4295819283),
    {
      "t": 655361,
      "n": "_depth",
      "d": 851987,
      "h": 4295819283,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819283)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180721171),
    {
      "p": [
        {
          "n": "writer",
          "p": 720915
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 851987,
      "h": 17180721171,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180721171),
//--TRIMMABLE-BOUNDARY-START(21475688467),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 851987,
      "h": 21475688467,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475688467)
  ],
  "i": [90177537
  ],
  "d": 720915,
  "h": 851987
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnWriter.Scope`; }
                }, $cls, ($v) => $cls.$_Scope = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(851987)
            
            //--TRIMMABLE-BOUNDARY-START(206159151123)
            /*void */ WriteBitString(/*ReadOnlySpan<byte>*/ value, /*int*/ unusedBitCount, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159151123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 3/*UniversalTagNumber.BitString*/);
                this.WriteBitStringCore(tag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString, value, unusedBitCount);
            }
            //--TRIMMABLE-BOUNDARY-END(206159151123)
            
            //--TRIMMABLE-BOUNDARY-START(210454118419)
            /*void */ WriteBitStringCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ bitString, /*int*/ unusedBitCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454118419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (unusedBitCount < 0 || unusedBitCount > 7)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("unusedBitCount", $.$box(unusedBitCount, $.$$.System.Int32), $.$sfa.System.SR.Argument_UnusedBitCountRange);
                }
                if (bitString.Length === 0 && unusedBitCount !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_UnusedBitCountMustBeZero, "unusedBitCount");
                }
                /*byte*/ let lastByte = bitString.IsEmpty ? 0 : bitString.get_Item(((bitString.Length - 1) | 0)).$v;
                if (!$.$sfa.System.Formats.Asn1.AsnWriter.CheckValidLastByte(lastByte, unusedBitCount))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_UnusedBitWasSet, "unusedBitCount");
                }
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (bitString.Length >= 1000/*AsnReader.MaxCERSegmentSize*/)
                    {
                        this.WriteConstructedCerBitString(tag, bitString, unusedBitCount);
                        return;
                    }
                }
                this.WriteTag(tag.AsPrimitive());
                this.WriteLength(((bitString.Length + 1) | 0));
                $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(unusedBitCount, $.$$.System.Byte), this._offset);
                this._offset++;
                bitString.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset));
                this._offset += bitString.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(210454118419)
            
            //--TRIMMABLE-BOUNDARY-START(47245361171)
            static /*bool */ CheckValidLastByte(/*byte*/ lastByte, /*int*/ unusedBitCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let mask = (((1 << unusedBitCount) - 1) | 0);
                return ((lastByte & mask) === 0);
            }
            //--TRIMMABLE-BOUNDARY-END(47245361171)
            
            //--TRIMMABLE-BOUNDARY-START(55835295763)
            static /*int */ DetermineCerBitStringTotalLength(/*Asn1Tag*/ tag, /*int*/ contentLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let MaxCERSegmentSize = 1000/*AsnReader.MaxCERSegmentSize*/;
                /*int*/ let MaxCERContentSize = ((MaxCERSegmentSize - 1) | 0);
                $.$$.System.Diagnostics.Debug.Assert$2(contentLength > MaxCERContentSize, "contentLength > MaxCERContentSize");
                /*int*/ let lastContentSize;
                /*int*/ let fullSegments = $.$$.System.Math.DivRem$2(contentLength, MaxCERContentSize, $.$ref(() => lastContentSize, ($v) => lastContentSize = $v, $.$$.System.Int32));
                /*int*/ let FullSegmentEncodedSize = 1004;
                $.$$.System.Diagnostics.Debug.Assert$2(FullSegmentEncodedSize === ((((((1 + 1) | 0) + MaxCERSegmentSize) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)) | 0), "FullSegmentEncodedSize == 1 + 1 + MaxCERSegmentSize + GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)");
                /*int*/ let remainingEncodedSize;
                if (lastContentSize === 0)
                {
                    remainingEncodedSize = 0;
                }
                else 
                {
                    remainingEncodedSize = ((((3 + lastContentSize) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(lastContentSize)) | 0);
                }
                return ((((((((fullSegments * FullSegmentEncodedSize) | 0) + remainingEncodedSize) | 0) + 3) | 0) + tag.CalculateEncodedSize()) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(55835295763)
            
            //--TRIMMABLE-BOUNDARY-START(236223922195)
            /*void */ WriteConstructedCerBitString(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ payload, /*int*/ unusedBitCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223922195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let MaxCERSegmentSize = 1000/*AsnReader.MaxCERSegmentSize*/;
                /*int*/ let MaxCERContentSize = ((MaxCERSegmentSize - 1) | 0);
                $.$$.System.Diagnostics.Debug.Assert$2(payload.Length > MaxCERContentSize, "payload.Length > MaxCERContentSize");
                /*int*/ let expectedSize = $.$sfa.System.Formats.Asn1.AsnWriter.DetermineCerBitStringTotalLength(tag, payload.Length);
                this.EnsureWriteCapacity(expectedSize);
                /*int*/ let savedOffset = this._offset;
                this.WriteTag(tag.AsConstructed());
                this.WriteLength(-1);
                /*byte[]*/ let ensureNoExtraCopy = this._buffer;
                /*ReadOnlySpan<byte>*/ let remainingData = payload;
                /*Span<byte>*/ let dest;
                /*Asn1Tag*/ let primitiveBitString = $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString;
                while(remainingData.Length > MaxCERContentSize)
                {
                    this.WriteTag(primitiveBitString);
                    this.WriteLength(MaxCERSegmentSize);
                    $.$$.System.Array.$WriteT1.call(this._buffer, 0, this._offset);
                    this._offset++;
                    dest = $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset);
                    remainingData.Slice(0, MaxCERContentSize).CopyTo(dest);
                    remainingData = remainingData.Slice$1(MaxCERContentSize);
                    this._offset += MaxCERContentSize;
                }
                this.WriteTag(primitiveBitString);
                this.WriteLength(((remainingData.Length + 1) | 0));
                $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(unusedBitCount, $.$$.System.Byte), this._offset);
                this._offset++;
                dest = $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset);
                remainingData.CopyTo(dest);
                this._offset += remainingData.Length;
                this.WriteEndOfContents();
                $.$$.System.Diagnostics.Debug.Assert$4(((this._offset - savedOffset) | 0) === expectedSize, `expected size was ${expectedSize}, actual was ${((this._offset - savedOffset) | 0)}`);
                $.$$.System.Diagnostics.Debug.Assert$2(this._buffer === ensureNoExtraCopy, `_buffer was replaced during ${"WriteConstructedCerBitString"}`);
            }
            //--TRIMMABLE-BOUNDARY-END(236223922195)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295688211)
                this._buffer = null;
                //--TRIMMABLE-BOUNDARY-END(4295688211)
                
            }
            static $h = 720915;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(180389347347),
    {
      "p": 524307,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374903315,
        "f": 50331649
      },
      "n": "RuleSet",
      "d": 720915,
      "h": 180389347347,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180389347347)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(322123268115),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1048577
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteNamedBitList",
      "o": "@$1",
      "d": 720915,
      "h": 322123268115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(322123268115),
//--TRIMMABLE-BOUNDARY-START(326418235411),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (TEnum) => TEnum.$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "g": [
        "TEnum"
      ],
      "n": "WriteNamedBitList",
      "o": "@$4",
      "d": 720915,
      "h": 326418235411,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(326418235411),
//--TRIMMABLE-BOUNDARY-START(330713202707),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 55181313
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteNamedBitList",
      "d": 720915,
      "h": 330713202707,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(330713202707),
//--TRIMMABLE-BOUNDARY-START(335008170003),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h
        },
        {
          "n": "tEnum",
          "p": 187629569
        },
        {
          "n": "value",
          "p": 1048577
        }
      ],
      "n": "WriteNamedBitList",
      "o": "@$2",
      "d": 720915,
      "h": 335008170003,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(335008170003),
//--TRIMMABLE-BOUNDARY-START(339303137299),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h
        },
        {
          "n": "integralValue",
          "p": 983041
        }
      ],
      "n": "WriteNamedBitList",
      "o": "@$3",
      "d": 720915,
      "h": 339303137299,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(339303137299),
//--TRIMMABLE-BOUNDARY-START(201864183827),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 55181313
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h
        }
      ],
      "n": "WriteBitArray",
      "d": 720915,
      "h": 201864183827,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(201864183827),
//--TRIMMABLE-BOUNDARY-START(223339020307),
    {
      "r": 65537,
      "p": [
        {
          "n": "encodingType",
          "p": 1572883
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteCharacterString",
      "o": "@$1",
      "d": 720915,
      "h": 223339020307,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223339020307),
//--TRIMMABLE-BOUNDARY-START(227633987603),
    {
      "r": 65537,
      "p": [
        {
          "n": "encodingType",
          "p": 1572883
        },
        {
          "n": "str",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteCharacterString",
      "d": 720915,
      "h": 227633987603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(227633987603),
//--TRIMMABLE-BOUNDARY-START(231928954899),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "str",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "WriteCharacterStringCore",
      "d": 720915,
      "h": 231928954899,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(231928954899),
//--TRIMMABLE-BOUNDARY-START(240518889491),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "str",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "size",
          "p": 655361
        }
      ],
      "n": "WriteConstructedCerCharacterString",
      "d": 720915,
      "h": 240518889491,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(240518889491),
//--TRIMMABLE-BOUNDARY-START(347893071891),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteNull",
      "d": 720915,
      "h": 347893071891,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(347893071891),
//--TRIMMABLE-BOUNDARY-START(352188039187),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        }
      ],
      "n": "WriteNullCore",
      "d": 720915,
      "h": 352188039187,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(352188039187),
//--TRIMMABLE-BOUNDARY-START(214749085715),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 262145
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteBoolean",
      "d": 720915,
      "h": 214749085715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214749085715),
//--TRIMMABLE-BOUNDARY-START(219044053011),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "WriteBooleanCore",
      "d": 720915,
      "h": 219044053011,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(219044053011),
//--TRIMMABLE-BOUNDARY-START(154619543571),
    {
      "r": 851987,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "PushSequence",
      "d": 720915,
      "h": 154619543571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154619543571),
//--TRIMMABLE-BOUNDARY-START(128849739795),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "PopSequence",
      "d": 720915,
      "h": 128849739795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128849739795),
//--TRIMMABLE-BOUNDARY-START(158914510867),
    {
      "r": 851987,
      "p": [
        {
          "n": "tag",
          "p": 65555
        }
      ],
      "n": "PushSequenceCore",
      "d": 720915,
      "h": 158914510867,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158914510867),
//--TRIMMABLE-BOUNDARY-START(133144707091),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        }
      ],
      "n": "PopSequenceCore",
      "d": 720915,
      "h": 133144707091,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133144707091),
//--TRIMMABLE-BOUNDARY-START(163209478163),
    {
      "r": 851987,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "PushSetOf",
      "d": 720915,
      "h": 163209478163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209478163),
//--TRIMMABLE-BOUNDARY-START(137439674387),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "PopSetOf",
      "d": 720915,
      "h": 137439674387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439674387),
//--TRIMMABLE-BOUNDARY-START(167504445459),
    {
      "r": 851987,
      "p": [
        {
          "n": "tag",
          "p": 65555
        }
      ],
      "n": "PushSetOfCore",
      "d": 720915,
      "h": 167504445459,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167504445459),
//--TRIMMABLE-BOUNDARY-START(141734641683),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        }
      ],
      "n": "PopSetOfCore",
      "d": 720915,
      "h": 141734641683,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141734641683),
//--TRIMMABLE-BOUNDARY-START(356483006483),
    {
      "r": 65537,
      "p": [
        {
          "n": "oidValue",
          "p": 1310721
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteObjectIdentifier",
      "o": "@$1",
      "d": 720915,
      "h": 356483006483,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(356483006483),
//--TRIMMABLE-BOUNDARY-START(360777973779),
    {
      "r": 65537,
      "p": [
        {
          "n": "oidValue",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteObjectIdentifier",
      "d": 720915,
      "h": 360777973779,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(360777973779),
//--TRIMMABLE-BOUNDARY-START(365072941075),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "oidValue",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "WriteObjectIdentifierCore",
      "d": 720915,
      "h": 365072941075,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(365072941075),
//--TRIMMABLE-BOUNDARY-START(120259805203),
    {
      "r": 786438,
      "p": [
        {
          "n": "oidValue",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
          "f": 4
        }
      ],
      "n": "ParseSubIdentifier",
      "d": 720915,
      "h": 120259805203,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120259805203),
//--TRIMMABLE-BOUNDARY-START(38655426579),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "AtoI",
      "d": 720915,
      "h": 38655426579,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38655426579),
//--TRIMMABLE-BOUNDARY-START(94490001427),
    {
      "r": 655361,
      "p": [
        {
          "n": "dest",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "subIdentifier",
          "p": 786438,
          "f": 4
        }
      ],
      "n": "EncodeSubIdentifier",
      "d": 720915,
      "h": 94490001427,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94490001427),
//--TRIMMABLE-BOUNDARY-START(270583660563),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 65339393
        },
        {
          "n": "omitFractionalSeconds",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteGeneralizedTime",
      "d": 720915,
      "h": 270583660563,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(270583660563),
//--TRIMMABLE-BOUNDARY-START(274878627859),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": 65339393
        },
        {
          "n": "omitFractionalSeconds",
          "p": 262145
        }
      ],
      "n": "WriteGeneralizedTimeCore",
      "d": 720915,
      "h": 274878627859,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(274878627859),
//--TRIMMABLE-BOUNDARY-START(382252810259),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 65339393
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteUtcTime",
      "o": "@$1",
      "d": 720915,
      "h": 382252810259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(382252810259),
//--TRIMMABLE-BOUNDARY-START(386547777555),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 65339393
        },
        {
          "n": "twoDigitYearMax",
          "p": 655361
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteUtcTime",
      "d": 720915,
      "h": 386547777555,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(386547777555),
//--TRIMMABLE-BOUNDARY-START(390842744851),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": 65339393
        }
      ],
      "n": "WriteUtcTimeCore",
      "d": 720915,
      "h": 390842744851,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(390842744851),
//--TRIMMABLE-BOUNDARY-START(150324576275),
    {
      "r": 851987,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "PushOctetString",
      "d": 720915,
      "h": 150324576275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324576275),
//--TRIMMABLE-BOUNDARY-START(124554772499),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "PopOctetString",
      "d": 720915,
      "h": 124554772499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124554772499),
//--TRIMMABLE-BOUNDARY-START(369367908371),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteOctetString",
      "d": 720915,
      "h": 369367908371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(369367908371),
//--TRIMMABLE-BOUNDARY-START(373662875667),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "octetString",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "WriteOctetStringCore",
      "d": 720915,
      "h": 373662875667,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(373662875667),
//--TRIMMABLE-BOUNDARY-START(244813856787),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "payload",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "WriteConstructedCerOctetString",
      "d": 720915,
      "h": 244813856787,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(244813856787),
//--TRIMMABLE-BOUNDARY-START(257698758675),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1048577
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteEnumeratedValue",
      "d": 720915,
      "h": 257698758675,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(257698758675),
//--TRIMMABLE-BOUNDARY-START(261993725971),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (TEnum) => TEnum.$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "g": [
        "TEnum"
      ],
      "n": "WriteEnumeratedValue",
      "o": "@$2",
      "d": 720915,
      "h": 261993725971,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(261993725971),
//--TRIMMABLE-BOUNDARY-START(266288693267),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "tEnum",
          "p": 187629569
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "WriteEnumeratedValue",
      "o": "@$1",
      "d": 720915,
      "h": 266288693267,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(266288693267),
//--TRIMMABLE-BOUNDARY-START(279173595155),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteInteger",
      "d": 720915,
      "h": 279173595155,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(279173595155),
//--TRIMMABLE-BOUNDARY-START(283468562451),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 983041
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteInteger",
      "o": "@$2",
      "d": 720915,
      "h": 283468562451,
      "f": 16777217,
      "a": [
        {
          "t": 54132737,
          "c": 8644067329,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(283468562451),
//--TRIMMABLE-BOUNDARY-START(287763529747),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 786438
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteInteger",
      "o": "@$3",
      "d": 720915,
      "h": 287763529747,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(287763529747),
//--TRIMMABLE-BOUNDARY-START(292058497043),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteInteger",
      "o": "@$1",
      "d": 720915,
      "h": 292058497043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(292058497043),
//--TRIMMABLE-BOUNDARY-START(309238366227),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteIntegerUnsigned",
      "d": 720915,
      "h": 309238366227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(309238366227),
//--TRIMMABLE-BOUNDARY-START(296353464339),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "WriteIntegerCore",
      "d": 720915,
      "h": 296353464339,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(296353464339),
//--TRIMMABLE-BOUNDARY-START(343598104595),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": 983041
        }
      ],
      "n": "WriteNonNegativeIntegerCore",
      "d": 720915,
      "h": 343598104595,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(343598104595),
//--TRIMMABLE-BOUNDARY-START(313533333523),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "WriteIntegerUnsignedCore",
      "d": 720915,
      "h": 313533333523,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(313533333523),
//--TRIMMABLE-BOUNDARY-START(300648431635),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "WriteIntegerCore",
      "o": "@$1",
      "d": 720915,
      "h": 300648431635,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(300648431635),
//--TRIMMABLE-BOUNDARY-START(304943398931),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": 786438
        }
      ],
      "n": "WriteIntegerCore",
      "o": "@$2",
      "d": 720915,
      "h": 304943398931,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(304943398931),
//--TRIMMABLE-BOUNDARY-START(176094380051),
    {
      "r": 65537,
      "n": "Reset",
      "d": 720915,
      "h": 176094380051,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094380051),
//--TRIMMABLE-BOUNDARY-START(111669870611),
    {
      "r": 655361,
      "n": "GetEncodedLength",
      "d": 720915,
      "h": 111669870611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669870611),
//--TRIMMABLE-BOUNDARY-START(197569216531),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryEncode",
      "d": 720915,
      "h": 197569216531,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197569216531),
//--TRIMMABLE-BOUNDARY-START(60130263059),
    {
      "r": 655361,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "Encode",
      "o": "@$1",
      "d": 720915,
      "h": 60130263059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130263059),
//--TRIMMABLE-BOUNDARY-START(64425230355),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "n": "Encode",
      "d": 720915,
      "h": 64425230355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425230355),
//--TRIMMABLE-BOUNDARY-START(68720197651),
    {
      "r": (TReturn) => TReturn.$h,
      "p": [
        {
          "n": "encodeCallback",
          "p": (TReturn) => $.$$.System.Func$$$($.$$.System.ReadOnlySpan$$($.$$.System.Byte), TReturn).$h
        }
      ],
      "g": [
        "TReturn"
      ],
      "n": "Encode",
      "o": "@$2",
      "d": 720915,
      "h": 68720197651,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(68720197651),
//--TRIMMABLE-BOUNDARY-START(73015164947),
    {
      "r": (TState, TReturn) => TReturn.$h,
      "p": [
        {
          "n": "state",
          "p": (TState, TReturn) => TState.$h
        },
        {
          "n": "encodeCallback",
          "p": (TState, TReturn) => $.$$.System.Func$$$$(TState, $.$$.System.ReadOnlySpan$$($.$$.System.Byte), TReturn).$h
        }
      ],
      "g": [
        "TState",
        "TReturn"
      ],
      "n": "Encode",
      "o": "@$3",
      "d": 720915,
      "h": 73015164947,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(73015164947),
//--TRIMMABLE-BOUNDARY-START(77310132243),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": (TState) => TState.$h
        },
        {
          "n": "encodeCallback",
          "p": (TState) => $.$$.System.Action$$$(TState, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)).$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "Encode",
      "o": "@$4",
      "d": 720915,
      "h": 77310132243,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(77310132243),
//--TRIMMABLE-BOUNDARY-START(81605099539),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "n": "EncodeAsSpan",
      "d": 720915,
      "h": 81605099539,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81605099539),
//--TRIMMABLE-BOUNDARY-START(85900066835),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "EncodedValueEquals",
      "d": 720915,
      "h": 85900066835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900066835),
//--TRIMMABLE-BOUNDARY-START(90195034131),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 720915
        }
      ],
      "n": "EncodedValueEquals",
      "o": "@$1",
      "d": 720915,
      "h": 90195034131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195034131),
//--TRIMMABLE-BOUNDARY-START(98784968723),
    {
      "r": 65537,
      "p": [
        {
          "n": "pendingCount",
          "p": 655361
        }
      ],
      "n": "EnsureWriteCapacity",
      "d": 720915,
      "h": 98784968723,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98784968723),
//--TRIMMABLE-BOUNDARY-START(377957842963),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        }
      ],
      "n": "WriteTag",
      "d": 720915,
      "h": 377957842963,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(377957842963),
//--TRIMMABLE-BOUNDARY-START(317828300819),
    {
      "r": 65537,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "WriteLength",
      "d": 720915,
      "h": 317828300819,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(317828300819),
//--TRIMMABLE-BOUNDARY-START(115964837907),
    {
      "r": 655361,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "GetEncodedLengthSubsequentByteCount",
      "d": 720915,
      "h": 115964837907,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(115964837907),
//--TRIMMABLE-BOUNDARY-START(51540328467),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": 720915
        }
      ],
      "n": "CopyTo",
      "d": 720915,
      "h": 51540328467,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540328467),
//--TRIMMABLE-BOUNDARY-START(249108824083),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "WriteEncodedValue",
      "d": 720915,
      "h": 249108824083,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(249108824083),
//--TRIMMABLE-BOUNDARY-START(253403791379),
    {
      "r": 65537,
      "n": "WriteEndOfContents",
      "d": 720915,
      "h": 253403791379,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(253403791379),
//--TRIMMABLE-BOUNDARY-START(171799412755),
    {
      "r": 851987,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "tagType",
          "p": 1572883
        }
      ],
      "n": "PushTag",
      "d": 720915,
      "h": 171799412755,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171799412755),
//--TRIMMABLE-BOUNDARY-START(146029608979),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "tagType",
          "p": 1572883
        },
        {
          "n": "sortContents",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "PopTag",
      "d": 720915,
      "h": 146029608979,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(146029608979),
//--TRIMMABLE-BOUNDARY-START(188979281939),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        }
      ],
      "n": "SortContents",
      "d": 720915,
      "h": 188979281939,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(188979281939),
//--TRIMMABLE-BOUNDARY-START(42950393875),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h
        },
        {
          "n": "universalTagNumber",
          "p": 1572883
        }
      ],
      "n": "CheckUniversalTag",
      "d": 720915,
      "h": 42950393875,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42950393875),
//--TRIMMABLE-BOUNDARY-START(206159151123),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 65,
          "v": 0
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteBitString",
      "d": 720915,
      "h": 206159151123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(206159151123),
//--TRIMMABLE-BOUNDARY-START(210454118419),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "bitString",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "unusedBitCount",
          "p": 655361
        }
      ],
      "n": "WriteBitStringCore",
      "d": 720915,
      "h": 210454118419,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210454118419),
//--TRIMMABLE-BOUNDARY-START(47245361171),
    {
      "r": 262145,
      "p": [
        {
          "n": "lastByte",
          "p": 393217
        },
        {
          "n": "unusedBitCount",
          "p": 655361
        }
      ],
      "n": "CheckValidLastByte",
      "d": 720915,
      "h": 47245361171,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47245361171),
//--TRIMMABLE-BOUNDARY-START(55835295763),
    {
      "r": 655361,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "contentLength",
          "p": 655361
        }
      ],
      "n": "DetermineCerBitStringTotalLength",
      "d": 720915,
      "h": 55835295763,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55835295763),
//--TRIMMABLE-BOUNDARY-START(236223922195),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "payload",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "unusedBitCount",
          "p": 655361
        }
      ],
      "n": "WriteConstructedCerBitString",
      "d": 720915,
      "h": 236223922195,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(236223922195)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688211),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_buffer",
      "d": 720915,
      "h": 4295688211,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688211),
//--TRIMMABLE-BOUNDARY-START(17180590099),
    {
      "t": 655361,
      "n": "_offset",
      "d": 720915,
      "h": 17180590099,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590099),
//--TRIMMABLE-BOUNDARY-START(12885622803),
    {
      "t": $.$sc.System.Collections.Generic.Stack$$($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame).$h,
      "n": "_nestingStack",
      "d": 720915,
      "h": 12885622803,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622803),
//--TRIMMABLE-BOUNDARY-START(8590655507),
    {
      "t": 655361,
      "n": "_encodeDepth",
      "d": 720915,
      "h": 8590655507,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655507)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475557395),
    {
      "p": [
        {
          "n": "ruleSet",
          "p": 524307
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720915,
      "h": 21475557395,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557395),
//--TRIMMABLE-BOUNDARY-START(25770524691),
    {
      "p": [
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "initialCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720915,
      "h": 25770524691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770524691)
  ],
  "j": [786451,917523,851987
  ],
  "h": 720915
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.AsnWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720915)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769491)
        $asm.$cls("$sfa.System.Obsoletions", ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382253858835)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382253858835)
            
            //--TRIMMABLE-BOUNDARY-START(433793466387)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433793466387)
            
            //--TRIMMABLE-BOUNDARY-START(429498499091)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429498499091)
            
            //--TRIMMABLE-BOUNDARY-START(266289741843)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266289741843)
            
            //--TRIMMABLE-BOUNDARY-START(261994774547)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261994774547)
            
            //--TRIMMABLE-BOUNDARY-START(77311180819)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77311180819)
            
            //--TRIMMABLE-BOUNDARY-START(73016213523)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73016213523)
            
            //--TRIMMABLE-BOUNDARY-START(94491050003)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94491050003)
            
            //--TRIMMABLE-BOUNDARY-START(90196082707)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90196082707)
            
            //--TRIMMABLE-BOUNDARY-START(214750134291)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214750134291)
            
            //--TRIMMABLE-BOUNDARY-START(210455166995)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210455166995)
            
            //--TRIMMABLE-BOUNDARY-START(442383400979)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442383400979)
            
            //--TRIMMABLE-BOUNDARY-START(446678368275)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446678368275)
            
            //--TRIMMABLE-BOUNDARY-START(438088433683)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438088433683)
            
            //--TRIMMABLE-BOUNDARY-START(146030657555)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146030657555)
            
            //--TRIMMABLE-BOUNDARY-START(141735690259)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141735690259)
            
            //--TRIMMABLE-BOUNDARY-START(120260853779)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120260853779)
            
            //--TRIMMABLE-BOUNDARY-START(115965886483)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115965886483)
            
            //--TRIMMABLE-BOUNDARY-START(51541377043)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51541377043)
            
            //--TRIMMABLE-BOUNDARY-START(47246409747)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47246409747)
            
            //--TRIMMABLE-BOUNDARY-START(326419283987)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326419283987)
            
            //--TRIMMABLE-BOUNDARY-START(322124316691)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322124316691)
            
            //--TRIMMABLE-BOUNDARY-START(60131311635)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60131311635)
            
            //--TRIMMABLE-BOUNDARY-START(55836344339)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55836344339)
            
            //--TRIMMABLE-BOUNDARY-START(85901115411)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85901115411)
            
            //--TRIMMABLE-BOUNDARY-START(81606148115)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81606148115)
            
            //--TRIMMABLE-BOUNDARY-START(197570265107)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197570265107)
            
            //--TRIMMABLE-BOUNDARY-START(193275297811)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193275297811)
            
            //--TRIMMABLE-BOUNDARY-START(489628041235)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489628041235)
            
            //--TRIMMABLE-BOUNDARY-START(485333073939)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485333073939)
            
            //--TRIMMABLE-BOUNDARY-START(163210526739)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163210526739)
            
            //--TRIMMABLE-BOUNDARY-START(158915559443)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158915559443)
            
            //--TRIMMABLE-BOUNDARY-START(206160199699)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206160199699)
            
            //--TRIMMABLE-BOUNDARY-START(201865232403)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201865232403)
            
            //--TRIMMABLE-BOUNDARY-START(399433728019)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399433728019)
            
            //--TRIMMABLE-BOUNDARY-START(395138760723)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395138760723)
            
            //--TRIMMABLE-BOUNDARY-START(300649480211)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300649480211)
            
            //--TRIMMABLE-BOUNDARY-START(296354512915)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296354512915)
            
            //--TRIMMABLE-BOUNDARY-START(377958891539)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377958891539)
            
            //--TRIMMABLE-BOUNDARY-START(373663924243)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373663924243)
            
            //--TRIMMABLE-BOUNDARY-START(231930003475)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231930003475)
            
            //--TRIMMABLE-BOUNDARY-START(227635036179)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227635036179)
            
            //--TRIMMABLE-BOUNDARY-START(154620592147)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154620592147)
            
            //--TRIMMABLE-BOUNDARY-START(150325624851)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150325624851)
            
            //--TRIMMABLE-BOUNDARY-START(352189087763)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352189087763)
            
            //--TRIMMABLE-BOUNDARY-START(347894120467)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347894120467)
            
            //--TRIMMABLE-BOUNDARY-START(360779022355)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360779022355)
            
            //--TRIMMABLE-BOUNDARY-START(356484055059)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356484055059)
            
            //--TRIMMABLE-BOUNDARY-START(17181638675)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17181638675)
            
            //--TRIMMABLE-BOUNDARY-START(12886671379)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12886671379)
            
            //--TRIMMABLE-BOUNDARY-START(408023662611)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408023662611)
            
            //--TRIMMABLE-BOUNDARY-START(403728695315)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403728695315)
            
            //--TRIMMABLE-BOUNDARY-START(498217975827)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498217975827)
            
            //--TRIMMABLE-BOUNDARY-START(493923008531)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493923008531)
            
            //--TRIMMABLE-BOUNDARY-START(283469611027)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283469611027)
            
            //--TRIMMABLE-BOUNDARY-START(279174643731)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279174643731)
            
            //--TRIMMABLE-BOUNDARY-START(506807910419)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506807910419)
            
            //--TRIMMABLE-BOUNDARY-START(502512943123)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502512943123)
            
            //--TRIMMABLE-BOUNDARY-START(274879676435)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274879676435)
            
            //--TRIMMABLE-BOUNDARY-START(270584709139)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270584709139)
            
            //--TRIMMABLE-BOUNDARY-START(481038106643)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481038106643)
            
            //--TRIMMABLE-BOUNDARY-START(476743139347)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476743139347)
            
            //--TRIMMABLE-BOUNDARY-START(128850788371)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128850788371)
            
            //--TRIMMABLE-BOUNDARY-START(124555821075)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124555821075)
            
            //--TRIMMABLE-BOUNDARY-START(111670919187)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111670919187)
            
            //--TRIMMABLE-BOUNDARY-START(107375951891)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107375951891)
            
            //--TRIMMABLE-BOUNDARY-START(335009218579)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335009218579)
            
            //--TRIMMABLE-BOUNDARY-START(330714251283)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330714251283)
            
            //--TRIMMABLE-BOUNDARY-START(68721246227)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68721246227)
            
            //--TRIMMABLE-BOUNDARY-START(64426278931)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64426278931)
            
            //--TRIMMABLE-BOUNDARY-START(390843793427)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390843793427)
            
            //--TRIMMABLE-BOUNDARY-START(386548826131)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386548826131)
            
            //--TRIMMABLE-BOUNDARY-START(309239414803)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309239414803)
            
            //--TRIMMABLE-BOUNDARY-START(304944447507)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304944447507)
            
            //--TRIMMABLE-BOUNDARY-START(42951442451)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42951442451)
            
            //--TRIMMABLE-BOUNDARY-START(38656475155)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38656475155)
            
            //--TRIMMABLE-BOUNDARY-START(416613597203)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416613597203)
            
            //--TRIMMABLE-BOUNDARY-START(412318629907)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412318629907)
            
            //--TRIMMABLE-BOUNDARY-START(472448172051)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472448172051)
            
            //--TRIMMABLE-BOUNDARY-START(468153204755)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468153204755)
            
            //--TRIMMABLE-BOUNDARY-START(188980330515)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188980330515)
            
            //--TRIMMABLE-BOUNDARY-START(184685363219)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184685363219)
            
            //--TRIMMABLE-BOUNDARY-START(171800461331)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171800461331)
            
            //--TRIMMABLE-BOUNDARY-START(167505494035)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167505494035)
            
            //--TRIMMABLE-BOUNDARY-START(180390395923)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180390395923)
            
            //--TRIMMABLE-BOUNDARY-START(176095428627)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176095428627)
            
            //--TRIMMABLE-BOUNDARY-START(34361507859)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34361507859)
            
            //--TRIMMABLE-BOUNDARY-START(30066540563)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30066540563)
            
            //--TRIMMABLE-BOUNDARY-START(137440722963)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137440722963)
            
            //--TRIMMABLE-BOUNDARY-START(133145755667)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133145755667)
            
            //--TRIMMABLE-BOUNDARY-START(103080984595)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103080984595)
            
            //--TRIMMABLE-BOUNDARY-START(98786017299)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98786017299)
            
            //--TRIMMABLE-BOUNDARY-START(523987779603)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523987779603)
            
            //--TRIMMABLE-BOUNDARY-START(519692812307)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519692812307)
            
            //--TRIMMABLE-BOUNDARY-START(369368956947)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369368956947)
            
            //--TRIMMABLE-BOUNDARY-START(365073989651)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365073989651)
            
            //--TRIMMABLE-BOUNDARY-START(223340068883)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223340068883)
            
            //--TRIMMABLE-BOUNDARY-START(219045101587)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219045101587)
            
            //--TRIMMABLE-BOUNDARY-START(249109872659)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249109872659)
            
            //--TRIMMABLE-BOUNDARY-START(236224970771)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236224970771)
            
            //--TRIMMABLE-BOUNDARY-START(244814905363)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244814905363)
            
            //--TRIMMABLE-BOUNDARY-START(240519938067)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240519938067)
            
            //--TRIMMABLE-BOUNDARY-START(317829349395)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317829349395)
            
            //--TRIMMABLE-BOUNDARY-START(313534382099)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313534382099)
            
            //--TRIMMABLE-BOUNDARY-START(8591704083)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8591704083)
            
            //--TRIMMABLE-BOUNDARY-START(4296736787)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4296736787)
            
            //--TRIMMABLE-BOUNDARY-START(455268302867)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455268302867)
            
            //--TRIMMABLE-BOUNDARY-START(450973335571)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450973335571)
            
            //--TRIMMABLE-BOUNDARY-START(25771573267)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25771573267)
            
            //--TRIMMABLE-BOUNDARY-START(21476605971)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21476605971)
            
            //--TRIMMABLE-BOUNDARY-START(257699807251)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257699807251)
            
            //--TRIMMABLE-BOUNDARY-START(253404839955)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253404839955)
            
            //--TRIMMABLE-BOUNDARY-START(515397845011)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515397845011)
            
            //--TRIMMABLE-BOUNDARY-START(511102877715)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511102877715)
            
            //--TRIMMABLE-BOUNDARY-START(463858237459)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463858237459)
            
            //--TRIMMABLE-BOUNDARY-START(459563270163)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459563270163)
            
            //--TRIMMABLE-BOUNDARY-START(425203531795)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425203531795)
            
            //--TRIMMABLE-BOUNDARY-START(420908564499)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420908564499)
            
            //--TRIMMABLE-BOUNDARY-START(343599153171)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343599153171)
            
            //--TRIMMABLE-BOUNDARY-START(339304185875)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339304185875)
            
            //--TRIMMABLE-BOUNDARY-START(292059545619)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292059545619)
            
            //--TRIMMABLE-BOUNDARY-START(287764578323)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287764578323)
            
            //--TRIMMABLE-BOUNDARY-START(532577714195)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532577714195)
            
            //--TRIMMABLE-BOUNDARY-START(528282746899)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528282746899)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382253858835)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382253858835)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433793466387)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433793466387)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429498499091)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429498499091)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266289741843)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266289741843)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261994774547)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261994774547)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77311180819)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77311180819)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73016213523)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73016213523)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94491050003)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94491050003)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90196082707)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90196082707)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214750134291)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214750134291)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210455166995)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210455166995)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442383400979)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442383400979)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446678368275)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446678368275)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438088433683)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438088433683)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146030657555)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146030657555)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141735690259)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141735690259)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120260853779)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120260853779)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115965886483)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115965886483)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51541377043)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51541377043)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47246409747)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47246409747)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326419283987)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326419283987)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322124316691)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322124316691)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60131311635)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60131311635)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55836344339)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55836344339)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85901115411)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85901115411)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81606148115)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81606148115)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197570265107)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197570265107)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193275297811)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193275297811)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489628041235)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489628041235)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485333073939)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485333073939)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163210526739)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163210526739)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158915559443)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158915559443)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206160199699)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206160199699)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201865232403)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201865232403)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399433728019)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399433728019)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395138760723)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395138760723)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300649480211)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300649480211)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296354512915)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296354512915)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377958891539)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377958891539)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373663924243)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373663924243)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231930003475)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231930003475)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227635036179)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227635036179)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154620592147)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154620592147)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150325624851)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150325624851)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352189087763)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352189087763)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347894120467)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347894120467)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360779022355)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360779022355)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356484055059)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356484055059)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181638675)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17181638675)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886671379)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12886671379)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408023662611)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408023662611)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403728695315)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403728695315)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498217975827)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498217975827)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493923008531)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493923008531)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283469611027)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283469611027)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279174643731)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279174643731)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506807910419)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506807910419)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502512943123)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502512943123)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274879676435)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274879676435)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270584709139)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270584709139)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481038106643)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481038106643)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476743139347)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476743139347)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128850788371)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128850788371)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124555821075)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124555821075)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111670919187)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111670919187)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107375951891)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107375951891)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335009218579)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335009218579)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330714251283)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330714251283)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68721246227)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68721246227)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64426278931)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64426278931)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390843793427)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390843793427)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386548826131)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386548826131)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309239414803)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309239414803)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304944447507)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304944447507)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42951442451)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42951442451)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38656475155)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38656475155)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416613597203)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416613597203)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412318629907)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412318629907)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472448172051)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472448172051)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468153204755)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468153204755)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188980330515)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188980330515)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184685363219)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184685363219)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171800461331)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171800461331)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167505494035)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167505494035)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180390395923)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180390395923)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176095428627)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176095428627)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34361507859)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34361507859)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30066540563)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30066540563)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137440722963)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137440722963)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133145755667)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133145755667)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103080984595)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103080984595)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98786017299)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98786017299)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523987779603)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523987779603)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519692812307)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519692812307)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369368956947)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369368956947)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365073989651)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365073989651)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223340068883)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223340068883)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219045101587)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219045101587)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249109872659)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249109872659)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236224970771)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236224970771)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244814905363)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244814905363)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240519938067)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240519938067)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317829349395)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317829349395)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313534382099)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313534382099)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591704083)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8591704083)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4296736787)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4296736787)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455268302867)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455268302867)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450973335571)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450973335571)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771573267)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25771573267)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476605971)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21476605971)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257699807251)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257699807251)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253404839955)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253404839955)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515397845011)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515397845011)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511102877715)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511102877715)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463858237459)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463858237459)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459563270163)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459563270163)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425203531795)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425203531795)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420908564499)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420908564499)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343599153171)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343599153171)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339304185875)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339304185875)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292059545619)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292059545619)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287764578323)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287764578323)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532577714195)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532577714195)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528282746899)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528282746899)
                    
                }
            }
            static $h = 1769491;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(382253858835),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 1769491,
      "h": 382253858835,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382253858835),
//--TRIMMABLE-BOUNDARY-START(433793466387),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 1769491,
      "h": 433793466387,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433793466387),
//--TRIMMABLE-BOUNDARY-START(429498499091),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 1769491,
      "h": 429498499091,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429498499091),
//--TRIMMABLE-BOUNDARY-START(266289741843),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 1769491,
      "h": 266289741843,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266289741843),
//--TRIMMABLE-BOUNDARY-START(261994774547),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 1769491,
      "h": 261994774547,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261994774547),
//--TRIMMABLE-BOUNDARY-START(77311180819),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 1769491,
      "h": 77311180819,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77311180819),
//--TRIMMABLE-BOUNDARY-START(73016213523),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 1769491,
      "h": 73016213523,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73016213523),
//--TRIMMABLE-BOUNDARY-START(94491050003),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 1769491,
      "h": 94491050003,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94491050003),
//--TRIMMABLE-BOUNDARY-START(90196082707),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 1769491,
      "h": 90196082707,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90196082707),
//--TRIMMABLE-BOUNDARY-START(214750134291),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 1769491,
      "h": 214750134291,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214750134291),
//--TRIMMABLE-BOUNDARY-START(210455166995),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 1769491,
      "h": 210455166995,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210455166995),
//--TRIMMABLE-BOUNDARY-START(442383400979),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 1769491,
      "h": 442383400979,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442383400979),
//--TRIMMABLE-BOUNDARY-START(446678368275),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 1769491,
      "h": 446678368275,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446678368275),
//--TRIMMABLE-BOUNDARY-START(438088433683),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 1769491,
      "h": 438088433683,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438088433683),
//--TRIMMABLE-BOUNDARY-START(146030657555),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 1769491,
      "h": 146030657555,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146030657555),
//--TRIMMABLE-BOUNDARY-START(141735690259),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 1769491,
      "h": 141735690259,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141735690259),
//--TRIMMABLE-BOUNDARY-START(120260853779),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 1769491,
      "h": 120260853779,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120260853779),
//--TRIMMABLE-BOUNDARY-START(115965886483),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 1769491,
      "h": 115965886483,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115965886483),
//--TRIMMABLE-BOUNDARY-START(51541377043),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 1769491,
      "h": 51541377043,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51541377043),
//--TRIMMABLE-BOUNDARY-START(47246409747),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 1769491,
      "h": 47246409747,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47246409747),
//--TRIMMABLE-BOUNDARY-START(326419283987),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 1769491,
      "h": 326419283987,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326419283987),
//--TRIMMABLE-BOUNDARY-START(322124316691),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 1769491,
      "h": 322124316691,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322124316691),
//--TRIMMABLE-BOUNDARY-START(60131311635),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 1769491,
      "h": 60131311635,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60131311635),
//--TRIMMABLE-BOUNDARY-START(55836344339),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 1769491,
      "h": 55836344339,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55836344339),
//--TRIMMABLE-BOUNDARY-START(85901115411),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 1769491,
      "h": 85901115411,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85901115411),
//--TRIMMABLE-BOUNDARY-START(81606148115),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 1769491,
      "h": 81606148115,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81606148115),
//--TRIMMABLE-BOUNDARY-START(197570265107),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 1769491,
      "h": 197570265107,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197570265107),
//--TRIMMABLE-BOUNDARY-START(193275297811),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 1769491,
      "h": 193275297811,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193275297811),
//--TRIMMABLE-BOUNDARY-START(489628041235),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 1769491,
      "h": 489628041235,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489628041235),
//--TRIMMABLE-BOUNDARY-START(485333073939),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 1769491,
      "h": 485333073939,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485333073939),
//--TRIMMABLE-BOUNDARY-START(163210526739),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 1769491,
      "h": 163210526739,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163210526739),
//--TRIMMABLE-BOUNDARY-START(158915559443),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 1769491,
      "h": 158915559443,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158915559443),
//--TRIMMABLE-BOUNDARY-START(206160199699),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 1769491,
      "h": 206160199699,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206160199699),
//--TRIMMABLE-BOUNDARY-START(201865232403),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 1769491,
      "h": 201865232403,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201865232403),
//--TRIMMABLE-BOUNDARY-START(399433728019),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 1769491,
      "h": 399433728019,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399433728019),
//--TRIMMABLE-BOUNDARY-START(395138760723),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 1769491,
      "h": 395138760723,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395138760723),
//--TRIMMABLE-BOUNDARY-START(300649480211),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 1769491,
      "h": 300649480211,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300649480211),
//--TRIMMABLE-BOUNDARY-START(296354512915),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 1769491,
      "h": 296354512915,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296354512915),
//--TRIMMABLE-BOUNDARY-START(377958891539),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 1769491,
      "h": 377958891539,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377958891539),
//--TRIMMABLE-BOUNDARY-START(373663924243),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 1769491,
      "h": 373663924243,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373663924243),
//--TRIMMABLE-BOUNDARY-START(231930003475),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 1769491,
      "h": 231930003475,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231930003475),
//--TRIMMABLE-BOUNDARY-START(227635036179),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 1769491,
      "h": 227635036179,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227635036179),
//--TRIMMABLE-BOUNDARY-START(154620592147),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 1769491,
      "h": 154620592147,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154620592147),
//--TRIMMABLE-BOUNDARY-START(150325624851),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 1769491,
      "h": 150325624851,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150325624851),
//--TRIMMABLE-BOUNDARY-START(352189087763),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 1769491,
      "h": 352189087763,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352189087763),
//--TRIMMABLE-BOUNDARY-START(347894120467),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 1769491,
      "h": 347894120467,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347894120467),
//--TRIMMABLE-BOUNDARY-START(360779022355),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 1769491,
      "h": 360779022355,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360779022355),
//--TRIMMABLE-BOUNDARY-START(356484055059),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 1769491,
      "h": 356484055059,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356484055059),
//--TRIMMABLE-BOUNDARY-START(17181638675),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 1769491,
      "h": 17181638675,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17181638675),
//--TRIMMABLE-BOUNDARY-START(12886671379),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 1769491,
      "h": 12886671379,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12886671379),
//--TRIMMABLE-BOUNDARY-START(408023662611),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 1769491,
      "h": 408023662611,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408023662611),
//--TRIMMABLE-BOUNDARY-START(403728695315),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 1769491,
      "h": 403728695315,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403728695315),
//--TRIMMABLE-BOUNDARY-START(498217975827),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 1769491,
      "h": 498217975827,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498217975827),
//--TRIMMABLE-BOUNDARY-START(493923008531),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 1769491,
      "h": 493923008531,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493923008531),
//--TRIMMABLE-BOUNDARY-START(283469611027),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 1769491,
      "h": 283469611027,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283469611027),
//--TRIMMABLE-BOUNDARY-START(279174643731),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 1769491,
      "h": 279174643731,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279174643731),
//--TRIMMABLE-BOUNDARY-START(506807910419),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 1769491,
      "h": 506807910419,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506807910419),
//--TRIMMABLE-BOUNDARY-START(502512943123),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 1769491,
      "h": 502512943123,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502512943123),
//--TRIMMABLE-BOUNDARY-START(274879676435),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 1769491,
      "h": 274879676435,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274879676435),
//--TRIMMABLE-BOUNDARY-START(270584709139),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 1769491,
      "h": 270584709139,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270584709139),
//--TRIMMABLE-BOUNDARY-START(481038106643),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 1769491,
      "h": 481038106643,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481038106643),
//--TRIMMABLE-BOUNDARY-START(476743139347),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 1769491,
      "h": 476743139347,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476743139347),
//--TRIMMABLE-BOUNDARY-START(128850788371),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 1769491,
      "h": 128850788371,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128850788371),
//--TRIMMABLE-BOUNDARY-START(124555821075),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 1769491,
      "h": 124555821075,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124555821075),
//--TRIMMABLE-BOUNDARY-START(111670919187),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 1769491,
      "h": 111670919187,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111670919187),
//--TRIMMABLE-BOUNDARY-START(107375951891),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 1769491,
      "h": 107375951891,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107375951891),
//--TRIMMABLE-BOUNDARY-START(335009218579),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 1769491,
      "h": 335009218579,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335009218579),
//--TRIMMABLE-BOUNDARY-START(330714251283),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 1769491,
      "h": 330714251283,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330714251283),
//--TRIMMABLE-BOUNDARY-START(68721246227),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 1769491,
      "h": 68721246227,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68721246227),
//--TRIMMABLE-BOUNDARY-START(64426278931),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 1769491,
      "h": 64426278931,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64426278931),
//--TRIMMABLE-BOUNDARY-START(390843793427),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 1769491,
      "h": 390843793427,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390843793427),
//--TRIMMABLE-BOUNDARY-START(386548826131),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 1769491,
      "h": 386548826131,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386548826131),
//--TRIMMABLE-BOUNDARY-START(309239414803),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 1769491,
      "h": 309239414803,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309239414803),
//--TRIMMABLE-BOUNDARY-START(304944447507),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 1769491,
      "h": 304944447507,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304944447507),
//--TRIMMABLE-BOUNDARY-START(42951442451),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 1769491,
      "h": 42951442451,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42951442451),
//--TRIMMABLE-BOUNDARY-START(38656475155),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 1769491,
      "h": 38656475155,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38656475155),
//--TRIMMABLE-BOUNDARY-START(416613597203),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 1769491,
      "h": 416613597203,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416613597203),
//--TRIMMABLE-BOUNDARY-START(412318629907),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 1769491,
      "h": 412318629907,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412318629907),
//--TRIMMABLE-BOUNDARY-START(472448172051),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 1769491,
      "h": 472448172051,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472448172051),
//--TRIMMABLE-BOUNDARY-START(468153204755),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 1769491,
      "h": 468153204755,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468153204755),
//--TRIMMABLE-BOUNDARY-START(188980330515),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 1769491,
      "h": 188980330515,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188980330515),
//--TRIMMABLE-BOUNDARY-START(184685363219),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 1769491,
      "h": 184685363219,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184685363219),
//--TRIMMABLE-BOUNDARY-START(171800461331),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 1769491,
      "h": 171800461331,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171800461331),
//--TRIMMABLE-BOUNDARY-START(167505494035),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 1769491,
      "h": 167505494035,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167505494035),
//--TRIMMABLE-BOUNDARY-START(180390395923),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 1769491,
      "h": 180390395923,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180390395923),
//--TRIMMABLE-BOUNDARY-START(176095428627),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 1769491,
      "h": 176095428627,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176095428627),
//--TRIMMABLE-BOUNDARY-START(34361507859),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 1769491,
      "h": 34361507859,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34361507859),
//--TRIMMABLE-BOUNDARY-START(30066540563),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 1769491,
      "h": 30066540563,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30066540563),
//--TRIMMABLE-BOUNDARY-START(137440722963),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 1769491,
      "h": 137440722963,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137440722963),
//--TRIMMABLE-BOUNDARY-START(133145755667),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 1769491,
      "h": 133145755667,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133145755667),
//--TRIMMABLE-BOUNDARY-START(103080984595),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 1769491,
      "h": 103080984595,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103080984595),
//--TRIMMABLE-BOUNDARY-START(98786017299),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 1769491,
      "h": 98786017299,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98786017299),
//--TRIMMABLE-BOUNDARY-START(523987779603),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 1769491,
      "h": 523987779603,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523987779603),
//--TRIMMABLE-BOUNDARY-START(519692812307),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 1769491,
      "h": 519692812307,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519692812307),
//--TRIMMABLE-BOUNDARY-START(369368956947),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 1769491,
      "h": 369368956947,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369368956947),
//--TRIMMABLE-BOUNDARY-START(365073989651),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 1769491,
      "h": 365073989651,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365073989651),
//--TRIMMABLE-BOUNDARY-START(223340068883),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 1769491,
      "h": 223340068883,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223340068883),
//--TRIMMABLE-BOUNDARY-START(219045101587),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 1769491,
      "h": 219045101587,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219045101587),
//--TRIMMABLE-BOUNDARY-START(249109872659),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 1769491,
      "h": 249109872659,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249109872659),
//--TRIMMABLE-BOUNDARY-START(236224970771),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 1769491,
      "h": 236224970771,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236224970771),
//--TRIMMABLE-BOUNDARY-START(244814905363),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 1769491,
      "h": 244814905363,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244814905363),
//--TRIMMABLE-BOUNDARY-START(240519938067),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 1769491,
      "h": 240519938067,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240519938067),
//--TRIMMABLE-BOUNDARY-START(317829349395),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 1769491,
      "h": 317829349395,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317829349395),
//--TRIMMABLE-BOUNDARY-START(313534382099),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 1769491,
      "h": 313534382099,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313534382099),
//--TRIMMABLE-BOUNDARY-START(8591704083),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 1769491,
      "h": 8591704083,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8591704083),
//--TRIMMABLE-BOUNDARY-START(4296736787),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 1769491,
      "h": 4296736787,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4296736787),
//--TRIMMABLE-BOUNDARY-START(455268302867),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 1769491,
      "h": 455268302867,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455268302867),
//--TRIMMABLE-BOUNDARY-START(450973335571),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 1769491,
      "h": 450973335571,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450973335571),
//--TRIMMABLE-BOUNDARY-START(25771573267),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 1769491,
      "h": 25771573267,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25771573267),
//--TRIMMABLE-BOUNDARY-START(21476605971),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 1769491,
      "h": 21476605971,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21476605971),
//--TRIMMABLE-BOUNDARY-START(257699807251),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 1769491,
      "h": 257699807251,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257699807251),
//--TRIMMABLE-BOUNDARY-START(253404839955),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 1769491,
      "h": 253404839955,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253404839955),
//--TRIMMABLE-BOUNDARY-START(515397845011),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 1769491,
      "h": 515397845011,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515397845011),
//--TRIMMABLE-BOUNDARY-START(511102877715),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 1769491,
      "h": 511102877715,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511102877715),
//--TRIMMABLE-BOUNDARY-START(463858237459),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 1769491,
      "h": 463858237459,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463858237459),
//--TRIMMABLE-BOUNDARY-START(459563270163),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 1769491,
      "h": 459563270163,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459563270163),
//--TRIMMABLE-BOUNDARY-START(425203531795),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 1769491,
      "h": 425203531795,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425203531795),
//--TRIMMABLE-BOUNDARY-START(420908564499),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 1769491,
      "h": 420908564499,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420908564499),
//--TRIMMABLE-BOUNDARY-START(343599153171),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 1769491,
      "h": 343599153171,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343599153171),
//--TRIMMABLE-BOUNDARY-START(339304185875),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 1769491,
      "h": 339304185875,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339304185875),
//--TRIMMABLE-BOUNDARY-START(292059545619),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 1769491,
      "h": 292059545619,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292059545619),
//--TRIMMABLE-BOUNDARY-START(287764578323),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 1769491,
      "h": 287764578323,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287764578323),
//--TRIMMABLE-BOUNDARY-START(532577714195),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 1769491,
      "h": 532577714195,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532577714195),
//--TRIMMABLE-BOUNDARY-START(528282746899),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 1769491,
      "h": 528282746899,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528282746899)
  ],
  "h": 1769491
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769491)
        
        
        //--TRIMMABLE-BOUNDARY-START(1703955)
        $asm.$cls("$sfa.System.Formats.Asn1.WellKnownOids", ($self) => class WellKnownOids
        {
            //--TRIMMABLE-BOUNDARY-START(8591638547)
            static /*string? */ GetValue(/*ReadOnlySpan<byte>*/ contents)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591638547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 56 && contents[5] === 4 && contents[6] === 1))
                    {
                        return "1.2.840.10040.4.1";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 56 && contents[5] === 4 && contents[6] === 3))
                    {
                        return "1.2.840.10040.4.3";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 2 && contents[6] === 1))
                    {
                        return "1.2.840.10045.2.1";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 1 && contents[6] === 1))
                    {
                        return "1.2.840.10045.1.1";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 1 && contents[6] === 2))
                    {
                        return "1.2.840.10045.1.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 3 && contents[6] === 1 && contents[7] === 7))
                    {
                        return "1.2.840.10045.3.1.7";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 1))
                    {
                        return "1.2.840.10045.4.1";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 3 && contents[7] === 2))
                    {
                        return "1.2.840.10045.4.3.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 3 && contents[7] === 3))
                    {
                        return "1.2.840.10045.4.3.3";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 3 && contents[7] === 4))
                    {
                        return "1.2.840.10045.4.3.4";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 1))
                    {
                        return "1.2.840.113549.1.1.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 5))
                    {
                        return "1.2.840.113549.1.1.5";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 7))
                    {
                        return "1.2.840.113549.1.1.7";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 8))
                    {
                        return "1.2.840.113549.1.1.8";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 9))
                    {
                        return "1.2.840.113549.1.1.9";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 10))
                    {
                        return "1.2.840.113549.1.1.10";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 11))
                    {
                        return "1.2.840.113549.1.1.11";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 12))
                    {
                        return "1.2.840.113549.1.1.12";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 13))
                    {
                        return "1.2.840.113549.1.1.13";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 3))
                    {
                        return "1.2.840.113549.1.5.3";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 10))
                    {
                        return "1.2.840.113549.1.5.10";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 11))
                    {
                        return "1.2.840.113549.1.5.11";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 12))
                    {
                        return "1.2.840.113549.1.5.12";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 13))
                    {
                        return "1.2.840.113549.1.5.13";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 1))
                    {
                        return "1.2.840.113549.1.7.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 2))
                    {
                        return "1.2.840.113549.1.7.2";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 3))
                    {
                        return "1.2.840.113549.1.7.3";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 6))
                    {
                        return "1.2.840.113549.1.7.6";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 1))
                    {
                        return "1.2.840.113549.1.9.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 3))
                    {
                        return "1.2.840.113549.1.9.3";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 4))
                    {
                        return "1.2.840.113549.1.9.4";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 5))
                    {
                        return "1.2.840.113549.1.9.5";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 6))
                    {
                        return "1.2.840.113549.1.9.6";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 7))
                    {
                        return "1.2.840.113549.1.9.7";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 14))
                    {
                        return "1.2.840.113549.1.9.14";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 15))
                    {
                        return "1.2.840.113549.1.9.15";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 1 && contents[10] === 4))
                    {
                        return "1.2.840.113549.1.9.16.1.4";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 2 && contents[10] === 12))
                    {
                        return "1.2.840.113549.1.9.16.2.12";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 2 && contents[10] === 14))
                    {
                        return "1.2.840.113549.1.9.16.2.14";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 2 && contents[10] === 47))
                    {
                        return "1.2.840.113549.1.9.16.2.47";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 20))
                    {
                        return "1.2.840.113549.1.9.20";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 21))
                    {
                        return "1.2.840.113549.1.9.21";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 22 && contents[9] === 1))
                    {
                        return "1.2.840.113549.1.9.22.1";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 1 && contents[9] === 3))
                    {
                        return "1.2.840.113549.1.12.1.3";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 1 && contents[9] === 5))
                    {
                        return "1.2.840.113549.1.12.1.5";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 1 && contents[9] === 6))
                    {
                        return "1.2.840.113549.1.12.1.6";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 1))
                    {
                        return "1.2.840.113549.1.12.10.1.1";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 2))
                    {
                        return "1.2.840.113549.1.12.10.1.2";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 3))
                    {
                        return "1.2.840.113549.1.12.10.1.3";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 5))
                    {
                        return "1.2.840.113549.1.12.10.1.5";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 6))
                    {
                        return "1.2.840.113549.1.12.10.1.6";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 5))
                    {
                        return "1.2.840.113549.2.5";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 7))
                    {
                        return "1.2.840.113549.2.7";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 9))
                    {
                        return "1.2.840.113549.2.9";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 10))
                    {
                        return "1.2.840.113549.2.10";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 11))
                    {
                        return "1.2.840.113549.2.11";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 3 && contents[7] === 2))
                    {
                        return "1.2.840.113549.3.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 3 && contents[7] === 7))
                    {
                        return "1.2.840.113549.3.7";
                    }
                    if ((contents.Length === 9 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 17 && contents[8] === 1))
                    {
                        return "1.3.6.1.4.1.311.17.1";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 17 && contents[8] === 3 && contents[9] === 20))
                    {
                        return "1.3.6.1.4.1.311.17.3.20";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 20 && contents[8] === 2 && contents[9] === 3))
                    {
                        return "1.3.6.1.4.1.311.20.2.3";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 88 && contents[8] === 2 && contents[9] === 1))
                    {
                        return "1.3.6.1.4.1.311.88.2.1";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 88 && contents[8] === 2 && contents[9] === 2))
                    {
                        return "1.3.6.1.4.1.311.88.2.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 1))
                    {
                        return "1.3.6.1.5.5.7.3.1";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 2))
                    {
                        return "1.3.6.1.5.5.7.3.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 3))
                    {
                        return "1.3.6.1.5.5.7.3.3";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 4))
                    {
                        return "1.3.6.1.5.5.7.3.4";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 8))
                    {
                        return "1.3.6.1.5.5.7.3.8";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 9))
                    {
                        return "1.3.6.1.5.5.7.3.9";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 6 && contents[7] === 2))
                    {
                        return "1.3.6.1.5.5.7.6.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 48 && contents[7] === 1))
                    {
                        return "1.3.6.1.5.5.7.48.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 48 && contents[7] === 1 && contents[8] === 2))
                    {
                        return "1.3.6.1.5.5.7.48.1.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 48 && contents[7] === 2))
                    {
                        return "1.3.6.1.5.5.7.48.2";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 14 && contents[2] === 3 && contents[3] === 2 && contents[4] === 26))
                    {
                        return "1.3.14.3.2.26";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 14 && contents[2] === 3 && contents[3] === 2 && contents[4] === 7))
                    {
                        return "1.3.14.3.2.7";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 129 && contents[2] === 4 && contents[3] === 0 && contents[4] === 34))
                    {
                        return "1.3.132.0.34";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 129 && contents[2] === 4 && contents[3] === 0 && contents[4] === 35))
                    {
                        return "1.3.132.0.35";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 3))
                    {
                        return "2.5.4.3";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 5))
                    {
                        return "2.5.4.5";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 6))
                    {
                        return "2.5.4.6";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 7))
                    {
                        return "2.5.4.7";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 8))
                    {
                        return "2.5.4.8";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 10))
                    {
                        return "2.5.4.10";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 11))
                    {
                        return "2.5.4.11";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 97))
                    {
                        return "2.5.4.97";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 14))
                    {
                        return "2.5.29.14";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 15))
                    {
                        return "2.5.29.15";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 17))
                    {
                        return "2.5.29.17";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 19))
                    {
                        return "2.5.29.19";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 20))
                    {
                        return "2.5.29.20";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 35))
                    {
                        return "2.5.29.35";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 1 && contents[8] === 2))
                    {
                        return "2.16.840.1.101.3.4.1.2";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 1 && contents[8] === 22))
                    {
                        return "2.16.840.1.101.3.4.1.22";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 1 && contents[8] === 42))
                    {
                        return "2.16.840.1.101.3.4.1.42";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 2 && contents[8] === 1))
                    {
                        return "2.16.840.1.101.3.4.2.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 2 && contents[8] === 2))
                    {
                        return "2.16.840.1.101.3.4.2.2";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 2 && contents[8] === 3))
                    {
                        return "2.16.840.1.101.3.4.2.3";
                    }
                    if ((contents.Length === 6 && contents[0] === 103 && contents[1] === 129 && contents[2] === 12 && contents[3] === 1 && contents[4] === 2 && contents[5] === 1))
                    {
                        return "2.23.140.1.2.1";
                    }
                    if ((contents.Length === 6 && contents[0] === 103 && contents[1] === 129 && contents[2] === 12 && contents[3] === 1 && contents[4] === 2 && contents[5] === 2))
                    {
                        return "2.23.140.1.2.2";
                    }
                    return null;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(8591638547)
            
            //--TRIMMABLE-BOUNDARY-START(4296671251)
            static /*ReadOnlySpan<byte> */ GetContents(/*ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296671251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let data = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([ 42, 134, 72, 206, 56, 4, 1, 42, 134, 72, 206, 56, 4, 3, 42, 134, 72, 206, 61, 2, 1, 42, 134, 72, 206, 61, 1, 1, 42, 134, 72, 206, 61, 1, 2, 42, 134, 72, 206, 61, 3, 1, 7, 42, 134, 72, 206, 61, 4, 1, 42, 134, 72, 206, 61, 4, 3, 2, 42, 134, 72, 206, 61, 4, 3, 3, 42, 134, 72, 206, 61, 4, 3, 4, 42, 134, 72, 134, 247, 13, 1, 1, 1, 42, 134, 72, 134, 247, 13, 1, 1, 5, 42, 134, 72, 134, 247, 13, 1, 1, 7, 42, 134, 72, 134, 247, 13, 1, 1, 8, 42, 134, 72, 134, 247, 13, 1, 1, 9, 42, 134, 72, 134, 247, 13, 1, 1, 10, 42, 134, 72, 134, 247, 13, 1, 1, 11, 42, 134, 72, 134, 247, 13, 1, 1, 12, 42, 134, 72, 134, 247, 13, 1, 1, 13, 42, 134, 72, 134, 247, 13, 1, 5, 3, 42, 134, 72, 134, 247, 13, 1, 5, 10, 42, 134, 72, 134, 247, 13, 1, 5, 11, 42, 134, 72, 134, 247, 13, 1, 5, 12, 42, 134, 72, 134, 247, 13, 1, 5, 13, 42, 134, 72, 134, 247, 13, 1, 7, 1, 42, 134, 72, 134, 247, 13, 1, 7, 2, 42, 134, 72, 134, 247, 13, 1, 7, 3, 42, 134, 72, 134, 247, 13, 1, 7, 6, 42, 134, 72, 134, 247, 13, 1, 9, 1, 42, 134, 72, 134, 247, 13, 1, 9, 3, 42, 134, 72, 134, 247, 13, 1, 9, 4, 42, 134, 72, 134, 247, 13, 1, 9, 5, 42, 134, 72, 134, 247, 13, 1, 9, 6, 42, 134, 72, 134, 247, 13, 1, 9, 7, 42, 134, 72, 134, 247, 13, 1, 9, 14, 42, 134, 72, 134, 247, 13, 1, 9, 15, 42, 134, 72, 134, 247, 13, 1, 9, 16, 1, 4, 42, 134, 72, 134, 247, 13, 1, 9, 16, 2, 12, 42, 134, 72, 134, 247, 13, 1, 9, 16, 2, 14, 42, 134, 72, 134, 247, 13, 1, 9, 16, 2, 47, 42, 134, 72, 134, 247, 13, 1, 9, 20, 42, 134, 72, 134, 247, 13, 1, 9, 21, 42, 134, 72, 134, 247, 13, 1, 9, 22, 1, 42, 134, 72, 134, 247, 13, 1, 12, 1, 3, 42, 134, 72, 134, 247, 13, 1, 12, 1, 5, 42, 134, 72, 134, 247, 13, 1, 12, 1, 6, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 1, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 2, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 3, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 5, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 6, 42, 134, 72, 134, 247, 13, 2, 5, 42, 134, 72, 134, 247, 13, 2, 7, 42, 134, 72, 134, 247, 13, 2, 9, 42, 134, 72, 134, 247, 13, 2, 10, 42, 134, 72, 134, 247, 13, 2, 11, 42, 134, 72, 134, 247, 13, 3, 2, 42, 134, 72, 134, 247, 13, 3, 7, 43, 6, 1, 4, 1, 130, 55, 17, 1, 43, 6, 1, 4, 1, 130, 55, 17, 3, 20, 43, 6, 1, 4, 1, 130, 55, 20, 2, 3, 43, 6, 1, 4, 1, 130, 55, 88, 2, 1, 43, 6, 1, 4, 1, 130, 55, 88, 2, 2, 43, 6, 1, 5, 5, 7, 3, 1, 43, 6, 1, 5, 5, 7, 3, 2, 43, 6, 1, 5, 5, 7, 3, 3, 43, 6, 1, 5, 5, 7, 3, 4, 43, 6, 1, 5, 5, 7, 3, 8, 43, 6, 1, 5, 5, 7, 3, 9, 43, 6, 1, 5, 5, 7, 6, 2, 43, 6, 1, 5, 5, 7, 48, 1, 43, 6, 1, 5, 5, 7, 48, 1, 2, 43, 6, 1, 5, 5, 7, 48, 2, 43, 14, 3, 2, 26, 43, 14, 3, 2, 7, 43, 129, 4, 0, 34, 43, 129, 4, 0, 35, 85, 4, 3, 85, 4, 5, 85, 4, 6, 85, 4, 7, 85, 4, 8, 85, 4, 10, 85, 4, 11, 85, 4, 97, 85, 29, 14, 85, 29, 15, 85, 29, 17, 85, 29, 19, 85, 29, 20, 85, 29, 35, 96, 134, 72, 1, 101, 3, 4, 1, 2, 96, 134, 72, 1, 101, 3, 4, 1, 22, 96, 134, 72, 1, 101, 3, 4, 1, 42, 96, 134, 72, 1, 101, 3, 4, 2, 1, 96, 134, 72, 1, 101, 3, 4, 2, 2, 96, 134, 72, 1, 101, 3, 4, 2, 3, 103, 129, 12, 1, 2, 1, 103, 129, 12, 1, 2, 2 ]);
                return (() =>
                {
                    if (value === "1.2.840.10040.4.1")
                    {
                        return data.Slice(0, 7);
                    }
                    if (value === "1.2.840.10040.4.3")
                    {
                        return data.Slice(7, 7);
                    }
                    if (value === "1.2.840.10045.2.1")
                    {
                        return data.Slice(14, 7);
                    }
                    if (value === "1.2.840.10045.1.1")
                    {
                        return data.Slice(21, 7);
                    }
                    if (value === "1.2.840.10045.1.2")
                    {
                        return data.Slice(28, 7);
                    }
                    if (value === "1.2.840.10045.3.1.7")
                    {
                        return data.Slice(35, 8);
                    }
                    if (value === "1.2.840.10045.4.1")
                    {
                        return data.Slice(43, 7);
                    }
                    if (value === "1.2.840.10045.4.3.2")
                    {
                        return data.Slice(50, 8);
                    }
                    if (value === "1.2.840.10045.4.3.3")
                    {
                        return data.Slice(58, 8);
                    }
                    if (value === "1.2.840.10045.4.3.4")
                    {
                        return data.Slice(66, 8);
                    }
                    if (value === "1.2.840.113549.1.1.1")
                    {
                        return data.Slice(74, 9);
                    }
                    if (value === "1.2.840.113549.1.1.5")
                    {
                        return data.Slice(83, 9);
                    }
                    if (value === "1.2.840.113549.1.1.7")
                    {
                        return data.Slice(92, 9);
                    }
                    if (value === "1.2.840.113549.1.1.8")
                    {
                        return data.Slice(101, 9);
                    }
                    if (value === "1.2.840.113549.1.1.9")
                    {
                        return data.Slice(110, 9);
                    }
                    if (value === "1.2.840.113549.1.1.10")
                    {
                        return data.Slice(119, 9);
                    }
                    if (value === "1.2.840.113549.1.1.11")
                    {
                        return data.Slice(128, 9);
                    }
                    if (value === "1.2.840.113549.1.1.12")
                    {
                        return data.Slice(137, 9);
                    }
                    if (value === "1.2.840.113549.1.1.13")
                    {
                        return data.Slice(146, 9);
                    }
                    if (value === "1.2.840.113549.1.5.3")
                    {
                        return data.Slice(155, 9);
                    }
                    if (value === "1.2.840.113549.1.5.10")
                    {
                        return data.Slice(164, 9);
                    }
                    if (value === "1.2.840.113549.1.5.11")
                    {
                        return data.Slice(173, 9);
                    }
                    if (value === "1.2.840.113549.1.5.12")
                    {
                        return data.Slice(182, 9);
                    }
                    if (value === "1.2.840.113549.1.5.13")
                    {
                        return data.Slice(191, 9);
                    }
                    if (value === "1.2.840.113549.1.7.1")
                    {
                        return data.Slice(200, 9);
                    }
                    if (value === "1.2.840.113549.1.7.2")
                    {
                        return data.Slice(209, 9);
                    }
                    if (value === "1.2.840.113549.1.7.3")
                    {
                        return data.Slice(218, 9);
                    }
                    if (value === "1.2.840.113549.1.7.6")
                    {
                        return data.Slice(227, 9);
                    }
                    if (value === "1.2.840.113549.1.9.1")
                    {
                        return data.Slice(236, 9);
                    }
                    if (value === "1.2.840.113549.1.9.3")
                    {
                        return data.Slice(245, 9);
                    }
                    if (value === "1.2.840.113549.1.9.4")
                    {
                        return data.Slice(254, 9);
                    }
                    if (value === "1.2.840.113549.1.9.5")
                    {
                        return data.Slice(263, 9);
                    }
                    if (value === "1.2.840.113549.1.9.6")
                    {
                        return data.Slice(272, 9);
                    }
                    if (value === "1.2.840.113549.1.9.7")
                    {
                        return data.Slice(281, 9);
                    }
                    if (value === "1.2.840.113549.1.9.14")
                    {
                        return data.Slice(290, 9);
                    }
                    if (value === "1.2.840.113549.1.9.15")
                    {
                        return data.Slice(299, 9);
                    }
                    if (value === "1.2.840.113549.1.9.16.1.4")
                    {
                        return data.Slice(308, 11);
                    }
                    if (value === "1.2.840.113549.1.9.16.2.12")
                    {
                        return data.Slice(319, 11);
                    }
                    if (value === "1.2.840.113549.1.9.16.2.14")
                    {
                        return data.Slice(330, 11);
                    }
                    if (value === "1.2.840.113549.1.9.16.2.47")
                    {
                        return data.Slice(341, 11);
                    }
                    if (value === "1.2.840.113549.1.9.20")
                    {
                        return data.Slice(352, 9);
                    }
                    if (value === "1.2.840.113549.1.9.21")
                    {
                        return data.Slice(361, 9);
                    }
                    if (value === "1.2.840.113549.1.9.22.1")
                    {
                        return data.Slice(370, 10);
                    }
                    if (value === "1.2.840.113549.1.12.1.3")
                    {
                        return data.Slice(380, 10);
                    }
                    if (value === "1.2.840.113549.1.12.1.5")
                    {
                        return data.Slice(390, 10);
                    }
                    if (value === "1.2.840.113549.1.12.1.6")
                    {
                        return data.Slice(400, 10);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.1")
                    {
                        return data.Slice(410, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.2")
                    {
                        return data.Slice(421, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.3")
                    {
                        return data.Slice(432, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.5")
                    {
                        return data.Slice(443, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.6")
                    {
                        return data.Slice(454, 11);
                    }
                    if (value === "1.2.840.113549.2.5")
                    {
                        return data.Slice(465, 8);
                    }
                    if (value === "1.2.840.113549.2.7")
                    {
                        return data.Slice(473, 8);
                    }
                    if (value === "1.2.840.113549.2.9")
                    {
                        return data.Slice(481, 8);
                    }
                    if (value === "1.2.840.113549.2.10")
                    {
                        return data.Slice(489, 8);
                    }
                    if (value === "1.2.840.113549.2.11")
                    {
                        return data.Slice(497, 8);
                    }
                    if (value === "1.2.840.113549.3.2")
                    {
                        return data.Slice(505, 8);
                    }
                    if (value === "1.2.840.113549.3.7")
                    {
                        return data.Slice(513, 8);
                    }
                    if (value === "1.3.6.1.4.1.311.17.1")
                    {
                        return data.Slice(521, 9);
                    }
                    if (value === "1.3.6.1.4.1.311.17.3.20")
                    {
                        return data.Slice(530, 10);
                    }
                    if (value === "1.3.6.1.4.1.311.20.2.3")
                    {
                        return data.Slice(540, 10);
                    }
                    if (value === "1.3.6.1.4.1.311.88.2.1")
                    {
                        return data.Slice(550, 10);
                    }
                    if (value === "1.3.6.1.4.1.311.88.2.2")
                    {
                        return data.Slice(560, 10);
                    }
                    if (value === "1.3.6.1.5.5.7.3.1")
                    {
                        return data.Slice(570, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.2")
                    {
                        return data.Slice(578, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.3")
                    {
                        return data.Slice(586, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.4")
                    {
                        return data.Slice(594, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.8")
                    {
                        return data.Slice(602, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.9")
                    {
                        return data.Slice(610, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.6.2")
                    {
                        return data.Slice(618, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.48.1")
                    {
                        return data.Slice(626, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.48.1.2")
                    {
                        return data.Slice(634, 9);
                    }
                    if (value === "1.3.6.1.5.5.7.48.2")
                    {
                        return data.Slice(643, 8);
                    }
                    if (value === "1.3.14.3.2.26")
                    {
                        return data.Slice(651, 5);
                    }
                    if (value === "1.3.14.3.2.7")
                    {
                        return data.Slice(656, 5);
                    }
                    if (value === "1.3.132.0.34")
                    {
                        return data.Slice(661, 5);
                    }
                    if (value === "1.3.132.0.35")
                    {
                        return data.Slice(666, 5);
                    }
                    if (value === "2.5.4.3")
                    {
                        return data.Slice(671, 3);
                    }
                    if (value === "2.5.4.5")
                    {
                        return data.Slice(674, 3);
                    }
                    if (value === "2.5.4.6")
                    {
                        return data.Slice(677, 3);
                    }
                    if (value === "2.5.4.7")
                    {
                        return data.Slice(680, 3);
                    }
                    if (value === "2.5.4.8")
                    {
                        return data.Slice(683, 3);
                    }
                    if (value === "2.5.4.10")
                    {
                        return data.Slice(686, 3);
                    }
                    if (value === "2.5.4.11")
                    {
                        return data.Slice(689, 3);
                    }
                    if (value === "2.5.4.97")
                    {
                        return data.Slice(692, 3);
                    }
                    if (value === "2.5.29.14")
                    {
                        return data.Slice(695, 3);
                    }
                    if (value === "2.5.29.15")
                    {
                        return data.Slice(698, 3);
                    }
                    if (value === "2.5.29.17")
                    {
                        return data.Slice(701, 3);
                    }
                    if (value === "2.5.29.19")
                    {
                        return data.Slice(704, 3);
                    }
                    if (value === "2.5.29.20")
                    {
                        return data.Slice(707, 3);
                    }
                    if (value === "2.5.29.35")
                    {
                        return data.Slice(710, 3);
                    }
                    if (value === "2.16.840.1.101.3.4.1.2")
                    {
                        return data.Slice(713, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.1.22")
                    {
                        return data.Slice(722, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.1.42")
                    {
                        return data.Slice(731, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.2.1")
                    {
                        return data.Slice(740, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.2.2")
                    {
                        return data.Slice(749, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.2.3")
                    {
                        return data.Slice(758, 9);
                    }
                    if (value === "2.23.140.1.2.1")
                    {
                        return data.Slice(767, 6);
                    }
                    if (value === "2.23.140.1.2.2")
                    {
                        return data.Slice(773, 6);
                    }
                    return $.$$.System.ReadOnlySpan$$($.$$.System.Byte).Empty;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(4296671251)
            
            static $h = 1703955;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591638547),
    {
      "r": 1310721,
      "p": [
        {
          "n": "contents",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "GetValue",
      "d": 1703955,
      "h": 8591638547,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591638547),
//--TRIMMABLE-BOUNDARY-START(4296671251),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "GetContents",
      "d": 1703955,
      "h": 4296671251,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296671251)
  ],
  "h": 1703955
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.WellKnownOids`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703955)
        
        
        //--TRIMMABLE-BOUNDARY-START(655379)
        $asm.$str("$sfa.System.Formats.Asn1.AsnReaderOptions", ($self) => class AsnReaderOptions extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17180524563)
            /*int*/ static DefaultTwoDigitMax = 2049;
            //--TRIMMABLE-BOUNDARY-END(17180524563)
            
            //--TRIMMABLE-BOUNDARY-START(4295622675)
            /*ushort*/  get _twoDigitYearMax() { return this.$getField(0, 2); }
            /*ushort*/  set _twoDigitYearMax(value) { this.$setField(0, 2, value); }
            //--TRIMMABLE-BOUNDARY-END(4295622675)
            
            //--TRIMMABLE-BOUNDARY-START(60130197523)
            /*int */ get UtcTimeTwoDigitYearMax()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360393747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._twoDigitYearMax === 0)
                {
                    return 2049/*DefaultTwoDigitMax*/;
                }
                return this._twoDigitYearMax;
            }
            /*int */ set UtcTimeTwoDigitYearMax(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540262931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 1 || value > 9999)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("value");
                }
                this._twoDigitYearMax = $.$cast(value, $.$$.System.UInt16);
            }
            //--TRIMMABLE-BOUNDARY-END(60130197523)
            
            //--TRIMMABLE-BOUNDARY-START(55835230227)
            /*bool*/ SkipSetSortOrderVerification = false;
            //--TRIMMABLE-BOUNDARY-END(55835230227)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._twoDigitYearMax = this._twoDigitYearMax;
                copy.SkipSetSortOrderVerification = this.SkipSetSortOrderVerification;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295622675)
                this._twoDigitYearMax = 0;
                //--TRIMMABLE-BOUNDARY-END(4295622675)
                
            }
            static $h = 655379;
            static $z = 3;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130197523),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360393747,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540262931,
        "f": 83886081
      },
      "n": "UtcTimeTwoDigitYearMax",
      "d": 655379,
      "h": 60130197523,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130197523),
//--TRIMMABLE-BOUNDARY-START(55835230227),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770459155,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950328339,
        "f": 83886081
      },
      "n": "SkipSetSortOrderVerification",
      "d": 655379,
      "h": 55835230227,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835230227)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180524563),
    {
      "t": 655361,
      "n": "DefaultTwoDigitMax",
      "d": 655379,
      "h": 17180524563,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180524563),
//--TRIMMABLE-BOUNDARY-START(4295622675),
    {
      "t": 589825,
      "n": "_twoDigitYearMax",
      "d": 655379,
      "h": 4295622675,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622675)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590589971),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655379,
      "h": 8590589971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590589971)
  ],
  "h": 655379
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Formats.Asn1.AsnReaderOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655379)
        
        
        //--TRIMMABLE-BOUNDARY-START(65555)
        $asm.$str("$sfa.System.Formats.Asn1.Asn1Tag", ($self) => class Asn1Tag extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(81604444179)
            /*Asn1Tag*/ static EndOfContents;
            //--TRIMMABLE-BOUNDARY-END(81604444179)
            
            //--TRIMMABLE-BOUNDARY-START(42949738515)
            /*Asn1Tag*/ static Boolean;
            //--TRIMMABLE-BOUNDARY-END(42949738515)
            
            //--TRIMMABLE-BOUNDARY-START(137439019027)
            /*Asn1Tag*/ static Integer;
            //--TRIMMABLE-BOUNDARY-END(137439019027)
            
            //--TRIMMABLE-BOUNDARY-START(163208822803)
            /*Asn1Tag*/ static PrimitiveBitString;
            //--TRIMMABLE-BOUNDARY-END(163208822803)
            
            //--TRIMMABLE-BOUNDARY-START(55834640403)
            /*Asn1Tag*/ static ConstructedBitString;
            //--TRIMMABLE-BOUNDARY-END(55834640403)
            
            //--TRIMMABLE-BOUNDARY-START(167503790099)
            /*Asn1Tag*/ static PrimitiveOctetString;
            //--TRIMMABLE-BOUNDARY-END(167503790099)
            
            //--TRIMMABLE-BOUNDARY-START(64424574995)
            /*Asn1Tag*/ static ConstructedOctetString;
            //--TRIMMABLE-BOUNDARY-END(64424574995)
            
            //--TRIMMABLE-BOUNDARY-START(146028953619)
            /*Asn1Tag*/ static Null;
            //--TRIMMABLE-BOUNDARY-END(146028953619)
            
            //--TRIMMABLE-BOUNDARY-START(150323920915)
            /*Asn1Tag*/ static ObjectIdentifier;
            //--TRIMMABLE-BOUNDARY-END(150323920915)
            
            //--TRIMMABLE-BOUNDARY-START(85899411475)
            /*Asn1Tag*/ static Enumerated;
            //--TRIMMABLE-BOUNDARY-END(85899411475)
            
            //--TRIMMABLE-BOUNDARY-START(171798757395)
            /*Asn1Tag*/ static Sequence;
            //--TRIMMABLE-BOUNDARY-END(171798757395)
            
            //--TRIMMABLE-BOUNDARY-START(176093724691)
            /*Asn1Tag*/ static SetOf;
            //--TRIMMABLE-BOUNDARY-END(176093724691)
            
            //--TRIMMABLE-BOUNDARY-START(206158495763)
            /*Asn1Tag*/ static UtcTime;
            //--TRIMMABLE-BOUNDARY-END(206158495763)
            
            //--TRIMMABLE-BOUNDARY-START(98784313363)
            /*Asn1Tag*/ static GeneralizedTime;
            //--TRIMMABLE-BOUNDARY-END(98784313363)
            
            //--TRIMMABLE-BOUNDARY-START(51539673107)
            /*byte*/ static ClassMask = 192;
            //--TRIMMABLE-BOUNDARY-END(51539673107)
            
            //--TRIMMABLE-BOUNDARY-START(60129607699)
            /*byte*/ static ConstructedMask = 32;
            //--TRIMMABLE-BOUNDARY-END(60129607699)
            
            //--TRIMMABLE-BOUNDARY-START(68719542291)
            /*byte*/ static ControlMask = 224;
            //--TRIMMABLE-BOUNDARY-END(68719542291)
            
            //--TRIMMABLE-BOUNDARY-START(184683659283)
            /*byte*/ static TagNumberMask = 31;
            //--TRIMMABLE-BOUNDARY-END(184683659283)
            
            //--TRIMMABLE-BOUNDARY-START(4295032851)
            /*byte*/  get _controlFlags() { return this.$getField(0, $.$$.System.Byte); }
            /*byte*/  set _controlFlags(value) { this.$setField(0, $.$$.System.Byte, value); }
            //--TRIMMABLE-BOUNDARY-END(4295032851)
            
            //--TRIMMABLE-BOUNDARY-START(180388691987)
            /*TagClass */ get TagClass()
            {
                return $.$cast((this._controlFlags & 192/*ClassMask*/), $.$sfa.System.Formats.Asn1.TagClass);
            }
            //--TRIMMABLE-BOUNDARY-END(180388691987)
            
            //--TRIMMABLE-BOUNDARY-START(141733986323)
            /*bool */ get IsConstructed()
            {
                return (this._controlFlags & 32/*ConstructedMask*/) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(141733986323)
            
            //--TRIMMABLE-BOUNDARY-START(188978626579)
            /*int*/ TagValue = 0;
            //--TRIMMABLE-BOUNDARY-END(188978626579)
            
            //--TRIMMABLE-BOUNDARY-START(12884967443)
            $ctor$3(/*byte*/ controlFlags, /*int*/ tagValue)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967443);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._controlFlags = $.$cast((controlFlags & 224/*ControlMask*/), $.$$.System.Byte);
                    this.TagValue = tagValue;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967443)
            
            //--TRIMMABLE-BOUNDARY-START(17179934739)
            $ctor$5(/*UniversalTagNumber*/ universalTagNumber, /*bool*/ isConstructed)
            {
                this.$ctor$3(isConstructed ? 32/*ConstructedMask*/ : 0, universalTagNumber);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17179934739);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*UniversalTagNumber*/ let ReservedIndex = $.$cast(15, $.$sfa.System.Formats.Asn1.UniversalTagNumber);
                    if (universalTagNumber < 0/*UniversalTagNumber.EndOfContents*/ || universalTagNumber > 36/*UniversalTagNumber.RelativeObjectIdentifierIRI*/ || universalTagNumber === ReservedIndex)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("universalTagNumber");
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17179934739)
            
            //--TRIMMABLE-BOUNDARY-START(21474902035)
            $ctor$4(/*TagClass*/ tagClass, /*int*/ tagValue, /*bool*/ isConstructed)
            {
                this.$ctor$3($.$cast(($.$cast(tagClass, $.$$.System.Byte) | (isConstructed ? 32/*ConstructedMask*/ : 0)), $.$$.System.Byte), tagValue);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21474902035);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    switch(tagClass)
                    {
                        case 0/*TagClass.Universal*/:
                        case 128/*TagClass.ContextSpecific*/:
                        case 64/*TagClass.Application*/:
                        case 192/*TagClass.Private*/:
                        break;
                        default:
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("tagClass");
                    }
                    if (tagValue < 0)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("tagValue");
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902035)
            
            //--TRIMMABLE-BOUNDARY-START(34359803923)
            /*Asn1Tag */ AsConstructed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3($.$cast((this._controlFlags | 32/*ConstructedMask*/), $.$$.System.Byte), this.TagValue);
            }
            //--TRIMMABLE-BOUNDARY-END(34359803923)
            
            //--TRIMMABLE-BOUNDARY-START(38654771219)
            /*Asn1Tag */ AsPrimitive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3($.$cast((this._controlFlags & ~32/*ConstructedMask*/), $.$$.System.Byte), this.TagValue);
            }
            //--TRIMMABLE-BOUNDARY-END(38654771219)
            
            //--TRIMMABLE-BOUNDARY-START(197568561171)
            static /*bool */ TryDecode(/*ReadOnlySpan<byte>*/ source, /*out Asn1Tag*/ tag, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568561171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                tag.$v = $.$default($.$sfa.System.Formats.Asn1.Asn1Tag);
                bytesConsumed.$v = 0;
                if (source.IsEmpty)
                {
                    return false;
                }
                /*byte*/ let first = source.get_Item(bytesConsumed.$v).$v;
                bytesConsumed.$v++;
                /*uint*/ let tagValue = ((first & 31/*TagNumberMask*/) >>> 0);
                if (tagValue === 31/*TagNumberMask*/)
                {
                    /*byte*/ let ContinuationFlag = 128;
                    /*byte*/ let ValueMask = ((ContinuationFlag - 1) | 0);
                    tagValue = 0;
                    /*byte*/ let current;
                    do
                    {
                        if (source.Length <= bytesConsumed.$v)
                        {
                            bytesConsumed.$v = 0;
                            return false;
                        }
                        current = source.get_Item(bytesConsumed.$v).$v;
                        /*byte*/ let currentValue = $.$cast((current & ValueMask), $.$$.System.Byte);
                        bytesConsumed.$v++;
                        /*int*/ let TooBigToShift = 33554432;
                        if (tagValue >= TooBigToShift)
                        {
                            bytesConsumed.$v = 0;
                            return false;
                        }
                        tagValue <<= 7;
                        tagValue |= currentValue;
                        if (tagValue === 0)
                        {
                            bytesConsumed.$v = 0;
                            return false;
                        }
                    }
                    while((current & ContinuationFlag) === ContinuationFlag);
                    if (tagValue <= 30)
                    {
                        bytesConsumed.$v = 0;
                        return false;
                    }
                    if (tagValue > 2147483647/*int.MaxValue*/)
                    {
                        bytesConsumed.$v = 0;
                        return false;
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(bytesConsumed.$v > 0, "bytesConsumed > 0");
                tag.$v = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(first, (tagValue | 0));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(197568561171)
            
            //--TRIMMABLE-BOUNDARY-START(73014509587)
            static /*Asn1Tag */ Decode(/*ReadOnlySpan<byte>*/ source, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014509587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Asn1Tag*/ let tag;
                if ($.$sfa.System.Formats.Asn1.Asn1Tag.TryDecode(source, $.$ref(() => tag, ($v) => tag = $v, $.$sfa.System.Formats.Asn1.Asn1Tag), bytesConsumed))
                {
                    return tag;
                }
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidTag);
            }
            //--TRIMMABLE-BOUNDARY-END(73014509587)
            
            //--TRIMMABLE-BOUNDARY-START(47244705811)
            /*int */ CalculateEncodedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let SevenBits = 127;
                /*int*/ let FourteenBits = 16383;
                /*int*/ let TwentyOneBits = 2097151;
                /*int*/ let TwentyEightBits = 268435455;
                if (this.TagValue < 31/*TagNumberMask*/)
                {
                    return 1;
                }
                if (this.TagValue <= SevenBits)
                {
                    return 2;
                }
                if (this.TagValue <= FourteenBits)
                {
                    return 3;
                }
                if (this.TagValue <= TwentyOneBits)
                {
                    return 4;
                }
                if (this.TagValue <= TwentyEightBits)
                {
                    return 5;
                }
                return 6;
            }
            //--TRIMMABLE-BOUNDARY-END(47244705811)
            
            //--TRIMMABLE-BOUNDARY-START(201863528467)
            /*bool */ TryEncode(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863528467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let spaceRequired = this.CalculateEncodedSize();
                if (destination.Length < spaceRequired)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                if (spaceRequired === 1)
                {
                    /*byte*/ let value = $.$cast((this._controlFlags | this.TagValue), $.$$.System.Byte);
                    destination.get_Item(0).$v = value;
                    bytesWritten.$v = 1;
                    return true;
                }
                /*byte*/ let firstByte = $.$cast((this._controlFlags | 31/*TagNumberMask*/), $.$$.System.Byte);
                destination.get_Item(0).$v = firstByte;
                /*int*/ let remaining = this.TagValue;
                /*int*/ let idx = ((spaceRequired - 1) | 0);
                while(remaining > 0)
                {
                    /*int*/ let segment = remaining & 127;
                    if (remaining !== this.TagValue)
                    {
                        segment |= 128;
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(segment <= 255/*byte.MaxValue*/, "segment <= byte.MaxValue");
                    destination.get_Item(idx).$v = $.$cast(segment, $.$$.System.Byte);
                    remaining >>= 7;
                    idx--;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(idx === 0, "idx == 0");
                bytesWritten.$v = spaceRequired;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(201863528467)
            
            //--TRIMMABLE-BOUNDARY-START(77309476883)
            /*int */ Encode(/*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309476883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let bytesWritten;
                if (this.TryEncode(destination, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32)))
                {
                    return bytesWritten;
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_DestinationTooShort, "destination");
            }
            //--TRIMMABLE-BOUNDARY-END(77309476883)
            
            //--TRIMMABLE-BOUNDARY-START(90194378771)
            /*bool */ Equals$2(/*Asn1Tag*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194378771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._controlFlags === other._controlFlags && this.TagValue === other.TagValue;
            }
            //--TRIMMABLE-BOUNDARY-END(90194378771)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 94489346067, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489346067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let tag;
                return $.$is(obj, $.$sfa.System.Formats.Asn1.Asn1Tag, { set $v(v){ tag = v; } }) && this.Equals$2(tag);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sfa.System.Formats.Asn1.Asn1Tag.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 94489346067, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 128849084435, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849084435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ((this._controlFlags << 24) >>> 0) ^ this.TagValue;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sfa.System.Formats.Asn1.Asn1Tag.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 128849084435, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(154618888211)
            static /*bool */ op_Equality(/*Asn1Tag*/ left, /*Asn1Tag*/ right)
            {
                return left.Equals$2(right);
            }
            //--TRIMMABLE-BOUNDARY-END(154618888211)
            
            //--TRIMMABLE-BOUNDARY-START(158913855507)
            static /*bool */ op_Inequality(/*Asn1Tag*/ left, /*Asn1Tag*/ right)
            {
                return !left.Equals$2(right);
            }
            //--TRIMMABLE-BOUNDARY-END(158913855507)
            
            //--TRIMMABLE-BOUNDARY-START(133144051731)
            /*bool */ HasSameClassAndValue(/*Asn1Tag*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144051731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TagValue === other.TagValue && this.TagClass === other.TagClass;
            }
            //--TRIMMABLE-BOUNDARY-END(133144051731)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 193273593875, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273593875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let ConstructedPrefix = "Constructed ";
                /*string*/ let classAndValue;
                if (this.TagClass === 0/*TagClass.Universal*/)
                {
                    classAndValue = $.$$.System.Enum.ToStringT($.$sfa.System.Formats.Asn1.UniversalTagNumber, $.$$.System.UInt32, ($.$cast(this.TagValue, $.$sfa.System.Formats.Asn1.UniversalTagNumber)));
                }
                else 
                {
                    classAndValue = `${this.TagClass}-${this.TagValue}`;
                }
                if (this.IsConstructed)
                {
                    return ConstructedPrefix + classAndValue;
                }
                return classAndValue;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sfa.System.Formats.Asn1.Asn1Tag.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 193273593875, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(4385210369)
            //Generated interface implemetation for System.IEquatable<System.Formats.Asn1.Asn1Tag>.Equals(System.Formats.Asn1.Asn1Tag)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385210369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385210369)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._controlFlags = this._controlFlags;
                copy.TagValue = this.TagValue;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295032851)
                this._controlFlags = 0;
                //--TRIMMABLE-BOUNDARY-END(4295032851)
                
            }
            //--TRIMMABLE-BOUNDARY-START(8590000147)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(81604444179)
                    this.EndOfContents = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 0/*UniversalTagNumber.EndOfContents*/);
                    //--TRIMMABLE-BOUNDARY-END(81604444179)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949738515)
                    this.Boolean = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 1/*UniversalTagNumber.Boolean*/);
                    //--TRIMMABLE-BOUNDARY-END(42949738515)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439019027)
                    this.Integer = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 2/*UniversalTagNumber.Integer*/);
                    //--TRIMMABLE-BOUNDARY-END(137439019027)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163208822803)
                    this.PrimitiveBitString = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 3/*UniversalTagNumber.BitString*/);
                    //--TRIMMABLE-BOUNDARY-END(163208822803)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834640403)
                    this.ConstructedBitString = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(32/*ConstructedMask*/, 3/*UniversalTagNumber.BitString*/);
                    //--TRIMMABLE-BOUNDARY-END(55834640403)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167503790099)
                    this.PrimitiveOctetString = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 4/*UniversalTagNumber.OctetString*/);
                    //--TRIMMABLE-BOUNDARY-END(167503790099)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424574995)
                    this.ConstructedOctetString = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(32/*ConstructedMask*/, 4/*UniversalTagNumber.OctetString*/);
                    //--TRIMMABLE-BOUNDARY-END(64424574995)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146028953619)
                    this.Null = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 5/*UniversalTagNumber.Null*/);
                    //--TRIMMABLE-BOUNDARY-END(146028953619)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150323920915)
                    this.ObjectIdentifier = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 6/*UniversalTagNumber.ObjectIdentifier*/);
                    //--TRIMMABLE-BOUNDARY-END(150323920915)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899411475)
                    this.Enumerated = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 10/*UniversalTagNumber.Enumerated*/);
                    //--TRIMMABLE-BOUNDARY-END(85899411475)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171798757395)
                    this.Sequence = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(32/*ConstructedMask*/, 16/*UniversalTagNumber.Sequence*/);
                    //--TRIMMABLE-BOUNDARY-END(171798757395)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176093724691)
                    this.SetOf = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(32/*ConstructedMask*/, 17/*UniversalTagNumber.SetOf*/);
                    //--TRIMMABLE-BOUNDARY-END(176093724691)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158495763)
                    this.UtcTime = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 23/*UniversalTagNumber.UtcTime*/);
                    //--TRIMMABLE-BOUNDARY-END(206158495763)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784313363)
                    this.GeneralizedTime = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 24/*UniversalTagNumber.GeneralizedTime*/);
                    //--TRIMMABLE-BOUNDARY-END(98784313363)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000147)
            
            static $h = 65555;
            static $z = 5;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(180388691987),
    {
      "p": 1507347,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964182547,
        "f": 50331649
      },
      "n": "TagClass",
      "d": 65555,
      "h": 180388691987,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180388691987),
//--TRIMMABLE-BOUNDARY-START(141733986323),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374247955,
        "f": 50331649
      },
      "n": "IsConstructed",
      "d": 65555,
      "h": 141733986323,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141733986323),
//--TRIMMABLE-BOUNDARY-START(188978626579),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554117139,
        "f": 50331649
      },
      "n": "TagValue",
      "d": 65555,
      "h": 188978626579,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188978626579)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34359803923),
    {
      "r": 65555,
      "n": "AsConstructed",
      "d": 65555,
      "h": 34359803923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359803923),
//--TRIMMABLE-BOUNDARY-START(38654771219),
    {
      "r": 65555,
      "n": "AsPrimitive",
      "d": 65555,
      "h": 38654771219,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654771219),
//--TRIMMABLE-BOUNDARY-START(197568561171),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "tag",
          "p": 65555,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecode",
      "d": 65555,
      "h": 197568561171,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(197568561171),
//--TRIMMABLE-BOUNDARY-START(73014509587),
    {
      "r": 65555,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "Decode",
      "d": 65555,
      "h": 73014509587,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73014509587),
//--TRIMMABLE-BOUNDARY-START(47244705811),
    {
      "r": 655361,
      "n": "CalculateEncodedSize",
      "d": 65555,
      "h": 47244705811,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244705811),
//--TRIMMABLE-BOUNDARY-START(201863528467),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryEncode",
      "d": 65555,
      "h": 201863528467,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201863528467),
//--TRIMMABLE-BOUNDARY-START(77309476883),
    {
      "r": 655361,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "Encode",
      "d": 65555,
      "h": 77309476883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309476883),
//--TRIMMABLE-BOUNDARY-START(90194378771),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 65555
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 65555,
      "h": 90194378771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194378771),
//--TRIMMABLE-BOUNDARY-START(ALL, 94489346067, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 65555,
      "h": 94489346067,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 94489346067, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 128849084435, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 65555,
      "h": 128849084435,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 128849084435, 184683724801),
//--TRIMMABLE-BOUNDARY-START(133144051731),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 65555
        }
      ],
      "n": "HasSameClassAndValue",
      "d": 65555,
      "h": 133144051731,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133144051731),
//--TRIMMABLE-BOUNDARY-START(ALL, 193273593875, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 65555,
      "h": 193273593875,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 193273593875, 330712612865)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81604444179),
    {
      "t": 65555,
      "n": "EndOfContents",
      "d": 65555,
      "h": 81604444179,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81604444179),
//--TRIMMABLE-BOUNDARY-START(42949738515),
    {
      "t": 65555,
      "n": "Boolean",
      "d": 65555,
      "h": 42949738515,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949738515),
//--TRIMMABLE-BOUNDARY-START(137439019027),
    {
      "t": 65555,
      "n": "Integer",
      "d": 65555,
      "h": 137439019027,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439019027),
//--TRIMMABLE-BOUNDARY-START(163208822803),
    {
      "t": 65555,
      "n": "PrimitiveBitString",
      "d": 65555,
      "h": 163208822803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163208822803),
//--TRIMMABLE-BOUNDARY-START(55834640403),
    {
      "t": 65555,
      "n": "ConstructedBitString",
      "d": 65555,
      "h": 55834640403,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834640403),
//--TRIMMABLE-BOUNDARY-START(167503790099),
    {
      "t": 65555,
      "n": "PrimitiveOctetString",
      "d": 65555,
      "h": 167503790099,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167503790099),
//--TRIMMABLE-BOUNDARY-START(64424574995),
    {
      "t": 65555,
      "n": "ConstructedOctetString",
      "d": 65555,
      "h": 64424574995,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424574995),
//--TRIMMABLE-BOUNDARY-START(146028953619),
    {
      "t": 65555,
      "n": "Null",
      "d": 65555,
      "h": 146028953619,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146028953619),
//--TRIMMABLE-BOUNDARY-START(150323920915),
    {
      "t": 65555,
      "n": "ObjectIdentifier",
      "d": 65555,
      "h": 150323920915,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150323920915),
//--TRIMMABLE-BOUNDARY-START(85899411475),
    {
      "t": 65555,
      "n": "Enumerated",
      "d": 65555,
      "h": 85899411475,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899411475),
//--TRIMMABLE-BOUNDARY-START(171798757395),
    {
      "t": 65555,
      "n": "Sequence",
      "d": 65555,
      "h": 171798757395,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171798757395),
//--TRIMMABLE-BOUNDARY-START(176093724691),
    {
      "t": 65555,
      "n": "SetOf",
      "d": 65555,
      "h": 176093724691,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176093724691),
//--TRIMMABLE-BOUNDARY-START(206158495763),
    {
      "t": 65555,
      "n": "UtcTime",
      "d": 65555,
      "h": 206158495763,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206158495763),
//--TRIMMABLE-BOUNDARY-START(98784313363),
    {
      "t": 65555,
      "n": "GeneralizedTime",
      "d": 65555,
      "h": 98784313363,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784313363),
//--TRIMMABLE-BOUNDARY-START(51539673107),
    {
      "t": 393217,
      "n": "ClassMask",
      "d": 65555,
      "h": 51539673107,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51539673107),
//--TRIMMABLE-BOUNDARY-START(60129607699),
    {
      "t": 393217,
      "n": "ConstructedMask",
      "d": 65555,
      "h": 60129607699,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60129607699),
//--TRIMMABLE-BOUNDARY-START(68719542291),
    {
      "t": 393217,
      "n": "ControlMask",
      "d": 65555,
      "h": 68719542291,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68719542291),
//--TRIMMABLE-BOUNDARY-START(184683659283),
    {
      "t": 393217,
      "n": "TagNumberMask",
      "d": 65555,
      "h": 184683659283,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(184683659283),
//--TRIMMABLE-BOUNDARY-START(4295032851),
    {
      "t": 393217,
      "n": "_controlFlags",
      "d": 65555,
      "h": 4295032851,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032851)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967443),
    {
      "p": [
        {
          "n": "controlFlags",
          "p": 393217
        },
        {
          "n": "tagValue",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65555,
      "h": 12884967443,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12884967443),
//--TRIMMABLE-BOUNDARY-START(17179934739),
    {
      "p": [
        {
          "n": "universalTagNumber",
          "p": 1572883
        },
        {
          "n": "isConstructed",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 65555,
      "h": 17179934739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934739),
//--TRIMMABLE-BOUNDARY-START(21474902035),
    {
      "p": [
        {
          "n": "tagClass",
          "p": 1507347
        },
        {
          "n": "tagValue",
          "p": 655361
        },
        {
          "n": "isConstructed",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 65555,
      "h": 21474902035,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474902035),
//--TRIMMABLE-BOUNDARY-START(25769869331),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65555,
      "h": 25769869331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769869331)
  ],
  "i": [$.$$.System.IEquatable$$($.$sfa.System.Formats.Asn1.Asn1Tag).$h
  ],
  "h": 65555
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sfa.System.Formats.Asn1.Asn1Tag) ]; }
            static get $fullName() { return `System.Formats.Asn1.Asn1Tag`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65555)
        
        
        //--TRIMMABLE-BOUNDARY-START(1900563)
        $asm.$str("$sfa.System.Security.Cryptography.CryptoPoolLease", ($self) => class CryptoPoolLease extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296867859)
            /*byte[]?*/  get _rented() { return this.$getField(0, 4); }
            /*byte[]?*/  set _rented(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4296867859)
            
            //--TRIMMABLE-BOUNDARY-START(8591835155)
            /*bool*/  get _skipClear() { return this.$getField(4, 1); }
            /*bool*/  set _skipClear(value) { this.$setField(4, 1, value); }
            //--TRIMMABLE-BOUNDARY-END(8591835155)
            
            //--TRIMMABLE-BOUNDARY-START(77311311891)
            /*Span<byte>*/ Span;
            //--TRIMMABLE-BOUNDARY-END(77311311891)
            
            //--TRIMMABLE-BOUNDARY-START(42951573523)
            /*bool */ get IsRented()
            {
                return !(this._rented === null);
            }
            //--TRIMMABLE-BOUNDARY-END(42951573523)
            
            //--TRIMMABLE-BOUNDARY-START(21476737043)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476737043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Return();
            }
            //--TRIMMABLE-BOUNDARY-END(21476737043)
            
            //--TRIMMABLE-BOUNDARY-START(60131442707)
            /*void */ Return()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131442707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Return$1(this._skipClear ? 0 : this.Span.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(60131442707)
            
            //--TRIMMABLE-BOUNDARY-START(64426410003)
            /*void */ Return$1(/*int*/ clearSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426410003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(this._rented === null))
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(this._rented, clearSize);
                    this._rented = null;
                }
                else if (!this._skipClear && clearSize > 0)
                {
                    /*Span<byte>*/ let toClear = this.Span.Slice(0, clearSize);
                    toClear.Clear();
                }
                this.Span = new ($.$$.System.Span$$($.$$.System.Byte))();
            }
            //--TRIMMABLE-BOUNDARY-END(64426410003)
            
            //--TRIMMABLE-BOUNDARY-START(47246540819)
            static /*CryptoPoolLease */ Rent(/*int*/ length, /*bool*/ skipClear)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246540819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let rented = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(length);
                return (() =>
                {
                    //new $.$sfa.System.Security.Cryptography.CryptoPoolLease()
                    const $t1 = $.$sfa.System.Security.Cryptography.CryptoPoolLease;
                    const $i1 = new $t1();
                    $i1._rented = rented;
                    $i1._skipClear = skipClear;
                    $i1.Span = new ($.$$.System.Span$$($.$$.System.Byte))().$ctor$3(rented, 0, length);
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(47246540819)
            
            //--TRIMMABLE-BOUNDARY-START(51541508115)
            static /*CryptoPoolLease */ RentConditionally(/*int*/ length, /*Span<byte>*/ currentBuffer, /*bool*/ skipClear, /*bool*/ skipClearIfNotRented)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541508115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Security.Cryptography.CryptoPoolLease.RentConditionally$1(length, currentBuffer, $.$discardRef(), skipClear, skipClearIfNotRented);
            }
            //--TRIMMABLE-BOUNDARY-END(51541508115)
            
            //--TRIMMABLE-BOUNDARY-START(55836475411)
            static /*CryptoPoolLease */ RentConditionally$1(/*int*/ length, /*Span<byte>*/ currentBuffer, /*out bool*/ rented, /*bool*/ skipClear, /*bool*/ skipClearIfNotRented)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836475411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (currentBuffer.Length >= length)
                {
                    rented.$v = false;
                    return (() =>
                    {
                        //new $.$sfa.System.Security.Cryptography.CryptoPoolLease()
                        const $t1 = $.$sfa.System.Security.Cryptography.CryptoPoolLease;
                        const $i1 = new $t1();
                        $i1._rented = null;
                        $i1._skipClear = skipClearIfNotRented || skipClear;
                        $i1.Span = currentBuffer.Slice(0, length);
                        return $i1;
                    })();
                }
                rented.$v = true;
                return $.$sfa.System.Security.Cryptography.CryptoPoolLease.Rent(length, skipClear);
            }
            //--TRIMMABLE-BOUNDARY-END(55836475411)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._rented = this._rented;
                copy._skipClear = this._skipClear;
                copy.Span = this.Span.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296867859)
                this._rented = null;
                //--TRIMMABLE-BOUNDARY-END(4296867859)
                
                //--TRIMMABLE-BOUNDARY-START(8591835155)
                this._skipClear = false;
                //--TRIMMABLE-BOUNDARY-END(8591835155)
                
                this.Span = $.$default($.$$.System.Span$$($.$$.System.Byte));
            }
            static $h = 1900563;
            static $z = 10;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311311891),
    {
      "p": $.$$.System.Span$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656606227,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016344595,
        "f": 83886082
      },
      "n": "Span",
      "d": 1900563,
      "h": 77311311891,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(77311311891),
//--TRIMMABLE-BOUNDARY-START(42951573523),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066671635,
        "f": 50331656
      },
      "n": "IsRented",
      "d": 1900563,
      "h": 42951573523,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(42951573523)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476737043),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1900563,
      "h": 21476737043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476737043),
//--TRIMMABLE-BOUNDARY-START(60131442707),
    {
      "r": 65537,
      "n": "Return",
      "d": 1900563,
      "h": 60131442707,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(60131442707),
//--TRIMMABLE-BOUNDARY-START(64426410003),
    {
      "r": 65537,
      "p": [
        {
          "n": "clearSize",
          "p": 655361
        }
      ],
      "n": "Return",
      "o": "@$1",
      "d": 1900563,
      "h": 64426410003,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64426410003),
//--TRIMMABLE-BOUNDARY-START(47246540819),
    {
      "r": 1900563,
      "p": [
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "skipClear",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "Rent",
      "d": 1900563,
      "h": 47246540819,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47246540819),
//--TRIMMABLE-BOUNDARY-START(51541508115),
    {
      "r": 1900563,
      "p": [
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "currentBuffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "skipClear",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "skipClearIfNotRented",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "RentConditionally",
      "d": 1900563,
      "h": 51541508115,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51541508115),
//--TRIMMABLE-BOUNDARY-START(55836475411),
    {
      "r": 1900563,
      "p": [
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "currentBuffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "rented",
          "p": 262145,
          "f": 2
        },
        {
          "n": "skipClear",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "skipClearIfNotRented",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "RentConditionally",
      "o": "@$1",
      "d": 1900563,
      "h": 55836475411,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55836475411)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296867859),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_rented",
      "d": 1900563,
      "h": 4296867859,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296867859),
//--TRIMMABLE-BOUNDARY-START(8591835155),
    {
      "t": 262145,
      "n": "_skipClear",
      "d": 1900563,
      "h": 8591835155,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591835155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886802451),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1900563,
      "h": 12886802451,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886802451)
  ],
  "i": [90177537
  ],
  "h": 1900563
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Security.Cryptography.CryptoPoolLease`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900563)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441811)
        $asm.$cls("$sfa.System.Formats.Asn1.T61Encoding", ($self) => class T61Encoding extends $.$$.System.Text.Encoding
        {
            //--TRIMMABLE-BOUNDARY-START(73015885843)
            /*UTF8Encoding*/ static s_utf8Encoding = null;
            //--TRIMMABLE-BOUNDARY-END(73015885843)
            
            //--TRIMMABLE-BOUNDARY-START(68720918547)
            /*Encoding*/ static s_latin1Encoding = null;
            //--TRIMMABLE-BOUNDARY-END(68720918547)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12886343699, 408187699201)
            /*int */ GetByteCount(/*char[]*/ chars, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886343699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetByteCount(chars, index, count);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12886343699, 408187699201)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17181310995, 416777633793)
            /*int */ GetByteCount$3(/*char**/ chars, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181310995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetByteCount$3(chars, count);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17181310995, 416777633793)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21476278291, 403892731905)
            /*int */ GetByteCount$6(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476278291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetByteCount$6(s);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21476278291, 403892731905)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25771245587, 421072601089)
            /*int */ GetByteCount$4(/*ReadOnlySpan<char>*/ chars)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771245587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetByteCount$4(chars);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25771245587, 421072601089)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30066212883, 455432339457)
            /*int */ GetBytes(/*char[]*/ chars, /*int*/ charIndex, /*int*/ charCount, /*byte[]*/ bytes, /*int*/ byteIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066212883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetBytes(chars, charIndex, charCount, bytes, byteIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30066212883, 455432339457)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 34361180179, 472612208641)
            /*int */ GetBytes$4(/*char**/ chars, /*int*/ charCount, /*byte**/ bytes, /*int*/ byteCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361180179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetBytes$4(chars, charCount, bytes, byteCount);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 34361180179, 472612208641)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38656147475, 506971947009)
            /*int */ GetCharCount(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656147475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetCharCount(bytes, index, count);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetCharCount(bytes, index, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38656147475, 506971947009)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 42951114771, 511266914305)
            /*int */ GetCharCount$3(/*byte**/ bytes, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951114771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetCharCount$3(bytes, count);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetCharCount$3(bytes, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 42951114771, 511266914305)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 47246082067, 515561881601)
            /*int */ GetCharCount$4(/*ReadOnlySpan<byte>*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246082067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetCharCount$4(bytes);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetCharCount$4(bytes);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 47246082067, 515561881601)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 51541049363, 549921619969)
            /*int */ GetChars(/*byte[]*/ bytes, /*int*/ byteIndex, /*int*/ byteCount, /*char[]*/ chars, /*int*/ charIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541049363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetChars(bytes, byteIndex, byteCount, chars, charIndex);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetChars(bytes, byteIndex, byteCount, chars, charIndex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 51541049363, 549921619969)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 55836016659, 554216587265)
            /*int */ GetChars$4(/*byte**/ bytes, /*int*/ byteCount, /*char**/ chars, /*int*/ charCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836016659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetChars$4(bytes, byteCount, chars, charCount);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetChars$4(bytes, byteCount, chars, charCount);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 55836016659, 554216587265)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 60130983955, 622936064001)
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130983955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetMaxByteCount(charCount);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 60130983955, 622936064001)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 64425951251, 627231031297)
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425951251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return byteCount;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 64425951251, 627231031297)
            
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-START(4296409107)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(73015885843)
                    this.s_utf8Encoding = new $.$$.System.Text.UTF8Encoding().$ctor$5(false, true);
                    //--TRIMMABLE-BOUNDARY-END(73015885843)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720918547)
                    this.s_latin1Encoding = $.$$.System.Text.Encoding.GetEncoding$3("iso-8859-1");
                    //--TRIMMABLE-BOUNDARY-END(68720918547)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296409107)
            
            static $h = 1441811;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 165806081,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12886343699, 408187699201),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetByteCount",
      "d": 1441811,
      "h": 12886343699,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12886343699, 408187699201),
//--TRIMMABLE-BOUNDARY-START(ALL, 17181310995, 416777633793),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetByteCount",
      "o": "@$3",
      "d": 1441811,
      "h": 17181310995,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17181310995, 416777633793),
//--TRIMMABLE-BOUNDARY-START(ALL, 21476278291, 403892731905),
    {
      "r": 655361,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "GetByteCount",
      "o": "@$6",
      "d": 1441811,
      "h": 21476278291,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21476278291, 403892731905),
//--TRIMMABLE-BOUNDARY-START(ALL, 25771245587, 421072601089),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "GetByteCount",
      "o": "@$4",
      "d": 1441811,
      "h": 25771245587,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25771245587, 421072601089),
//--TRIMMABLE-BOUNDARY-START(ALL, 30066212883, 455432339457),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "charIndex",
          "p": 655361
        },
        {
          "n": "charCount",
          "p": 655361
        },
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "byteIndex",
          "p": 655361
        }
      ],
      "n": "GetBytes",
      "d": 1441811,
      "h": 30066212883,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30066212883, 455432339457),
//--TRIMMABLE-BOUNDARY-START(ALL, 34361180179, 472612208641),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "charCount",
          "p": 655361
        },
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.System.Byte).$h
        },
        {
          "n": "byteCount",
          "p": 655361
        }
      ],
      "n": "GetBytes",
      "o": "@$4",
      "d": 1441811,
      "h": 34361180179,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 34361180179, 472612208641),
//--TRIMMABLE-BOUNDARY-START(ALL, 38656147475, 506971947009),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetCharCount",
      "d": 1441811,
      "h": 38656147475,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38656147475, 506971947009),
//--TRIMMABLE-BOUNDARY-START(ALL, 42951114771, 511266914305),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.System.Byte).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetCharCount",
      "o": "@$3",
      "d": 1441811,
      "h": 42951114771,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42951114771, 511266914305),
//--TRIMMABLE-BOUNDARY-START(ALL, 47246082067, 515561881601),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "GetCharCount",
      "o": "@$4",
      "d": 1441811,
      "h": 47246082067,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47246082067, 515561881601),
//--TRIMMABLE-BOUNDARY-START(ALL, 51541049363, 549921619969),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "byteIndex",
          "p": 655361
        },
        {
          "n": "byteCount",
          "p": 655361
        },
        {
          "n": "chars",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "charIndex",
          "p": 655361
        }
      ],
      "n": "GetChars",
      "d": 1441811,
      "h": 51541049363,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51541049363, 549921619969),
//--TRIMMABLE-BOUNDARY-START(ALL, 55836016659, 554216587265),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.System.Byte).$h
        },
        {
          "n": "byteCount",
          "p": 655361
        },
        {
          "n": "chars",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "charCount",
          "p": 655361
        }
      ],
      "n": "GetChars",
      "o": "@$4",
      "d": 1441811,
      "h": 55836016659,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55836016659, 554216587265),
//--TRIMMABLE-BOUNDARY-START(ALL, 60130983955, 622936064001),
    {
      "r": 655361,
      "p": [
        {
          "n": "charCount",
          "p": 655361
        }
      ],
      "n": "GetMaxByteCount",
      "d": 1441811,
      "h": 60130983955,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 60130983955, 622936064001),
//--TRIMMABLE-BOUNDARY-START(ALL, 64425951251, 627231031297),
    {
      "r": 655361,
      "p": [
        {
          "n": "byteCount",
          "p": 655361
        }
      ],
      "n": "GetMaxCharCount",
      "d": 1441811,
      "h": 64425951251,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 64425951251, 627231031297)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015885843),
    {
      "t": 168689665,
      "n": "s_utf8Encoding",
      "d": 1441811,
      "h": 73015885843,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73015885843),
//--TRIMMABLE-BOUNDARY-START(68720918547),
    {
      "t": 165806081,
      "n": "s_latin1Encoding",
      "d": 1441811,
      "h": 68720918547,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68720918547)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591376403),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1441811,
      "h": 8591376403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591376403)
  ],
  "i": [89849857
  ],
  "h": 1441811
}; }
            static get $b() { return $.$$.System.Text.Encoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.T61Encoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441811)
        
        
        //--TRIMMABLE-BOUNDARY-START(983059)
        $asm.$cls("$sfa.System.Formats.Asn1.BMPEncoding", ($self) => class BMPEncoding extends $.$sfa.System.Formats.Asn1.SpanBasedEncoding
        {
            //--TRIMMABLE-BOUNDARY-START(ALL, 8590917651, 25771180051)
            /*int */ GetBytes$9(/*ReadOnlySpan<char>*/ chars, /*Span<byte>*/ bytes, /*bool*/ write)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590917651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (chars.IsEmpty)
                {
                    return 0;
                }
                /*int*/ let writeIdx = 0;
                for(/*int*/ let i = 0; i < chars.Length; i++)
                {
                    /*char*/ let c = chars.get_Item(i).$v;
                    if ($.$$.System.Char.IsSurrogate(c))
                    {
                        this.EncoderFallback.CreateFallbackBuffer().Fallback$1(c, i);
                        $.$$.System.Diagnostics.Debug.Fail$1("Fallback should have thrown");
                        throw new $.$$.System.InvalidOperationException().$ctor$9();
                    }
                    /*ushort*/ let val16 = c;
                    if (write)
                    {
                        bytes.get_Item(((writeIdx + 1) | 0)).$v = $.$cast(val16, $.$$.System.Byte);
                        bytes.get_Item(writeIdx).$v = $.$cast((val16 >>> 8), $.$$.System.Byte);
                    }
                    writeIdx += 2;
                }
                return writeIdx;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8590917651, 25771180051)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12885884947, 51540983827)
            /*int */ GetChars$6(/*ReadOnlySpan<byte>*/ bytes, /*Span<char>*/ chars, /*bool*/ write)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885884947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (bytes.IsEmpty)
                {
                    return 0;
                }
                if (bytes.Length % 2 !== 0)
                {
                    this.DecoderFallback.CreateFallbackBuffer().Fallback(bytes.Slice$1(((bytes.Length - 1) | 0)).ToArray(), ((bytes.Length - 1) | 0));
                    $.$$.System.Diagnostics.Debug.Fail$1("Fallback should have thrown");
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                /*int*/ let writeIdx = 0;
                for(/*int*/ let i = 0; i < bytes.Length; i += 2)
                {
                    /*char*/ let c = $.$cast($.$$.System.Buffers.Binary.BinaryPrimitives.ReadInt16BigEndian(bytes.Slice$1(i)), $.$$.System.Char);
                    if ($.$$.System.Char.IsSurrogate(c))
                    {
                        this.DecoderFallback.CreateFallbackBuffer().Fallback(bytes.Slice(i, 2).ToArray(), i);
                        $.$$.System.Diagnostics.Debug.Fail$1("Fallback should have thrown");
                        throw new $.$$.System.InvalidOperationException().$ctor$9();
                    }
                    if (write)
                    {
                        chars.get_Item(writeIdx).$v = c;
                    }
                    writeIdx++;
                }
                return writeIdx;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12885884947, 51540983827)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17180852243, 622936064001)
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //checked
                {
                    return $.$checked(charCount * 2, 1);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17180852243, 622936064001)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21475819539, 627231031297)
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.trunc(byteCount / 2);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21475819539, 627231031297)
            
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 983059;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1376275,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8590917651, 25771180051),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "bytes",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "write",
          "p": 262145
        }
      ],
      "n": "GetBytes",
      "o": "@$9",
      "d": 983059,
      "h": 8590917651,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8590917651, 25771180051),
//--TRIMMABLE-BOUNDARY-START(ALL, 12885884947, 51540983827),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "chars",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "write",
          "p": 262145
        }
      ],
      "n": "GetChars",
      "o": "@$6",
      "d": 983059,
      "h": 12885884947,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12885884947, 51540983827),
//--TRIMMABLE-BOUNDARY-START(ALL, 17180852243, 622936064001),
    {
      "r": 655361,
      "p": [
        {
          "n": "charCount",
          "p": 655361
        }
      ],
      "n": "GetMaxByteCount",
      "d": 983059,
      "h": 17180852243,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17180852243, 622936064001),
//--TRIMMABLE-BOUNDARY-START(ALL, 21475819539, 627231031297),
    {
      "r": 655361,
      "p": [
        {
          "n": "byteCount",
          "p": 655361
        }
      ],
      "n": "GetMaxCharCount",
      "d": 983059,
      "h": 21475819539,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21475819539, 627231031297)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950355),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 983059,
      "h": 4295950355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950355)
  ],
  "i": [89849857
  ],
  "h": 983059
}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.SpanBasedEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.BMPEncoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983059)
        
        
        //--TRIMMABLE-BOUNDARY-START(524307)
        $asm.$str("$sfa.System.Formats.Asn1.AsnEncodingRules", ($self) => class AsnEncodingRules extends $.$$.System.Enum
        {
            static BER = 0;
            static CER = 1;
            static DER = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "BER": 0n,
                    "CER": 1n,
                    "DER": 2n
                };
            }
            static $h = 524307;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590458899),
    {
      "t": 524307,
      "n": "BER",
      "d": 524307,
      "h": 8590458899,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458899),
//--TRIMMABLE-BOUNDARY-START(12885426195),
    {
      "t": 524307,
      "n": "CER",
      "d": 524307,
      "h": 12885426195,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426195),
//--TRIMMABLE-BOUNDARY-START(17180393491),
    {
      "t": 524307,
      "n": "DER",
      "d": 524307,
      "h": 17180393491,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393491)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491603),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524307,
      "h": 4295491603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491603)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 524307
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Formats.Asn1.AsnEncodingRules`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524307)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572883)
        $asm.$str("$sfa.System.Formats.Asn1.UniversalTagNumber", ($self) => class UniversalTagNumber extends $.$$.System.Enum
        {
            static EndOfContents = 0;
            static Boolean = 1;
            static Integer = 2;
            static BitString = 3;
            static OctetString = 4;
            static Null = 5;
            static ObjectIdentifier = 6;
            static ObjectDescriptor = 7;
            static External = 8;
            static InstanceOf = 8;
            static Real = 9;
            static Enumerated = 10;
            static Embedded = 11;
            static UTF8String = 12;
            static RelativeObjectIdentifier = 13;
            static Time = 14;
            static Sequence = 16;
            static SequenceOf = 16;
            static Set = 17;
            static SetOf = 17;
            static NumericString = 18;
            static PrintableString = 19;
            static TeletexString = 20;
            static T61String = 20;
            static VideotexString = 21;
            static IA5String = 22;
            static UtcTime = 23;
            static GeneralizedTime = 24;
            static GraphicString = 25;
            static VisibleString = 26;
            static ISO646String = 26;
            static GeneralString = 27;
            static UniversalString = 28;
            static UnrestrictedCharacterString = 29;
            static BMPString = 30;
            static Date = 31;
            static TimeOfDay = 32;
            static DateTime = 33;
            static Duration = 34;
            static ObjectIdentifierIRI = 35;
            static RelativeObjectIdentifierIRI = 36;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1572883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "EndOfContents": 0n,
                    "Boolean": 1n,
                    "Integer": 2n,
                    "BitString": 3n,
                    "OctetString": 4n,
                    "Null": 5n,
                    "ObjectIdentifier": 6n,
                    "ObjectDescriptor": 7n,
                    "External": 8n,
                    "InstanceOf": 8n,
                    "Real": 9n,
                    "Enumerated": 10n,
                    "Embedded": 11n,
                    "UTF8String": 12n,
                    "RelativeObjectIdentifier": 13n,
                    "Time": 14n,
                    "Sequence": 16n,
                    "SequenceOf": 16n,
                    "Set": 17n,
                    "SetOf": 17n,
                    "NumericString": 18n,
                    "PrintableString": 19n,
                    "TeletexString": 20n,
                    "T61String": 20n,
                    "VideotexString": 21n,
                    "IA5String": 22n,
                    "UtcTime": 23n,
                    "GeneralizedTime": 24n,
                    "GraphicString": 25n,
                    "VisibleString": 26n,
                    "ISO646String": 26n,
                    "GeneralString": 27n,
                    "UniversalString": 28n,
                    "UnrestrictedCharacterString": 29n,
                    "BMPString": 30n,
                    "Date": 31n,
                    "TimeOfDay": 32n,
                    "DateTime": 33n,
                    "Duration": 34n,
                    "ObjectIdentifierIRI": 35n,
                    "RelativeObjectIdentifierIRI": 36n
                };
            }
            static $h = 1572883;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656278547),
    {
      "t": 1572883,
      "n": "EndOfContents",
      "d": 1572883,
      "h": 38656278547,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656278547),
//--TRIMMABLE-BOUNDARY-START(17181442067),
    {
      "t": 1572883,
      "n": "Boolean",
      "d": 1572883,
      "h": 17181442067,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181442067),
//--TRIMMABLE-BOUNDARY-START(73016016915),
    {
      "t": 1572883,
      "n": "Integer",
      "d": 1572883,
      "h": 73016016915,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73016016915),
//--TRIMMABLE-BOUNDARY-START(8591507475),
    {
      "t": 1572883,
      "n": "BitString",
      "d": 1572883,
      "h": 8591507475,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591507475),
//--TRIMMABLE-BOUNDARY-START(103080787987),
    {
      "t": 1572883,
      "n": "OctetString",
      "d": 1572883,
      "h": 103080787987,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103080787987),
//--TRIMMABLE-BOUNDARY-START(81605951507),
    {
      "t": 1572883,
      "n": "Null",
      "d": 1572883,
      "h": 81605951507,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605951507),
//--TRIMMABLE-BOUNDARY-START(94490853395),
    {
      "t": 1572883,
      "n": "ObjectIdentifier",
      "d": 1572883,
      "h": 94490853395,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490853395),
//--TRIMMABLE-BOUNDARY-START(90195886099),
    {
      "t": 1572883,
      "n": "ObjectDescriptor",
      "d": 1572883,
      "h": 90195886099,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195886099),
//--TRIMMABLE-BOUNDARY-START(47246213139),
    {
      "t": 1572883,
      "n": "External",
      "d": 1572883,
      "h": 47246213139,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246213139),
//--TRIMMABLE-BOUNDARY-START(68721049619),
    {
      "t": 1572883,
      "n": "InstanceOf",
      "d": 1572883,
      "h": 68721049619,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68721049619),
//--TRIMMABLE-BOUNDARY-START(111670722579),
    {
      "t": 1572883,
      "n": "Real",
      "d": 1572883,
      "h": 111670722579,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670722579),
//--TRIMMABLE-BOUNDARY-START(42951245843),
    {
      "t": 1572883,
      "n": "Enumerated",
      "d": 1572883,
      "h": 42951245843,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951245843),
//--TRIMMABLE-BOUNDARY-START(34361311251),
    {
      "t": 1572883,
      "n": "Embedded",
      "d": 1572883,
      "h": 34361311251,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361311251),
//--TRIMMABLE-BOUNDARY-START(171800264723),
    {
      "t": 1572883,
      "n": "UTF8String",
      "d": 1572883,
      "h": 171800264723,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171800264723),
//--TRIMMABLE-BOUNDARY-START(115965689875),
    {
      "t": 1572883,
      "n": "RelativeObjectIdentifier",
      "d": 1572883,
      "h": 115965689875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115965689875),
//--TRIMMABLE-BOUNDARY-START(150325428243),
    {
      "t": 1572883,
      "n": "Time",
      "d": 1572883,
      "h": 150325428243,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150325428243),
//--TRIMMABLE-BOUNDARY-START(124555624467),
    {
      "t": 1572883,
      "n": "Sequence",
      "d": 1572883,
      "h": 124555624467,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124555624467),
//--TRIMMABLE-BOUNDARY-START(128850591763),
    {
      "t": 1572883,
      "n": "SequenceOf",
      "d": 1572883,
      "h": 128850591763,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128850591763),
//--TRIMMABLE-BOUNDARY-START(133145559059),
    {
      "t": 1572883,
      "n": "Set",
      "d": 1572883,
      "h": 133145559059,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133145559059),
//--TRIMMABLE-BOUNDARY-START(137440526355),
    {
      "t": 1572883,
      "n": "SetOf",
      "d": 1572883,
      "h": 137440526355,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137440526355),
//--TRIMMABLE-BOUNDARY-START(85900918803),
    {
      "t": 1572883,
      "n": "NumericString",
      "d": 1572883,
      "h": 85900918803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900918803),
//--TRIMMABLE-BOUNDARY-START(107375755283),
    {
      "t": 1572883,
      "n": "PrintableString",
      "d": 1572883,
      "h": 107375755283,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107375755283),
//--TRIMMABLE-BOUNDARY-START(146030460947),
    {
      "t": 1572883,
      "n": "TeletexString",
      "d": 1572883,
      "h": 146030460947,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146030460947),
//--TRIMMABLE-BOUNDARY-START(141735493651),
    {
      "t": 1572883,
      "n": "T61String",
      "d": 1572883,
      "h": 141735493651,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141735493651),
//--TRIMMABLE-BOUNDARY-START(176095232019),
    {
      "t": 1572883,
      "n": "VideotexString",
      "d": 1572883,
      "h": 176095232019,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176095232019),
//--TRIMMABLE-BOUNDARY-START(64426082323),
    {
      "t": 1572883,
      "n": "IA5String",
      "d": 1572883,
      "h": 64426082323,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64426082323),
//--TRIMMABLE-BOUNDARY-START(167505297427),
    {
      "t": 1572883,
      "n": "UtcTime",
      "d": 1572883,
      "h": 167505297427,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167505297427),
//--TRIMMABLE-BOUNDARY-START(51541180435),
    {
      "t": 1572883,
      "n": "GeneralizedTime",
      "d": 1572883,
      "h": 51541180435,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541180435),
//--TRIMMABLE-BOUNDARY-START(60131115027),
    {
      "t": 1572883,
      "n": "GraphicString",
      "d": 1572883,
      "h": 60131115027,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60131115027),
//--TRIMMABLE-BOUNDARY-START(180390199315),
    {
      "t": 1572883,
      "n": "VisibleString",
      "d": 1572883,
      "h": 180390199315,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180390199315),
//--TRIMMABLE-BOUNDARY-START(77310984211),
    {
      "t": 1572883,
      "n": "ISO646String",
      "d": 1572883,
      "h": 77310984211,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310984211),
//--TRIMMABLE-BOUNDARY-START(55836147731),
    {
      "t": 1572883,
      "n": "GeneralString",
      "d": 1572883,
      "h": 55836147731,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836147731),
//--TRIMMABLE-BOUNDARY-START(158915362835),
    {
      "t": 1572883,
      "n": "UniversalString",
      "d": 1572883,
      "h": 158915362835,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158915362835),
//--TRIMMABLE-BOUNDARY-START(163210330131),
    {
      "t": 1572883,
      "n": "UnrestrictedCharacterString",
      "d": 1572883,
      "h": 163210330131,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163210330131),
//--TRIMMABLE-BOUNDARY-START(12886474771),
    {
      "t": 1572883,
      "n": "BMPString",
      "d": 1572883,
      "h": 12886474771,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886474771),
//--TRIMMABLE-BOUNDARY-START(21476409363),
    {
      "t": 1572883,
      "n": "Date",
      "d": 1572883,
      "h": 21476409363,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476409363),
//--TRIMMABLE-BOUNDARY-START(154620395539),
    {
      "t": 1572883,
      "n": "TimeOfDay",
      "d": 1572883,
      "h": 154620395539,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154620395539),
//--TRIMMABLE-BOUNDARY-START(25771376659),
    {
      "t": 1572883,
      "n": "DateTime",
      "d": 1572883,
      "h": 25771376659,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771376659),
//--TRIMMABLE-BOUNDARY-START(30066343955),
    {
      "t": 1572883,
      "n": "Duration",
      "d": 1572883,
      "h": 30066343955,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066343955),
//--TRIMMABLE-BOUNDARY-START(98785820691),
    {
      "t": 1572883,
      "n": "ObjectIdentifierIRI",
      "d": 1572883,
      "h": 98785820691,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98785820691),
//--TRIMMABLE-BOUNDARY-START(120260657171),
    {
      "t": 1572883,
      "n": "RelativeObjectIdentifierIRI",
      "d": 1572883,
      "h": 120260657171,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120260657171)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540179),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1572883,
      "h": 4296540179,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540179)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 1572883
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Formats.Asn1.UniversalTagNumber`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572883)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507347)
        $asm.$str("$sfa.System.Formats.Asn1.TagClass", ($self) => class TagClass extends $.$$.System.Enum
        {
            static Universal = 0;
            static Application = 64;
            static ContextSpecific = 128;
            static Private = 192;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1507347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Universal": 0n,
                    "Application": 64n,
                    "ContextSpecific": 128n,
                    "Private": 192n
                };
            }
            static $h = 1507347;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476343827),
    {
      "t": 1507347,
      "n": "Universal",
      "d": 1507347,
      "h": 21476343827,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476343827),
//--TRIMMABLE-BOUNDARY-START(8591441939),
    {
      "t": 1507347,
      "n": "Application",
      "d": 1507347,
      "h": 8591441939,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591441939),
//--TRIMMABLE-BOUNDARY-START(12886409235),
    {
      "t": 1507347,
      "n": "ContextSpecific",
      "d": 1507347,
      "h": 12886409235,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886409235),
//--TRIMMABLE-BOUNDARY-START(17181376531),
    {
      "t": 1507347,
      "n": "Private",
      "d": 1507347,
      "h": 17181376531,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181376531)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296474643),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507347,
      "h": 4296474643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296474643)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 1507347
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Formats.Asn1.TagClass`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507347)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048595)
        $asm.$cls("$sfa.System.Formats.Asn1.IA5Encoding", ($self) => class IA5Encoding extends $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding
        {
            //--TRIMMABLE-BOUNDARY-START(4296015891)
            $ctor$7()
            {
                super.$ctor$5(0, 127);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296015891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296015891)
            
            static $h = 1048595;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245203,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015891),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1048595,
      "h": 4296015891,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296015891)
  ],
  "i": [89849857
  ],
  "h": 1048595
}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.IA5Encoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048595)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638419)
        $asm.$cls("$sfa.System.Formats.Asn1.VisibleStringEncoding", ($self) => class VisibleStringEncoding extends $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding
        {
            //--TRIMMABLE-BOUNDARY-START(4296605715)
            $ctor$7()
            {
                super.$ctor$5(32, 126);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296605715);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605715)
            
            static $h = 1638419;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245203,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605715),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1638419,
      "h": 4296605715,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296605715)
  ],
  "i": [89849857
  ],
  "h": 1638419
}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.VisibleStringEncoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638419)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114131)
        $asm.$cls("$sfa.System.Formats.Asn1.NumericStringEncoding", ($self) => class NumericStringEncoding extends $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding
        {
            //--TRIMMABLE-BOUNDARY-START(4296081427)
            $ctor$7()
            {
                super.$ctor$6("0123456789 ");
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296081427);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296081427)
            
            static $h = 1114131;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245203,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081427),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1114131,
      "h": 4296081427,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296081427)
  ],
  "i": [89849857
  ],
  "h": 1114131
}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.NumericStringEncoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114131)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179667)
        $asm.$cls("$sfa.System.Formats.Asn1.PrintableStringEncoding", ($self) => class PrintableStringEncoding extends $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding
        {
            //--TRIMMABLE-BOUNDARY-START(4296146963)
            $ctor$7()
            {
                super.$ctor$6("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 '()+,-./:=?");
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296146963);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296146963)
            
            static $h = 1179667;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245203,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296146963),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1179667,
      "h": 4296146963,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296146963)
  ],
  "i": [89849857
  ],
  "h": 1179667
}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.PrintableStringEncoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179667)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310739)
        $asm.$cls("$sfa.System.Formats.Asn1.SetOfValueComparer", ($self) => class SetOfValueComparer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361049107)
            /*SetOfValueComparer*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(34361049107)
            
            //--TRIMMABLE-BOUNDARY-START(17181179923)
            /*int */ Compare(/*ReadOnlyMemory<byte>*/ x, /*ReadOnlyMemory<byte>*/ y)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181179923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sfa.System.Formats.Asn1.SetOfValueComparer.Compare$1(x.Span, y.Span);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181179923)
            
            //--TRIMMABLE-BOUNDARY-START(21476147219)
            static /*int */ Compare$1(/*ReadOnlySpan<byte>*/ x, /*ReadOnlySpan<byte>*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let min = $.$$.System.Math.Min$4(x.Length, y.Length);
                /*int*/ let diff;
                /*int*/ let diffIndex = $.$$.System.MemoryExtensions.CommonPrefixLength$1($.$$.System.Byte, x, y);
                if (diffIndex !== min)
                {
                    return (($.$cast(x.get_Item(diffIndex).$v, $.$$.System.Int32) - y.get_Item(diffIndex).$v) | 0);
                }
                diff = ((x.Length - y.Length) | 0);
                return diff;
            }
            //--TRIMMABLE-BOUNDARY-END(21476147219)
            
            //--TRIMMABLE-BOUNDARY-START(4354277377)
            //Generated interface implemetation for System.Collections.Generic.IComparer<System.ReadOnlyMemory<byte>>.Compare(System.ReadOnlyMemory<byte>, System.ReadOnlyMemory<byte>)
            System$Collections$Generic$IComparer$$$Compare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354277377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354277377)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-START(4296278035)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sfa.System.Formats.Asn1.SetOfValueComparer().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296278035)
            
            static $h = 1310739;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361049107),
    {
      "p": 1310739,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066081811,
        "f": 50331688
      },
      "n": "Instance",
      "d": 1310739,
      "h": 34361049107,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(34361049107)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181179923),
    {
      "r": 655361,
      "p": [
        {
          "n": "x",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "y",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        }
      ],
      "n": "Compare",
      "d": 1310739,
      "h": 17181179923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181179923),
//--TRIMMABLE-BOUNDARY-START(21476147219),
    {
      "r": 655361,
      "p": [
        {
          "n": "x",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "y",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "Compare",
      "o": "@$1",
      "d": 1310739,
      "h": 21476147219,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21476147219)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591245331),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310739,
      "h": 8591245331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591245331)
  ],
  "i": [$.$$.System.Collections.Generic.IComparer$$($.$$.System.ReadOnlyMemory$$($.$$.System.Byte)).$h
  ],
  "h": 1310739
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IComparer$$($.$$.System.ReadOnlyMemory$$($.$$.System.Byte)) ]; }
            static get $fullName() { return `System.Formats.Asn1.SetOfValueComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310739)
        
        
        //--TRIMMABLE-BOUNDARY-START(196627)
        $asm.$cls("$sfa.System.Formats.Asn1.AsnContentException", ($self) => class AsnContentException extends $.$$.System.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(4295163923)
            $ctor$5()
            {
                super.$ctor$4($.$sfa.System.SR.ContentException_DefaultMessage);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295163923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163923)
            
            //--TRIMMABLE-BOUNDARY-START(8590131219)
            $ctor$8(/*string?*/ message)
            {
                super.$ctor$4(message ?? $.$sfa.System.SR.ContentException_DefaultMessage);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131219);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131219)
            
            //--TRIMMABLE-BOUNDARY-START(12885098515)
            $ctor$7(/*string?*/ message, /*Exception?*/ inner)
            {
                super.$ctor$3(message ?? $.$sfa.System.SR.ContentException_DefaultMessage, inner);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885098515);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098515)
            
            //--TRIMMABLE-BOUNDARY-START(17180065811)
            $ctor$6(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$2(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065811);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065811)
            
            static $h = 196627;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79888385,
  "h": 196627
}; }
            static get $b() { return $.$$.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Formats.Asn1.AsnContentException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196627)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Numerics", "NetJs.System.Text.Encoding.Extensions"))
//--TRIMMABLE-BOUNDARY-END(19)
