
//--TRIMMABLE-BOUNDARY-START(19)
(async function () {
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $srn, $stee) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Formats.Asn1", 
    {
  "h": 19,
  "f": "System.Formats.Asn1",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Formats.Asn1",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Formats.Asn1",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1376275)
        $asm.$cls(`$sfa.SFA.SpanBasedEncoding`, ($self) => class SpanBasedEncoding extends $.$$.ST.Encoding
        {
            //--TRIMMABLE-BOUNDARY-START(4296343571)
            $ctor$4()
            {
                super.$ctor$2(0, $.$$.ST.EncoderFallback.ExceptionFallback, $.$$.ST.DecoderFallback.ExceptionFallback);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296343571);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343571)
            
            //--TRIMMABLE-BOUNDARY-START(8591310867)
            /*int */ GetByteCount(/*char[]*/ chars, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591310867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetByteCount$4(new ($.$$.S.ReadOnlySpan$$($.$$.S.Char))().$ctor$6(chars, index, count));
            }
            //--TRIMMABLE-BOUNDARY-END(8591310867)
            
            //--TRIMMABLE-BOUNDARY-START(12886278163)
            /*int */ GetByteCount$3(/*char**/ chars, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886278163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetByteCount$4(new ($.$$.S.ReadOnlySpan$$($.$$.S.Char))().$ctor$4(chars, count));
            }
            //--TRIMMABLE-BOUNDARY-END(12886278163)
            
            //--TRIMMABLE-BOUNDARY-START(21476212755)
            /*int */ GetByteCount$6(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476212755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetByteCount$4($.$$.S.MemoryExtensions.AsSpan$4(s));
            }
            //--TRIMMABLE-BOUNDARY-END(21476212755)
            
            //--TRIMMABLE-BOUNDARY-START(17181245459)
            /*int */ GetByteCount$4(/*ReadOnlySpan<char>*/ chars)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181245459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetBytes$9(chars, $.$$.S.Span$$($.$$.S.Byte).Empty, false);
            }
            //--TRIMMABLE-BOUNDARY-END(17181245459)
            
            //--TRIMMABLE-BOUNDARY-START(25771180051)
            /*int */ GetBytes(/*char[]*/ chars, /*int*/ charIndex, /*int*/ charCount, /*byte[]*/ bytes, /*int*/ byteIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771180051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetBytes$9(new ($.$$.S.ReadOnlySpan$$($.$$.S.Char))().$ctor$6(chars, charIndex, charCount), new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$6(bytes, byteIndex, ((bytes.length - byteIndex) | 0)), true);
            }
            //--TRIMMABLE-BOUNDARY-END(25771180051)
            
            //--TRIMMABLE-BOUNDARY-START(30066147347)
            /*int */ GetBytes$4(/*char**/ chars, /*int*/ charCount, /*byte**/ bytes, /*int*/ byteCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066147347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetBytes$9(new ($.$$.S.ReadOnlySpan$$($.$$.S.Char))().$ctor$4(chars, charCount), new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$5(bytes, byteCount), true);
            }
            //--TRIMMABLE-BOUNDARY-END(30066147347)
            
            //--TRIMMABLE-BOUNDARY-START(38656081939)
            /*int */ GetCharCount(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656081939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCharCount$4(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$6(bytes, index, count));
            }
            //--TRIMMABLE-BOUNDARY-END(38656081939)
            
            //--TRIMMABLE-BOUNDARY-START(42951049235)
            /*int */ GetCharCount$3(/*byte**/ bytes, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951049235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCharCount$4(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$4(bytes, count));
            }
            //--TRIMMABLE-BOUNDARY-END(42951049235)
            
            //--TRIMMABLE-BOUNDARY-START(47246016531)
            /*int */ GetCharCount$4(/*ReadOnlySpan<byte>*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246016531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChars$6(bytes, $.$$.S.Span$$($.$$.S.Char).Empty, false);
            }
            //--TRIMMABLE-BOUNDARY-END(47246016531)
            
            //--TRIMMABLE-BOUNDARY-START(51540983827)
            /*int */ GetChars(/*byte[]*/ bytes, /*int*/ byteIndex, /*int*/ byteCount, /*char[]*/ chars, /*int*/ charIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540983827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChars$6(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$6(bytes, byteIndex, byteCount), new ($.$$.S.Span$$($.$$.S.Char))().$ctor$6(chars, charIndex, ((chars.length - charIndex) | 0)), true);
            }
            //--TRIMMABLE-BOUNDARY-END(51540983827)
            
            //--TRIMMABLE-BOUNDARY-START(55835951123)
            /*int */ GetChars$4(/*byte**/ bytes, /*int*/ byteCount, /*char**/ chars, /*int*/ charCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835951123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChars$6(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$4(bytes, byteCount), new ($.$$.S.Span$$($.$$.S.Char))().$ctor$5(chars, charCount), true);
            }
            //--TRIMMABLE-BOUNDARY-END(55835951123)
            
            //--TRIMMABLE-BOUNDARY-START(4296343571)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4296343571)
            
            static $h = 1376275;
            static $f = 0b110000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.ST.Encoding; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361114643),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "bytes",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "write",
          "p": 262145
        }
      ],
      "n": "GetBytes",
      "o": "@$9",
      "d": 1376275,
      "h": 34361114643,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(34361114643),
//--TRIMMABLE-BOUNDARY-START(60130918419),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "chars",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "write",
          "p": 262145
        }
      ],
      "n": "GetChars",
      "o": "@$6",
      "d": 1376275,
      "h": 60130918419,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(60130918419),
//--TRIMMABLE-BOUNDARY-START(8591310867),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetByteCount",
      "d": 1376275,
      "h": 8591310867,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591310867),
//--TRIMMABLE-BOUNDARY-START(12886278163),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetByteCount",
      "o": "@$3",
      "d": 1376275,
      "h": 12886278163,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886278163),
//--TRIMMABLE-BOUNDARY-START(21476212755),
    {
      "r": 655361,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "GetByteCount",
      "o": "@$6",
      "d": 1376275,
      "h": 21476212755,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476212755),
//--TRIMMABLE-BOUNDARY-START(17181245459),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "GetByteCount",
      "o": "@$4",
      "d": 1376275,
      "h": 17181245459,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181245459),
//--TRIMMABLE-BOUNDARY-START(25771180051),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "charIndex",
          "p": 655361
        },
        {
          "n": "charCount",
          "p": 655361
        },
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "byteIndex",
          "p": 655361
        }
      ],
      "n": "GetBytes",
      "d": 1376275,
      "h": 25771180051,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771180051),
//--TRIMMABLE-BOUNDARY-START(30066147347),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "charCount",
          "p": 655361
        },
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "byteCount",
          "p": 655361
        }
      ],
      "n": "GetBytes",
      "o": "@$4",
      "d": 1376275,
      "h": 30066147347,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066147347),
//--TRIMMABLE-BOUNDARY-START(38656081939),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetCharCount",
      "d": 1376275,
      "h": 38656081939,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656081939),
//--TRIMMABLE-BOUNDARY-START(42951049235),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetCharCount",
      "o": "@$3",
      "d": 1376275,
      "h": 42951049235,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951049235),
//--TRIMMABLE-BOUNDARY-START(47246016531),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetCharCount",
      "o": "@$4",
      "d": 1376275,
      "h": 47246016531,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246016531),
//--TRIMMABLE-BOUNDARY-START(51540983827),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "byteIndex",
          "p": 655361
        },
        {
          "n": "byteCount",
          "p": 655361
        },
        {
          "n": "chars",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "charIndex",
          "p": 655361
        }
      ],
      "n": "GetChars",
      "d": 1376275,
      "h": 51540983827,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540983827),
//--TRIMMABLE-BOUNDARY-START(55835951123),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "byteCount",
          "p": 655361
        },
        {
          "n": "chars",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "charCount",
          "p": 655361
        }
      ],
      "n": "GetChars",
      "o": "@$4",
      "d": 1376275,
      "h": 55835951123,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835951123)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343571),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1376275,
      "h": 4296343571,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296343571)
  ],
  "h": 1376275
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.SpanBasedEncoding`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}SpanBasedEncoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376275)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245203)
        $asm.$cls(`$sfa.SFA.RestrictedAsciiStringEncoding`, ($self) => class RestrictedAsciiStringEncoding extends $.$sfa.SFA.SpanBasedEncoding
        {
            //--TRIMMABLE-BOUNDARY-START(4296212499)
            /*bool[]*/ _isAllowed = null;
            //--TRIMMABLE-BOUNDARY-END(4296212499)
            
            //--TRIMMABLE-BOUNDARY-START(8591179795)
            $ctor$5(/*byte*/ minCharAllowed, /*byte*/ maxCharAllowed)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591179795);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(minCharAllowed <= maxCharAllowed, "minCharAllowed <= maxCharAllowed");
                    $.$$.SD.Debug.Assert$4(maxCharAllowed <= 127, "maxCharAllowed <= 0x7F");
                    /*bool[]*/ let isAllowed = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Boolean), null, [128], null);
                    $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Boolean, isAllowed, minCharAllowed, ((maxCharAllowed - minCharAllowed + 1) | 0)).Fill(true);
                    this._isAllowed = isAllowed;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179795)
            
            //--TRIMMABLE-BOUNDARY-START(12886147091)
            $ctor$6(/*string*/ allowedChars)
            {
                super.$ctor$4();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886147091);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool[]*/ let isAllowed = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Boolean), null, [127], null);
                    let $en1 = $.$$.S.String.GetEnumerator.call(allowedChars);
                    while ($en1.MoveNext())
                    {
                        let c = $en1.Current;
                        {
                            if (c >= isAllowed.length)
                            {
                                throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("allowedChars");
                            }
                            $.$$.SD.Debug.Assert$4($.$$.System.Array.$ReadT1.call(isAllowed, c) === false, "isAllowed[c] == false");
                            $.$$.System.Array.$WriteT1.call(isAllowed, true, c);
                        }
                    }
                    this._isAllowed = isAllowed;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886147091)
            
            //--TRIMMABLE-BOUNDARY-START(25771048979)
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771048979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return charCount;
            }
            //--TRIMMABLE-BOUNDARY-END(25771048979)
            
            //--TRIMMABLE-BOUNDARY-START(30066016275)
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066016275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return byteCount;
            }
            //--TRIMMABLE-BOUNDARY-END(30066016275)
            
            //--TRIMMABLE-BOUNDARY-START(17181114387)
            /*int */ GetBytes$9(/*ReadOnlySpan<char>*/ chars, /*Span<byte>*/ bytes, /*bool*/ write)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181114387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (chars.IsEmpty)
                {
                    return 0;
                }
                for(/*int*/ let i = 0; i < chars.Length; i++)
                {
                    /*char*/ let c = chars._reference.GetAt(i);
                    if (c >= (this._isAllowed.length >>> 0) || !$.$$.System.Array.$ReadT1.call(this._isAllowed, c))
                    {
                        this.EncoderFallback.CreateFallbackBuffer().Fallback$1(c, i);
                        $.$$.SD.Debug.Fail$1("Fallback should have thrown");
                        throw new $.$$.S.InvalidOperationException().$ctor$9();
                    }
                    if (write)
                    {
                        bytes._reference.SetAt(((c & 0xFF) >>> 0), i);
                    }
                }
                return chars.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(17181114387)
            
            //--TRIMMABLE-BOUNDARY-START(21476081683)
            /*int */ GetChars$6(/*ReadOnlySpan<byte>*/ bytes, /*Span<char>*/ chars, /*bool*/ write)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476081683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (bytes.IsEmpty)
                {
                    return 0;
                }
                for(/*int*/ let i = 0; i < bytes.Length; i++)
                {
                    /*byte*/ let b = bytes._reference.GetAt(i);
                    if (b >= (this._isAllowed.length >>> 0) || !$.$$.System.Array.$ReadT1.call(this._isAllowed, b))
                    {
                        this.DecoderFallback.CreateFallbackBuffer().Fallback($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), [b], null, null), i);
                        $.$$.SD.Debug.Fail$1("Fallback should have thrown");
                        throw new $.$$.S.InvalidOperationException().$ctor$9();
                    }
                    if (write)
                    {
                        chars._reference.SetAt(b, i);
                    }
                }
                return bytes.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(21476081683)
            
            static $h = 1245203;
            static $f = 0b110000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sfa.SFA.SpanBasedEncoding; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771048979),
    {
      "r": 655361,
      "p": [
        {
          "n": "charCount",
          "p": 655361
        }
      ],
      "n": "GetMaxByteCount",
      "d": 1245203,
      "h": 25771048979,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771048979),
//--TRIMMABLE-BOUNDARY-START(30066016275),
    {
      "r": 655361,
      "p": [
        {
          "n": "byteCount",
          "p": 655361
        }
      ],
      "n": "GetMaxCharCount",
      "d": 1245203,
      "h": 30066016275,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066016275),
//--TRIMMABLE-BOUNDARY-START(17181114387),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "bytes",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "write",
          "p": 262145
        }
      ],
      "n": "GetBytes",
      "o": "@$9",
      "d": 1245203,
      "h": 17181114387,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(17181114387),
//--TRIMMABLE-BOUNDARY-START(21476081683),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "chars",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "write",
          "p": 262145
        }
      ],
      "n": "GetChars",
      "o": "@$6",
      "d": 1245203,
      "h": 21476081683,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(21476081683)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296212499),
    {
      "t": $.$typeArray($.$$.S.Boolean).$h,
      "n": "_isAllowed",
      "d": 1245203,
      "h": 4296212499,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212499)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591179795),
    {
      "p": [
        {
          "n": "minCharAllowed",
          "p": 393217
        },
        {
          "n": "maxCharAllowed",
          "p": 393217
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1245203,
      "h": 8591179795,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591179795),
//--TRIMMABLE-BOUNDARY-START(12886147091),
    {
      "p": [
        {
          "n": "allowedChars",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1245203,
      "h": 12886147091,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12886147091)
  ],
  "h": 1245203
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.RestrictedAsciiStringEncoding`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}RestrictedAsciiStringEncoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245203)
        
        

        //--TRIMMABLE-BOUNDARY-START(262163)
        $asm.$cls(`$sfa.SFA.AsnDecoder`, ($self) => class AsnDecoder
        {
            //--TRIMMABLE-BOUNDARY-START(180388888595)
            static /*void */ ReadNull(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388888595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.SFA.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag ?? $.$sfa.SFA.Asn1Tag.Null, 5/*UniversalTagNumber.Null*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32));
                if (contents.Length !== 0)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
                bytesConsumed.$v = consumed;
            }
            //--TRIMMABLE-BOUNDARY-END(180388888595)
            
            //--TRIMMABLE-BOUNDARY-START(197568757779)
            static /*void */ ReadSequence(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int?*/ let length;
                /*int*/ let headerLength;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568757779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Asn1Tag*/ let tag = $.$sfa.SFA.AsnDecoder.ReadTagAndLength(source, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.S.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.S.Int32));
                $.$sfa.SFA.AsnDecoder.CheckExpectedTag(tag, expectedTag ?? $.$sfa.SFA.Asn1Tag.Sequence, 16/*UniversalTagNumber.Sequence*/);
                if (!tag.IsConstructed)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.Format$6($.$sfa.S.SR.ContentException_ConstructedEncodingRequired, $.$box(16/*UniversalTagNumber.Sequence*/, $.$sfa.SFA.UniversalTagNumber)));
                }
                if ($.$$.S.Nullable$$($.$$.S.Int32).HasValue$get.call(length))
                {
                    if ($.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(length) > ((source.Length - headerLength) | 0))
                    {
                        throw $.$sfa.SFA.AsnDecoder.GetValidityException(2/*LengthValidity.LengthExceedsInput*/);
                    }
                    contentLength.$v = $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(length);
                    contentOffset.$v = headerLength;
                    bytesConsumed.$v = ((contentLength.$v + headerLength) | 0);
                }
                else 
                {
                    /*int*/ let len = $.$sfa.SFA.AsnDecoder.SeekEndOfContents(source.Slice$1(headerLength), ruleSet);
                    contentLength.$v = len;
                    contentOffset.$v = headerLength;
                    bytesConsumed.$v = ((((len + headerLength) | 0) + 2/*EndOfContentsEncodedLength*/) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197568757779)
            
            //--TRIMMABLE-BOUNDARY-START(120259346451)
            static /*bool */ ReadBoolean(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259346451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.SFA.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag ?? $.$sfa.SFA.Asn1Tag.Boolean, 1/*UniversalTagNumber.Boolean*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32));
                if (contents.Length !== 1)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
                /*byte*/ let val = contents._reference.GetAt(0);
                if (val === 0)
                {
                    bytesConsumed.$v = consumed;
                    return false;
                }
                if (val !== 255 && (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/))
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                bytesConsumed.$v = consumed;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(120259346451)
            
            //--TRIMMABLE-BOUNDARY-START(137439215635)
            static /*ReadOnlySpan<byte> */ ReadEnumeratedBytes(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439215635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag ?? $.$sfa.SFA.Asn1Tag.Enumerated, 10/*UniversalTagNumber.Enumerated*/, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(137439215635)
            
            //--TRIMMABLE-BOUNDARY-START(146029150227)
            static /*TEnum */ ReadEnumeratedValue$1(TEnum, /*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029150227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let tEnum = TEnum.$type;
                return $.$cast($.$$.S.Enum.ToObject$4(tEnum, $.$sfa.SFA.AsnDecoder.ReadEnumeratedValue(source, ruleSet, tEnum, bytesConsumed, $.$clone(expectedTag))), TEnum);
            }
            //--TRIMMABLE-BOUNDARY-END(146029150227)
            
            //--TRIMMABLE-BOUNDARY-START(141734182931)
            static /*Enum */ ReadEnumeratedValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Type*/ enumType, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734182931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (enumType === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("enumType");
                }
                /*UniversalTagNumber*/ let TagNumber = 10/*UniversalTagNumber.Enumerated*/;
                /*Asn1Tag*/ let localTag = expectedTag ?? $.$sfa.SFA.Asn1Tag.Enumerated;
                /*Type*/ let backingType = enumType.GetEnumUnderlyingType();
                if (enumType.IsDefined($.$$.S.FlagsAttribute.$type, false))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_EnumeratedValueRequiresNonFlagsEnum, "enumType");
                }
                /*int*/ let sizeLimit = $.$sfa.SFA.AsnDecoder.GetPrimitiveIntegerSize(backingType);
                if (backingType === $.$$.S.Int32.$type || backingType === $.$$.S.Int64.$type || backingType === $.$$.S.Int16.$type || backingType === $.$$.S.SByte.$type)
                {
                    /*long*/ let value;
                    /*int*/ let consumed;
                    if (!$.$sfa.SFA.AsnDecoder.TryReadSignedInteger(source, ruleSet, sizeLimit, localTag, TagNumber, $.$ref(() => value, ($v) => value = $v, $.$$.S.Int64), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32)))
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_EnumeratedValueTooBig);
                    }
                    bytesConsumed.$v = consumed;
                    return $.$cast($.$$.S.Enum.ToObject$3(enumType, value), $.$$.S.Enum);
                }
                if (backingType === $.$$.S.UInt32.$type || backingType === $.$$.S.UInt64.$type || backingType === $.$$.S.UInt16.$type || backingType === $.$$.S.Byte.$type)
                {
                    /*ulong*/ let value;
                    /*int*/ let consumed;
                    if (!$.$sfa.SFA.AsnDecoder.TryReadUnsignedInteger(source, ruleSet, sizeLimit, localTag, TagNumber, $.$ref(() => value, ($v) => value = $v, $.$$.S.UInt64), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32)))
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_EnumeratedValueTooBig);
                    }
                    bytesConsumed.$v = consumed;
                    return $.$cast($.$$.S.Enum.ToObject$8(enumType, value), $.$$.S.Enum);
                }
                throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.Format$6($.$sfa.S.SR.Argument_EnumeratedValueBackingTypeNotSupported, backingType.FullName));
            }
            //--TRIMMABLE-BOUNDARY-END(141734182931)
            
            //--TRIMMABLE-BOUNDARY-START(201863725075)
            static /*void */ ReadSetOf(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed, /*bool*/ skipSortOrderValidation, /*Asn1Tag?*/ expectedTag)
            {
                /*int?*/ let length;
                /*int*/ let headerLength;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863725075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Asn1Tag*/ let tag = $.$sfa.SFA.AsnDecoder.ReadTagAndLength(source, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.S.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.S.Int32));
                $.$sfa.SFA.AsnDecoder.CheckExpectedTag(tag, expectedTag ?? $.$sfa.SFA.Asn1Tag.SetOf, 17/*UniversalTagNumber.SetOf*/);
                if (!tag.IsConstructed)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.Format$6($.$sfa.S.SR.ContentException_ConstructedEncodingRequired, $.$box(17/*UniversalTagNumber.SetOf*/, $.$sfa.SFA.UniversalTagNumber)));
                }
                /*int*/ let suffix;
                /*ReadOnlySpan<byte>*/ let contents;
                if ($.$$.S.Nullable$$($.$$.S.Int32).HasValue$get.call(length))
                {
                    suffix = 0;
                    contents = $.$sfa.SFA.AsnDecoder.Slice$1(source, headerLength, $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(length));
                }
                else 
                {
                    /*int*/ let actualLength = $.$sfa.SFA.AsnDecoder.SeekEndOfContents(source.Slice$1(headerLength), ruleSet);
                    contents = $.$sfa.SFA.AsnDecoder.Slice$1(source, headerLength, actualLength);
                    suffix = 2/*EndOfContentsEncodedLength*/;
                }
                if (!skipSortOrderValidation)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                    {
                        /*ReadOnlySpan<byte>*/ let remaining = contents;
                        /*ReadOnlySpan<byte>*/ let previous = new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))();
                        while(!remaining.IsEmpty)
                        {
                            /*int*/ let consumed;
                            $.$sfa.SFA.AsnDecoder.ReadEncodedValue(remaining, ruleSet, $.$discardRef(), $.$discardRef(), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32));
                            /*ReadOnlySpan<byte>*/ let current = remaining.Slice(0, consumed);
                            remaining = remaining.Slice$1(consumed);
                            if ($.$sfa.SFA.SetOfValueComparer.Compare$1(current, previous) < 0)
                            {
                                throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_SetOfNotSorted);
                            }
                            previous = current;
                        }
                    }
                }
                contentOffset.$v = headerLength;
                contentLength.$v = contents.Length;
                bytesConsumed.$v = ((((headerLength + contents.Length) | 0) + suffix) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(201863725075)
            
            //--TRIMMABLE-BOUNDARY-START(176093921299)
            static /*TFlagsEnum */ ReadNamedBitListValue$1(TFlagsEnum, /*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093921299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let tFlagsEnum = TFlagsEnum.$type;
                /*TFlagsEnum*/ let ret = $.$cast($.$$.S.Enum.ToObject$4(tFlagsEnum, $.$sfa.SFA.AsnDecoder.ReadNamedBitListValue(source, ruleSet, tFlagsEnum, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag))), TFlagsEnum);
                bytesConsumed.$v = consumed;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(176093921299)
            
            //--TRIMMABLE-BOUNDARY-START(171798954003)
            static /*Enum */ ReadNamedBitListValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Type*/ flagsEnumType, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let unusedBitCount;
                /*int*/ let consumed;
                /*int*/ let bytesWritten;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798954003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (flagsEnumType === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("flagsEnumType");
                }
                /*Type*/ let backingType = flagsEnumType.GetEnumUnderlyingType();
                if (!flagsEnumType.IsDefined($.$$.S.FlagsAttribute.$type, false))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_NamedBitListRequiresFlagsEnum, "flagsEnumType");
                }
                /*Span<byte>*/ let stackSpan = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Byte, 8, null);
                /*int*/ let sizeLimit = $.$sfa.SFA.AsnDecoder.GetPrimitiveIntegerSize(backingType);
                stackSpan = stackSpan.Slice(0, sizeLimit);
                /*bool*/ let read = $.$sfa.SFA.AsnDecoder.TryReadBitString(source, stackSpan, ruleSet, $.$ref(() => unusedBitCount, ($v) => unusedBitCount = $v, $.$$.S.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.S.Int32), $.$clone(expectedTag));
                if (!read)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.Format$6($.$sfa.S.SR.ContentException_NamedBitListValueTooBig, flagsEnumType.Name));
                }
                /*Enum*/ let ret;
                if (bytesWritten === 0)
                {
                    ret = $.$cast($.$$.S.Enum.ToObject$2(flagsEnumType, 0), $.$$.S.Enum);
                    bytesConsumed.$v = consumed;
                    return ret;
                }
                /*ReadOnlySpan<byte>*/ let valueSpan = $.$$.S.Span$$($.$$.S.Byte).op_Implicit(stackSpan.Slice(0, bytesWritten));
                if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                {
                    /*byte*/ let lastByte = valueSpan._reference.GetAt(((bytesWritten - 1) | 0));
                    /*byte*/ let testBit = $.$cast((1 << unusedBitCount), $.$$.S.Byte);
                    if ((lastByte & testBit) === 0)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                ret = $.$cast($.$$.S.Enum.ToObject$3(flagsEnumType, $.$sfa.SFA.AsnDecoder.InterpretNamedBitListReversed(valueSpan)), $.$$.S.Enum);
                bytesConsumed.$v = consumed;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(171798954003)
            
            //--TRIMMABLE-BOUNDARY-START(167503986707)
            static /*BitArray */ ReadNamedBitList(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let contentLength;
                /*int*/ let unusedBitCount;
                /*int*/ let consumed;
                /*int*/ let written;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503986707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Asn1Tag*/ let actualTag = $.$sfa.SFA.AsnDecoder.ReadEncodedValue(source, ruleSet, $.$discardRef(), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$$.S.Int32), $.$discardRef());
                if (expectedTag !== null)
                {
                    $.$sfa.SFA.AsnDecoder.CheckExpectedTag(actualTag, $.$$.S.Nullable$$($.$sfa.SFA.Asn1Tag).Value$get.call(expectedTag), 3/*UniversalTagNumber.BitString*/);
                }
                /*byte[]*/ let rented = $.$sfa.SSC.CryptoPool.Rent(contentLength);
                if (!$.$sfa.SFA.AsnDecoder.TryReadBitString(source, $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(rented), ruleSet, $.$ref(() => unusedBitCount, ($v) => unusedBitCount = $v, $.$$.S.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$ref(() => written, ($v) => written = $v, $.$$.S.Int32), $.$clone(expectedTag)))
                {
                    $.$$.SD.Debug.Fail$1("TryReadBitString failed with an over-allocated buffer");
                    throw new $.$$.S.InvalidOperationException().$ctor$9();
                }
                /*int*/ let validBitCount = $.$checked($.$checked(written * 8, 1) - unusedBitCount, 1);
                /*Span<byte>*/ let valueSpan = $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, rented, 0, written);
                $.$sfa.SFA.AsnDecoder.ReverseBitsPerByte(valueSpan);
                /*BitArray*/ let ret = new $.$$.SC$1.BitArray().$ctor$2(rented);
                $.$sfa.SSC.CryptoPool.Return$1(rented, written);
                ret.Length = validBitCount;
                bytesConsumed.$v = consumed;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(167503986707)
            
            //--TRIMMABLE-BOUNDARY-START(77309673491)
            static /*long */ InterpretNamedBitListReversed(/*ReadOnlySpan<byte>*/ valueSpan)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309673491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(valueSpan.Length <= 8, "valueSpan.Length <= sizeof(long)");
                /*long*/ let accum = 0n;
                /*long*/ let currentBitValue = 1n;
                for(/*int*/ let byteIdx = 0; byteIdx < valueSpan.Length; byteIdx++)
                {
                    /*byte*/ let byteVal = valueSpan._reference.GetAt(byteIdx);
                    for(/*int*/ let bitIndex = 7; bitIndex >= 0; bitIndex--)
                    {
                        /*int*/ let test = 1 << bitIndex;
                        if ((byteVal & test) !== 0)
                        {
                            accum |= currentBitValue;
                        }
                        currentBitValue <<= 1n;
                    }
                }
                return accum;
            }
            //--TRIMMABLE-BOUNDARY-END(77309673491)
            
            //--TRIMMABLE-BOUNDARY-START(219043594259)
            static /*void */ ReverseBitsPerByte(/*Span<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043594259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let byteIdx = 0; byteIdx < value.Length; byteIdx++)
                {
                    value._reference.SetAt($.$cast(((BigInt.asUintN(64, BigInt(value._reference.GetAt(byteIdx)) * 8623620610n) & 1136090292240n) % 1023n), $.$$.S.Byte), byteIdx);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219043594259)
            
            //--TRIMMABLE-BOUNDARY-START(214748626963)
            static /*DateTimeOffset */ ReadUtcTime(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*int*/ twoDigitYearMax, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let bytesRead;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748626963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (twoDigitYearMax < 1 || twoDigitYearMax > 9999)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("twoDigitYearMax");
                }
                /*Span<byte>*/ let tmpSpace = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Byte, 17, null);
                /*byte[]?*/ let rented = null;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.SFA.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag ?? $.$sfa.SFA.Asn1Tag.UtcTime, 23/*UniversalTagNumber.UtcTime*/, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.S.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.S.Byte)), tmpSpace);
                /*DateTimeOffset*/ let value = $.$sfa.SFA.AsnDecoder.ParseUtcTime(contents, ruleSet, twoDigitYearMax);
                if (rented !== null)
                {
                    $.$$.SD.Debug.Fail$1(`UtcTime did not fit in tmpSpace (${$.$strNN(contents.Length)} total)`);
                    $.$sfa.SSC.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = bytesRead;
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(214748626963)
            
            //--TRIMMABLE-BOUNDARY-START(107374444563)
            static /*DateTimeOffset */ ParseUtcTime(/*ReadOnlySpan<byte>*/ contentOctets, /*AsnEncodingRules*/ ruleSet, /*int*/ twoDigitYearMax)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374444563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let NoSecondsZulu = 11;
                /*int*/ let NoSecondsOffset = 15;
                /*int*/ let HasSecondsZulu = 13;
                /*int*/ let HasSecondsOffset = 17;
                if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (contentOctets.Length !== HasSecondsZulu)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                if (contentOctets.Length < NoSecondsZulu || contentOctets.Length > HasSecondsOffset || (contentOctets.Length & 1) !== 1)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
                /*ReadOnlySpan<byte>*/ let contents = contentOctets;
                /*int*/ let year = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                /*int*/ let month = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                /*int*/ let day = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                /*int*/ let hour = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                /*int*/ let minute = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                /*int*/ let second = 0;
                /*int*/ let offsetHour = 0;
                /*int*/ let offsetMinute = 0;
                /*bool*/ let minus = false;
                if (contentOctets.Length === HasSecondsOffset || contentOctets.Length === HasSecondsZulu)
                {
                    second = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                }
                if (contentOctets.Length === NoSecondsZulu || contentOctets.Length === HasSecondsZulu)
                {
                    if (contents._reference.GetAt(0) !== /*Z*/ 90)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                    }
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4(contentOctets.Length === NoSecondsOffset || contentOctets.Length === HasSecondsOffset, "contentOctets.Length == NoSecondsOffset ||\r\n                    contentOctets.Length == HasSecondsOffset");
                    if (contents._reference.GetAt(0) === /*-*/ 45)
                    {
                        minus = true;
                    }
                    else if (contents._reference.GetAt(0) !== /*+*/ 43)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                    }
                    contents = contents.Slice$1(1);
                    offsetHour = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                    offsetMinute = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                    $.$$.SD.Debug.Assert$4(contents.IsEmpty, "contents.IsEmpty");
                }
                if (offsetMinute > 59)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
                /*TimeSpan*/ let offset = new $.$$.S.TimeSpan().$ctor$6(offsetHour, offsetMinute, 0);
                if (minus)
                {
                    offset = $.$$.S.TimeSpan.op_UnaryNegation(offset);
                }
                /*int*/ let century = $.trunc(twoDigitYearMax / 100);
                if (year > twoDigitYearMax % 100)
                {
                    century--;
                }
                /*int*/ let scaledYear = ((((century * 100) | 0) + year) | 0);
                try
                {
                    return new $.$$.S.DateTimeOffset().$ctor$11(scaledYear, month, day, hour, minute, second, offset);
                }
                catch(e)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$7($.$sfa.S.SR.ContentException_DefaultMessage, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374444563)
            
            //--TRIMMABLE-BOUNDARY-START(150324117523)
            static /*DateTimeOffset */ ReadGeneralizedTime(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let bytesRead;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324117523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]?*/ let rented = null;
                /*int*/ let StackBufSize = 64;
                /*Span<byte>*/ let tmpSpace = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Byte, StackBufSize, null);
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.SFA.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag ?? $.$sfa.SFA.Asn1Tag.GeneralizedTime, 24/*UniversalTagNumber.GeneralizedTime*/, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.S.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.S.Byte)), tmpSpace);
                /*DateTimeOffset*/ let value = $.$sfa.SFA.AsnDecoder.ParseGeneralizedTime(ruleSet, contents);
                if (rented !== null)
                {
                    $.$sfa.SSC.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = bytesRead;
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(150324117523)
            
            //--TRIMMABLE-BOUNDARY-START(90194575379)
            static /*DateTimeOffset */ ParseGeneralizedTime(/*AsnEncodingRules*/ ruleSet, /*ReadOnlySpan<byte>*/ contentOctets)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let strict = ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/;
                if (strict && contentOctets.Length < 15)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                else if (contentOctets.Length < 10)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
                /*ReadOnlySpan<byte>*/ let contents = contentOctets;
                /*int*/ let year = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 4);
                /*int*/ let month = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                /*int*/ let day = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                /*int*/ let hour = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                /*int?*/ let minute = null;
                /*int?*/ let second = null;
                /*ulong*/ let fraction = 0n;
                /*ulong*/ let fractionScale = 1n;
                /*byte*/ let lastFracDigit = 255;
                /*TimeSpan?*/ let timeOffset = null;
                /*bool*/ let isZulu = false;
                /*byte*/ let HmsState = 0;
                /*byte*/ let FracState = 1;
                /*byte*/ let SuffixState = 2;
                /*byte*/ let state = HmsState;
                /*static byte?*/  function GetNextState(/*byte*/ octet)
                {
                    if (octet === /*Z*/ 90 || octet === /*-*/ 45 || octet === /*+*/ 43)
                    {
                        return SuffixState;
                    }
                    if (octet === /*.*/ 46 || octet === /*,*/ 44)
                    {
                        return FracState;
                    }
                    return null;
                }
                while(state === HmsState && contents.Length !== 0)
                {
                    /*byte?*/ let nextState = GetNextState(contents._reference.GetAt(0));
                    if (nextState === null)
                    {
                        if (minute === null)
                        {
                            minute = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                        }
                        else if (second === null)
                        {
                            second = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                        }
                        else 
                        {
                            throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                        }
                    }
                    else 
                    {
                        state = $.$$.S.Nullable$$($.$$.S.Byte).Value$get.call(nextState);
                    }
                }
                if (state === FracState)
                {
                    /*int*/ let fracLength;
                    /*uint*/ let nonSemantic;
                    $.$$.SD.Debug.Assert$4(!contents.IsEmpty, "!contents.IsEmpty");
                    /*byte*/ let octet = contents._reference.GetAt(0);
                    $.$$.SD.Debug.Assert$4(state === GetNextState(octet), "state == GetNextState(octet)");
                    if (octet === /*.*/ 46)
                    {
                    }
                    else if (octet === /*,*/ 44)
                    {
                        if (strict)
                        {
                            throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                        }
                    }
                    else 
                    {
                        $.$$.SD.Debug.Fail$1((() =>
                        {
                            var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(2, 2);
                            $handler.AppendLiteral("Unhandled value '");
                            $handler.AppendFormatted($.$box(octet, $.$$.S.Byte), null, "X2");
                            $handler.AppendLiteral("' in ");
                            $handler.AppendFormatted($.$box("FracState", $.$$.S.String), null, null);
                            return $handler.ToStringAndClear                    ();
                        })());
                        throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                    }
                    contents = contents.Slice$1(1);
                    if (contents.IsEmpty)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                    }
                    if (!$.$$.SBT.Utf8Parser.TryParse$15($.$sfa.SFA.AsnDecoder.SliceAtMost(contents, 12), $.$ref(() => fraction, ($v) => fraction = $v, $.$$.S.UInt64), $.$ref(() => fracLength, ($v) => fracLength = $v, $.$$.S.Int32), /*\u0000*/ 0) || fracLength === 0)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                    }
                    lastFracDigit = $.$cast((fraction % 10n), $.$$.S.Byte);
                    for(/*int*/ let i = 0; i < fracLength; i++)
                    {
                        fractionScale *= 10n;
                    }
                    contents = contents.Slice$1(fracLength);
                    while($.$$.SBT.Utf8Parser.TryParse$14($.$sfa.SFA.AsnDecoder.SliceAtMost(contents, 9), $.$ref(() => nonSemantic, ($v) => nonSemantic = $v, $.$$.S.UInt32), $.$ref(() => fracLength, ($v) => fracLength = $v, $.$$.S.Int32), /*\u0000*/ 0))
                    {
                        contents = contents.Slice$1(fracLength);
                        lastFracDigit = (((nonSemantic % 10) & 0xFF) >>> 0);
                    }
                    if (contents.Length !== 0)
                    {
                        /*byte?*/ let nextState = GetNextState(contents._reference.GetAt(0));
                        if (nextState === null)
                        {
                            throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                        }
                        state = $.$$.S.Nullable$$($.$$.S.Byte).Value$get.call(nextState);
                    }
                }
                if (state === SuffixState)
                {
                    $.$$.SD.Debug.Assert$4(!contents.IsEmpty, "!contents.IsEmpty");
                    /*byte*/ let octet = contents._reference.GetAt(0);
                    $.$$.SD.Debug.Assert$4(state === GetNextState(octet), "state == GetNextState(octet)");
                    contents = contents.Slice$1(1);
                    if (octet === /*Z*/ 90)
                    {
                        timeOffset = $.$$.S.TimeSpan.Zero;
                        isZulu = true;
                    }
                    else 
                    {
                        /*bool*/ let isMinus;
                        if (octet === /*+*/ 43)
                        {
                            isMinus = false;
                        }
                        else if (octet === /*-*/ 45)
                        {
                            isMinus = true;
                        }
                        else 
                        {
                            $.$$.SD.Debug.Fail$1((() =>
                            {
                                var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(2, 2);
                                $handler.AppendLiteral("Unhandled value '");
                                $handler.AppendFormatted($.$box(octet, $.$$.S.Byte), null, "X2");
                                $handler.AppendLiteral("' in ");
                                $handler.AppendFormatted($.$box("SuffixState", $.$$.S.String), null, null);
                                return $handler.ToStringAndClear                        ();
                            })());
                            throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                        }
                        if (contents.IsEmpty)
                        {
                            throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                        }
                        /*int*/ let offsetHour = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                        /*int*/ let offsetMinute = 0;
                        if (contents.Length !== 0)
                        {
                            offsetMinute = $.$sfa.SFA.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Byte), () => contents, ($v) => contents = $v, null, true), 2);
                        }
                        if (offsetMinute > 59)
                        {
                            throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                        }
                        /*TimeSpan*/ let tmp = new $.$$.S.TimeSpan().$ctor$6(offsetHour, offsetMinute, 0);
                        if (isMinus)
                        {
                            tmp = $.$$.S.TimeSpan.op_UnaryNegation(tmp);
                        }
                        timeOffset = tmp;
                    }
                }
                if (!contents.IsEmpty)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
                if (strict)
                {
                    if (!isZulu || !$.$$.S.Nullable$$($.$$.S.Int32).HasValue$get.call(second))
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                    if (lastFracDigit === 0)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                /*double*/ let frac = $.$cast(fraction, $.$$.S.Double) / Number(fractionScale);
                /*TimeSpan*/ let fractionSpan = $.$$.S.TimeSpan.Zero;
                if (!$.$$.S.Nullable$$($.$$.S.Int32).HasValue$get.call(minute))
                {
                    minute = 0;
                    second = 0;
                    if (fraction !== 0n)
                    {
                        fractionSpan = new $.$$.S.TimeSpan().$ctor$7($.$cast((frac * Number(36000000000n)), $.$$.S.Int64));
                    }
                }
                else if (!$.$$.S.Nullable$$($.$$.S.Int32).HasValue$get.call(second))
                {
                    second = 0;
                    if (fraction !== 0n)
                    {
                        fractionSpan = new $.$$.S.TimeSpan().$ctor$7($.$cast((frac * Number(600000000n)), $.$$.S.Int64));
                    }
                }
                else if (fraction !== 0n)
                {
                    fractionSpan = new $.$$.S.TimeSpan().$ctor$7($.$cast((frac * Number(10000000n)), $.$$.S.Int64));
                }
                /*DateTimeOffset*/ let value;
                try
                {
                    if (timeOffset === null)
                    {
                        value = new $.$$.S.DateTimeOffset().$ctor$5(new $.$$.S.DateTime().$ctor$16(year, month, day, hour, $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(minute), $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(second)));
                    }
                    else 
                    {
                        value = new $.$$.S.DateTimeOffset().$ctor$11(year, month, day, hour, $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(minute), $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(second), $.$$.S.Nullable$$($.$$.S.TimeSpan).Value$get.call(timeOffset));
                    }
                    value = $.$$.S.DateTimeOffset.op_Addition(value, fractionSpan);
                    return value;
                }
                catch(e)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$7($.$sfa.S.SR.ContentException_DefaultMessage, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194575379)
            
            //--TRIMMABLE-BOUNDARY-START(184683855891)
            static /*string */ ReadObjectIdentifier(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683855891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.SFA.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag ?? $.$sfa.SFA.Asn1Tag.ObjectIdentifier, 6/*UniversalTagNumber.ObjectIdentifier*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32));
                /*string?*/ let wellKnown = $.$sfa.SFA.WellKnownOids.GetValue(contents);
                if (!(wellKnown === null))
                {
                    bytesConsumed.$v = consumed;
                    return wellKnown;
                }
                /*string*/ let ret = $.$sfa.SFA.AsnDecoder.ReadObjectIdentifier$1(contents);
                bytesConsumed.$v = consumed;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(184683855891)
            
            //--TRIMMABLE-BOUNDARY-START(206158692371)
            static /*void */ ReadSubIdentifier(/*ReadOnlySpan<byte>*/ source, /*out int*/ bytesRead, /*out long?*/ smallValue, /*out BigInteger?*/ largeValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158692371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(source.Length > 0, "source.Length > 0");
                if (source._reference.GetAt(0) === 128)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
                /*int*/ let semanticBits = (() =>
                {
                    let $switch47 = source.get_Item(0).$v;
                    if ($switch47 >= 192)
                    {
                        return 0;
                    }
                    if ($switch47 >= 160)
                    {
                        return -1;
                    }
                    if ($switch47 >= 144)
                    {
                        return -2;
                    }
                    if ($switch47 >= 136)
                    {
                        return -3;
                    }
                    if ($switch47 >= 132)
                    {
                        return -4;
                    }
                    if ($switch47 >= 130)
                    {
                        return -5;
                    }
                    if ($switch47 >= 129)
                    {
                        return -6;
                    }
                    return 0;
                })();
                /*int*/ let end = -1;
                /*int*/ let idx;
                /*int*/ let MaxAllowedBits = 128;
                for(idx = 0; idx < source.Length; idx++)
                {
                    semanticBits += 7;
                    if (semanticBits > MaxAllowedBits)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_OidTooBig);
                    }
                    /*bool*/ let endOfIdentifier = (source._reference.GetAt(idx) & 128) === 0;
                    if (endOfIdentifier)
                    {
                        end = idx;
                        break;
                    }
                }
                if (end < 0)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
                bytesRead.$v = ((end + 1) | 0);
                /*long*/ let accum = 0n;
                if (bytesRead.$v <= 9)
                {
                    for(idx = 0; idx < bytesRead.$v; idx++)
                    {
                        /*byte*/ let cur = source._reference.GetAt(idx);
                        accum <<= 7n;
                        accum |= BigInt($.$cast((cur & 127), $.$$.S.Byte));
                    }
                    largeValue.$v = null;
                    smallValue.$v = accum;
                    return;
                }
                /*int*/ let SemanticByteCount = 7;
                /*int*/ let ContentByteCount = 8;
                /*int*/ let bytesRequired = (((((($.trunc(bytesRead.$v / ContentByteCount)) + 1) | 0)) * SemanticByteCount) | 0);
                /*byte[]*/ let tmpBytes = $.$sfa.SSC.CryptoPool.Rent(bytesRequired);
                $.$$.S.Array.Clear(tmpBytes, 0, tmpBytes.length);
                /*Span<byte>*/ let writeSpan = $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(tmpBytes);
                /*Span<byte>*/ let accumValueBytes = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Byte, 8, null);
                /*int*/ let nextStop = bytesRead.$v;
                idx = ((bytesRead.$v - ContentByteCount) | 0);
                while(nextStop > 0)
                {
                    /*byte*/ let cur = source._reference.GetAt(idx);
                    accum <<= 7n;
                    accum |= BigInt($.$cast((cur & 127), $.$$.S.Byte));
                    idx++;
                    if (idx >= nextStop)
                    {
                        $.$$.SD.Debug.Assert$4(idx === nextStop, "idx == nextStop");
                        $.$$.SD.Debug.Assert$4(writeSpan.Length >= SemanticByteCount, "writeSpan.Length >= SemanticByteCount");
                        $.$$.SBB.BinaryPrimitives.WriteInt64LittleEndian(accumValueBytes, accum);
                        $.$$.SD.Debug.Assert$4(accumValueBytes._reference.GetAt(7) === 0, "accumValueBytes[7] == 0");
                        accumValueBytes.Slice(0, SemanticByteCount).CopyTo(writeSpan);
                        writeSpan = writeSpan.Slice$1(SemanticByteCount);
                        accum = 0n;
                        nextStop -= ContentByteCount;
                        idx = $.$$.S.Math.Max$4(0, ((nextStop - ContentByteCount) | 0));
                    }
                }
                /*int*/ let bytesWritten = ((tmpBytes.length - writeSpan.Length) | 0);
                /*int*/ let paddingByteCount = ((bytesRequired - bytesWritten) | 0);
                $.$$.SD.Debug.Assert$4(paddingByteCount >= 0 && paddingByteCount < 8, "paddingByteCount >= 0 && paddingByteCount < sizeof(long)");
                largeValue.$v = new $.$srn.SN.BigInteger().$ctor$3(tmpBytes);
                smallValue.$v = null;
                $.$sfa.SSC.CryptoPool.Return$1(tmpBytes, bytesWritten);
            }
            //--TRIMMABLE-BOUNDARY-END(206158692371)
            
            //--TRIMMABLE-BOUNDARY-START(188978823187)
            static /*string */ ReadObjectIdentifier$1(/*ReadOnlySpan<byte>*/ contents)
            {
                /*int*/ let bytesRead;
                /*long?*/ let smallValue;
                /*BigInteger?*/ let largeValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978823187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (contents.Length < 1)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
                /*StringBuilder*/ let builder = new $.$$.ST.StringBuilder().$ctor$4(((($.$cast(contents.Length, $.$$.S.Byte)) * 4) | 0));
                $.$sfa.SFA.AsnDecoder.ReadSubIdentifier(contents, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.S.Int32), $.$ref(() => smallValue, ($v) => smallValue = $v, $.$typeNullable($.$$.S.Int64)), $.$ref(() => largeValue, ($v) => largeValue = $v, $.$typeNullable($.$srn.SN.BigInteger)));
                /*byte*/ let firstArc;
                if (smallValue !== null)
                {
                    /*long*/ let firstIdentifier = $.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(smallValue);
                    if (firstIdentifier < 40n)
                    {
                        firstArc = 0;
                    }
                    else if (firstIdentifier < 80n)
                    {
                        firstArc = 1;
                        firstIdentifier -= 40n;
                    }
                    else 
                    {
                        firstArc = 2;
                        firstIdentifier -= 80n;
                    }
                    builder.Append$3(firstArc);
                    builder.Append$5(/*.*/ 46);
                    builder.Append$14(firstIdentifier);
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4(largeValue !== null, "largeValue != null");
                    /*BigInteger*/ let firstIdentifier = $.$$.S.Nullable$$($.$srn.SN.BigInteger).Value$get.call(largeValue);
                    $.$$.SD.Debug.Assert$4($.$srn.SN.BigInteger.op_GreaterThan$2(firstIdentifier, 9223372036854775807n), "firstIdentifier > long.MaxValue");
                    firstArc = 2;
                    firstIdentifier = $.$srn.SN.BigInteger.op_Subtraction(firstIdentifier, $.$srn.SN.BigInteger.op_Implicit$4(80));
                    builder.Append$3(firstArc);
                    builder.Append$5(/*.*/ 46);
                    builder.Append$21(firstIdentifier.ToString());
                }
                contents = contents.Slice$1(bytesRead);
                /*int*/ let MaxArcs = 64;
                /*int*/ let remainingArcs = ((MaxArcs - 2) | 0);
                while(!contents.IsEmpty)
                {
                    if (remainingArcs <= 0)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_OidTooBig);
                    }
                    remainingArcs--;
                    $.$sfa.SFA.AsnDecoder.ReadSubIdentifier(contents, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.S.Int32), $.$ref(() => smallValue, ($v) => smallValue = $v, $.$typeNullable($.$$.S.Int64)), $.$ref(() => largeValue, ($v) => largeValue = $v, $.$typeNullable($.$srn.SN.BigInteger)));
                    $.$$.SD.Debug.Assert$4((smallValue === null) !== (largeValue === null), "(smallValue == null) != (largeValue == null)");
                    builder.Append$5(/*.*/ 46);
                    if (smallValue !== null)
                    {
                        builder.Append$14($.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(smallValue));
                    }
                    else 
                    {
                        builder.Append$21($.$$.S.Nullable$$($.$srn.SN.BigInteger).Value$get.call(largeValue).ToString());
                    }
                    contents = contents.Slice$1(bytesRead);
                }
                return builder.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(188978823187)
            
            //--TRIMMABLE-BOUNDARY-START(85899608083)
            /*int*/ static MaxCERSegmentSize = 1000;
            //--TRIMMABLE-BOUNDARY-END(85899608083)
            
            //--TRIMMABLE-BOUNDARY-START(51539869715)
            /*int*/ static EndOfContentsEncodedLength = 2;
            //--TRIMMABLE-BOUNDARY-END(51539869715)
            
            //--TRIMMABLE-BOUNDARY-START(283468103699)
            static /*bool */ TryReadEncodedValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out Asn1Tag*/ tag, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed)
            {
                /*Asn1Tag*/ let localTag;
                /*int*/ let tagLength;
                /*int?*/ let encodedLength;
                /*int*/ let lengthLength;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468103699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnDecoder.CheckEncodingRules(ruleSet);
                if ($.$sfa.SFA.Asn1Tag.TryDecode(source, $.$ref(() => localTag, ($v) => localTag = $v, $.$sfa.SFA.Asn1Tag), $.$ref(() => tagLength, ($v) => tagLength = $v, $.$$.S.Int32)) && $.$sfa.SFA.AsnDecoder.TryReadLength(source.Slice$1(tagLength), ruleSet, $.$ref(() => encodedLength, ($v) => encodedLength = $v, $.$typeNullable($.$$.S.Int32)), $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$$.S.Int32)))
                {
                    /*int*/ let len;
                    /*int*/ let consumed;
                    /*int*/ let headerLength = ((tagLength + lengthLength) | 0);
                    /*LengthValidity*/ let validity = $.$sfa.SFA.AsnDecoder.ValidateLength(source.Slice$1(headerLength), ruleSet, localTag, encodedLength, $.$ref(() => len, ($v) => len = $v, $.$$.S.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32));
                    if (validity === 3/*LengthValidity.Valid*/)
                    {
                        tag.$v = localTag;
                        contentOffset.$v = headerLength;
                        contentLength.$v = len;
                        bytesConsumed.$v = ((headerLength + consumed) | 0);
                        return true;
                    }
                }
                tag.$v = new $.$sfa.SFA.Asn1Tag();
                contentOffset.$v = contentLength.$v = bytesConsumed.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(283468103699)
            
            //--TRIMMABLE-BOUNDARY-START(133144248339)
            static /*Asn1Tag */ ReadEncodedValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed)
            {
                /*int*/ let tagLength;
                /*int*/ let lengthLength;
                /*int*/ let len;
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144248339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnDecoder.CheckEncodingRules(ruleSet);
                /*Asn1Tag*/ let tag = $.$sfa.SFA.Asn1Tag.Decode(source, $.$ref(() => tagLength, ($v) => tagLength = $v, $.$$.S.Int32));
                /*int?*/ let encodedLength = $.$sfa.SFA.AsnDecoder.ReadLength(source.Slice$1(tagLength), ruleSet, $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$$.S.Int32));
                /*int*/ let headerLength = ((tagLength + lengthLength) | 0);
                /*LengthValidity*/ let validity = $.$sfa.SFA.AsnDecoder.ValidateLength(source.Slice$1(headerLength), ruleSet, tag, encodedLength, $.$ref(() => len, ($v) => len = $v, $.$$.S.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32));
                if (validity === 3/*LengthValidity.Valid*/)
                {
                    contentOffset.$v = headerLength;
                    contentLength.$v = len;
                    bytesConsumed.$v = ((headerLength + consumed) | 0);
                    return tag;
                }
                throw $.$sfa.SFA.AsnDecoder.GetValidityException(validity);
            }
            //--TRIMMABLE-BOUNDARY-END(133144248339)
            
            //--TRIMMABLE-BOUNDARY-START(64424771603)
            static /*ReadOnlySpan<byte> */ GetPrimitiveContentSpan(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out int*/ bytesConsumed)
            {
                /*int*/ let tagLength;
                /*int*/ let lengthLength;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424771603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnDecoder.CheckEncodingRules(ruleSet);
                /*Asn1Tag*/ let localTag = $.$sfa.SFA.Asn1Tag.Decode(source, $.$ref(() => tagLength, ($v) => tagLength = $v, $.$$.S.Int32));
                /*int?*/ let encodedLength = $.$sfa.SFA.AsnDecoder.ReadLength(source.Slice$1(tagLength), ruleSet, $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$$.S.Int32));
                /*int*/ let headerLength = ((tagLength + lengthLength) | 0);
                $.$sfa.SFA.AsnDecoder.CheckExpectedTag(localTag, expectedTag, tagNumber);
                if (localTag.IsConstructed)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.Format$6($.$sfa.S.SR.ContentException_PrimitiveEncodingRequired, $.$box(tagNumber, $.$sfa.SFA.UniversalTagNumber)));
                }
                if (encodedLength === null)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
                /*ReadOnlySpan<byte>*/ let ret = $.$sfa.SFA.AsnDecoder.Slice$1(source, headerLength, $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(encodedLength));
                bytesConsumed.$v = ((headerLength + ret.Length) | 0);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(64424771603)
            
            //--TRIMMABLE-BOUNDARY-START(42949935123)
            static /*int? */ DecodeLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed)
            {
                /*int*/ let read;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnDecoder.CheckEncodingRules(ruleSet);
                /*int?*/ let ret = $.$sfa.SFA.AsnDecoder.ReadLength(source, ruleSet, $.$ref(() => read, ($v) => read = $v, $.$$.S.Int32));
                bytesConsumed.$v = read;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(42949935123)
            
            //--TRIMMABLE-BOUNDARY-START(253403332627)
            static /*bool */ TryDecodeLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ decodedLength, /*out int*/ bytesConsumed)
            {
                /*int?*/ let decoded;
                /*int*/ let read;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403332627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnDecoder.CheckEncodingRules(ruleSet);
                /*bool*/ let ret = $.$sfa.SFA.AsnDecoder.TryReadLength(source, ruleSet, $.$ref(() => decoded, ($v) => decoded = $v, $.$typeNullable($.$$.S.Int32)), $.$ref(() => read, ($v) => read = $v, $.$$.S.Int32));
                bytesConsumed.$v = read;
                decodedLength.$v = decoded;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(253403332627)
            
            //--TRIMMABLE-BOUNDARY-START(296353005587)
            static /*bool */ TryReadLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ length, /*out int*/ bytesRead)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353005587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.AsnDecoder.DecodeLength$1(source, ruleSet, length, bytesRead) === 5/*LengthDecodeStatus.Success*/;
            }
            //--TRIMMABLE-BOUNDARY-END(296353005587)
            
            //--TRIMMABLE-BOUNDARY-START(163209019411)
            static /*int? */ ReadLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed)
            {
                /*int?*/ let length;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209019411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LengthDecodeStatus*/ let status = $.$sfa.SFA.AsnDecoder.DecodeLength$1(source, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.S.Int32)), bytesConsumed);
                let $switchJumpState73;
                $switchJumpStart73: while(true)
                {
                    switch($switchJumpState73 ?? status)
                    {
                        case 5/*LengthDecodeStatus.Success*/:
                        return length;
                        case 3/*LengthDecodeStatus.LengthTooBig*/:
                        throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_LengthTooBig);
                        case 4/*LengthDecodeStatus.LaxEncodingProhibited*/:
                        case 1/*LengthDecodeStatus.DerIndefinite*/:
                        throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_LengthRuleSetConstraint);
                        case 0/*LengthDecodeStatus.NeedMoreData*/:
                        case 2/*LengthDecodeStatus.ReservedValue*/:
                        throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                        default:
                        $.$$.SD.Debug.Fail$1(`No handler is present for status ${$.$strNN($.$$.S.Enum.ToStringT($.$sfa.SFA.AsnDecoder.LengthDecodeStatus, $.$$.S.UInt32, status))}.`);
                        $switchJumpState73 = 0/*LengthDecodeStatus.NeedMoreData*/; /*goto case LengthDecodeStatus.NeedMoreData*/
                        continue $switchJumpStart73;
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209019411)
            
            //--TRIMMABLE-BOUNDARY-START(47244902419)
            static /*LengthDecodeStatus */ DecodeLength$1(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ length, /*out int*/ bytesRead)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244902419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                length.$v = null;
                bytesRead.$v = 0;
                $.$sfa.SFA.AsnDecoder.AssertEncodingRules(ruleSet);
                if (source.IsEmpty)
                {
                    return 0/*LengthDecodeStatus.NeedMoreData*/;
                }
                /*byte*/ let lengthOrLengthLength = source._reference.GetAt(bytesRead.$v);
                bytesRead.$v++;
                /*byte*/ let MultiByteMarker = 128;
                if (lengthOrLengthLength === MultiByteMarker)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/)
                    {
                        bytesRead.$v = 0;
                        return 1/*LengthDecodeStatus.DerIndefinite*/;
                    }
                    return 5/*LengthDecodeStatus.Success*/;
                }
                if (lengthOrLengthLength < MultiByteMarker)
                {
                    length.$v = lengthOrLengthLength;
                    return 5/*LengthDecodeStatus.Success*/;
                }
                if (lengthOrLengthLength === 255)
                {
                    bytesRead.$v = 0;
                    return 2/*LengthDecodeStatus.ReservedValue*/;
                }
                /*byte*/ let lengthLength = $.$cast((lengthOrLengthLength & ~MultiByteMarker), $.$$.S.Byte);
                if (((lengthLength + 1) | 0) > source.Length)
                {
                    bytesRead.$v = 0;
                    return 0/*LengthDecodeStatus.NeedMoreData*/;
                }
                /*bool*/ let minimalRepresentation = ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/;
                if (minimalRepresentation && lengthLength > 4)
                {
                    bytesRead.$v = 0;
                    return 3/*LengthDecodeStatus.LengthTooBig*/;
                }
                /*uint*/ let parsedLength = 0;
                for(/*int*/ let i = 0; i < lengthLength; i++)
                {
                    /*byte*/ let current = source._reference.GetAt(bytesRead.$v);
                    bytesRead.$v++;
                    if (parsedLength === 0)
                    {
                        if (minimalRepresentation && current === 0)
                        {
                            bytesRead.$v = 0;
                            return 4/*LengthDecodeStatus.LaxEncodingProhibited*/;
                        }
                        if (!minimalRepresentation && current !== 0)
                        {
                            if (((lengthLength - i) | 0) > 4)
                            {
                                bytesRead.$v = 0;
                                return 3/*LengthDecodeStatus.LengthTooBig*/;
                            }
                        }
                    }
                    parsedLength <<= 8;
                    parsedLength |= current;
                }
                if (parsedLength > 2147483647/*int.MaxValue*/)
                {
                    bytesRead.$v = 0;
                    return 3/*LengthDecodeStatus.LengthTooBig*/;
                }
                if (minimalRepresentation && parsedLength < MultiByteMarker)
                {
                    bytesRead.$v = 0;
                    return 4/*LengthDecodeStatus.LaxEncodingProhibited*/;
                }
                $.$$.SD.Debug.Assert$4(bytesRead.$v > 0, "bytesRead > 0");
                length.$v = (parsedLength | 0);
                return 5/*LengthDecodeStatus.Success*/;
            }
            //--TRIMMABLE-BOUNDARY-END(47244902419)
            
            //--TRIMMABLE-BOUNDARY-START(210453659667)
            static /*Asn1Tag */ ReadTagAndLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ contentsLength, /*out int*/ bytesRead)
            {
                /*int*/ let tagBytesRead;
                /*int*/ let lengthBytesRead;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453659667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Asn1Tag*/ let tag = $.$sfa.SFA.Asn1Tag.Decode(source, $.$ref(() => tagBytesRead, ($v) => tagBytesRead = $v, $.$$.S.Int32));
                /*int?*/ let length = $.$sfa.SFA.AsnDecoder.ReadLength(source.Slice$1(tagBytesRead), ruleSet, $.$ref(() => lengthBytesRead, ($v) => lengthBytesRead = $v, $.$$.S.Int32));
                /*int*/ let allBytesRead = ((tagBytesRead + lengthBytesRead) | 0);
                if (tag.IsConstructed)
                {
                    if (ruleSet === 1/*AsnEncodingRules.CER*/ && length !== null)
                    {
                        throw $.$sfa.SFA.AsnDecoder.GetValidityException(0/*LengthValidity.CerRequiresIndefinite*/);
                    }
                }
                else if (length === null)
                {
                    throw $.$sfa.SFA.AsnDecoder.GetValidityException(1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/);
                }
                bytesRead.$v = allBytesRead;
                contentsLength.$v = length;
                return tag;
            }
            //--TRIMMABLE-BOUNDARY-END(210453659667)
            
            //--TRIMMABLE-BOUNDARY-START(343597645843)
            static /*void */ ValidateEndOfContents(/*Asn1Tag*/ tag, /*int?*/ length, /*int*/ headerLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597645843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tag.IsConstructed || length !== 0 || headerLength !== 2/*EndOfContentsEncodedLength*/)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(343597645843)
            
            //--TRIMMABLE-BOUNDARY-START(347892613139)
            static /*LengthValidity */ ValidateLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ localTag, /*int?*/ encodedLength, /*out int*/ actualLength, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892613139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (localTag.IsConstructed)
                {
                    if (ruleSet === 1/*AsnEncodingRules.CER*/ && encodedLength !== null)
                    {
                        actualLength.$v = bytesConsumed.$v = 0;
                        return 0/*LengthValidity.CerRequiresIndefinite*/;
                    }
                }
                else if (encodedLength === null)
                {
                    actualLength.$v = bytesConsumed.$v = 0;
                    return 1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/;
                }
                if (encodedLength !== null)
                {
                    /*int*/ let len = $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(encodedLength);
                    /*int*/ let totalLength = len;
                    if (totalLength > source.Length)
                    {
                        actualLength.$v = bytesConsumed.$v = 0;
                        return 2/*LengthValidity.LengthExceedsInput*/;
                    }
                    actualLength.$v = len;
                    bytesConsumed.$v = len;
                    return 3/*LengthValidity.Valid*/;
                }
                actualLength.$v = $.$sfa.SFA.AsnDecoder.SeekEndOfContents(source, ruleSet);
                bytesConsumed.$v = ((actualLength.$v + 2/*EndOfContentsEncodedLength*/) | 0);
                return 3/*LengthValidity.Valid*/;
            }
            //--TRIMMABLE-BOUNDARY-END(347892613139)
            
            //--TRIMMABLE-BOUNDARY-START(73014706195)
            static /*AsnContentException */ GetValidityException(/*LengthValidity*/ validity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(validity !== 3/*LengthValidity.Valid*/, "validity != LengthValidity.Valid");
                let $switchJumpState76;
                $switchJumpStart76: while(true)
                {
                    switch($switchJumpState76 ?? validity)
                    {
                        case 0/*LengthValidity.CerRequiresIndefinite*/:
                        return new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_CerRequiresIndefiniteLength);
                        case 2/*LengthValidity.LengthExceedsInput*/:
                        return new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_LengthExceedsPayload);
                        case 1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/:
                        return new $.$sfa.SFA.AsnContentException().$ctor$5();
                        default:
                        $.$$.SD.Debug.Fail$1(`No handler for validity ${$.$strNN($.$$.S.Enum.ToStringT($.$sfa.SFA.AsnDecoder.LengthValidity, $.$$.S.UInt32, validity))}.`);
                        $switchJumpState76 = 1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/; /*goto case LengthValidity.PrimitiveEncodingRequiresDefinite*/
                        continue $switchJumpStart76;
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014706195)
            
            //--TRIMMABLE-BOUNDARY-START(68719738899)
            static /*int */ GetPrimitiveIntegerSize(/*Type*/ primitiveType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719738899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (primitiveType === $.$$.S.Byte.$type || primitiveType === $.$$.S.SByte.$type)
                {
                    return 1;
                }
                if (primitiveType === $.$$.S.Int16.$type || primitiveType === $.$$.S.UInt16.$type)
                {
                    return 2;
                }
                if (primitiveType === $.$$.S.Int32.$type || primitiveType === $.$$.S.UInt32.$type)
                {
                    return 4;
                }
                if (primitiveType === $.$$.S.Int64.$type || primitiveType === $.$$.S.UInt64.$type)
                {
                    return 8;
                }
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(68719738899)
            
            //--TRIMMABLE-BOUNDARY-START(223338561555)
            static /*int */ SeekEndOfContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338561555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let cur = source;
                /*int*/ let totalLen = 0;
                /*int*/ let depth = 1;
                while(!cur.IsEmpty)
                {
                    /*int?*/ let length;
                    /*int*/ let bytesRead;
                    /*Asn1Tag*/ let tag = $.$sfa.SFA.AsnDecoder.ReadTagAndLength(cur, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.S.Int32)), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.S.Int32));
                    if ($.$sfa.SFA.Asn1Tag.op_Equality(tag, $.$sfa.SFA.Asn1Tag.EndOfContents))
                    {
                        $.$sfa.SFA.AsnDecoder.ValidateEndOfContents(tag, length, bytesRead);
                        depth--;
                        if (depth === 0)
                        {
                            return totalLen;
                        }
                    }
                    if (length === null)
                    {
                        depth++;
                        cur = cur.Slice$1(bytesRead);
                        totalLen += bytesRead;
                    }
                    else 
                    {
                        /*ReadOnlySpan<byte>*/ let tlv = $.$sfa.SFA.AsnDecoder.Slice$1(cur, 0, ((bytesRead + $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(length)) | 0));
                        cur = cur.Slice$1(tlv.Length);
                        totalLen += tlv.Length;
                    }
                }
                throw new $.$sfa.SFA.AsnContentException().$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(223338561555)
            
            //--TRIMMABLE-BOUNDARY-START(98784509971)
            static /*int */ ParseNonNegativeIntAndSlice(/*ref ReadOnlySpan<byte>*/ data, /*int*/ bytesToRead)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784509971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let value = $.$sfa.SFA.AsnDecoder.ParseNonNegativeInt($.$sfa.SFA.AsnDecoder.Slice$1(data.$v, 0, bytesToRead));
                data.$v = data.$v.Slice$1(bytesToRead);
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(98784509971)
            
            //--TRIMMABLE-BOUNDARY-START(94489542675)
            static /*int */ ParseNonNegativeInt(/*ReadOnlySpan<byte>*/ data)
            {
                /*uint*/ let value;
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489542675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.SBT.Utf8Parser.TryParse$14(data, $.$ref(() => value, ($v) => value = $v, $.$$.S.UInt32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), /*\u0000*/ 0) && value <= 2147483647/*int.MaxValue*/ && consumed === data.Length)
                {
                    return (value | 0);
                }
                throw new $.$sfa.SFA.AsnContentException().$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(94489542675)
            
            //--TRIMMABLE-BOUNDARY-START(240518430739)
            static /*ReadOnlySpan<byte> */ SliceAtMost(/*ReadOnlySpan<byte>*/ source, /*int*/ longestPermitted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518430739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let len = $.$$.S.Math.Min$4(longestPermitted, source.Length);
                return source.Slice(0, len);
            }
            //--TRIMMABLE-BOUNDARY-END(240518430739)
            
            //--TRIMMABLE-BOUNDARY-START(231928496147)
            static /*ReadOnlySpan<byte> */ Slice$1(/*ReadOnlySpan<byte>*/ source, /*int*/ offset, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928496147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(offset >= 0, "offset >= 0");
                if (length < 0 || ((source.Length - offset) | 0) < length)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_LengthExceedsPayload);
                }
                return source.Slice(offset, length);
            }
            //--TRIMMABLE-BOUNDARY-END(231928496147)
            
            //--TRIMMABLE-BOUNDARY-START(236223463443)
            static /*ReadOnlySpan<byte> */ Slice$2(/*ReadOnlySpan<byte>*/ source, /*int*/ offset, /*int?*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223463443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(offset >= 0, "offset >= 0");
                if (length === null)
                {
                    return source.Slice$1(offset);
                }
                /*int*/ let lengthVal = $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(length);
                if (lengthVal < 0 || ((source.Length - offset) | 0) < lengthVal)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_LengthExceedsPayload);
                }
                return source.Slice(offset, lengthVal);
            }
            //--TRIMMABLE-BOUNDARY-END(236223463443)
            
            //--TRIMMABLE-BOUNDARY-START(227633528851)
            static /*ReadOnlyMemory<byte> */ Slice(/*ReadOnlyMemory<byte>*/ bigger, /*ReadOnlySpan<byte>*/ smaller)
            {
                /*int*/ let offset;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633528851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (smaller.IsEmpty)
                {
                    return new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))();
                }
                if ($.$$.S.MemoryExtensions.Overlaps($.$$.S.Byte, bigger.Span, smaller, $.$ref(() => offset, ($v) => offset = $v, $.$$.S.Int32)))
                {
                    return bigger.Slice(offset, smaller.Length);
                }
                $.$$.SD.Debug.Fail$1("AsnReader asked for a matching slice from a non-overlapping input");
                throw new $.$sfa.SFA.AsnContentException().$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(227633528851)
            
            //--TRIMMABLE-BOUNDARY-START(4295229459)
            static /*void */ AssertEncodingRules(/*AsnEncodingRules*/ ruleSet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(ruleSet >= 0/*AsnEncodingRules.BER*/ && ruleSet <= 2/*AsnEncodingRules.DER*/, "ruleSet >= AsnEncodingRules.BER && ruleSet <= AsnEncodingRules.DER");
            }
            //--TRIMMABLE-BOUNDARY-END(4295229459)
            
            //--TRIMMABLE-BOUNDARY-START(8590196755)
            static /*void */ CheckEncodingRules(/*AsnEncodingRules*/ ruleSet)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (ruleSet !== 0/*AsnEncodingRules.BER*/ && ruleSet !== 1/*AsnEncodingRules.CER*/ && ruleSet !== 2/*AsnEncodingRules.DER*/)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("ruleSet");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590196755)
            
            //--TRIMMABLE-BOUNDARY-START(12885164051)
            static /*void */ CheckExpectedTag(/*Asn1Tag*/ tag, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (expectedTag.TagClass === 0/*TagClass.Universal*/ && expectedTag.TagValue !== tagNumber)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_UniversalValueIsFixed, "expectedTag");
                }
                if (expectedTag.TagClass !== tag.TagClass || expectedTag.TagValue !== tag.TagValue)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.Format$7($.$sfa.S.SR.ContentException_WrongTag, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(tag.TagClass, $.$sfa.SFA.TagClass), $.$box(tag.TagValue, $.$$.S.Int32), $.$box(expectedTag.TagClass, $.$sfa.SFA.TagClass), $.$box(expectedTag.TagValue, $.$$.S.Int32) ], null, null)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885164051)
            
            //--TRIMMABLE-BOUNDARY-START(393235)
            static $_LengthDecodeStatus;
            static get LengthDecodeStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sfa.SFA.AsnDecoder;
                return $cls.$_LengthDecodeStatus ??= $asm.$nstr(`$sfa.SFA.AsnDecoder.LengthDecodeStatus`, ($self) => class LengthDecodeStatus extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static NeedMoreData = 0;
                    static DerIndefinite = 1;
                    static ReservedValue = 2;
                    static LengthTooBig = 3;
                    static LaxEncodingProhibited = 4;
                    static Success = 5;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(393235);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "NeedMoreData": 0n,
                            "DerIndefinite": 1n,
                            "ReservedValue": 2n,
                            "LengthTooBig": 3n,
                            "LaxEncodingProhibited": 4n,
                            "Success": 5n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4295360531)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295360531);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295360531)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295360531)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295360531)
                    
                    static $h = 393235;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475229715),
    {
      "t": 393235,
      "n": "NeedMoreData",
      "d": 393235,
      "h": 21475229715,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475229715),
//--TRIMMABLE-BOUNDARY-START(8590327827),
    {
      "t": 393235,
      "n": "DerIndefinite",
      "d": 393235,
      "h": 8590327827,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590327827),
//--TRIMMABLE-BOUNDARY-START(25770197011),
    {
      "t": 393235,
      "n": "ReservedValue",
      "d": 393235,
      "h": 25770197011,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770197011),
//--TRIMMABLE-BOUNDARY-START(17180262419),
    {
      "t": 393235,
      "n": "LengthTooBig",
      "d": 393235,
      "h": 17180262419,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180262419),
//--TRIMMABLE-BOUNDARY-START(12885295123),
    {
      "t": 393235,
      "n": "LaxEncodingProhibited",
      "d": 393235,
      "h": 12885295123,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885295123),
//--TRIMMABLE-BOUNDARY-START(30065164307),
    {
      "t": 393235,
      "n": "Success",
      "d": 393235,
      "h": 30065164307,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065164307)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360531),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393235,
      "h": 4295360531,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360531)
  ],
  "d": 262163,
  "h": 393235
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.AsnDecoder+LengthDecodeStatus`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}AsnDecoder${separator}LengthDecodeStatus`; }
                }, $cls, ($v) => $cls.$_LengthDecodeStatus = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393235)
            
            //--TRIMMABLE-BOUNDARY-START(458771)
            static $_LengthValidity;
            static get LengthValidity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(458771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sfa.SFA.AsnDecoder;
                return $cls.$_LengthValidity ??= $asm.$nstr(`$sfa.SFA.AsnDecoder.LengthValidity`, ($self) => class LengthValidity extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static CerRequiresIndefinite = 0;
                    static PrimitiveEncodingRequiresDefinite = 1;
                    static LengthExceedsInput = 2;
                    static Valid = 3;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(458771);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "CerRequiresIndefinite": 0n,
                            "PrimitiveEncodingRequiresDefinite": 1n,
                            "LengthExceedsInput": 2n,
                            "Valid": 3n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4295426067)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295426067);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295426067)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295426067)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295426067)
                    
                    static $h = 458771;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393363),
    {
      "t": 458771,
      "n": "CerRequiresIndefinite",
      "d": 458771,
      "h": 8590393363,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393363),
//--TRIMMABLE-BOUNDARY-START(17180327955),
    {
      "t": 458771,
      "n": "PrimitiveEncodingRequiresDefinite",
      "d": 458771,
      "h": 17180327955,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180327955),
//--TRIMMABLE-BOUNDARY-START(12885360659),
    {
      "t": 458771,
      "n": "LengthExceedsInput",
      "d": 458771,
      "h": 12885360659,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360659),
//--TRIMMABLE-BOUNDARY-START(21475295251),
    {
      "t": 458771,
      "n": "Valid",
      "d": 458771,
      "h": 21475295251,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475295251)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426067),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458771,
      "h": 4295426067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426067)
  ],
  "d": 262163,
  "h": 458771
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.AsnDecoder+LengthValidity`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}AsnDecoder${separator}LengthValidity`; }
                }, $cls, ($v) => $cls.$_LengthValidity = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(458771)
            
            //--TRIMMABLE-BOUNDARY-START(300647972883)
            static /*bool */ TryReadOctetString(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                /*int?*/ let contentLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let contents;
                /*int*/ let consumed;
                /*int*/ let bytesRead;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300647972883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.MemoryExtensions.Overlaps$1($.$$.S.Byte, source, $.$$.S.Span$$($.$$.S.Byte).op_Implicit(destination)))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_SourceOverlapsDestination, "destination");
                }
                if ($.$sfa.SFA.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag ?? $.$sfa.SFA.Asn1Tag.PrimitiveOctetString, 4/*UniversalTagNumber.OctetString*/, $.$ref(() => contentLength, ($v) => contentLength = $v, $.$typeNullable($.$$.S.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.S.Int32), $.$ref(() => contents, ($v) => contents = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32)))
                {
                    if (contents.Length > destination.Length)
                    {
                        bytesWritten.$v = 0;
                        bytesConsumed.$v = 0;
                        return false;
                    }
                    contents.CopyTo(destination);
                    bytesWritten.$v = contents.Length;
                    bytesConsumed.$v = consumed;
                    return true;
                }
                /*bool*/ let copied = $.$sfa.SFA.AsnDecoder.TryCopyConstructedOctetStringContents($.$sfa.SFA.AsnDecoder.Slice$2(source, headerLength, contentLength), ruleSet, destination, contentLength === null, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.S.Int32), bytesWritten);
                if (copied)
                {
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                }
                else 
                {
                    bytesConsumed.$v = 0;
                }
                return copied;
            }
            //--TRIMMABLE-BOUNDARY-END(300647972883)
            
            //--TRIMMABLE-BOUNDARY-START(193273790483)
            static /*byte[] */ ReadOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273790483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]?*/ let rented = null;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.SFA.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag ?? $.$sfa.SFA.Asn1Tag.PrimitiveOctetString, 4/*UniversalTagNumber.OctetString*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.S.Byte)), new ($.$$.S.Span$$($.$$.S.Byte))());
                /*byte[]*/ let ret = contents.ToArray();
                if (rented !== null)
                {
                    $.$sfa.SSC.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = consumed;
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(193273790483)
            
            //--TRIMMABLE-BOUNDARY-START(322122809363)
            static /*bool */ TryReadPrimitiveOctetStringCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*out int?*/ contentLength, /*out int*/ headerLength, /*out ReadOnlySpan<byte>*/ contents, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322122809363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Asn1Tag*/ let actualTag = $.$sfa.SFA.AsnDecoder.ReadTagAndLength(source, ruleSet, contentLength, headerLength);
                $.$sfa.SFA.AsnDecoder.CheckExpectedTag(actualTag, expectedTag, universalTagNumber);
                /*ReadOnlySpan<byte>*/ let encodedValue = $.$sfa.SFA.AsnDecoder.Slice$2(source, headerLength.$v, contentLength.$v);
                if (actualTag.IsConstructed)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderDer_TryBerOrCer);
                    }
                    contents.$v = new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))();
                    bytesConsumed.$v = 0;
                    return false;
                }
                $.$$.SD.Debug.Assert$4($.$$.S.Nullable$$($.$$.S.Int32).HasValue$get.call(contentLength.$v), "contentLength.HasValue");
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && encodedValue.Length > 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCer_TryBerOrDer);
                }
                contents.$v = encodedValue;
                bytesConsumed.$v = ((headerLength.$v + encodedValue.Length) | 0);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(322122809363)
            
            //--TRIMMABLE-BOUNDARY-START(317827842067)
            static /*bool */ TryReadPrimitiveOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317827842067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag ?? $.$sfa.SFA.Asn1Tag.PrimitiveOctetString, 4/*UniversalTagNumber.OctetString*/, $.$discardRef(), $.$discardRef(), value, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(317827842067)
            
            //--TRIMMABLE-BOUNDARY-START(38654967827)
            static /*int */ CountConstructedOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*bool*/ isIndefinite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let contentLength = $.$sfa.SFA.AsnDecoder.CopyConstructedOctetString$1(source, ruleSet, $.$$.S.Span$$($.$$.S.Byte).Empty, false, isIndefinite, $.$discardRef());
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && contentLength <= 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                return contentLength;
            }
            //--TRIMMABLE-BOUNDARY-END(38654967827)
            
            //--TRIMMABLE-BOUNDARY-START(25770065939)
            static /*void */ CopyConstructedOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*bool*/ isIndefinite, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770065939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bytesWritten.$v = $.$sfa.SFA.AsnDecoder.CopyConstructedOctetString$1(source, ruleSet, destination, true, isIndefinite, bytesRead);
            }
            //--TRIMMABLE-BOUNDARY-END(25770065939)
            
            //--TRIMMABLE-BOUNDARY-START(30065033235)
            static /*int */ CopyConstructedOctetString$1(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*bool*/ write, /*bool*/ isIndefinite, /*out int*/ bytesRead)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bytesRead.$v = 0;
                /*int*/ let lastSegmentLength = 1000/*MaxCERSegmentSize*/;
                /*ReadOnlySpan<byte>*/ let cur = source;
                /*Stack<(int Offset, int Length, bool IsIndefinite, int BytesRead)>?*/ let readerStack = null;
                /*int*/ let totalLength = 0;
                /*Asn1Tag*/ let tag = $.$sfa.SFA.Asn1Tag.ConstructedBitString;
                /*Span<byte>*/ let curDest = destination;
                while(true)
                {
                    while(!cur.IsEmpty)
                    {
                        /*int?*/ let length;
                        /*int*/ let headerLength;
                        tag = $.$sfa.SFA.AsnDecoder.ReadTagAndLength(cur, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.S.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.S.Int32));
                        if ($.$sfa.SFA.Asn1Tag.op_Equality(tag, $.$sfa.SFA.Asn1Tag.PrimitiveOctetString))
                        {
                            if (ruleSet === 1/*AsnEncodingRules.CER*/ && lastSegmentLength !== 1000/*MaxCERSegmentSize*/)
                            {
                                throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            $.$$.SD.Debug.Assert$4(length !== null, "length != null");
                            /*ReadOnlySpan<byte>*/ let contents = $.$sfa.SFA.AsnDecoder.Slice$1(cur, headerLength, $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(length));
                            /*int*/ let localLen = ((headerLength + contents.Length) | 0);
                            cur = cur.Slice$1(localLen);
                            bytesRead.$v += localLen;
                            totalLength += contents.Length;
                            lastSegmentLength = contents.Length;
                            if (ruleSet === 1/*AsnEncodingRules.CER*/ && lastSegmentLength > 1000/*MaxCERSegmentSize*/)
                            {
                                throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            if (write)
                            {
                                contents.CopyTo(curDest);
                                curDest = curDest.Slice$1(contents.Length);
                            }
                        }
                        else if ($.$sfa.SFA.Asn1Tag.op_Equality(tag, $.$sfa.SFA.Asn1Tag.EndOfContents) && isIndefinite)
                        {
                            $.$sfa.SFA.AsnDecoder.ValidateEndOfContents(tag, length, headerLength);
                            bytesRead.$v += headerLength;
                            if ($.$$.S.Int32.op_GreaterThan((readerStack?.Count ?? null), 0))
                            {
                                let [ topOffset, topLength, wasIndefinite, pushedBytesRead ] = $.$destructure(readerStack.Pop(), 4);
                                /*ReadOnlySpan<byte>*/ let topSpan = source.Slice(topOffset, topLength);
                                cur = topSpan.Slice$1(bytesRead.$v);
                                bytesRead.$v += pushedBytesRead;
                                isIndefinite = wasIndefinite;
                            }
                            else 
                            {
                                break;
                            }
                        }
                        else if ($.$sfa.SFA.Asn1Tag.op_Equality(tag, $.$sfa.SFA.Asn1Tag.ConstructedOctetString))
                        {
                            /*int*/ let curOffset;
                            if (ruleSet === 1/*AsnEncodingRules.CER*/)
                            {
                                throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            readerStack ??= new ($.$sc.SCG.Stack$$($.$$.S.ValueTuple$$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean, $.$$.S.Int32)))().$ctor$1();
                            if (!$.$$.S.MemoryExtensions.Overlaps($.$$.S.Byte, source, cur, $.$ref(() => curOffset, ($v) => curOffset = $v, $.$$.S.Int32)))
                            {
                                $.$$.SD.Debug.Fail$1("Non-overlapping data encountered...");
                                throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                            }
                            readerStack.Push(new ($.$$.S.ValueTuple$$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean, $.$$.S.Int32))().$ctor$3(curOffset, cur.Length, isIndefinite, bytesRead.$v));
                            cur = $.$sfa.SFA.AsnDecoder.Slice$2(cur, headerLength, length);
                            bytesRead.$v = headerLength;
                            isIndefinite = (length === null);
                        }
                        else 
                        {
                            throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                        }
                    }
                    if (isIndefinite && $.$sfa.SFA.Asn1Tag.op_Inequality(tag, $.$sfa.SFA.Asn1Tag.EndOfContents))
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                    }
                    if ($.$$.S.Int32.op_GreaterThan((readerStack?.Count ?? null), 0))
                    {
                        let [ topOffset, topLength, wasIndefinite, pushedBytesRead ] = $.$destructure(readerStack.Pop(), 4);
                        /*ReadOnlySpan<byte>*/ let topSpan = source.Slice(topOffset, topLength);
                        cur = topSpan.Slice$1(bytesRead.$v);
                        isIndefinite = wasIndefinite;
                        bytesRead.$v += pushedBytesRead;
                    }
                    else 
                    {
                        return totalLength;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065033235)
            
            //--TRIMMABLE-BOUNDARY-START(249108365331)
            static /*bool */ TryCopyConstructedOctetStringContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ dest, /*bool*/ isIndefinite, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108365331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bytesRead.$v = 0;
                /*int*/ let contentLength = $.$sfa.SFA.AsnDecoder.CountConstructedOctetString(source, ruleSet, isIndefinite);
                if (dest.Length < contentLength)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                $.$sfa.SFA.AsnDecoder.CopyConstructedOctetString(source, ruleSet, dest, isIndefinite, bytesRead, bytesWritten);
                $.$$.SD.Debug.Assert$4(bytesWritten.$v === contentLength, "bytesWritten == contentLength");
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(249108365331)
            
            //--TRIMMABLE-BOUNDARY-START(60129804307)
            static /*ReadOnlySpan<byte> */ GetOctetStringContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*out int*/ bytesConsumed, /*ref byte[]?*/ rented, /*Span<byte>*/ tmpSpace)
            {
                /*int?*/ let contentLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let contents;
                /*int*/ let bytesRead;
                /*int*/ let bytesWritten;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129804307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(rented.$v === null, "rented == null");
                if ($.$sfa.SFA.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => contentLength, ($v) => contentLength = $v, $.$typeNullable($.$$.S.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.S.Int32), $.$ref(() => contents, ($v) => contents = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)), bytesConsumed))
                {
                    return contents;
                }
                contents = source.Slice$1(headerLength);
                /*int*/ let tooBig = contentLength ?? $.$sfa.SFA.AsnDecoder.SeekEndOfContents(contents, ruleSet);
                if (tmpSpace.Length > 0 && tooBig > tmpSpace.Length)
                {
                    /*bool*/ let isIndefinite = contentLength === null;
                    tooBig = $.$sfa.SFA.AsnDecoder.CountConstructedOctetString(contents, ruleSet, isIndefinite);
                }
                if (tooBig > tmpSpace.Length)
                {
                    rented.$v = $.$sfa.SSC.CryptoPool.Rent(tooBig);
                    tmpSpace = $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(rented.$v);
                }
                if ($.$sfa.SFA.AsnDecoder.TryCopyConstructedOctetStringContents($.$sfa.SFA.AsnDecoder.Slice$2(source, headerLength, contentLength), ruleSet, tmpSpace, contentLength === null, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.S.Int32), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.S.Int32)))
                {
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                    return $.$$.S.Span$$($.$$.S.Byte).op_Implicit(tmpSpace.Slice(0, bytesWritten));
                }
                $.$$.SD.Debug.Fail$1("TryCopyConstructedOctetStringContents failed with a pre-allocated buffer");
                throw new $.$sfa.SFA.AsnContentException().$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(60129804307)
            
            //--TRIMMABLE-BOUNDARY-START(158914052115)
            static /*ReadOnlySpan<byte> */ ReadIntegerBytes(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914052115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag ?? $.$sfa.SFA.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(158914052115)
            
            //--TRIMMABLE-BOUNDARY-START(154619084819)
            static /*BigInteger */ ReadInteger(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619084819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.SFA.AsnDecoder.ReadIntegerBytes(source, ruleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                /*BigInteger*/ let value = new $.$srn.SN.BigInteger().$ctor$9(contents, false, true);
                bytesConsumed.$v = consumed;
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(154619084819)
            
            //--TRIMMABLE-BOUNDARY-START(287763070995)
            static /*bool */ TryReadInt32(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*long*/ let longValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763070995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.SFA.AsnDecoder.TryReadSignedInteger(source, ruleSet, 4, expectedTag ?? $.$sfa.SFA.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, $.$ref(() => longValue, ($v) => longValue = $v, $.$$.S.Int64), bytesConsumed))
                {
                    value.$v = $.$cast(longValue, $.$$.S.Int32);
                    return true;
                }
                value.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(287763070995)
            
            //--TRIMMABLE-BOUNDARY-START(330712743955)
            static /*bool */ TryReadUInt32(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out uint*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*ulong*/ let ulongValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712743955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.SFA.AsnDecoder.TryReadUnsignedInteger(source, ruleSet, 4, expectedTag ?? $.$sfa.SFA.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, $.$ref(() => ulongValue, ($v) => ulongValue = $v, $.$$.S.UInt64), bytesConsumed))
                {
                    value.$v = $.$cast(ulongValue, $.$$.S.UInt32);
                    return true;
                }
                value.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(330712743955)
            
            //--TRIMMABLE-BOUNDARY-START(292058038291)
            static /*bool */ TryReadInt64(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out long*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058038291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.AsnDecoder.TryReadSignedInteger(source, ruleSet, 8, expectedTag ?? $.$sfa.SFA.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, value, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(292058038291)
            
            //--TRIMMABLE-BOUNDARY-START(335007711251)
            static /*bool */ TryReadUInt64(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out ulong*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007711251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.AsnDecoder.TryReadUnsignedInteger(source, ruleSet, 8, expectedTag ?? $.$sfa.SFA.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, value, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(335007711251)
            
            //--TRIMMABLE-BOUNDARY-START(55834837011)
            static /*ReadOnlySpan<byte> */ GetIntegerContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out int*/ bytesConsumed)
            {
                /*int*/ let consumed;
                /*ushort*/ let bigEndianValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.SFA.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag, tagNumber, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32));
                if (contents.IsEmpty)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
                if ($.$$.SBB.BinaryPrimitives.TryReadUInt16BigEndian(contents, $.$ref(() => bigEndianValue, ($v) => bigEndianValue = $v, $.$$.S.UInt16)))
                {
                    /*ushort*/ let RedundancyMask = 65408;
                    /*ushort*/ let masked = $.$cast((bigEndianValue & RedundancyMask), $.$$.S.UInt16);
                    if (masked === 0 || masked === RedundancyMask)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                    }
                }
                bytesConsumed.$v = consumed;
                return contents;
            }
            //--TRIMMABLE-BOUNDARY-END(55834837011)
            
            //--TRIMMABLE-BOUNDARY-START(326417776659)
            static /*bool */ TryReadSignedInteger(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*int*/ sizeLimit, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out long*/ value, /*out int*/ bytesConsumed)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326417776659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(sizeLimit <= 8, "sizeLimit <= sizeof(long)");
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.SFA.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag, tagNumber, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32));
                if (contents.Length > sizeLimit)
                {
                    value.$v = 0n;
                    bytesConsumed.$v = 0;
                    return false;
                }
                /*bool*/ let isNegative = (contents._reference.GetAt(0) & 128) !== 0;
                /*long*/ let accum = BigInt(isNegative ? -1 : 0);
                for(/*int*/ let i = 0; i < contents.Length; i++)
                {
                    accum <<= 8n;
                    accum |= BigInt(contents._reference.GetAt(i));
                }
                bytesConsumed.$v = consumed;
                value.$v = accum;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(326417776659)
            
            //--TRIMMABLE-BOUNDARY-START(339302678547)
            static /*bool */ TryReadUnsignedInteger(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*int*/ sizeLimit, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out ulong*/ value, /*out int*/ bytesConsumed)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339302678547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(sizeLimit <= 8, "sizeLimit <= sizeof(ulong)");
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.SFA.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag, tagNumber, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32));
                /*bool*/ let isNegative = (contents._reference.GetAt(0) & 128) !== 0;
                if (isNegative)
                {
                    bytesConsumed.$v = 0;
                    value.$v = 0n;
                    return false;
                }
                if (contents.Length > 1 && contents._reference.GetAt(0) === 0)
                {
                    contents = contents.Slice$1(1);
                }
                if (contents.Length > sizeLimit)
                {
                    bytesConsumed.$v = 0;
                    value.$v = 0n;
                    return false;
                }
                /*ulong*/ let accum = 0n;
                for(/*int*/ let i = 0; i < contents.Length; i++)
                {
                    accum <<= 8n;
                    accum |= BigInt(contents._reference.GetAt(i));
                }
                bytesConsumed.$v = consumed;
                value.$v = accum;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(339302678547)
            
            //--TRIMMABLE-BOUNDARY-START(304942940179)
            static /*bool */ TryReadPrimitiveBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let localUbc;
                /*ReadOnlySpan<byte>*/ let localValue;
                /*int*/ let consumed;
                /*byte*/ let normalizedLastByte;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304942940179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.SFA.AsnDecoder.TryReadPrimitiveBitStringCore(source, ruleSet, expectedTag ?? $.$sfa.SFA.Asn1Tag.PrimitiveBitString, $.$discardRef(), $.$discardRef(), $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.S.Int32), $.$ref(() => localValue, ($v) => localValue = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$$.S.Byte)))
                {
                    if (localValue.Length === 0 || normalizedLastByte === localValue._reference.GetAt(((localValue.Length - 1) | 0)))
                    {
                        unusedBitCount.$v = localUbc;
                        value.$v = localValue;
                        bytesConsumed.$v = consumed;
                        return true;
                    }
                }
                unusedBitCount.$v = 0;
                value.$v = new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))();
                bytesConsumed.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(304942940179)
            
            //--TRIMMABLE-BOUNDARY-START(257698299923)
            static /*bool */ TryReadBitString(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                /*ReadOnlySpan<byte>*/ let value;
                /*int*/ let bytesRead;
                /*int*/ let written;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698299923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.MemoryExtensions.Overlaps$1($.$$.S.Byte, source, $.$$.S.Span$$($.$$.S.Byte).op_Implicit(destination)))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_SourceOverlapsDestination, "destination");
                }
                /*int*/ let localUbc;
                /*byte*/ let normalizedLastByte;
                /*int*/ let consumed;
                /*int?*/ let contentsLength;
                /*int*/ let headerLength;
                if ($.$sfa.SFA.AsnDecoder.TryReadPrimitiveBitStringCore(source, ruleSet, expectedTag ?? $.$sfa.SFA.Asn1Tag.PrimitiveBitString, $.$ref(() => contentsLength, ($v) => contentsLength = $v, $.$typeNullable($.$$.S.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.S.Int32), $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.S.Int32), $.$ref(() => value, ($v) => value = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$$.S.Byte)))
                {
                    if (value.Length > destination.Length)
                    {
                        bytesConsumed.$v = 0;
                        bytesWritten.$v = 0;
                        unusedBitCount.$v = 0;
                        return false;
                    }
                    $.$sfa.SFA.AsnDecoder.CopyBitStringValue(value, normalizedLastByte, destination);
                    bytesWritten.$v = value.Length;
                    bytesConsumed.$v = consumed;
                    unusedBitCount.$v = localUbc;
                    return true;
                }
                if ($.$sfa.SFA.AsnDecoder.TryCopyConstructedBitStringValue($.$sfa.SFA.AsnDecoder.Slice$2(source, headerLength, contentsLength), ruleSet, destination, contentsLength === null, $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.S.Int32), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.S.Int32), $.$ref(() => written, ($v) => written = $v, $.$$.S.Int32)))
                {
                    unusedBitCount.$v = localUbc;
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                    bytesWritten.$v = written;
                    return true;
                }
                bytesWritten.$v = bytesConsumed.$v = unusedBitCount.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(257698299923)
            
            //--TRIMMABLE-BOUNDARY-START(115964379155)
            static /*byte[] */ ReadBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int?*/ let contentsLength;
                /*int*/ let headerLength;
                /*int*/ let localUbc;
                /*ReadOnlySpan<byte>*/ let localValue;
                /*int*/ let consumed;
                /*byte*/ let normalizedLastByte;
                /*int*/ let bytesRead;
                /*int*/ let written;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964379155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.SFA.AsnDecoder.TryReadPrimitiveBitStringCore(source, ruleSet, expectedTag ?? $.$sfa.SFA.Asn1Tag.PrimitiveBitString, $.$ref(() => contentsLength, ($v) => contentsLength = $v, $.$typeNullable($.$$.S.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.S.Int32), $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.S.Int32), $.$ref(() => localValue, ($v) => localValue = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$$.S.Byte)))
                {
                    /*byte[]*/ let ret = localValue.ToArray();
                    if (localValue.Length > 0)
                    {
                        $.$$.System.Array.$WriteT1.call(ret, normalizedLastByte, ((ret.length - 1) | 0));
                    }
                    unusedBitCount.$v = localUbc;
                    bytesConsumed.$v = consumed;
                    return ret;
                }
                /*int*/ let tooBig = contentsLength ?? $.$sfa.SFA.AsnDecoder.SeekEndOfContents(source.Slice$1(headerLength), ruleSet);
                /*byte[]*/ let rented = $.$sfa.SSC.CryptoPool.Rent(tooBig);
                if ($.$sfa.SFA.AsnDecoder.TryCopyConstructedBitStringValue($.$sfa.SFA.AsnDecoder.Slice$2(source, headerLength, contentsLength), ruleSet, $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(rented), contentsLength === null, $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.S.Int32), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.S.Int32), $.$ref(() => written, ($v) => written = $v, $.$$.S.Int32)))
                {
                    /*byte[]*/ let ret = $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, rented, 0, written).ToArray();
                    $.$sfa.SSC.CryptoPool.Return$1(rented, written);
                    unusedBitCount.$v = localUbc;
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                    return ret;
                }
                $.$$.SD.Debug.Fail$1("TryCopyConstructedBitStringValue failed with a pre-allocated buffer");
                throw new $.$sfa.SFA.AsnContentException().$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(115964379155)
            
            //--TRIMMABLE-BOUNDARY-START(103079477267)
            static /*void */ ParsePrimitiveBitStringContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out ReadOnlySpan<byte>*/ value, /*out byte*/ normalizedLastByte)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079477267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && source.Length > 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCer_TryBerOrDer);
                }
                if (source.Length === 0)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
                unusedBitCount.$v = source._reference.GetAt(0);
                if (unusedBitCount.$v > 7)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                }
                if (source.Length === 1)
                {
                    if (unusedBitCount.$v > 0)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                    }
                    $.$$.SD.Debug.Assert$4(unusedBitCount.$v === 0, "unusedBitCount == 0");
                    value.$v = $.$$.S.ReadOnlySpan$$($.$$.S.Byte).Empty;
                    normalizedLastByte.$v = 0;
                    return;
                }
                /*int*/ let mask = -1 << unusedBitCount.$v;
                /*byte*/ let lastByte = source._reference.GetAt(((source.Length - 1) | 0));
                /*byte*/ let maskedByte = $.$cast((lastByte & mask), $.$$.S.Byte);
                if (maskedByte !== lastByte)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                normalizedLastByte.$v = maskedByte;
                value.$v = source.Slice$1(1);
            }
            //--TRIMMABLE-BOUNDARY-END(103079477267)
            
            //--TRIMMABLE-BOUNDARY-START(327699)
            static $_BitStringCopyAction;
            static get BitStringCopyAction()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sfa.SFA.AsnDecoder;
                return $cls.$_BitStringCopyAction ??= $asm.$ncls(`$sfa.SFA.AsnDecoder.BitStringCopyAction`, ($self) => class BitStringCopyAction extends $.$$.S.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ value, /*$.$$.S.Byte*/ normalizedLastByte, /**/ destination)
                    {
                        return this.$nativeFunction.call(this.$target, value, normalizedLastByte, destination);
                    }
                    static $h = 327699;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180196883),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "normalizedLastByte",
          "p": 393217
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "Invoke",
      "d": 327699,
      "h": 17180196883,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180196883),
//--TRIMMABLE-BOUNDARY-START(8590262291),
    {
      "r": 90570753,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "normalizedLastByte",
          "p": 393217
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 327699,
      "h": 8590262291,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590262291),
//--TRIMMABLE-BOUNDARY-START(12885229587),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 327699,
      "h": 12885229587,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885229587)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295294995),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 327699,
      "h": 4295294995,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295294995)
  ],
  "d": 262163,
  "h": 327699
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.AsnDecoder+BitStringCopyAction`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}AsnDecoder${separator}BitStringCopyAction`; }
                }, $cls, ($v) => $cls.$_BitStringCopyAction = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327699)
            
            //--TRIMMABLE-BOUNDARY-START(17180131347)
            static /*void */ CopyBitStringValue(/*ReadOnlySpan<byte>*/ value, /*byte*/ normalizedLastByte, /*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.Length === 0)
                {
                    return;
                }
                value.CopyTo(destination);
                destination._reference.SetAt(normalizedLastByte, ((value.Length - 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(17180131347)
            
            //--TRIMMABLE-BOUNDARY-START(34360000531)
            static /*int */ CountConstructedBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*bool*/ isIndefinite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Span<byte>*/ let destination = $.$$.S.Span$$($.$$.S.Byte).Empty;
                return $.$sfa.SFA.AsnDecoder.ProcessConstructedBitString(source, ruleSet, destination, null, isIndefinite, $.$discardRef(), $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(34360000531)
            
            //--TRIMMABLE-BOUNDARY-START(21475098643)
            static /*void */ CopyConstructedBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*bool*/ isIndefinite, /*out int*/ unusedBitCount, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Span<byte>*/ let tmpDest = destination;
                bytesWritten.$v = $.$sfa.SFA.AsnDecoder.ProcessConstructedBitString(source, ruleSet, tmpDest, new $.$sfa.SFA.AsnDecoder.BitStringCopyAction().$ctor($.$sfa.SFA.AsnDecoder, $.$sfa.SFA.AsnDecoder.CopyBitStringValue), isIndefinite, unusedBitCount, bytesRead);
            }
            //--TRIMMABLE-BOUNDARY-END(21475098643)
            
            //--TRIMMABLE-BOUNDARY-START(111669411859)
            static /*int */ ProcessConstructedBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*BitStringCopyAction?*/ copyAction, /*bool*/ isIndefinite, /*out int*/ lastUnusedBitCount, /*out int*/ bytesRead)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669411859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                lastUnusedBitCount.$v = 0;
                bytesRead.$v = 0;
                /*int*/ let lastSegmentLength = 1000/*MaxCERSegmentSize*/;
                /*ReadOnlySpan<byte>*/ let cur = source;
                /*Stack<(int Offset, int Length, bool Indefinite, int BytesRead)>?*/ let readerStack = null;
                /*int*/ let totalLength = 0;
                /*Asn1Tag*/ let tag = $.$sfa.SFA.Asn1Tag.ConstructedBitString;
                /*Span<byte>*/ let curDest = destination;
                while(true)
                {
                    while(!cur.IsEmpty)
                    {
                        /*int?*/ let length;
                        /*int*/ let headerLength;
                        tag = $.$sfa.SFA.AsnDecoder.ReadTagAndLength(cur, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.S.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.S.Int32));
                        if ($.$sfa.SFA.Asn1Tag.op_Equality(tag, $.$sfa.SFA.Asn1Tag.PrimitiveBitString))
                        {
                            /*ReadOnlySpan<byte>*/ let contents;
                            /*byte*/ let normalizedLastByte;
                            if (lastUnusedBitCount.$v !== 0)
                            {
                                throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                            }
                            if (ruleSet === 1/*AsnEncodingRules.CER*/ && lastSegmentLength !== 1000/*MaxCERSegmentSize*/)
                            {
                                throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCer_TryBerOrDer);
                            }
                            $.$$.SD.Debug.Assert$4(length !== null, "length != null");
                            /*ReadOnlySpan<byte>*/ let encodedValue = $.$sfa.SFA.AsnDecoder.Slice$1(cur, headerLength, $.$$.S.Nullable$$($.$$.S.Int32).Value$get.call(length));
                            $.$sfa.SFA.AsnDecoder.ParsePrimitiveBitStringContents(encodedValue, ruleSet, lastUnusedBitCount, $.$ref(() => contents, ($v) => contents = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$$.S.Byte));
                            /*int*/ let localLen = ((headerLength + encodedValue.Length) | 0);
                            cur = cur.Slice$1(localLen);
                            bytesRead.$v += localLen;
                            totalLength += contents.Length;
                            lastSegmentLength = encodedValue.Length;
                            if (copyAction !== null)
                            {
                                copyAction.Invoke(contents, normalizedLastByte, curDest);
                                curDest = curDest.Slice$1(contents.Length);
                            }
                        }
                        else if ($.$sfa.SFA.Asn1Tag.op_Equality(tag, $.$sfa.SFA.Asn1Tag.EndOfContents) && isIndefinite)
                        {
                            $.$sfa.SFA.AsnDecoder.ValidateEndOfContents(tag, length, headerLength);
                            bytesRead.$v += headerLength;
                            if ($.$$.S.Int32.op_GreaterThan((readerStack?.Count ?? null), 0))
                            {
                                let [ topOffset, topLength, wasIndefinite, pushedBytesRead ] = $.$destructure(readerStack.Pop(), 4);
                                /*ReadOnlySpan<byte>*/ let topSpan = source.Slice(topOffset, topLength);
                                cur = topSpan.Slice$1(bytesRead.$v);
                                bytesRead.$v += pushedBytesRead;
                                isIndefinite = wasIndefinite;
                            }
                            else 
                            {
                                break;
                            }
                        }
                        else if ($.$sfa.SFA.Asn1Tag.op_Equality(tag, $.$sfa.SFA.Asn1Tag.ConstructedBitString))
                        {
                            /*int*/ let curOffset;
                            if (ruleSet === 1/*AsnEncodingRules.CER*/)
                            {
                                throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            readerStack ??= new ($.$sc.SCG.Stack$$($.$$.S.ValueTuple$$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean, $.$$.S.Int32)))().$ctor$1();
                            if (!$.$$.S.MemoryExtensions.Overlaps($.$$.S.Byte, source, cur, $.$ref(() => curOffset, ($v) => curOffset = $v, $.$$.S.Int32)))
                            {
                                $.$$.SD.Debug.Fail$1("Non-overlapping data encountered...");
                                throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                            }
                            readerStack.Push(new ($.$$.S.ValueTuple$$$$$($.$$.S.Int32, $.$$.S.Int32, $.$$.S.Boolean, $.$$.S.Int32))().$ctor$3(curOffset, cur.Length, isIndefinite, bytesRead.$v));
                            cur = $.$sfa.SFA.AsnDecoder.Slice$2(cur, headerLength, length);
                            bytesRead.$v = headerLength;
                            isIndefinite = (length === null);
                        }
                        else 
                        {
                            throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                        }
                    }
                    if (isIndefinite && $.$sfa.SFA.Asn1Tag.op_Inequality(tag, $.$sfa.SFA.Asn1Tag.EndOfContents))
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$5();
                    }
                    if ($.$$.S.Int32.op_GreaterThan((readerStack?.Count ?? null), 0))
                    {
                        let [ topOffset, topLength, wasIndefinite, pushedBytesRead ] = $.$destructure(readerStack.Pop(), 4);
                        /*ReadOnlySpan<byte>*/ let tmpSpan = source.Slice(topOffset, topLength);
                        cur = tmpSpan.Slice$1(bytesRead.$v);
                        isIndefinite = wasIndefinite;
                        bytesRead.$v += pushedBytesRead;
                    }
                    else 
                    {
                        return totalLength;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669411859)
            
            //--TRIMMABLE-BOUNDARY-START(244813398035)
            static /*bool */ TryCopyConstructedBitStringValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ dest, /*bool*/ isIndefinite, /*out int*/ unusedBitCount, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813398035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let contentLength = $.$sfa.SFA.AsnDecoder.CountConstructedBitString(source, ruleSet, isIndefinite);
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && contentLength < 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                if (dest.Length < contentLength)
                {
                    unusedBitCount.$v = 0;
                    bytesRead.$v = 0;
                    bytesWritten.$v = 0;
                    return false;
                }
                $.$sfa.SFA.AsnDecoder.CopyConstructedBitString(source, ruleSet, dest, isIndefinite, unusedBitCount, bytesRead, bytesWritten);
                $.$$.SD.Debug.Assert$4(bytesWritten.$v === contentLength, "bytesWritten == contentLength");
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(244813398035)
            
            //--TRIMMABLE-BOUNDARY-START(309237907475)
            static /*bool */ TryReadPrimitiveBitStringCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*out int?*/ contentsLength, /*out int*/ headerLength, /*out int*/ unusedBitCount, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed, /*out byte*/ normalizedLastByte)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309237907475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Asn1Tag*/ let actualTag = $.$sfa.SFA.AsnDecoder.ReadTagAndLength(source, ruleSet, contentsLength, headerLength);
                $.$sfa.SFA.AsnDecoder.CheckExpectedTag(actualTag, expectedTag, 3/*UniversalTagNumber.BitString*/);
                /*ReadOnlySpan<byte>*/ let encodedValue = $.$sfa.SFA.AsnDecoder.Slice$2(source, headerLength.$v, contentsLength.$v);
                if (actualTag.IsConstructed)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/)
                    {
                        throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidUnderDer_TryBerOrCer);
                    }
                    unusedBitCount.$v = 0;
                    value.$v = new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))();
                    normalizedLastByte.$v = 0;
                    bytesConsumed.$v = 0;
                    return false;
                }
                $.$$.SD.Debug.Assert$4($.$$.S.Nullable$$($.$$.S.Int32).HasValue$get.call(contentsLength.$v), "contentsLength.HasValue");
                $.$sfa.SFA.AsnDecoder.ParsePrimitiveBitStringContents(encodedValue, ruleSet, unusedBitCount, value, normalizedLastByte);
                bytesConsumed.$v = ((headerLength.$v + encodedValue.Length) | 0);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(309237907475)
            
            //--TRIMMABLE-BOUNDARY-START(313532874771)
            static /*bool */ TryReadPrimitiveCharacterStringBytes(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532874771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*UniversalTagNumber*/ let universalTagNumber = 22/*UniversalTagNumber.IA5String*/;
                if (expectedTag.TagClass === 0/*TagClass.Universal*/)
                {
                    universalTagNumber = $.$cast(expectedTag.TagValue, $.$sfa.SFA.UniversalTagNumber);
                    if (!$.$sfa.SFA.AsnDecoder.IsCharacterStringEncodingType(universalTagNumber))
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_Tag_NotCharacterString, "expectedTag");
                    }
                }
                return $.$sfa.SFA.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag, universalTagNumber, $.$discardRef(), $.$discardRef(), value, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(313532874771)
            
            //--TRIMMABLE-BOUNDARY-START(266288234515)
            static /*bool */ TryReadCharacterStringBytes(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*out int*/ bytesConsumed, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288234515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.MemoryExtensions.Overlaps$1($.$$.S.Byte, source, $.$$.S.Span$$($.$$.S.Byte).op_Implicit(destination)))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_SourceOverlapsDestination, "destination");
                }
                /*UniversalTagNumber*/ let universalTagNumber = 22/*UniversalTagNumber.IA5String*/;
                if (expectedTag.TagClass === 0/*TagClass.Universal*/)
                {
                    universalTagNumber = $.$cast(expectedTag.TagValue, $.$sfa.SFA.UniversalTagNumber);
                    if (!$.$sfa.SFA.AsnDecoder.IsCharacterStringEncodingType(universalTagNumber))
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_Tag_NotCharacterString, "expectedTag");
                    }
                }
                return $.$sfa.SFA.AsnDecoder.TryReadCharacterStringBytesCore(source, ruleSet, expectedTag, universalTagNumber, destination, bytesConsumed, bytesWritten);
            }
            //--TRIMMABLE-BOUNDARY-END(266288234515)
            
            //--TRIMMABLE-BOUNDARY-START(261993267219)
            static /*bool */ TryReadCharacterString(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*AsnEncodingRules*/ ruleSet, /*UniversalTagNumber*/ encodingType, /*out int*/ bytesConsumed, /*out int*/ charsWritten, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993267219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Text.Encoding*/ let encoding = $.$sfa.SFA.AsnCharacterStringEncodings.GetEncoding(encodingType);
                return $.$sfa.SFA.AsnDecoder.TryReadCharacterStringCore(source, ruleSet, expectedTag ?? new $.$sfa.SFA.Asn1Tag().$ctor$5(encodingType, false), encodingType, encoding, destination, bytesConsumed, charsWritten);
            }
            //--TRIMMABLE-BOUNDARY-END(261993267219)
            
            //--TRIMMABLE-BOUNDARY-START(124554313747)
            static /*string */ ReadCharacterString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*UniversalTagNumber*/ encodingType, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554313747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Text.Encoding*/ let encoding = $.$sfa.SFA.AsnCharacterStringEncodings.GetEncoding(encodingType);
                return $.$sfa.SFA.AsnDecoder.ReadCharacterStringCore(source, ruleSet, expectedTag ?? new $.$sfa.SFA.Asn1Tag().$ctor$5(encodingType, false), encodingType, encoding, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(124554313747)
            
            //--TRIMMABLE-BOUNDARY-START(270583201811)
            static /*bool */ TryReadCharacterStringBytesCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten)
            {
                /*int?*/ let contentLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let contents;
                /*int*/ let consumed;
                /*int*/ let bytesRead;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583201811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.SFA.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => contentLength, ($v) => contentLength = $v, $.$typeNullable($.$$.S.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.S.Int32), $.$ref(() => contents, ($v) => contents = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32)))
                {
                    if (contents.Length > destination.Length)
                    {
                        bytesWritten.$v = 0;
                        bytesConsumed.$v = 0;
                        return false;
                    }
                    contents.CopyTo(destination);
                    bytesWritten.$v = contents.Length;
                    bytesConsumed.$v = consumed;
                    return true;
                }
                /*bool*/ let copied = $.$sfa.SFA.AsnDecoder.TryCopyConstructedOctetStringContents($.$sfa.SFA.AsnDecoder.Slice$2(source, headerLength, contentLength), ruleSet, destination, contentLength === null, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.S.Int32), bytesWritten);
                if (copied)
                {
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                }
                else 
                {
                    bytesConsumed.$v = 0;
                }
                return copied;
            }
            //--TRIMMABLE-BOUNDARY-END(270583201811)
            
            //--TRIMMABLE-BOUNDARY-START(279173136403)
            static /*bool */ TryReadCharacterStringCore$1(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Text.Encoding*/ encoding, /*out int*/ charsWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173136403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return encoding.TryGetChars(source, destination, charsWritten);
                }
                catch(e)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$7($.$sfa.S.SR.ContentException_DefaultMessage, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(279173136403)
            
            //--TRIMMABLE-BOUNDARY-START(128849281043)
            static /*string */ ReadCharacterStringCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*Text.Encoding*/ encoding, /*out int*/ bytesConsumed)
            {
                /*int*/ let bytesRead;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849281043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]?*/ let rented = null;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.SFA.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.S.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.S.Byte)), new ($.$$.S.Span$$($.$$.S.Byte))());
                /*string*/ let str;
                if (contents.Length === 0)
                {
                    str = $.$$.S.String.Empty;
                }
                else 
                {
                    {
                        /*fixed*/ 
                        {
                            /*byte**/ let bytePtr = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Byte, contents);
                            try
                            {
                                str = encoding.GetString$2(bytePtr, contents.Length);
                            }
                            catch(e)
                            {
                                throw new $.$sfa.SFA.AsnContentException().$ctor$7($.$sfa.S.SR.ContentException_DefaultMessage, e);
                            }
                        }
                    }
                }
                if (rented !== null)
                {
                    $.$sfa.SSC.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = bytesRead;
                return str;
            }
            //--TRIMMABLE-BOUNDARY-END(128849281043)
            
            //--TRIMMABLE-BOUNDARY-START(274878169107)
            static /*bool */ TryReadCharacterStringCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*Text.Encoding*/ encoding, /*Span<char>*/ destination, /*out int*/ bytesConsumed, /*out int*/ charsWritten)
            {
                /*int*/ let bytesRead;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878169107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]?*/ let rented = null;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.SFA.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.S.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.S.Byte)), new ($.$$.S.Span$$($.$$.S.Byte))());
                /*bool*/ let copied = $.$sfa.SFA.AsnDecoder.TryReadCharacterStringCore$1(contents, destination, encoding, charsWritten);
                if (rented !== null)
                {
                    $.$sfa.SSC.CryptoPool.Return$1(rented, contents.Length);
                }
                if (copied)
                {
                    bytesConsumed.$v = bytesRead;
                }
                else 
                {
                    bytesConsumed.$v = 0;
                }
                return copied;
            }
            //--TRIMMABLE-BOUNDARY-END(274878169107)
            
            //--TRIMMABLE-BOUNDARY-START(81604640787)
            static /*bool */ IsCharacterStringEncodingType(/*UniversalTagNumber*/ encodingType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(encodingType)
                {
                    case 30/*UniversalTagNumber.BMPString*/:
                    case 27/*UniversalTagNumber.GeneralString*/:
                    case 25/*UniversalTagNumber.GraphicString*/:
                    case 22/*UniversalTagNumber.IA5String*/:
                    case 26/*UniversalTagNumber.ISO646String*/:
                    case 18/*UniversalTagNumber.NumericString*/:
                    case 19/*UniversalTagNumber.PrintableString*/:
                    case 20/*UniversalTagNumber.TeletexString*/:
                    case 28/*UniversalTagNumber.UniversalString*/:
                    case 12/*UniversalTagNumber.UTF8String*/:
                    case 21/*UniversalTagNumber.VideotexString*/:
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(81604640787)
            
            static $h = 262163;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(180388888595),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadNull",
      "d": 262163,
      "h": 180388888595,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(180388888595),
//--TRIMMABLE-BOUNDARY-START(197568757779),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "contentOffset",
          "p": 655361,
          "f": 2
        },
        {
          "n": "contentLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadSequence",
      "d": 262163,
      "h": 197568757779,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(197568757779),
//--TRIMMABLE-BOUNDARY-START(120259346451),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadBoolean",
      "d": 262163,
      "h": 120259346451,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120259346451),
//--TRIMMABLE-BOUNDARY-START(137439215635),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadEnumeratedBytes",
      "d": 262163,
      "h": 137439215635,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(137439215635),
//--TRIMMABLE-BOUNDARY-START(146029150227),
    {
      "r": (TEnum) => TEnum.$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "g": [
        "TEnum"
      ],
      "n": "ReadEnumeratedValue",
      "o": "@$1",
      "d": 262163,
      "h": 146029150227,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(146029150227),
//--TRIMMABLE-BOUNDARY-START(141734182931),
    {
      "r": 1048577,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "enumType",
          "p": 188547073
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadEnumeratedValue",
      "d": 262163,
      "h": 141734182931,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141734182931),
//--TRIMMABLE-BOUNDARY-START(201863725075),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "contentOffset",
          "p": 655361,
          "f": 2
        },
        {
          "n": "contentLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "skipSortOrderValidation",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadSetOf",
      "d": 262163,
      "h": 201863725075,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(201863725075),
//--TRIMMABLE-BOUNDARY-START(176093921299),
    {
      "r": (TFlagsEnum) => TFlagsEnum.$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "g": [
        "TFlagsEnum"
      ],
      "n": "ReadNamedBitListValue",
      "o": "@$1",
      "d": 262163,
      "h": 176093921299,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(176093921299),
//--TRIMMABLE-BOUNDARY-START(171798954003),
    {
      "r": 1048577,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "flagsEnumType",
          "p": 188547073
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadNamedBitListValue",
      "d": 262163,
      "h": 171798954003,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(171798954003),
//--TRIMMABLE-BOUNDARY-START(167503986707),
    {
      "r": 56033281,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadNamedBitList",
      "d": 262163,
      "h": 167503986707,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(167503986707),
//--TRIMMABLE-BOUNDARY-START(77309673491),
    {
      "r": 917505,
      "p": [
        {
          "n": "valueSpan",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "InterpretNamedBitListReversed",
      "d": 262163,
      "h": 77309673491,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77309673491),
//--TRIMMABLE-BOUNDARY-START(219043594259),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "ReverseBitsPerByte",
      "d": 262163,
      "h": 219043594259,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(219043594259),
//--TRIMMABLE-BOUNDARY-START(214748626963),
    {
      "r": 66191361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "twoDigitYearMax",
          "p": 655361,
          "f": 65,
          "v": 2049
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadUtcTime",
      "d": 262163,
      "h": 214748626963,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(214748626963),
//--TRIMMABLE-BOUNDARY-START(107374444563),
    {
      "r": 66191361,
      "p": [
        {
          "n": "contentOctets",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "twoDigitYearMax",
          "p": 655361
        }
      ],
      "n": "ParseUtcTime",
      "d": 262163,
      "h": 107374444563,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107374444563),
//--TRIMMABLE-BOUNDARY-START(150324117523),
    {
      "r": 66191361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadGeneralizedTime",
      "d": 262163,
      "h": 150324117523,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(150324117523),
//--TRIMMABLE-BOUNDARY-START(90194575379),
    {
      "r": 66191361,
      "p": [
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "contentOctets",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "ParseGeneralizedTime",
      "d": 262163,
      "h": 90194575379,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90194575379),
//--TRIMMABLE-BOUNDARY-START(184683855891),
    {
      "r": 1310721,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadObjectIdentifier",
      "d": 262163,
      "h": 184683855891,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(184683855891),
//--TRIMMABLE-BOUNDARY-START(206158692371),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        },
        {
          "n": "smallValue",
          "p": $.$typeNullable($.$$.S.Int64).$h,
          "f": 2
        },
        {
          "n": "largeValue",
          "p": $.$typeNullable($.$srn.SN.BigInteger).$h,
          "f": 2
        }
      ],
      "n": "ReadSubIdentifier",
      "d": 262163,
      "h": 206158692371,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(206158692371),
//--TRIMMABLE-BOUNDARY-START(188978823187),
    {
      "r": 1310721,
      "p": [
        {
          "n": "contents",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "ReadObjectIdentifier",
      "o": "@$1",
      "d": 262163,
      "h": 188978823187,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(188978823187),
//--TRIMMABLE-BOUNDARY-START(283468103699),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "tag",
          "p": 65555,
          "f": 2
        },
        {
          "n": "contentOffset",
          "p": 655361,
          "f": 2
        },
        {
          "n": "contentLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadEncodedValue",
      "d": 262163,
      "h": 283468103699,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(283468103699),
//--TRIMMABLE-BOUNDARY-START(133144248339),
    {
      "r": 65555,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "contentOffset",
          "p": 655361,
          "f": 2
        },
        {
          "n": "contentLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ReadEncodedValue",
      "d": 262163,
      "h": 133144248339,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(133144248339),
//--TRIMMABLE-BOUNDARY-START(64424771603),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "tagNumber",
          "p": 1572883
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetPrimitiveContentSpan",
      "d": 262163,
      "h": 64424771603,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424771603),
//--TRIMMABLE-BOUNDARY-START(42949935123),
    {
      "r": $.$typeNullable($.$$.S.Int32).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "DecodeLength",
      "d": 262163,
      "h": 42949935123,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949935123),
//--TRIMMABLE-BOUNDARY-START(253403332627),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "decodedLength",
          "p": $.$typeNullable($.$$.S.Int32).$h,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecodeLength",
      "d": 262163,
      "h": 253403332627,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(253403332627),
//--TRIMMABLE-BOUNDARY-START(296353005587),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "length",
          "p": $.$typeNullable($.$$.S.Int32).$h,
          "f": 2
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadLength",
      "d": 262163,
      "h": 296353005587,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(296353005587),
//--TRIMMABLE-BOUNDARY-START(163209019411),
    {
      "r": $.$typeNullable($.$$.S.Int32).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ReadLength",
      "d": 262163,
      "h": 163209019411,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(163209019411),
//--TRIMMABLE-BOUNDARY-START(47244902419),
    {
      "r": 393235,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "length",
          "p": $.$typeNullable($.$$.S.Int32).$h,
          "f": 2
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "DecodeLength",
      "o": "@$1",
      "d": 262163,
      "h": 47244902419,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47244902419),
//--TRIMMABLE-BOUNDARY-START(210453659667),
    {
      "r": 65555,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "contentsLength",
          "p": $.$typeNullable($.$$.S.Int32).$h,
          "f": 2
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ReadTagAndLength",
      "d": 262163,
      "h": 210453659667,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(210453659667),
//--TRIMMABLE-BOUNDARY-START(343597645843),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "length",
          "p": $.$typeNullable($.$$.S.Int32).$h
        },
        {
          "n": "headerLength",
          "p": 655361
        }
      ],
      "n": "ValidateEndOfContents",
      "d": 262163,
      "h": 343597645843,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(343597645843),
//--TRIMMABLE-BOUNDARY-START(347892613139),
    {
      "r": 458771,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "localTag",
          "p": 65555
        },
        {
          "n": "encodedLength",
          "p": $.$typeNullable($.$$.S.Int32).$h
        },
        {
          "n": "actualLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ValidateLength",
      "d": 262163,
      "h": 347892613139,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(347892613139),
//--TRIMMABLE-BOUNDARY-START(73014706195),
    {
      "r": 196627,
      "p": [
        {
          "n": "validity",
          "p": 458771
        }
      ],
      "n": "GetValidityException",
      "d": 262163,
      "h": 73014706195,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73014706195),
//--TRIMMABLE-BOUNDARY-START(68719738899),
    {
      "r": 655361,
      "p": [
        {
          "n": "primitiveType",
          "p": 188547073
        }
      ],
      "n": "GetPrimitiveIntegerSize",
      "d": 262163,
      "h": 68719738899,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68719738899),
//--TRIMMABLE-BOUNDARY-START(223338561555),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        }
      ],
      "n": "SeekEndOfContents",
      "d": 262163,
      "h": 223338561555,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(223338561555),
//--TRIMMABLE-BOUNDARY-START(98784509971),
    {
      "r": 655361,
      "p": [
        {
          "n": "data",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "bytesToRead",
          "p": 655361
        }
      ],
      "n": "ParseNonNegativeIntAndSlice",
      "d": 262163,
      "h": 98784509971,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(98784509971),
//--TRIMMABLE-BOUNDARY-START(94489542675),
    {
      "r": 655361,
      "p": [
        {
          "n": "data",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "ParseNonNegativeInt",
      "d": 262163,
      "h": 94489542675,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94489542675),
//--TRIMMABLE-BOUNDARY-START(240518430739),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "longestPermitted",
          "p": 655361
        }
      ],
      "n": "SliceAtMost",
      "d": 262163,
      "h": 240518430739,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(240518430739),
//--TRIMMABLE-BOUNDARY-START(231928496147),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "Slice",
      "o": "@$1",
      "d": 262163,
      "h": 231928496147,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(231928496147),
//--TRIMMABLE-BOUNDARY-START(236223463443),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "length",
          "p": $.$typeNullable($.$$.S.Int32).$h
        }
      ],
      "n": "Slice",
      "o": "@$2",
      "d": 262163,
      "h": 236223463443,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(236223463443),
//--TRIMMABLE-BOUNDARY-START(227633528851),
    {
      "r": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "bigger",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "smaller",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Slice",
      "d": 262163,
      "h": 227633528851,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(227633528851),
//--TRIMMABLE-BOUNDARY-START(4295229459),
    {
      "r": 65537,
      "p": [
        {
          "n": "ruleSet",
          "p": 524307
        }
      ],
      "n": "AssertEncodingRules",
      "d": 262163,
      "h": 4295229459,
      "f": 16777250,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "DEBUG",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295229459),
//--TRIMMABLE-BOUNDARY-START(8590196755),
    {
      "r": 65537,
      "p": [
        {
          "n": "ruleSet",
          "p": 524307
        }
      ],
      "n": "CheckEncodingRules",
      "d": 262163,
      "h": 8590196755,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590196755),
//--TRIMMABLE-BOUNDARY-START(12885164051),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "tagNumber",
          "p": 1572883
        }
      ],
      "n": "CheckExpectedTag",
      "d": 262163,
      "h": 12885164051,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885164051),
//--TRIMMABLE-BOUNDARY-START(300647972883),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadOctetString",
      "d": 262163,
      "h": 300647972883,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(300647972883),
//--TRIMMABLE-BOUNDARY-START(193273790483),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadOctetString",
      "d": 262163,
      "h": 193273790483,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(193273790483),
//--TRIMMABLE-BOUNDARY-START(322122809363),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "universalTagNumber",
          "p": 1572883
        },
        {
          "n": "contentLength",
          "p": $.$typeNullable($.$$.S.Int32).$h,
          "f": 2
        },
        {
          "n": "headerLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "contents",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadPrimitiveOctetStringCore",
      "d": 262163,
      "h": 322122809363,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(322122809363),
//--TRIMMABLE-BOUNDARY-START(317827842067),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadPrimitiveOctetString",
      "d": 262163,
      "h": 317827842067,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(317827842067),
//--TRIMMABLE-BOUNDARY-START(38654967827),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "isIndefinite",
          "p": 262145
        }
      ],
      "n": "CountConstructedOctetString",
      "d": 262163,
      "h": 38654967827,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38654967827),
//--TRIMMABLE-BOUNDARY-START(25770065939),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "isIndefinite",
          "p": 262145
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "CopyConstructedOctetString",
      "d": 262163,
      "h": 25770065939,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770065939),
//--TRIMMABLE-BOUNDARY-START(30065033235),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "write",
          "p": 262145
        },
        {
          "n": "isIndefinite",
          "p": 262145
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "CopyConstructedOctetString",
      "o": "@$1",
      "d": 262163,
      "h": 30065033235,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065033235),
//--TRIMMABLE-BOUNDARY-START(249108365331),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "dest",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "isIndefinite",
          "p": 262145
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryCopyConstructedOctetStringContents",
      "d": 262163,
      "h": 249108365331,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(249108365331),
//--TRIMMABLE-BOUNDARY-START(60129804307),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "universalTagNumber",
          "p": 1572883
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "rented",
          "p": $.$typeArray($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "tmpSpace",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h,
          "f": 65
        }
      ],
      "n": "GetOctetStringContents",
      "d": 262163,
      "h": 60129804307,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60129804307),
//--TRIMMABLE-BOUNDARY-START(158914052115),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadIntegerBytes",
      "d": 262163,
      "h": 158914052115,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(158914052115),
//--TRIMMABLE-BOUNDARY-START(154619084819),
    {
      "r": 786438,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadInteger",
      "d": 262163,
      "h": 154619084819,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(154619084819),
//--TRIMMABLE-BOUNDARY-START(287763070995),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "value",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadInt32",
      "d": 262163,
      "h": 287763070995,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(287763070995),
//--TRIMMABLE-BOUNDARY-START(330712743955),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "value",
          "p": 720897,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadUInt32",
      "d": 262163,
      "h": 330712743955,
      "f": 16777249,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(330712743955),
//--TRIMMABLE-BOUNDARY-START(292058038291),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "value",
          "p": 917505,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadInt64",
      "d": 262163,
      "h": 292058038291,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(292058038291),
//--TRIMMABLE-BOUNDARY-START(335007711251),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "value",
          "p": 983041,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadUInt64",
      "d": 262163,
      "h": 335007711251,
      "f": 16777249,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(335007711251),
//--TRIMMABLE-BOUNDARY-START(55834837011),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "tagNumber",
          "p": 1572883
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetIntegerContents",
      "d": 262163,
      "h": 55834837011,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55834837011),
//--TRIMMABLE-BOUNDARY-START(326417776659),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "sizeLimit",
          "p": 655361
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "tagNumber",
          "p": 1572883
        },
        {
          "n": "value",
          "p": 917505,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadSignedInteger",
      "d": 262163,
      "h": 326417776659,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(326417776659),
//--TRIMMABLE-BOUNDARY-START(339302678547),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "sizeLimit",
          "p": 655361
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "tagNumber",
          "p": 1572883
        },
        {
          "n": "value",
          "p": 983041,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadUnsignedInteger",
      "d": 262163,
      "h": 339302678547,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(339302678547),
//--TRIMMABLE-BOUNDARY-START(304942940179),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadPrimitiveBitString",
      "d": 262163,
      "h": 304942940179,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(304942940179),
//--TRIMMABLE-BOUNDARY-START(257698299923),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadBitString",
      "d": 262163,
      "h": 257698299923,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(257698299923),
//--TRIMMABLE-BOUNDARY-START(115964379155),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadBitString",
      "d": 262163,
      "h": 115964379155,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115964379155),
//--TRIMMABLE-BOUNDARY-START(103079477267),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
          "f": 2
        },
        {
          "n": "normalizedLastByte",
          "p": 393217,
          "f": 2
        }
      ],
      "n": "ParsePrimitiveBitStringContents",
      "d": 262163,
      "h": 103079477267,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103079477267),
//--TRIMMABLE-BOUNDARY-START(17180131347),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "normalizedLastByte",
          "p": 393217
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "CopyBitStringValue",
      "d": 262163,
      "h": 17180131347,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180131347),
//--TRIMMABLE-BOUNDARY-START(34360000531),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "isIndefinite",
          "p": 262145
        }
      ],
      "n": "CountConstructedBitString",
      "d": 262163,
      "h": 34360000531,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34360000531),
//--TRIMMABLE-BOUNDARY-START(21475098643),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "isIndefinite",
          "p": 262145
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "CopyConstructedBitString",
      "d": 262163,
      "h": 21475098643,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475098643),
//--TRIMMABLE-BOUNDARY-START(111669411859),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "copyAction",
          "p": 327699
        },
        {
          "n": "isIndefinite",
          "p": 262145
        },
        {
          "n": "lastUnusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ProcessConstructedBitString",
      "d": 262163,
      "h": 111669411859,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(111669411859),
//--TRIMMABLE-BOUNDARY-START(244813398035),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "dest",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "isIndefinite",
          "p": 262145
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesRead",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryCopyConstructedBitStringValue",
      "d": 262163,
      "h": 244813398035,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(244813398035),
//--TRIMMABLE-BOUNDARY-START(309237907475),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "contentsLength",
          "p": $.$typeNullable($.$$.S.Int32).$h,
          "f": 2
        },
        {
          "n": "headerLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "normalizedLastByte",
          "p": 393217,
          "f": 2
        }
      ],
      "n": "TryReadPrimitiveBitStringCore",
      "d": 262163,
      "h": 309237907475,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(309237907475),
//--TRIMMABLE-BOUNDARY-START(313532874771),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadPrimitiveCharacterStringBytes",
      "d": 262163,
      "h": 313532874771,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(313532874771),
//--TRIMMABLE-BOUNDARY-START(266288234515),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadCharacterStringBytes",
      "d": 262163,
      "h": 266288234515,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(266288234515),
//--TRIMMABLE-BOUNDARY-START(261993267219),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "encodingType",
          "p": 1572883
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadCharacterString",
      "d": 262163,
      "h": 261993267219,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(261993267219),
//--TRIMMABLE-BOUNDARY-START(124554313747),
    {
      "r": 1310721,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "encodingType",
          "p": 1572883
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadCharacterString",
      "d": 262163,
      "h": 124554313747,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124554313747),
//--TRIMMABLE-BOUNDARY-START(270583201811),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "universalTagNumber",
          "p": 1572883
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadCharacterStringBytesCore",
      "d": 262163,
      "h": 270583201811,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(270583201811),
//--TRIMMABLE-BOUNDARY-START(279173136403),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadCharacterStringCore",
      "o": "@$1",
      "d": 262163,
      "h": 279173136403,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(279173136403),
//--TRIMMABLE-BOUNDARY-START(128849281043),
    {
      "r": 1310721,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "universalTagNumber",
          "p": 1572883
        },
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ReadCharacterStringCore",
      "d": 262163,
      "h": 128849281043,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(128849281043),
//--TRIMMABLE-BOUNDARY-START(274878169107),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "universalTagNumber",
          "p": 1572883
        },
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadCharacterStringCore",
      "d": 262163,
      "h": 274878169107,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(274878169107),
//--TRIMMABLE-BOUNDARY-START(81604640787),
    {
      "r": 262145,
      "p": [
        {
          "n": "encodingType",
          "p": 1572883
        }
      ],
      "n": "IsCharacterStringEncodingType",
      "d": 262163,
      "h": 81604640787,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604640787)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(85899608083),
    {
      "t": 655361,
      "n": "MaxCERSegmentSize",
      "d": 262163,
      "h": 85899608083,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85899608083),
//--TRIMMABLE-BOUNDARY-START(51539869715),
    {
      "t": 655361,
      "n": "EndOfContentsEncodedLength",
      "d": 262163,
      "h": 51539869715,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51539869715)
  ],
  "h": 262163
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sfa.SFA.AsnDecoder.LengthDecodeStatus, $.$sfa.SFA.AsnDecoder.LengthValidity, $.$sfa.SFA.AsnDecoder.BitStringCopyAction ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.AsnDecoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}AsnDecoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262163)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835027)
        $asm.$cls(`$sfa.SSC.CryptoPool`, ($self) => class CryptoPool
        {
            //--TRIMMABLE-BOUNDARY-START(4296802323)
            /*int*/ static ClearAll = -1;
            //--TRIMMABLE-BOUNDARY-END(4296802323)
            
            //--TRIMMABLE-BOUNDARY-START(8591769619)
            static /*byte[] */ Rent(/*int*/ minimumLength)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591769619);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(minimumLength);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591769619)
            
            //--TRIMMABLE-BOUNDARY-START(12886736915)
            static /*void */ Return(/*ArraySegment<byte>*/ arraySegment, /*int*/ clearSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886736915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(arraySegment.Array !== null, "arraySegment.Array != null");
                $.$$.SD.Debug.Assert$4(arraySegment.Offset === 0, "arraySegment.Offset == 0");
                $.$sfa.SSC.CryptoPool.Return$1(arraySegment.Array, clearSize === -1/*ClearAll*/ ? arraySegment.Count : clearSize);
            }
            //--TRIMMABLE-BOUNDARY-END(12886736915)
            
            //--TRIMMABLE-BOUNDARY-START(17181704211)
            static /*void */ Return$1(/*byte[]*/ array, /*int*/ clearSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181704211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(clearSize <= array.length, "clearSize <= array.Length");
                /*bool*/ let clearWholeArray = clearSize < 0;
                if (!clearWholeArray && clearSize !== 0)
                {
                    $.$$.S.Array.Clear(array, 0, clearSize);
                }
                $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(array, clearWholeArray);
            }
            //--TRIMMABLE-BOUNDARY-END(17181704211)
            
            static $h = 1835027;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591769619),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "minimumLength",
          "p": 655361
        }
      ],
      "n": "Rent",
      "d": 1835027,
      "h": 8591769619,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591769619),
//--TRIMMABLE-BOUNDARY-START(12886736915),
    {
      "r": 65537,
      "p": [
        {
          "n": "arraySegment",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "clearSize",
          "p": 655361,
          "f": 65,
          "v": -1
        }
      ],
      "n": "Return",
      "d": 1835027,
      "h": 12886736915,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886736915),
//--TRIMMABLE-BOUNDARY-START(17181704211),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "clearSize",
          "p": 655361,
          "f": 65,
          "v": -1
        }
      ],
      "n": "Return",
      "o": "@$1",
      "d": 1835027,
      "h": 17181704211,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17181704211)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296802323),
    {
      "t": 655361,
      "n": "ClearAll",
      "d": 1835027,
      "h": 4296802323,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4296802323)
  ],
  "h": 1835027
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Cryptography.CryptoPool`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Cryptography${separator}CryptoPool`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835027)
        
        

        //--TRIMMABLE-BOUNDARY-START(589843)
        $asm.$cls(`$sfa.SFA.AsnReader`, ($self) => class AsnReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(124554641427)
            /*void */ ReadNull(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554641427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnDecoder.ReadNull(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
            }
            //--TRIMMABLE-BOUNDARY-END(124554641427)
            
            //--TRIMMABLE-BOUNDARY-START(137439543315)
            /*AsnReader */ ReadSequence(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let contentStart;
                /*int*/ let contentLength;
                /*int*/ let bytesConsumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439543315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnDecoder.ReadSequence(this._data.Span, this.RuleSet, $.$ref(() => contentStart, ($v) => contentStart = $v, $.$$.S.Int32), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$$.S.Int32), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                /*AsnReader*/ let ret = this.CloneAtSlice(contentStart, contentLength);
                this._data = this._data.Slice$1(bytesConsumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(137439543315)
            
            //--TRIMMABLE-BOUNDARY-START(73015033875)
            /*bool */ ReadBoolean(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let bytesConsumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ret = $.$sfa.SFA.AsnDecoder.ReadBoolean(this._data.Span, this.RuleSet, $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(bytesConsumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(73015033875)
            
            //--TRIMMABLE-BOUNDARY-START(85899935763)
            /*ReadOnlyMemory<byte> */ ReadEnumeratedBytes(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let bytes = $.$sfa.SFA.AsnDecoder.ReadEnumeratedBytes(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                /*ReadOnlyMemory<byte>*/ let memory = $.$sfa.SFA.AsnDecoder.Slice(this._data, bytes);
                this._data = this._data.Slice$1(consumed);
                return memory;
            }
            //--TRIMMABLE-BOUNDARY-END(85899935763)
            
            //--TRIMMABLE-BOUNDARY-START(94489870355)
            /*TEnum */ ReadEnumeratedValue$1(TEnum, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489870355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TEnum*/ let ret = $.$sfa.SFA.AsnDecoder.ReadEnumeratedValue$1(TEnum, this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(94489870355)
            
            //--TRIMMABLE-BOUNDARY-START(90194903059)
            /*Enum */ ReadEnumeratedValue(/*Type*/ enumType, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Enum*/ let ret = $.$sfa.SFA.AsnDecoder.ReadEnumeratedValue(this._data.Span, this.RuleSet, enumType, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(90194903059)
            
            //--TRIMMABLE-BOUNDARY-START(146029477907)
            /*AsnReader */ ReadSetOf$1(/*Asn1Tag?*/ expectedTag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029477907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadSetOf(this._options.SkipSetSortOrderVerification, $.$clone(expectedTag));
            }
            //--TRIMMABLE-BOUNDARY-END(146029477907)
            
            //--TRIMMABLE-BOUNDARY-START(141734510611)
            /*AsnReader */ ReadSetOf(/*bool*/ skipSortOrderValidation, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let contentOffset;
                /*int*/ let contentLength;
                /*int*/ let bytesConsumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734510611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnDecoder.ReadSetOf(this._data.Span, this.RuleSet, $.$ref(() => contentOffset, ($v) => contentOffset = $v, $.$$.S.Int32), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$$.S.Int32), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.S.Int32), skipSortOrderValidation, $.$clone(expectedTag));
                /*AsnReader*/ let ret = this.CloneAtSlice(contentOffset, contentLength);
                this._data = this._data.Slice$1(bytesConsumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(141734510611)
            
            //--TRIMMABLE-BOUNDARY-START(120259674131)
            /*TFlagsEnum */ ReadNamedBitListValue$1(TFlagsEnum, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259674131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TFlagsEnum*/ let ret = $.$sfa.SFA.AsnDecoder.ReadNamedBitListValue$1(TFlagsEnum, this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(120259674131)
            
            //--TRIMMABLE-BOUNDARY-START(115964706835)
            /*Enum */ ReadNamedBitListValue(/*Type*/ flagsEnumType, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Enum*/ let ret = $.$sfa.SFA.AsnDecoder.ReadNamedBitListValue(this._data.Span, this.RuleSet, flagsEnumType, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(115964706835)
            
            //--TRIMMABLE-BOUNDARY-START(111669739539)
            /*BitArray */ ReadNamedBitList(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669739539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*BitArray*/ let ret = $.$sfa.SFA.AsnDecoder.ReadNamedBitList(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(111669739539)
            
            //--TRIMMABLE-BOUNDARY-START(154619412499)
            /*DateTimeOffset */ ReadUtcTime$1(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619412499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*DateTimeOffset*/ let ret = $.$sfa.SFA.AsnDecoder.ReadUtcTime(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), this._options.UtcTimeTwoDigitYearMax, $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(154619412499)
            
            //--TRIMMABLE-BOUNDARY-START(150324445203)
            /*DateTimeOffset */ ReadUtcTime(/*int*/ twoDigitYearMax, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324445203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*DateTimeOffset*/ let ret = $.$sfa.SFA.AsnDecoder.ReadUtcTime(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), twoDigitYearMax, $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(150324445203)
            
            //--TRIMMABLE-BOUNDARY-START(98784837651)
            /*DateTimeOffset */ ReadGeneralizedTime(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784837651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*DateTimeOffset*/ let ret = $.$sfa.SFA.AsnDecoder.ReadGeneralizedTime(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(98784837651)
            
            //--TRIMMABLE-BOUNDARY-START(128849608723)
            /*string */ ReadObjectIdentifier(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849608723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let oidValue = $.$sfa.SFA.AsnDecoder.ReadObjectIdentifier(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return oidValue;
            }
            //--TRIMMABLE-BOUNDARY-END(128849608723)
            
            //--TRIMMABLE-BOUNDARY-START(51540197395)
            /*int*/ static MaxCERSegmentSize = 1000;
            //--TRIMMABLE-BOUNDARY-END(51540197395)
            
            //--TRIMMABLE-BOUNDARY-START(4295557139)
            /*ReadOnlyMemory<byte>*/ _data;
            //--TRIMMABLE-BOUNDARY-END(4295557139)
            
            //--TRIMMABLE-BOUNDARY-START(8590524435)
            /*AsnReaderOptions*/ _options;
            //--TRIMMABLE-BOUNDARY-END(8590524435)
            
            //--TRIMMABLE-BOUNDARY-START(158914379795)
            /*AsnEncodingRules*/ RuleSet = 0;
            //--TRIMMABLE-BOUNDARY-END(158914379795)
            
            //--TRIMMABLE-BOUNDARY-START(47245230099)
            /*bool */ get HasData()
            {
                return !this._data.IsEmpty;
            }
            //--TRIMMABLE-BOUNDARY-END(47245230099)
            
            //--TRIMMABLE-BOUNDARY-START(17180459027)
            $ctor$1(/*ReadOnlyMemory<byte>*/ data, /*AsnEncodingRules*/ ruleSet, /*AsnReaderOptions*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180459027);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$sfa.SFA.AsnDecoder.CheckEncodingRules(ruleSet);
                    this._data = data;
                    this.RuleSet = ruleSet;
                    this._options = $.$clone(options);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459027)
            
            //--TRIMMABLE-BOUNDARY-START(163209347091)
            /*void */ ThrowIfNotEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209347091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.HasData)
                {
                    throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_TooMuchData);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209347091)
            
            //--TRIMMABLE-BOUNDARY-START(64425099283)
            /*Asn1Tag */ PeekTag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425099283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.Asn1Tag.Decode(this._data.Span, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(64425099283)
            
            //--TRIMMABLE-BOUNDARY-START(60130131987)
            /*ReadOnlyMemory<byte> */ PeekEncodedValue()
            {
                /*int*/ let bytesConsumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130131987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnDecoder.ReadEncodedValue(this._data.Span, this.RuleSet, $.$discardRef(), $.$discardRef(), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.S.Int32));
                return this._data.Slice(0, bytesConsumed);
            }
            //--TRIMMABLE-BOUNDARY-END(60130131987)
            
            //--TRIMMABLE-BOUNDARY-START(55835164691)
            /*ReadOnlyMemory<byte> */ PeekContentBytes()
            {
                /*int*/ let contentOffset;
                /*int*/ let contentLength;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835164691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnDecoder.ReadEncodedValue(this._data.Span, this.RuleSet, $.$ref(() => contentOffset, ($v) => contentOffset = $v, $.$$.S.Int32), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$$.S.Int32), $.$discardRef());
                return this._data.Slice(contentOffset, contentLength);
            }
            //--TRIMMABLE-BOUNDARY-END(55835164691)
            
            //--TRIMMABLE-BOUNDARY-START(81604968467)
            /*ReadOnlyMemory<byte> */ ReadEncodedValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604968467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlyMemory<byte>*/ let encodedValue = this.PeekEncodedValue();
                this._data = this._data.Slice$1(encodedValue.Length);
                return encodedValue;
            }
            //--TRIMMABLE-BOUNDARY-END(81604968467)
            
            //--TRIMMABLE-BOUNDARY-START(21475426323)
            /*AsnReader */ Clone()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426323);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sfa.SFA.AsnReader().$ctor$1(this._data, this.RuleSet, $.$clone(this._options));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475426323)
            
            //--TRIMMABLE-BOUNDARY-START(25770393619)
            /*AsnReader */ CloneAtSlice(/*int*/ start, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sfa.SFA.AsnReader().$ctor$1(this._data.Slice(start, length), this.RuleSet, $.$clone(this._options));
            }
            //--TRIMMABLE-BOUNDARY-END(25770393619)
            
            //--TRIMMABLE-BOUNDARY-START(188979150867)
            /*bool */ TryReadOctetString(/*Span<byte>*/ destination, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let bytesConsumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979150867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ret = $.$sfa.SFA.AsnDecoder.TryReadOctetString(this._data.Span, destination, this.RuleSet, $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.S.Int32), bytesWritten, $.$clone(expectedTag));
                if (ret)
                {
                    this._data = this._data.Slice$1(bytesConsumed);
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(188979150867)
            
            //--TRIMMABLE-BOUNDARY-START(133144576019)
            /*byte[] */ ReadOctetString(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144576019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let ret = $.$sfa.SFA.AsnDecoder.ReadOctetString(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(133144576019)
            
            //--TRIMMABLE-BOUNDARY-START(201864052755)
            /*bool */ TryReadPrimitiveOctetString(/*out ReadOnlyMemory<byte>*/ contents, /*Asn1Tag?*/ expectedTag)
            {
                /*ReadOnlySpan<byte>*/ let span;
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864052755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ret = $.$sfa.SFA.AsnDecoder.TryReadPrimitiveOctetString(this._data.Span, this.RuleSet, $.$ref(() => span, ($v) => span = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                if (ret)
                {
                    contents.$v = $.$sfa.SFA.AsnDecoder.Slice(this._data, span);
                    this._data = this._data.Slice$1(consumed);
                }
                else 
                {
                    contents.$v = new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))();
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(201864052755)
            
            //--TRIMMABLE-BOUNDARY-START(107374772243)
            /*ReadOnlyMemory<byte> */ ReadIntegerBytes(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374772243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let bytes = $.$sfa.SFA.AsnDecoder.ReadIntegerBytes(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                /*ReadOnlyMemory<byte>*/ let ret = $.$sfa.SFA.AsnDecoder.Slice(this._data, bytes);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(107374772243)
            
            //--TRIMMABLE-BOUNDARY-START(103079804947)
            /*BigInteger */ ReadInteger(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079804947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*BigInteger*/ let ret = $.$sfa.SFA.AsnDecoder.ReadInteger(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(103079804947)
            
            //--TRIMMABLE-BOUNDARY-START(180389216275)
            /*bool */ TryReadInt32(/*out int*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let read;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389216275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ret = $.$sfa.SFA.AsnDecoder.TryReadInt32(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(read);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(180389216275)
            
            //--TRIMMABLE-BOUNDARY-START(206159020051)
            /*bool */ TryReadUInt32(/*out uint*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let read;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159020051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ret = $.$sfa.SFA.AsnDecoder.TryReadUInt32(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(read);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(206159020051)
            
            //--TRIMMABLE-BOUNDARY-START(184684183571)
            /*bool */ TryReadInt64(/*out long*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let read;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684183571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ret = $.$sfa.SFA.AsnDecoder.TryReadInt64(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(read);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(184684183571)
            
            //--TRIMMABLE-BOUNDARY-START(210453987347)
            /*bool */ TryReadUInt64(/*out ulong*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let read;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453987347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ret = $.$sfa.SFA.AsnDecoder.TryReadUInt64(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(read);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(210453987347)
            
            //--TRIMMABLE-BOUNDARY-START(193274118163)
            /*bool */ TryReadPrimitiveBitString(/*out int*/ unusedBitCount, /*out ReadOnlyMemory<byte>*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*ReadOnlySpan<byte>*/ let span;
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274118163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ret = $.$sfa.SFA.AsnDecoder.TryReadPrimitiveBitString(this._data.Span, this.RuleSet, unusedBitCount, $.$ref(() => span, ($v) => span = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                if (ret)
                {
                    value.$v = $.$sfa.SFA.AsnDecoder.Slice(this._data, span);
                    this._data = this._data.Slice$1(consumed);
                }
                else 
                {
                    value.$v = new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))();
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(193274118163)
            
            //--TRIMMABLE-BOUNDARY-START(167504314387)
            /*bool */ TryReadBitString(/*Span<byte>*/ destination, /*out int*/ unusedBitCount, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504314387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ret = $.$sfa.SFA.AsnDecoder.TryReadBitString(this._data.Span, destination, this.RuleSet, unusedBitCount, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), bytesWritten, $.$clone(expectedTag));
                if (ret)
                {
                    this._data = this._data.Slice$1(consumed);
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(167504314387)
            
            //--TRIMMABLE-BOUNDARY-START(68720066579)
            /*byte[] */ ReadBitString(/*out int*/ unusedBitCount, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let ret = $.$sfa.SFA.AsnDecoder.ReadBitString(this._data.Span, this.RuleSet, unusedBitCount, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(68720066579)
            
            //--TRIMMABLE-BOUNDARY-START(197569085459)
            /*bool */ TryReadPrimitiveCharacterStringBytes(/*Asn1Tag*/ expectedTag, /*out ReadOnlyMemory<byte>*/ contents)
            {
                /*ReadOnlySpan<byte>*/ let span;
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569085459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ret = $.$sfa.SFA.AsnDecoder.TryReadPrimitiveCharacterStringBytes(this._data.Span, this.RuleSet, expectedTag, $.$ref(() => span, ($v) => span = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32));
                if (ret)
                {
                    contents.$v = $.$sfa.SFA.AsnDecoder.Slice(this._data, span);
                    this._data = this._data.Slice$1(consumed);
                }
                else 
                {
                    contents.$v = new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))();
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(197569085459)
            
            //--TRIMMABLE-BOUNDARY-START(176094248979)
            /*bool */ TryReadCharacterStringBytes(/*Span<byte>*/ destination, /*Asn1Tag*/ expectedTag, /*out int*/ bytesWritten)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094248979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ret = $.$sfa.SFA.AsnDecoder.TryReadCharacterStringBytes(this._data.Span, destination, this.RuleSet, expectedTag, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), bytesWritten);
                if (ret)
                {
                    this._data = this._data.Slice$1(consumed);
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(176094248979)
            
            //--TRIMMABLE-BOUNDARY-START(171799281683)
            /*bool */ TryReadCharacterString(/*Span<char>*/ destination, /*UniversalTagNumber*/ encodingType, /*out int*/ charsWritten, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799281683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ret = $.$sfa.SFA.AsnDecoder.TryReadCharacterString(this._data.Span, destination, this.RuleSet, encodingType, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), charsWritten, $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(171799281683)
            
            //--TRIMMABLE-BOUNDARY-START(77310001171)
            /*string */ ReadCharacterString(/*UniversalTagNumber*/ encodingType, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let ret = $.$sfa.SFA.AsnDecoder.ReadCharacterString(this._data.Span, this.RuleSet, encodingType, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32), $.$clone(expectedTag));
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(77310001171)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295557139)
                this._data = $.$default($.$$.S.ReadOnlyMemory$$($.$$.S.Byte));
                //--TRIMMABLE-BOUNDARY-END(4295557139)
                
                //--TRIMMABLE-BOUNDARY-START(8590524435)
                this._options = $.$default($.$sfa.SFA.AsnReaderOptions);
                //--TRIMMABLE-BOUNDARY-END(8590524435)
                
            }
            static $h = 589843;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(158914379795),
    {
      "p": 524307,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262803,
        "f": 50331649
      },
      "n": "RuleSet",
      "d": 589843,
      "h": 158914379795,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914379795),
//--TRIMMABLE-BOUNDARY-START(47245230099),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360328211,
        "f": 50331649
      },
      "n": "HasData",
      "d": 589843,
      "h": 47245230099,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245230099)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(124554641427),
    {
      "r": 65537,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadNull",
      "d": 589843,
      "h": 124554641427,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124554641427),
//--TRIMMABLE-BOUNDARY-START(137439543315),
    {
      "r": 589843,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadSequence",
      "d": 589843,
      "h": 137439543315,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439543315),
//--TRIMMABLE-BOUNDARY-START(73015033875),
    {
      "r": 262145,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadBoolean",
      "d": 589843,
      "h": 73015033875,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015033875),
//--TRIMMABLE-BOUNDARY-START(85899935763),
    {
      "r": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadEnumeratedBytes",
      "d": 589843,
      "h": 85899935763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899935763),
//--TRIMMABLE-BOUNDARY-START(94489870355),
    {
      "r": (TEnum) => TEnum.$h,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "g": [
        "TEnum"
      ],
      "n": "ReadEnumeratedValue",
      "o": "@$1",
      "d": 589843,
      "h": 94489870355,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(94489870355),
//--TRIMMABLE-BOUNDARY-START(90194903059),
    {
      "r": 1048577,
      "p": [
        {
          "n": "enumType",
          "p": 188547073
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadEnumeratedValue",
      "d": 589843,
      "h": 90194903059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194903059),
//--TRIMMABLE-BOUNDARY-START(146029477907),
    {
      "r": 589843,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadSetOf",
      "o": "@$1",
      "d": 589843,
      "h": 146029477907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029477907),
//--TRIMMABLE-BOUNDARY-START(141734510611),
    {
      "r": 589843,
      "p": [
        {
          "n": "skipSortOrderValidation",
          "p": 262145
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadSetOf",
      "d": 589843,
      "h": 141734510611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141734510611),
//--TRIMMABLE-BOUNDARY-START(120259674131),
    {
      "r": (TFlagsEnum) => TFlagsEnum.$h,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "g": [
        "TFlagsEnum"
      ],
      "n": "ReadNamedBitListValue",
      "o": "@$1",
      "d": 589843,
      "h": 120259674131,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(120259674131),
//--TRIMMABLE-BOUNDARY-START(115964706835),
    {
      "r": 1048577,
      "p": [
        {
          "n": "flagsEnumType",
          "p": 188547073
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadNamedBitListValue",
      "d": 589843,
      "h": 115964706835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964706835),
//--TRIMMABLE-BOUNDARY-START(111669739539),
    {
      "r": 56033281,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadNamedBitList",
      "d": 589843,
      "h": 111669739539,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669739539),
//--TRIMMABLE-BOUNDARY-START(154619412499),
    {
      "r": 66191361,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadUtcTime",
      "o": "@$1",
      "d": 589843,
      "h": 154619412499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154619412499),
//--TRIMMABLE-BOUNDARY-START(150324445203),
    {
      "r": 66191361,
      "p": [
        {
          "n": "twoDigitYearMax",
          "p": 655361
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadUtcTime",
      "d": 589843,
      "h": 150324445203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324445203),
//--TRIMMABLE-BOUNDARY-START(98784837651),
    {
      "r": 66191361,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadGeneralizedTime",
      "d": 589843,
      "h": 98784837651,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784837651),
//--TRIMMABLE-BOUNDARY-START(128849608723),
    {
      "r": 1310721,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadObjectIdentifier",
      "d": 589843,
      "h": 128849608723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128849608723),
//--TRIMMABLE-BOUNDARY-START(163209347091),
    {
      "r": 65537,
      "n": "ThrowIfNotEmpty",
      "d": 589843,
      "h": 163209347091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209347091),
//--TRIMMABLE-BOUNDARY-START(64425099283),
    {
      "r": 65555,
      "n": "PeekTag",
      "d": 589843,
      "h": 64425099283,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425099283),
//--TRIMMABLE-BOUNDARY-START(60130131987),
    {
      "r": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
      "n": "PeekEncodedValue",
      "d": 589843,
      "h": 60130131987,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130131987),
//--TRIMMABLE-BOUNDARY-START(55835164691),
    {
      "r": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
      "n": "PeekContentBytes",
      "d": 589843,
      "h": 55835164691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835164691),
//--TRIMMABLE-BOUNDARY-START(81604968467),
    {
      "r": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
      "n": "ReadEncodedValue",
      "d": 589843,
      "h": 81604968467,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604968467),
//--TRIMMABLE-BOUNDARY-START(21475426323),
    {
      "r": 589843,
      "n": "Clone",
      "d": 589843,
      "h": 21475426323,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426323),
//--TRIMMABLE-BOUNDARY-START(25770393619),
    {
      "r": 589843,
      "p": [
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "CloneAtSlice",
      "d": 589843,
      "h": 25770393619,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770393619),
//--TRIMMABLE-BOUNDARY-START(188979150867),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadOctetString",
      "d": 589843,
      "h": 188979150867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188979150867),
//--TRIMMABLE-BOUNDARY-START(133144576019),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadOctetString",
      "d": 589843,
      "h": 133144576019,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133144576019),
//--TRIMMABLE-BOUNDARY-START(201864052755),
    {
      "r": 262145,
      "p": [
        {
          "n": "contents",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadPrimitiveOctetString",
      "d": 589843,
      "h": 201864052755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201864052755),
//--TRIMMABLE-BOUNDARY-START(107374772243),
    {
      "r": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadIntegerBytes",
      "d": 589843,
      "h": 107374772243,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374772243),
//--TRIMMABLE-BOUNDARY-START(103079804947),
    {
      "r": 786438,
      "p": [
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadInteger",
      "d": 589843,
      "h": 103079804947,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079804947),
//--TRIMMABLE-BOUNDARY-START(180389216275),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadInt32",
      "d": 589843,
      "h": 180389216275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180389216275),
//--TRIMMABLE-BOUNDARY-START(206159020051),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadUInt32",
      "d": 589843,
      "h": 206159020051,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206159020051),
//--TRIMMABLE-BOUNDARY-START(184684183571),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 917505,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadInt64",
      "d": 589843,
      "h": 184684183571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684183571),
//--TRIMMABLE-BOUNDARY-START(210453987347),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 983041,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadUInt64",
      "d": 589843,
      "h": 210453987347,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210453987347),
//--TRIMMABLE-BOUNDARY-START(193274118163),
    {
      "r": 262145,
      "p": [
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "value",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadPrimitiveBitString",
      "d": 589843,
      "h": 193274118163,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193274118163),
//--TRIMMABLE-BOUNDARY-START(167504314387),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadBitString",
      "d": 589843,
      "h": 167504314387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167504314387),
//--TRIMMABLE-BOUNDARY-START(68720066579),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadBitString",
      "d": 589843,
      "h": 68720066579,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720066579),
//--TRIMMABLE-BOUNDARY-START(197569085459),
    {
      "r": 262145,
      "p": [
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "contents",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
          "f": 2
        }
      ],
      "n": "TryReadPrimitiveCharacterStringBytes",
      "d": 589843,
      "h": 197569085459,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197569085459),
//--TRIMMABLE-BOUNDARY-START(176094248979),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "expectedTag",
          "p": 65555
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadCharacterStringBytes",
      "d": 589843,
      "h": 176094248979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094248979),
//--TRIMMABLE-BOUNDARY-START(171799281683),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "encodingType",
          "p": 1572883
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "TryReadCharacterString",
      "d": 589843,
      "h": 171799281683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171799281683),
//--TRIMMABLE-BOUNDARY-START(77310001171),
    {
      "r": 1310721,
      "p": [
        {
          "n": "encodingType",
          "p": 1572883
        },
        {
          "n": "expectedTag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "ReadCharacterString",
      "d": 589843,
      "h": 77310001171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310001171)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540197395),
    {
      "t": 655361,
      "n": "MaxCERSegmentSize",
      "d": 589843,
      "h": 51540197395,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51540197395),
//--TRIMMABLE-BOUNDARY-START(4295557139),
    {
      "t": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
      "n": "_data",
      "d": 589843,
      "h": 4295557139,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557139),
//--TRIMMABLE-BOUNDARY-START(8590524435),
    {
      "t": 655379,
      "n": "_options",
      "d": 589843,
      "h": 8590524435,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524435)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180459027),
    {
      "p": [
        {
          "n": "data",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "options",
          "p": 655379,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589843,
      "h": 17180459027,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180459027)
  ],
  "h": 589843
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.AsnReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}AsnReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589843)
        
        

        //--TRIMMABLE-BOUNDARY-START(720915)
        $asm.$cls(`$sfa.SFA.AsnWriter`, ($self) => class AsnWriter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(214749085715)
            /*void */ WriteCharacterString$1(/*UniversalTagNumber*/ encodingType, /*string*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749085715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.WriteCharacterString(encodingType, $.$$.S.MemoryExtensions.AsSpan$4(value), $.$clone(tag));
            }
            //--TRIMMABLE-BOUNDARY-END(214749085715)
            
            //--TRIMMABLE-BOUNDARY-START(210454118419)
            /*void */ WriteCharacterString(/*UniversalTagNumber*/ encodingType, /*ReadOnlySpan<char>*/ str, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454118419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), encodingType);
                /*Text.Encoding*/ let encoding = $.$sfa.SFA.AsnCharacterStringEncodings.GetEncoding(encodingType);
                this.WriteCharacterStringCore(tag ?? new $.$sfa.SFA.Asn1Tag().$ctor$5(encodingType, false), encoding, str);
            }
            //--TRIMMABLE-BOUNDARY-END(210454118419)
            
            //--TRIMMABLE-BOUNDARY-START(219044053011)
            /*void */ WriteCharacterStringCore(/*Asn1Tag*/ tag, /*Text.Encoding*/ encoding, /*ReadOnlySpan<char>*/ str)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044053011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let size = encoding.GetByteCount$4(str);
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (size > 1000/*AsnReader.MaxCERSegmentSize*/)
                    {
                        this.WriteConstructedCerCharacterString(tag, encoding, str, size);
                        return;
                    }
                }
                this.WriteTag(tag.AsPrimitive());
                this.WriteLength(size);
                /*Span<byte>*/ let dest = $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, this._buffer, this._offset, size);
                /*int*/ let written = encoding.GetBytes$5(str, dest);
                if (written !== size)
                {
                    $.$$.SD.Debug.Fail$1(`Encoding produced different answer for GetByteCount (${$.$strNN(size)}) and GetBytes (${$.$strNN(written)})`);
                    throw new $.$$.S.InvalidOperationException().$ctor$9();
                }
                this._offset += size;
            }
            //--TRIMMABLE-BOUNDARY-END(219044053011)
            
            //--TRIMMABLE-BOUNDARY-START(227633987603)
            /*void */ WriteConstructedCerCharacterString(/*Asn1Tag*/ tag, /*Text.Encoding*/ encoding, /*ReadOnlySpan<char>*/ str, /*int*/ size)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633987603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(size > 1000/*AsnReader.MaxCERSegmentSize*/, "size > AsnReader.MaxCERSegmentSize");
                /*byte[]*/ let tmp = $.$sfa.SSC.CryptoPool.Rent(size);
                /*int*/ let written = encoding.GetBytes$5(str, $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(tmp));
                if (written !== size)
                {
                    $.$$.SD.Debug.Fail$1(`Encoding produced different answer for GetByteCount (${$.$strNN(size)}) and GetBytes (${$.$strNN(written)})`);
                    throw new $.$$.S.InvalidOperationException().$ctor$9();
                }
                this.WriteConstructedCerOctetString(tag, $.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, tmp, 0, size)));
                $.$sfa.SSC.CryptoPool.Return$1(tmp, size);
            }
            //--TRIMMABLE-BOUNDARY-END(227633987603)
            
            //--TRIMMABLE-BOUNDARY-START(313533333523)
            /*void */ WriteNamedBitList$1(/*Enum*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533333523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 3/*UniversalTagNumber.BitString*/);
                this.WriteNamedBitList$2($.$clone(tag), $.$$.S.Object.GetType.call(value), value);
            }
            //--TRIMMABLE-BOUNDARY-END(313533333523)
            
            //--TRIMMABLE-BOUNDARY-START(326418235411)
            /*void */ WriteNamedBitList$4(TEnum, /*TEnum*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418235411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 3/*UniversalTagNumber.BitString*/);
                this.WriteNamedBitList$2($.$clone(tag), TEnum.$type, value);
            }
            //--TRIMMABLE-BOUNDARY-END(326418235411)
            
            //--TRIMMABLE-BOUNDARY-START(309238366227)
            /*void */ WriteNamedBitList(/*BitArray*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238366227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 3/*UniversalTagNumber.BitString*/);
                this.WriteBitArray(value, $.$clone(tag));
            }
            //--TRIMMABLE-BOUNDARY-END(309238366227)
            
            //--TRIMMABLE-BOUNDARY-START(317828300819)
            /*void */ WriteNamedBitList$2(/*Asn1Tag?*/ tag, /*Type*/ tEnum, /*Enum*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828300819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let backingType = tEnum.GetEnumUnderlyingType();
                if (!tEnum.IsDefined($.$$.S.FlagsAttribute.$type, false))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_NamedBitListRequiresFlagsEnum, "tEnum");
                }
                /*ulong*/ let integralValue;
                if (backingType === $.$$.S.SByte.$type)
                {
                    integralValue = BigInt($.$cast($.$$.S.Convert.ToSByte$10(value), $.$$.S.Byte));
                }
                else if (backingType === $.$$.S.Int16.$type)
                {
                    integralValue = BigInt($.$cast($.$$.S.Convert.ToInt16$10(value), $.$$.S.UInt16));
                }
                else if (backingType === $.$$.S.Int32.$type)
                {
                    integralValue = BigInt(($.$$.S.Convert.ToInt32$10(value) >>> 0));
                }
                else if (backingType === $.$$.S.UInt64.$type)
                {
                    integralValue = $.$$.S.Convert.ToUInt64$10(value);
                }
                else 
                {
                    integralValue = $.$cast($.$$.S.Convert.ToInt64$10(value), $.$$.S.UInt64);
                }
                this.WriteNamedBitList$3($.$clone(tag), integralValue);
            }
            //--TRIMMABLE-BOUNDARY-END(317828300819)
            
            //--TRIMMABLE-BOUNDARY-START(322123268115)
            /*void */ WriteNamedBitList$3(/*Asn1Tag?*/ tag, /*ulong*/ integralValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123268115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Span<byte>*/ let temp = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Byte, 8, null);
                temp.Clear();
                /*int*/ let indexOfHighestSetBit = -1;
                for(/*int*/ let i = 0; integralValue !== 0n; integralValue >>= 1n, i++)
                {
                    if ((integralValue & 1n) !== 0n)
                    {
                        temp._reference.SetAt($.$cast((128 >> (i % 8)), $.$$.S.Byte), $.trunc(i / 8));
                        indexOfHighestSetBit = i;
                    }
                }
                if (indexOfHighestSetBit < 0)
                {
                    this.WriteBitString($.$$.S.ReadOnlySpan$$($.$$.S.Byte).Empty, 0, $.$clone(tag));
                }
                else 
                {
                    /*int*/ let byteLen = ((($.trunc(indexOfHighestSetBit / 8)) + 1) | 0);
                    /*int*/ let unusedBitCount = ((7 - (indexOfHighestSetBit % 8)) | 0);
                    this.WriteBitString($.$$.S.Span$$($.$$.S.Byte).op_Implicit(temp.Slice(0, byteLen)), unusedBitCount, $.$clone(tag));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(322123268115)
            
            //--TRIMMABLE-BOUNDARY-START(188979281939)
            /*void */ WriteBitArray(/*BitArray*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979281939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.Count === 0)
                {
                    this.WriteBitString($.$$.S.ReadOnlySpan$$($.$$.S.Byte).Empty, 0, $.$clone(tag));
                    return;
                }
                /*int*/ let requiredBytes = $.trunc(($.$checked(value.Count + 7, 1)) / 8);
                /*int*/ let unusedBits = ((((requiredBytes * 8) | 0) - value.Count) | 0);
                /*byte[]*/ let rented = $.$sfa.SSC.CryptoPool.Rent(requiredBytes);
                value.CopyTo(rented, 0);
                /*Span<byte>*/ let valueSpan = $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, rented, 0, requiredBytes);
                $.$sfa.SFA.AsnDecoder.ReverseBitsPerByte(valueSpan);
                this.WriteBitString($.$$.S.Span$$($.$$.S.Byte).op_Implicit(valueSpan), unusedBits, $.$clone(tag));
                $.$sfa.SSC.CryptoPool.Return$1(rented, requiredBytes);
            }
            //--TRIMMABLE-BOUNDARY-END(188979281939)
            
            //--TRIMMABLE-BOUNDARY-START(201864183827)
            /*void */ WriteBoolean(/*bool*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864183827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 1/*UniversalTagNumber.Boolean*/);
                this.WriteBooleanCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.Boolean, value);
            }
            //--TRIMMABLE-BOUNDARY-END(201864183827)
            
            //--TRIMMABLE-BOUNDARY-START(206159151123)
            /*void */ WriteBooleanCore(/*Asn1Tag*/ tag, /*bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159151123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(1);
                $.$$.SD.Debug.Assert$4(this._offset < this._buffer.length, "_offset < _buffer.Length");
                $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast((value ? 255 : 0), $.$$.S.Byte), this._offset);
                this._offset++;
            }
            //--TRIMMABLE-BOUNDARY-END(206159151123)
            
            //--TRIMMABLE-BOUNDARY-START(193274249235)
            /*void */ WriteBitString(/*ReadOnlySpan<byte>*/ value, /*int*/ unusedBitCount, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274249235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 3/*UniversalTagNumber.BitString*/);
                this.WriteBitStringCore(tag ?? $.$sfa.SFA.Asn1Tag.PrimitiveBitString, value, unusedBitCount);
            }
            //--TRIMMABLE-BOUNDARY-END(193274249235)
            
            //--TRIMMABLE-BOUNDARY-START(197569216531)
            /*void */ WriteBitStringCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ bitString, /*int*/ unusedBitCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569216531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (unusedBitCount < 0 || unusedBitCount > 7)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("unusedBitCount", $.$box(unusedBitCount, $.$$.S.Int32), $.$sfa.S.SR.Argument_UnusedBitCountRange);
                }
                if (bitString.Length === 0 && unusedBitCount !== 0)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_UnusedBitCountMustBeZero, "unusedBitCount");
                }
                /*byte*/ let lastByte = bitString.IsEmpty ? 0 : bitString._reference.GetAt(((bitString.Length - 1) | 0));
                if (!$.$sfa.SFA.AsnWriter.CheckValidLastByte(lastByte, unusedBitCount))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_UnusedBitWasSet, "unusedBitCount");
                }
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (bitString.Length >= 1000/*AsnReader.MaxCERSegmentSize*/)
                    {
                        this.WriteConstructedCerBitString(tag, bitString, unusedBitCount);
                        return;
                    }
                }
                this.WriteTag(tag.AsPrimitive());
                this.WriteLength(((bitString.Length + 1) | 0));
                $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(unusedBitCount, $.$$.S.Byte), this._offset);
                this._offset++;
                bitString.CopyTo($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset));
                this._offset += bitString.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(197569216531)
            
            //--TRIMMABLE-BOUNDARY-START(42950393875)
            static /*bool */ CheckValidLastByte(/*byte*/ lastByte, /*int*/ unusedBitCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let mask = (((1 << unusedBitCount) - 1) | 0);
                return ((lastByte & mask) === 0);
            }
            //--TRIMMABLE-BOUNDARY-END(42950393875)
            
            //--TRIMMABLE-BOUNDARY-START(51540328467)
            static /*int */ DetermineCerBitStringTotalLength(/*Asn1Tag*/ tag, /*int*/ contentLength)
            {
                /*int*/ let lastContentSize;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let MaxCERSegmentSize = 1000/*AsnReader.MaxCERSegmentSize*/;
                /*int*/ let MaxCERContentSize = ((MaxCERSegmentSize - 1) | 0);
                $.$$.SD.Debug.Assert$4(contentLength > MaxCERContentSize, "contentLength > MaxCERContentSize");
                /*int*/ let fullSegments = $.$$.S.Math.DivRem$2(contentLength, MaxCERContentSize, $.$ref(() => lastContentSize, ($v) => lastContentSize = $v, $.$$.S.Int32));
                /*int*/ let FullSegmentEncodedSize = 1004;
                $.$$.SD.Debug.Assert$4(FullSegmentEncodedSize === ((((((1 + 1) | 0) + MaxCERSegmentSize) | 0) + $.$sfa.SFA.AsnWriter.GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)) | 0), "FullSegmentEncodedSize == 1 + 1 + MaxCERSegmentSize + GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)");
                /*int*/ let remainingEncodedSize;
                if (lastContentSize === 0)
                {
                    remainingEncodedSize = 0;
                }
                else 
                {
                    remainingEncodedSize = ((((3 + lastContentSize) | 0) + $.$sfa.SFA.AsnWriter.GetEncodedLengthSubsequentByteCount(lastContentSize)) | 0);
                }
                return ((((((((fullSegments * FullSegmentEncodedSize) | 0) + remainingEncodedSize) | 0) + 3) | 0) + tag.CalculateEncodedSize()) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(51540328467)
            
            //--TRIMMABLE-BOUNDARY-START(223339020307)
            /*void */ WriteConstructedCerBitString(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ payload, /*int*/ unusedBitCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339020307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let MaxCERSegmentSize = 1000/*AsnReader.MaxCERSegmentSize*/;
                /*int*/ let MaxCERContentSize = ((MaxCERSegmentSize - 1) | 0);
                $.$$.SD.Debug.Assert$4(payload.Length > MaxCERContentSize, "payload.Length > MaxCERContentSize");
                /*int*/ let expectedSize = $.$sfa.SFA.AsnWriter.DetermineCerBitStringTotalLength(tag, payload.Length);
                this.EnsureWriteCapacity(expectedSize);
                /*int*/ let savedOffset = this._offset;
                this.WriteTag(tag.AsConstructed());
                this.WriteLength(-1);
                /*byte[]*/ let ensureNoExtraCopy = this._buffer;
                /*ReadOnlySpan<byte>*/ let remainingData = payload;
                /*Span<byte>*/ let dest;
                /*Asn1Tag*/ let primitiveBitString = $.$sfa.SFA.Asn1Tag.PrimitiveBitString;
                while(remainingData.Length > MaxCERContentSize)
                {
                    this.WriteTag(primitiveBitString);
                    this.WriteLength(MaxCERSegmentSize);
                    $.$$.System.Array.$WriteT1.call(this._buffer, 0, this._offset);
                    this._offset++;
                    dest = $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset);
                    remainingData.Slice(0, MaxCERContentSize).CopyTo(dest);
                    remainingData = remainingData.Slice$1(MaxCERContentSize);
                    this._offset += MaxCERContentSize;
                }
                this.WriteTag(primitiveBitString);
                this.WriteLength(((remainingData.Length + 1) | 0));
                $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(unusedBitCount, $.$$.S.Byte), this._offset);
                this._offset++;
                dest = $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset);
                remainingData.CopyTo(dest);
                this._offset += remainingData.Length;
                this.WriteEndOfContents();
                $.$$.SD.Debug.Assert$1(((this._offset - savedOffset) | 0) === expectedSize, `expected size was ${$.$strNN(expectedSize)}, actual was ${$.$strNN(((this._offset - savedOffset) | 0))}`);
                $.$$.SD.Debug.Assert$4(this._buffer === ensureNoExtraCopy, `_buffer was replaced during ${$.$strNN("WriteConstructedCerBitString")}`);
            }
            //--TRIMMABLE-BOUNDARY-END(223339020307)
            
            //--TRIMMABLE-BOUNDARY-START(335008170003)
            /*void */ WriteNull(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008170003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 5/*UniversalTagNumber.Null*/);
                this.WriteNullCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.Null);
            }
            //--TRIMMABLE-BOUNDARY-END(335008170003)
            
            //--TRIMMABLE-BOUNDARY-START(339303137299)
            /*void */ WriteNullCore(/*Asn1Tag*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303137299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(0);
            }
            //--TRIMMABLE-BOUNDARY-END(339303137299)
            
            //--TRIMMABLE-BOUNDARY-START(150324576275)
            /*Scope */ PushSequence(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324576275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 16/*UniversalTagNumber.Sequence*/);
                return this.PushSequenceCore((tag?.AsConstructed() ?? null) ?? $.$sfa.SFA.Asn1Tag.Sequence);
            }
            //--TRIMMABLE-BOUNDARY-END(150324576275)
            
            //--TRIMMABLE-BOUNDARY-START(124554772499)
            /*void */ PopSequence(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554772499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 16/*UniversalTagNumber.Sequence*/);
                this.PopSequenceCore((tag?.AsConstructed() ?? null) ?? $.$sfa.SFA.Asn1Tag.Sequence);
            }
            //--TRIMMABLE-BOUNDARY-END(124554772499)
            
            //--TRIMMABLE-BOUNDARY-START(154619543571)
            /*Scope */ PushSequenceCore(/*Asn1Tag*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619543571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(tag.IsConstructed, "tag.IsConstructed");
                return this.PushTag(tag, 16/*UniversalTagNumber.Sequence*/);
            }
            //--TRIMMABLE-BOUNDARY-END(154619543571)
            
            //--TRIMMABLE-BOUNDARY-START(128849739795)
            /*void */ PopSequenceCore(/*Asn1Tag*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849739795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(tag.IsConstructed, "tag.IsConstructed");
                this.PopTag(tag, 16/*UniversalTagNumber.Sequence*/, false);
            }
            //--TRIMMABLE-BOUNDARY-END(128849739795)
            
            //--TRIMMABLE-BOUNDARY-START(146029608979)
            /*Scope */ PushOctetString(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029608979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 4/*UniversalTagNumber.OctetString*/);
                return this.PushTag((tag?.AsConstructed() ?? null) ?? $.$sfa.SFA.Asn1Tag.ConstructedOctetString, 4/*UniversalTagNumber.OctetString*/);
            }
            //--TRIMMABLE-BOUNDARY-END(146029608979)
            
            //--TRIMMABLE-BOUNDARY-START(120259805203)
            /*void */ PopOctetString(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259805203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 4/*UniversalTagNumber.OctetString*/);
                this.PopTag((tag?.AsConstructed() ?? null) ?? $.$sfa.SFA.Asn1Tag.ConstructedOctetString, 4/*UniversalTagNumber.OctetString*/, false);
            }
            //--TRIMMABLE-BOUNDARY-END(120259805203)
            
            //--TRIMMABLE-BOUNDARY-START(356483006483)
            /*void */ WriteOctetString(/*ReadOnlySpan<byte>*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483006483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 4/*UniversalTagNumber.OctetString*/);
                this.WriteOctetStringCore(tag ?? $.$sfa.SFA.Asn1Tag.PrimitiveOctetString, value);
            }
            //--TRIMMABLE-BOUNDARY-END(356483006483)
            
            //--TRIMMABLE-BOUNDARY-START(360777973779)
            /*void */ WriteOctetStringCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ octetString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777973779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (octetString.Length > 1000/*AsnReader.MaxCERSegmentSize*/)
                    {
                        this.WriteConstructedCerOctetString(tag, octetString);
                        return;
                    }
                }
                this.WriteTag(tag.AsPrimitive());
                this.WriteLength(octetString.Length);
                octetString.CopyTo($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset));
                this._offset += octetString.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(360777973779)
            
            //--TRIMMABLE-BOUNDARY-START(231928954899)
            /*void */ WriteConstructedCerOctetString(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ payload)
            {
                /*int*/ let lastSegmentSize;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928954899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let MaxCERSegmentSize = 1000/*AsnReader.MaxCERSegmentSize*/;
                $.$$.SD.Debug.Assert$4(payload.Length > MaxCERSegmentSize, "payload.Length > MaxCERSegmentSize");
                this.WriteTag(tag.AsConstructed());
                this.WriteLength(-1);
                /*int*/ let fullSegments = $.$$.S.Math.DivRem$2(payload.Length, MaxCERSegmentSize, $.$ref(() => lastSegmentSize, ($v) => lastSegmentSize = $v, $.$$.S.Int32));
                /*int*/ let FullSegmentEncodedSize = 1004;
                $.$$.SD.Debug.Assert$4(FullSegmentEncodedSize === ((((((1 + 1) | 0) + MaxCERSegmentSize) | 0) + $.$sfa.SFA.AsnWriter.GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)) | 0), "FullSegmentEncodedSize == 1 + 1 + MaxCERSegmentSize + GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)");
                /*int*/ let remainingEncodedSize;
                if (lastSegmentSize === 0)
                {
                    remainingEncodedSize = 0;
                }
                else 
                {
                    remainingEncodedSize = ((((2 + lastSegmentSize) | 0) + $.$sfa.SFA.AsnWriter.GetEncodedLengthSubsequentByteCount(lastSegmentSize)) | 0);
                }
                /*int*/ let expectedSize = ((((((fullSegments * FullSegmentEncodedSize) | 0) + remainingEncodedSize) | 0) + 2) | 0);
                this.EnsureWriteCapacity(expectedSize);
                /*byte[]*/ let ensureNoExtraCopy = this._buffer;
                /*int*/ let savedOffset = this._offset;
                /*ReadOnlySpan<byte>*/ let remainingData = payload;
                /*Span<byte>*/ let dest;
                /*Asn1Tag*/ let primitiveOctetString = $.$sfa.SFA.Asn1Tag.PrimitiveOctetString;
                while(remainingData.Length > MaxCERSegmentSize)
                {
                    this.WriteTag(primitiveOctetString);
                    this.WriteLength(MaxCERSegmentSize);
                    dest = $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset);
                    remainingData.Slice(0, MaxCERSegmentSize).CopyTo(dest);
                    this._offset += MaxCERSegmentSize;
                    remainingData = remainingData.Slice$1(MaxCERSegmentSize);
                }
                this.WriteTag(primitiveOctetString);
                this.WriteLength(remainingData.Length);
                dest = $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset);
                remainingData.CopyTo(dest);
                this._offset += remainingData.Length;
                this.WriteEndOfContents();
                $.$$.SD.Debug.Assert$1(((this._offset - savedOffset) | 0) === expectedSize, `expected size was ${$.$strNN(expectedSize)}, actual was ${$.$strNN(((this._offset - savedOffset) | 0))}`);
                $.$$.SD.Debug.Assert$4(this._buffer === ensureNoExtraCopy, `_buffer was replaced during ${$.$strNN("WriteConstructedCerOctetString")}`);
            }
            //--TRIMMABLE-BOUNDARY-END(231928954899)
            
            //--TRIMMABLE-BOUNDARY-START(347893071891)
            /*void */ WriteObjectIdentifier$1(/*string*/ oidValue, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893071891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(oidValue, "oidValue");
                this.WriteObjectIdentifier($.$$.S.MemoryExtensions.AsSpan$4(oidValue), $.$clone(tag));
            }
            //--TRIMMABLE-BOUNDARY-END(347893071891)
            
            //--TRIMMABLE-BOUNDARY-START(343598104595)
            /*void */ WriteObjectIdentifier(/*ReadOnlySpan<char>*/ oidValue, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343598104595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 6/*UniversalTagNumber.ObjectIdentifier*/);
                /*ReadOnlySpan<byte>*/ let wellKnownContents = $.$sfa.SFA.WellKnownOids.GetContents(oidValue);
                if (!wellKnownContents.IsEmpty)
                {
                    this.WriteTag((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.ObjectIdentifier);
                    this.WriteLength(wellKnownContents.Length);
                    wellKnownContents.CopyTo($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset));
                    this._offset += wellKnownContents.Length;
                    return;
                }
                this.WriteObjectIdentifierCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.ObjectIdentifier, oidValue);
            }
            //--TRIMMABLE-BOUNDARY-END(343598104595)
            
            //--TRIMMABLE-BOUNDARY-START(352188039187)
            /*void */ WriteObjectIdentifierCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<char>*/ oidValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188039187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (oidValue.Length < 3)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_InvalidOidValue, "oidValue");
                }
                if (oidValue._reference.GetAt(1) !== /*.*/ 46)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_InvalidOidValue, "oidValue");
                }
                /*byte[]*/ let tmp = $.$sfa.SSC.CryptoPool.Rent($.trunc(oidValue.Length / 2));
                /*int*/ let tmpOffset = 0;
                try
                {
                    /*int*/ let firstComponent = (() =>
                    {
                        let $switch3 = oidValue.get_Item(0).$v;
                        if ($switch3 === /*0*/ 48)
                        {
                            return 0;
                        }
                        if ($switch3 === /*1*/ 49)
                        {
                            return 1;
                        }
                        if ($switch3 === /*2*/ 50)
                        {
                            return 2;
                        }
                        throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_InvalidOidValue, "oidValue");
                    })();
                    /*ReadOnlySpan<char>*/ let remaining = oidValue.Slice$1(2);
                    /*BigInteger*/ let subIdentifier = $.$sfa.SFA.AsnWriter.ParseSubIdentifier($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Char), () => remaining, ($v) => remaining = $v, null, true));
                    if (firstComponent <= 1 && $.$srn.SN.BigInteger.op_GreaterThanOrEqual$2(subIdentifier, 40n))
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_InvalidOidValue, "oidValue");
                    }
                    subIdentifier = $.$srn.SN.BigInteger.op_Addition(subIdentifier, $.$srn.SN.BigInteger.op_Implicit$4(((40 * firstComponent) | 0)));
                    /*int*/ let localLen = $.$sfa.SFA.AsnWriter.EncodeSubIdentifier($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, tmp, tmpOffset), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$srn.SN.BigInteger, () => subIdentifier, ($v) => subIdentifier = $v, null, true));
                    tmpOffset += localLen;
                    while(!remaining.IsEmpty)
                    {
                        subIdentifier = $.$sfa.SFA.AsnWriter.ParseSubIdentifier($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.ReadOnlySpan$$($.$$.S.Char), () => remaining, ($v) => remaining = $v, null, true));
                        localLen = $.$sfa.SFA.AsnWriter.EncodeSubIdentifier($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, tmp, tmpOffset), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$srn.SN.BigInteger, () => subIdentifier, ($v) => subIdentifier = $v, null, true));
                        tmpOffset += localLen;
                    }
                    $.$$.SD.Debug.Assert$4(!tag.IsConstructed, "!tag.IsConstructed");
                    this.WriteTag(tag);
                    this.WriteLength(tmpOffset);
                    $.$$.S.Buffer.BlockCopy(tmp, 0, this._buffer, this._offset, tmpOffset);
                    this._offset += tmpOffset;
                }
                finally
                {
                    {
                        $.$sfa.SSC.CryptoPool.Return$1(tmp, tmpOffset);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(352188039187)
            
            //--TRIMMABLE-BOUNDARY-START(115964837907)
            static /*BigInteger */ ParseSubIdentifier(/*ref ReadOnlySpan<char>*/ oidValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964837907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let endIndex = $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, oidValue.$v, /*.*/ 46);
                if (endIndex === -1)
                {
                    endIndex = oidValue.$v.Length;
                }
                else if (endIndex === 0 || endIndex === ((oidValue.$v.Length - 1) | 0))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_InvalidOidValue, "oidValue");
                }
                /*BigInteger*/ let value = $.$srn.SN.BigInteger.Zero;
                for(/*int*/ let position = 0; position < endIndex; position++)
                {
                    if (position > 0 && $.$srn.SN.BigInteger.op_Equality$2(value, 0n))
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_InvalidOidValue, "oidValue");
                    }
                    value = $.$srn.SN.BigInteger.op_Multiply(value, $.$srn.SN.BigInteger.op_Implicit$4(10));
                    value = $.$srn.SN.BigInteger.op_Addition(value, $.$srn.SN.BigInteger.op_Implicit$4($.$sfa.SFA.AsnWriter.AtoI(oidValue.$v._reference.GetAt(position))));
                }
                oidValue.$v = oidValue.$v.Slice$1($.$$.S.Math.Min$4(oidValue.$v.Length, ((endIndex + 1) | 0)));
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(115964837907)
            
            //--TRIMMABLE-BOUNDARY-START(34360459283)
            static /*int */ AtoI(/*char*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360459283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (c >= /*0*/ 48 && c <= /*9*/ 57)
                {
                    return c - /*0*/ 48;
                }
                throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_InvalidOidValue, "oidValue");
            }
            //--TRIMMABLE-BOUNDARY-END(34360459283)
            
            //--TRIMMABLE-BOUNDARY-START(90195034131)
            static /*int */ EncodeSubIdentifier(/*Span<byte>*/ dest, /*ref BigInteger*/ subIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(dest.Length > 0, "dest.Length > 0");
                if (subIdentifier.$v.IsZero)
                {
                    dest._reference.SetAt(0, 0);
                    return 1;
                }
                /*BigInteger*/ let unencoded = subIdentifier.$v;
                /*int*/ let idx = 0;
                do
                {
                    /*BigInteger*/ let cur = $.$srn.SN.BigInteger.op_BitwiseAnd(unencoded, $.$srn.SN.BigInteger.op_Implicit$4(127));
                    /*byte*/ let curByte = $.$srn.SN.BigInteger.op_Explicit(cur);
                    if ($.$srn.SN.BigInteger.op_Inequality$4(subIdentifier.$v, unencoded))
                    {
                        curByte |= 128;
                    }
                    unencoded = $.$srn.SN.BigInteger.op_RightShift(unencoded, 7);
                    dest._reference.SetAt(curByte, idx);
                    idx++;
                }
                while($.$srn.SN.BigInteger.op_Inequality$4(unencoded, $.$srn.SN.BigInteger.Zero));
                $.$$.S.MemoryExtensions.Reverse($.$$.S.Byte, dest.Slice(0, idx));
                return idx;
            }
            //--TRIMMABLE-BOUNDARY-END(90195034131)
            
            //--TRIMMABLE-BOUNDARY-START(373662875667)
            /*void */ WriteUtcTime$1(/*DateTimeOffset*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662875667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 23/*UniversalTagNumber.UtcTime*/);
                this.WriteUtcTimeCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.UtcTime, value);
            }
            //--TRIMMABLE-BOUNDARY-END(373662875667)
            
            //--TRIMMABLE-BOUNDARY-START(369367908371)
            /*void */ WriteUtcTime(/*DateTimeOffset*/ value, /*int*/ twoDigitYearMax, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367908371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 23/*UniversalTagNumber.UtcTime*/);
                value = value.ToUniversalTime();
                if (value.Year > twoDigitYearMax || value.Year <= ((twoDigitYearMax - 100) | 0))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("value");
                }
                this.WriteUtcTimeCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.UtcTime, value);
            }
            //--TRIMMABLE-BOUNDARY-END(369367908371)
            
            //--TRIMMABLE-BOUNDARY-START(377957842963)
            /*void */ WriteUtcTimeCore(/*Asn1Tag*/ tag, /*DateTimeOffset*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957842963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                /*int*/ let UtcTimeValueLength = 13;
                this.WriteLength(UtcTimeValueLength);
                /*DateTimeOffset*/ let normalized = value.ToUniversalTime();
                /*int*/ let year = normalized.Year;
                /*int*/ let month = normalized.Month;
                /*int*/ let day = normalized.Day;
                /*int*/ let hour = normalized.Hour;
                /*int*/ let minute = normalized.Minute;
                /*int*/ let second = normalized.Second;
                /*Span<byte>*/ let baseSpan = $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset);
                /*StandardFormat*/ let format = new $.$$.SB.StandardFormat().$ctor$3(/*D*/ 68, 2);
                if (!$.$$.SBT.Utf8Formatter.TryFormat$9(year % 100, baseSpan.Slice(0, 2), $.$discardRef(), format) || !$.$$.SBT.Utf8Formatter.TryFormat$9(month, baseSpan.Slice(2, 2), $.$discardRef(), format) || !$.$$.SBT.Utf8Formatter.TryFormat$9(day, baseSpan.Slice(4, 2), $.$discardRef(), format) || !$.$$.SBT.Utf8Formatter.TryFormat$9(hour, baseSpan.Slice(6, 2), $.$discardRef(), format) || !$.$$.SBT.Utf8Formatter.TryFormat$9(minute, baseSpan.Slice(8, 2), $.$discardRef(), format) || !$.$$.SBT.Utf8Formatter.TryFormat$9(second, baseSpan.Slice(10, 2), $.$discardRef(), format))
                {
                    $.$$.SD.Debug.Fail$1((() =>
                    {
                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendLiteral("Utf8Formatter.TryFormat failed to build components of ");
                        $handler.AppendFormatted($.$box(normalized, $.$$.S.DateTimeOffset), null, "O");
                        return $handler.ToStringAndClear                ();
                    })());
                    throw new $.$$.S.InvalidOperationException().$ctor$9();
                }
                $.$$.System.Array.$WriteT1.call(this._buffer, /*Z*/ 90, ((this._offset + 12) | 0));
                this._offset += UtcTimeValueLength;
            }
            //--TRIMMABLE-BOUNDARY-END(377957842963)
            
            //--TRIMMABLE-BOUNDARY-START(158914510867)
            /*Scope */ PushSetOf(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914510867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 17/*UniversalTagNumber.SetOf*/);
                return this.PushSetOfCore((tag?.AsConstructed() ?? null) ?? $.$sfa.SFA.Asn1Tag.SetOf);
            }
            //--TRIMMABLE-BOUNDARY-END(158914510867)
            
            //--TRIMMABLE-BOUNDARY-START(133144707091)
            /*void */ PopSetOf(/*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144707091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 17/*UniversalTagNumber.SetOf*/);
                this.PopSetOfCore((tag?.AsConstructed() ?? null) ?? $.$sfa.SFA.Asn1Tag.SetOf);
            }
            //--TRIMMABLE-BOUNDARY-END(133144707091)
            
            //--TRIMMABLE-BOUNDARY-START(163209478163)
            /*Scope */ PushSetOfCore(/*Asn1Tag*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209478163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(tag.IsConstructed, "tag.IsConstructed");
                return this.PushTag(tag, 17/*UniversalTagNumber.SetOf*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163209478163)
            
            //--TRIMMABLE-BOUNDARY-START(137439674387)
            /*void */ PopSetOfCore(/*Asn1Tag*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439674387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(tag.IsConstructed, "tag.IsConstructed");
                /*bool*/ let sortContents = this.RuleSet === 1/*AsnEncodingRules.CER*/ || this.RuleSet === 2/*AsnEncodingRules.DER*/;
                this.PopTag(tag, 17/*UniversalTagNumber.SetOf*/, sortContents);
            }
            //--TRIMMABLE-BOUNDARY-END(137439674387)
            
            //--TRIMMABLE-BOUNDARY-START(257698758675)
            /*void */ WriteGeneralizedTime(/*DateTimeOffset*/ value, /*bool*/ omitFractionalSeconds, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698758675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 24/*UniversalTagNumber.GeneralizedTime*/);
                this.WriteGeneralizedTimeCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.GeneralizedTime, value, omitFractionalSeconds);
            }
            //--TRIMMABLE-BOUNDARY-END(257698758675)
            
            //--TRIMMABLE-BOUNDARY-START(261993725971)
            /*void */ WriteGeneralizedTimeCore(/*Asn1Tag*/ tag, /*DateTimeOffset*/ value, /*bool*/ omitFractionalSeconds)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993725971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*DateTimeOffset*/ let normalized = value.ToUniversalTime();
                $.$$.SD.Debug.Assert$4(normalized.Year <= 9999, "DateTimeOffset guards against this internally");
                /*scoped Span<byte>*/ let fraction = new ($.$$.S.Span$$($.$$.S.Byte))();
                if (!omitFractionalSeconds)
                {
                    /*long*/ let floatingTicks = normalized.Ticks % 10000000n;
                    if (floatingTicks !== 0n)
                    {
                        /*int*/ let bytesWritten;
                        fraction = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Byte, 9, null);
                        /*decimal*/ let decimalTicks = $.$$.S.Decimal.op_Implicit$4(floatingTicks);
                        decimalTicks = $.$$.S.Decimal.op_Division(decimalTicks, $.$$.S.Decimal.op_Implicit$4(10000000n));
                        if (!$.$$.SBT.Utf8Formatter.TryFormat$4(decimalTicks, fraction, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.S.Int32), new $.$$.SB.StandardFormat().$ctor$3(/*G*/ 71, 255)))
                        {
                            $.$$.SD.Debug.Fail$1(`Utf8Formatter.TryFormat could not format ${$.$strNN(floatingTicks)} / TicksPerSecond`);
                            throw new $.$$.S.InvalidOperationException().$ctor$9();
                        }
                        $.$$.SD.Debug.Assert$1(bytesWritten > 2, `${$.$strNN(bytesWritten)} should be > 2`);
                        $.$$.SD.Debug.Assert$4(fraction._reference.GetAt(0) === /*0*/ 48, "fraction[0] == (byte)'0'");
                        $.$$.SD.Debug.Assert$4(fraction._reference.GetAt(1) === /*.*/ 46, "fraction[1] == (byte)'.'");
                        fraction = fraction.Slice(1, ((bytesWritten - 1) | 0));
                    }
                }
                /*int*/ let IntegerPortionLength = ((((((((((4 + 2) | 0) + 2) | 0) + 2) | 0) + 2) | 0) + 2) | 0);
                /*int*/ let totalLength = ((((IntegerPortionLength + 1) | 0) + fraction.Length) | 0);
                $.$$.SD.Debug.Assert$4(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(totalLength);
                /*int*/ let year = normalized.Year;
                /*int*/ let month = normalized.Month;
                /*int*/ let day = normalized.Day;
                /*int*/ let hour = normalized.Hour;
                /*int*/ let minute = normalized.Minute;
                /*int*/ let second = normalized.Second;
                /*Span<byte>*/ let baseSpan = $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset);
                /*StandardFormat*/ let d4 = new $.$$.SB.StandardFormat().$ctor$3(/*D*/ 68, 4);
                /*StandardFormat*/ let d2 = new $.$$.SB.StandardFormat().$ctor$3(/*D*/ 68, 2);
                if (!$.$$.SBT.Utf8Formatter.TryFormat$9(year, baseSpan.Slice(0, 4), $.$discardRef(), d4) || !$.$$.SBT.Utf8Formatter.TryFormat$9(month, baseSpan.Slice(4, 2), $.$discardRef(), d2) || !$.$$.SBT.Utf8Formatter.TryFormat$9(day, baseSpan.Slice(6, 2), $.$discardRef(), d2) || !$.$$.SBT.Utf8Formatter.TryFormat$9(hour, baseSpan.Slice(8, 2), $.$discardRef(), d2) || !$.$$.SBT.Utf8Formatter.TryFormat$9(minute, baseSpan.Slice(10, 2), $.$discardRef(), d2) || !$.$$.SBT.Utf8Formatter.TryFormat$9(second, baseSpan.Slice(12, 2), $.$discardRef(), d2))
                {
                    $.$$.SD.Debug.Fail$1((() =>
                    {
                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendLiteral("Utf8Formatter.TryFormat failed to build components of ");
                        $handler.AppendFormatted($.$box(normalized, $.$$.S.DateTimeOffset), null, "O");
                        return $handler.ToStringAndClear                ();
                    })());
                    throw new $.$$.S.InvalidOperationException().$ctor$9();
                }
                this._offset += IntegerPortionLength;
                fraction.CopyTo(baseSpan.Slice$1(IntegerPortionLength));
                this._offset += fraction.Length;
                $.$$.System.Array.$WriteT1.call(this._buffer, /*Z*/ 90, this._offset);
                this._offset++;
            }
            //--TRIMMABLE-BOUNDARY-END(261993725971)
            
            //--TRIMMABLE-BOUNDARY-START(244813856787)
            /*void */ WriteEnumeratedValue(/*Enum*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813856787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.WriteEnumeratedValue$1((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.Enumerated, $.$$.S.Object.GetType.call(value), value);
            }
            //--TRIMMABLE-BOUNDARY-END(244813856787)
            
            //--TRIMMABLE-BOUNDARY-START(253403791379)
            /*void */ WriteEnumeratedValue$2(TEnum, /*TEnum*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403791379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteEnumeratedValue$1((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.Enumerated, TEnum.$type, $.$box(value, TEnum));
            }
            //--TRIMMABLE-BOUNDARY-END(253403791379)
            
            //--TRIMMABLE-BOUNDARY-START(249108824083)
            /*void */ WriteEnumeratedValue$1(/*Asn1Tag*/ tag, /*Type*/ tEnum, /*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108824083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag(tag, 10/*UniversalTagNumber.Enumerated*/);
                /*Type*/ let backingType = tEnum.GetEnumUnderlyingType();
                if (tEnum.IsDefined($.$$.S.FlagsAttribute.$type, false))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_EnumeratedValueRequiresNonFlagsEnum, "tEnum");
                }
                if (backingType === $.$$.S.UInt64.$type)
                {
                    /*ulong*/ let numericValue = $.$$.S.Convert.ToUInt64$10(value);
                    this.WriteNonNegativeIntegerCore(tag, numericValue);
                }
                else 
                {
                    /*long*/ let numericValue = $.$$.S.Convert.ToInt64$10(value);
                    this.WriteIntegerCore(tag, numericValue);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249108824083)
            
            //--TRIMMABLE-BOUNDARY-START(266288693267)
            /*void */ WriteInteger(/*long*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288693267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.Integer, value);
            }
            //--TRIMMABLE-BOUNDARY-END(266288693267)
            
            //--TRIMMABLE-BOUNDARY-START(279173595155)
            /*void */ WriteInteger$3(/*ulong*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173595155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 2/*UniversalTagNumber.Integer*/);
                this.WriteNonNegativeIntegerCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.Integer, value);
            }
            //--TRIMMABLE-BOUNDARY-END(279173595155)
            
            //--TRIMMABLE-BOUNDARY-START(270583660563)
            /*void */ WriteInteger$1(/*BigInteger*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583660563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerCore$1((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.Integer, value);
            }
            //--TRIMMABLE-BOUNDARY-END(270583660563)
            
            //--TRIMMABLE-BOUNDARY-START(274878627859)
            /*void */ WriteInteger$2(/*ReadOnlySpan<byte>*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878627859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerCore$2((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.Integer, value);
            }
            //--TRIMMABLE-BOUNDARY-END(274878627859)
            
            //--TRIMMABLE-BOUNDARY-START(296353464339)
            /*void */ WriteIntegerUnsigned(/*ReadOnlySpan<byte>*/ value, /*Asn1Tag?*/ tag)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353464339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.SFA.AsnWriter.CheckUniversalTag($.$clone(tag), 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerUnsignedCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.SFA.Asn1Tag.Integer, value);
            }
            //--TRIMMABLE-BOUNDARY-END(296353464339)
            
            //--TRIMMABLE-BOUNDARY-START(283468562451)
            /*void */ WriteIntegerCore(/*Asn1Tag*/ tag, /*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468562451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value >= 0n)
                {
                    this.WriteNonNegativeIntegerCore(tag, $.$cast(value, $.$$.S.UInt64));
                    return;
                }
                /*int*/ let valueLength;
                if (value >= BigInt(-128/*sbyte.MinValue*/))
                {
                    valueLength = 1;
                }
                else if (value >= BigInt(-32768/*short.MinValue*/))
                {
                    valueLength = 2;
                }
                else if (value >= $.$cast(18446744073701163008n, $.$$.S.Int64))
                {
                    valueLength = 3;
                }
                else if (value >= BigInt(-2147483648/*int.MinValue*/))
                {
                    valueLength = 4;
                }
                else if (value >= $.$cast(18446743523953737728n, $.$$.S.Int64))
                {
                    valueLength = 5;
                }
                else if (value >= $.$cast(18446603336221196288n, $.$$.S.Int64))
                {
                    valueLength = 6;
                }
                else if (value >= $.$cast(18410715276690587648n, $.$$.S.Int64))
                {
                    valueLength = 7;
                }
                else 
                {
                    valueLength = 8;
                }
                $.$$.SD.Debug.Assert$4(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(valueLength);
                /*long*/ let remaining = value;
                /*int*/ let idx = ((((this._offset + valueLength) | 0) - 1) | 0);
                do
                {
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(remaining, $.$$.S.Byte), idx);
                    remaining >>= 8n;
                    idx--;
                }
                while(idx >= this._offset);
                if (valueLength > 1)
                {
                    $.$$.SD.Debug.Assert$4($.$$.System.Array.$ReadT1.call(this._buffer, this._offset) !== 255 || $.$$.System.Array.$ReadT1.call(this._buffer, ((this._offset + 1) | 0)) < 128, "_buffer[_offset] != 0xFF || _buffer[_offset + 1] < 0x80");
                }
                this._offset += valueLength;
            }
            //--TRIMMABLE-BOUNDARY-END(283468562451)
            
            //--TRIMMABLE-BOUNDARY-START(330713202707)
            /*void */ WriteNonNegativeIntegerCore(/*Asn1Tag*/ tag, /*ulong*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713202707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let valueLength;
                if (value < 128n)
                {
                    valueLength = 1;
                }
                else if (value < 32768n)
                {
                    valueLength = 2;
                }
                else if (value < 8388608n)
                {
                    valueLength = 3;
                }
                else if (value < 2147483648n)
                {
                    valueLength = 4;
                }
                else if (value < 549755813888n)
                {
                    valueLength = 5;
                }
                else if (value < 140737488355328n)
                {
                    valueLength = 6;
                }
                else if (value < 36028797018963968n)
                {
                    valueLength = 7;
                }
                else if (value < 9223372036854775808n)
                {
                    valueLength = 8;
                }
                else 
                {
                    valueLength = 9;
                }
                $.$$.SD.Debug.Assert$4(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(valueLength);
                /*ulong*/ let remaining = value;
                /*int*/ let idx = ((((this._offset + valueLength) | 0) - 1) | 0);
                do
                {
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(remaining, $.$$.S.Byte), idx);
                    remaining >>= 8n;
                    idx--;
                }
                while(idx >= this._offset);
                if (valueLength > 1)
                {
                    $.$$.SD.Debug.Assert$4($.$$.System.Array.$ReadT1.call(this._buffer, this._offset) !== 0 || $.$$.System.Array.$ReadT1.call(this._buffer, ((this._offset + 1) | 0)) > 127, "_buffer[_offset] != 0 || _buffer[_offset + 1] > 0x7F");
                }
                this._offset += valueLength;
            }
            //--TRIMMABLE-BOUNDARY-END(330713202707)
            
            //--TRIMMABLE-BOUNDARY-START(300648431635)
            /*void */ WriteIntegerUnsignedCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648431635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.IsEmpty)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_IntegerCannotBeEmpty, "value");
                }
                if (value.Length > 1 && value._reference.GetAt(0) === 0 && value._reference.GetAt(1) < 128)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_IntegerRedundantByte, "value");
                }
                $.$$.SD.Debug.Assert$4(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                if (value._reference.GetAt(0) >= 128)
                {
                    this.WriteLength($.$checked(value.Length + 1, 1));
                    $.$$.System.Array.$WriteT1.call(this._buffer, 0, this._offset);
                    this._offset++;
                }
                else 
                {
                    this.WriteLength(value.Length);
                }
                value.CopyTo($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset));
                this._offset += value.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(300648431635)
            
            //--TRIMMABLE-BOUNDARY-START(292058497043)
            /*void */ WriteIntegerCore$2(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ value)
            {
                /*ushort*/ let bigEndianValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058497043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.IsEmpty)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_IntegerCannotBeEmpty, "value");
                }
                if ($.$$.SBB.BinaryPrimitives.TryReadUInt16BigEndian(value, $.$ref(() => bigEndianValue, ($v) => bigEndianValue = $v, $.$$.S.UInt16)))
                {
                    /*ushort*/ let RedundancyMask = 65408;
                    /*ushort*/ let masked = $.$cast((bigEndianValue & RedundancyMask), $.$$.S.UInt16);
                    if (masked === 0 || masked === RedundancyMask)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_IntegerRedundantByte, "value");
                    }
                }
                $.$$.SD.Debug.Assert$4(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(value.Length);
                value.CopyTo($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset));
                this._offset += value.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(292058497043)
            
            //--TRIMMABLE-BOUNDARY-START(287763529747)
            /*void */ WriteIntegerCore$1(/*Asn1Tag*/ tag, /*BigInteger*/ value)
            {
                /*int*/ let bytesWritten;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763529747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(value.GetByteCount(false));
                value.TryWriteBytes($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.S.Int32), false, true);
                this._offset += bytesWritten;
            }
            //--TRIMMABLE-BOUNDARY-END(287763529747)
            
            //--TRIMMABLE-BOUNDARY-START(4295688211)
            /*byte[]*/ _buffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295688211)
            
            //--TRIMMABLE-BOUNDARY-START(17180590099)
            /*int*/ _offset = 0;
            //--TRIMMABLE-BOUNDARY-END(17180590099)
            
            //--TRIMMABLE-BOUNDARY-START(12885622803)
            /*Stack<StackFrame>?*/ _nestingStack = null;
            //--TRIMMABLE-BOUNDARY-END(12885622803)
            
            //--TRIMMABLE-BOUNDARY-START(8590655507)
            /*int*/ _encodeDepth = 0;
            //--TRIMMABLE-BOUNDARY-END(8590655507)
            
            //--TRIMMABLE-BOUNDARY-START(176094380051)
            /*AsnEncodingRules*/ RuleSet = 0;
            //--TRIMMABLE-BOUNDARY-END(176094380051)
            
            //--TRIMMABLE-BOUNDARY-START(30065491987)
            $ctor$2(/*AsnEncodingRules*/ ruleSet)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065491987);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (ruleSet !== 0/*AsnEncodingRules.BER*/ && ruleSet !== 1/*AsnEncodingRules.CER*/ && ruleSet !== 2/*AsnEncodingRules.DER*/)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("ruleSet");
                    }
                    this.RuleSet = ruleSet;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065491987)
            
            //--TRIMMABLE-BOUNDARY-START(25770524691)
            $ctor$1(/*AsnEncodingRules*/ ruleSet, /*int*/ initialCapacity)
            {
                this.$ctor$2(ruleSet);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770524691);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (initialCapacity < 0)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("initialCapacity", $.$sfa.S.SR.ArgumentOutOfRange_NeedNonNegNum);
                    }
                    if (initialCapacity > 0)
                    {
                        this._buffer = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [initialCapacity], null);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770524691)
            
            //--TRIMMABLE-BOUNDARY-START(171799412755)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799412755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._encodeDepth !== 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$sfa.S.SR.AsnWriter_ModifyingWhileEncoding);
                }
                if (this._offset > 0)
                {
                    $.$$.SD.Debug.Assert$4(this._buffer !== null, "_buffer != null");
                    $.$$.S.Array.Clear(this._buffer, 0, this._offset);
                    this._offset = 0;
                    this._nestingStack?.Clear();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171799412755)
            
            //--TRIMMABLE-BOUNDARY-START(107374903315)
            /*int */ GetEncodedLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374903315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$sfa.S.SR.AsnWriter_EncodeUnbalancedStack);
                }
                return this._offset;
            }
            //--TRIMMABLE-BOUNDARY-END(107374903315)
            
            //--TRIMMABLE-BOUNDARY-START(184684314643)
            /*bool */ TryEncode(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684314643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$sfa.S.SR.AsnWriter_EncodeUnbalancedStack);
                }
                if (destination.Length < this._offset)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                if (this._offset === 0)
                {
                    bytesWritten.$v = 0;
                    return true;
                }
                bytesWritten.$v = this._offset;
                $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, this._buffer, 0, this._offset).CopyTo(destination);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(184684314643)
            
            //--TRIMMABLE-BOUNDARY-START(60130263059)
            /*int */ Encode$1(/*Span<byte>*/ destination)
            {
                /*int*/ let bytesWritten;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.TryEncode(destination, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.S.Int32)))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_DestinationTooShort, "destination");
                }
                $.$$.SD.Debug.Assert$4(bytesWritten === this._offset, "bytesWritten == _offset");
                return bytesWritten;
            }
            //--TRIMMABLE-BOUNDARY-END(60130263059)
            
            //--TRIMMABLE-BOUNDARY-START(55835295763)
            /*byte[] */ Encode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$sfa.S.SR.AsnWriter_EncodeUnbalancedStack);
                }
                if (this._offset === 0)
                {
                    return $.$$.S.Array.Empty($.$$.S.Byte);
                }
                return $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, this._buffer, 0, this._offset).ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(55835295763)
            
            //--TRIMMABLE-BOUNDARY-START(64425230355)
            /*TReturn */ Encode$2(TReturn, /*Func<ReadOnlySpan<byte>, TReturn>*/ encodeCallback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(encodeCallback, "encodeCallback");
                this._encodeDepth = $.$checked(this._encodeDepth + 1, 1);
                try
                {
                    /*ReadOnlySpan<byte>*/ let encoded = this.EncodeAsSpan();
                    return encodeCallback.Invoke(encoded);
                }
                finally
                {
                    {
                        this._encodeDepth--;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425230355)
            
            //--TRIMMABLE-BOUNDARY-START(68720197651)
            /*TReturn */ Encode$3(TState, TReturn, /*TState*/ state, /*Func<TState, ReadOnlySpan<byte>, TReturn>*/ encodeCallback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(encodeCallback, "encodeCallback");
                this._encodeDepth = $.$checked(this._encodeDepth + 1, 1);
                try
                {
                    /*ReadOnlySpan<byte>*/ let encoded = this.EncodeAsSpan();
                    return encodeCallback.Invoke(state, encoded);
                }
                finally
                {
                    {
                        this._encodeDepth--;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720197651)
            
            //--TRIMMABLE-BOUNDARY-START(73015164947)
            /*void */ Encode$4(TState, /*TState*/ state, /*Action<TState, ReadOnlySpan<byte>>*/ encodeCallback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015164947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(encodeCallback, "encodeCallback");
                this._encodeDepth = $.$checked(this._encodeDepth + 1, 1);
                try
                {
                    /*ReadOnlySpan<byte>*/ let encoded = this.EncodeAsSpan();
                    encodeCallback.Invoke(state, encoded);
                }
                finally
                {
                    {
                        this._encodeDepth--;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015164947)
            
            //--TRIMMABLE-BOUNDARY-START(77310132243)
            /*ReadOnlySpan<byte> */ EncodeAsSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310132243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$sfa.S.SR.AsnWriter_EncodeUnbalancedStack);
                }
                if (this._offset === 0)
                {
                    return $.$$.S.ReadOnlySpan$$($.$$.S.Byte).Empty;
                }
                return new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$6(this._buffer, 0, this._offset);
            }
            //--TRIMMABLE-BOUNDARY-END(77310132243)
            
            //--TRIMMABLE-BOUNDARY-START(81605099539)
            /*bool */ EncodedValueEquals(/*ReadOnlySpan<byte>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.MemoryExtensions.SequenceEqual$1($.$$.S.Byte, this.EncodeAsSpan(), other);
            }
            //--TRIMMABLE-BOUNDARY-END(81605099539)
            
            //--TRIMMABLE-BOUNDARY-START(85900066835)
            /*bool */ EncodedValueEquals$1(/*AsnWriter*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900066835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(other, "other");
                return $.$$.S.MemoryExtensions.SequenceEqual$1($.$$.S.Byte, this.EncodeAsSpan(), other.EncodeAsSpan());
            }
            //--TRIMMABLE-BOUNDARY-END(85900066835)
            
            //--TRIMMABLE-BOUNDARY-START(94490001427)
            /*void */ EnsureWriteCapacity(/*int*/ pendingCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490001427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (pendingCount < 0)
                {
                    throw new $.$$.S.OverflowException().$ctor$13();
                }
                if (this._encodeDepth !== 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$sfa.S.SR.AsnWriter_ModifyingWhileEncoding);
                }
                if (this._buffer === null || ((this._buffer.length - this._offset) | 0) < pendingCount)
                {
                    /*int*/ let BlockSize = 1024;
                    /*int*/ let blocks = $.trunc($.$checked($.$checked(this._offset + pendingCount, 1) + ($.$checked(BlockSize - 1, 1)), 1) / BlockSize);
                    /*byte[]?*/ let oldBytes = this._buffer;
                    $.$$.S.Array.Resize($.$$.S.Byte, $.$ref(() => this._buffer, ($v) => this._buffer = $v, $.$typeArray($.$$.S.Byte)), ((BlockSize * blocks) | 0));
                    /*byte[]?*/ let __ca1__;
                    if ((__ca1__ = oldBytes) !== null)
                    {
                        $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, __ca1__, 0, this._offset).Clear();
                    }
                    $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset).Fill(202);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490001427)
            
            //--TRIMMABLE-BOUNDARY-START(365072941075)
            /*void */ WriteTag(/*Asn1Tag*/ tag)
            {
                /*int*/ let written;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072941075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let spaceRequired = tag.CalculateEncodedSize();
                this.EnsureWriteCapacity(spaceRequired);
                if (!tag.TryEncode($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, this._buffer, this._offset, spaceRequired), $.$ref(() => written, ($v) => written = $v, $.$$.S.Int32)) || written !== spaceRequired)
                {
                    $.$$.SD.Debug.Fail$1(`TryWrite failed or written was wrong value (${$.$strNN(written)} vs ${$.$strNN(spaceRequired)})`);
                    throw new $.$$.S.InvalidOperationException().$ctor$9();
                }
                this._offset += spaceRequired;
            }
            //--TRIMMABLE-BOUNDARY-END(365072941075)
            
            //--TRIMMABLE-BOUNDARY-START(304943398931)
            /*void */ WriteLength(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943398931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte*/ let MultiByteMarker = 128;
                $.$$.SD.Debug.Assert$4(length >= -1, "length >= -1");
                if (length === -1)
                {
                    this.EnsureWriteCapacity(1);
                    $.$$.System.Array.$WriteT1.call(this._buffer, MultiByteMarker, this._offset);
                    this._offset++;
                    return;
                }
                $.$$.SD.Debug.Assert$4(length >= 0, "length >= 0");
                if (length < MultiByteMarker)
                {
                    this.EnsureWriteCapacity(((1 + length) | 0));
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(length, $.$$.S.Byte), this._offset);
                    this._offset++;
                    return;
                }
                /*int*/ let lengthLength = $.$sfa.SFA.AsnWriter.GetEncodedLengthSubsequentByteCount(length);
                this.EnsureWriteCapacity(((((lengthLength + 1) | 0) + length) | 0));
                $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast((MultiByteMarker | lengthLength), $.$$.S.Byte), this._offset);
                /*int*/ let idx = ((this._offset + lengthLength) | 0);
                /*int*/ let remaining = length;
                do
                {
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(remaining, $.$$.S.Byte), idx);
                    remaining >>= 8;
                    idx--;
                }
                while(remaining > 0);
                $.$$.SD.Debug.Assert$4(idx === this._offset, "idx == _offset");
                this._offset += ((lengthLength + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(304943398931)
            
            //--TRIMMABLE-BOUNDARY-START(111669870611)
            static /*int */ GetEncodedLengthSubsequentByteCount(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669870611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (length < 0)
                {
                    throw new $.$$.S.OverflowException().$ctor$13();
                }
                if (length <= 127)
                {
                    return 0;
                }
                if (length <= 255/*byte.MaxValue*/)
                {
                    return 1;
                }
                if (length <= 65535/*ushort.MaxValue*/)
                {
                    return 2;
                }
                if (length <= 16777215)
                {
                    return 3;
                }
                return 4;
            }
            //--TRIMMABLE-BOUNDARY-END(111669870611)
            
            //--TRIMMABLE-BOUNDARY-START(47245361171)
            /*void */ CopyTo(/*AsnWriter*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(destination, "destination");
                try
                {
                    destination.WriteEncodedValue(this.EncodeAsSpan());
                }
                catch(e)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$11(new $.$$.S.InvalidOperationException().$ctor$9().Message, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245361171)
            
            //--TRIMMABLE-BOUNDARY-START(236223922195)
            /*void */ WriteEncodedValue(/*ReadOnlySpan<byte>*/ value)
            {
                /*int*/ let consumed;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223922195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let read = $.$sfa.SFA.AsnDecoder.TryReadEncodedValue(value, this.RuleSet, $.$discardRef(), $.$discardRef(), $.$discardRef(), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32));
                if (!read || consumed !== value.Length)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_WriteEncodedValue_OneValueAtATime, "value");
                }
                this.EnsureWriteCapacity(value.Length);
                value.CopyTo($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._buffer, this._offset));
                this._offset += value.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(236223922195)
            
            //--TRIMMABLE-BOUNDARY-START(240518889491)
            /*void */ WriteEndOfContents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518889491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureWriteCapacity(2);
                $.$$.System.Array.$WriteT1.call(this._buffer, 0, this._offset++);
                $.$$.System.Array.$WriteT1.call(this._buffer, 0, this._offset++);
            }
            //--TRIMMABLE-BOUNDARY-END(240518889491)
            
            //--TRIMMABLE-BOUNDARY-START(167504445459)
            /*Scope */ PushTag(/*Asn1Tag*/ tag, /*UniversalTagNumber*/ tagType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504445459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._nestingStack ??= new ($.$sc.SCG.Stack$$($.$sfa.SFA.AsnWriter.StackFrame))().$ctor$1();
                $.$$.SD.Debug.Assert$4(tag.IsConstructed, "tag.IsConstructed");
                this.WriteTag(tag);
                this._nestingStack.Push(new $.$sfa.SFA.AsnWriter.StackFrame().$ctor$3(tag, this._offset, tagType));
                this.WriteLength(-1);
                return new $.$sfa.SFA.AsnWriter.Scope().$ctor$3(this);
            }
            //--TRIMMABLE-BOUNDARY-END(167504445459)
            
            //--TRIMMABLE-BOUNDARY-START(141734641683)
            /*void */ PopTag(/*Asn1Tag*/ tag, /*UniversalTagNumber*/ tagType, /*bool*/ sortContents)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734641683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._nestingStack === null || this._nestingStack.Count === 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$sfa.S.SR.AsnWriter_PopWrongTag);
                }
                let [ stackTag, lenOffset, stackTagType ] = $.$destructure(this._nestingStack.Peek(), 3);
                $.$$.SD.Debug.Assert$4(tag.IsConstructed, "tag.IsConstructed");
                if ($.$sfa.SFA.Asn1Tag.op_Inequality(stackTag, tag) || stackTagType !== tagType)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$sfa.S.SR.AsnWriter_PopWrongTag);
                }
                this._nestingStack.Pop();
                if (sortContents)
                {
                    $.$$.SD.Debug.Assert$4(tagType === 17/*UniversalTagNumber.SetOf*/, "tagType == UniversalTagNumber.SetOf");
                    $.$sfa.SFA.AsnWriter.SortContents(this._buffer, ((lenOffset + 1) | 0), this._offset);
                }
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/ && tagType !== 4/*UniversalTagNumber.OctetString*/)
                {
                    this.WriteEndOfContents();
                    return;
                }
                /*int*/ let containedLength = ((((this._offset - 1) | 0) - lenOffset) | 0);
                $.$$.SD.Debug.Assert$4(containedLength >= 0, "containedLength >= 0");
                /*int*/ let start = ((lenOffset + 1) | 0);
                if (tagType === 4/*UniversalTagNumber.OctetString*/)
                {
                    if (this.RuleSet !== 1/*AsnEncodingRules.CER*/ || containedLength <= 1000/*AsnDecoder.MaxCERSegmentSize*/)
                    {
                        /*int*/ let tagLen = tag.CalculateEncodedSize();
                        tag.AsPrimitive().Encode($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, this._buffer, ((lenOffset - tagLen) | 0), tagLen));
                    }
                    else 
                    {
                        /*int*/ let lastSegmentSize;
                        /*int*/ let fullSegments = $.$$.S.Math.DivRem$2(containedLength, 1000/*AsnDecoder.MaxCERSegmentSize*/, $.$ref(() => lastSegmentSize, ($v) => lastSegmentSize = $v, $.$$.S.Int32));
                        /*int*/ let requiredPadding = ((((((4 * fullSegments) | 0) + 2) | 0) + $.$sfa.SFA.AsnWriter.GetEncodedLengthSubsequentByteCount(lastSegmentSize)) | 0);
                        this.EnsureWriteCapacity(((requiredPadding + 2) | 0));
                        /*ReadOnlySpan<byte>*/ let src = $.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, this._buffer, start, containedLength));
                        /*Span<byte>*/ let dest = $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, this._buffer, ((start + requiredPadding) | 0), containedLength);
                        src.CopyTo(dest);
                        /*int*/ let expectedEnd = ((((((start + containedLength) | 0) + requiredPadding) | 0) + 2) | 0);
                        this._offset = ((lenOffset - tag.CalculateEncodedSize()) | 0);
                        this.WriteConstructedCerOctetString(tag, $.$$.S.Span$$($.$$.S.Byte).op_Implicit(dest));
                        $.$$.SD.Debug.Assert$4(this._offset === expectedEnd, "_offset == expectedEnd");
                        return;
                    }
                }
                /*int*/ let shiftSize = $.$sfa.SFA.AsnWriter.GetEncodedLengthSubsequentByteCount(containedLength);
                if (shiftSize === 0)
                {
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(containedLength, $.$$.S.Byte), lenOffset);
                    return;
                }
                this.EnsureWriteCapacity(shiftSize);
                $.$$.S.Buffer.BlockCopy(this._buffer, start, this._buffer, ((start + shiftSize) | 0), containedLength);
                /*int*/ let tmp = this._offset;
                this._offset = lenOffset;
                this.WriteLength(containedLength);
                $.$$.SD.Debug.Assert$4(((((this._offset - lenOffset) | 0) - 1) | 0) === shiftSize, "_offset - lenOffset - 1 == shiftSize");
                this._offset = ((tmp + shiftSize) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(141734641683)
            
            //--TRIMMABLE-BOUNDARY-START(180389347347)
            static /*void */ SortContents(/*byte[]*/ buffer, /*int*/ start, /*int*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389347347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(buffer !== null, "buffer != null");
                $.$$.SD.Debug.Assert$4(end >= start, "end >= start");
                /*int*/ let len = ((end - start) | 0);
                if (len === 0)
                {
                    return;
                }
                /*var*/ let reader = new $.$sfa.SFA.AsnReader().$ctor$1(new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))().$ctor$4(buffer, start, len), 0/*AsnEncodingRules.BER*/, new $.$sfa.SFA.AsnReaderOptions());
                /*int*/ let pos = start;
                /*ReadOnlyMemory<byte>*/ let encoded = reader.ReadEncodedValue();
                if (!reader.HasData)
                {
                    return;
                }
                /*List<(int, int)>*/ let positions = new ($.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32)))().$ctor$1();
                positions.Add(new ($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$3(pos, encoded.Length));
                pos += encoded.Length;
                do
                {
                    encoded = reader.ReadEncodedValue();
                    positions.Add(new ($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$3(pos, encoded.Length));
                    pos += encoded.Length;
                }
                while(reader.HasData);
                $.$$.SD.Debug.Assert$4(pos === end, "pos == end");
                /*var*/ let comparer = new $.$sfa.SFA.AsnWriter.ArrayIndexSetOfValueComparer().$ctor$1(buffer);
                positions.Sort$1(comparer);
                /*byte[]*/ let tmp = $.$sfa.SSC.CryptoPool.Rent(len);
                pos = 0;
                let $en16 = positions.GetEnumerator();
                while ($en16.MoveNext())
                {
                    let $t17 = $en16.Current;
                    /*int*/ let offset = $t17.Item1;
                    /*int*/ let length = $t17.Item2;
                    {
                        $.$$.S.Buffer.BlockCopy(buffer, offset, tmp, pos, length);
                        pos += length;
                    }
                }
                $.$$.SD.Debug.Assert$4(pos === len, "pos == len");
                $.$$.S.Buffer.BlockCopy(tmp, 0, buffer, start, len);
                $.$sfa.SSC.CryptoPool.Return$1(tmp, len);
            }
            //--TRIMMABLE-BOUNDARY-END(180389347347)
            
            //--TRIMMABLE-BOUNDARY-START(38655426579)
            static /*void */ CheckUniversalTag(/*Asn1Tag?*/ tag, /*UniversalTagNumber*/ universalTagNumber)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655426579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tag !== null)
                {
                    /*Asn1Tag*/ let value = $.$$.S.Nullable$$($.$sfa.SFA.Asn1Tag).Value$get.call(tag);
                    if (value.TagClass === 0/*TagClass.Universal*/ && value.TagValue !== universalTagNumber)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_UniversalValueIsFixed, "tag");
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655426579)
            
            //--TRIMMABLE-BOUNDARY-START(786451)
            static $_ArrayIndexSetOfValueComparer;
            static get ArrayIndexSetOfValueComparer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sfa.SFA.AsnWriter;
                return $cls.$_ArrayIndexSetOfValueComparer ??= $asm.$ncls(`$sfa.SFA.AsnWriter.ArrayIndexSetOfValueComparer`, ($self) => class ArrayIndexSetOfValueComparer extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295753747)
                    /*byte[]*/ _data = null;
                    //--TRIMMABLE-BOUNDARY-END(4295753747)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590721043)
                    $ctor$1(/*byte[]*/ data)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590721043);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._data = data;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590721043)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885688339)
                    /*int */ Compare(/*(int, int)*/ x, /*(int, int)*/ y)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885688339);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let [ xOffset, xLength ] = $.$destructure($.$clone(x), 2);
                        let [ yOffset, yLength ] = $.$destructure($.$clone(y), 2);
                        /*int*/ let value = $.$sfa.SFA.SetOfValueComparer.Instance.Compare(new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))().$ctor$4(this._data, xOffset, xLength), new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))().$ctor$4(this._data, yOffset, yLength));
                        if (value === 0)
                        {
                            return ((xOffset - yOffset) | 0);
                        }
                        return value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885688339)
                    
                    //--TRIMMABLE-BOUNDARY-START(4355129345)
                    //Generated interface implemetation for System.Collections.Generic.IComparer<(int, int)>.Compare((int, int), (int, int))
                    [`SCG$IComparer$System$ValueTuple$System$Int32$System$Int32$$Compare`]()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4355129345);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Compare(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4355129345)
                    
                    static $h = 786451;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885688339),
    {
      "r": 655361,
      "p": [
        {
          "n": "x",
          "p": $.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32).$h
        },
        {
          "n": "y",
          "p": $.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32).$h
        }
      ],
      "n": "Compare",
      "d": 786451,
      "h": 12885688339,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688339)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295753747),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_data",
      "d": 786451,
      "h": 4295753747,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753747)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590721043),
    {
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786451,
      "h": 8590721043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590721043)
  ],
  "d": 720915,
  "h": 786451
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IComparer$$($.$$.S.ValueTuple$$$($.$$.S.Int32, $.$$.S.Int32)) ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.AsnWriter+ArrayIndexSetOfValueComparer`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}AsnWriter${separator}ArrayIndexSetOfValueComparer`; }
                }, $cls, ($v) => $cls.$_ArrayIndexSetOfValueComparer = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786451)
            
            //--TRIMMABLE-BOUNDARY-START(917523)
            static $_StackFrame;
            static get StackFrame()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(917523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sfa.SFA.AsnWriter;
                return $cls.$_StackFrame ??= $asm.$nstr(`$sfa.SFA.AsnWriter.StackFrame`, ($self) => class StackFrame extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(85900263443)
                    /*Asn1Tag*/ Tag;
                    //--TRIMMABLE-BOUNDARY-END(85900263443)
                    
                    //--TRIMMABLE-BOUNDARY-START(73015361555)
                    /*int*/ Offset = 0;
                    //--TRIMMABLE-BOUNDARY-END(73015361555)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720394259)
                    /*UniversalTagNumber*/ ItemType = 0;
                    //--TRIMMABLE-BOUNDARY-END(68720394259)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475754003)
                    $ctor$3(/*Asn1Tag*/ tag, /*int*/ offset, /*UniversalTagNumber*/ itemType)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475754003);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Tag = tag;
                            this.Offset = offset;
                            this.ItemType = itemType;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475754003)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770721299)
                    /*void */ Deconstruct(/*out Asn1Tag*/ tag, /*out int*/ offset, /*out UniversalTagNumber*/ itemType)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770721299);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        tag.$v = this.Tag;
                        offset.$v = this.Offset;
                        itemType.$v = this.ItemType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770721299)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360655891)
                    /*bool */ Equals$2(/*StackFrame*/ other)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360655891);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Tag.Equals$2(other.Tag) && this.Offset === other.Offset && this.ItemType === other.ItemType;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360655891)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065688595)
                    /*bool */ Equals$1(/*object?*/ obj)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065688595);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let other;
                            return $.$is(obj, $.$sfa.SFA.AsnWriter.StackFrame, { set $v($v){ other = $v; } }) && this.Equals$2(other);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065688595)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425426963)
                    /*int */ GetHashCode()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64425426963);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new ($.$$.S.ValueTuple$$$$($.$sfa.SFA.Asn1Tag, $.$$.S.Int32, $.$sfa.SFA.UniversalTagNumber))().$ctor$3(this.Tag, this.Offset, this.ItemType).GetHashCode();
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425426963)
                    
                    //--TRIMMABLE-BOUNDARY-START(77310328851)
                    static /*bool */ op_Equality(/*StackFrame*/ left, /*StackFrame*/ right)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(77310328851);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return left.Equals$2(right);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(77310328851)
                    
                    //--TRIMMABLE-BOUNDARY-START(81605296147)
                    static /*bool */ op_Inequality(/*StackFrame*/ left, /*StackFrame*/ right)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(81605296147);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return !left.Equals$2(right);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(81605296147)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386127873)
                    //Generated interface implemetation for System.IEquatable<System.Formats.Asn1.AsnWriter.StackFrame>.Equals(System.Formats.Asn1.AsnWriter.StackFrame)
                    S$IEquatable$System$Formats$Asn1$AsnWriter$StackFrame$Equals()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386127873);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Equals$2(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386127873)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180786707)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180786707);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180786707)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180786707)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180786707)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Tag = this.Tag.$clone();
                        copy.Offset = this.Offset;
                        copy.ItemType = this.ItemType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(85900263443)
                        this.Tag = $.$default($.$sfa.SFA.Asn1Tag);
                        //--TRIMMABLE-BOUNDARY-END(85900263443)
                        
                    }
                    static $h = 917523;
                    static $z = 13;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85900263443),
    {
      "p": 65555,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130459667,
        "f": 50331649
      },
      "n": "Tag",
      "d": 917523,
      "h": 85900263443,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900263443),
//--TRIMMABLE-BOUNDARY-START(73015361555),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540525075,
        "f": 50331649
      },
      "n": "Offset",
      "d": 917523,
      "h": 73015361555,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015361555),
//--TRIMMABLE-BOUNDARY-START(68720394259),
    {
      "p": 1572883,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950590483,
        "f": 50331649
      },
      "n": "ItemType",
      "d": 917523,
      "h": 68720394259,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720394259)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770721299),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555,
          "f": 2
        },
        {
          "n": "offset",
          "p": 655361,
          "f": 2
        },
        {
          "n": "itemType",
          "p": 1572883,
          "f": 2
        }
      ],
      "n": "Deconstruct",
      "d": 917523,
      "h": 25770721299,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770721299),
//--TRIMMABLE-BOUNDARY-START(34360655891),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 917523
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 917523,
      "h": 34360655891,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360655891),
//--TRIMMABLE-BOUNDARY-START(30065688595),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 917523,
      "h": 30065688595,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065688595),
//--TRIMMABLE-BOUNDARY-START(64425426963),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 917523,
      "h": 64425426963,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425426963)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475754003),
    {
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "itemType",
          "p": 1572883
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917523,
      "h": 21475754003,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475754003),
//--TRIMMABLE-BOUNDARY-START(17180786707),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917523,
      "h": 17180786707,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786707)
  ],
  "d": 720915,
  "h": 917523
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$sfa.SFA.AsnWriter.StackFrame) ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.AsnWriter+StackFrame`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}AsnWriter${separator}StackFrame`; }
                }, $cls, ($v) => $cls.$_StackFrame = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917523)
            
            //--TRIMMABLE-BOUNDARY-START(851987)
            static $_Scope;
            static get Scope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(851987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sfa.SFA.AsnWriter;
                return $cls.$_Scope ??= $asm.$nstr(`$sfa.SFA.AsnWriter.Scope`, ($self) => class Scope extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885753875)
                    /*AsnWriter*/ _writer = null;
                    //--TRIMMABLE-BOUNDARY-END(12885753875)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590786579)
                    /*StackFrame*/ _frame;
                    //--TRIMMABLE-BOUNDARY-END(8590786579)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295819283)
                    /*int*/ _depth = 0;
                    //--TRIMMABLE-BOUNDARY-END(4295819283)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475688467)
                    $ctor$3(/*AsnWriter*/ writer)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475688467);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.SD.Debug.Assert$4(writer._nestingStack !== null, "writer._nestingStack != null");
                            this._writer = writer;
                            this._frame = this._writer._nestingStack.Peek();
                            this._depth = this._writer._nestingStack.Count;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475688467)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770655763)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770655763);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4(this._writer === null || this._writer._nestingStack !== null, "_writer == null || _writer._nestingStack != null");
                        if (this._writer === null || this._writer._nestingStack.Count === 0)
                        {
                            return;
                        }
                        if ($.$sfa.SFA.AsnWriter.StackFrame.op_Equality(this._writer._nestingStack.Peek(), this._frame))
                        {
                            let $switch18 = this._frame.ItemType;
                            switch($switch18)
                            {
                                case 17/*UniversalTagNumber.SetOf*/:
                                this._writer.PopSetOf(this._frame.Tag);
                                break;
                                case 16/*UniversalTagNumber.Sequence*/:
                                this._writer.PopSequence(this._frame.Tag);
                                break;
                                case 4/*UniversalTagNumber.OctetString*/:
                                this._writer.PopOctetString(this._frame.Tag);
                                break;
                                default:
                                $.$$.SD.Debug.Fail$1(`No handler for ${$.$strNN($.$$.S.Enum.ToStringT($.$sfa.SFA.UniversalTagNumber, $.$$.S.UInt32, this._frame.ItemType))}`);
                                throw new $.$$.S.InvalidOperationException().$ctor$9();
                            }
                        }
                        else if (this._writer._nestingStack.Count > this._depth && this._writer._nestingStack.Contains(this._frame))
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$sfa.S.SR.AsnWriter_PopWrongTag);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770655763)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180721171)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180721171);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180721171)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180721171)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180721171)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._writer = this._writer;
                        copy._frame = this._frame.$clone();
                        copy._depth = this._depth;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590786579)
                        this._frame = $.$default($.$sfa.SFA.AsnWriter.StackFrame);
                        //--TRIMMABLE-BOUNDARY-END(8590786579)
                        
                    }
                    static $h = 851987;
                    static $z = 21;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770655763),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 851987,
      "h": 25770655763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770655763)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885753875),
    {
      "t": 720915,
      "n": "_writer",
      "d": 851987,
      "h": 12885753875,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885753875),
//--TRIMMABLE-BOUNDARY-START(8590786579),
    {
      "t": 917523,
      "n": "_frame",
      "d": 851987,
      "h": 8590786579,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590786579),
//--TRIMMABLE-BOUNDARY-START(4295819283),
    {
      "t": 655361,
      "n": "_depth",
      "d": 851987,
      "h": 4295819283,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819283)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475688467),
    {
      "p": [
        {
          "n": "writer",
          "p": 720915
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 851987,
      "h": 21475688467,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475688467),
//--TRIMMABLE-BOUNDARY-START(17180721171),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 851987,
      "h": 17180721171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180721171)
  ],
  "d": 720915,
  "h": 851987
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.AsnWriter+Scope`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}AsnWriter${separator}Scope`; }
                }, $cls, ($v) => $cls.$_Scope = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(851987)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295688211)
                this._buffer = null;
                //--TRIMMABLE-BOUNDARY-END(4295688211)
                
            }
            static $h = 720915;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(176094380051),
    {
      "p": 524307,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079936019,
        "f": 50331649
      },
      "n": "RuleSet",
      "d": 720915,
      "h": 176094380051,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176094380051)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(214749085715),
    {
      "r": 65537,
      "p": [
        {
          "n": "encodingType",
          "p": 1572883
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteCharacterString",
      "o": "@$1",
      "d": 720915,
      "h": 214749085715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214749085715),
//--TRIMMABLE-BOUNDARY-START(210454118419),
    {
      "r": 65537,
      "p": [
        {
          "n": "encodingType",
          "p": 1572883
        },
        {
          "n": "str",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteCharacterString",
      "d": 720915,
      "h": 210454118419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210454118419),
//--TRIMMABLE-BOUNDARY-START(219044053011),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "str",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "WriteCharacterStringCore",
      "d": 720915,
      "h": 219044053011,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(219044053011),
//--TRIMMABLE-BOUNDARY-START(227633987603),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "str",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "size",
          "p": 655361
        }
      ],
      "n": "WriteConstructedCerCharacterString",
      "d": 720915,
      "h": 227633987603,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(227633987603),
//--TRIMMABLE-BOUNDARY-START(313533333523),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1048577
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteNamedBitList",
      "o": "@$1",
      "d": 720915,
      "h": 313533333523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(313533333523),
//--TRIMMABLE-BOUNDARY-START(326418235411),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (TEnum) => TEnum.$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "g": [
        "TEnum"
      ],
      "n": "WriteNamedBitList",
      "o": "@$4",
      "d": 720915,
      "h": 326418235411,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(326418235411),
//--TRIMMABLE-BOUNDARY-START(309238366227),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 56033281
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteNamedBitList",
      "d": 720915,
      "h": 309238366227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(309238366227),
//--TRIMMABLE-BOUNDARY-START(317828300819),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h
        },
        {
          "n": "tEnum",
          "p": 188547073
        },
        {
          "n": "value",
          "p": 1048577
        }
      ],
      "n": "WriteNamedBitList",
      "o": "@$2",
      "d": 720915,
      "h": 317828300819,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(317828300819),
//--TRIMMABLE-BOUNDARY-START(322123268115),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h
        },
        {
          "n": "integralValue",
          "p": 983041
        }
      ],
      "n": "WriteNamedBitList",
      "o": "@$3",
      "d": 720915,
      "h": 322123268115,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(322123268115),
//--TRIMMABLE-BOUNDARY-START(188979281939),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 56033281
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h
        }
      ],
      "n": "WriteBitArray",
      "d": 720915,
      "h": 188979281939,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(188979281939),
//--TRIMMABLE-BOUNDARY-START(201864183827),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 262145
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteBoolean",
      "d": 720915,
      "h": 201864183827,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201864183827),
//--TRIMMABLE-BOUNDARY-START(206159151123),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "WriteBooleanCore",
      "d": 720915,
      "h": 206159151123,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(206159151123),
//--TRIMMABLE-BOUNDARY-START(193274249235),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "unusedBitCount",
          "p": 655361,
          "f": 65,
          "v": 0
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteBitString",
      "d": 720915,
      "h": 193274249235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193274249235),
//--TRIMMABLE-BOUNDARY-START(197569216531),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "bitString",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "unusedBitCount",
          "p": 655361
        }
      ],
      "n": "WriteBitStringCore",
      "d": 720915,
      "h": 197569216531,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197569216531),
//--TRIMMABLE-BOUNDARY-START(42950393875),
    {
      "r": 262145,
      "p": [
        {
          "n": "lastByte",
          "p": 393217
        },
        {
          "n": "unusedBitCount",
          "p": 655361
        }
      ],
      "n": "CheckValidLastByte",
      "d": 720915,
      "h": 42950393875,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42950393875),
//--TRIMMABLE-BOUNDARY-START(51540328467),
    {
      "r": 655361,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "contentLength",
          "p": 655361
        }
      ],
      "n": "DetermineCerBitStringTotalLength",
      "d": 720915,
      "h": 51540328467,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51540328467),
//--TRIMMABLE-BOUNDARY-START(223339020307),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "payload",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "unusedBitCount",
          "p": 655361
        }
      ],
      "n": "WriteConstructedCerBitString",
      "d": 720915,
      "h": 223339020307,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223339020307),
//--TRIMMABLE-BOUNDARY-START(335008170003),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteNull",
      "d": 720915,
      "h": 335008170003,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(335008170003),
//--TRIMMABLE-BOUNDARY-START(339303137299),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        }
      ],
      "n": "WriteNullCore",
      "d": 720915,
      "h": 339303137299,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(339303137299),
//--TRIMMABLE-BOUNDARY-START(150324576275),
    {
      "r": 851987,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "PushSequence",
      "d": 720915,
      "h": 150324576275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324576275),
//--TRIMMABLE-BOUNDARY-START(124554772499),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "PopSequence",
      "d": 720915,
      "h": 124554772499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124554772499),
//--TRIMMABLE-BOUNDARY-START(154619543571),
    {
      "r": 851987,
      "p": [
        {
          "n": "tag",
          "p": 65555
        }
      ],
      "n": "PushSequenceCore",
      "d": 720915,
      "h": 154619543571,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(154619543571),
//--TRIMMABLE-BOUNDARY-START(128849739795),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        }
      ],
      "n": "PopSequenceCore",
      "d": 720915,
      "h": 128849739795,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128849739795),
//--TRIMMABLE-BOUNDARY-START(146029608979),
    {
      "r": 851987,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "PushOctetString",
      "d": 720915,
      "h": 146029608979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029608979),
//--TRIMMABLE-BOUNDARY-START(120259805203),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "PopOctetString",
      "d": 720915,
      "h": 120259805203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120259805203),
//--TRIMMABLE-BOUNDARY-START(356483006483),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteOctetString",
      "d": 720915,
      "h": 356483006483,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(356483006483),
//--TRIMMABLE-BOUNDARY-START(360777973779),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "octetString",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "WriteOctetStringCore",
      "d": 720915,
      "h": 360777973779,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(360777973779),
//--TRIMMABLE-BOUNDARY-START(231928954899),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "payload",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "WriteConstructedCerOctetString",
      "d": 720915,
      "h": 231928954899,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(231928954899),
//--TRIMMABLE-BOUNDARY-START(347893071891),
    {
      "r": 65537,
      "p": [
        {
          "n": "oidValue",
          "p": 1310721
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteObjectIdentifier",
      "o": "@$1",
      "d": 720915,
      "h": 347893071891,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(347893071891),
//--TRIMMABLE-BOUNDARY-START(343598104595),
    {
      "r": 65537,
      "p": [
        {
          "n": "oidValue",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteObjectIdentifier",
      "d": 720915,
      "h": 343598104595,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(343598104595),
//--TRIMMABLE-BOUNDARY-START(352188039187),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "oidValue",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "WriteObjectIdentifierCore",
      "d": 720915,
      "h": 352188039187,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(352188039187),
//--TRIMMABLE-BOUNDARY-START(115964837907),
    {
      "r": 786438,
      "p": [
        {
          "n": "oidValue",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h,
          "f": 4
        }
      ],
      "n": "ParseSubIdentifier",
      "d": 720915,
      "h": 115964837907,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(115964837907),
//--TRIMMABLE-BOUNDARY-START(34360459283),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "AtoI",
      "d": 720915,
      "h": 34360459283,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34360459283),
//--TRIMMABLE-BOUNDARY-START(90195034131),
    {
      "r": 655361,
      "p": [
        {
          "n": "dest",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "subIdentifier",
          "p": 786438,
          "f": 4
        }
      ],
      "n": "EncodeSubIdentifier",
      "d": 720915,
      "h": 90195034131,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90195034131),
//--TRIMMABLE-BOUNDARY-START(373662875667),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 66191361
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteUtcTime",
      "o": "@$1",
      "d": 720915,
      "h": 373662875667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(373662875667),
//--TRIMMABLE-BOUNDARY-START(369367908371),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 66191361
        },
        {
          "n": "twoDigitYearMax",
          "p": 655361
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteUtcTime",
      "d": 720915,
      "h": 369367908371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(369367908371),
//--TRIMMABLE-BOUNDARY-START(377957842963),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": 66191361
        }
      ],
      "n": "WriteUtcTimeCore",
      "d": 720915,
      "h": 377957842963,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(377957842963),
//--TRIMMABLE-BOUNDARY-START(158914510867),
    {
      "r": 851987,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "PushSetOf",
      "d": 720915,
      "h": 158914510867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914510867),
//--TRIMMABLE-BOUNDARY-START(133144707091),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "PopSetOf",
      "d": 720915,
      "h": 133144707091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133144707091),
//--TRIMMABLE-BOUNDARY-START(163209478163),
    {
      "r": 851987,
      "p": [
        {
          "n": "tag",
          "p": 65555
        }
      ],
      "n": "PushSetOfCore",
      "d": 720915,
      "h": 163209478163,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163209478163),
//--TRIMMABLE-BOUNDARY-START(137439674387),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        }
      ],
      "n": "PopSetOfCore",
      "d": 720915,
      "h": 137439674387,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137439674387),
//--TRIMMABLE-BOUNDARY-START(257698758675),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 66191361
        },
        {
          "n": "omitFractionalSeconds",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteGeneralizedTime",
      "d": 720915,
      "h": 257698758675,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(257698758675),
//--TRIMMABLE-BOUNDARY-START(261993725971),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": 66191361
        },
        {
          "n": "omitFractionalSeconds",
          "p": 262145
        }
      ],
      "n": "WriteGeneralizedTimeCore",
      "d": 720915,
      "h": 261993725971,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(261993725971),
//--TRIMMABLE-BOUNDARY-START(244813856787),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1048577
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteEnumeratedValue",
      "d": 720915,
      "h": 244813856787,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(244813856787),
//--TRIMMABLE-BOUNDARY-START(253403791379),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (TEnum) => TEnum.$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "g": [
        "TEnum"
      ],
      "n": "WriteEnumeratedValue",
      "o": "@$2",
      "d": 720915,
      "h": 253403791379,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(253403791379),
//--TRIMMABLE-BOUNDARY-START(249108824083),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "tEnum",
          "p": 188547073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "WriteEnumeratedValue",
      "o": "@$1",
      "d": 720915,
      "h": 249108824083,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(249108824083),
//--TRIMMABLE-BOUNDARY-START(266288693267),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteInteger",
      "d": 720915,
      "h": 266288693267,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(266288693267),
//--TRIMMABLE-BOUNDARY-START(279173595155),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 983041
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteInteger",
      "o": "@$3",
      "d": 720915,
      "h": 279173595155,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(279173595155),
//--TRIMMABLE-BOUNDARY-START(270583660563),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 786438
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteInteger",
      "o": "@$1",
      "d": 720915,
      "h": 270583660563,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(270583660563),
//--TRIMMABLE-BOUNDARY-START(274878627859),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteInteger",
      "o": "@$2",
      "d": 720915,
      "h": 274878627859,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(274878627859),
//--TRIMMABLE-BOUNDARY-START(296353464339),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h,
          "f": 65
        }
      ],
      "n": "WriteIntegerUnsigned",
      "d": 720915,
      "h": 296353464339,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(296353464339),
//--TRIMMABLE-BOUNDARY-START(283468562451),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "WriteIntegerCore",
      "d": 720915,
      "h": 283468562451,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(283468562451),
//--TRIMMABLE-BOUNDARY-START(330713202707),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": 983041
        }
      ],
      "n": "WriteNonNegativeIntegerCore",
      "d": 720915,
      "h": 330713202707,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(330713202707),
//--TRIMMABLE-BOUNDARY-START(300648431635),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "WriteIntegerUnsignedCore",
      "d": 720915,
      "h": 300648431635,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(300648431635),
//--TRIMMABLE-BOUNDARY-START(292058497043),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "WriteIntegerCore",
      "o": "@$2",
      "d": 720915,
      "h": 292058497043,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(292058497043),
//--TRIMMABLE-BOUNDARY-START(287763529747),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "value",
          "p": 786438
        }
      ],
      "n": "WriteIntegerCore",
      "o": "@$1",
      "d": 720915,
      "h": 287763529747,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(287763529747),
//--TRIMMABLE-BOUNDARY-START(171799412755),
    {
      "r": 65537,
      "n": "Reset",
      "d": 720915,
      "h": 171799412755,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171799412755),
//--TRIMMABLE-BOUNDARY-START(107374903315),
    {
      "r": 655361,
      "n": "GetEncodedLength",
      "d": 720915,
      "h": 107374903315,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374903315),
//--TRIMMABLE-BOUNDARY-START(184684314643),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryEncode",
      "d": 720915,
      "h": 184684314643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684314643),
//--TRIMMABLE-BOUNDARY-START(60130263059),
    {
      "r": 655361,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "Encode",
      "o": "@$1",
      "d": 720915,
      "h": 60130263059,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130263059),
//--TRIMMABLE-BOUNDARY-START(55835295763),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "n": "Encode",
      "d": 720915,
      "h": 55835295763,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835295763),
//--TRIMMABLE-BOUNDARY-START(64425230355),
    {
      "r": (TReturn) => TReturn.$h,
      "p": [
        {
          "n": "encodeCallback",
          "p": (TReturn) => $.$$.S.Func$$$($.$$.S.ReadOnlySpan$$($.$$.S.Byte), TReturn).$h
        }
      ],
      "g": [
        "TReturn"
      ],
      "n": "Encode",
      "o": "@$2",
      "d": 720915,
      "h": 64425230355,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(64425230355),
//--TRIMMABLE-BOUNDARY-START(68720197651),
    {
      "r": (TState, TReturn) => TReturn.$h,
      "p": [
        {
          "n": "state",
          "p": (TState, TReturn) => TState.$h
        },
        {
          "n": "encodeCallback",
          "p": (TState, TReturn) => $.$$.S.Func$$$$(TState, $.$$.S.ReadOnlySpan$$($.$$.S.Byte), TReturn).$h
        }
      ],
      "g": [
        "TState",
        "TReturn"
      ],
      "n": "Encode",
      "o": "@$3",
      "d": 720915,
      "h": 68720197651,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(68720197651),
//--TRIMMABLE-BOUNDARY-START(73015164947),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": (TState) => TState.$h
        },
        {
          "n": "encodeCallback",
          "p": (TState) => $.$$.S.Action$$$(TState, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)).$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "Encode",
      "o": "@$4",
      "d": 720915,
      "h": 73015164947,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(73015164947),
//--TRIMMABLE-BOUNDARY-START(77310132243),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "n": "EncodeAsSpan",
      "d": 720915,
      "h": 77310132243,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77310132243),
//--TRIMMABLE-BOUNDARY-START(81605099539),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "EncodedValueEquals",
      "d": 720915,
      "h": 81605099539,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605099539),
//--TRIMMABLE-BOUNDARY-START(85900066835),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 720915
        }
      ],
      "n": "EncodedValueEquals",
      "o": "@$1",
      "d": 720915,
      "h": 85900066835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900066835),
//--TRIMMABLE-BOUNDARY-START(94490001427),
    {
      "r": 65537,
      "p": [
        {
          "n": "pendingCount",
          "p": 655361
        }
      ],
      "n": "EnsureWriteCapacity",
      "d": 720915,
      "h": 94490001427,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94490001427),
//--TRIMMABLE-BOUNDARY-START(365072941075),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        }
      ],
      "n": "WriteTag",
      "d": 720915,
      "h": 365072941075,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(365072941075),
//--TRIMMABLE-BOUNDARY-START(304943398931),
    {
      "r": 65537,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "WriteLength",
      "d": 720915,
      "h": 304943398931,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(304943398931),
//--TRIMMABLE-BOUNDARY-START(111669870611),
    {
      "r": 655361,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "GetEncodedLengthSubsequentByteCount",
      "d": 720915,
      "h": 111669870611,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(111669870611),
//--TRIMMABLE-BOUNDARY-START(47245361171),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": 720915
        }
      ],
      "n": "CopyTo",
      "d": 720915,
      "h": 47245361171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245361171),
//--TRIMMABLE-BOUNDARY-START(236223922195),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "WriteEncodedValue",
      "d": 720915,
      "h": 236223922195,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(236223922195),
//--TRIMMABLE-BOUNDARY-START(240518889491),
    {
      "r": 65537,
      "n": "WriteEndOfContents",
      "d": 720915,
      "h": 240518889491,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(240518889491),
//--TRIMMABLE-BOUNDARY-START(167504445459),
    {
      "r": 851987,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "tagType",
          "p": 1572883
        }
      ],
      "n": "PushTag",
      "d": 720915,
      "h": 167504445459,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167504445459),
//--TRIMMABLE-BOUNDARY-START(141734641683),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": 65555
        },
        {
          "n": "tagType",
          "p": 1572883
        },
        {
          "n": "sortContents",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "PopTag",
      "d": 720915,
      "h": 141734641683,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141734641683),
//--TRIMMABLE-BOUNDARY-START(180389347347),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        }
      ],
      "n": "SortContents",
      "d": 720915,
      "h": 180389347347,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(180389347347),
//--TRIMMABLE-BOUNDARY-START(38655426579),
    {
      "r": 65537,
      "p": [
        {
          "n": "tag",
          "p": $.$typeNullable($.$sfa.SFA.Asn1Tag).$h
        },
        {
          "n": "universalTagNumber",
          "p": 1572883
        }
      ],
      "n": "CheckUniversalTag",
      "d": 720915,
      "h": 38655426579,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38655426579)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688211),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_buffer",
      "d": 720915,
      "h": 4295688211,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688211),
//--TRIMMABLE-BOUNDARY-START(17180590099),
    {
      "t": 655361,
      "n": "_offset",
      "d": 720915,
      "h": 17180590099,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590099),
//--TRIMMABLE-BOUNDARY-START(12885622803),
    {
      "t": $.$sc.SCG.Stack$$($.$sfa.SFA.AsnWriter.StackFrame).$h,
      "n": "_nestingStack",
      "d": 720915,
      "h": 12885622803,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622803),
//--TRIMMABLE-BOUNDARY-START(8590655507),
    {
      "t": 655361,
      "n": "_encodeDepth",
      "d": 720915,
      "h": 8590655507,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655507)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065491987),
    {
      "p": [
        {
          "n": "ruleSet",
          "p": 524307
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720915,
      "h": 30065491987,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065491987),
//--TRIMMABLE-BOUNDARY-START(25770524691),
    {
      "p": [
        {
          "n": "ruleSet",
          "p": 524307
        },
        {
          "n": "initialCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720915,
      "h": 25770524691,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770524691)
  ],
  "h": 720915
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sfa.SFA.AsnWriter.ArrayIndexSetOfValueComparer, $.$sfa.SFA.AsnWriter.StackFrame, $.$sfa.SFA.AsnWriter.Scope ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.AsnWriter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}AsnWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720915)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966099)
        $asm.$cls(`$sfa.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(562642681875)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(562642681875)
            
            //--TRIMMABLE-BOUNDARY-START(554052747283)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(554052747283)
            
            //--TRIMMABLE-BOUNDARY-START(558347714579)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536872878099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$sfa.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.Formats.Asn1", $.$sfa.S.SR.$type.Assembly);
                    $.$sfa.S.SR.s_resourceManager = temp;
                }
                return $.$sfa.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(558347714579)
            
            //--TRIMMABLE-BOUNDARY-START(158915756051)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528282943507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575527583763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sfa.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(158915756051)
            
            //--TRIMMABLE-BOUNDARY-START(8591900691)
            static /*string */ get Argument_DestinationTooShort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635232787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Destination is too short.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591900691)
            
            //--TRIMMABLE-BOUNDARY-START(17181835283)
            static /*string */ get Argument_EnumeratedValueRequiresNonFlagsEnum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815101971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "ASN.1 Enumerated values only apply to enum types without the [Flags] attribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(17181835283)
            
            //--TRIMMABLE-BOUNDARY-START(12886867987)
            static /*string */ get Argument_EnumeratedValueBackingTypeNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225167379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Enumerations with a backing type of '{0}' are not supported for ReadEnumeratedValue.";
            }
            //--TRIMMABLE-BOUNDARY-END(12886867987)
            
            //--TRIMMABLE-BOUNDARY-START(197570461715)
            static /*string */ FormatArgument_EnumeratedValueBackingTypeNotSupported(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570461715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Enumerations with a backing type of '{0}' are not supported for ReadEnumeratedValue.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(197570461715)
            
            //--TRIMMABLE-BOUNDARY-START(30066737171)
            static /*string */ get Argument_InvalidOidValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584905747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The OID value is invalid.";
            }
            //--TRIMMABLE-BOUNDARY-END(30066737171)
            
            //--TRIMMABLE-BOUNDARY-START(34361704467)
            static /*string */ get Argument_NamedBitListRequiresFlagsEnum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174840339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Named bit list operations require an enum with the [Flags] attribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(34361704467)
            
            //--TRIMMABLE-BOUNDARY-START(38656671763)
            static /*string */ get Argument_SourceOverlapsDestination()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764774931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The destination buffer overlaps the source buffer.";
            }
            //--TRIMMABLE-BOUNDARY-END(38656671763)
            
            //--TRIMMABLE-BOUNDARY-START(42951639059)
            static /*string */ get Argument_Tag_NotCharacterString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354709523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified tag has the Universal TagClass, but the TagValue does not correspond with a known character string type.";
            }
            //--TRIMMABLE-BOUNDARY-END(42951639059)
            
            //--TRIMMABLE-BOUNDARY-START(21476802579)
            static /*string */ get Argument_IntegerCannotBeEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405036563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An integer value cannot be empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(21476802579)
            
            //--TRIMMABLE-BOUNDARY-START(25771769875)
            static /*string */ get Argument_IntegerRedundantByte()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994971155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The first 9 bits of the integer value all have the same value. Ensure the input is in big-endian byte order and that all redundant leading bytes have been removed.";
            }
            //--TRIMMABLE-BOUNDARY-END(25771769875)
            
            //--TRIMMABLE-BOUNDARY-START(47246606355)
            static /*string */ get Argument_UniversalValueIsFixed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304944644115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Tags with TagClass Universal must have the appropriate TagValue value for the data type being read or written.";
            }
            //--TRIMMABLE-BOUNDARY-END(47246606355)
            
            //--TRIMMABLE-BOUNDARY-START(51541573651)
            static /*string */ get Argument_UnusedBitCountMustBeZero()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313534578707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unused bit count must be 0 when the bit string is empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(51541573651)
            
            //--TRIMMABLE-BOUNDARY-START(55836540947)
            static /*string */ get Argument_UnusedBitCountRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124513299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unused bit count must be between 0 and 7, inclusive.";
            }
            //--TRIMMABLE-BOUNDARY-END(55836540947)
            
            //--TRIMMABLE-BOUNDARY-START(60131508243)
            static /*string */ get Argument_UnusedBitWasSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714447891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "One or more of the bits covered by the provided unusedBitCount value is set. All unused bits must be cleared.";
            }
            //--TRIMMABLE-BOUNDARY-END(60131508243)
            
            //--TRIMMABLE-BOUNDARY-START(64426475539)
            static /*string */ get Argument_WriteEncodedValue_OneValueAtATime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304382483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The input to WriteEncodedValue must represent a single encoded value with no trailing data.";
            }
            //--TRIMMABLE-BOUNDARY-END(64426475539)
            
            //--TRIMMABLE-BOUNDARY-START(68721442835)
            static /*string */ get ArgumentOutOfRange_NeedNonNegNum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894317075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Non-negative number required.";
            }
            //--TRIMMABLE-BOUNDARY-END(68721442835)
            
            //--TRIMMABLE-BOUNDARY-START(73016410131)
            static /*string */ get AsnWriter_EncodeUnbalancedStack()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356484251667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Encode cannot be called while a Sequence, Set-Of, or Octet String is still open.";
            }
            //--TRIMMABLE-BOUNDARY-END(73016410131)
            
            //--TRIMMABLE-BOUNDARY-START(77311377427)
            static /*string */ get AsnWriter_ModifyingWhileEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365074186259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The AsnWriter cannot be written to while performing the Encode callback.";
            }
            //--TRIMMABLE-BOUNDARY-END(77311377427)
            
            //--TRIMMABLE-BOUNDARY-START(81606344723)
            static /*string */ get AsnWriter_PopWrongTag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373664120851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot pop the requested tag as it is not currently in progress.";
            }
            //--TRIMMABLE-BOUNDARY-END(81606344723)
            
            //--TRIMMABLE-BOUNDARY-START(85901312019)
            static /*string */ get ContentException_CerRequiresIndefiniteLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382254055443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A constructed tag used a definite length encoding, which is invalid for CER data. The input may be encoded with BER or DER.";
            }
            //--TRIMMABLE-BOUNDARY-END(85901312019)
            
            //--TRIMMABLE-BOUNDARY-START(90196279315)
            static /*string */ get ContentException_ConstructedEncodingRequired()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390843990035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded value uses a primitive encoding, which is invalid for '{0}' values.";
            }
            //--TRIMMABLE-BOUNDARY-END(90196279315)
            
            //--TRIMMABLE-BOUNDARY-START(201865429011)
            static /*string */ FormatContentException_ConstructedEncodingRequired(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865429011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The encoded value uses a primitive encoding, which is invalid for '{0}' values.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(201865429011)
            
            //--TRIMMABLE-BOUNDARY-START(94491246611)
            static /*string */ get ContentException_DefaultMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399433924627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The ASN.1 value is invalid.";
            }
            //--TRIMMABLE-BOUNDARY-END(94491246611)
            
            //--TRIMMABLE-BOUNDARY-START(98786213907)
            static /*string */ get ContentException_EnumeratedValueTooBig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408023859219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded enumerated value is larger than the value size of the '{0}' enum.";
            }
            //--TRIMMABLE-BOUNDARY-END(98786213907)
            
            //--TRIMMABLE-BOUNDARY-START(206160396307)
            static /*string */ FormatContentException_EnumeratedValueTooBig(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160396307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The encoded enumerated value is larger than the value size of the '{0}' enum.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(206160396307)
            
            //--TRIMMABLE-BOUNDARY-START(107376148499)
            static /*string */ get ContentException_InvalidUnderCer_TryBerOrDer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425203728403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded value is not valid under the selected encoding, but it may be valid under the BER or DER encoding.";
            }
            //--TRIMMABLE-BOUNDARY-END(107376148499)
            
            //--TRIMMABLE-BOUNDARY-START(111671115795)
            static /*string */ get ContentException_InvalidUnderCerOrDer_TryBer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433793662995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded value is not valid under the selected encoding, but it may be valid under the BER encoding.";
            }
            //--TRIMMABLE-BOUNDARY-END(111671115795)
            
            //--TRIMMABLE-BOUNDARY-START(115966083091)
            static /*string */ get ContentException_InvalidUnderDer_TryBerOrCer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442383597587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded value is not valid under the selected encoding, but it may be valid under the BER or CER encoding.";
            }
            //--TRIMMABLE-BOUNDARY-END(115966083091)
            
            //--TRIMMABLE-BOUNDARY-START(103081181203)
            static /*string */ get ContentException_InvalidTag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416613793811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The provided data does not represent a valid tag.";
            }
            //--TRIMMABLE-BOUNDARY-END(103081181203)
            
            //--TRIMMABLE-BOUNDARY-START(120261050387)
            static /*string */ get ContentException_LengthExceedsPayload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450973532179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded length exceeds the number of bytes remaining in the input buffer.";
            }
            //--TRIMMABLE-BOUNDARY-END(120261050387)
            
            //--TRIMMABLE-BOUNDARY-START(124556017683)
            static /*string */ get ContentException_LengthRuleSetConstraint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459563466771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded length is not valid under the requested encoding rules, the value may be valid under the BER encoding.";
            }
            //--TRIMMABLE-BOUNDARY-END(124556017683)
            
            //--TRIMMABLE-BOUNDARY-START(128850984979)
            static /*string */ get ContentException_LengthTooBig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468153401363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded length exceeds the maximum supported by this library (Int32.MaxValue).";
            }
            //--TRIMMABLE-BOUNDARY-END(128850984979)
            
            //--TRIMMABLE-BOUNDARY-START(133145952275)
            static /*string */ get ContentException_NamedBitListValueTooBig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476743335955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded named bit list value is larger than the value size of the '{0}' enum.";
            }
            //--TRIMMABLE-BOUNDARY-END(133145952275)
            
            //--TRIMMABLE-BOUNDARY-START(210455363603)
            static /*string */ FormatContentException_NamedBitListValueTooBig(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455363603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The encoded named bit list value is larger than the value size of the '{0}' enum.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(210455363603)
            
            //--TRIMMABLE-BOUNDARY-START(137440919571)
            static /*string */ get ContentException_OidTooBig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485333270547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded object identifier (OID) exceeds the limits supported by this library. Supported OIDs are limited to 64 arcs and each subidentifier is limited to a 128-bit value.";
            }
            //--TRIMMABLE-BOUNDARY-END(137440919571)
            
            //--TRIMMABLE-BOUNDARY-START(141735886867)
            static /*string */ get ContentException_PrimitiveEncodingRequired()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493923205139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded value uses a constructed encoding, which is invalid for '{0}' values.";
            }
            //--TRIMMABLE-BOUNDARY-END(141735886867)
            
            //--TRIMMABLE-BOUNDARY-START(214750330899)
            static /*string */ FormatContentException_PrimitiveEncodingRequired(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750330899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The encoded value uses a constructed encoding, which is invalid for '{0}' values.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(214750330899)
            
            //--TRIMMABLE-BOUNDARY-START(146030854163)
            static /*string */ get ContentException_SetOfNotSorted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502513139731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded set is not sorted as required by the current encoding rules. The value may be valid under the BER encoding, or you can ignore the sort validation by specifying skipSortValidation=true.";
            }
            //--TRIMMABLE-BOUNDARY-END(146030854163)
            
            //--TRIMMABLE-BOUNDARY-START(150325821459)
            static /*string */ get ContentException_TooMuchData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511103074323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The last expected value has been read, but the reader still has pending data. This value may be from a newer schema, or is corrupt.";
            }
            //--TRIMMABLE-BOUNDARY-END(150325821459)
            
            //--TRIMMABLE-BOUNDARY-START(154620788755)
            static /*string */ get ContentException_WrongTag()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519693008915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The provided data is tagged with '{0}' class value '{1}', but it should have been '{2}' class value '{3}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(154620788755)
            
            //--TRIMMABLE-BOUNDARY-START(219045298195)
            static /*string */ FormatContentException_WrongTag(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045298195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$11("The provided data is tagged with '{0}' class value '{1}', but it should have been '{2}' class value '{3}'.", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ arg1, arg2, arg3, arg4 ]));
            }
            //--TRIMMABLE-BOUNDARY-END(219045298195)
            
            //--TRIMMABLE-BOUNDARY-START(566937649171)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(566937649171)
            
            //--TRIMMABLE-BOUNDARY-START(549757779987)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(549757779987);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(549757779987)
            
            //--TRIMMABLE-BOUNDARY-START(579822551059)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(579822551059);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sfa.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(579822551059)
            
            //--TRIMMABLE-BOUNDARY-START(545462812691)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545462812691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sfa.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(545462812691)
            
            //--TRIMMABLE-BOUNDARY-START(541167845395)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541167845395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sfa.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(541167845395)
            
            //--TRIMMABLE-BOUNDARY-START(188980527123)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980527123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(188980527123)
            
            //--TRIMMABLE-BOUNDARY-START(184685559827)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685559827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(184685559827)
            
            //--TRIMMABLE-BOUNDARY-START(180390592531)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390592531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(180390592531)
            
            //--TRIMMABLE-BOUNDARY-START(193275494419)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275494419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sfa.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(193275494419)
            
            //--TRIMMABLE-BOUNDARY-START(171800657939)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800657939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(171800657939)
            
            //--TRIMMABLE-BOUNDARY-START(167505690643)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505690643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(167505690643)
            
            //--TRIMMABLE-BOUNDARY-START(163210723347)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210723347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(163210723347)
            
            //--TRIMMABLE-BOUNDARY-START(176095625235)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095625235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sfa.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(176095625235)
            
            //--TRIMMABLE-BOUNDARY-START(4296933395)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296933395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(566937649171)
                    this.s_usingResourceKeys = $.$sfa.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(566937649171)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296933395)
            
            static $h = 1966099;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1966099
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966099)
        
        

        //--TRIMMABLE-BOUNDARY-START(131091)
        $asm.$cls(`$sfa.SFA.AsnCharacterStringEncodings`, ($self) => class AsnCharacterStringEncodings
        {
            //--TRIMMABLE-BOUNDARY-START(42949804051)
            /*UTF8Encoding*/ static s_utf8Encoding = null;
            //--TRIMMABLE-BOUNDARY-END(42949804051)
            
            //--TRIMMABLE-BOUNDARY-START(21474967571)
            /*BMPEncoding*/ static s_bmpEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(21474967571)
            
            //--TRIMMABLE-BOUNDARY-START(25769934867)
            /*IA5Encoding*/ static s_ia5Encoding = null;
            //--TRIMMABLE-BOUNDARY-END(25769934867)
            
            //--TRIMMABLE-BOUNDARY-START(47244771347)
            /*VisibleStringEncoding*/ static s_visibleStringEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(47244771347)
            
            //--TRIMMABLE-BOUNDARY-START(30064902163)
            /*NumericStringEncoding*/ static s_numericStringEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(30064902163)
            
            //--TRIMMABLE-BOUNDARY-START(34359869459)
            /*PrintableStringEncoding*/ static s_printableStringEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(34359869459)
            
            //--TRIMMABLE-BOUNDARY-START(38654836755)
            /*T61Encoding*/ static s_t61Encoding = null;
            //--TRIMMABLE-BOUNDARY-END(38654836755)
            
            //--TRIMMABLE-BOUNDARY-START(17180000275)
            static /*Encoding */ GetEncoding(/*UniversalTagNumber*/ encodingType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180000275);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        if (encodingType === 12/*UniversalTagNumber.UTF8String*/)
                        {
                            return $.$sfa.SFA.AsnCharacterStringEncodings.s_utf8Encoding;
                        }
                        if (encodingType === 18/*UniversalTagNumber.NumericString*/)
                        {
                            return $.$sfa.SFA.AsnCharacterStringEncodings.s_numericStringEncoding;
                        }
                        if (encodingType === 19/*UniversalTagNumber.PrintableString*/)
                        {
                            return $.$sfa.SFA.AsnCharacterStringEncodings.s_printableStringEncoding;
                        }
                        if (encodingType === 22/*UniversalTagNumber.IA5String*/)
                        {
                            return $.$sfa.SFA.AsnCharacterStringEncodings.s_ia5Encoding;
                        }
                        if (encodingType === 26/*UniversalTagNumber.VisibleString*/)
                        {
                            return $.$sfa.SFA.AsnCharacterStringEncodings.s_visibleStringEncoding;
                        }
                        if (encodingType === 30/*UniversalTagNumber.BMPString*/)
                        {
                            return $.$sfa.SFA.AsnCharacterStringEncodings.s_bmpEncoding;
                        }
                        if (encodingType === 20/*UniversalTagNumber.T61String*/)
                        {
                            return $.$sfa.SFA.AsnCharacterStringEncodings.s_t61Encoding;
                        }
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("encodingType", $.$box(encodingType, $.$sfa.SFA.UniversalTagNumber), null);
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180000275)
            
            //--TRIMMABLE-BOUNDARY-START(8590065683)
            static /*int */ GetByteCount(/*this Encoding*/ encoding, /*ReadOnlySpan<char>*/ str)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (str.IsEmpty)
                {
                    str = $.$$.S.MemoryExtensions.AsSpan$4($.$$.S.String.Empty);
                }
                {
                    /*fixed*/ 
                    {
                        /*char**/ let strPtr = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Char, str);
                        return encoding.GetByteCount$3(strPtr, str.Length);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590065683)
            
            //--TRIMMABLE-BOUNDARY-START(12885032979)
            static /*int */ GetBytes(/*this Encoding*/ encoding, /*ReadOnlySpan<char>*/ chars, /*Span<byte>*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885032979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (chars.IsEmpty)
                {
                    chars = $.$$.S.MemoryExtensions.AsSpan$4($.$$.S.String.Empty);
                }
                if (bytes.IsEmpty)
                {
                    bytes = $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2($.$$.S.Array.Empty($.$$.S.Byte));
                }
                {
                    /*fixed*/ 
                    {
                        /*char**/ let charsPtr = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Char, chars);
                        /*fixed*/ 
                        {
                            /*byte**/ let bytesPtr = $.$$.SRI.MemoryMarshal.GetReference$1($.$$.S.Byte, bytes);
                            return encoding.GetBytes$4(charsPtr, chars.Length, bytesPtr, bytes.Length);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885032979)
            
            //--TRIMMABLE-BOUNDARY-START(4295098387)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(42949804051)
                    this.s_utf8Encoding = new $.$$.ST.UTF8Encoding().$ctor$5(false, true);
                    //--TRIMMABLE-BOUNDARY-END(42949804051)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474967571)
                    this.s_bmpEncoding = new $.$sfa.SFA.BMPEncoding().$ctor$5();
                    //--TRIMMABLE-BOUNDARY-END(21474967571)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769934867)
                    this.s_ia5Encoding = new $.$sfa.SFA.IA5Encoding().$ctor$7();
                    //--TRIMMABLE-BOUNDARY-END(25769934867)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244771347)
                    this.s_visibleStringEncoding = new $.$sfa.SFA.VisibleStringEncoding().$ctor$7();
                    //--TRIMMABLE-BOUNDARY-END(47244771347)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30064902163)
                    this.s_numericStringEncoding = new $.$sfa.SFA.NumericStringEncoding().$ctor$7();
                    //--TRIMMABLE-BOUNDARY-END(30064902163)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34359869459)
                    this.s_printableStringEncoding = new $.$sfa.SFA.PrintableStringEncoding().$ctor$7();
                    //--TRIMMABLE-BOUNDARY-END(34359869459)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654836755)
                    this.s_t61Encoding = new $.$sfa.SFA.T61Encoding().$ctor$4();
                    //--TRIMMABLE-BOUNDARY-END(38654836755)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295098387)
            
            static $h = 131091;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180000275),
    {
      "r": 166723585,
      "p": [
        {
          "n": "encodingType",
          "p": 1572883
        }
      ],
      "n": "GetEncoding",
      "d": 131091,
      "h": 17180000275,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180000275),
//--TRIMMABLE-BOUNDARY-START(8590065683),
    {
      "r": 655361,
      "p": [
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "str",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "GetByteCount",
      "d": 131091,
      "h": 8590065683,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590065683),
//--TRIMMABLE-BOUNDARY-START(12885032979),
    {
      "r": 655361,
      "p": [
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "chars",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "bytes",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetBytes",
      "d": 131091,
      "h": 12885032979,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885032979)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42949804051),
    {
      "t": 169607169,
      "n": "s_utf8Encoding",
      "d": 131091,
      "h": 42949804051,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42949804051),
//--TRIMMABLE-BOUNDARY-START(21474967571),
    {
      "t": 983059,
      "n": "s_bmpEncoding",
      "d": 131091,
      "h": 21474967571,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21474967571),
//--TRIMMABLE-BOUNDARY-START(25769934867),
    {
      "t": 1048595,
      "n": "s_ia5Encoding",
      "d": 131091,
      "h": 25769934867,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25769934867),
//--TRIMMABLE-BOUNDARY-START(47244771347),
    {
      "t": 1638419,
      "n": "s_visibleStringEncoding",
      "d": 131091,
      "h": 47244771347,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47244771347),
//--TRIMMABLE-BOUNDARY-START(30064902163),
    {
      "t": 1114131,
      "n": "s_numericStringEncoding",
      "d": 131091,
      "h": 30064902163,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30064902163),
//--TRIMMABLE-BOUNDARY-START(34359869459),
    {
      "t": 1179667,
      "n": "s_printableStringEncoding",
      "d": 131091,
      "h": 34359869459,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34359869459),
//--TRIMMABLE-BOUNDARY-START(38654836755),
    {
      "t": 1441811,
      "n": "s_t61Encoding",
      "d": 131091,
      "h": 38654836755,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38654836755)
  ],
  "h": 131091
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.AsnCharacterStringEncodings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}AsnCharacterStringEncodings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131091)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769491)
        $asm.$cls(`$sfa.S.Obsoletions`, ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382253858835)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382253858835)
            
            //--TRIMMABLE-BOUNDARY-START(433793466387)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433793466387)
            
            //--TRIMMABLE-BOUNDARY-START(429498499091)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429498499091)
            
            //--TRIMMABLE-BOUNDARY-START(266289741843)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266289741843)
            
            //--TRIMMABLE-BOUNDARY-START(261994774547)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261994774547)
            
            //--TRIMMABLE-BOUNDARY-START(77311180819)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77311180819)
            
            //--TRIMMABLE-BOUNDARY-START(73016213523)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73016213523)
            
            //--TRIMMABLE-BOUNDARY-START(94491050003)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94491050003)
            
            //--TRIMMABLE-BOUNDARY-START(90196082707)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90196082707)
            
            //--TRIMMABLE-BOUNDARY-START(214750134291)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214750134291)
            
            //--TRIMMABLE-BOUNDARY-START(210455166995)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210455166995)
            
            //--TRIMMABLE-BOUNDARY-START(442383400979)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442383400979)
            
            //--TRIMMABLE-BOUNDARY-START(446678368275)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446678368275)
            
            //--TRIMMABLE-BOUNDARY-START(438088433683)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438088433683)
            
            //--TRIMMABLE-BOUNDARY-START(146030657555)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146030657555)
            
            //--TRIMMABLE-BOUNDARY-START(141735690259)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141735690259)
            
            //--TRIMMABLE-BOUNDARY-START(120260853779)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120260853779)
            
            //--TRIMMABLE-BOUNDARY-START(115965886483)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115965886483)
            
            //--TRIMMABLE-BOUNDARY-START(51541377043)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51541377043)
            
            //--TRIMMABLE-BOUNDARY-START(47246409747)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47246409747)
            
            //--TRIMMABLE-BOUNDARY-START(326419283987)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326419283987)
            
            //--TRIMMABLE-BOUNDARY-START(322124316691)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322124316691)
            
            //--TRIMMABLE-BOUNDARY-START(60131311635)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60131311635)
            
            //--TRIMMABLE-BOUNDARY-START(55836344339)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55836344339)
            
            //--TRIMMABLE-BOUNDARY-START(85901115411)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85901115411)
            
            //--TRIMMABLE-BOUNDARY-START(81606148115)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81606148115)
            
            //--TRIMMABLE-BOUNDARY-START(197570265107)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197570265107)
            
            //--TRIMMABLE-BOUNDARY-START(193275297811)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193275297811)
            
            //--TRIMMABLE-BOUNDARY-START(489628041235)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489628041235)
            
            //--TRIMMABLE-BOUNDARY-START(485333073939)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485333073939)
            
            //--TRIMMABLE-BOUNDARY-START(163210526739)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163210526739)
            
            //--TRIMMABLE-BOUNDARY-START(158915559443)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158915559443)
            
            //--TRIMMABLE-BOUNDARY-START(206160199699)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206160199699)
            
            //--TRIMMABLE-BOUNDARY-START(201865232403)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201865232403)
            
            //--TRIMMABLE-BOUNDARY-START(399433728019)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399433728019)
            
            //--TRIMMABLE-BOUNDARY-START(395138760723)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395138760723)
            
            //--TRIMMABLE-BOUNDARY-START(300649480211)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300649480211)
            
            //--TRIMMABLE-BOUNDARY-START(296354512915)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296354512915)
            
            //--TRIMMABLE-BOUNDARY-START(377958891539)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377958891539)
            
            //--TRIMMABLE-BOUNDARY-START(373663924243)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373663924243)
            
            //--TRIMMABLE-BOUNDARY-START(231930003475)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231930003475)
            
            //--TRIMMABLE-BOUNDARY-START(227635036179)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227635036179)
            
            //--TRIMMABLE-BOUNDARY-START(154620592147)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154620592147)
            
            //--TRIMMABLE-BOUNDARY-START(150325624851)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150325624851)
            
            //--TRIMMABLE-BOUNDARY-START(352189087763)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352189087763)
            
            //--TRIMMABLE-BOUNDARY-START(347894120467)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347894120467)
            
            //--TRIMMABLE-BOUNDARY-START(360779022355)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360779022355)
            
            //--TRIMMABLE-BOUNDARY-START(356484055059)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356484055059)
            
            //--TRIMMABLE-BOUNDARY-START(17181638675)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17181638675)
            
            //--TRIMMABLE-BOUNDARY-START(12886671379)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12886671379)
            
            //--TRIMMABLE-BOUNDARY-START(408023662611)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408023662611)
            
            //--TRIMMABLE-BOUNDARY-START(403728695315)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403728695315)
            
            //--TRIMMABLE-BOUNDARY-START(498217975827)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498217975827)
            
            //--TRIMMABLE-BOUNDARY-START(493923008531)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493923008531)
            
            //--TRIMMABLE-BOUNDARY-START(283469611027)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283469611027)
            
            //--TRIMMABLE-BOUNDARY-START(279174643731)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279174643731)
            
            //--TRIMMABLE-BOUNDARY-START(506807910419)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506807910419)
            
            //--TRIMMABLE-BOUNDARY-START(502512943123)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502512943123)
            
            //--TRIMMABLE-BOUNDARY-START(274879676435)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274879676435)
            
            //--TRIMMABLE-BOUNDARY-START(270584709139)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270584709139)
            
            //--TRIMMABLE-BOUNDARY-START(481038106643)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481038106643)
            
            //--TRIMMABLE-BOUNDARY-START(476743139347)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476743139347)
            
            //--TRIMMABLE-BOUNDARY-START(128850788371)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128850788371)
            
            //--TRIMMABLE-BOUNDARY-START(124555821075)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124555821075)
            
            //--TRIMMABLE-BOUNDARY-START(111670919187)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111670919187)
            
            //--TRIMMABLE-BOUNDARY-START(107375951891)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107375951891)
            
            //--TRIMMABLE-BOUNDARY-START(335009218579)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335009218579)
            
            //--TRIMMABLE-BOUNDARY-START(330714251283)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330714251283)
            
            //--TRIMMABLE-BOUNDARY-START(68721246227)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68721246227)
            
            //--TRIMMABLE-BOUNDARY-START(64426278931)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64426278931)
            
            //--TRIMMABLE-BOUNDARY-START(390843793427)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390843793427)
            
            //--TRIMMABLE-BOUNDARY-START(386548826131)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386548826131)
            
            //--TRIMMABLE-BOUNDARY-START(309239414803)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309239414803)
            
            //--TRIMMABLE-BOUNDARY-START(304944447507)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304944447507)
            
            //--TRIMMABLE-BOUNDARY-START(42951442451)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42951442451)
            
            //--TRIMMABLE-BOUNDARY-START(38656475155)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38656475155)
            
            //--TRIMMABLE-BOUNDARY-START(416613597203)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416613597203)
            
            //--TRIMMABLE-BOUNDARY-START(412318629907)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412318629907)
            
            //--TRIMMABLE-BOUNDARY-START(472448172051)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472448172051)
            
            //--TRIMMABLE-BOUNDARY-START(468153204755)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468153204755)
            
            //--TRIMMABLE-BOUNDARY-START(188980330515)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188980330515)
            
            //--TRIMMABLE-BOUNDARY-START(184685363219)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184685363219)
            
            //--TRIMMABLE-BOUNDARY-START(171800461331)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171800461331)
            
            //--TRIMMABLE-BOUNDARY-START(167505494035)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167505494035)
            
            //--TRIMMABLE-BOUNDARY-START(180390395923)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180390395923)
            
            //--TRIMMABLE-BOUNDARY-START(176095428627)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176095428627)
            
            //--TRIMMABLE-BOUNDARY-START(34361507859)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34361507859)
            
            //--TRIMMABLE-BOUNDARY-START(30066540563)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30066540563)
            
            //--TRIMMABLE-BOUNDARY-START(137440722963)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137440722963)
            
            //--TRIMMABLE-BOUNDARY-START(133145755667)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133145755667)
            
            //--TRIMMABLE-BOUNDARY-START(103080984595)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103080984595)
            
            //--TRIMMABLE-BOUNDARY-START(98786017299)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98786017299)
            
            //--TRIMMABLE-BOUNDARY-START(523987779603)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523987779603)
            
            //--TRIMMABLE-BOUNDARY-START(519692812307)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519692812307)
            
            //--TRIMMABLE-BOUNDARY-START(369368956947)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369368956947)
            
            //--TRIMMABLE-BOUNDARY-START(365073989651)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365073989651)
            
            //--TRIMMABLE-BOUNDARY-START(223340068883)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223340068883)
            
            //--TRIMMABLE-BOUNDARY-START(219045101587)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219045101587)
            
            //--TRIMMABLE-BOUNDARY-START(249109872659)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249109872659)
            
            //--TRIMMABLE-BOUNDARY-START(236224970771)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236224970771)
            
            //--TRIMMABLE-BOUNDARY-START(244814905363)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244814905363)
            
            //--TRIMMABLE-BOUNDARY-START(240519938067)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240519938067)
            
            //--TRIMMABLE-BOUNDARY-START(317829349395)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317829349395)
            
            //--TRIMMABLE-BOUNDARY-START(313534382099)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313534382099)
            
            //--TRIMMABLE-BOUNDARY-START(8591704083)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8591704083)
            
            //--TRIMMABLE-BOUNDARY-START(4296736787)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4296736787)
            
            //--TRIMMABLE-BOUNDARY-START(455268302867)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455268302867)
            
            //--TRIMMABLE-BOUNDARY-START(450973335571)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450973335571)
            
            //--TRIMMABLE-BOUNDARY-START(25771573267)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25771573267)
            
            //--TRIMMABLE-BOUNDARY-START(21476605971)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21476605971)
            
            //--TRIMMABLE-BOUNDARY-START(257699807251)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257699807251)
            
            //--TRIMMABLE-BOUNDARY-START(253404839955)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253404839955)
            
            //--TRIMMABLE-BOUNDARY-START(515397845011)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515397845011)
            
            //--TRIMMABLE-BOUNDARY-START(511102877715)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511102877715)
            
            //--TRIMMABLE-BOUNDARY-START(463858237459)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463858237459)
            
            //--TRIMMABLE-BOUNDARY-START(459563270163)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459563270163)
            
            //--TRIMMABLE-BOUNDARY-START(425203531795)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425203531795)
            
            //--TRIMMABLE-BOUNDARY-START(420908564499)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420908564499)
            
            //--TRIMMABLE-BOUNDARY-START(343599153171)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343599153171)
            
            //--TRIMMABLE-BOUNDARY-START(339304185875)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339304185875)
            
            //--TRIMMABLE-BOUNDARY-START(292059545619)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292059545619)
            
            //--TRIMMABLE-BOUNDARY-START(287764578323)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287764578323)
            
            //--TRIMMABLE-BOUNDARY-START(532577714195)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532577714195)
            
            //--TRIMMABLE-BOUNDARY-START(528282746899)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528282746899)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382253858835)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382253858835)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433793466387)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433793466387)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429498499091)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429498499091)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266289741843)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266289741843)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261994774547)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261994774547)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77311180819)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77311180819)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73016213523)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73016213523)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94491050003)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94491050003)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90196082707)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90196082707)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214750134291)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214750134291)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210455166995)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210455166995)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442383400979)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442383400979)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446678368275)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446678368275)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438088433683)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438088433683)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146030657555)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146030657555)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141735690259)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141735690259)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120260853779)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120260853779)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115965886483)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115965886483)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51541377043)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51541377043)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47246409747)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47246409747)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326419283987)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326419283987)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322124316691)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322124316691)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60131311635)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60131311635)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55836344339)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55836344339)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85901115411)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85901115411)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81606148115)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81606148115)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197570265107)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197570265107)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193275297811)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193275297811)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489628041235)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489628041235)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485333073939)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485333073939)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163210526739)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163210526739)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158915559443)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158915559443)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206160199699)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206160199699)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201865232403)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201865232403)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399433728019)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399433728019)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395138760723)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395138760723)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300649480211)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300649480211)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296354512915)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296354512915)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377958891539)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377958891539)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373663924243)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373663924243)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231930003475)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231930003475)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227635036179)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227635036179)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154620592147)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154620592147)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150325624851)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150325624851)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352189087763)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352189087763)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347894120467)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347894120467)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360779022355)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360779022355)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356484055059)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356484055059)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181638675)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17181638675)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886671379)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12886671379)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408023662611)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408023662611)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403728695315)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403728695315)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498217975827)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498217975827)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493923008531)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493923008531)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283469611027)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283469611027)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279174643731)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279174643731)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506807910419)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506807910419)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502512943123)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502512943123)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274879676435)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274879676435)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270584709139)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270584709139)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481038106643)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481038106643)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476743139347)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476743139347)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128850788371)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128850788371)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124555821075)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124555821075)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111670919187)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111670919187)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107375951891)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107375951891)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335009218579)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335009218579)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330714251283)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330714251283)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68721246227)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68721246227)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64426278931)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64426278931)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390843793427)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390843793427)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386548826131)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386548826131)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309239414803)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309239414803)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304944447507)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304944447507)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42951442451)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42951442451)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38656475155)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38656475155)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416613597203)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416613597203)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412318629907)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412318629907)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472448172051)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472448172051)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468153204755)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468153204755)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188980330515)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188980330515)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184685363219)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184685363219)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171800461331)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171800461331)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167505494035)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167505494035)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180390395923)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180390395923)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176095428627)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176095428627)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34361507859)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34361507859)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30066540563)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30066540563)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137440722963)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137440722963)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133145755667)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133145755667)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103080984595)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103080984595)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98786017299)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98786017299)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523987779603)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523987779603)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519692812307)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519692812307)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369368956947)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369368956947)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365073989651)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365073989651)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223340068883)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223340068883)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219045101587)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219045101587)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249109872659)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249109872659)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236224970771)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236224970771)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244814905363)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244814905363)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240519938067)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240519938067)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317829349395)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317829349395)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313534382099)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313534382099)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591704083)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8591704083)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4296736787)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4296736787)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455268302867)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455268302867)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450973335571)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450973335571)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771573267)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25771573267)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476605971)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21476605971)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257699807251)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257699807251)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253404839955)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253404839955)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515397845011)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515397845011)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511102877715)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511102877715)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463858237459)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463858237459)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459563270163)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459563270163)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425203531795)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425203531795)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420908564499)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420908564499)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343599153171)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343599153171)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339304185875)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339304185875)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292059545619)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292059545619)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287764578323)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287764578323)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532577714195)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532577714195)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528282746899)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528282746899)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 1769491;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(382253858835),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 1769491,
      "h": 382253858835,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382253858835),
//--TRIMMABLE-BOUNDARY-START(433793466387),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 1769491,
      "h": 433793466387,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433793466387),
//--TRIMMABLE-BOUNDARY-START(429498499091),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 1769491,
      "h": 429498499091,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429498499091),
//--TRIMMABLE-BOUNDARY-START(266289741843),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 1769491,
      "h": 266289741843,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266289741843),
//--TRIMMABLE-BOUNDARY-START(261994774547),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 1769491,
      "h": 261994774547,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261994774547),
//--TRIMMABLE-BOUNDARY-START(77311180819),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 1769491,
      "h": 77311180819,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77311180819),
//--TRIMMABLE-BOUNDARY-START(73016213523),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 1769491,
      "h": 73016213523,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73016213523),
//--TRIMMABLE-BOUNDARY-START(94491050003),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 1769491,
      "h": 94491050003,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94491050003),
//--TRIMMABLE-BOUNDARY-START(90196082707),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 1769491,
      "h": 90196082707,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90196082707),
//--TRIMMABLE-BOUNDARY-START(214750134291),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 1769491,
      "h": 214750134291,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214750134291),
//--TRIMMABLE-BOUNDARY-START(210455166995),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 1769491,
      "h": 210455166995,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210455166995),
//--TRIMMABLE-BOUNDARY-START(442383400979),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 1769491,
      "h": 442383400979,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442383400979),
//--TRIMMABLE-BOUNDARY-START(446678368275),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 1769491,
      "h": 446678368275,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446678368275),
//--TRIMMABLE-BOUNDARY-START(438088433683),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 1769491,
      "h": 438088433683,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438088433683),
//--TRIMMABLE-BOUNDARY-START(146030657555),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 1769491,
      "h": 146030657555,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146030657555),
//--TRIMMABLE-BOUNDARY-START(141735690259),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 1769491,
      "h": 141735690259,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141735690259),
//--TRIMMABLE-BOUNDARY-START(120260853779),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 1769491,
      "h": 120260853779,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120260853779),
//--TRIMMABLE-BOUNDARY-START(115965886483),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 1769491,
      "h": 115965886483,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115965886483),
//--TRIMMABLE-BOUNDARY-START(51541377043),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 1769491,
      "h": 51541377043,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51541377043),
//--TRIMMABLE-BOUNDARY-START(47246409747),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 1769491,
      "h": 47246409747,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47246409747),
//--TRIMMABLE-BOUNDARY-START(326419283987),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 1769491,
      "h": 326419283987,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326419283987),
//--TRIMMABLE-BOUNDARY-START(322124316691),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 1769491,
      "h": 322124316691,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322124316691),
//--TRIMMABLE-BOUNDARY-START(60131311635),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 1769491,
      "h": 60131311635,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60131311635),
//--TRIMMABLE-BOUNDARY-START(55836344339),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 1769491,
      "h": 55836344339,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55836344339),
//--TRIMMABLE-BOUNDARY-START(85901115411),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 1769491,
      "h": 85901115411,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85901115411),
//--TRIMMABLE-BOUNDARY-START(81606148115),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 1769491,
      "h": 81606148115,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81606148115),
//--TRIMMABLE-BOUNDARY-START(197570265107),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 1769491,
      "h": 197570265107,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197570265107),
//--TRIMMABLE-BOUNDARY-START(193275297811),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 1769491,
      "h": 193275297811,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193275297811),
//--TRIMMABLE-BOUNDARY-START(489628041235),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 1769491,
      "h": 489628041235,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489628041235),
//--TRIMMABLE-BOUNDARY-START(485333073939),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 1769491,
      "h": 485333073939,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485333073939),
//--TRIMMABLE-BOUNDARY-START(163210526739),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 1769491,
      "h": 163210526739,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163210526739),
//--TRIMMABLE-BOUNDARY-START(158915559443),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 1769491,
      "h": 158915559443,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158915559443),
//--TRIMMABLE-BOUNDARY-START(206160199699),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 1769491,
      "h": 206160199699,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206160199699),
//--TRIMMABLE-BOUNDARY-START(201865232403),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 1769491,
      "h": 201865232403,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201865232403),
//--TRIMMABLE-BOUNDARY-START(399433728019),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 1769491,
      "h": 399433728019,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399433728019),
//--TRIMMABLE-BOUNDARY-START(395138760723),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 1769491,
      "h": 395138760723,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395138760723),
//--TRIMMABLE-BOUNDARY-START(300649480211),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 1769491,
      "h": 300649480211,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300649480211),
//--TRIMMABLE-BOUNDARY-START(296354512915),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 1769491,
      "h": 296354512915,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296354512915),
//--TRIMMABLE-BOUNDARY-START(377958891539),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 1769491,
      "h": 377958891539,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377958891539),
//--TRIMMABLE-BOUNDARY-START(373663924243),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 1769491,
      "h": 373663924243,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373663924243),
//--TRIMMABLE-BOUNDARY-START(231930003475),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 1769491,
      "h": 231930003475,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231930003475),
//--TRIMMABLE-BOUNDARY-START(227635036179),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 1769491,
      "h": 227635036179,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227635036179),
//--TRIMMABLE-BOUNDARY-START(154620592147),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 1769491,
      "h": 154620592147,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154620592147),
//--TRIMMABLE-BOUNDARY-START(150325624851),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 1769491,
      "h": 150325624851,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150325624851),
//--TRIMMABLE-BOUNDARY-START(352189087763),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 1769491,
      "h": 352189087763,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352189087763),
//--TRIMMABLE-BOUNDARY-START(347894120467),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 1769491,
      "h": 347894120467,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347894120467),
//--TRIMMABLE-BOUNDARY-START(360779022355),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 1769491,
      "h": 360779022355,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360779022355),
//--TRIMMABLE-BOUNDARY-START(356484055059),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 1769491,
      "h": 356484055059,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356484055059),
//--TRIMMABLE-BOUNDARY-START(17181638675),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 1769491,
      "h": 17181638675,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17181638675),
//--TRIMMABLE-BOUNDARY-START(12886671379),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 1769491,
      "h": 12886671379,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12886671379),
//--TRIMMABLE-BOUNDARY-START(408023662611),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 1769491,
      "h": 408023662611,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408023662611),
//--TRIMMABLE-BOUNDARY-START(403728695315),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 1769491,
      "h": 403728695315,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403728695315),
//--TRIMMABLE-BOUNDARY-START(498217975827),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 1769491,
      "h": 498217975827,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498217975827),
//--TRIMMABLE-BOUNDARY-START(493923008531),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 1769491,
      "h": 493923008531,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493923008531),
//--TRIMMABLE-BOUNDARY-START(283469611027),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 1769491,
      "h": 283469611027,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283469611027),
//--TRIMMABLE-BOUNDARY-START(279174643731),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 1769491,
      "h": 279174643731,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279174643731),
//--TRIMMABLE-BOUNDARY-START(506807910419),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 1769491,
      "h": 506807910419,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506807910419),
//--TRIMMABLE-BOUNDARY-START(502512943123),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 1769491,
      "h": 502512943123,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502512943123),
//--TRIMMABLE-BOUNDARY-START(274879676435),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 1769491,
      "h": 274879676435,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274879676435),
//--TRIMMABLE-BOUNDARY-START(270584709139),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 1769491,
      "h": 270584709139,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270584709139),
//--TRIMMABLE-BOUNDARY-START(481038106643),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 1769491,
      "h": 481038106643,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481038106643),
//--TRIMMABLE-BOUNDARY-START(476743139347),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 1769491,
      "h": 476743139347,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476743139347),
//--TRIMMABLE-BOUNDARY-START(128850788371),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 1769491,
      "h": 128850788371,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128850788371),
//--TRIMMABLE-BOUNDARY-START(124555821075),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 1769491,
      "h": 124555821075,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124555821075),
//--TRIMMABLE-BOUNDARY-START(111670919187),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 1769491,
      "h": 111670919187,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111670919187),
//--TRIMMABLE-BOUNDARY-START(107375951891),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 1769491,
      "h": 107375951891,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107375951891),
//--TRIMMABLE-BOUNDARY-START(335009218579),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 1769491,
      "h": 335009218579,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335009218579),
//--TRIMMABLE-BOUNDARY-START(330714251283),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 1769491,
      "h": 330714251283,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330714251283),
//--TRIMMABLE-BOUNDARY-START(68721246227),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 1769491,
      "h": 68721246227,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68721246227),
//--TRIMMABLE-BOUNDARY-START(64426278931),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 1769491,
      "h": 64426278931,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64426278931),
//--TRIMMABLE-BOUNDARY-START(390843793427),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 1769491,
      "h": 390843793427,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390843793427),
//--TRIMMABLE-BOUNDARY-START(386548826131),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 1769491,
      "h": 386548826131,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386548826131),
//--TRIMMABLE-BOUNDARY-START(309239414803),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 1769491,
      "h": 309239414803,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309239414803),
//--TRIMMABLE-BOUNDARY-START(304944447507),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 1769491,
      "h": 304944447507,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304944447507),
//--TRIMMABLE-BOUNDARY-START(42951442451),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 1769491,
      "h": 42951442451,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42951442451),
//--TRIMMABLE-BOUNDARY-START(38656475155),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 1769491,
      "h": 38656475155,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38656475155),
//--TRIMMABLE-BOUNDARY-START(416613597203),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 1769491,
      "h": 416613597203,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416613597203),
//--TRIMMABLE-BOUNDARY-START(412318629907),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 1769491,
      "h": 412318629907,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412318629907),
//--TRIMMABLE-BOUNDARY-START(472448172051),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 1769491,
      "h": 472448172051,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472448172051),
//--TRIMMABLE-BOUNDARY-START(468153204755),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 1769491,
      "h": 468153204755,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468153204755),
//--TRIMMABLE-BOUNDARY-START(188980330515),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 1769491,
      "h": 188980330515,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188980330515),
//--TRIMMABLE-BOUNDARY-START(184685363219),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 1769491,
      "h": 184685363219,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184685363219),
//--TRIMMABLE-BOUNDARY-START(171800461331),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 1769491,
      "h": 171800461331,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171800461331),
//--TRIMMABLE-BOUNDARY-START(167505494035),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 1769491,
      "h": 167505494035,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167505494035),
//--TRIMMABLE-BOUNDARY-START(180390395923),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 1769491,
      "h": 180390395923,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180390395923),
//--TRIMMABLE-BOUNDARY-START(176095428627),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 1769491,
      "h": 176095428627,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176095428627),
//--TRIMMABLE-BOUNDARY-START(34361507859),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 1769491,
      "h": 34361507859,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34361507859),
//--TRIMMABLE-BOUNDARY-START(30066540563),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 1769491,
      "h": 30066540563,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30066540563),
//--TRIMMABLE-BOUNDARY-START(137440722963),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 1769491,
      "h": 137440722963,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137440722963),
//--TRIMMABLE-BOUNDARY-START(133145755667),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 1769491,
      "h": 133145755667,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133145755667),
//--TRIMMABLE-BOUNDARY-START(103080984595),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 1769491,
      "h": 103080984595,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103080984595),
//--TRIMMABLE-BOUNDARY-START(98786017299),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 1769491,
      "h": 98786017299,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98786017299),
//--TRIMMABLE-BOUNDARY-START(523987779603),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 1769491,
      "h": 523987779603,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523987779603),
//--TRIMMABLE-BOUNDARY-START(519692812307),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 1769491,
      "h": 519692812307,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519692812307),
//--TRIMMABLE-BOUNDARY-START(369368956947),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 1769491,
      "h": 369368956947,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369368956947),
//--TRIMMABLE-BOUNDARY-START(365073989651),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 1769491,
      "h": 365073989651,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365073989651),
//--TRIMMABLE-BOUNDARY-START(223340068883),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 1769491,
      "h": 223340068883,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223340068883),
//--TRIMMABLE-BOUNDARY-START(219045101587),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 1769491,
      "h": 219045101587,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219045101587),
//--TRIMMABLE-BOUNDARY-START(249109872659),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 1769491,
      "h": 249109872659,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249109872659),
//--TRIMMABLE-BOUNDARY-START(236224970771),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 1769491,
      "h": 236224970771,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236224970771),
//--TRIMMABLE-BOUNDARY-START(244814905363),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 1769491,
      "h": 244814905363,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244814905363),
//--TRIMMABLE-BOUNDARY-START(240519938067),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 1769491,
      "h": 240519938067,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240519938067),
//--TRIMMABLE-BOUNDARY-START(317829349395),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 1769491,
      "h": 317829349395,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317829349395),
//--TRIMMABLE-BOUNDARY-START(313534382099),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 1769491,
      "h": 313534382099,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313534382099),
//--TRIMMABLE-BOUNDARY-START(8591704083),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 1769491,
      "h": 8591704083,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8591704083),
//--TRIMMABLE-BOUNDARY-START(4296736787),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 1769491,
      "h": 4296736787,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4296736787),
//--TRIMMABLE-BOUNDARY-START(455268302867),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 1769491,
      "h": 455268302867,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455268302867),
//--TRIMMABLE-BOUNDARY-START(450973335571),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 1769491,
      "h": 450973335571,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450973335571),
//--TRIMMABLE-BOUNDARY-START(25771573267),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 1769491,
      "h": 25771573267,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25771573267),
//--TRIMMABLE-BOUNDARY-START(21476605971),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 1769491,
      "h": 21476605971,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21476605971),
//--TRIMMABLE-BOUNDARY-START(257699807251),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 1769491,
      "h": 257699807251,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257699807251),
//--TRIMMABLE-BOUNDARY-START(253404839955),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 1769491,
      "h": 253404839955,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253404839955),
//--TRIMMABLE-BOUNDARY-START(515397845011),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 1769491,
      "h": 515397845011,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515397845011),
//--TRIMMABLE-BOUNDARY-START(511102877715),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 1769491,
      "h": 511102877715,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511102877715),
//--TRIMMABLE-BOUNDARY-START(463858237459),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 1769491,
      "h": 463858237459,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463858237459),
//--TRIMMABLE-BOUNDARY-START(459563270163),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 1769491,
      "h": 459563270163,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459563270163),
//--TRIMMABLE-BOUNDARY-START(425203531795),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 1769491,
      "h": 425203531795,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425203531795),
//--TRIMMABLE-BOUNDARY-START(420908564499),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 1769491,
      "h": 420908564499,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420908564499),
//--TRIMMABLE-BOUNDARY-START(343599153171),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 1769491,
      "h": 343599153171,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343599153171),
//--TRIMMABLE-BOUNDARY-START(339304185875),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 1769491,
      "h": 339304185875,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339304185875),
//--TRIMMABLE-BOUNDARY-START(292059545619),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 1769491,
      "h": 292059545619,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292059545619),
//--TRIMMABLE-BOUNDARY-START(287764578323),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 1769491,
      "h": 287764578323,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287764578323),
//--TRIMMABLE-BOUNDARY-START(532577714195),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 1769491,
      "h": 532577714195,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532577714195),
//--TRIMMABLE-BOUNDARY-START(528282746899),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 1769491,
      "h": 528282746899,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528282746899)
  ],
  "h": 1769491
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Obsoletions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769491)
        
        

        //--TRIMMABLE-BOUNDARY-START(1703955)
        $asm.$cls(`$sfa.SFA.WellKnownOids`, ($self) => class WellKnownOids
        {
            //--TRIMMABLE-BOUNDARY-START(8591638547)
            static /*string? */ GetValue(/*ReadOnlySpan<byte>*/ contents)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591638547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 56 && contents[5] === 4 && contents[6] === 1))
                    {
                        return "1.2.840.10040.4.1";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 56 && contents[5] === 4 && contents[6] === 3))
                    {
                        return "1.2.840.10040.4.3";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 2 && contents[6] === 1))
                    {
                        return "1.2.840.10045.2.1";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 1 && contents[6] === 1))
                    {
                        return "1.2.840.10045.1.1";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 1 && contents[6] === 2))
                    {
                        return "1.2.840.10045.1.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 3 && contents[6] === 1 && contents[7] === 7))
                    {
                        return "1.2.840.10045.3.1.7";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 1))
                    {
                        return "1.2.840.10045.4.1";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 3 && contents[7] === 2))
                    {
                        return "1.2.840.10045.4.3.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 3 && contents[7] === 3))
                    {
                        return "1.2.840.10045.4.3.3";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 3 && contents[7] === 4))
                    {
                        return "1.2.840.10045.4.3.4";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 1))
                    {
                        return "1.2.840.113549.1.1.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 5))
                    {
                        return "1.2.840.113549.1.1.5";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 7))
                    {
                        return "1.2.840.113549.1.1.7";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 8))
                    {
                        return "1.2.840.113549.1.1.8";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 9))
                    {
                        return "1.2.840.113549.1.1.9";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 10))
                    {
                        return "1.2.840.113549.1.1.10";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 11))
                    {
                        return "1.2.840.113549.1.1.11";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 12))
                    {
                        return "1.2.840.113549.1.1.12";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 13))
                    {
                        return "1.2.840.113549.1.1.13";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 3))
                    {
                        return "1.2.840.113549.1.5.3";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 10))
                    {
                        return "1.2.840.113549.1.5.10";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 11))
                    {
                        return "1.2.840.113549.1.5.11";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 12))
                    {
                        return "1.2.840.113549.1.5.12";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 13))
                    {
                        return "1.2.840.113549.1.5.13";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 1))
                    {
                        return "1.2.840.113549.1.7.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 2))
                    {
                        return "1.2.840.113549.1.7.2";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 3))
                    {
                        return "1.2.840.113549.1.7.3";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 6))
                    {
                        return "1.2.840.113549.1.7.6";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 1))
                    {
                        return "1.2.840.113549.1.9.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 3))
                    {
                        return "1.2.840.113549.1.9.3";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 4))
                    {
                        return "1.2.840.113549.1.9.4";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 5))
                    {
                        return "1.2.840.113549.1.9.5";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 6))
                    {
                        return "1.2.840.113549.1.9.6";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 7))
                    {
                        return "1.2.840.113549.1.9.7";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 14))
                    {
                        return "1.2.840.113549.1.9.14";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 15))
                    {
                        return "1.2.840.113549.1.9.15";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 1 && contents[10] === 4))
                    {
                        return "1.2.840.113549.1.9.16.1.4";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 2 && contents[10] === 12))
                    {
                        return "1.2.840.113549.1.9.16.2.12";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 2 && contents[10] === 14))
                    {
                        return "1.2.840.113549.1.9.16.2.14";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 2 && contents[10] === 47))
                    {
                        return "1.2.840.113549.1.9.16.2.47";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 20))
                    {
                        return "1.2.840.113549.1.9.20";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 21))
                    {
                        return "1.2.840.113549.1.9.21";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 22 && contents[9] === 1))
                    {
                        return "1.2.840.113549.1.9.22.1";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 1 && contents[9] === 3))
                    {
                        return "1.2.840.113549.1.12.1.3";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 1 && contents[9] === 5))
                    {
                        return "1.2.840.113549.1.12.1.5";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 1 && contents[9] === 6))
                    {
                        return "1.2.840.113549.1.12.1.6";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 1))
                    {
                        return "1.2.840.113549.1.12.10.1.1";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 2))
                    {
                        return "1.2.840.113549.1.12.10.1.2";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 3))
                    {
                        return "1.2.840.113549.1.12.10.1.3";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 5))
                    {
                        return "1.2.840.113549.1.12.10.1.5";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 6))
                    {
                        return "1.2.840.113549.1.12.10.1.6";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 5))
                    {
                        return "1.2.840.113549.2.5";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 7))
                    {
                        return "1.2.840.113549.2.7";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 9))
                    {
                        return "1.2.840.113549.2.9";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 10))
                    {
                        return "1.2.840.113549.2.10";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 11))
                    {
                        return "1.2.840.113549.2.11";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 3 && contents[7] === 2))
                    {
                        return "1.2.840.113549.3.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 3 && contents[7] === 7))
                    {
                        return "1.2.840.113549.3.7";
                    }
                    if ((contents.Length === 9 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 17 && contents[8] === 1))
                    {
                        return "1.3.6.1.4.1.311.17.1";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 17 && contents[8] === 3 && contents[9] === 20))
                    {
                        return "1.3.6.1.4.1.311.17.3.20";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 20 && contents[8] === 2 && contents[9] === 3))
                    {
                        return "1.3.6.1.4.1.311.20.2.3";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 88 && contents[8] === 2 && contents[9] === 1))
                    {
                        return "1.3.6.1.4.1.311.88.2.1";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 88 && contents[8] === 2 && contents[9] === 2))
                    {
                        return "1.3.6.1.4.1.311.88.2.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 1))
                    {
                        return "1.3.6.1.5.5.7.3.1";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 2))
                    {
                        return "1.3.6.1.5.5.7.3.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 3))
                    {
                        return "1.3.6.1.5.5.7.3.3";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 4))
                    {
                        return "1.3.6.1.5.5.7.3.4";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 8))
                    {
                        return "1.3.6.1.5.5.7.3.8";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 9))
                    {
                        return "1.3.6.1.5.5.7.3.9";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 6 && contents[7] === 2))
                    {
                        return "1.3.6.1.5.5.7.6.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 48 && contents[7] === 1))
                    {
                        return "1.3.6.1.5.5.7.48.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 48 && contents[7] === 1 && contents[8] === 2))
                    {
                        return "1.3.6.1.5.5.7.48.1.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 48 && contents[7] === 2))
                    {
                        return "1.3.6.1.5.5.7.48.2";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 14 && contents[2] === 3 && contents[3] === 2 && contents[4] === 26))
                    {
                        return "1.3.14.3.2.26";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 14 && contents[2] === 3 && contents[3] === 2 && contents[4] === 7))
                    {
                        return "1.3.14.3.2.7";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 129 && contents[2] === 4 && contents[3] === 0 && contents[4] === 34))
                    {
                        return "1.3.132.0.34";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 129 && contents[2] === 4 && contents[3] === 0 && contents[4] === 35))
                    {
                        return "1.3.132.0.35";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 3))
                    {
                        return "2.5.4.3";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 5))
                    {
                        return "2.5.4.5";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 6))
                    {
                        return "2.5.4.6";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 7))
                    {
                        return "2.5.4.7";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 8))
                    {
                        return "2.5.4.8";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 10))
                    {
                        return "2.5.4.10";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 11))
                    {
                        return "2.5.4.11";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 97))
                    {
                        return "2.5.4.97";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 14))
                    {
                        return "2.5.29.14";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 15))
                    {
                        return "2.5.29.15";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 17))
                    {
                        return "2.5.29.17";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 19))
                    {
                        return "2.5.29.19";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 20))
                    {
                        return "2.5.29.20";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 35))
                    {
                        return "2.5.29.35";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 1 && contents[8] === 2))
                    {
                        return "2.16.840.1.101.3.4.1.2";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 1 && contents[8] === 22))
                    {
                        return "2.16.840.1.101.3.4.1.22";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 1 && contents[8] === 42))
                    {
                        return "2.16.840.1.101.3.4.1.42";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 2 && contents[8] === 1))
                    {
                        return "2.16.840.1.101.3.4.2.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 2 && contents[8] === 2))
                    {
                        return "2.16.840.1.101.3.4.2.2";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 2 && contents[8] === 3))
                    {
                        return "2.16.840.1.101.3.4.2.3";
                    }
                    if ((contents.Length === 6 && contents[0] === 103 && contents[1] === 129 && contents[2] === 12 && contents[3] === 1 && contents[4] === 2 && contents[5] === 1))
                    {
                        return "2.23.140.1.2.1";
                    }
                    if ((contents.Length === 6 && contents[0] === 103 && contents[1] === 129 && contents[2] === 12 && contents[3] === 1 && contents[4] === 2 && contents[5] === 2))
                    {
                        return "2.23.140.1.2.2";
                    }
                    return null;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(8591638547)
            
            //--TRIMMABLE-BOUNDARY-START(4296671251)
            static /*ReadOnlySpan<byte> */ GetContents(/*ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296671251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let data = new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([ 42, 134, 72, 206, 56, 4, 1, 42, 134, 72, 206, 56, 4, 3, 42, 134, 72, 206, 61, 2, 1, 42, 134, 72, 206, 61, 1, 1, 42, 134, 72, 206, 61, 1, 2, 42, 134, 72, 206, 61, 3, 1, 7, 42, 134, 72, 206, 61, 4, 1, 42, 134, 72, 206, 61, 4, 3, 2, 42, 134, 72, 206, 61, 4, 3, 3, 42, 134, 72, 206, 61, 4, 3, 4, 42, 134, 72, 134, 247, 13, 1, 1, 1, 42, 134, 72, 134, 247, 13, 1, 1, 5, 42, 134, 72, 134, 247, 13, 1, 1, 7, 42, 134, 72, 134, 247, 13, 1, 1, 8, 42, 134, 72, 134, 247, 13, 1, 1, 9, 42, 134, 72, 134, 247, 13, 1, 1, 10, 42, 134, 72, 134, 247, 13, 1, 1, 11, 42, 134, 72, 134, 247, 13, 1, 1, 12, 42, 134, 72, 134, 247, 13, 1, 1, 13, 42, 134, 72, 134, 247, 13, 1, 5, 3, 42, 134, 72, 134, 247, 13, 1, 5, 10, 42, 134, 72, 134, 247, 13, 1, 5, 11, 42, 134, 72, 134, 247, 13, 1, 5, 12, 42, 134, 72, 134, 247, 13, 1, 5, 13, 42, 134, 72, 134, 247, 13, 1, 7, 1, 42, 134, 72, 134, 247, 13, 1, 7, 2, 42, 134, 72, 134, 247, 13, 1, 7, 3, 42, 134, 72, 134, 247, 13, 1, 7, 6, 42, 134, 72, 134, 247, 13, 1, 9, 1, 42, 134, 72, 134, 247, 13, 1, 9, 3, 42, 134, 72, 134, 247, 13, 1, 9, 4, 42, 134, 72, 134, 247, 13, 1, 9, 5, 42, 134, 72, 134, 247, 13, 1, 9, 6, 42, 134, 72, 134, 247, 13, 1, 9, 7, 42, 134, 72, 134, 247, 13, 1, 9, 14, 42, 134, 72, 134, 247, 13, 1, 9, 15, 42, 134, 72, 134, 247, 13, 1, 9, 16, 1, 4, 42, 134, 72, 134, 247, 13, 1, 9, 16, 2, 12, 42, 134, 72, 134, 247, 13, 1, 9, 16, 2, 14, 42, 134, 72, 134, 247, 13, 1, 9, 16, 2, 47, 42, 134, 72, 134, 247, 13, 1, 9, 20, 42, 134, 72, 134, 247, 13, 1, 9, 21, 42, 134, 72, 134, 247, 13, 1, 9, 22, 1, 42, 134, 72, 134, 247, 13, 1, 12, 1, 3, 42, 134, 72, 134, 247, 13, 1, 12, 1, 5, 42, 134, 72, 134, 247, 13, 1, 12, 1, 6, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 1, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 2, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 3, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 5, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 6, 42, 134, 72, 134, 247, 13, 2, 5, 42, 134, 72, 134, 247, 13, 2, 7, 42, 134, 72, 134, 247, 13, 2, 9, 42, 134, 72, 134, 247, 13, 2, 10, 42, 134, 72, 134, 247, 13, 2, 11, 42, 134, 72, 134, 247, 13, 3, 2, 42, 134, 72, 134, 247, 13, 3, 7, 43, 6, 1, 4, 1, 130, 55, 17, 1, 43, 6, 1, 4, 1, 130, 55, 17, 3, 20, 43, 6, 1, 4, 1, 130, 55, 20, 2, 3, 43, 6, 1, 4, 1, 130, 55, 88, 2, 1, 43, 6, 1, 4, 1, 130, 55, 88, 2, 2, 43, 6, 1, 5, 5, 7, 3, 1, 43, 6, 1, 5, 5, 7, 3, 2, 43, 6, 1, 5, 5, 7, 3, 3, 43, 6, 1, 5, 5, 7, 3, 4, 43, 6, 1, 5, 5, 7, 3, 8, 43, 6, 1, 5, 5, 7, 3, 9, 43, 6, 1, 5, 5, 7, 6, 2, 43, 6, 1, 5, 5, 7, 48, 1, 43, 6, 1, 5, 5, 7, 48, 1, 2, 43, 6, 1, 5, 5, 7, 48, 2, 43, 14, 3, 2, 26, 43, 14, 3, 2, 7, 43, 129, 4, 0, 34, 43, 129, 4, 0, 35, 85, 4, 3, 85, 4, 5, 85, 4, 6, 85, 4, 7, 85, 4, 8, 85, 4, 10, 85, 4, 11, 85, 4, 97, 85, 29, 14, 85, 29, 15, 85, 29, 17, 85, 29, 19, 85, 29, 20, 85, 29, 35, 96, 134, 72, 1, 101, 3, 4, 1, 2, 96, 134, 72, 1, 101, 3, 4, 1, 22, 96, 134, 72, 1, 101, 3, 4, 1, 42, 96, 134, 72, 1, 101, 3, 4, 2, 1, 96, 134, 72, 1, 101, 3, 4, 2, 2, 96, 134, 72, 1, 101, 3, 4, 2, 3, 103, 129, 12, 1, 2, 1, 103, 129, 12, 1, 2, 2 ]);
                return (() =>
                {
                    if (value === "1.2.840.10040.4.1")
                    {
                        return data.Slice(0, 7);
                    }
                    if (value === "1.2.840.10040.4.3")
                    {
                        return data.Slice(7, 7);
                    }
                    if (value === "1.2.840.10045.2.1")
                    {
                        return data.Slice(14, 7);
                    }
                    if (value === "1.2.840.10045.1.1")
                    {
                        return data.Slice(21, 7);
                    }
                    if (value === "1.2.840.10045.1.2")
                    {
                        return data.Slice(28, 7);
                    }
                    if (value === "1.2.840.10045.3.1.7")
                    {
                        return data.Slice(35, 8);
                    }
                    if (value === "1.2.840.10045.4.1")
                    {
                        return data.Slice(43, 7);
                    }
                    if (value === "1.2.840.10045.4.3.2")
                    {
                        return data.Slice(50, 8);
                    }
                    if (value === "1.2.840.10045.4.3.3")
                    {
                        return data.Slice(58, 8);
                    }
                    if (value === "1.2.840.10045.4.3.4")
                    {
                        return data.Slice(66, 8);
                    }
                    if (value === "1.2.840.113549.1.1.1")
                    {
                        return data.Slice(74, 9);
                    }
                    if (value === "1.2.840.113549.1.1.5")
                    {
                        return data.Slice(83, 9);
                    }
                    if (value === "1.2.840.113549.1.1.7")
                    {
                        return data.Slice(92, 9);
                    }
                    if (value === "1.2.840.113549.1.1.8")
                    {
                        return data.Slice(101, 9);
                    }
                    if (value === "1.2.840.113549.1.1.9")
                    {
                        return data.Slice(110, 9);
                    }
                    if (value === "1.2.840.113549.1.1.10")
                    {
                        return data.Slice(119, 9);
                    }
                    if (value === "1.2.840.113549.1.1.11")
                    {
                        return data.Slice(128, 9);
                    }
                    if (value === "1.2.840.113549.1.1.12")
                    {
                        return data.Slice(137, 9);
                    }
                    if (value === "1.2.840.113549.1.1.13")
                    {
                        return data.Slice(146, 9);
                    }
                    if (value === "1.2.840.113549.1.5.3")
                    {
                        return data.Slice(155, 9);
                    }
                    if (value === "1.2.840.113549.1.5.10")
                    {
                        return data.Slice(164, 9);
                    }
                    if (value === "1.2.840.113549.1.5.11")
                    {
                        return data.Slice(173, 9);
                    }
                    if (value === "1.2.840.113549.1.5.12")
                    {
                        return data.Slice(182, 9);
                    }
                    if (value === "1.2.840.113549.1.5.13")
                    {
                        return data.Slice(191, 9);
                    }
                    if (value === "1.2.840.113549.1.7.1")
                    {
                        return data.Slice(200, 9);
                    }
                    if (value === "1.2.840.113549.1.7.2")
                    {
                        return data.Slice(209, 9);
                    }
                    if (value === "1.2.840.113549.1.7.3")
                    {
                        return data.Slice(218, 9);
                    }
                    if (value === "1.2.840.113549.1.7.6")
                    {
                        return data.Slice(227, 9);
                    }
                    if (value === "1.2.840.113549.1.9.1")
                    {
                        return data.Slice(236, 9);
                    }
                    if (value === "1.2.840.113549.1.9.3")
                    {
                        return data.Slice(245, 9);
                    }
                    if (value === "1.2.840.113549.1.9.4")
                    {
                        return data.Slice(254, 9);
                    }
                    if (value === "1.2.840.113549.1.9.5")
                    {
                        return data.Slice(263, 9);
                    }
                    if (value === "1.2.840.113549.1.9.6")
                    {
                        return data.Slice(272, 9);
                    }
                    if (value === "1.2.840.113549.1.9.7")
                    {
                        return data.Slice(281, 9);
                    }
                    if (value === "1.2.840.113549.1.9.14")
                    {
                        return data.Slice(290, 9);
                    }
                    if (value === "1.2.840.113549.1.9.15")
                    {
                        return data.Slice(299, 9);
                    }
                    if (value === "1.2.840.113549.1.9.16.1.4")
                    {
                        return data.Slice(308, 11);
                    }
                    if (value === "1.2.840.113549.1.9.16.2.12")
                    {
                        return data.Slice(319, 11);
                    }
                    if (value === "1.2.840.113549.1.9.16.2.14")
                    {
                        return data.Slice(330, 11);
                    }
                    if (value === "1.2.840.113549.1.9.16.2.47")
                    {
                        return data.Slice(341, 11);
                    }
                    if (value === "1.2.840.113549.1.9.20")
                    {
                        return data.Slice(352, 9);
                    }
                    if (value === "1.2.840.113549.1.9.21")
                    {
                        return data.Slice(361, 9);
                    }
                    if (value === "1.2.840.113549.1.9.22.1")
                    {
                        return data.Slice(370, 10);
                    }
                    if (value === "1.2.840.113549.1.12.1.3")
                    {
                        return data.Slice(380, 10);
                    }
                    if (value === "1.2.840.113549.1.12.1.5")
                    {
                        return data.Slice(390, 10);
                    }
                    if (value === "1.2.840.113549.1.12.1.6")
                    {
                        return data.Slice(400, 10);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.1")
                    {
                        return data.Slice(410, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.2")
                    {
                        return data.Slice(421, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.3")
                    {
                        return data.Slice(432, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.5")
                    {
                        return data.Slice(443, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.6")
                    {
                        return data.Slice(454, 11);
                    }
                    if (value === "1.2.840.113549.2.5")
                    {
                        return data.Slice(465, 8);
                    }
                    if (value === "1.2.840.113549.2.7")
                    {
                        return data.Slice(473, 8);
                    }
                    if (value === "1.2.840.113549.2.9")
                    {
                        return data.Slice(481, 8);
                    }
                    if (value === "1.2.840.113549.2.10")
                    {
                        return data.Slice(489, 8);
                    }
                    if (value === "1.2.840.113549.2.11")
                    {
                        return data.Slice(497, 8);
                    }
                    if (value === "1.2.840.113549.3.2")
                    {
                        return data.Slice(505, 8);
                    }
                    if (value === "1.2.840.113549.3.7")
                    {
                        return data.Slice(513, 8);
                    }
                    if (value === "1.3.6.1.4.1.311.17.1")
                    {
                        return data.Slice(521, 9);
                    }
                    if (value === "1.3.6.1.4.1.311.17.3.20")
                    {
                        return data.Slice(530, 10);
                    }
                    if (value === "1.3.6.1.4.1.311.20.2.3")
                    {
                        return data.Slice(540, 10);
                    }
                    if (value === "1.3.6.1.4.1.311.88.2.1")
                    {
                        return data.Slice(550, 10);
                    }
                    if (value === "1.3.6.1.4.1.311.88.2.2")
                    {
                        return data.Slice(560, 10);
                    }
                    if (value === "1.3.6.1.5.5.7.3.1")
                    {
                        return data.Slice(570, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.2")
                    {
                        return data.Slice(578, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.3")
                    {
                        return data.Slice(586, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.4")
                    {
                        return data.Slice(594, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.8")
                    {
                        return data.Slice(602, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.9")
                    {
                        return data.Slice(610, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.6.2")
                    {
                        return data.Slice(618, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.48.1")
                    {
                        return data.Slice(626, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.48.1.2")
                    {
                        return data.Slice(634, 9);
                    }
                    if (value === "1.3.6.1.5.5.7.48.2")
                    {
                        return data.Slice(643, 8);
                    }
                    if (value === "1.3.14.3.2.26")
                    {
                        return data.Slice(651, 5);
                    }
                    if (value === "1.3.14.3.2.7")
                    {
                        return data.Slice(656, 5);
                    }
                    if (value === "1.3.132.0.34")
                    {
                        return data.Slice(661, 5);
                    }
                    if (value === "1.3.132.0.35")
                    {
                        return data.Slice(666, 5);
                    }
                    if (value === "2.5.4.3")
                    {
                        return data.Slice(671, 3);
                    }
                    if (value === "2.5.4.5")
                    {
                        return data.Slice(674, 3);
                    }
                    if (value === "2.5.4.6")
                    {
                        return data.Slice(677, 3);
                    }
                    if (value === "2.5.4.7")
                    {
                        return data.Slice(680, 3);
                    }
                    if (value === "2.5.4.8")
                    {
                        return data.Slice(683, 3);
                    }
                    if (value === "2.5.4.10")
                    {
                        return data.Slice(686, 3);
                    }
                    if (value === "2.5.4.11")
                    {
                        return data.Slice(689, 3);
                    }
                    if (value === "2.5.4.97")
                    {
                        return data.Slice(692, 3);
                    }
                    if (value === "2.5.29.14")
                    {
                        return data.Slice(695, 3);
                    }
                    if (value === "2.5.29.15")
                    {
                        return data.Slice(698, 3);
                    }
                    if (value === "2.5.29.17")
                    {
                        return data.Slice(701, 3);
                    }
                    if (value === "2.5.29.19")
                    {
                        return data.Slice(704, 3);
                    }
                    if (value === "2.5.29.20")
                    {
                        return data.Slice(707, 3);
                    }
                    if (value === "2.5.29.35")
                    {
                        return data.Slice(710, 3);
                    }
                    if (value === "2.16.840.1.101.3.4.1.2")
                    {
                        return data.Slice(713, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.1.22")
                    {
                        return data.Slice(722, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.1.42")
                    {
                        return data.Slice(731, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.2.1")
                    {
                        return data.Slice(740, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.2.2")
                    {
                        return data.Slice(749, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.2.3")
                    {
                        return data.Slice(758, 9);
                    }
                    if (value === "2.23.140.1.2.1")
                    {
                        return data.Slice(767, 6);
                    }
                    if (value === "2.23.140.1.2.2")
                    {
                        return data.Slice(773, 6);
                    }
                    return $.$$.S.ReadOnlySpan$$($.$$.S.Byte).Empty;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(4296671251)
            
            static $h = 1703955;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591638547),
    {
      "r": 1310721,
      "p": [
        {
          "n": "contents",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetValue",
      "d": 1703955,
      "h": 8591638547,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591638547),
//--TRIMMABLE-BOUNDARY-START(4296671251),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "GetContents",
      "d": 1703955,
      "h": 4296671251,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296671251)
  ],
  "h": 1703955
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.WellKnownOids`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}WellKnownOids`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703955)
        
        

        //--TRIMMABLE-BOUNDARY-START(655379)
        $asm.$str(`$sfa.SFA.AsnReaderOptions`, ($self) => class AsnReaderOptions extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17180524563)
            /*int*/ static DefaultTwoDigitMax = 2049;
            //--TRIMMABLE-BOUNDARY-END(17180524563)
            
            //--TRIMMABLE-BOUNDARY-START(4295622675)
            /*ushort*/ _twoDigitYearMax = 0;
            //--TRIMMABLE-BOUNDARY-END(4295622675)
            
            //--TRIMMABLE-BOUNDARY-START(60130197523)
            /*int */ get UtcTimeTwoDigitYearMax()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360393747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._twoDigitYearMax === 0)
                {
                    return 2049/*DefaultTwoDigitMax*/;
                }
                return this._twoDigitYearMax;
            }
            /*int */ set UtcTimeTwoDigitYearMax(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540262931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 1 || value > 9999)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("value");
                }
                this._twoDigitYearMax = $.$cast(value, $.$$.S.UInt16);
            }
            //--TRIMMABLE-BOUNDARY-END(60130197523)
            
            //--TRIMMABLE-BOUNDARY-START(55835230227)
            /*bool*/ SkipSetSortOrderVerification = false;
            //--TRIMMABLE-BOUNDARY-END(55835230227)
            
            //--TRIMMABLE-BOUNDARY-START(12885557267)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885557267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557267)
            
            //--TRIMMABLE-BOUNDARY-START(12885557267)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885557267)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._twoDigitYearMax = this._twoDigitYearMax;
                copy.SkipSetSortOrderVerification = this.SkipSetSortOrderVerification;
                return copy;
            }
            static $h = 655379;
            static $z = 3;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130197523),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360393747,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540262931,
        "f": 83886081
      },
      "n": "UtcTimeTwoDigitYearMax",
      "d": 655379,
      "h": 60130197523,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130197523),
//--TRIMMABLE-BOUNDARY-START(55835230227),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770459155,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950328339,
        "f": 83886081
      },
      "n": "SkipSetSortOrderVerification",
      "d": 655379,
      "h": 55835230227,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835230227)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180524563),
    {
      "t": 655361,
      "n": "DefaultTwoDigitMax",
      "d": 655379,
      "h": 17180524563,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180524563),
//--TRIMMABLE-BOUNDARY-START(4295622675),
    {
      "t": 589825,
      "n": "_twoDigitYearMax",
      "d": 655379,
      "h": 4295622675,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622675)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885557267),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655379,
      "h": 12885557267,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557267)
  ],
  "h": 655379
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.AsnReaderOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}AsnReaderOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655379)
        
        

        //--TRIMMABLE-BOUNDARY-START(65555)
        $asm.$str(`$sfa.SFA.Asn1Tag`, ($self) => class Asn1Tag extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(81604444179)
            /*Asn1Tag*/ static EndOfContents;
            //--TRIMMABLE-BOUNDARY-END(81604444179)
            
            //--TRIMMABLE-BOUNDARY-START(42949738515)
            /*Asn1Tag*/ static Boolean;
            //--TRIMMABLE-BOUNDARY-END(42949738515)
            
            //--TRIMMABLE-BOUNDARY-START(137439019027)
            /*Asn1Tag*/ static Integer;
            //--TRIMMABLE-BOUNDARY-END(137439019027)
            
            //--TRIMMABLE-BOUNDARY-START(163208822803)
            /*Asn1Tag*/ static PrimitiveBitString;
            //--TRIMMABLE-BOUNDARY-END(163208822803)
            
            //--TRIMMABLE-BOUNDARY-START(55834640403)
            /*Asn1Tag*/ static ConstructedBitString;
            //--TRIMMABLE-BOUNDARY-END(55834640403)
            
            //--TRIMMABLE-BOUNDARY-START(167503790099)
            /*Asn1Tag*/ static PrimitiveOctetString;
            //--TRIMMABLE-BOUNDARY-END(167503790099)
            
            //--TRIMMABLE-BOUNDARY-START(64424574995)
            /*Asn1Tag*/ static ConstructedOctetString;
            //--TRIMMABLE-BOUNDARY-END(64424574995)
            
            //--TRIMMABLE-BOUNDARY-START(146028953619)
            /*Asn1Tag*/ static Null;
            //--TRIMMABLE-BOUNDARY-END(146028953619)
            
            //--TRIMMABLE-BOUNDARY-START(150323920915)
            /*Asn1Tag*/ static ObjectIdentifier;
            //--TRIMMABLE-BOUNDARY-END(150323920915)
            
            //--TRIMMABLE-BOUNDARY-START(85899411475)
            /*Asn1Tag*/ static Enumerated;
            //--TRIMMABLE-BOUNDARY-END(85899411475)
            
            //--TRIMMABLE-BOUNDARY-START(171798757395)
            /*Asn1Tag*/ static Sequence;
            //--TRIMMABLE-BOUNDARY-END(171798757395)
            
            //--TRIMMABLE-BOUNDARY-START(176093724691)
            /*Asn1Tag*/ static SetOf;
            //--TRIMMABLE-BOUNDARY-END(176093724691)
            
            //--TRIMMABLE-BOUNDARY-START(206158495763)
            /*Asn1Tag*/ static UtcTime;
            //--TRIMMABLE-BOUNDARY-END(206158495763)
            
            //--TRIMMABLE-BOUNDARY-START(98784313363)
            /*Asn1Tag*/ static GeneralizedTime;
            //--TRIMMABLE-BOUNDARY-END(98784313363)
            
            //--TRIMMABLE-BOUNDARY-START(51539673107)
            /*byte*/ static ClassMask = 192;
            //--TRIMMABLE-BOUNDARY-END(51539673107)
            
            //--TRIMMABLE-BOUNDARY-START(60129607699)
            /*byte*/ static ConstructedMask = 32;
            //--TRIMMABLE-BOUNDARY-END(60129607699)
            
            //--TRIMMABLE-BOUNDARY-START(68719542291)
            /*byte*/ static ControlMask = 224;
            //--TRIMMABLE-BOUNDARY-END(68719542291)
            
            //--TRIMMABLE-BOUNDARY-START(184683659283)
            /*byte*/ static TagNumberMask = 31;
            //--TRIMMABLE-BOUNDARY-END(184683659283)
            
            //--TRIMMABLE-BOUNDARY-START(4295032851)
            /*byte*/ _controlFlags = 0;
            //--TRIMMABLE-BOUNDARY-END(4295032851)
            
            //--TRIMMABLE-BOUNDARY-START(180388691987)
            /*TagClass */ get TagClass()
            {
                return $.$cast((this._controlFlags & 192/*ClassMask*/), $.$sfa.SFA.TagClass);
            }
            //--TRIMMABLE-BOUNDARY-END(180388691987)
            
            //--TRIMMABLE-BOUNDARY-START(141733986323)
            /*bool */ get IsConstructed()
            {
                return (this._controlFlags & 32/*ConstructedMask*/) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(141733986323)
            
            //--TRIMMABLE-BOUNDARY-START(188978626579)
            /*int*/ TagValue = 0;
            //--TRIMMABLE-BOUNDARY-END(188978626579)
            
            //--TRIMMABLE-BOUNDARY-START(21474902035)
            $ctor$3(/*byte*/ controlFlags, /*int*/ tagValue)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21474902035);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._controlFlags = $.$cast((controlFlags & 224/*ControlMask*/), $.$$.S.Byte);
                    this.TagValue = tagValue;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902035)
            
            //--TRIMMABLE-BOUNDARY-START(30064836627)
            $ctor$5(/*UniversalTagNumber*/ universalTagNumber, /*bool*/ isConstructed)
            {
                this.$ctor$3(isConstructed ? 32/*ConstructedMask*/ : 0, universalTagNumber);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064836627);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*UniversalTagNumber*/ let ReservedIndex = $.$cast(15, $.$sfa.SFA.UniversalTagNumber);
                    if (universalTagNumber < 0/*UniversalTagNumber.EndOfContents*/ || universalTagNumber > 36/*UniversalTagNumber.RelativeObjectIdentifierIRI*/ || universalTagNumber === ReservedIndex)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("universalTagNumber");
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064836627)
            
            //--TRIMMABLE-BOUNDARY-START(25769869331)
            $ctor$4(/*TagClass*/ tagClass, /*int*/ tagValue, /*bool*/ isConstructed)
            {
                this.$ctor$3($.$cast(($.$cast(tagClass, $.$$.S.Byte) | (isConstructed ? 32/*ConstructedMask*/ : 0)), $.$$.S.Byte), tagValue);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769869331);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    switch(tagClass)
                    {
                        case 0/*TagClass.Universal*/:
                        case 128/*TagClass.ContextSpecific*/:
                        case 64/*TagClass.Application*/:
                        case 192/*TagClass.Private*/:
                        break;
                        default:
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("tagClass");
                    }
                    if (tagValue < 0)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("tagValue");
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869331)
            
            //--TRIMMABLE-BOUNDARY-START(34359803923)
            /*Asn1Tag */ AsConstructed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sfa.SFA.Asn1Tag().$ctor$3($.$cast((this._controlFlags | 32/*ConstructedMask*/), $.$$.S.Byte), this.TagValue);
            }
            //--TRIMMABLE-BOUNDARY-END(34359803923)
            
            //--TRIMMABLE-BOUNDARY-START(38654771219)
            /*Asn1Tag */ AsPrimitive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sfa.SFA.Asn1Tag().$ctor$3($.$cast((this._controlFlags & ~32/*ConstructedMask*/), $.$$.S.Byte), this.TagValue);
            }
            //--TRIMMABLE-BOUNDARY-END(38654771219)
            
            //--TRIMMABLE-BOUNDARY-START(197568561171)
            static /*bool */ TryDecode(/*ReadOnlySpan<byte>*/ source, /*out Asn1Tag*/ tag, /*out int*/ bytesConsumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568561171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                tag.$v = $.$default($.$sfa.SFA.Asn1Tag);
                bytesConsumed.$v = 0;
                if (source.IsEmpty)
                {
                    return false;
                }
                /*byte*/ let first = source._reference.GetAt(bytesConsumed.$v);
                bytesConsumed.$v++;
                /*uint*/ let tagValue = ((first & 31/*TagNumberMask*/) >>> 0);
                if (tagValue === 31/*TagNumberMask*/)
                {
                    /*byte*/ let ContinuationFlag = 128;
                    /*byte*/ let ValueMask = ((ContinuationFlag - 1) | 0);
                    tagValue = 0;
                    /*byte*/ let current;
                    do
                    {
                        if (source.Length <= bytesConsumed.$v)
                        {
                            bytesConsumed.$v = 0;
                            return false;
                        }
                        current = source._reference.GetAt(bytesConsumed.$v);
                        /*byte*/ let currentValue = $.$cast((current & ValueMask), $.$$.S.Byte);
                        bytesConsumed.$v++;
                        /*int*/ let TooBigToShift = 33554432;
                        if (tagValue >= TooBigToShift)
                        {
                            bytesConsumed.$v = 0;
                            return false;
                        }
                        tagValue <<= 7;
                        tagValue |= currentValue;
                        if (tagValue === 0)
                        {
                            bytesConsumed.$v = 0;
                            return false;
                        }
                    }
                    while((current & ContinuationFlag) === ContinuationFlag);
                    if (tagValue <= 30)
                    {
                        bytesConsumed.$v = 0;
                        return false;
                    }
                    if (tagValue > 2147483647/*int.MaxValue*/)
                    {
                        bytesConsumed.$v = 0;
                        return false;
                    }
                }
                $.$$.SD.Debug.Assert$4(bytesConsumed.$v > 0, "bytesConsumed > 0");
                tag.$v = new $.$sfa.SFA.Asn1Tag().$ctor$3(first, (tagValue | 0));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(197568561171)
            
            //--TRIMMABLE-BOUNDARY-START(73014509587)
            static /*Asn1Tag */ Decode(/*ReadOnlySpan<byte>*/ source, /*out int*/ bytesConsumed)
            {
                /*Asn1Tag*/ let tag;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014509587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sfa.SFA.Asn1Tag.TryDecode(source, $.$ref(() => tag, ($v) => tag = $v, $.$sfa.SFA.Asn1Tag), bytesConsumed))
                {
                    return tag;
                }
                throw new $.$sfa.SFA.AsnContentException().$ctor$8($.$sfa.S.SR.ContentException_InvalidTag);
            }
            //--TRIMMABLE-BOUNDARY-END(73014509587)
            
            //--TRIMMABLE-BOUNDARY-START(47244705811)
            /*int */ CalculateEncodedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let SevenBits = 127;
                /*int*/ let FourteenBits = 16383;
                /*int*/ let TwentyOneBits = 2097151;
                /*int*/ let TwentyEightBits = 268435455;
                if (this.TagValue < 31/*TagNumberMask*/)
                {
                    return 1;
                }
                if (this.TagValue <= SevenBits)
                {
                    return 2;
                }
                if (this.TagValue <= FourteenBits)
                {
                    return 3;
                }
                if (this.TagValue <= TwentyOneBits)
                {
                    return 4;
                }
                if (this.TagValue <= TwentyEightBits)
                {
                    return 5;
                }
                return 6;
            }
            //--TRIMMABLE-BOUNDARY-END(47244705811)
            
            //--TRIMMABLE-BOUNDARY-START(201863528467)
            /*bool */ TryEncode(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863528467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let spaceRequired = this.CalculateEncodedSize();
                if (destination.Length < spaceRequired)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                if (spaceRequired === 1)
                {
                    /*byte*/ let value = $.$cast((this._controlFlags | this.TagValue), $.$$.S.Byte);
                    destination._reference.SetAt(value, 0);
                    bytesWritten.$v = 1;
                    return true;
                }
                /*byte*/ let firstByte = $.$cast((this._controlFlags | 31/*TagNumberMask*/), $.$$.S.Byte);
                destination._reference.SetAt(firstByte, 0);
                /*int*/ let remaining = this.TagValue;
                /*int*/ let idx = ((spaceRequired - 1) | 0);
                while(remaining > 0)
                {
                    /*int*/ let segment = remaining & 127;
                    if (remaining !== this.TagValue)
                    {
                        segment |= 128;
                    }
                    $.$$.SD.Debug.Assert$4(segment <= 255/*byte.MaxValue*/, "segment <= byte.MaxValue");
                    destination._reference.SetAt($.$cast(segment, $.$$.S.Byte), idx);
                    remaining >>= 7;
                    idx--;
                }
                $.$$.SD.Debug.Assert$4(idx === 0, "idx == 0");
                bytesWritten.$v = spaceRequired;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(201863528467)
            
            //--TRIMMABLE-BOUNDARY-START(77309476883)
            /*int */ Encode(/*Span<byte>*/ destination)
            {
                /*int*/ let bytesWritten;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309476883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.TryEncode(destination, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.S.Int32)))
                {
                    return bytesWritten;
                }
                throw new $.$$.S.ArgumentException().$ctor$13($.$sfa.S.SR.Argument_DestinationTooShort, "destination");
            }
            //--TRIMMABLE-BOUNDARY-END(77309476883)
            
            //--TRIMMABLE-BOUNDARY-START(94489346067)
            /*bool */ Equals$2(/*Asn1Tag*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489346067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._controlFlags === other._controlFlags && this.TagValue === other.TagValue;
            }
            //--TRIMMABLE-BOUNDARY-END(94489346067)
            
            //--TRIMMABLE-BOUNDARY-START(90194378771)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194378771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let tag;
                return $.$is(obj, $.$sfa.SFA.Asn1Tag, { set $v($v){ tag = $v; } }) && this.Equals$2(tag);
            }
            //--TRIMMABLE-BOUNDARY-END(90194378771)
            
            //--TRIMMABLE-BOUNDARY-START(128849084435)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849084435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ((this._controlFlags << 24) >>> 0) ^ this.TagValue;
            }
            //--TRIMMABLE-BOUNDARY-END(128849084435)
            
            //--TRIMMABLE-BOUNDARY-START(154618888211)
            static /*bool */ op_Equality(/*Asn1Tag*/ left, /*Asn1Tag*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154618888211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return left.Equals$2(right);
            }
            //--TRIMMABLE-BOUNDARY-END(154618888211)
            
            //--TRIMMABLE-BOUNDARY-START(158913855507)
            static /*bool */ op_Inequality(/*Asn1Tag*/ left, /*Asn1Tag*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913855507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !left.Equals$2(right);
            }
            //--TRIMMABLE-BOUNDARY-END(158913855507)
            
            //--TRIMMABLE-BOUNDARY-START(133144051731)
            /*bool */ HasSameClassAndValue(/*Asn1Tag*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144051731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TagValue === other.TagValue && this.TagClass === other.TagClass;
            }
            //--TRIMMABLE-BOUNDARY-END(133144051731)
            
            //--TRIMMABLE-BOUNDARY-START(193273593875)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273593875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let ConstructedPrefix = "Constructed ";
                /*string*/ let classAndValue;
                if (this.TagClass === 0/*TagClass.Universal*/)
                {
                    classAndValue = $.$$.S.Enum.ToStringT($.$sfa.SFA.UniversalTagNumber, $.$$.S.UInt32, ($.$cast(this.TagValue, $.$sfa.SFA.UniversalTagNumber)));
                }
                else 
                {
                    classAndValue = `${$.$strNN($.$$.S.Enum.ToStringT($.$sfa.SFA.TagClass, $.$$.S.UInt32, this.TagClass))}-${$.$strNN(this.TagValue)}`;
                }
                if (this.IsConstructed)
                {
                    return $.$strNN(ConstructedPrefix) + $.$strNN(classAndValue);
                }
                return classAndValue;
            }
            //--TRIMMABLE-BOUNDARY-END(193273593875)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<System.Formats.Asn1.Asn1Tag>.Equals(System.Formats.Asn1.Asn1Tag)
            S$IEquatable$System$Formats$Asn1$Asn1Tag$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(17179934739)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17179934739)
            
            //--TRIMMABLE-BOUNDARY-START(17179934739)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17179934739)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._controlFlags = this._controlFlags;
                copy.TagValue = this.TagValue;
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(12884967443)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(81604444179)
                    this.EndOfContents = new $.$sfa.SFA.Asn1Tag().$ctor$3(0, 0/*UniversalTagNumber.EndOfContents*/);
                    //--TRIMMABLE-BOUNDARY-END(81604444179)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949738515)
                    this.Boolean = new $.$sfa.SFA.Asn1Tag().$ctor$3(0, 1/*UniversalTagNumber.Boolean*/);
                    //--TRIMMABLE-BOUNDARY-END(42949738515)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439019027)
                    this.Integer = new $.$sfa.SFA.Asn1Tag().$ctor$3(0, 2/*UniversalTagNumber.Integer*/);
                    //--TRIMMABLE-BOUNDARY-END(137439019027)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163208822803)
                    this.PrimitiveBitString = new $.$sfa.SFA.Asn1Tag().$ctor$3(0, 3/*UniversalTagNumber.BitString*/);
                    //--TRIMMABLE-BOUNDARY-END(163208822803)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834640403)
                    this.ConstructedBitString = new $.$sfa.SFA.Asn1Tag().$ctor$3(32/*ConstructedMask*/, 3/*UniversalTagNumber.BitString*/);
                    //--TRIMMABLE-BOUNDARY-END(55834640403)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167503790099)
                    this.PrimitiveOctetString = new $.$sfa.SFA.Asn1Tag().$ctor$3(0, 4/*UniversalTagNumber.OctetString*/);
                    //--TRIMMABLE-BOUNDARY-END(167503790099)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424574995)
                    this.ConstructedOctetString = new $.$sfa.SFA.Asn1Tag().$ctor$3(32/*ConstructedMask*/, 4/*UniversalTagNumber.OctetString*/);
                    //--TRIMMABLE-BOUNDARY-END(64424574995)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146028953619)
                    this.Null = new $.$sfa.SFA.Asn1Tag().$ctor$3(0, 5/*UniversalTagNumber.Null*/);
                    //--TRIMMABLE-BOUNDARY-END(146028953619)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150323920915)
                    this.ObjectIdentifier = new $.$sfa.SFA.Asn1Tag().$ctor$3(0, 6/*UniversalTagNumber.ObjectIdentifier*/);
                    //--TRIMMABLE-BOUNDARY-END(150323920915)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899411475)
                    this.Enumerated = new $.$sfa.SFA.Asn1Tag().$ctor$3(0, 10/*UniversalTagNumber.Enumerated*/);
                    //--TRIMMABLE-BOUNDARY-END(85899411475)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171798757395)
                    this.Sequence = new $.$sfa.SFA.Asn1Tag().$ctor$3(32/*ConstructedMask*/, 16/*UniversalTagNumber.Sequence*/);
                    //--TRIMMABLE-BOUNDARY-END(171798757395)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176093724691)
                    this.SetOf = new $.$sfa.SFA.Asn1Tag().$ctor$3(32/*ConstructedMask*/, 17/*UniversalTagNumber.SetOf*/);
                    //--TRIMMABLE-BOUNDARY-END(176093724691)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158495763)
                    this.UtcTime = new $.$sfa.SFA.Asn1Tag().$ctor$3(0, 23/*UniversalTagNumber.UtcTime*/);
                    //--TRIMMABLE-BOUNDARY-END(206158495763)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784313363)
                    this.GeneralizedTime = new $.$sfa.SFA.Asn1Tag().$ctor$3(0, 24/*UniversalTagNumber.GeneralizedTime*/);
                    //--TRIMMABLE-BOUNDARY-END(98784313363)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12884967443)
            
            static $h = 65555;
            static $z = 5;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(180388691987),
    {
      "p": 1507347,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964182547,
        "f": 50331649
      },
      "n": "TagClass",
      "d": 65555,
      "h": 180388691987,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180388691987),
//--TRIMMABLE-BOUNDARY-START(141733986323),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374247955,
        "f": 50331649
      },
      "n": "IsConstructed",
      "d": 65555,
      "h": 141733986323,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141733986323),
//--TRIMMABLE-BOUNDARY-START(188978626579),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554117139,
        "f": 50331649
      },
      "n": "TagValue",
      "d": 65555,
      "h": 188978626579,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188978626579)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34359803923),
    {
      "r": 65555,
      "n": "AsConstructed",
      "d": 65555,
      "h": 34359803923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359803923),
//--TRIMMABLE-BOUNDARY-START(38654771219),
    {
      "r": 65555,
      "n": "AsPrimitive",
      "d": 65555,
      "h": 38654771219,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654771219),
//--TRIMMABLE-BOUNDARY-START(197568561171),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "tag",
          "p": 65555,
          "f": 2
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecode",
      "d": 65555,
      "h": 197568561171,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(197568561171),
//--TRIMMABLE-BOUNDARY-START(73014509587),
    {
      "r": 65555,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "Decode",
      "d": 65555,
      "h": 73014509587,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73014509587),
//--TRIMMABLE-BOUNDARY-START(47244705811),
    {
      "r": 655361,
      "n": "CalculateEncodedSize",
      "d": 65555,
      "h": 47244705811,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244705811),
//--TRIMMABLE-BOUNDARY-START(201863528467),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryEncode",
      "d": 65555,
      "h": 201863528467,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201863528467),
//--TRIMMABLE-BOUNDARY-START(77309476883),
    {
      "r": 655361,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "Encode",
      "d": 65555,
      "h": 77309476883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309476883),
//--TRIMMABLE-BOUNDARY-START(94489346067),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 65555
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 65555,
      "h": 94489346067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489346067),
//--TRIMMABLE-BOUNDARY-START(90194378771),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 65555,
      "h": 90194378771,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90194378771),
//--TRIMMABLE-BOUNDARY-START(128849084435),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 65555,
      "h": 128849084435,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128849084435),
//--TRIMMABLE-BOUNDARY-START(133144051731),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 65555
        }
      ],
      "n": "HasSameClassAndValue",
      "d": 65555,
      "h": 133144051731,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133144051731),
//--TRIMMABLE-BOUNDARY-START(193273593875),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 65555,
      "h": 193273593875,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193273593875)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81604444179),
    {
      "t": 65555,
      "n": "EndOfContents",
      "d": 65555,
      "h": 81604444179,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81604444179),
//--TRIMMABLE-BOUNDARY-START(42949738515),
    {
      "t": 65555,
      "n": "Boolean",
      "d": 65555,
      "h": 42949738515,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949738515),
//--TRIMMABLE-BOUNDARY-START(137439019027),
    {
      "t": 65555,
      "n": "Integer",
      "d": 65555,
      "h": 137439019027,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439019027),
//--TRIMMABLE-BOUNDARY-START(163208822803),
    {
      "t": 65555,
      "n": "PrimitiveBitString",
      "d": 65555,
      "h": 163208822803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163208822803),
//--TRIMMABLE-BOUNDARY-START(55834640403),
    {
      "t": 65555,
      "n": "ConstructedBitString",
      "d": 65555,
      "h": 55834640403,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834640403),
//--TRIMMABLE-BOUNDARY-START(167503790099),
    {
      "t": 65555,
      "n": "PrimitiveOctetString",
      "d": 65555,
      "h": 167503790099,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167503790099),
//--TRIMMABLE-BOUNDARY-START(64424574995),
    {
      "t": 65555,
      "n": "ConstructedOctetString",
      "d": 65555,
      "h": 64424574995,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424574995),
//--TRIMMABLE-BOUNDARY-START(146028953619),
    {
      "t": 65555,
      "n": "Null",
      "d": 65555,
      "h": 146028953619,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146028953619),
//--TRIMMABLE-BOUNDARY-START(150323920915),
    {
      "t": 65555,
      "n": "ObjectIdentifier",
      "d": 65555,
      "h": 150323920915,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150323920915),
//--TRIMMABLE-BOUNDARY-START(85899411475),
    {
      "t": 65555,
      "n": "Enumerated",
      "d": 65555,
      "h": 85899411475,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899411475),
//--TRIMMABLE-BOUNDARY-START(171798757395),
    {
      "t": 65555,
      "n": "Sequence",
      "d": 65555,
      "h": 171798757395,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171798757395),
//--TRIMMABLE-BOUNDARY-START(176093724691),
    {
      "t": 65555,
      "n": "SetOf",
      "d": 65555,
      "h": 176093724691,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176093724691),
//--TRIMMABLE-BOUNDARY-START(206158495763),
    {
      "t": 65555,
      "n": "UtcTime",
      "d": 65555,
      "h": 206158495763,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206158495763),
//--TRIMMABLE-BOUNDARY-START(98784313363),
    {
      "t": 65555,
      "n": "GeneralizedTime",
      "d": 65555,
      "h": 98784313363,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784313363),
//--TRIMMABLE-BOUNDARY-START(51539673107),
    {
      "t": 393217,
      "n": "ClassMask",
      "d": 65555,
      "h": 51539673107,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51539673107),
//--TRIMMABLE-BOUNDARY-START(60129607699),
    {
      "t": 393217,
      "n": "ConstructedMask",
      "d": 65555,
      "h": 60129607699,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60129607699),
//--TRIMMABLE-BOUNDARY-START(68719542291),
    {
      "t": 393217,
      "n": "ControlMask",
      "d": 65555,
      "h": 68719542291,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68719542291),
//--TRIMMABLE-BOUNDARY-START(184683659283),
    {
      "t": 393217,
      "n": "TagNumberMask",
      "d": 65555,
      "h": 184683659283,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(184683659283),
//--TRIMMABLE-BOUNDARY-START(4295032851),
    {
      "t": 393217,
      "n": "_controlFlags",
      "d": 65555,
      "h": 4295032851,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032851)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21474902035),
    {
      "p": [
        {
          "n": "controlFlags",
          "p": 393217
        },
        {
          "n": "tagValue",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65555,
      "h": 21474902035,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21474902035),
//--TRIMMABLE-BOUNDARY-START(30064836627),
    {
      "p": [
        {
          "n": "universalTagNumber",
          "p": 1572883
        },
        {
          "n": "isConstructed",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 65555,
      "h": 30064836627,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064836627),
//--TRIMMABLE-BOUNDARY-START(25769869331),
    {
      "p": [
        {
          "n": "tagClass",
          "p": 1507347
        },
        {
          "n": "tagValue",
          "p": 655361
        },
        {
          "n": "isConstructed",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 65555,
      "h": 25769869331,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769869331),
//--TRIMMABLE-BOUNDARY-START(17179934739),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65555,
      "h": 17179934739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934739)
  ],
  "h": 65555
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$sfa.SFA.Asn1Tag) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.Asn1Tag`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}Asn1Tag`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65555)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900563)
        $asm.$str(`$sfa.SSC.CryptoPoolLease`, ($self) => class CryptoPoolLease extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296867859)
            /*byte[]?*/ _rented = null;
            //--TRIMMABLE-BOUNDARY-END(4296867859)
            
            //--TRIMMABLE-BOUNDARY-START(8591835155)
            /*bool*/ _skipClear = false;
            //--TRIMMABLE-BOUNDARY-END(8591835155)
            
            //--TRIMMABLE-BOUNDARY-START(77311311891)
            /*Span<byte>*/ Span;
            //--TRIMMABLE-BOUNDARY-END(77311311891)
            
            //--TRIMMABLE-BOUNDARY-START(42951573523)
            /*bool */ get IsRented()
            {
                return !(this._rented === null);
            }
            //--TRIMMABLE-BOUNDARY-END(42951573523)
            
            //--TRIMMABLE-BOUNDARY-START(21476737043)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476737043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Return();
            }
            //--TRIMMABLE-BOUNDARY-END(21476737043)
            
            //--TRIMMABLE-BOUNDARY-START(60131442707)
            /*void */ Return()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131442707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Return$1(this._skipClear ? 0 : this.Span.Length);
            }
            //--TRIMMABLE-BOUNDARY-END(60131442707)
            
            //--TRIMMABLE-BOUNDARY-START(64426410003)
            /*void */ Return$1(/*int*/ clearSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426410003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(this._rented === null))
                {
                    $.$sfa.SSC.CryptoPool.Return$1(this._rented, clearSize);
                    this._rented = null;
                }
                else if (!this._skipClear && clearSize > 0)
                {
                    /*Span<byte>*/ let toClear = this.Span.Slice(0, clearSize);
                    toClear.Clear();
                }
                this.Span = new ($.$$.S.Span$$($.$$.S.Byte))();
            }
            //--TRIMMABLE-BOUNDARY-END(64426410003)
            
            //--TRIMMABLE-BOUNDARY-START(47246540819)
            static /*CryptoPoolLease */ Rent(/*int*/ length, /*bool*/ skipClear)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246540819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let rented = $.$sfa.SSC.CryptoPool.Rent(length);
                return (() =>
                {
                    //new $.$sfa.SSC.CryptoPoolLease()
                    const $t1 = $.$sfa.SSC.CryptoPoolLease;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1._rented = rented;
                    $i1._skipClear = skipClear;
                    $i1.Span = new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$6(rented, 0, length);
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(47246540819)
            
            //--TRIMMABLE-BOUNDARY-START(55836475411)
            static /*CryptoPoolLease */ RentConditionally$1(/*int*/ length, /*Span<byte>*/ currentBuffer, /*bool*/ skipClear, /*bool*/ skipClearIfNotRented)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836475411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SSC.CryptoPoolLease.RentConditionally(length, currentBuffer, $.$discardRef(), skipClear, skipClearIfNotRented);
            }
            //--TRIMMABLE-BOUNDARY-END(55836475411)
            
            //--TRIMMABLE-BOUNDARY-START(51541508115)
            static /*CryptoPoolLease */ RentConditionally(/*int*/ length, /*Span<byte>*/ currentBuffer, /*out bool*/ rented, /*bool*/ skipClear, /*bool*/ skipClearIfNotRented)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541508115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (currentBuffer.Length >= length)
                {
                    rented.$v = false;
                    return (() =>
                    {
                        //new $.$sfa.SSC.CryptoPoolLease()
                        const $t2 = $.$sfa.SSC.CryptoPoolLease;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2._rented = null;
                        $i2._skipClear = skipClearIfNotRented || skipClear;
                        $i2.Span = currentBuffer.Slice(0, length);
                        return $i2;
                    })();
                }
                rented.$v = true;
                return $.$sfa.SSC.CryptoPoolLease.Rent(length, skipClear);
            }
            //--TRIMMABLE-BOUNDARY-END(51541508115)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(17181769747)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181769747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181769747)
            
            //--TRIMMABLE-BOUNDARY-START(17181769747)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17181769747)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._rented = this._rented;
                copy._skipClear = this._skipClear;
                copy.Span = this.Span.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(77311311891)
                this.Span = $.$default($.$$.S.Span$$($.$$.S.Byte));
                //--TRIMMABLE-BOUNDARY-END(77311311891)
                
            }
            static $h = 1900563;
            static $z = 10;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77311311891),
    {
      "p": $.$$.S.Span$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656606227,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016344595,
        "f": 83886082
      },
      "n": "Span",
      "d": 1900563,
      "h": 77311311891,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(77311311891),
//--TRIMMABLE-BOUNDARY-START(42951573523),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066671635,
        "f": 50331656
      },
      "n": "IsRented",
      "d": 1900563,
      "h": 42951573523,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(42951573523)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476737043),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1900563,
      "h": 21476737043,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476737043),
//--TRIMMABLE-BOUNDARY-START(60131442707),
    {
      "r": 65537,
      "n": "Return",
      "d": 1900563,
      "h": 60131442707,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(60131442707),
//--TRIMMABLE-BOUNDARY-START(64426410003),
    {
      "r": 65537,
      "p": [
        {
          "n": "clearSize",
          "p": 655361
        }
      ],
      "n": "Return",
      "o": "@$1",
      "d": 1900563,
      "h": 64426410003,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64426410003),
//--TRIMMABLE-BOUNDARY-START(47246540819),
    {
      "r": 1900563,
      "p": [
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "skipClear",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "Rent",
      "d": 1900563,
      "h": 47246540819,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47246540819),
//--TRIMMABLE-BOUNDARY-START(55836475411),
    {
      "r": 1900563,
      "p": [
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "currentBuffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "skipClear",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "skipClearIfNotRented",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "RentConditionally",
      "o": "@$1",
      "d": 1900563,
      "h": 55836475411,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55836475411),
//--TRIMMABLE-BOUNDARY-START(51541508115),
    {
      "r": 1900563,
      "p": [
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "currentBuffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "rented",
          "p": 262145,
          "f": 2
        },
        {
          "n": "skipClear",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "skipClearIfNotRented",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "RentConditionally",
      "d": 1900563,
      "h": 51541508115,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51541508115)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296867859),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_rented",
      "d": 1900563,
      "h": 4296867859,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296867859),
//--TRIMMABLE-BOUNDARY-START(8591835155),
    {
      "t": 262145,
      "n": "_skipClear",
      "d": 1900563,
      "h": 8591835155,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591835155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181769747),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1900563,
      "h": 17181769747,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181769747)
  ],
  "h": 1900563
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Cryptography.CryptoPoolLease`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Cryptography${separator}CryptoPoolLease`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900563)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441811)
        $asm.$cls(`$sfa.SFA.T61Encoding`, ($self) => class T61Encoding extends $.$$.ST.Encoding
        {
            //--TRIMMABLE-BOUNDARY-START(73015885843)
            /*UTF8Encoding*/ static s_utf8Encoding = null;
            //--TRIMMABLE-BOUNDARY-END(73015885843)
            
            //--TRIMMABLE-BOUNDARY-START(68720918547)
            /*Encoding*/ static s_latin1Encoding = null;
            //--TRIMMABLE-BOUNDARY-END(68720918547)
            
            //--TRIMMABLE-BOUNDARY-START(12886343699)
            /*int */ GetByteCount(/*char[]*/ chars, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886343699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.T61Encoding.s_utf8Encoding.GetByteCount(chars, index, count);
            }
            //--TRIMMABLE-BOUNDARY-END(12886343699)
            
            //--TRIMMABLE-BOUNDARY-START(17181310995)
            /*int */ GetByteCount$3(/*char**/ chars, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181310995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.T61Encoding.s_utf8Encoding.GetByteCount$3(chars, count);
            }
            //--TRIMMABLE-BOUNDARY-END(17181310995)
            
            //--TRIMMABLE-BOUNDARY-START(25771245587)
            /*int */ GetByteCount$6(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771245587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.T61Encoding.s_utf8Encoding.GetByteCount$6(s);
            }
            //--TRIMMABLE-BOUNDARY-END(25771245587)
            
            //--TRIMMABLE-BOUNDARY-START(21476278291)
            /*int */ GetByteCount$4(/*ReadOnlySpan<char>*/ chars)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476278291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.T61Encoding.s_utf8Encoding.GetByteCount$4(chars);
            }
            //--TRIMMABLE-BOUNDARY-END(21476278291)
            
            //--TRIMMABLE-BOUNDARY-START(30066212883)
            /*int */ GetBytes(/*char[]*/ chars, /*int*/ charIndex, /*int*/ charCount, /*byte[]*/ bytes, /*int*/ byteIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066212883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.T61Encoding.s_utf8Encoding.GetBytes(chars, charIndex, charCount, bytes, byteIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(30066212883)
            
            //--TRIMMABLE-BOUNDARY-START(34361180179)
            /*int */ GetBytes$4(/*char**/ chars, /*int*/ charCount, /*byte**/ bytes, /*int*/ byteCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361180179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.T61Encoding.s_utf8Encoding.GetBytes$4(chars, charCount, bytes, byteCount);
            }
            //--TRIMMABLE-BOUNDARY-END(34361180179)
            
            //--TRIMMABLE-BOUNDARY-START(38656147475)
            /*int */ GetCharCount(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656147475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return $.$sfa.SFA.T61Encoding.s_utf8Encoding.GetCharCount(bytes, index, count);
                }
                catch($e)
                {
                    return $.$sfa.SFA.T61Encoding.s_latin1Encoding.GetCharCount(bytes, index, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656147475)
            
            //--TRIMMABLE-BOUNDARY-START(42951114771)
            /*int */ GetCharCount$3(/*byte**/ bytes, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951114771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return $.$sfa.SFA.T61Encoding.s_utf8Encoding.GetCharCount$3(bytes, count);
                }
                catch($e)
                {
                    return $.$sfa.SFA.T61Encoding.s_latin1Encoding.GetCharCount$3(bytes, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951114771)
            
            //--TRIMMABLE-BOUNDARY-START(47246082067)
            /*int */ GetCharCount$4(/*ReadOnlySpan<byte>*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246082067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return $.$sfa.SFA.T61Encoding.s_utf8Encoding.GetCharCount$4(bytes);
                }
                catch($e)
                {
                    return $.$sfa.SFA.T61Encoding.s_latin1Encoding.GetCharCount$4(bytes);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246082067)
            
            //--TRIMMABLE-BOUNDARY-START(51541049363)
            /*int */ GetChars(/*byte[]*/ bytes, /*int*/ byteIndex, /*int*/ byteCount, /*char[]*/ chars, /*int*/ charIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541049363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return $.$sfa.SFA.T61Encoding.s_utf8Encoding.GetChars(bytes, byteIndex, byteCount, chars, charIndex);
                }
                catch($e)
                {
                    return $.$sfa.SFA.T61Encoding.s_latin1Encoding.GetChars(bytes, byteIndex, byteCount, chars, charIndex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541049363)
            
            //--TRIMMABLE-BOUNDARY-START(55836016659)
            /*int */ GetChars$4(/*byte**/ bytes, /*int*/ byteCount, /*char**/ chars, /*int*/ charCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836016659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return $.$sfa.SFA.T61Encoding.s_utf8Encoding.GetChars$4(bytes, byteCount, chars, charCount);
                }
                catch($e)
                {
                    return $.$sfa.SFA.T61Encoding.s_latin1Encoding.GetChars$4(bytes, byteCount, chars, charCount);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836016659)
            
            //--TRIMMABLE-BOUNDARY-START(60130983955)
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130983955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sfa.SFA.T61Encoding.s_utf8Encoding.GetMaxByteCount(charCount);
            }
            //--TRIMMABLE-BOUNDARY-END(60130983955)
            
            //--TRIMMABLE-BOUNDARY-START(64425951251)
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425951251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return byteCount;
            }
            //--TRIMMABLE-BOUNDARY-END(64425951251)
            
            //--TRIMMABLE-BOUNDARY-START(8591376403)
            //default constructor overload
            $ctor$4()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591376403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591376403)
            
            //--TRIMMABLE-BOUNDARY-START(8591376403)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(8591376403)
            
            //--TRIMMABLE-BOUNDARY-START(4296409107)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(73015885843)
                    this.s_utf8Encoding = new $.$$.ST.UTF8Encoding().$ctor$5(false, true);
                    //--TRIMMABLE-BOUNDARY-END(73015885843)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720918547)
                    this.s_latin1Encoding = $.$$.ST.Encoding.GetEncoding$3("iso-8859-1");
                    //--TRIMMABLE-BOUNDARY-END(68720918547)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296409107)
            
            static $h = 1441811;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.ST.Encoding; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886343699),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetByteCount",
      "d": 1441811,
      "h": 12886343699,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886343699),
//--TRIMMABLE-BOUNDARY-START(17181310995),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetByteCount",
      "o": "@$3",
      "d": 1441811,
      "h": 17181310995,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181310995),
//--TRIMMABLE-BOUNDARY-START(25771245587),
    {
      "r": 655361,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "GetByteCount",
      "o": "@$6",
      "d": 1441811,
      "h": 25771245587,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771245587),
//--TRIMMABLE-BOUNDARY-START(21476278291),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "GetByteCount",
      "o": "@$4",
      "d": 1441811,
      "h": 21476278291,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476278291),
//--TRIMMABLE-BOUNDARY-START(30066212883),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "charIndex",
          "p": 655361
        },
        {
          "n": "charCount",
          "p": 655361
        },
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "byteIndex",
          "p": 655361
        }
      ],
      "n": "GetBytes",
      "d": 1441811,
      "h": 30066212883,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066212883),
//--TRIMMABLE-BOUNDARY-START(34361180179),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "charCount",
          "p": 655361
        },
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "byteCount",
          "p": 655361
        }
      ],
      "n": "GetBytes",
      "o": "@$4",
      "d": 1441811,
      "h": 34361180179,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361180179),
//--TRIMMABLE-BOUNDARY-START(38656147475),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetCharCount",
      "d": 1441811,
      "h": 38656147475,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656147475),
//--TRIMMABLE-BOUNDARY-START(42951114771),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetCharCount",
      "o": "@$3",
      "d": 1441811,
      "h": 42951114771,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951114771),
//--TRIMMABLE-BOUNDARY-START(47246082067),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetCharCount",
      "o": "@$4",
      "d": 1441811,
      "h": 47246082067,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246082067),
//--TRIMMABLE-BOUNDARY-START(51541049363),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "byteIndex",
          "p": 655361
        },
        {
          "n": "byteCount",
          "p": 655361
        },
        {
          "n": "chars",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "charIndex",
          "p": 655361
        }
      ],
      "n": "GetChars",
      "d": 1441811,
      "h": 51541049363,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541049363),
//--TRIMMABLE-BOUNDARY-START(55836016659),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "byteCount",
          "p": 655361
        },
        {
          "n": "chars",
          "p": $.$typePointer($.$$.S.Char).$h
        },
        {
          "n": "charCount",
          "p": 655361
        }
      ],
      "n": "GetChars",
      "o": "@$4",
      "d": 1441811,
      "h": 55836016659,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55836016659),
//--TRIMMABLE-BOUNDARY-START(60130983955),
    {
      "r": 655361,
      "p": [
        {
          "n": "charCount",
          "p": 655361
        }
      ],
      "n": "GetMaxByteCount",
      "d": 1441811,
      "h": 60130983955,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130983955),
//--TRIMMABLE-BOUNDARY-START(64425951251),
    {
      "r": 655361,
      "p": [
        {
          "n": "byteCount",
          "p": 655361
        }
      ],
      "n": "GetMaxCharCount",
      "d": 1441811,
      "h": 64425951251,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425951251)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015885843),
    {
      "t": 169607169,
      "n": "s_utf8Encoding",
      "d": 1441811,
      "h": 73015885843,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73015885843),
//--TRIMMABLE-BOUNDARY-START(68720918547),
    {
      "t": 166723585,
      "n": "s_latin1Encoding",
      "d": 1441811,
      "h": 68720918547,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68720918547)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591376403),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1441811,
      "h": 8591376403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591376403)
  ],
  "h": 1441811
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.T61Encoding`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}T61Encoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441811)
        
        

        //--TRIMMABLE-BOUNDARY-START(983059)
        $asm.$cls(`$sfa.SFA.BMPEncoding`, ($self) => class BMPEncoding extends $.$sfa.SFA.SpanBasedEncoding
        {
            //--TRIMMABLE-BOUNDARY-START(8590917651)
            /*int */ GetBytes$9(/*ReadOnlySpan<char>*/ chars, /*Span<byte>*/ bytes, /*bool*/ write)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590917651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (chars.IsEmpty)
                {
                    return 0;
                }
                /*int*/ let writeIdx = 0;
                for(/*int*/ let i = 0; i < chars.Length; i++)
                {
                    /*char*/ let c = chars._reference.GetAt(i);
                    if ($.$$.S.Char.IsSurrogate$1(c))
                    {
                        this.EncoderFallback.CreateFallbackBuffer().Fallback$1(c, i);
                        $.$$.SD.Debug.Fail$1("Fallback should have thrown");
                        throw new $.$$.S.InvalidOperationException().$ctor$9();
                    }
                    /*ushort*/ let val16 = c;
                    if (write)
                    {
                        bytes._reference.SetAt(((val16 & 0xFF) >>> 0), ((writeIdx + 1) | 0));
                        bytes._reference.SetAt($.$cast((val16 >>> 8), $.$$.S.Byte), writeIdx);
                    }
                    writeIdx += 2;
                }
                return writeIdx;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917651)
            
            //--TRIMMABLE-BOUNDARY-START(12885884947)
            /*int */ GetChars$6(/*ReadOnlySpan<byte>*/ bytes, /*Span<char>*/ chars, /*bool*/ write)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885884947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (bytes.IsEmpty)
                {
                    return 0;
                }
                if (bytes.Length % 2 !== 0)
                {
                    this.DecoderFallback.CreateFallbackBuffer().Fallback(bytes.Slice$1(((bytes.Length - 1) | 0)).ToArray(), ((bytes.Length - 1) | 0));
                    $.$$.SD.Debug.Fail$1("Fallback should have thrown");
                    throw new $.$$.S.InvalidOperationException().$ctor$9();
                }
                /*int*/ let writeIdx = 0;
                for(/*int*/ let i = 0; i < bytes.Length; i += 2)
                {
                    /*char*/ let c = $.$cast($.$$.SBB.BinaryPrimitives.ReadInt16BigEndian(bytes.Slice$1(i)), $.$$.S.Char);
                    if ($.$$.S.Char.IsSurrogate$1(c))
                    {
                        this.DecoderFallback.CreateFallbackBuffer().Fallback(bytes.Slice(i, 2).ToArray(), i);
                        $.$$.SD.Debug.Fail$1("Fallback should have thrown");
                        throw new $.$$.S.InvalidOperationException().$ctor$9();
                    }
                    if (write)
                    {
                        chars._reference.SetAt(c, writeIdx);
                    }
                    writeIdx++;
                }
                return writeIdx;
            }
            //--TRIMMABLE-BOUNDARY-END(12885884947)
            
            //--TRIMMABLE-BOUNDARY-START(17180852243)
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //checked
                {
                    return $.$checked(charCount * 2, 1);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180852243)
            
            //--TRIMMABLE-BOUNDARY-START(21475819539)
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.trunc(byteCount / 2);
            }
            //--TRIMMABLE-BOUNDARY-END(21475819539)
            
            //--TRIMMABLE-BOUNDARY-START(4295950355)
            //default constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950355)
            
            //--TRIMMABLE-BOUNDARY-START(4295950355)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295950355)
            
            static $h = 983059;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sfa.SFA.SpanBasedEncoding; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590917651),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "bytes",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "write",
          "p": 262145
        }
      ],
      "n": "GetBytes",
      "o": "@$9",
      "d": 983059,
      "h": 8590917651,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590917651),
//--TRIMMABLE-BOUNDARY-START(12885884947),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "chars",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        },
        {
          "n": "write",
          "p": 262145
        }
      ],
      "n": "GetChars",
      "o": "@$6",
      "d": 983059,
      "h": 12885884947,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12885884947),
//--TRIMMABLE-BOUNDARY-START(17180852243),
    {
      "r": 655361,
      "p": [
        {
          "n": "charCount",
          "p": 655361
        }
      ],
      "n": "GetMaxByteCount",
      "d": 983059,
      "h": 17180852243,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180852243),
//--TRIMMABLE-BOUNDARY-START(21475819539),
    {
      "r": 655361,
      "p": [
        {
          "n": "byteCount",
          "p": 655361
        }
      ],
      "n": "GetMaxCharCount",
      "d": 983059,
      "h": 21475819539,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475819539)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950355),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 983059,
      "h": 4295950355,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950355)
  ],
  "h": 983059
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.BMPEncoding`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}BMPEncoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983059)
        
        

        //--TRIMMABLE-BOUNDARY-START(524307)
        $asm.$str(`$sfa.SFA.AsnEncodingRules`, ($self) => class AsnEncodingRules extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static BER = 0;
            static CER = 1;
            static DER = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "BER": 0n,
                    "CER": 1n,
                    "DER": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295491603)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491603)
            
            //--TRIMMABLE-BOUNDARY-START(4295491603)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295491603)
            
            static $h = 524307;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590458899),
    {
      "t": 524307,
      "n": "BER",
      "d": 524307,
      "h": 8590458899,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458899),
//--TRIMMABLE-BOUNDARY-START(12885426195),
    {
      "t": 524307,
      "n": "CER",
      "d": 524307,
      "h": 12885426195,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426195),
//--TRIMMABLE-BOUNDARY-START(17180393491),
    {
      "t": 524307,
      "n": "DER",
      "d": 524307,
      "h": 17180393491,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393491)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491603),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524307,
      "h": 4295491603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491603)
  ],
  "h": 524307
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.AsnEncodingRules`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}AsnEncodingRules`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524307)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507347)
        $asm.$str(`$sfa.SFA.TagClass`, ($self) => class TagClass extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Universal = 0;
            static Application = 64;
            static ContextSpecific = 128;
            static Private = 192;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1507347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Universal": 0n,
                    "Application": 64n,
                    "ContextSpecific": 128n,
                    "Private": 192n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296474643)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296474643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296474643)
            
            //--TRIMMABLE-BOUNDARY-START(4296474643)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296474643)
            
            static $h = 1507347;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476343827),
    {
      "t": 1507347,
      "n": "Universal",
      "d": 1507347,
      "h": 21476343827,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476343827),
//--TRIMMABLE-BOUNDARY-START(8591441939),
    {
      "t": 1507347,
      "n": "Application",
      "d": 1507347,
      "h": 8591441939,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591441939),
//--TRIMMABLE-BOUNDARY-START(12886409235),
    {
      "t": 1507347,
      "n": "ContextSpecific",
      "d": 1507347,
      "h": 12886409235,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886409235),
//--TRIMMABLE-BOUNDARY-START(17181376531),
    {
      "t": 1507347,
      "n": "Private",
      "d": 1507347,
      "h": 17181376531,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181376531)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296474643),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507347,
      "h": 4296474643,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296474643)
  ],
  "h": 1507347
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.TagClass`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}TagClass`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507347)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572883)
        $asm.$str(`$sfa.SFA.UniversalTagNumber`, ($self) => class UniversalTagNumber extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static EndOfContents = 0;
            static Boolean = 1;
            static Integer = 2;
            static BitString = 3;
            static OctetString = 4;
            static Null = 5;
            static ObjectIdentifier = 6;
            static ObjectDescriptor = 7;
            static External = 8;
            static InstanceOf = 8;
            static Real = 9;
            static Enumerated = 10;
            static Embedded = 11;
            static UTF8String = 12;
            static RelativeObjectIdentifier = 13;
            static Time = 14;
            static Sequence = 16;
            static SequenceOf = 16;
            static Set = 17;
            static SetOf = 17;
            static NumericString = 18;
            static PrintableString = 19;
            static TeletexString = 20;
            static T61String = 20;
            static VideotexString = 21;
            static IA5String = 22;
            static UtcTime = 23;
            static GeneralizedTime = 24;
            static GraphicString = 25;
            static VisibleString = 26;
            static ISO646String = 26;
            static GeneralString = 27;
            static UniversalString = 28;
            static UnrestrictedCharacterString = 29;
            static BMPString = 30;
            static Date = 31;
            static TimeOfDay = 32;
            static DateTime = 33;
            static Duration = 34;
            static ObjectIdentifierIRI = 35;
            static RelativeObjectIdentifierIRI = 36;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1572883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "EndOfContents": 0n,
                    "Boolean": 1n,
                    "Integer": 2n,
                    "BitString": 3n,
                    "OctetString": 4n,
                    "Null": 5n,
                    "ObjectIdentifier": 6n,
                    "ObjectDescriptor": 7n,
                    "External": 8n,
                    "InstanceOf": 8n,
                    "Real": 9n,
                    "Enumerated": 10n,
                    "Embedded": 11n,
                    "UTF8String": 12n,
                    "RelativeObjectIdentifier": 13n,
                    "Time": 14n,
                    "Sequence": 16n,
                    "SequenceOf": 16n,
                    "Set": 17n,
                    "SetOf": 17n,
                    "NumericString": 18n,
                    "PrintableString": 19n,
                    "TeletexString": 20n,
                    "T61String": 20n,
                    "VideotexString": 21n,
                    "IA5String": 22n,
                    "UtcTime": 23n,
                    "GeneralizedTime": 24n,
                    "GraphicString": 25n,
                    "VisibleString": 26n,
                    "ISO646String": 26n,
                    "GeneralString": 27n,
                    "UniversalString": 28n,
                    "UnrestrictedCharacterString": 29n,
                    "BMPString": 30n,
                    "Date": 31n,
                    "TimeOfDay": 32n,
                    "DateTime": 33n,
                    "Duration": 34n,
                    "ObjectIdentifierIRI": 35n,
                    "RelativeObjectIdentifierIRI": 36n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296540179)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540179)
            
            //--TRIMMABLE-BOUNDARY-START(4296540179)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296540179)
            
            static $h = 1572883;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656278547),
    {
      "t": 1572883,
      "n": "EndOfContents",
      "d": 1572883,
      "h": 38656278547,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656278547),
//--TRIMMABLE-BOUNDARY-START(17181442067),
    {
      "t": 1572883,
      "n": "Boolean",
      "d": 1572883,
      "h": 17181442067,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181442067),
//--TRIMMABLE-BOUNDARY-START(73016016915),
    {
      "t": 1572883,
      "n": "Integer",
      "d": 1572883,
      "h": 73016016915,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73016016915),
//--TRIMMABLE-BOUNDARY-START(8591507475),
    {
      "t": 1572883,
      "n": "BitString",
      "d": 1572883,
      "h": 8591507475,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591507475),
//--TRIMMABLE-BOUNDARY-START(103080787987),
    {
      "t": 1572883,
      "n": "OctetString",
      "d": 1572883,
      "h": 103080787987,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103080787987),
//--TRIMMABLE-BOUNDARY-START(81605951507),
    {
      "t": 1572883,
      "n": "Null",
      "d": 1572883,
      "h": 81605951507,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605951507),
//--TRIMMABLE-BOUNDARY-START(94490853395),
    {
      "t": 1572883,
      "n": "ObjectIdentifier",
      "d": 1572883,
      "h": 94490853395,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490853395),
//--TRIMMABLE-BOUNDARY-START(90195886099),
    {
      "t": 1572883,
      "n": "ObjectDescriptor",
      "d": 1572883,
      "h": 90195886099,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195886099),
//--TRIMMABLE-BOUNDARY-START(47246213139),
    {
      "t": 1572883,
      "n": "External",
      "d": 1572883,
      "h": 47246213139,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246213139),
//--TRIMMABLE-BOUNDARY-START(68721049619),
    {
      "t": 1572883,
      "n": "InstanceOf",
      "d": 1572883,
      "h": 68721049619,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68721049619),
//--TRIMMABLE-BOUNDARY-START(111670722579),
    {
      "t": 1572883,
      "n": "Real",
      "d": 1572883,
      "h": 111670722579,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670722579),
//--TRIMMABLE-BOUNDARY-START(42951245843),
    {
      "t": 1572883,
      "n": "Enumerated",
      "d": 1572883,
      "h": 42951245843,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951245843),
//--TRIMMABLE-BOUNDARY-START(34361311251),
    {
      "t": 1572883,
      "n": "Embedded",
      "d": 1572883,
      "h": 34361311251,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361311251),
//--TRIMMABLE-BOUNDARY-START(171800264723),
    {
      "t": 1572883,
      "n": "UTF8String",
      "d": 1572883,
      "h": 171800264723,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171800264723),
//--TRIMMABLE-BOUNDARY-START(115965689875),
    {
      "t": 1572883,
      "n": "RelativeObjectIdentifier",
      "d": 1572883,
      "h": 115965689875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115965689875),
//--TRIMMABLE-BOUNDARY-START(150325428243),
    {
      "t": 1572883,
      "n": "Time",
      "d": 1572883,
      "h": 150325428243,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150325428243),
//--TRIMMABLE-BOUNDARY-START(124555624467),
    {
      "t": 1572883,
      "n": "Sequence",
      "d": 1572883,
      "h": 124555624467,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124555624467),
//--TRIMMABLE-BOUNDARY-START(128850591763),
    {
      "t": 1572883,
      "n": "SequenceOf",
      "d": 1572883,
      "h": 128850591763,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128850591763),
//--TRIMMABLE-BOUNDARY-START(133145559059),
    {
      "t": 1572883,
      "n": "Set",
      "d": 1572883,
      "h": 133145559059,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133145559059),
//--TRIMMABLE-BOUNDARY-START(137440526355),
    {
      "t": 1572883,
      "n": "SetOf",
      "d": 1572883,
      "h": 137440526355,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137440526355),
//--TRIMMABLE-BOUNDARY-START(85900918803),
    {
      "t": 1572883,
      "n": "NumericString",
      "d": 1572883,
      "h": 85900918803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900918803),
//--TRIMMABLE-BOUNDARY-START(107375755283),
    {
      "t": 1572883,
      "n": "PrintableString",
      "d": 1572883,
      "h": 107375755283,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107375755283),
//--TRIMMABLE-BOUNDARY-START(146030460947),
    {
      "t": 1572883,
      "n": "TeletexString",
      "d": 1572883,
      "h": 146030460947,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146030460947),
//--TRIMMABLE-BOUNDARY-START(141735493651),
    {
      "t": 1572883,
      "n": "T61String",
      "d": 1572883,
      "h": 141735493651,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141735493651),
//--TRIMMABLE-BOUNDARY-START(176095232019),
    {
      "t": 1572883,
      "n": "VideotexString",
      "d": 1572883,
      "h": 176095232019,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176095232019),
//--TRIMMABLE-BOUNDARY-START(64426082323),
    {
      "t": 1572883,
      "n": "IA5String",
      "d": 1572883,
      "h": 64426082323,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64426082323),
//--TRIMMABLE-BOUNDARY-START(167505297427),
    {
      "t": 1572883,
      "n": "UtcTime",
      "d": 1572883,
      "h": 167505297427,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167505297427),
//--TRIMMABLE-BOUNDARY-START(51541180435),
    {
      "t": 1572883,
      "n": "GeneralizedTime",
      "d": 1572883,
      "h": 51541180435,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541180435),
//--TRIMMABLE-BOUNDARY-START(60131115027),
    {
      "t": 1572883,
      "n": "GraphicString",
      "d": 1572883,
      "h": 60131115027,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60131115027),
//--TRIMMABLE-BOUNDARY-START(180390199315),
    {
      "t": 1572883,
      "n": "VisibleString",
      "d": 1572883,
      "h": 180390199315,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180390199315),
//--TRIMMABLE-BOUNDARY-START(77310984211),
    {
      "t": 1572883,
      "n": "ISO646String",
      "d": 1572883,
      "h": 77310984211,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310984211),
//--TRIMMABLE-BOUNDARY-START(55836147731),
    {
      "t": 1572883,
      "n": "GeneralString",
      "d": 1572883,
      "h": 55836147731,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836147731),
//--TRIMMABLE-BOUNDARY-START(158915362835),
    {
      "t": 1572883,
      "n": "UniversalString",
      "d": 1572883,
      "h": 158915362835,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158915362835),
//--TRIMMABLE-BOUNDARY-START(163210330131),
    {
      "t": 1572883,
      "n": "UnrestrictedCharacterString",
      "d": 1572883,
      "h": 163210330131,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163210330131),
//--TRIMMABLE-BOUNDARY-START(12886474771),
    {
      "t": 1572883,
      "n": "BMPString",
      "d": 1572883,
      "h": 12886474771,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886474771),
//--TRIMMABLE-BOUNDARY-START(21476409363),
    {
      "t": 1572883,
      "n": "Date",
      "d": 1572883,
      "h": 21476409363,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476409363),
//--TRIMMABLE-BOUNDARY-START(154620395539),
    {
      "t": 1572883,
      "n": "TimeOfDay",
      "d": 1572883,
      "h": 154620395539,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154620395539),
//--TRIMMABLE-BOUNDARY-START(25771376659),
    {
      "t": 1572883,
      "n": "DateTime",
      "d": 1572883,
      "h": 25771376659,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771376659),
//--TRIMMABLE-BOUNDARY-START(30066343955),
    {
      "t": 1572883,
      "n": "Duration",
      "d": 1572883,
      "h": 30066343955,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066343955),
//--TRIMMABLE-BOUNDARY-START(98785820691),
    {
      "t": 1572883,
      "n": "ObjectIdentifierIRI",
      "d": 1572883,
      "h": 98785820691,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98785820691),
//--TRIMMABLE-BOUNDARY-START(120260657171),
    {
      "t": 1572883,
      "n": "RelativeObjectIdentifierIRI",
      "d": 1572883,
      "h": 120260657171,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120260657171)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540179),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1572883,
      "h": 4296540179,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540179)
  ],
  "h": 1572883
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.UniversalTagNumber`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}UniversalTagNumber`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572883)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048595)
        $asm.$cls(`$sfa.SFA.IA5Encoding`, ($self) => class IA5Encoding extends $.$sfa.SFA.RestrictedAsciiStringEncoding
        {
            //--TRIMMABLE-BOUNDARY-START(4296015891)
            $ctor$7()
            {
                super.$ctor$5(0, 127);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296015891);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296015891)
            
            //--TRIMMABLE-BOUNDARY-START(4296015891)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4296015891)
            
            static $h = 1048595;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sfa.SFA.RestrictedAsciiStringEncoding; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015891),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1048595,
      "h": 4296015891,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296015891)
  ],
  "h": 1048595
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.IA5Encoding`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}IA5Encoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048595)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638419)
        $asm.$cls(`$sfa.SFA.VisibleStringEncoding`, ($self) => class VisibleStringEncoding extends $.$sfa.SFA.RestrictedAsciiStringEncoding
        {
            //--TRIMMABLE-BOUNDARY-START(4296605715)
            $ctor$7()
            {
                super.$ctor$5(32, 126);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296605715);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605715)
            
            //--TRIMMABLE-BOUNDARY-START(4296605715)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4296605715)
            
            static $h = 1638419;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sfa.SFA.RestrictedAsciiStringEncoding; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605715),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1638419,
      "h": 4296605715,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296605715)
  ],
  "h": 1638419
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.VisibleStringEncoding`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}VisibleStringEncoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638419)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114131)
        $asm.$cls(`$sfa.SFA.NumericStringEncoding`, ($self) => class NumericStringEncoding extends $.$sfa.SFA.RestrictedAsciiStringEncoding
        {
            //--TRIMMABLE-BOUNDARY-START(4296081427)
            $ctor$7()
            {
                super.$ctor$6("0123456789 ");
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296081427);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296081427)
            
            //--TRIMMABLE-BOUNDARY-START(4296081427)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4296081427)
            
            static $h = 1114131;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sfa.SFA.RestrictedAsciiStringEncoding; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081427),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1114131,
      "h": 4296081427,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296081427)
  ],
  "h": 1114131
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.NumericStringEncoding`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}NumericStringEncoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114131)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179667)
        $asm.$cls(`$sfa.SFA.PrintableStringEncoding`, ($self) => class PrintableStringEncoding extends $.$sfa.SFA.RestrictedAsciiStringEncoding
        {
            //--TRIMMABLE-BOUNDARY-START(4296146963)
            $ctor$7()
            {
                super.$ctor$6("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 '()+,-./:=?");
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296146963);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296146963)
            
            //--TRIMMABLE-BOUNDARY-START(4296146963)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$7();
            }
            //--TRIMMABLE-BOUNDARY-END(4296146963)
            
            static $h = 1179667;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sfa.SFA.RestrictedAsciiStringEncoding; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296146963),
    {
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1179667,
      "h": 4296146963,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296146963)
  ],
  "h": 1179667
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.PrintableStringEncoding`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}PrintableStringEncoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179667)
        
        

        //--TRIMMABLE-BOUNDARY-START(196627)
        $asm.$cls(`$sfa.SFA.AsnContentException`, ($self) => class AsnContentException extends $.$$.S.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(4295163923)
            $ctor$5()
            {
                super.$ctor$4($.$sfa.S.SR.ContentException_DefaultMessage);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295163923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163923)
            
            //--TRIMMABLE-BOUNDARY-START(17180065811)
            $ctor$8(/*string?*/ message)
            {
                super.$ctor$4(message ?? $.$sfa.S.SR.ContentException_DefaultMessage);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065811);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065811)
            
            //--TRIMMABLE-BOUNDARY-START(12885098515)
            $ctor$7(/*string?*/ message, /*Exception?*/ inner)
            {
                super.$ctor$3(message ?? $.$sfa.S.SR.ContentException_DefaultMessage, inner);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885098515);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098515)
            
            //--TRIMMABLE-BOUNDARY-START(8590131219)
            $ctor$6(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$2(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131219);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131219)
            
            //--TRIMMABLE-BOUNDARY-START(4295163923)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295163923)
            
            static $h = 196627;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Exception; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 196627
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.AsnContentException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}AsnContentException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196627)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310739)
        $asm.$cls(`$sfa.SFA.SetOfValueComparer`, ($self) => class SetOfValueComparer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361049107)
            /*SetOfValueComparer*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(34361049107)
            
            //--TRIMMABLE-BOUNDARY-START(17181179923)
            /*int */ Compare(/*ReadOnlyMemory<byte>*/ x, /*ReadOnlyMemory<byte>*/ y)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181179923);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sfa.SFA.SetOfValueComparer.Compare$1(x.Span, y.Span);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181179923)
            
            //--TRIMMABLE-BOUNDARY-START(21476147219)
            static /*int */ Compare$1(/*ReadOnlySpan<byte>*/ x, /*ReadOnlySpan<byte>*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let min = $.$$.S.Math.Min$4(x.Length, y.Length);
                /*int*/ let diff;
                /*int*/ let diffIndex = $.$$.S.MemoryExtensions.CommonPrefixLength$1($.$$.S.Byte, x, y);
                if (diffIndex !== min)
                {
                    return (($.$cast(x._reference.GetAt(diffIndex), $.$$.S.Int32) - y._reference.GetAt(diffIndex)) | 0);
                }
                diff = ((x.Length - y.Length) | 0);
                return diff;
            }
            //--TRIMMABLE-BOUNDARY-END(21476147219)
            
            //--TRIMMABLE-BOUNDARY-START(4355129345)
            //Generated interface implemetation for System.Collections.Generic.IComparer<System.ReadOnlyMemory<byte>>.Compare(System.ReadOnlyMemory<byte>, System.ReadOnlyMemory<byte>)
            [`SCG$IComparer$System$ReadOnlyMemory$System$Byte$$Compare`]()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355129345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355129345)
            
            //--TRIMMABLE-BOUNDARY-START(12886212627)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886212627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886212627)
            
            //--TRIMMABLE-BOUNDARY-START(12886212627)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886212627)
            
            //--TRIMMABLE-BOUNDARY-START(8591245331)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591245331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(34361049107)
                    this.Instance = new $.$sfa.SFA.SetOfValueComparer().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(34361049107)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591245331)
            
            static $h = 1310739;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361049107),
    {
      "p": 1310739,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066081811,
        "f": 50331688
      },
      "n": "Instance",
      "d": 1310739,
      "h": 34361049107,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(34361049107)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181179923),
    {
      "r": 655361,
      "p": [
        {
          "n": "x",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "y",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        }
      ],
      "n": "Compare",
      "d": 1310739,
      "h": 17181179923,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181179923),
//--TRIMMABLE-BOUNDARY-START(21476147219),
    {
      "r": 655361,
      "p": [
        {
          "n": "x",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "y",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Compare",
      "o": "@$1",
      "d": 1310739,
      "h": 21476147219,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21476147219)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886212627),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310739,
      "h": 12886212627,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886212627)
  ],
  "h": 1310739
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IComparer$$($.$$.S.ReadOnlyMemory$$($.$$.S.Byte)) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Formats.Asn1.SetOfValueComparer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Formats${separator}Asn1${separator}SetOfValueComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310739)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Numerics", "NetJs.System.Text.Encoding.Extensions"));
})();
//--TRIMMABLE-BOUNDARY-END(19)
