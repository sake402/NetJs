
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $sri, $srn, $stee) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Formats.Asn1", 
    {"h":61294,"f":"System.Formats.Asn1","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Formats.Asn1","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Formats.Asn1","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sfa.System.Formats.Asn1.SpanBasedEncoding", ($self) => class SpanBasedEncoding extends $.$$.System.Text.Encoding
        {
            $ctor$4()
            {
                super.$ctor$2(0, $.$$.System.Text.EncoderFallback.ExceptionFallback, $.$$.System.Text.DecoderFallback.ExceptionFallback);
                {
                }
                return this;
            }
            /*int */ GetByteCount(/*char[]*/ chars, /*int*/ index, /*int*/ count)
            {
                return this.GetByteCount$4(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$3(chars, index, count));
            }
            /*int */ GetByteCount$3(/*char**/ chars, /*int*/ count)
            {
                return this.GetByteCount$4(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(chars, count));
            }
            /*int */ GetByteCount$6(/*string*/ s)
            {
                return this.GetByteCount$4($.$$.System.MemoryExtensions.AsSpan$4(s));
            }
            /*int */ GetByteCount$4(/*ReadOnlySpan<char>*/ chars)
            {
                return this.GetBytes$9(chars, $.$$.System.Span$$($.$$.System.Byte).Empty, false);
            }
            /*int */ GetBytes(/*char[]*/ chars, /*int*/ charIndex, /*int*/ charCount, /*byte[]*/ bytes, /*int*/ byteIndex)
            {
                return this.GetBytes$9(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$3(chars, charIndex, charCount), new ($.$$.System.Span$$($.$$.System.Byte))().$ctor$3(bytes, byteIndex, ((bytes.length - byteIndex) | 0)), true);
            }
            /*int */ GetBytes$4(/*char**/ chars, /*int*/ charCount, /*byte**/ bytes, /*int*/ byteCount)
            {
                return this.GetBytes$9(new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$5(chars, charCount), new ($.$$.System.Span$$($.$$.System.Byte))().$ctor$5(bytes, byteCount), true);
            }
            /*int */ GetCharCount(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                return this.GetCharCount$4(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$3(bytes, index, count));
            }
            /*int */ GetCharCount$3(/*byte**/ bytes, /*int*/ count)
            {
                return this.GetCharCount$4(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$5(bytes, count));
            }
            /*int */ GetCharCount$4(/*ReadOnlySpan<byte>*/ bytes)
            {
                return this.GetChars$6(bytes, $.$$.System.Span$$($.$$.System.Char).Empty, false);
            }
            /*int */ GetChars(/*byte[]*/ bytes, /*int*/ byteIndex, /*int*/ byteCount, /*char[]*/ chars, /*int*/ charIndex)
            {
                return this.GetChars$6(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$3(bytes, byteIndex, byteCount), new ($.$$.System.Span$$($.$$.System.Char))().$ctor$3(chars, charIndex, ((chars.length - charIndex) | 0)), true);
            }
            /*int */ GetChars$4(/*byte**/ bytes, /*int*/ byteCount, /*char**/ chars, /*int*/ charCount)
            {
                return this.GetChars$6(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$5(bytes, byteCount), new ($.$$.System.Span$$($.$$.System.Char))().$ctor$5(chars, charCount), true);
            }
            static $h = 1437550;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":121700353,"m":[{"r":655361,"p":[{"n":"chars","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"bytes","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"write","p":262145}],"n":"GetBytes","o":"@$9","d":1437550,"h":8591372142,"f":16777476},{"r":655361,"p":[{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"chars","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"write","p":262145}],"n":"GetChars","o":"@$6","d":1437550,"h":12886339438,"f":16777476},{"r":655361,"p":[{"n":"chars","p":$.$typeArray($.$$.System.Char).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetByteCount","d":1437550,"h":17181306734,"f":16809985},{"r":655361,"p":[{"n":"chars","p":$.$typePointer($.$$.System.Char).$h},{"n":"count","p":655361}],"n":"GetByteCount","o":"@$3","d":1437550,"h":21476274030,"f":16809985},{"r":655361,"p":[{"n":"s","p":1310721}],"n":"GetByteCount","o":"@$6","d":1437550,"h":25771241326,"f":16809985},{"r":655361,"p":[{"n":"chars","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"GetByteCount","o":"@$4","d":1437550,"h":30066208622,"f":16809985},{"r":655361,"p":[{"n":"chars","p":$.$typeArray($.$$.System.Char).$h},{"n":"charIndex","p":655361},{"n":"charCount","p":655361},{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"byteIndex","p":655361}],"n":"GetBytes","d":1437550,"h":34361175918,"f":16809985},{"r":655361,"p":[{"n":"chars","p":$.$typePointer($.$$.System.Char).$h},{"n":"charCount","p":655361},{"n":"bytes","p":$.$typePointer($.$$.System.Byte).$h},{"n":"byteCount","p":655361}],"n":"GetBytes","o":"@$4","d":1437550,"h":38656143214,"f":16809985},{"r":655361,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetCharCount","d":1437550,"h":42951110510,"f":16809985},{"r":655361,"p":[{"n":"bytes","p":$.$typePointer($.$$.System.Byte).$h},{"n":"count","p":655361}],"n":"GetCharCount","o":"@$3","d":1437550,"h":47246077806,"f":16809985},{"r":655361,"p":[{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"GetCharCount","o":"@$4","d":1437550,"h":51541045102,"f":16809985},{"r":655361,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"byteIndex","p":655361},{"n":"byteCount","p":655361},{"n":"chars","p":$.$typeArray($.$$.System.Char).$h},{"n":"charIndex","p":655361}],"n":"GetChars","d":1437550,"h":55836012398,"f":16809985},{"r":655361,"p":[{"n":"bytes","p":$.$typePointer($.$$.System.Byte).$h},{"n":"byteCount","p":655361},{"n":"chars","p":$.$typePointer($.$$.System.Char).$h},{"n":"charCount","p":655361}],"n":"GetChars","o":"@$4","d":1437550,"h":60130979694,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$4","d":1437550,"h":4296404846,"f":16777220}],"i":[57212929],"h":1437550}; }
            static get $b() { return $.$$.System.Text.Encoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.SpanBasedEncoding`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding", ($self) => class RestrictedAsciiStringEncoding extends $.$sfa.System.Formats.Asn1.SpanBasedEncoding
        {
            /*bool[]*/ _isAllowed = null;
            $ctor$5(/*byte*/ minCharAllowed, /*byte*/ maxCharAllowed)
            {
                super.$ctor$4();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(minCharAllowed <= maxCharAllowed, "minCharAllowed <= maxCharAllowed");
                    $.$$.System.Diagnostics.Debug.Assert$2(maxCharAllowed <= 127, "maxCharAllowed <= 0x7F");
                    /*bool[]*/ let isAllowed = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Boolean), null, [128], null);
                    $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Boolean, isAllowed, minCharAllowed, ((maxCharAllowed - minCharAllowed + 1) | 0)).Fill(true);
                    this._isAllowed = isAllowed;
                }
                return this;
            }
            $ctor$6(/*string*/ allowedChars)
            {
                super.$ctor$4();
                {
                    /*bool[]*/ let isAllowed = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Boolean), null, [127], null);
                    var $en3 = $.$$.System.String.GetEnumerator.call(allowedChars);
                    while ($en3.MoveNext())
                    {
                        var c = $en3.Current;
                        {
                            if (c >= isAllowed.length)
                            {
                                throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("allowedChars");
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Array.$ReadT1.call(isAllowed, c) === false, "isAllowed[c] == false");
                            $.$$.System.Array.$WriteT1.call(isAllowed, true, c);
                        }
                    }
                    this._isAllowed = isAllowed;
                }
                return this;
            }
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                return charCount;
            }
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                return byteCount;
            }
            /*int */ GetBytes$9(/*ReadOnlySpan<char>*/ chars, /*Span<byte>*/ bytes, /*bool*/ write)
            {
                if (chars.IsEmpty)
                {
                    return 0;
                }
                for(/*int*/ let i = 0; i < chars.Length; i++)
                {
                    /*char*/ let c = chars.get_Item(i).$v;
                    if (c >= (this._isAllowed.length >>> 0) || !$.$$.System.Array.$ReadT1.call(this._isAllowed, c))
                    {
                        this.EncoderFallback.CreateFallbackBuffer().Fallback$1(c, i);
                        $.$$.System.Diagnostics.Debug.Fail$1("Fallback should have thrown");
                        throw new $.$$.System.InvalidOperationException().$ctor$9();
                    }
                    if (write)
                    {
                        bytes.get_Item(i).$v = $.$cast(c, $.$$.System.Byte);
                    }
                }
                return chars.Length;
            }
            /*int */ GetChars$6(/*ReadOnlySpan<byte>*/ bytes, /*Span<char>*/ chars, /*bool*/ write)
            {
                if (bytes.IsEmpty)
                {
                    return 0;
                }
                for(/*int*/ let i = 0; i < bytes.Length; i++)
                {
                    /*byte*/ let b = bytes.get_Item(i).$v;
                    if (b >= (this._isAllowed.length >>> 0) || !$.$$.System.Array.$ReadT1.call(this._isAllowed, b))
                    {
                        this.DecoderFallback.CreateFallbackBuffer().Fallback($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), [b], null, null), i);
                        $.$$.System.Diagnostics.Debug.Fail$1("Fallback should have thrown");
                        throw new $.$$.System.InvalidOperationException().$ctor$9();
                    }
                    if (write)
                    {
                        chars.get_Item(i).$v = b;
                    }
                }
                return bytes.Length;
            }
            static $h = 1306478;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1437550,"m":[{"r":655361,"p":[{"n":"charCount","p":655361}],"n":"GetMaxByteCount","d":1306478,"h":17181175662,"f":16809985},{"r":655361,"p":[{"n":"byteCount","p":655361}],"n":"GetMaxCharCount","d":1306478,"h":21476142958,"f":16809985},{"r":655361,"p":[{"n":"chars","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"bytes","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"write","p":262145}],"n":"GetBytes","o":"@$9","d":1306478,"h":25771110254,"f":16809988},{"r":655361,"p":[{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"chars","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"write","p":262145}],"n":"GetChars","o":"@$6","d":1306478,"h":30066077550,"f":16809988}],"l":[{"t":$.$typeArray($.$$.System.Boolean).$h,"n":"_isAllowed","d":1306478,"h":4296273774,"f":4194306}],"c":[{"p":[{"n":"minCharAllowed","p":393217},{"n":"maxCharAllowed","p":393217}],"n":".ctor","o":"$ctor$5","d":1306478,"h":8591241070,"f":16777220},{"p":[{"n":"allowedChars","p":1310721}],"n":".ctor","o":"$ctor$6","d":1306478,"h":12886208366,"f":16777220}],"i":[57212929],"h":1306478}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.SpanBasedEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.RestrictedAsciiStringEncoding`; }
        });
        
        $asm.$cls("$sfa.System.Security.Cryptography.CryptoPool", ($self) => class CryptoPool
        {
            /*int*/ static ClearAll = -1;
            static /*byte[] */ Rent(/*int*/ minimumLength)
            {
                return $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(minimumLength);
            }
            static /*void */ Return(/*ArraySegment<byte>*/ arraySegment, /*int*/ clearSize)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(arraySegment.Array !== null, "arraySegment.Array != null");
                $.$$.System.Diagnostics.Debug.Assert$2(arraySegment.Offset === 0, "arraySegment.Offset == 0");
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(arraySegment.Array, clearSize === -1/*ClearAll*/ ? arraySegment.Count : clearSize);
            }
            static /*void */ Return$1(/*byte[]*/ array, /*int*/ clearSize)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(clearSize <= array.length, "clearSize <= array.Length");
                /*bool*/ let clearWholeArray = clearSize < 0;
                if (!clearWholeArray && clearSize !== 0)
                {
                    $.$$.System.Array.Clear(array, 0, clearSize);
                }
                $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(array, clearWholeArray);
            }
            static $h = 1896302;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"minimumLength","p":655361}],"n":"Rent","d":1896302,"h":8591830894,"f":16777256},{"r":65537,"p":[{"n":"arraySegment","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"clearSize","p":655361,"f":65,"v":-1}],"n":"Return","d":1896302,"h":12886798190,"f":16777256},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$$.System.Byte).$h},{"n":"clearSize","p":655361,"f":65,"v":-1}],"n":"Return","o":"@$1","d":1896302,"h":17181765486,"f":16777256}],"l":[{"t":655361,"n":"ClearAll","d":1896302,"h":4296863598,"f":4194344}],"h":1896302}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.Cryptography.CryptoPool`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.AsnCharacterStringEncodings", ($self) => class AsnCharacterStringEncodings
        {
            /*UTF8Encoding*/ static s_utf8Encoding = null;
            /*BMPEncoding*/ static s_bmpEncoding = null;
            /*IA5Encoding*/ static s_ia5Encoding = null;
            /*VisibleStringEncoding*/ static s_visibleStringEncoding = null;
            /*NumericStringEncoding*/ static s_numericStringEncoding = null;
            /*PrintableStringEncoding*/ static s_printableStringEncoding = null;
            /*T61Encoding*/ static s_t61Encoding = null;
            static /*Encoding */ GetEncoding(/*UniversalTagNumber*/ encodingType)
            {
                return (() =>
                {
                    if (encodingType === 12/*UniversalTagNumber.UTF8String*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_utf8Encoding;
                    }
                    if (encodingType === 18/*UniversalTagNumber.NumericString*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_numericStringEncoding;
                    }
                    if (encodingType === 19/*UniversalTagNumber.PrintableString*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_printableStringEncoding;
                    }
                    if (encodingType === 22/*UniversalTagNumber.IA5String*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_ia5Encoding;
                    }
                    if (encodingType === 26/*UniversalTagNumber.VisibleString*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_visibleStringEncoding;
                    }
                    if (encodingType === 30/*UniversalTagNumber.BMPString*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_bmpEncoding;
                    }
                    if (encodingType === 20/*UniversalTagNumber.T61String*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_t61Encoding;
                    }
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("encodingType", $.$box(encodingType, $.$sfa.System.Formats.Asn1.UniversalTagNumber), null);
                })();
            }
            static /*int */ GetByteCount(/*this Encoding*/ encoding, /*ReadOnlySpan<char>*/ str)
            {
                if (str.IsEmpty)
                {
                    str = $.$$.System.MemoryExtensions.AsSpan$4($.$$.System.String.Empty);
                }
                {
                    /*fixed*/ 
                    {
                        /*char**/ let strPtr = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Char, str);
                        return encoding.GetByteCount$3(strPtr, str.Length);
                    }
                }
            }
            static /*int */ GetBytes(/*this Encoding*/ encoding, /*ReadOnlySpan<char>*/ chars, /*Span<byte>*/ bytes)
            {
                if (chars.IsEmpty)
                {
                    chars = $.$$.System.MemoryExtensions.AsSpan$4($.$$.System.String.Empty);
                }
                if (bytes.IsEmpty)
                {
                    bytes = $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2($.$$.System.Array.Empty($.$$.System.Byte));
                }
                {
                    /*fixed*/ 
                    {
                        /*char**/ let charsPtr = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Char, chars);
                        /*fixed*/ 
                        {
                            /*byte**/ let bytesPtr = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Byte, bytes);
                            return encoding.GetBytes$4(charsPtr, chars.Length, bytesPtr, bytes.Length);
                        }
                    }
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_utf8Encoding = new $.$$.System.Text.UTF8Encoding().$ctor$5(false, true);
                }
                {
                    this.s_bmpEncoding = new $.$sfa.System.Formats.Asn1.BMPEncoding().$ctor$5();
                }
                {
                    this.s_ia5Encoding = new $.$sfa.System.Formats.Asn1.IA5Encoding().$ctor$7();
                }
                {
                    this.s_visibleStringEncoding = new $.$sfa.System.Formats.Asn1.VisibleStringEncoding().$ctor$7();
                }
                {
                    this.s_numericStringEncoding = new $.$sfa.System.Formats.Asn1.NumericStringEncoding().$ctor$7();
                }
                {
                    this.s_printableStringEncoding = new $.$sfa.System.Formats.Asn1.PrintableStringEncoding().$ctor$7();
                }
                {
                    this.s_t61Encoding = new $.$sfa.System.Formats.Asn1.T61Encoding().$ctor$4();
                }
            }
            static $h = 192366;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":121700353,"p":[{"n":"encodingType","p":1634158}],"n":"GetEncoding","d":192366,"h":34359930734,"f":16777256},{"r":655361,"p":[{"n":"encoding","p":121700353},{"n":"str","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"GetByteCount","d":192366,"h":38654898030,"f":16777256},{"r":655361,"p":[{"n":"encoding","p":121700353},{"n":"chars","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"bytes","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"GetBytes","d":192366,"h":42949865326,"f":16777256}],"l":[{"t":124583937,"n":"s_utf8Encoding","d":192366,"h":4295159662,"f":4194338},{"t":1044334,"n":"s_bmpEncoding","d":192366,"h":8590126958,"f":4194338},{"t":1109870,"n":"s_ia5Encoding","d":192366,"h":12885094254,"f":4194338},{"t":1699694,"n":"s_visibleStringEncoding","d":192366,"h":17180061550,"f":4194338},{"t":1175406,"n":"s_numericStringEncoding","d":192366,"h":21475028846,"f":4194338},{"t":1240942,"n":"s_printableStringEncoding","d":192366,"h":25769996142,"f":4194338},{"t":1503086,"n":"s_t61Encoding","d":192366,"h":30064963438,"f":4194338}],"h":192366}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.AsnCharacterStringEncodings`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.AsnDecoder", ($self) => class AsnDecoder
        {
            static /*bool */ ReadBoolean(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Boolean, 1/*UniversalTagNumber.Boolean*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (contents.Length !== 1)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*byte*/ let val = contents.get_Item(0).$v;
                if (val === 0)
                {
                    bytesConsumed.$v = consumed;
                    return false;
                }
                if (val !== 255 && (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/))
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                bytesConsumed.$v = consumed;
                return true;
            }
            static /*TFlagsEnum */ ReadNamedBitListValue$1(TFlagsEnum, /*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*Type*/ let tFlagsEnum = TFlagsEnum.$type;
                /*int*/ let consumed;
                /*TFlagsEnum*/ let ret = $.$cast($.$$.System.Enum.ToObject$4(tFlagsEnum, $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNamedBitListValue(source, ruleSet, tFlagsEnum, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null)), TFlagsEnum);
                bytesConsumed.$v = consumed;
                return ret;
            }
            static /*Enum */ ReadNamedBitListValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Type*/ flagsEnumType, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                if ($.$$.System.Type.op_Equality$1(flagsEnumType, null))
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("flagsEnumType");
                }
                /*Type*/ let backingType = flagsEnumType.GetEnumUnderlyingType();
                if (!flagsEnumType.IsDefined($.$$.System.FlagsAttribute.$type, false))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_NamedBitListRequiresFlagsEnum, "flagsEnumType");
                }
                /*Span<byte>*/ let stackSpan = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, $.$$.System.UInt64.$z, null);
                /*int*/ let sizeLimit = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveIntegerSize(backingType);
                stackSpan = stackSpan.Slice(0, sizeLimit);
                /*int*/ let unusedBitCount;
                /*int*/ let consumed;
                /*int*/ let bytesWritten;
                /*bool*/ let read = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadBitString(source, stackSpan, ruleSet, $.$ref(() => unusedBitCount, ($v) => unusedBitCount = $v, $.$$.System.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                if (!read)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.Format$6($.$sfa.System.SR.ContentException_NamedBitListValueTooBig, flagsEnumType.Name));
                }
                /*Enum*/ let ret;
                if (bytesWritten === 0)
                {
                    ret = $.$cast($.$$.System.Enum.ToObject$2(flagsEnumType, 0), $.$$.System.Enum);
                    bytesConsumed.$v = consumed;
                    return ret;
                }
                /*ReadOnlySpan<byte>*/ let valueSpan = $.$$.System.Span$$($.$$.System.Byte).op_Implicit(stackSpan.Slice(0, bytesWritten));
                if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                {
                    /*byte*/ let lastByte = valueSpan.get_Item(((bytesWritten - 1) | 0)).$v;
                    /*byte*/ let testBit = $.$cast((1 << unusedBitCount), $.$$.System.Byte);
                    if ((lastByte & testBit) === 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                ret = $.$cast($.$$.System.Enum.ToObject$3(flagsEnumType, $.$sfa.System.Formats.Asn1.AsnDecoder.InterpretNamedBitListReversed(valueSpan)), $.$$.System.Enum);
                bytesConsumed.$v = consumed;
                return ret;
            }
            static /*BitArray */ ReadNamedBitList(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let contentLength;
                /*Asn1Tag*/ let actualTag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEncodedValue(source, ruleSet, $.$discardRef(), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$$.System.Int32), $.$discardRef());
                if (expectedTag !== null)
                {
                    $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(actualTag, $.$$.System.Nullable$$($.$sfa.System.Formats.Asn1.Asn1Tag).Value$get.call(expectedTag), 3/*UniversalTagNumber.BitString*/);
                }
                /*byte[]*/ let rented = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(contentLength);
                /*int*/ let unusedBitCount;
                /*int*/ let consumed;
                /*int*/ let written;
                if (!$.$sfa.System.Formats.Asn1.AsnDecoder.TryReadBitString(source, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rented), ruleSet, $.$ref(() => unusedBitCount, ($v) => unusedBitCount = $v, $.$$.System.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), $.$ref(() => written, ($v) => written = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null))
                {
                    $.$$.System.Diagnostics.Debug.Fail$1("TryReadBitString failed with an over-allocated buffer");
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                /*int*/ let validBitCount = $.$checked($.$checked(written * 8, 1) - unusedBitCount, 1);
                /*Span<byte>*/ let valueSpan = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, rented, 0, written);
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReverseBitsPerByte(valueSpan);
                /*BitArray*/ let ret = new $.$$.System.Collections.BitArray().$ctor$2(rented);
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, written);
                ret.Length = validBitCount;
                bytesConsumed.$v = consumed;
                return ret;
            }
            static /*long */ InterpretNamedBitListReversed(/*ReadOnlySpan<byte>*/ valueSpan)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(valueSpan.Length <= $.$$.System.Int64.$z, "valueSpan.Length <= sizeof(long)");
                /*long*/ let accum = 0n;
                /*long*/ let currentBitValue = 1n;
                for(/*int*/ let byteIdx = 0; byteIdx < valueSpan.Length; byteIdx++)
                {
                    /*byte*/ let byteVal = valueSpan.get_Item(byteIdx).$v;
                    for(/*int*/ let bitIndex = 7; bitIndex >= 0; bitIndex--)
                    {
                        /*int*/ let test = 1 << bitIndex;
                        if ((byteVal & test) !== 0)
                        {
                            accum |= currentBitValue;
                        }
                        currentBitValue <<= 1n;
                    }
                }
                return accum;
            }
            static /*void */ ReverseBitsPerByte(/*Span<byte>*/ value)
            {
                for(/*int*/ let byteIdx = 0; byteIdx < value.Length; byteIdx++)
                {
                    value.get_Item(byteIdx).$v = $.$cast(((BigInt(value.get_Item(byteIdx).$v) * 8623620610n & 1136090292240n) % 1023n), $.$$.System.Byte);
                }
            }
            static /*void */ ReadNull(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Null, 5/*UniversalTagNumber.Null*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (contents.Length !== 0)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                bytesConsumed.$v = consumed;
            }
            static /*ReadOnlySpan<byte> */ ReadEnumeratedBytes(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                return $.$sfa.System.Formats.Asn1.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Enumerated, 10/*UniversalTagNumber.Enumerated*/, bytesConsumed);
            }
            static /*TEnum */ ReadEnumeratedValue$1(TEnum, /*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*Type*/ let tEnum = TEnum.$type;
                return $.$cast($.$$.System.Enum.ToObject$4(tEnum, $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEnumeratedValue(source, ruleSet, tEnum, bytesConsumed, expectedTag?.Clone() ?? null)), TEnum);
            }
            static /*Enum */ ReadEnumeratedValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Type*/ enumType, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                if ($.$$.System.Type.op_Equality$1(enumType, null))
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("enumType");
                }
                /*UniversalTagNumber*/ let TagNumber = 10/*UniversalTagNumber.Enumerated*/;
                /*Asn1Tag*/ let localTag = expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Enumerated;
                /*Type*/ let backingType = enumType.GetEnumUnderlyingType();
                if (enumType.IsDefined($.$$.System.FlagsAttribute.$type, false))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_EnumeratedValueRequiresNonFlagsEnum, "enumType");
                }
                /*int*/ let sizeLimit = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveIntegerSize(backingType);
                if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.Int32.$type) || $.$$.System.Type.op_Equality$1(backingType, $.$$.System.Int64.$type) || $.$$.System.Type.op_Equality$1(backingType, $.$$.System.Int16.$type) || $.$$.System.Type.op_Equality$1(backingType, $.$$.System.SByte.$type))
                {
                    /*long*/ let value;
                    /*int*/ let consumed;
                    if (!$.$sfa.System.Formats.Asn1.AsnDecoder.TryReadSignedInteger(source, ruleSet, sizeLimit, localTag, TagNumber, $.$ref(() => value, ($v) => value = $v, $.$$.System.Int64), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32)))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_EnumeratedValueTooBig);
                    }
                    bytesConsumed.$v = consumed;
                    return $.$cast($.$$.System.Enum.ToObject$3(enumType, value), $.$$.System.Enum);
                }
                if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.UInt32.$type) || $.$$.System.Type.op_Equality$1(backingType, $.$$.System.UInt64.$type) || $.$$.System.Type.op_Equality$1(backingType, $.$$.System.UInt16.$type) || $.$$.System.Type.op_Equality$1(backingType, $.$$.System.Byte.$type))
                {
                    /*ulong*/ let value;
                    /*int*/ let consumed;
                    if (!$.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUnsignedInteger(source, ruleSet, sizeLimit, localTag, TagNumber, $.$ref(() => value, ($v) => value = $v, $.$$.System.UInt64), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32)))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_EnumeratedValueTooBig);
                    }
                    bytesConsumed.$v = consumed;
                    return $.$cast($.$$.System.Enum.ToObject$8(enumType, value), $.$$.System.Enum);
                }
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.Format$6($.$sfa.System.SR.Argument_EnumeratedValueBackingTypeNotSupported, backingType.FullName));
            }
            static /*void */ ReadSequence(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int?*/ let length;
                /*int*/ let headerLength;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(source, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32));
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(tag, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Sequence, 16/*UniversalTagNumber.Sequence*/);
                if (!tag.IsConstructed)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.Format$6($.$sfa.System.SR.ContentException_ConstructedEncodingRequired, $.$box(16/*UniversalTagNumber.Sequence*/, $.$sfa.System.Formats.Asn1.UniversalTagNumber)));
                }
                if ($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(length))
                {
                    if ($.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length) > ((source.Length - headerLength) | 0))
                    {
                        throw $.$sfa.System.Formats.Asn1.AsnDecoder.GetValidityException(2/*LengthValidity.LengthExceedsInput*/);
                    }
                    contentLength.$v = $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length);
                    contentOffset.$v = headerLength;
                    bytesConsumed.$v = ((contentLength.$v + headerLength) | 0);
                }
                else 
                {
                    /*int*/ let len = $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(source.Slice$1(headerLength), ruleSet);
                    contentLength.$v = len;
                    contentOffset.$v = headerLength;
                    bytesConsumed.$v = ((((len + headerLength) | 0) + 2/*EndOfContentsEncodedLength*/) | 0);
                }
            }
            static /*DateTimeOffset */ ReadGeneralizedTime(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*byte[]?*/ let rented = null;
                /*int*/ let StackBufSize = 64;
                /*Span<byte>*/ let tmpSpace = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, StackBufSize, null);
                /*int*/ let bytesRead;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.GeneralizedTime, 24/*UniversalTagNumber.GeneralizedTime*/, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.System.Byte)), tmpSpace);
                /*DateTimeOffset*/ let value = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseGeneralizedTime(ruleSet, contents);
                if (rented !== null)
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = bytesRead;
                return value;
            }
            static /*DateTimeOffset */ ParseGeneralizedTime(/*AsnEncodingRules*/ ruleSet, /*ReadOnlySpan<byte>*/ contentOctets)
            {
                /*bool*/ let strict = ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/;
                if (strict && contentOctets.Length < 15)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                else if (contentOctets.Length < 10)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*ReadOnlySpan<byte>*/ let contents = contentOctets;
                /*int*/ let year = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 4);
                /*int*/ let month = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let day = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let hour = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int?*/ let minute = null;
                /*int?*/ let second = null;
                /*ulong*/ let fraction = 0n;
                /*ulong*/ let fractionScale = 1n;
                /*byte*/ let lastFracDigit = 255;
                /*TimeSpan?*/ let timeOffset = null;
                /*bool*/ let isZulu = false;
                /*byte*/ let HmsState = 0;
                /*byte*/ let FracState = 1;
                /*byte*/ let SuffixState = 2;
                /*byte*/ let state = HmsState;
                /*static byte?*/  function GetNextState(/*byte*/ octet)
                {
                    if (octet === /*Z*/ 90 || octet === /*-*/ 45 || octet === /*+*/ 43)
                    {
                        return SuffixState;
                    }
                    if (octet === /*.*/ 46 || octet === /*,*/ 44)
                    {
                        return FracState;
                    }
                    return null;
                }
                while(state === HmsState && contents.Length !== 0)
                {
                    /*byte?*/ let nextState = GetNextState(contents.get_Item(0).$v);
                    if (nextState === null)
                    {
                        if (minute === null)
                        {
                            minute = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                        }
                        else if (second === null)
                        {
                            second = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                        }
                        else 
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                    }
                    else 
                    {
                        state = $.$$.System.Nullable$$($.$$.System.Byte).Value$get.call(nextState);
                    }
                }
                if (state === FracState)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!contents.IsEmpty, "!contents.IsEmpty");
                    /*byte*/ let octet = contents.get_Item(0).$v;
                    $.$$.System.Diagnostics.Debug.Assert$2(state === GetNextState(octet), "state == GetNextState(octet)");
                    if (octet === /*.*/ 46)
                    {
                    }
                    else if (octet === /*,*/ 44)
                    {
                        if (strict)
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                        }
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Fail$1((() =>
                        {
                            var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(2, 2);
                            $handler.AppendLiteral("Unhandled value '");
                            $handler.AppendFormatted($.$box(octet, $.$$.System.Byte), null, "X2");
                            $handler.AppendLiteral("' in ");
                            $handler.AppendFormatted($.$box("FracState", $.$$.System.String), null, null);
                            return $handler.ToStringAndClear                    ();
                        })());
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    contents = contents.Slice$1(1);
                    if (contents.IsEmpty)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    /*int*/ let fracLength;
                    if (!$.$$.System.Buffers.Text.Utf8Parser.TryParse$15($.$sfa.System.Formats.Asn1.AsnDecoder.SliceAtMost(contents, 12), $.$ref(() => fraction, ($v) => fraction = $v, $.$$.System.UInt64), $.$ref(() => fracLength, ($v) => fracLength = $v, $.$$.System.Int32), /*\u0000*/ 0) || fracLength === 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    lastFracDigit = $.$cast((fraction % 10n), $.$$.System.Byte);
                    for(/*int*/ let i = 0; i < fracLength; i++)
                    {
                        fractionScale *= 10n;
                    }
                    contents = contents.Slice$1(fracLength);
                    /*uint*/ let nonSemantic;
                    while($.$$.System.Buffers.Text.Utf8Parser.TryParse$14($.$sfa.System.Formats.Asn1.AsnDecoder.SliceAtMost(contents, 9), $.$ref(() => nonSemantic, ($v) => nonSemantic = $v, $.$$.System.UInt32), $.$ref(() => fracLength, ($v) => fracLength = $v, $.$$.System.Int32), /*\u0000*/ 0))
                    {
                        contents = contents.Slice$1(fracLength);
                        lastFracDigit = $.$cast((nonSemantic % 10), $.$$.System.Byte);
                    }
                    if (contents.Length !== 0)
                    {
                        /*byte?*/ let nextState = GetNextState(contents.get_Item(0).$v);
                        if (nextState === null)
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                        state = $.$$.System.Nullable$$($.$$.System.Byte).Value$get.call(nextState);
                    }
                }
                if (state === SuffixState)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!contents.IsEmpty, "!contents.IsEmpty");
                    /*byte*/ let octet = contents.get_Item(0).$v;
                    $.$$.System.Diagnostics.Debug.Assert$2(state === GetNextState(octet), "state == GetNextState(octet)");
                    contents = contents.Slice$1(1);
                    if (octet === /*Z*/ 90)
                    {
                        timeOffset = $.$$.System.TimeSpan.Zero;
                        isZulu = true;
                    }
                    else 
                    {
                        /*bool*/ let isMinus;
                        if (octet === /*+*/ 43)
                        {
                            isMinus = false;
                        }
                        else if (octet === /*-*/ 45)
                        {
                            isMinus = true;
                        }
                        else 
                        {
                            $.$$.System.Diagnostics.Debug.Fail$1((() =>
                            {
                                var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(2, 2);
                                $handler.AppendLiteral("Unhandled value '");
                                $handler.AppendFormatted($.$box(octet, $.$$.System.Byte), null, "X2");
                                $handler.AppendLiteral("' in ");
                                $handler.AppendFormatted($.$box("SuffixState", $.$$.System.String), null, null);
                                return $handler.ToStringAndClear                        ();
                            })());
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                        if (contents.IsEmpty)
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                        /*int*/ let offsetHour = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                        /*int*/ let offsetMinute = 0;
                        if (contents.Length !== 0)
                        {
                            offsetMinute = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                        }
                        if (offsetMinute > 59)
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                        /*TimeSpan*/ let tmp = new $.$$.System.TimeSpan().$ctor$6(offsetHour, offsetMinute, 0);
                        if (isMinus)
                        {
                            tmp = $.$$.System.TimeSpan.op_UnaryNegation(tmp);
                        }
                        timeOffset = tmp;
                    }
                }
                if (!contents.IsEmpty)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                if (strict)
                {
                    if (!isZulu || !$.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(second))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                    if (lastFracDigit === 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                /*double*/ let frac = $.$cast(fraction, $.$$.System.Double) / Number(fractionScale);
                /*TimeSpan*/ let fractionSpan = $.$$.System.TimeSpan.Zero;
                if (!$.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(minute))
                {
                    minute = 0;
                    second = 0;
                    if (fraction !== 0n)
                    {
                        fractionSpan = new $.$$.System.TimeSpan().$ctor$7($.$cast((frac * Number(36000000000n)), $.$$.System.Int64));
                    }
                }
                else if (!$.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(second))
                {
                    second = 0;
                    if (fraction !== 0n)
                    {
                        fractionSpan = new $.$$.System.TimeSpan().$ctor$7($.$cast((frac * Number(600000000n)), $.$$.System.Int64));
                    }
                }
                else if (fraction !== 0n)
                {
                    fractionSpan = new $.$$.System.TimeSpan().$ctor$7($.$cast((frac * Number(10000000n)), $.$$.System.Int64));
                }
                /*DateTimeOffset*/ let value;
                try
                {
                    if (timeOffset === null)
                    {
                        value = new $.$$.System.DateTimeOffset().$ctor$5(new $.$$.System.DateTime().$ctor$16(year, month, day, hour, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(minute), $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(second)));
                    }
                    else 
                    {
                        value = new $.$$.System.DateTimeOffset().$ctor$11(year, month, day, hour, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(minute), $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(second), $.$$.System.Nullable$$($.$$.System.TimeSpan).Value$get.call(timeOffset));
                    }
                    value = $.$$.System.DateTimeOffset.op_Addition(value, fractionSpan);
                    return value;
                }
                catch(e)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$7($.$sfa.System.SR.ContentException_DefaultMessage, e);
                }
            }
            static /*void */ ReadSetOf(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed, /*bool*/ skipSortOrderValidation, /*Asn1Tag?*/ expectedTag)
            {
                /*int?*/ let length;
                /*int*/ let headerLength;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(source, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32));
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(tag, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.SetOf, 17/*UniversalTagNumber.SetOf*/);
                if (!tag.IsConstructed)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.Format$6($.$sfa.System.SR.ContentException_ConstructedEncodingRequired, $.$box(17/*UniversalTagNumber.SetOf*/, $.$sfa.System.Formats.Asn1.UniversalTagNumber)));
                }
                /*int*/ let suffix;
                /*ReadOnlySpan<byte>*/ let contents;
                if ($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(length))
                {
                    suffix = 0;
                    contents = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(source, headerLength, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length));
                }
                else 
                {
                    /*int*/ let actualLength = $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(source.Slice$1(headerLength), ruleSet);
                    contents = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(source, headerLength, actualLength);
                    suffix = 2/*EndOfContentsEncodedLength*/;
                }
                if (!skipSortOrderValidation)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                    {
                        /*ReadOnlySpan<byte>*/ let remaining = contents;
                        /*ReadOnlySpan<byte>*/ let previous = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))();
                        while(!remaining.IsEmpty)
                        {
                            /*int*/ let consumed;
                            $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEncodedValue(remaining, ruleSet, $.$discardRef(), $.$discardRef(), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                            /*ReadOnlySpan<byte>*/ let current = remaining.Slice(0, consumed);
                            remaining = remaining.Slice$1(consumed);
                            if ($.$sfa.System.Formats.Asn1.SetOfValueComparer.Compare$1(current, previous) < 0)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_SetOfNotSorted);
                            }
                            previous = current;
                        }
                    }
                }
                contentOffset.$v = headerLength;
                contentLength.$v = contents.Length;
                bytesConsumed.$v = ((((headerLength + contents.Length) | 0) + suffix) | 0);
            }
            static /*string */ ReadObjectIdentifier(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ObjectIdentifier, 6/*UniversalTagNumber.ObjectIdentifier*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                /*string?*/ let wellKnown = $.$sfa.System.Formats.Asn1.WellKnownOids.GetValue(contents);
                if (!(wellKnown === null))
                {
                    bytesConsumed.$v = consumed;
                    return wellKnown;
                }
                /*string*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadObjectIdentifier$1(contents);
                bytesConsumed.$v = consumed;
                return ret;
            }
            static /*void */ ReadSubIdentifier(/*ReadOnlySpan<byte>*/ source, /*out int*/ bytesRead, /*out long?*/ smallValue, /*out BigInteger?*/ largeValue)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(source.Length > 0, "source.Length > 0");
                if (source.get_Item(0).$v === 128)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*int*/ let semanticBits = (() =>
                {
                    let $switch1 = source.get_Item(0).$v;
                    if ($switch1 >= 192)
                    {
                        return 0;
                    }
                    if ($switch1 >= 160)
                    {
                        return -1;
                    }
                    if ($switch1 >= 144)
                    {
                        return -2;
                    }
                    if ($switch1 >= 136)
                    {
                        return -3;
                    }
                    if ($switch1 >= 132)
                    {
                        return -4;
                    }
                    if ($switch1 >= 130)
                    {
                        return -5;
                    }
                    if ($switch1 >= 129)
                    {
                        return -6;
                    }
                    return 0;
                })();
                /*int*/ let end = -1;
                /*int*/ let idx;
                /*int*/ let MaxAllowedBits = 128;
                for(idx = 0; idx < source.Length; idx++)
                {
                    semanticBits += 7;
                    if (semanticBits > MaxAllowedBits)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_OidTooBig);
                    }
                    /*bool*/ let endOfIdentifier = (source.get_Item(idx).$v & 128) === 0;
                    if (endOfIdentifier)
                    {
                        end = idx;
                        break;
                    }
                }
                if (end < 0)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                bytesRead.$v = ((end + 1) | 0);
                /*long*/ let accum = 0n;
                if (bytesRead.$v <= 9)
                {
                    for(idx = 0; idx < bytesRead.$v; idx++)
                    {
                        /*byte*/ let cur = source.get_Item(idx).$v;
                        accum <<= 7n;
                        accum |= BigInt($.$cast((cur & 127), $.$$.System.Byte));
                    }
                    largeValue.$v = null;
                    smallValue.$v = accum;
                    return;
                }
                /*int*/ let SemanticByteCount = 7;
                /*int*/ let ContentByteCount = 8;
                /*int*/ let bytesRequired = (((((($.trunc(bytesRead.$v / ContentByteCount)) + 1) | 0)) * SemanticByteCount) | 0);
                /*byte[]*/ let tmpBytes = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(bytesRequired);
                $.$$.System.Array.Clear(tmpBytes, 0, tmpBytes.length);
                /*Span<byte>*/ let writeSpan = $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(tmpBytes);
                /*Span<byte>*/ let accumValueBytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, $.$$.System.Int64.$z, null);
                /*int*/ let nextStop = bytesRead.$v;
                idx = ((bytesRead.$v - ContentByteCount) | 0);
                while(nextStop > 0)
                {
                    /*byte*/ let cur = source.get_Item(idx).$v;
                    accum <<= 7n;
                    accum |= BigInt($.$cast((cur & 127), $.$$.System.Byte));
                    idx++;
                    if (idx >= nextStop)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(idx === nextStop, "idx == nextStop");
                        $.$$.System.Diagnostics.Debug.Assert$2(writeSpan.Length >= SemanticByteCount, "writeSpan.Length >= SemanticByteCount");
                        $.$$.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian(accumValueBytes, accum);
                        $.$$.System.Diagnostics.Debug.Assert$2(accumValueBytes.get_Item(7).$v === 0, "accumValueBytes[7] == 0");
                        accumValueBytes.Slice(0, SemanticByteCount).CopyTo(writeSpan);
                        writeSpan = writeSpan.Slice$1(SemanticByteCount);
                        accum = 0n;
                        nextStop -= ContentByteCount;
                        idx = $.$$.System.Math.Max$4(0, ((nextStop - ContentByteCount) | 0));
                    }
                }
                /*int*/ let bytesWritten = ((tmpBytes.length - writeSpan.Length) | 0);
                /*int*/ let paddingByteCount = ((bytesRequired - bytesWritten) | 0);
                $.$$.System.Diagnostics.Debug.Assert$2(paddingByteCount >= 0 && paddingByteCount < $.$$.System.Int64.$z, "paddingByteCount >= 0 && paddingByteCount < sizeof(long)");
                largeValue.$v = new $.$srn.System.Numerics.BigInteger().$ctor$3(tmpBytes);
                smallValue.$v = null;
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(tmpBytes, bytesWritten);
            }
            static /*string */ ReadObjectIdentifier$1(/*ReadOnlySpan<byte>*/ contents)
            {
                if (contents.Length < 1)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*StringBuilder*/ let builder = new $.$$.System.Text.StringBuilder().$ctor$4(((($.$cast(contents.Length, $.$$.System.Byte)) * 4) | 0));
                /*int*/ let bytesRead;
                /*long?*/ let smallValue;
                /*BigInteger?*/ let largeValue;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadSubIdentifier(contents, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => smallValue, ($v) => smallValue = $v, $.$typeNullable($.$$.System.Int64)), $.$ref(() => largeValue, ($v) => largeValue = $v, $.$typeNullable($.$srn.System.Numerics.BigInteger)));
                /*byte*/ let firstArc;
                if (smallValue !== null)
                {
                    /*long*/ let firstIdentifier = $.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(smallValue);
                    if (firstIdentifier < 40n)
                    {
                        firstArc = 0;
                    }
                    else if (firstIdentifier < 80n)
                    {
                        firstArc = 1;
                        firstIdentifier -= 40n;
                    }
                    else 
                    {
                        firstArc = 2;
                        firstIdentifier -= 80n;
                    }
                    builder.Append$1(firstArc);
                    builder.Append$3(/*.*/ 46);
                    builder.Append$12(firstIdentifier);
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(largeValue !== null, "largeValue != null");
                    /*BigInteger*/ let firstIdentifier = $.$$.System.Nullable$$($.$srn.System.Numerics.BigInteger).Value$get.call(largeValue);
                    $.$$.System.Diagnostics.Debug.Assert$2($.$srn.System.Numerics.BigInteger.op_GreaterThan$2(firstIdentifier, 9223372036854775807n), "firstIdentifier > long.MaxValue");
                    firstArc = 2;
                    firstIdentifier = $.$srn.System.Numerics.BigInteger.op_Subtraction(firstIdentifier, $.$srn.System.Numerics.BigInteger.op_Implicit$4(80));
                    builder.Append$1(firstArc);
                    builder.Append$3(/*.*/ 46);
                    builder.Append$19($.$srn.System.Numerics.BigInteger.ToString.call(firstIdentifier));
                }
                contents = contents.Slice$1(bytesRead);
                /*int*/ let MaxArcs = 64;
                /*int*/ let remainingArcs = ((MaxArcs - 2) | 0);
                while(!contents.IsEmpty)
                {
                    if (remainingArcs <= 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_OidTooBig);
                    }
                    remainingArcs--;
                    $.$sfa.System.Formats.Asn1.AsnDecoder.ReadSubIdentifier(contents, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => smallValue, ($v) => smallValue = $v, $.$typeNullable($.$$.System.Int64)), $.$ref(() => largeValue, ($v) => largeValue = $v, $.$typeNullable($.$srn.System.Numerics.BigInteger)));
                    $.$$.System.Diagnostics.Debug.Assert$2((smallValue === null) !== (largeValue === null), "(smallValue == null) != (largeValue == null)");
                    builder.Append$3(/*.*/ 46);
                    if (smallValue !== null)
                    {
                        builder.Append$12($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(smallValue));
                    }
                    else 
                    {
                        builder.Append$19($.$srn.System.Numerics.BigInteger.ToString.call($.$$.System.Nullable$$($.$srn.System.Numerics.BigInteger).Value$get.call(largeValue)));
                    }
                    contents = contents.Slice$1(bytesRead);
                }
                return $.$$.System.Text.StringBuilder.ToString.call(builder);
            }
            static /*bool */ TryReadOctetString(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                if ($.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Byte, source, $.$$.System.Span$$($.$$.System.Byte).op_Implicit(destination)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_SourceOverlapsDestination, "destination");
                }
                /*int?*/ let contentLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let contents;
                /*int*/ let consumed;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString, 4/*UniversalTagNumber.OctetString*/, $.$ref(() => contentLength, ($v) => contentLength = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32), $.$ref(() => contents, ($v) => contents = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32)))
                {
                    if (contents.Length > destination.Length)
                    {
                        bytesWritten.$v = 0;
                        bytesConsumed.$v = 0;
                        return false;
                    }
                    contents.CopyTo(destination);
                    bytesWritten.$v = contents.Length;
                    bytesConsumed.$v = consumed;
                    return true;
                }
                /*int*/ let bytesRead;
                /*bool*/ let copied = $.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedOctetStringContents($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength, contentLength), ruleSet, destination, contentLength === null, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), bytesWritten);
                if (copied)
                {
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                }
                else 
                {
                    bytesConsumed.$v = 0;
                }
                return copied;
            }
            static /*byte[] */ ReadOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*byte[]?*/ let rented = null;
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString, 4/*UniversalTagNumber.OctetString*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.System.Byte)), new ($.$$.System.Span$$($.$$.System.Byte))());
                /*byte[]*/ let ret = contents.ToArray();
                if (rented !== null)
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = consumed;
                return ret;
            }
            static /*bool */ TryReadPrimitiveOctetStringCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*out int?*/ contentLength, /*out int*/ headerLength, /*out ReadOnlySpan<byte>*/ contents, /*out int*/ bytesConsumed)
            {
                /*Asn1Tag*/ let actualTag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(source, ruleSet, contentLength, headerLength);
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(actualTag, expectedTag, universalTagNumber);
                /*ReadOnlySpan<byte>*/ let encodedValue = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength.$v, contentLength.$v);
                if (actualTag.IsConstructed)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderDer_TryBerOrCer);
                    }
                    contents.$v = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))();
                    bytesConsumed.$v = 0;
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(contentLength.$v), "contentLength.HasValue");
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && encodedValue.Length > 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCer_TryBerOrDer);
                }
                contents.$v = encodedValue;
                bytesConsumed.$v = ((headerLength.$v + encodedValue.Length) | 0);
                return true;
            }
            static /*bool */ TryReadPrimitiveOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString, 4/*UniversalTagNumber.OctetString*/, $.$discardRef(), $.$discardRef(), value, bytesConsumed);
            }
            static /*int */ CountConstructedOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*bool*/ isIndefinite)
            {
                /*int*/ let contentLength = $.$sfa.System.Formats.Asn1.AsnDecoder.CopyConstructedOctetString(source, ruleSet, $.$$.System.Span$$($.$$.System.Byte).Empty, false, isIndefinite, $.$discardRef());
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && contentLength <= 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                return contentLength;
            }
            static /*void */ CopyConstructedOctetString$1(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*bool*/ isIndefinite, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                bytesWritten.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.CopyConstructedOctetString(source, ruleSet, destination, true, isIndefinite, bytesRead);
            }
            static /*int */ CopyConstructedOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*bool*/ write, /*bool*/ isIndefinite, /*out int*/ bytesRead)
            {
                bytesRead.$v = 0;
                /*int*/ let lastSegmentLength = 1000/*MaxCERSegmentSize*/;
                /*ReadOnlySpan<byte>*/ let cur = source;
                /*Stack<(int Offset, int Length, bool IsIndefinite, int BytesRead)>?*/ let readerStack = null;
                /*int*/ let totalLength = 0;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedBitString;
                /*Span<byte>*/ let curDest = destination;
                while(true)
                {
                    while(!cur.IsEmpty)
                    {
                        /*int?*/ let length;
                        /*int*/ let headerLength;
                        tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(cur, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32));
                        if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString))
                        {
                            if (ruleSet === 1/*AsnEncodingRules.CER*/ && lastSegmentLength !== 1000/*MaxCERSegmentSize*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(length !== null, "length != null");
                            /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(cur, headerLength, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length));
                            /*int*/ let localLen = ((headerLength + contents.Length) | 0);
                            cur = cur.Slice$1(localLen);
                            bytesRead.$v += localLen;
                            totalLength += contents.Length;
                            lastSegmentLength = contents.Length;
                            if (ruleSet === 1/*AsnEncodingRules.CER*/ && lastSegmentLength > 1000/*MaxCERSegmentSize*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            if (write)
                            {
                                contents.CopyTo(curDest);
                                curDest = curDest.Slice$1(contents.Length);
                            }
                        }
                        else if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents) && isIndefinite)
                        {
                            $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateEndOfContents(tag, length, headerLength);
                            bytesRead.$v += headerLength;
                            if ($.$$.System.Int32.op_GreaterThan$1((readerStack?.Count ?? null), 0))
                            {
                                const { Item1: topOffset, Item2: topLength, Item3: wasIndefinite, Item4: pushedBytesRead } = readerStack.Pop();
                                /*ReadOnlySpan<byte>*/ let topSpan = source.Slice(topOffset, topLength);
                                cur = topSpan.Slice$1(bytesRead.$v);
                                bytesRead.$v += pushedBytesRead;
                                isIndefinite = wasIndefinite;
                            }
                            else 
                            {
                                break;
                            }
                        }
                        else if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedOctetString))
                        {
                            if (ruleSet === 1/*AsnEncodingRules.CER*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            readerStack ??= new ($.$sc.System.Collections.Generic.Stack$$($.$$.System.ValueTuple$$$$$($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Boolean, $.$$.System.Int32)))().$ctor$1();
                            /*int*/ let curOffset;
                            if (!$.$$.System.MemoryExtensions.Overlaps($.$$.System.Byte, source, cur, $.$ref(() => curOffset, ($v) => curOffset = $v, $.$$.System.Int32)))
                            {
                                $.$$.System.Diagnostics.Debug.Fail$1("Non-overlapping data encountered...");
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                            }
                            readerStack.Push(new ($.$$.System.ValueTuple$$$$$($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Boolean, $.$$.System.Int32))().$ctor$3(curOffset, cur.Length, isIndefinite, bytesRead.$v));
                            cur = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(cur, headerLength, length);
                            bytesRead.$v = headerLength;
                            isIndefinite = (length === null);
                        }
                        else 
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                    }
                    if (isIndefinite && $.$sfa.System.Formats.Asn1.Asn1Tag.op_Inequality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    if ($.$$.System.Int32.op_GreaterThan$1((readerStack?.Count ?? null), 0))
                    {
                        const { Item1: topOffset, Item2: topLength, Item3: wasIndefinite, Item4: pushedBytesRead } = readerStack.Pop();
                        /*ReadOnlySpan<byte>*/ let topSpan = source.Slice(topOffset, topLength);
                        cur = topSpan.Slice$1(bytesRead.$v);
                        isIndefinite = wasIndefinite;
                        bytesRead.$v += pushedBytesRead;
                    }
                    else 
                    {
                        return totalLength;
                    }
                }
            }
            static /*bool */ TryCopyConstructedOctetStringContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ dest, /*bool*/ isIndefinite, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                bytesRead.$v = 0;
                /*int*/ let contentLength = $.$sfa.System.Formats.Asn1.AsnDecoder.CountConstructedOctetString(source, ruleSet, isIndefinite);
                if (dest.Length < contentLength)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                $.$sfa.System.Formats.Asn1.AsnDecoder.CopyConstructedOctetString$1(source, ruleSet, dest, isIndefinite, bytesRead, bytesWritten);
                $.$$.System.Diagnostics.Debug.Assert$2(bytesWritten.$v === contentLength, "bytesWritten == contentLength");
                return true;
            }
            static /*ReadOnlySpan<byte> */ GetOctetStringContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*out int*/ bytesConsumed, /*ref byte[]?*/ rented, /*Span<byte>*/ tmpSpace)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(rented.$v === null, "rented == null");
                /*int?*/ let contentLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let contents;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => contentLength, ($v) => contentLength = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32), $.$ref(() => contents, ($v) => contents = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), bytesConsumed))
                {
                    return contents;
                }
                contents = source.Slice$1(headerLength);
                /*int*/ let tooBig = contentLength ?? $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(contents, ruleSet);
                if (tmpSpace.Length > 0 && tooBig > tmpSpace.Length)
                {
                    /*bool*/ let isIndefinite = contentLength === null;
                    tooBig = $.$sfa.System.Formats.Asn1.AsnDecoder.CountConstructedOctetString(contents, ruleSet, isIndefinite);
                }
                if (tooBig > tmpSpace.Length)
                {
                    rented.$v = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(tooBig);
                    tmpSpace = $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rented.$v);
                }
                /*int*/ let bytesRead;
                /*int*/ let bytesWritten;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedOctetStringContents($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength, contentLength), ruleSet, tmpSpace, contentLength === null, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32)))
                {
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                    return $.$$.System.Span$$($.$$.System.Byte).op_Implicit(tmpSpace.Slice(0, bytesWritten));
                }
                $.$$.System.Diagnostics.Debug.Fail$1("TryCopyConstructedOctetStringContents failed with a pre-allocated buffer");
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            static /*bool */ TryReadPrimitiveCharacterStringBytes(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed)
            {
                /*UniversalTagNumber*/ let universalTagNumber = 22/*UniversalTagNumber.IA5String*/;
                if (expectedTag.TagClass === 0/*TagClass.Universal*/)
                {
                    universalTagNumber = $.$cast(expectedTag.TagValue, $.$sfa.System.Formats.Asn1.UniversalTagNumber);
                    if (!$.$sfa.System.Formats.Asn1.AsnDecoder.IsCharacterStringEncodingType(universalTagNumber))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_Tag_NotCharacterString, "expectedTag");
                    }
                }
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag, universalTagNumber, $.$discardRef(), $.$discardRef(), value, bytesConsumed);
            }
            static /*bool */ TryReadCharacterStringBytes(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*out int*/ bytesConsumed, /*out int*/ bytesWritten)
            {
                if ($.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Byte, source, $.$$.System.Span$$($.$$.System.Byte).op_Implicit(destination)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_SourceOverlapsDestination, "destination");
                }
                /*UniversalTagNumber*/ let universalTagNumber = 22/*UniversalTagNumber.IA5String*/;
                if (expectedTag.TagClass === 0/*TagClass.Universal*/)
                {
                    universalTagNumber = $.$cast(expectedTag.TagValue, $.$sfa.System.Formats.Asn1.UniversalTagNumber);
                    if (!$.$sfa.System.Formats.Asn1.AsnDecoder.IsCharacterStringEncodingType(universalTagNumber))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_Tag_NotCharacterString, "expectedTag");
                    }
                }
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterStringBytesCore(source, ruleSet, expectedTag, universalTagNumber, destination, bytesConsumed, bytesWritten);
            }
            static /*bool */ TryReadCharacterString(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*AsnEncodingRules*/ ruleSet, /*UniversalTagNumber*/ encodingType, /*out int*/ bytesConsumed, /*out int*/ charsWritten, /*Asn1Tag?*/ expectedTag)
            {
                /*Text.Encoding*/ let encoding = $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.GetEncoding(encodingType);
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterStringCore$1(source, ruleSet, expectedTag ?? new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$5(encodingType, false), encodingType, encoding, destination, bytesConsumed, charsWritten);
            }
            static /*string */ ReadCharacterString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*UniversalTagNumber*/ encodingType, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*Text.Encoding*/ let encoding = $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.GetEncoding(encodingType);
                return $.$sfa.System.Formats.Asn1.AsnDecoder.ReadCharacterStringCore(source, ruleSet, expectedTag ?? new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$5(encodingType, false), encodingType, encoding, bytesConsumed);
            }
            static /*bool */ TryReadCharacterStringBytesCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten)
            {
                /*int?*/ let contentLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let contents;
                /*int*/ let consumed;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => contentLength, ($v) => contentLength = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32), $.$ref(() => contents, ($v) => contents = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32)))
                {
                    if (contents.Length > destination.Length)
                    {
                        bytesWritten.$v = 0;
                        bytesConsumed.$v = 0;
                        return false;
                    }
                    contents.CopyTo(destination);
                    bytesWritten.$v = contents.Length;
                    bytesConsumed.$v = consumed;
                    return true;
                }
                /*int*/ let bytesRead;
                /*bool*/ let copied = $.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedOctetStringContents($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength, contentLength), ruleSet, destination, contentLength === null, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), bytesWritten);
                if (copied)
                {
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                }
                else 
                {
                    bytesConsumed.$v = 0;
                }
                return copied;
            }
            static /*bool */ TryReadCharacterStringCore(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Text.Encoding*/ encoding, /*out int*/ charsWritten)
            {
                try
                {
                    return encoding.TryGetChars(source, destination, charsWritten);
                }
                catch(e)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$7($.$sfa.System.SR.ContentException_DefaultMessage, e);
                }
            }
            static /*string */ ReadCharacterStringCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*Text.Encoding*/ encoding, /*out int*/ bytesConsumed)
            {
                /*byte[]?*/ let rented = null;
                /*int*/ let bytesRead;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.System.Byte)), new ($.$$.System.Span$$($.$$.System.Byte))());
                /*string*/ let str;
                if (contents.Length === 0)
                {
                    str = $.$$.System.String.Empty;
                }
                else 
                {
                    {
                        /*fixed*/ 
                        {
                            /*byte**/ let bytePtr = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Byte, contents);
                            try
                            {
                                str = encoding.GetString$2(bytePtr, contents.Length);
                            }
                            catch(e)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$7($.$sfa.System.SR.ContentException_DefaultMessage, e);
                            }
                        }
                    }
                }
                if (rented !== null)
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = bytesRead;
                return str;
            }
            static /*bool */ TryReadCharacterStringCore$1(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*Text.Encoding*/ encoding, /*Span<char>*/ destination, /*out int*/ bytesConsumed, /*out int*/ charsWritten)
            {
                /*byte[]?*/ let rented = null;
                /*int*/ let bytesRead;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.System.Byte)), new ($.$$.System.Span$$($.$$.System.Byte))());
                /*bool*/ let copied = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterStringCore(contents, destination, encoding, charsWritten);
                if (rented !== null)
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                if (copied)
                {
                    bytesConsumed.$v = bytesRead;
                }
                else 
                {
                    bytesConsumed.$v = 0;
                }
                return copied;
            }
            static /*bool */ IsCharacterStringEncodingType(/*UniversalTagNumber*/ encodingType)
            {
                switch(encodingType)
                {
                    case 30/*UniversalTagNumber.BMPString*/:
                    case 27/*UniversalTagNumber.GeneralString*/:
                    case 25/*UniversalTagNumber.GraphicString*/:
                    case 22/*UniversalTagNumber.IA5String*/:
                    case 26/*UniversalTagNumber.ISO646String*/:
                    case 18/*UniversalTagNumber.NumericString*/:
                    case 19/*UniversalTagNumber.PrintableString*/:
                    case 20/*UniversalTagNumber.TeletexString*/:
                    case 28/*UniversalTagNumber.UniversalString*/:
                    case 12/*UniversalTagNumber.UTF8String*/:
                    case 21/*UniversalTagNumber.VideotexString*/:
                    return true;
                }
                return false;
            }
            static /*ReadOnlySpan<byte> */ ReadIntegerBytes(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                return $.$sfa.System.Formats.Asn1.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, bytesConsumed);
            }
            static /*BigInteger */ ReadInteger(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadIntegerBytes(source, ruleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                /*BigInteger*/ let value = new $.$srn.System.Numerics.BigInteger().$ctor$9(contents, false, true);
                bytesConsumed.$v = consumed;
                return value;
            }
            static /*bool */ TryReadInt32(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*long*/ let longValue;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadSignedInteger(source, ruleSet, $.$$.System.Int32.$z, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, $.$ref(() => longValue, ($v) => longValue = $v, $.$$.System.Int64), bytesConsumed))
                {
                    value.$v = $.$cast(longValue, $.$$.System.Int32);
                    return true;
                }
                value.$v = 0;
                return false;
            }
            static /*bool */ TryReadUInt32(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out uint*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*ulong*/ let ulongValue;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUnsignedInteger(source, ruleSet, $.$$.System.UInt32.$z, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, $.$ref(() => ulongValue, ($v) => ulongValue = $v, $.$$.System.UInt64), bytesConsumed))
                {
                    value.$v = $.$cast(ulongValue, $.$$.System.UInt32);
                    return true;
                }
                value.$v = 0;
                return false;
            }
            static /*bool */ TryReadInt64(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out long*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadSignedInteger(source, ruleSet, $.$$.System.Int64.$z, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, value, bytesConsumed);
            }
            static /*bool */ TryReadUInt64(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out ulong*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUnsignedInteger(source, ruleSet, $.$$.System.UInt64.$z, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, value, bytesConsumed);
            }
            static /*ReadOnlySpan<byte> */ GetIntegerContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out int*/ bytesConsumed)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag, tagNumber, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (contents.IsEmpty)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*ushort*/ let bigEndianValue;
                if ($.$$.System.Buffers.Binary.BinaryPrimitives.TryReadUInt16BigEndian(contents, $.$ref(() => bigEndianValue, ($v) => bigEndianValue = $v, $.$$.System.UInt16)))
                {
                    /*ushort*/ let RedundancyMask = 65408;
                    /*ushort*/ let masked = $.$cast((bigEndianValue & RedundancyMask), $.$$.System.UInt16);
                    if (masked === 0 || masked === RedundancyMask)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                }
                bytesConsumed.$v = consumed;
                return contents;
            }
            static /*bool */ TryReadSignedInteger(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*int*/ sizeLimit, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out long*/ value, /*out int*/ bytesConsumed)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(sizeLimit <= $.$$.System.Int64.$z, "sizeLimit <= sizeof(long)");
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag, tagNumber, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (contents.Length > sizeLimit)
                {
                    value.$v = 0n;
                    bytesConsumed.$v = 0;
                    return false;
                }
                /*bool*/ let isNegative = (contents.get_Item(0).$v & 128) !== 0;
                /*long*/ let accum = BigInt(isNegative ? -1 : 0);
                for(/*int*/ let i = 0; i < contents.Length; i++)
                {
                    accum <<= 8n;
                    accum |= BigInt(contents.get_Item(i).$v);
                }
                bytesConsumed.$v = consumed;
                value.$v = accum;
                return true;
            }
            static /*bool */ TryReadUnsignedInteger(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*int*/ sizeLimit, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out ulong*/ value, /*out int*/ bytesConsumed)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(sizeLimit <= $.$$.System.UInt64.$z, "sizeLimit <= sizeof(ulong)");
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag, tagNumber, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                /*bool*/ let isNegative = (contents.get_Item(0).$v & 128) !== 0;
                if (isNegative)
                {
                    bytesConsumed.$v = 0;
                    value.$v = 0n;
                    return false;
                }
                if (contents.Length > 1 && contents.get_Item(0).$v === 0)
                {
                    contents = contents.Slice$1(1);
                }
                if (contents.Length > sizeLimit)
                {
                    bytesConsumed.$v = 0;
                    value.$v = 0n;
                    return false;
                }
                /*ulong*/ let accum = 0n;
                for(/*int*/ let i = 0; i < contents.Length; i++)
                {
                    accum <<= 8n;
                    accum |= BigInt(contents.get_Item(i).$v);
                }
                bytesConsumed.$v = consumed;
                value.$v = accum;
                return true;
            }
            static /*DateTimeOffset */ ReadUtcTime(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*int*/ twoDigitYearMax, /*Asn1Tag?*/ expectedTag)
            {
                if (twoDigitYearMax < 1 || twoDigitYearMax > 9999)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("twoDigitYearMax");
                }
                /*Span<byte>*/ let tmpSpace = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 17, null);
                /*byte[]?*/ let rented = null;
                /*int*/ let bytesRead;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.UtcTime, 23/*UniversalTagNumber.UtcTime*/, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$$.System.Byte)), tmpSpace);
                /*DateTimeOffset*/ let value = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseUtcTime(contents, ruleSet, twoDigitYearMax);
                if (rented !== null)
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`UtcTime did not fit in tmpSpace (${contents.Length} total)`);
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = bytesRead;
                return value;
            }
            static /*DateTimeOffset */ ParseUtcTime(/*ReadOnlySpan<byte>*/ contentOctets, /*AsnEncodingRules*/ ruleSet, /*int*/ twoDigitYearMax)
            {
                /*int*/ let NoSecondsZulu = 11;
                /*int*/ let NoSecondsOffset = 15;
                /*int*/ let HasSecondsZulu = 13;
                /*int*/ let HasSecondsOffset = 17;
                if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (contentOctets.Length !== HasSecondsZulu)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                if (contentOctets.Length < NoSecondsZulu || contentOctets.Length > HasSecondsOffset || (contentOctets.Length & 1) !== 1)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*ReadOnlySpan<byte>*/ let contents = contentOctets;
                /*int*/ let year = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let month = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let day = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let hour = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let minute = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let second = 0;
                /*int*/ let offsetHour = 0;
                /*int*/ let offsetMinute = 0;
                /*bool*/ let minus = false;
                if (contentOctets.Length === HasSecondsOffset || contentOctets.Length === HasSecondsZulu)
                {
                    second = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                }
                if (contentOctets.Length === NoSecondsZulu || contentOctets.Length === HasSecondsZulu)
                {
                    if (contents.get_Item(0).$v !== /*Z*/ 90)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(contentOctets.Length === NoSecondsOffset || contentOctets.Length === HasSecondsOffset, "contentOctets.Length == NoSecondsOffset ||\r\n                    contentOctets.Length == HasSecondsOffset");
                    if (contents.get_Item(0).$v === /*-*/ 45)
                    {
                        minus = true;
                    }
                    else if (contents.get_Item(0).$v !== /*+*/ 43)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    contents = contents.Slice$1(1);
                    offsetHour = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                    offsetMinute = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                    $.$$.System.Diagnostics.Debug.Assert$2(contents.IsEmpty, "contents.IsEmpty");
                }
                if (offsetMinute > 59)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*TimeSpan*/ let offset = new $.$$.System.TimeSpan().$ctor$6(offsetHour, offsetMinute, 0);
                if (minus)
                {
                    offset = $.$$.System.TimeSpan.op_UnaryNegation(offset);
                }
                /*int*/ let century = $.trunc(twoDigitYearMax / 100);
                if (year > twoDigitYearMax % 100)
                {
                    century--;
                }
                /*int*/ let scaledYear = ((((century * 100) | 0) + year) | 0);
                try
                {
                    return new $.$$.System.DateTimeOffset().$ctor$11(scaledYear, month, day, hour, minute, second, offset);
                }
                catch(e)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$7($.$sfa.System.SR.ContentException_DefaultMessage, e);
                }
            }
            /*int*/ static MaxCERSegmentSize = 1000;
            /*int*/ static EndOfContentsEncodedLength = 2;
            static /*bool */ TryReadEncodedValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out Asn1Tag*/ tag, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed)
            {
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*Asn1Tag*/ let localTag;
                /*int*/ let tagLength;
                /*int?*/ let encodedLength;
                /*int*/ let lengthLength;
                if ($.$sfa.System.Formats.Asn1.Asn1Tag.TryDecode(source, $.$ref(() => localTag, ($v) => localTag = $v, $.$sfa.System.Formats.Asn1.Asn1Tag), $.$ref(() => tagLength, ($v) => tagLength = $v, $.$$.System.Int32)) && $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadLength(source.Slice$1(tagLength), ruleSet, $.$ref(() => encodedLength, ($v) => encodedLength = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$$.System.Int32)))
                {
                    /*int*/ let headerLength = ((tagLength + lengthLength) | 0);
                    /*int*/ let len;
                    /*int*/ let consumed;
                    /*LengthValidity*/ let validity = $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateLength(source.Slice$1(headerLength), ruleSet, localTag, encodedLength, $.$ref(() => len, ($v) => len = $v, $.$$.System.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                    if (validity === 3/*LengthValidity.Valid*/)
                    {
                        tag.$v = localTag;
                        contentOffset.$v = headerLength;
                        contentLength.$v = len;
                        bytesConsumed.$v = ((headerLength + consumed) | 0);
                        return true;
                    }
                }
                tag.$v = new $.$sfa.System.Formats.Asn1.Asn1Tag();
                contentOffset.$v = contentLength.$v = bytesConsumed.$v = 0;
                return false;
            }
            static /*Asn1Tag */ ReadEncodedValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed)
            {
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*int*/ let tagLength;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.Asn1Tag.Decode(source, $.$ref(() => tagLength, ($v) => tagLength = $v, $.$$.System.Int32));
                /*int*/ let lengthLength;
                /*int?*/ let encodedLength = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadLength(source.Slice$1(tagLength), ruleSet, $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$$.System.Int32));
                /*int*/ let headerLength = ((tagLength + lengthLength) | 0);
                /*int*/ let len;
                /*int*/ let consumed;
                /*LengthValidity*/ let validity = $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateLength(source.Slice$1(headerLength), ruleSet, tag, encodedLength, $.$ref(() => len, ($v) => len = $v, $.$$.System.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (validity === 3/*LengthValidity.Valid*/)
                {
                    contentOffset.$v = headerLength;
                    contentLength.$v = len;
                    bytesConsumed.$v = ((headerLength + consumed) | 0);
                    return tag;
                }
                throw $.$sfa.System.Formats.Asn1.AsnDecoder.GetValidityException(validity);
            }
            static /*ReadOnlySpan<byte> */ GetPrimitiveContentSpan(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out int*/ bytesConsumed)
            {
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*int*/ let tagLength;
                /*Asn1Tag*/ let localTag = $.$sfa.System.Formats.Asn1.Asn1Tag.Decode(source, $.$ref(() => tagLength, ($v) => tagLength = $v, $.$$.System.Int32));
                /*int*/ let lengthLength;
                /*int?*/ let encodedLength = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadLength(source.Slice$1(tagLength), ruleSet, $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$$.System.Int32));
                /*int*/ let headerLength = ((tagLength + lengthLength) | 0);
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(localTag, expectedTag, tagNumber);
                if (localTag.IsConstructed)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.Format$6($.$sfa.System.SR.ContentException_PrimitiveEncodingRequired, $.$box(tagNumber, $.$sfa.System.Formats.Asn1.UniversalTagNumber)));
                }
                if (encodedLength === null)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*ReadOnlySpan<byte>*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(source, headerLength, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(encodedLength));
                bytesConsumed.$v = ((headerLength + ret.Length) | 0);
                return ret;
            }
            static /*int? */ DecodeLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed)
            {
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*int*/ let read;
                /*int?*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadLength(source, ruleSet, $.$ref(() => read, ($v) => read = $v, $.$$.System.Int32));
                bytesConsumed.$v = read;
                return ret;
            }
            static /*bool */ TryDecodeLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ decodedLength, /*out int*/ bytesConsumed)
            {
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*int?*/ let decoded;
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadLength(source, ruleSet, $.$ref(() => decoded, ($v) => decoded = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => read, ($v) => read = $v, $.$$.System.Int32));
                bytesConsumed.$v = read;
                decodedLength.$v = decoded;
                return ret;
            }
            static /*bool */ TryReadLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ length, /*out int*/ bytesRead)
            {
                return $.$sfa.System.Formats.Asn1.AsnDecoder.DecodeLength$1(source, ruleSet, length, bytesRead) === 5/*LengthDecodeStatus.Success*/;
            }
            static /*int? */ ReadLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed)
            {
                /*int?*/ let length;
                /*LengthDecodeStatus*/ let status = $.$sfa.System.Formats.Asn1.AsnDecoder.DecodeLength$1(source, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.System.Int32)), bytesConsumed);
                let $switchJumpState3;
                $switchJumpStart3: while(true)
                {
                    switch($switchJumpState3 ?? status)
                    {
                        case 5/*LengthDecodeStatus.Success*/:
                        return length;
                        case 3/*LengthDecodeStatus.LengthTooBig*/:
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_LengthTooBig);
                        case 4/*LengthDecodeStatus.LaxEncodingProhibited*/:
                        case 1/*LengthDecodeStatus.DerIndefinite*/:
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_LengthRuleSetConstraint);
                        case 0/*LengthDecodeStatus.NeedMoreData*/:
                        case 2/*LengthDecodeStatus.ReservedValue*/:
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        default:
                        $.$$.System.Diagnostics.Debug.Fail$1(`No handler is present for status ${status}.`);
                        $switchJumpState3 = 0/*LengthDecodeStatus.NeedMoreData*/; /*goto case LengthDecodeStatus.NeedMoreData*/
                        continue $switchJumpStart3;
                    }
                    break;
                }
            }
            static /*LengthDecodeStatus */ DecodeLength$1(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ length, /*out int*/ bytesRead)
            {
                length.$v = null;
                bytesRead.$v = 0;
                $.$sfa.System.Formats.Asn1.AsnDecoder.AssertEncodingRules(ruleSet);
                if (source.IsEmpty)
                {
                    return 0/*LengthDecodeStatus.NeedMoreData*/;
                }
                /*byte*/ let lengthOrLengthLength = source.get_Item(bytesRead.$v).$v;
                bytesRead.$v++;
                /*byte*/ let MultiByteMarker = 128;
                if (lengthOrLengthLength === MultiByteMarker)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/)
                    {
                        bytesRead.$v = 0;
                        return 1/*LengthDecodeStatus.DerIndefinite*/;
                    }
                    return 5/*LengthDecodeStatus.Success*/;
                }
                if (lengthOrLengthLength < MultiByteMarker)
                {
                    length.$v = lengthOrLengthLength;
                    return 5/*LengthDecodeStatus.Success*/;
                }
                if (lengthOrLengthLength === 255)
                {
                    bytesRead.$v = 0;
                    return 2/*LengthDecodeStatus.ReservedValue*/;
                }
                /*byte*/ let lengthLength = $.$cast((lengthOrLengthLength & ~MultiByteMarker), $.$$.System.Byte);
                if (((lengthLength + 1) | 0) > source.Length)
                {
                    bytesRead.$v = 0;
                    return 0/*LengthDecodeStatus.NeedMoreData*/;
                }
                /*bool*/ let minimalRepresentation = ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/;
                if (minimalRepresentation && lengthLength > $.$$.System.Int32.$z)
                {
                    bytesRead.$v = 0;
                    return 3/*LengthDecodeStatus.LengthTooBig*/;
                }
                /*uint*/ let parsedLength = 0;
                for(/*int*/ let i = 0; i < lengthLength; i++)
                {
                    /*byte*/ let current = source.get_Item(bytesRead.$v).$v;
                    bytesRead.$v++;
                    if (parsedLength === 0)
                    {
                        if (minimalRepresentation && current === 0)
                        {
                            bytesRead.$v = 0;
                            return 4/*LengthDecodeStatus.LaxEncodingProhibited*/;
                        }
                        if (!minimalRepresentation && current !== 0)
                        {
                            if (((lengthLength - i) | 0) > $.$$.System.Int32.$z)
                            {
                                bytesRead.$v = 0;
                                return 3/*LengthDecodeStatus.LengthTooBig*/;
                            }
                        }
                    }
                    parsedLength <<= 8;
                    parsedLength |= current;
                }
                if (parsedLength > 2147483647/*int.MaxValue*/)
                {
                    bytesRead.$v = 0;
                    return 3/*LengthDecodeStatus.LengthTooBig*/;
                }
                if (minimalRepresentation && parsedLength < MultiByteMarker)
                {
                    bytesRead.$v = 0;
                    return 4/*LengthDecodeStatus.LaxEncodingProhibited*/;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(bytesRead.$v > 0, "bytesRead > 0");
                length.$v = (parsedLength | 0);
                return 5/*LengthDecodeStatus.Success*/;
            }
            static /*Asn1Tag */ ReadTagAndLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ contentsLength, /*out int*/ bytesRead)
            {
                /*int*/ let tagBytesRead;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.Asn1Tag.Decode(source, $.$ref(() => tagBytesRead, ($v) => tagBytesRead = $v, $.$$.System.Int32));
                /*int*/ let lengthBytesRead;
                /*int?*/ let length = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadLength(source.Slice$1(tagBytesRead), ruleSet, $.$ref(() => lengthBytesRead, ($v) => lengthBytesRead = $v, $.$$.System.Int32));
                /*int*/ let allBytesRead = ((tagBytesRead + lengthBytesRead) | 0);
                if (tag.IsConstructed)
                {
                    if (ruleSet === 1/*AsnEncodingRules.CER*/ && length !== null)
                    {
                        throw $.$sfa.System.Formats.Asn1.AsnDecoder.GetValidityException(0/*LengthValidity.CerRequiresIndefinite*/);
                    }
                }
                else if (length === null)
                {
                    throw $.$sfa.System.Formats.Asn1.AsnDecoder.GetValidityException(1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/);
                }
                bytesRead.$v = allBytesRead;
                contentsLength.$v = length;
                return tag;
            }
            static /*void */ ValidateEndOfContents(/*Asn1Tag*/ tag, /*int?*/ length, /*int*/ headerLength)
            {
                if (tag.IsConstructed || length !== 0 || headerLength !== 2/*EndOfContentsEncodedLength*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
            }
            static /*LengthValidity */ ValidateLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ localTag, /*int?*/ encodedLength, /*out int*/ actualLength, /*out int*/ bytesConsumed)
            {
                if (localTag.IsConstructed)
                {
                    if (ruleSet === 1/*AsnEncodingRules.CER*/ && encodedLength !== null)
                    {
                        actualLength.$v = bytesConsumed.$v = 0;
                        return 0/*LengthValidity.CerRequiresIndefinite*/;
                    }
                }
                else if (encodedLength === null)
                {
                    actualLength.$v = bytesConsumed.$v = 0;
                    return 1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/;
                }
                if (encodedLength !== null)
                {
                    /*int*/ let len = $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(encodedLength);
                    /*int*/ let totalLength = len;
                    if (totalLength > source.Length)
                    {
                        actualLength.$v = bytesConsumed.$v = 0;
                        return 2/*LengthValidity.LengthExceedsInput*/;
                    }
                    actualLength.$v = len;
                    bytesConsumed.$v = len;
                    return 3/*LengthValidity.Valid*/;
                }
                actualLength.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(source, ruleSet);
                bytesConsumed.$v = ((actualLength.$v + 2/*EndOfContentsEncodedLength*/) | 0);
                return 3/*LengthValidity.Valid*/;
            }
            static /*AsnContentException */ GetValidityException(/*LengthValidity*/ validity)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(validity !== 3/*LengthValidity.Valid*/, "validity != LengthValidity.Valid");
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    switch($switchJumpState1 ?? validity)
                    {
                        case 0/*LengthValidity.CerRequiresIndefinite*/:
                        return new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_CerRequiresIndefiniteLength);
                        case 2/*LengthValidity.LengthExceedsInput*/:
                        return new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_LengthExceedsPayload);
                        case 1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/:
                        return new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        default:
                        $.$$.System.Diagnostics.Debug.Fail$1(`No handler for validity ${validity}.`);
                        $switchJumpState1 = 1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/; /*goto case LengthValidity.PrimitiveEncodingRequiresDefinite*/
                        continue $switchJumpStart1;
                    }
                    break;
                }
            }
            static /*int */ GetPrimitiveIntegerSize(/*Type*/ primitiveType)
            {
                if ($.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.Byte.$type) || $.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.SByte.$type))
                {
                    return 1;
                }
                if ($.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.Int16.$type) || $.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.UInt16.$type))
                {
                    return 2;
                }
                if ($.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.Int32.$type) || $.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.UInt32.$type))
                {
                    return 4;
                }
                if ($.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.Int64.$type) || $.$$.System.Type.op_Equality$1(primitiveType, $.$$.System.UInt64.$type))
                {
                    return 8;
                }
                return 0;
            }
            static /*int */ SeekEndOfContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet)
            {
                /*ReadOnlySpan<byte>*/ let cur = source;
                /*int*/ let totalLen = 0;
                /*int*/ let depth = 1;
                while(!cur.IsEmpty)
                {
                    /*int?*/ let length;
                    /*int*/ let bytesRead;
                    /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(cur, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32));
                    if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents))
                    {
                        $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateEndOfContents(tag, length, bytesRead);
                        depth--;
                        if (depth === 0)
                        {
                            return totalLen;
                        }
                    }
                    if (length === null)
                    {
                        depth++;
                        cur = cur.Slice$1(bytesRead);
                        totalLen += bytesRead;
                    }
                    else 
                    {
                        /*ReadOnlySpan<byte>*/ let tlv = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(cur, 0, ((bytesRead + $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length)) | 0));
                        cur = cur.Slice$1(tlv.Length);
                        totalLen += tlv.Length;
                    }
                }
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            static /*int */ ParseNonNegativeIntAndSlice(/*ref ReadOnlySpan<byte>*/ data, /*int*/ bytesToRead)
            {
                /*int*/ let value = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeInt($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(data.$v, 0, bytesToRead));
                data.$v = data.$v.Slice$1(bytesToRead);
                return value;
            }
            static /*int */ ParseNonNegativeInt(/*ReadOnlySpan<byte>*/ data)
            {
                /*uint*/ let value;
                /*int*/ let consumed;
                if ($.$$.System.Buffers.Text.Utf8Parser.TryParse$14(data, $.$ref(() => value, ($v) => value = $v, $.$$.System.UInt32), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), /*\u0000*/ 0) && value <= 2147483647/*int.MaxValue*/ && consumed === data.Length)
                {
                    return (value | 0);
                }
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            static /*ReadOnlySpan<byte> */ SliceAtMost(/*ReadOnlySpan<byte>*/ source, /*int*/ longestPermitted)
            {
                /*int*/ let len = $.$$.System.Math.Min$4(longestPermitted, source.Length);
                return source.Slice(0, len);
            }
            static /*ReadOnlySpan<byte> */ Slice$1(/*ReadOnlySpan<byte>*/ source, /*int*/ offset, /*int*/ length)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(offset >= 0, "offset >= 0");
                if (length < 0 || ((source.Length - offset) | 0) < length)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_LengthExceedsPayload);
                }
                return source.Slice(offset, length);
            }
            static /*ReadOnlySpan<byte> */ Slice$2(/*ReadOnlySpan<byte>*/ source, /*int*/ offset, /*int?*/ length)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(offset >= 0, "offset >= 0");
                if (length === null)
                {
                    return source.Slice$1(offset);
                }
                /*int*/ let lengthVal = $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length);
                if (lengthVal < 0 || ((source.Length - offset) | 0) < lengthVal)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_LengthExceedsPayload);
                }
                return source.Slice(offset, lengthVal);
            }
            static /*ReadOnlyMemory<byte> */ Slice(/*ReadOnlyMemory<byte>*/ bigger, /*ReadOnlySpan<byte>*/ smaller)
            {
                if (smaller.IsEmpty)
                {
                    return new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))();
                }
                /*int*/ let offset;
                if ($.$$.System.MemoryExtensions.Overlaps($.$$.System.Byte, bigger.Span, smaller, $.$ref(() => offset, ($v) => offset = $v, $.$$.System.Int32)))
                {
                    return bigger.Slice(offset, smaller.Length);
                }
                $.$$.System.Diagnostics.Debug.Fail$1("AsnReader asked for a matching slice from a non-overlapping input");
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            static /*void */ AssertEncodingRules(/*AsnEncodingRules*/ ruleSet)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(ruleSet >= 0/*AsnEncodingRules.BER*/ && ruleSet <= 2/*AsnEncodingRules.DER*/, "ruleSet >= AsnEncodingRules.BER && ruleSet <= AsnEncodingRules.DER");
            }
            static /*void */ CheckEncodingRules(/*AsnEncodingRules*/ ruleSet)
            {
                if (ruleSet !== 0/*AsnEncodingRules.BER*/ && ruleSet !== 1/*AsnEncodingRules.CER*/ && ruleSet !== 2/*AsnEncodingRules.DER*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("ruleSet");
                }
            }
            static /*void */ CheckExpectedTag(/*Asn1Tag*/ tag, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber)
            {
                if (expectedTag.TagClass === 0/*TagClass.Universal*/ && expectedTag.TagValue !== tagNumber)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_UniversalValueIsFixed, "expectedTag");
                }
                if (expectedTag.TagClass !== tag.TagClass || expectedTag.TagValue !== tag.TagValue)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.Format$7($.$sfa.System.SR.ContentException_WrongTag, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$box(tag.TagClass, $.$sfa.System.Formats.Asn1.TagClass), $.$box(tag.TagValue, $.$$.System.Int32), $.$box(expectedTag.TagClass, $.$sfa.System.Formats.Asn1.TagClass), $.$box(expectedTag.TagValue, $.$$.System.Int32) ], null, null)));
                }
            }
            static $_LengthDecodeStatus;
            static get LengthDecodeStatus()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnDecoder;
                return $cls.$_LengthDecodeStatus ??= $asm.$nstr("$sfa.System.Formats.Asn1.AsnDecoder.LengthDecodeStatus", ($self) => class LengthDecodeStatus extends $.$$.System.Enum
                {
                    static NeedMoreData = 0;
                    static DerIndefinite = 1;
                    static ReservedValue = 2;
                    static LengthTooBig = 3;
                    static LaxEncodingProhibited = 4;
                    static Success = 5;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "NeedMoreData": 0n,
                            "DerIndefinite": 1n,
                            "ReservedValue": 2n,
                            "LengthTooBig": 3n,
                            "LaxEncodingProhibited": 4n,
                            "Success": 5n
                        };
                    }
                    static $h = 454510;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":454510,"n":"NeedMoreData","d":454510,"h":4295421806,"f":4194337},{"t":454510,"n":"DerIndefinite","d":454510,"h":8590389102,"f":4194337},{"t":454510,"n":"ReservedValue","d":454510,"h":12885356398,"f":4194337},{"t":454510,"n":"LengthTooBig","d":454510,"h":17180323694,"f":4194337},{"t":454510,"n":"LaxEncodingProhibited","d":454510,"h":21475290990,"f":4194337},{"t":454510,"n":"Success","d":454510,"h":25770258286,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":454510,"h":30065225582,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":323438,"h":454510}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnDecoder.LengthDecodeStatus`; }
                }, $cls, ($v) => $cls.$_LengthDecodeStatus = $v);
            }
            static $_LengthValidity;
            static get LengthValidity()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnDecoder;
                return $cls.$_LengthValidity ??= $asm.$nstr("$sfa.System.Formats.Asn1.AsnDecoder.LengthValidity", ($self) => class LengthValidity extends $.$$.System.Enum
                {
                    static CerRequiresIndefinite = 0;
                    static PrimitiveEncodingRequiresDefinite = 1;
                    static LengthExceedsInput = 2;
                    static Valid = 3;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "CerRequiresIndefinite": 0n,
                            "PrimitiveEncodingRequiresDefinite": 1n,
                            "LengthExceedsInput": 2n,
                            "Valid": 3n
                        };
                    }
                    static $h = 520046;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":520046,"n":"CerRequiresIndefinite","d":520046,"h":4295487342,"f":4194337},{"t":520046,"n":"PrimitiveEncodingRequiresDefinite","d":520046,"h":8590454638,"f":4194337},{"t":520046,"n":"LengthExceedsInput","d":520046,"h":12885421934,"f":4194337},{"t":520046,"n":"Valid","d":520046,"h":17180389230,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":520046,"h":21475356526,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":323438,"h":520046}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnDecoder.LengthValidity`; }
                }, $cls, ($v) => $cls.$_LengthValidity = $v);
            }
            static /*bool */ TryReadPrimitiveBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let localUbc;
                /*ReadOnlySpan<byte>*/ let localValue;
                /*int*/ let consumed;
                /*byte*/ let normalizedLastByte;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveBitStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString, $.$discardRef(), $.$discardRef(), $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.System.Int32), $.$ref(() => localValue, ($v) => localValue = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$$.System.Byte)))
                {
                    if (localValue.Length === 0 || normalizedLastByte === localValue.get_Item(((localValue.Length - 1) | 0)).$v)
                    {
                        unusedBitCount.$v = localUbc;
                        value.$v = localValue;
                        bytesConsumed.$v = consumed;
                        return true;
                    }
                }
                unusedBitCount.$v = 0;
                value.$v = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))();
                bytesConsumed.$v = 0;
                return false;
            }
            static /*bool */ TryReadBitString(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                if ($.$$.System.MemoryExtensions.Overlaps$1($.$$.System.Byte, source, $.$$.System.Span$$($.$$.System.Byte).op_Implicit(destination)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_SourceOverlapsDestination, "destination");
                }
                /*int*/ let localUbc;
                /*byte*/ let normalizedLastByte;
                /*int*/ let consumed;
                /*int?*/ let contentsLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let value;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveBitStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString, $.$ref(() => contentsLength, ($v) => contentsLength = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32), $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.System.Int32), $.$ref(() => value, ($v) => value = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$$.System.Byte)))
                {
                    if (value.Length > destination.Length)
                    {
                        bytesConsumed.$v = 0;
                        bytesWritten.$v = 0;
                        unusedBitCount.$v = 0;
                        return false;
                    }
                    $.$sfa.System.Formats.Asn1.AsnDecoder.CopyBitStringValue(value, normalizedLastByte, destination);
                    bytesWritten.$v = value.Length;
                    bytesConsumed.$v = consumed;
                    unusedBitCount.$v = localUbc;
                    return true;
                }
                /*int*/ let bytesRead;
                /*int*/ let written;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedBitStringValue($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength, contentsLength), ruleSet, destination, contentsLength === null, $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.System.Int32), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => written, ($v) => written = $v, $.$$.System.Int32)))
                {
                    unusedBitCount.$v = localUbc;
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                    bytesWritten.$v = written;
                    return true;
                }
                bytesWritten.$v = bytesConsumed.$v = unusedBitCount.$v = 0;
                return false;
            }
            static /*byte[] */ ReadBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int?*/ let contentsLength;
                /*int*/ let headerLength;
                /*int*/ let localUbc;
                /*ReadOnlySpan<byte>*/ let localValue;
                /*int*/ let consumed;
                /*byte*/ let normalizedLastByte;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveBitStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString, $.$ref(() => contentsLength, ($v) => contentsLength = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32), $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.System.Int32), $.$ref(() => localValue, ($v) => localValue = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$$.System.Byte)))
                {
                    /*byte[]*/ let ret = localValue.ToArray();
                    if (localValue.Length > 0)
                    {
                        $.$$.System.Array.$WriteT1.call(ret, normalizedLastByte, ((ret.length - 1) | 0));
                    }
                    unusedBitCount.$v = localUbc;
                    bytesConsumed.$v = consumed;
                    return ret;
                }
                /*int*/ let tooBig = contentsLength ?? $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(source.Slice$1(headerLength), ruleSet);
                /*byte[]*/ let rented = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(tooBig);
                /*int*/ let bytesRead;
                /*int*/ let written;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedBitStringValue($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength, contentsLength), ruleSet, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rented), contentsLength === null, $.$ref(() => localUbc, ($v) => localUbc = $v, $.$$.System.Int32), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$$.System.Int32), $.$ref(() => written, ($v) => written = $v, $.$$.System.Int32)))
                {
                    /*byte[]*/ let ret = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, rented, 0, written).ToArray();
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, written);
                    unusedBitCount.$v = localUbc;
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                    return ret;
                }
                $.$$.System.Diagnostics.Debug.Fail$1("TryCopyConstructedBitStringValue failed with a pre-allocated buffer");
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            static /*void */ ParsePrimitiveBitStringContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out ReadOnlySpan<byte>*/ value, /*out byte*/ normalizedLastByte)
            {
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && source.Length > 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCer_TryBerOrDer);
                }
                if (source.Length === 0)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                unusedBitCount.$v = source.get_Item(0).$v;
                if (unusedBitCount.$v > 7)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                if (source.Length === 1)
                {
                    if (unusedBitCount.$v > 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(unusedBitCount.$v === 0, "unusedBitCount == 0");
                    value.$v = $.$$.System.ReadOnlySpan$$($.$$.System.Byte).Empty;
                    normalizedLastByte.$v = 0;
                    return;
                }
                /*int*/ let mask = -1 << unusedBitCount.$v;
                /*byte*/ let lastByte = source.get_Item(((source.Length - 1) | 0)).$v;
                /*byte*/ let maskedByte = $.$cast((lastByte & mask), $.$$.System.Byte);
                if (maskedByte !== lastByte)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                normalizedLastByte.$v = maskedByte;
                value.$v = source.Slice$1(1);
            }
            static $_BitStringCopyAction;
            static get BitStringCopyAction()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnDecoder;
                return $cls.$_BitStringCopyAction ??= $asm.$ncls("$sfa.System.Formats.Asn1.AsnDecoder.BitStringCopyAction", ($self) => class BitStringCopyAction extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ value, /*$.$$.System.Byte*/ normalizedLastByte, /**/ destination)
                    {
                        return this.$nativeFunction.call(this.$target, value, normalizedLastByte, destination);
                    }
                    static $h = 388974;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"normalizedLastByte","p":393217},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"Invoke","d":388974,"h":8590323566,"f":16777345},{"r":57016321,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"normalizedLastByte","p":393217},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":388974,"h":12885290862,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":388974,"h":17180258158,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":388974,"h":4295356270,"f":16777217}],"i":[57212929,113246209],"d":323438,"h":388974}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnDecoder.BitStringCopyAction`; }
                }, $cls, ($v) => $cls.$_BitStringCopyAction = $v);
            }
            static /*void */ CopyBitStringValue(/*ReadOnlySpan<byte>*/ value, /*byte*/ normalizedLastByte, /*Span<byte>*/ destination)
            {
                if (value.Length === 0)
                {
                    return;
                }
                value.CopyTo(destination);
                destination.get_Item(((value.Length - 1) | 0)).$v = normalizedLastByte;
            }
            static /*int */ CountConstructedBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*bool*/ isIndefinite)
            {
                /*Span<byte>*/ let destination = $.$$.System.Span$$($.$$.System.Byte).Empty;
                return $.$sfa.System.Formats.Asn1.AsnDecoder.ProcessConstructedBitString(source, ruleSet, destination, null, isIndefinite, $.$discardRef(), $.$discardRef());
            }
            static /*void */ CopyConstructedBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*bool*/ isIndefinite, /*out int*/ unusedBitCount, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                /*Span<byte>*/ let tmpDest = destination;
                bytesWritten.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.ProcessConstructedBitString(source, ruleSet, tmpDest, new $.$sfa.System.Formats.Asn1.AsnDecoder.BitStringCopyAction().$ctor($.$sfa.System.Formats.Asn1.AsnDecoder, $.$sfa.System.Formats.Asn1.AsnDecoder.CopyBitStringValue), isIndefinite, unusedBitCount, bytesRead);
            }
            static /*int */ ProcessConstructedBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*BitStringCopyAction?*/ copyAction, /*bool*/ isIndefinite, /*out int*/ lastUnusedBitCount, /*out int*/ bytesRead)
            {
                lastUnusedBitCount.$v = 0;
                bytesRead.$v = 0;
                /*int*/ let lastSegmentLength = 1000/*MaxCERSegmentSize*/;
                /*ReadOnlySpan<byte>*/ let cur = source;
                /*Stack<(int Offset, int Length, bool Indefinite, int BytesRead)>?*/ let readerStack = null;
                /*int*/ let totalLength = 0;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedBitString;
                /*Span<byte>*/ let curDest = destination;
                while(true)
                {
                    while(!cur.IsEmpty)
                    {
                        /*int?*/ let length;
                        /*int*/ let headerLength;
                        tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(cur, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$$.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$$.System.Int32));
                        if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString))
                        {
                            if (lastUnusedBitCount.$v !== 0)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                            }
                            if (ruleSet === 1/*AsnEncodingRules.CER*/ && lastSegmentLength !== 1000/*MaxCERSegmentSize*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCer_TryBerOrDer);
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(length !== null, "length != null");
                            /*ReadOnlySpan<byte>*/ let encodedValue = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(cur, headerLength, $.$$.System.Nullable$$($.$$.System.Int32).Value$get.call(length));
                            /*ReadOnlySpan<byte>*/ let contents;
                            /*byte*/ let normalizedLastByte;
                            $.$sfa.System.Formats.Asn1.AsnDecoder.ParsePrimitiveBitStringContents(encodedValue, ruleSet, lastUnusedBitCount, $.$ref(() => contents, ($v) => contents = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$$.System.Byte));
                            /*int*/ let localLen = ((headerLength + encodedValue.Length) | 0);
                            cur = cur.Slice$1(localLen);
                            bytesRead.$v += localLen;
                            totalLength += contents.Length;
                            lastSegmentLength = encodedValue.Length;
                            if (copyAction !== null)
                            {
                                copyAction.Invoke(contents, normalizedLastByte, curDest);
                                curDest = curDest.Slice$1(contents.Length);
                            }
                        }
                        else if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents) && isIndefinite)
                        {
                            $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateEndOfContents(tag, length, headerLength);
                            bytesRead.$v += headerLength;
                            if ($.$$.System.Int32.op_GreaterThan$1((readerStack?.Count ?? null), 0))
                            {
                                const { Item1: topOffset, Item2: topLength, Item3: wasIndefinite, Item4: pushedBytesRead } = readerStack.Pop();
                                /*ReadOnlySpan<byte>*/ let topSpan = source.Slice(topOffset, topLength);
                                cur = topSpan.Slice$1(bytesRead.$v);
                                bytesRead.$v += pushedBytesRead;
                                isIndefinite = wasIndefinite;
                            }
                            else 
                            {
                                break;
                            }
                        }
                        else if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedBitString))
                        {
                            if (ruleSet === 1/*AsnEncodingRules.CER*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            readerStack ??= new ($.$sc.System.Collections.Generic.Stack$$($.$$.System.ValueTuple$$$$$($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Boolean, $.$$.System.Int32)))().$ctor$1();
                            /*int*/ let curOffset;
                            if (!$.$$.System.MemoryExtensions.Overlaps($.$$.System.Byte, source, cur, $.$ref(() => curOffset, ($v) => curOffset = $v, $.$$.System.Int32)))
                            {
                                $.$$.System.Diagnostics.Debug.Fail$1("Non-overlapping data encountered...");
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                            }
                            readerStack.Push(new ($.$$.System.ValueTuple$$$$$($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Boolean, $.$$.System.Int32))().$ctor$3(curOffset, cur.Length, isIndefinite, bytesRead.$v));
                            cur = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(cur, headerLength, length);
                            bytesRead.$v = headerLength;
                            isIndefinite = (length === null);
                        }
                        else 
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                    }
                    if (isIndefinite && $.$sfa.System.Formats.Asn1.Asn1Tag.op_Inequality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    if ($.$$.System.Int32.op_GreaterThan$1((readerStack?.Count ?? null), 0))
                    {
                        const { Item1: topOffset, Item2: topLength, Item3: wasIndefinite, Item4: pushedBytesRead } = readerStack.Pop();
                        /*ReadOnlySpan<byte>*/ let tmpSpan = source.Slice(topOffset, topLength);
                        cur = tmpSpan.Slice$1(bytesRead.$v);
                        isIndefinite = wasIndefinite;
                        bytesRead.$v += pushedBytesRead;
                    }
                    else 
                    {
                        return totalLength;
                    }
                }
            }
            static /*bool */ TryCopyConstructedBitStringValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ dest, /*bool*/ isIndefinite, /*out int*/ unusedBitCount, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                /*int*/ let contentLength = $.$sfa.System.Formats.Asn1.AsnDecoder.CountConstructedBitString(source, ruleSet, isIndefinite);
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && contentLength < 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                if (dest.Length < contentLength)
                {
                    unusedBitCount.$v = 0;
                    bytesRead.$v = 0;
                    bytesWritten.$v = 0;
                    return false;
                }
                $.$sfa.System.Formats.Asn1.AsnDecoder.CopyConstructedBitString(source, ruleSet, dest, isIndefinite, unusedBitCount, bytesRead, bytesWritten);
                $.$$.System.Diagnostics.Debug.Assert$2(bytesWritten.$v === contentLength, "bytesWritten == contentLength");
                return true;
            }
            static /*bool */ TryReadPrimitiveBitStringCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*out int?*/ contentsLength, /*out int*/ headerLength, /*out int*/ unusedBitCount, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed, /*out byte*/ normalizedLastByte)
            {
                /*Asn1Tag*/ let actualTag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(source, ruleSet, contentsLength, headerLength);
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(actualTag, expectedTag, 3/*UniversalTagNumber.BitString*/);
                /*ReadOnlySpan<byte>*/ let encodedValue = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(source, headerLength.$v, contentsLength.$v);
                if (actualTag.IsConstructed)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidUnderDer_TryBerOrCer);
                    }
                    unusedBitCount.$v = 0;
                    value.$v = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))();
                    normalizedLastByte.$v = 0;
                    bytesConsumed.$v = 0;
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(contentsLength.$v), "contentsLength.HasValue");
                $.$sfa.System.Formats.Asn1.AsnDecoder.ParsePrimitiveBitStringContents(encodedValue, ruleSet, unusedBitCount, value, normalizedLastByte);
                bytesConsumed.$v = ((headerLength.$v + encodedValue.Length) | 0);
                return true;
            }
            static $h = 323438;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadBoolean","d":323438,"h":4295290734,"f":16777249},{"r":(TFlagsEnum) => TFlagsEnum.$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"g":["TFlagsEnum"],"n":"ReadNamedBitListValue","o":"@$1","d":323438,"h":8590258030,"f":16908321},{"r":1048577,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"flagsEnumType","p":142475265},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadNamedBitListValue","d":323438,"h":12885225326,"f":16777249},{"r":24510465,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadNamedBitList","d":323438,"h":17180192622,"f":16777249},{"r":917505,"p":[{"n":"valueSpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"InterpretNamedBitListReversed","d":323438,"h":21475159918,"f":16777250},{"r":65537,"p":[{"n":"value","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"ReverseBitsPerByte","d":323438,"h":25770127214,"f":16777256},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadNull","d":323438,"h":30065094510,"f":16777249},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadEnumeratedBytes","d":323438,"h":34360061806,"f":16777249},{"r":(TEnum) => TEnum.$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"g":["TEnum"],"n":"ReadEnumeratedValue","o":"@$1","d":323438,"h":38655029102,"f":16908321},{"r":1048577,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"enumType","p":142475265},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadEnumeratedValue","d":323438,"h":42949996398,"f":16777249},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"contentOffset","p":655361,"f":2},{"n":"contentLength","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadSequence","d":323438,"h":47244963694,"f":16777249},{"r":34471937,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadGeneralizedTime","d":323438,"h":51539930990,"f":16777249},{"r":34471937,"p":[{"n":"ruleSet","p":585582},{"n":"contentOctets","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"ParseGeneralizedTime","d":323438,"h":55834898286,"f":16777250},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"contentOffset","p":655361,"f":2},{"n":"contentLength","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"skipSortOrderValidation","p":262145,"f":65,"v":false},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadSetOf","d":323438,"h":60129865582,"f":16777249},{"r":1310721,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadObjectIdentifier","d":323438,"h":64424832878,"f":16777249},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"bytesRead","p":655361,"f":2},{"n":"smallValue","p":$.$typeNullable($.$$.System.Int64).$h,"f":2},{"n":"largeValue","p":$.$typeNullable($.$srn.System.Numerics.BigInteger).$h,"f":2}],"n":"ReadSubIdentifier","d":323438,"h":68719800174,"f":16777250},{"r":1310721,"p":[{"n":"contents","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"ReadObjectIdentifier","o":"@$1","d":323438,"h":73014767470,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadOctetString","d":323438,"h":77309734766,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadOctetString","d":323438,"h":81604702062,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"expectedTag","p":126830},{"n":"universalTagNumber","p":1634158},{"n":"contentLength","p":$.$typeNullable($.$$.System.Int32).$h,"f":2},{"n":"headerLength","p":655361,"f":2},{"n":"contents","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryReadPrimitiveOctetStringCore","d":323438,"h":85899669358,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadPrimitiveOctetString","d":323438,"h":90194636654,"f":16777249},{"r":655361,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"isIndefinite","p":262145}],"n":"CountConstructedOctetString","d":323438,"h":94489603950,"f":16777250},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"isIndefinite","p":262145},{"n":"bytesRead","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"CopyConstructedOctetString","o":"@$1","d":323438,"h":98784571246,"f":16777250},{"r":655361,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"write","p":262145},{"n":"isIndefinite","p":262145},{"n":"bytesRead","p":655361,"f":2}],"n":"CopyConstructedOctetString","d":323438,"h":103079538542,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"dest","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"isIndefinite","p":262145},{"n":"bytesRead","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryCopyConstructedOctetStringContents","d":323438,"h":107374505838,"f":16777250},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"expectedTag","p":126830},{"n":"universalTagNumber","p":1634158},{"n":"bytesConsumed","p":655361,"f":2},{"n":"rented","p":$.$typeArray($.$$.System.Byte).$h,"f":4},{"n":"tmpSpace","p":$.$$.System.Span$$($.$$.System.Byte).$h,"f":65}],"n":"GetOctetStringContents","d":323438,"h":111669473134,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"expectedTag","p":126830},{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryReadPrimitiveCharacterStringBytes","d":323438,"h":115964440430,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"expectedTag","p":126830},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryReadCharacterStringBytes","d":323438,"h":120259407726,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"ruleSet","p":585582},{"n":"encodingType","p":1634158},{"n":"bytesConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadCharacterString","d":323438,"h":124554375022,"f":16777249},{"r":1310721,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"encodingType","p":1634158},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadCharacterString","d":323438,"h":128849342318,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"expectedTag","p":126830},{"n":"universalTagNumber","p":1634158},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryReadCharacterStringBytesCore","d":323438,"h":133144309614,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"encoding","p":121700353},{"n":"charsWritten","p":655361,"f":2}],"n":"TryReadCharacterStringCore","d":323438,"h":137439276910,"f":16777250},{"r":1310721,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"expectedTag","p":126830},{"n":"universalTagNumber","p":1634158},{"n":"encoding","p":121700353},{"n":"bytesConsumed","p":655361,"f":2}],"n":"ReadCharacterStringCore","d":323438,"h":141734244206,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"expectedTag","p":126830},{"n":"universalTagNumber","p":1634158},{"n":"encoding","p":121700353},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2}],"n":"TryReadCharacterStringCore","o":"@$1","d":323438,"h":146029211502,"f":16777250},{"r":262145,"p":[{"n":"encodingType","p":1634158}],"n":"IsCharacterStringEncodingType","d":323438,"h":150324178798,"f":16777250},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadIntegerBytes","d":323438,"h":154619146094,"f":16777249},{"r":846197,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadInteger","d":323438,"h":158914113390,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"value","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadInt32","d":323438,"h":163209080686,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"value","p":720897,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadUInt32","d":323438,"h":167504047982,"f":16777249,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"value","p":917505,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadInt64","d":323438,"h":171799015278,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"value","p":983041,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadUInt64","d":323438,"h":176093982574,"f":16777249,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"expectedTag","p":126830},{"n":"tagNumber","p":1634158},{"n":"bytesConsumed","p":655361,"f":2}],"n":"GetIntegerContents","d":323438,"h":180388949870,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"sizeLimit","p":655361},{"n":"expectedTag","p":126830},{"n":"tagNumber","p":1634158},{"n":"value","p":917505,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryReadSignedInteger","d":323438,"h":184683917166,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"sizeLimit","p":655361},{"n":"expectedTag","p":126830},{"n":"tagNumber","p":1634158},{"n":"value","p":983041,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryReadUnsignedInteger","d":323438,"h":188978884462,"f":16777250},{"r":34471937,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2},{"n":"twoDigitYearMax","p":655361,"f":65,"v":2049},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadUtcTime","d":323438,"h":193273851758,"f":16777249},{"r":34471937,"p":[{"n":"contentOctets","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"twoDigitYearMax","p":655361}],"n":"ParseUtcTime","d":323438,"h":197568819054,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"tag","p":126830,"f":2},{"n":"contentOffset","p":655361,"f":2},{"n":"contentLength","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryReadEncodedValue","d":323438,"h":210453720942,"f":16777249},{"r":126830,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"contentOffset","p":655361,"f":2},{"n":"contentLength","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"ReadEncodedValue","d":323438,"h":214748688238,"f":16777249},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"expectedTag","p":126830},{"n":"tagNumber","p":1634158},{"n":"bytesConsumed","p":655361,"f":2}],"n":"GetPrimitiveContentSpan","d":323438,"h":219043655534,"f":16777250},{"r":$.$typeNullable($.$$.System.Int32).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2}],"n":"DecodeLength","d":323438,"h":223338622830,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"decodedLength","p":$.$typeNullable($.$$.System.Int32).$h,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryDecodeLength","d":323438,"h":227633590126,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"length","p":$.$typeNullable($.$$.System.Int32).$h,"f":2},{"n":"bytesRead","p":655361,"f":2}],"n":"TryReadLength","d":323438,"h":231928557422,"f":16777250},{"r":$.$typeNullable($.$$.System.Int32).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"bytesConsumed","p":655361,"f":2}],"n":"ReadLength","d":323438,"h":236223524718,"f":16777250},{"r":454510,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"length","p":$.$typeNullable($.$$.System.Int32).$h,"f":2},{"n":"bytesRead","p":655361,"f":2}],"n":"DecodeLength","o":"@$1","d":323438,"h":240518492014,"f":16777250},{"r":126830,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"contentsLength","p":$.$typeNullable($.$$.System.Int32).$h,"f":2},{"n":"bytesRead","p":655361,"f":2}],"n":"ReadTagAndLength","d":323438,"h":244813459310,"f":16777250},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"length","p":$.$typeNullable($.$$.System.Int32).$h},{"n":"headerLength","p":655361}],"n":"ValidateEndOfContents","d":323438,"h":249108426606,"f":16777250},{"r":520046,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"localTag","p":126830},{"n":"encodedLength","p":$.$typeNullable($.$$.System.Int32).$h},{"n":"actualLength","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"ValidateLength","d":323438,"h":253403393902,"f":16777250},{"r":257902,"p":[{"n":"validity","p":520046}],"n":"GetValidityException","d":323438,"h":257698361198,"f":16777250},{"r":655361,"p":[{"n":"primitiveType","p":142475265}],"n":"GetPrimitiveIntegerSize","d":323438,"h":261993328494,"f":16777250},{"r":655361,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582}],"n":"SeekEndOfContents","d":323438,"h":266288295790,"f":16777250},{"r":655361,"p":[{"n":"data","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"f":4},{"n":"bytesToRead","p":655361}],"n":"ParseNonNegativeIntAndSlice","d":323438,"h":270583263086,"f":16777250},{"r":655361,"p":[{"n":"data","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"ParseNonNegativeInt","d":323438,"h":274878230382,"f":16777250},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"longestPermitted","p":655361}],"n":"SliceAtMost","d":323438,"h":279173197678,"f":16777250},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"Slice","o":"@$1","d":323438,"h":283468164974,"f":16777250},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"length","p":$.$typeNullable($.$$.System.Int32).$h}],"n":"Slice","o":"@$2","d":323438,"h":287763132270,"f":16777250},{"r":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,"p":[{"n":"bigger","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"smaller","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"Slice","d":323438,"h":292058099566,"f":16777256},{"r":65537,"p":[{"n":"ruleSet","p":585582}],"n":"AssertEncodingRules","d":323438,"h":296353066862,"f":16777250,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"ruleSet","p":585582}],"n":"CheckEncodingRules","d":323438,"h":300648034158,"f":16777256},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"expectedTag","p":126830},{"n":"tagNumber","p":1634158}],"n":"CheckExpectedTag","d":323438,"h":304943001454,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"unusedBitCount","p":655361,"f":2},{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadPrimitiveBitString","d":323438,"h":317827903342,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"unusedBitCount","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadBitString","d":323438,"h":322122870638,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"unusedBitCount","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadBitString","d":323438,"h":326417837934,"f":16777249},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"unusedBitCount","p":655361,"f":2},{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"f":2},{"n":"normalizedLastByte","p":393217,"f":2}],"n":"ParsePrimitiveBitStringContents","d":323438,"h":330712805230,"f":16777250},{"r":65537,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"normalizedLastByte","p":393217},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"CopyBitStringValue","d":323438,"h":339302739822,"f":16777250},{"r":655361,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"isIndefinite","p":262145}],"n":"CountConstructedBitString","d":323438,"h":343597707118,"f":16777250},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"isIndefinite","p":262145},{"n":"unusedBitCount","p":655361,"f":2},{"n":"bytesRead","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"CopyConstructedBitString","d":323438,"h":347892674414,"f":16777250},{"r":655361,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"copyAction","p":388974},{"n":"isIndefinite","p":262145},{"n":"lastUnusedBitCount","p":655361,"f":2},{"n":"bytesRead","p":655361,"f":2}],"n":"ProcessConstructedBitString","d":323438,"h":352187641710,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"dest","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"isIndefinite","p":262145},{"n":"unusedBitCount","p":655361,"f":2},{"n":"bytesRead","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryCopyConstructedBitStringValue","d":323438,"h":356482609006,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"expectedTag","p":126830},{"n":"contentsLength","p":$.$typeNullable($.$$.System.Int32).$h,"f":2},{"n":"headerLength","p":655361,"f":2},{"n":"unusedBitCount","p":655361,"f":2},{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"normalizedLastByte","p":393217,"f":2}],"n":"TryReadPrimitiveBitStringCore","d":323438,"h":360777576302,"f":16777250}],"l":[{"t":655361,"n":"MaxCERSegmentSize","d":323438,"h":201863786350,"f":4194344},{"t":655361,"n":"EndOfContentsEncodedLength","d":323438,"h":206158753646,"f":4194344}],"j":[454510,520046,388974],"h":323438}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.AsnDecoder`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.AsnReader", ($self) => class AsnReader extends $.$$.System.Object
        {
            /*bool */ ReadBoolean(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let bytesConsumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadBoolean(this._data.Span, this.RuleSet, $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(bytesConsumed);
                return ret;
            }
            /*TFlagsEnum */ ReadNamedBitListValue$1(TFlagsEnum, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*TFlagsEnum*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNamedBitListValue$1(TFlagsEnum, this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            /*Enum */ ReadNamedBitListValue(/*Type*/ flagsEnumType, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*Enum*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNamedBitListValue(this._data.Span, this.RuleSet, flagsEnumType, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            /*BitArray */ ReadNamedBitList(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*BitArray*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNamedBitList(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            /*void */ ReadNull(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNull(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
            }
            /*ReadOnlyMemory<byte> */ ReadEnumeratedBytes(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let bytes = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEnumeratedBytes(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                /*ReadOnlyMemory<byte>*/ let memory = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(this._data, bytes);
                this._data = this._data.Slice$1(consumed);
                return memory;
            }
            /*TEnum */ ReadEnumeratedValue$1(TEnum, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*TEnum*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEnumeratedValue$1(TEnum, this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            /*Enum */ ReadEnumeratedValue(/*Type*/ enumType, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*Enum*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEnumeratedValue(this._data.Span, this.RuleSet, enumType, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            /*AsnReader */ ReadSequence(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let contentStart;
                /*int*/ let contentLength;
                /*int*/ let bytesConsumed;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadSequence(this._data.Span, this.RuleSet, $.$ref(() => contentStart, ($v) => contentStart = $v, $.$$.System.Int32), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$$.System.Int32), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                /*AsnReader*/ let ret = this.CloneAtSlice(contentStart, contentLength);
                this._data = this._data.Slice$1(bytesConsumed);
                return ret;
            }
            /*DateTimeOffset */ ReadGeneralizedTime(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*DateTimeOffset*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadGeneralizedTime(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            /*AsnReader */ ReadSetOf$1(/*Asn1Tag?*/ expectedTag)
            {
                return this.ReadSetOf(this._options.SkipSetSortOrderVerification, expectedTag?.Clone() ?? null);
            }
            /*AsnReader */ ReadSetOf(/*bool*/ skipSortOrderValidation, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let contentOffset;
                /*int*/ let contentLength;
                /*int*/ let bytesConsumed;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadSetOf(this._data.Span, this.RuleSet, $.$ref(() => contentOffset, ($v) => contentOffset = $v, $.$$.System.Int32), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$$.System.Int32), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32), skipSortOrderValidation, expectedTag?.Clone() ?? null);
                /*AsnReader*/ let ret = this.CloneAtSlice(contentOffset, contentLength);
                this._data = this._data.Slice$1(bytesConsumed);
                return ret;
            }
            /*string */ ReadObjectIdentifier(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*string*/ let oidValue = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadObjectIdentifier(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return oidValue;
            }
            /*bool */ TryReadOctetString(/*Span<byte>*/ destination, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let bytesConsumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadOctetString(this._data.Span, destination, this.RuleSet, $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32), bytesWritten, expectedTag?.Clone() ?? null);
                if (ret)
                {
                    this._data = this._data.Slice$1(bytesConsumed);
                }
                return ret;
            }
            /*byte[] */ ReadOctetString(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*byte[]*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadOctetString(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            /*bool */ TryReadPrimitiveOctetString(/*out ReadOnlyMemory<byte>*/ contents, /*Asn1Tag?*/ expectedTag)
            {
                /*ReadOnlySpan<byte>*/ let span;
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetString(this._data.Span, this.RuleSet, $.$ref(() => span, ($v) => span = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                if (ret)
                {
                    contents.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(this._data, span);
                    this._data = this._data.Slice$1(consumed);
                }
                else 
                {
                    contents.$v = new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))();
                }
                return ret;
            }
            /*bool */ TryReadPrimitiveCharacterStringBytes(/*Asn1Tag*/ expectedTag, /*out ReadOnlyMemory<byte>*/ contents)
            {
                /*ReadOnlySpan<byte>*/ let span;
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveCharacterStringBytes(this._data.Span, this.RuleSet, expectedTag, $.$ref(() => span, ($v) => span = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (ret)
                {
                    contents.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(this._data, span);
                    this._data = this._data.Slice$1(consumed);
                }
                else 
                {
                    contents.$v = new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))();
                }
                return ret;
            }
            /*bool */ TryReadCharacterStringBytes(/*Span<byte>*/ destination, /*Asn1Tag*/ expectedTag, /*out int*/ bytesWritten)
            {
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterStringBytes(this._data.Span, destination, this.RuleSet, expectedTag, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), bytesWritten);
                if (ret)
                {
                    this._data = this._data.Slice$1(consumed);
                }
                return ret;
            }
            /*bool */ TryReadCharacterString(/*Span<char>*/ destination, /*UniversalTagNumber*/ encodingType, /*out int*/ charsWritten, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterString(this._data.Span, destination, this.RuleSet, encodingType, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), charsWritten, expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            /*string */ ReadCharacterString(/*UniversalTagNumber*/ encodingType, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*string*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadCharacterString(this._data.Span, this.RuleSet, encodingType, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            /*ReadOnlyMemory<byte> */ ReadIntegerBytes(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let bytes = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadIntegerBytes(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                /*ReadOnlyMemory<byte>*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(this._data, bytes);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            /*BigInteger */ ReadInteger(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*BigInteger*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadInteger(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            /*bool */ TryReadInt32(/*out int*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadInt32(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(read);
                return ret;
            }
            /*bool */ TryReadUInt32(/*out uint*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUInt32(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(read);
                return ret;
            }
            /*bool */ TryReadInt64(/*out long*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadInt64(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(read);
                return ret;
            }
            /*bool */ TryReadUInt64(/*out ulong*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUInt64(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(read);
                return ret;
            }
            /*DateTimeOffset */ ReadUtcTime$1(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*DateTimeOffset*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadUtcTime(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), this._options.UtcTimeTwoDigitYearMax, expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            /*DateTimeOffset */ ReadUtcTime(/*int*/ twoDigitYearMax, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*DateTimeOffset*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadUtcTime(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), twoDigitYearMax, expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            /*int*/ static MaxCERSegmentSize = 1000;
            /*ReadOnlyMemory<byte>*/ _data;
            /*AsnReaderOptions*/ _options;
            /*AsnEncodingRules*/ RuleSet = 0;
            /*bool */ get HasData()
            {
                return !this._data.IsEmpty;
            }
            $ctor$1(/*ReadOnlyMemory<byte>*/ data, /*AsnEncodingRules*/ ruleSet, /*AsnReaderOptions*/ options)
            {
                super.$ctor();
                {
                    $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                    this._data = data;
                    this.RuleSet = ruleSet;
                    this._options = options.Clone();
                }
                return this;
            }
            /*void */ ThrowIfNotEmpty()
            {
                if (this.HasData)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_TooMuchData);
                }
            }
            /*Asn1Tag */ PeekTag()
            {
                return $.$sfa.System.Formats.Asn1.Asn1Tag.Decode(this._data.Span, $.$discardRef());
            }
            /*ReadOnlyMemory<byte> */ PeekEncodedValue()
            {
                /*int*/ let bytesConsumed;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEncodedValue(this._data.Span, this.RuleSet, $.$discardRef(), $.$discardRef(), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$$.System.Int32));
                return this._data.Slice(0, bytesConsumed);
            }
            /*ReadOnlyMemory<byte> */ PeekContentBytes()
            {
                /*int*/ let contentOffset;
                /*int*/ let contentLength;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEncodedValue(this._data.Span, this.RuleSet, $.$ref(() => contentOffset, ($v) => contentOffset = $v, $.$$.System.Int32), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$$.System.Int32), $.$discardRef());
                return this._data.Slice(contentOffset, contentLength);
            }
            /*ReadOnlyMemory<byte> */ ReadEncodedValue()
            {
                /*ReadOnlyMemory<byte>*/ let encodedValue = this.PeekEncodedValue();
                this._data = this._data.Slice$1(encodedValue.Length);
                return encodedValue;
            }
            /*AsnReader */ Clone()
            {
                return new $.$sfa.System.Formats.Asn1.AsnReader().$ctor$1(this._data, this.RuleSet, this._options.Clone());
            }
            /*AsnReader */ CloneAtSlice(/*int*/ start, /*int*/ length)
            {
                return new $.$sfa.System.Formats.Asn1.AsnReader().$ctor$1(this._data.Slice(start, length), this.RuleSet, this._options.Clone());
            }
            /*bool */ TryReadPrimitiveBitString(/*out int*/ unusedBitCount, /*out ReadOnlyMemory<byte>*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*ReadOnlySpan<byte>*/ let span;
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveBitString(this._data.Span, this.RuleSet, unusedBitCount, $.$ref(() => span, ($v) => span = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                if (ret)
                {
                    value.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(this._data, span);
                    this._data = this._data.Slice$1(consumed);
                }
                else 
                {
                    value.$v = new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))();
                }
                return ret;
            }
            /*bool */ TryReadBitString(/*Span<byte>*/ destination, /*out int*/ unusedBitCount, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadBitString(this._data.Span, destination, this.RuleSet, unusedBitCount, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), bytesWritten, expectedTag?.Clone() ?? null);
                if (ret)
                {
                    this._data = this._data.Slice$1(consumed);
                }
                return ret;
            }
            /*byte[] */ ReadBitString(/*out int*/ unusedBitCount, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*byte[]*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadBitString(this._data.Span, this.RuleSet, unusedBitCount, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32), expectedTag?.Clone() ?? null);
                this._data = this._data.Slice$1(consumed);
                return ret;
            }
            //default member initializer
            constructor()
            {
                super();
                this._data = $.$default($.$$.System.ReadOnlyMemory$$($.$$.System.Byte));
                this._options = $.$default($.$sfa.System.Formats.Asn1.AsnReaderOptions);
                this.RuleSet = 0;
            }
            static $h = 651118;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":585582,"g":{"r":0,"d":0,"h":146029539182,"f":50331649},"n":"RuleSet","d":651118,"h":141734571886,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":154619473774,"f":50331649},"n":"HasData","d":651118,"h":150324506478,"f":2097153}],"m":[{"r":262145,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadBoolean","d":651118,"h":4295618414,"f":16777217},{"r":(TFlagsEnum) => TFlagsEnum.$h,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"g":["TFlagsEnum"],"n":"ReadNamedBitListValue","o":"@$1","d":651118,"h":8590585710,"f":16908289},{"r":1048577,"p":[{"n":"flagsEnumType","p":142475265},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadNamedBitListValue","d":651118,"h":12885553006,"f":16777217},{"r":24510465,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadNamedBitList","d":651118,"h":17180520302,"f":16777217},{"r":65537,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadNull","d":651118,"h":21475487598,"f":16777217},{"r":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadEnumeratedBytes","d":651118,"h":25770454894,"f":16777217},{"r":(TEnum) => TEnum.$h,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"g":["TEnum"],"n":"ReadEnumeratedValue","o":"@$1","d":651118,"h":30065422190,"f":16908289},{"r":1048577,"p":[{"n":"enumType","p":142475265},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadEnumeratedValue","d":651118,"h":34360389486,"f":16777217},{"r":651118,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadSequence","d":651118,"h":38655356782,"f":16777217},{"r":34471937,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadGeneralizedTime","d":651118,"h":42950324078,"f":16777217},{"r":651118,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadSetOf","o":"@$1","d":651118,"h":47245291374,"f":16777217},{"r":651118,"p":[{"n":"skipSortOrderValidation","p":262145},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadSetOf","d":651118,"h":51540258670,"f":16777217},{"r":1310721,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadObjectIdentifier","d":651118,"h":55835225966,"f":16777217},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadOctetString","d":651118,"h":60130193262,"f":16777217},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadOctetString","d":651118,"h":64425160558,"f":16777217},{"r":262145,"p":[{"n":"contents","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadPrimitiveOctetString","d":651118,"h":68720127854,"f":16777217},{"r":262145,"p":[{"n":"expectedTag","p":126830},{"n":"contents","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,"f":2}],"n":"TryReadPrimitiveCharacterStringBytes","d":651118,"h":73015095150,"f":16777217},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"expectedTag","p":126830},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryReadCharacterStringBytes","d":651118,"h":77310062446,"f":16777217},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"encodingType","p":1634158},{"n":"charsWritten","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadCharacterString","d":651118,"h":81605029742,"f":16777217},{"r":1310721,"p":[{"n":"encodingType","p":1634158},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadCharacterString","d":651118,"h":85899997038,"f":16777217},{"r":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadIntegerBytes","d":651118,"h":90194964334,"f":16777217},{"r":846197,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadInteger","d":651118,"h":94489931630,"f":16777217},{"r":262145,"p":[{"n":"value","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadInt32","d":651118,"h":98784898926,"f":16777217},{"r":262145,"p":[{"n":"value","p":720897,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadUInt32","d":651118,"h":103079866222,"f":16777217,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"r":262145,"p":[{"n":"value","p":917505,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadInt64","d":651118,"h":107374833518,"f":16777217},{"r":262145,"p":[{"n":"value","p":983041,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadUInt64","d":651118,"h":111669800814,"f":16777217,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"r":34471937,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadUtcTime","o":"@$1","d":651118,"h":115964768110,"f":16777217},{"r":34471937,"p":[{"n":"twoDigitYearMax","p":655361},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadUtcTime","d":651118,"h":120259735406,"f":16777217},{"r":65537,"n":"ThrowIfNotEmpty","d":651118,"h":163209408366,"f":16777217},{"r":126830,"n":"PeekTag","d":651118,"h":167504375662,"f":16777217},{"r":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,"n":"PeekEncodedValue","d":651118,"h":171799342958,"f":16777217},{"r":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,"n":"PeekContentBytes","d":651118,"h":176094310254,"f":16777217},{"r":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,"n":"ReadEncodedValue","d":651118,"h":180389277550,"f":16777217},{"r":651118,"n":"Clone","d":651118,"h":184684244846,"f":16777217},{"r":651118,"p":[{"n":"start","p":655361},{"n":"length","p":655361}],"n":"CloneAtSlice","d":651118,"h":188979212142,"f":16777218},{"r":262145,"p":[{"n":"unusedBitCount","p":655361,"f":2},{"n":"value","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadPrimitiveBitString","d":651118,"h":193274179438,"f":16777217},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"unusedBitCount","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadBitString","d":651118,"h":197569146734,"f":16777217},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"unusedBitCount","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadBitString","d":651118,"h":201864114030,"f":16777217}],"l":[{"t":655361,"n":"MaxCERSegmentSize","d":651118,"h":124554702702,"f":4194344},{"t":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,"n":"_data","d":651118,"h":128849669998,"f":4194306},{"t":716654,"n":"_options","d":651118,"h":133144637294,"f":4194306}],"c":[{"p":[{"n":"data","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"ruleSet","p":585582},{"n":"options","p":716654,"f":65}],"n":".ctor","o":"$ctor$1","d":651118,"h":158914441070,"f":16777217}],"h":651118}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.AsnReader`; }
        });
        
        $asm.$cls("$sfa.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$sfa.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Formats.Asn1", $.$sfa.System.SR.$type.Assembly);
                    $.$sfa.System.SR.s_resourceManager = temp;
                }
                return $.$sfa.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sfa.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sfa.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_DestinationTooShort()
            {
                return "Destination is too short.";
            }
            static /*string */ get Argument_EnumeratedValueRequiresNonFlagsEnum()
            {
                return "ASN.1 Enumerated values only apply to enum types without the [Flags] attribute.";
            }
            static /*string */ get Argument_EnumeratedValueBackingTypeNotSupported()
            {
                return "Enumerations with a backing type of '{0}' are not supported for ReadEnumeratedValue.";
            }
            static /*string */ FormatArgument_EnumeratedValueBackingTypeNotSupported(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Enumerations with a backing type of '{0}' are not supported for ReadEnumeratedValue.", arg1);
            }
            static /*string */ get Argument_InvalidOidValue()
            {
                return "The OID value is invalid.";
            }
            static /*string */ get Argument_NamedBitListRequiresFlagsEnum()
            {
                return "Named bit list operations require an enum with the [Flags] attribute.";
            }
            static /*string */ get Argument_SourceOverlapsDestination()
            {
                return "The destination buffer overlaps the source buffer.";
            }
            static /*string */ get Argument_Tag_NotCharacterString()
            {
                return "The specified tag has the Universal TagClass, but the TagValue does not correspond with a known character string type.";
            }
            static /*string */ get Argument_IntegerCannotBeEmpty()
            {
                return "An integer value cannot be empty.";
            }
            static /*string */ get Argument_IntegerRedundantByte()
            {
                return "The first 9 bits of the integer value all have the same value. Ensure the input is in big-endian byte order and that all redundant leading bytes have been removed.";
            }
            static /*string */ get Argument_UniversalValueIsFixed()
            {
                return "Tags with TagClass Universal must have the appropriate TagValue value for the data type being read or written.";
            }
            static /*string */ get Argument_UnusedBitCountMustBeZero()
            {
                return "Unused bit count must be 0 when the bit string is empty.";
            }
            static /*string */ get Argument_UnusedBitCountRange()
            {
                return "Unused bit count must be between 0 and 7, inclusive.";
            }
            static /*string */ get Argument_UnusedBitWasSet()
            {
                return "One or more of the bits covered by the provided unusedBitCount value is set. All unused bits must be cleared.";
            }
            static /*string */ get Argument_WriteEncodedValue_OneValueAtATime()
            {
                return "The input to WriteEncodedValue must represent a single encoded value with no trailing data.";
            }
            static /*string */ get ArgumentOutOfRange_NeedNonNegNum()
            {
                return "Non-negative number required.";
            }
            static /*string */ get AsnWriter_EncodeUnbalancedStack()
            {
                return "Encode cannot be called while a Sequence, Set-Of, or Octet String is still open.";
            }
            static /*string */ get AsnWriter_ModifyingWhileEncoding()
            {
                return "The AsnWriter cannot be written to while performing the Encode callback.";
            }
            static /*string */ get AsnWriter_PopWrongTag()
            {
                return "Cannot pop the requested tag as it is not currently in progress.";
            }
            static /*string */ get ContentException_CerRequiresIndefiniteLength()
            {
                return "A constructed tag used a definite length encoding, which is invalid for CER data. The input may be encoded with BER or DER.";
            }
            static /*string */ get ContentException_ConstructedEncodingRequired()
            {
                return "The encoded value uses a primitive encoding, which is invalid for '{0}' values.";
            }
            static /*string */ FormatContentException_ConstructedEncodingRequired(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The encoded value uses a primitive encoding, which is invalid for '{0}' values.", arg1);
            }
            static /*string */ get ContentException_DefaultMessage()
            {
                return "The ASN.1 value is invalid.";
            }
            static /*string */ get ContentException_EnumeratedValueTooBig()
            {
                return "The encoded enumerated value is larger than the value size of the '{0}' enum.";
            }
            static /*string */ FormatContentException_EnumeratedValueTooBig(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The encoded enumerated value is larger than the value size of the '{0}' enum.", arg1);
            }
            static /*string */ get ContentException_InvalidUnderCer_TryBerOrDer()
            {
                return "The encoded value is not valid under the selected encoding, but it may be valid under the BER or DER encoding.";
            }
            static /*string */ get ContentException_InvalidUnderCerOrDer_TryBer()
            {
                return "The encoded value is not valid under the selected encoding, but it may be valid under the BER encoding.";
            }
            static /*string */ get ContentException_InvalidUnderDer_TryBerOrCer()
            {
                return "The encoded value is not valid under the selected encoding, but it may be valid under the BER or CER encoding.";
            }
            static /*string */ get ContentException_InvalidTag()
            {
                return "The provided data does not represent a valid tag.";
            }
            static /*string */ get ContentException_LengthExceedsPayload()
            {
                return "The encoded length exceeds the number of bytes remaining in the input buffer.";
            }
            static /*string */ get ContentException_LengthRuleSetConstraint()
            {
                return "The encoded length is not valid under the requested encoding rules, the value may be valid under the BER encoding.";
            }
            static /*string */ get ContentException_LengthTooBig()
            {
                return "The encoded length exceeds the maximum supported by this library (Int32.MaxValue).";
            }
            static /*string */ get ContentException_NamedBitListValueTooBig()
            {
                return "The encoded named bit list value is larger than the value size of the '{0}' enum.";
            }
            static /*string */ FormatContentException_NamedBitListValueTooBig(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The encoded named bit list value is larger than the value size of the '{0}' enum.", arg1);
            }
            static /*string */ get ContentException_OidTooBig()
            {
                return "The encoded object identifier (OID) exceeds the limits supported by this library. Supported OIDs are limited to 64 arcs and each subidentifier is limited to a 128-bit value.";
            }
            static /*string */ get ContentException_PrimitiveEncodingRequired()
            {
                return "The encoded value uses a constructed encoding, which is invalid for '{0}' values.";
            }
            static /*string */ FormatContentException_PrimitiveEncodingRequired(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The encoded value uses a constructed encoding, which is invalid for '{0}' values.", arg1);
            }
            static /*string */ get ContentException_SetOfNotSorted()
            {
                return "The encoded set is not sorted as required by the current encoding rules. The value may be valid under the BER encoding, or you can ignore the sort validation by specifying skipSortValidation=true.";
            }
            static /*string */ get ContentException_TooMuchData()
            {
                return "The last expected value has been read, but the reader still has pending data. This value may be from a newer schema, or is corrupt.";
            }
            static /*string */ get ContentException_WrongTag()
            {
                return "The provided data is tagged with '{0}' class value '{1}', but it should have been '{2}' class value '{3}'.";
            }
            static /*string */ FormatContentException_WrongTag(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                return $.$$.System.String.Format$11("The provided data is tagged with '{0}' class value '{1}', but it should have been '{2}' class value '{3}'.", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ arg1, arg2, arg3, arg4 ]));
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sfa.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sfa.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sfa.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sfa.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sfa.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sfa.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2027374;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2027374}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.AsnWriter", ($self) => class AsnWriter extends $.$$.System.Object
        {
            /*void */ WriteBitString(/*ReadOnlySpan<byte>*/ value, /*int*/ unusedBitCount, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 3/*UniversalTagNumber.BitString*/);
                this.WriteBitStringCore(tag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString, value, unusedBitCount);
            }
            /*void */ WriteBitStringCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ bitString, /*int*/ unusedBitCount)
            {
                if (unusedBitCount < 0 || unusedBitCount > 7)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("unusedBitCount", $.$box(unusedBitCount, $.$$.System.Int32), $.$sfa.System.SR.Argument_UnusedBitCountRange);
                }
                if (bitString.Length === 0 && unusedBitCount !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_UnusedBitCountMustBeZero, "unusedBitCount");
                }
                /*byte*/ let lastByte = bitString.IsEmpty ? 0 : bitString.get_Item(((bitString.Length - 1) | 0)).$v;
                if (!$.$sfa.System.Formats.Asn1.AsnWriter.CheckValidLastByte(lastByte, unusedBitCount))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_UnusedBitWasSet, "unusedBitCount");
                }
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (bitString.Length >= 1000/*AsnReader.MaxCERSegmentSize*/)
                    {
                        this.WriteConstructedCerBitString(tag, bitString, unusedBitCount);
                        return;
                    }
                }
                this.WriteTag(tag.AsPrimitive());
                this.WriteLength(((bitString.Length + 1) | 0));
                $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(unusedBitCount, $.$$.System.Byte), this._offset);
                this._offset++;
                bitString.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset));
                this._offset += bitString.Length;
            }
            static /*bool */ CheckValidLastByte(/*byte*/ lastByte, /*int*/ unusedBitCount)
            {
                /*int*/ let mask = (((1 << unusedBitCount) - 1) | 0);
                return ((lastByte & mask) === 0);
            }
            static /*int */ DetermineCerBitStringTotalLength(/*Asn1Tag*/ tag, /*int*/ contentLength)
            {
                /*int*/ let MaxCERSegmentSize = 1000/*AsnReader.MaxCERSegmentSize*/;
                /*int*/ let MaxCERContentSize = ((MaxCERSegmentSize - 1) | 0);
                $.$$.System.Diagnostics.Debug.Assert$2(contentLength > MaxCERContentSize, "contentLength > MaxCERContentSize");
                /*int*/ let lastContentSize;
                /*int*/ let fullSegments = $.$$.System.Math.DivRem$2(contentLength, MaxCERContentSize, $.$ref(() => lastContentSize, ($v) => lastContentSize = $v, $.$$.System.Int32));
                /*int*/ let FullSegmentEncodedSize = 1004;
                $.$$.System.Diagnostics.Debug.Assert$2(FullSegmentEncodedSize === ((((((1 + 1) | 0) + MaxCERSegmentSize) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)) | 0), "FullSegmentEncodedSize == 1 + 1 + MaxCERSegmentSize + GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)");
                /*int*/ let remainingEncodedSize;
                if (lastContentSize === 0)
                {
                    remainingEncodedSize = 0;
                }
                else 
                {
                    remainingEncodedSize = ((((3 + lastContentSize) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(lastContentSize)) | 0);
                }
                return ((((((((fullSegments * FullSegmentEncodedSize) | 0) + remainingEncodedSize) | 0) + 3) | 0) + tag.CalculateEncodedSize()) | 0);
            }
            /*void */ WriteConstructedCerBitString(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ payload, /*int*/ unusedBitCount)
            {
                /*int*/ let MaxCERSegmentSize = 1000/*AsnReader.MaxCERSegmentSize*/;
                /*int*/ let MaxCERContentSize = ((MaxCERSegmentSize - 1) | 0);
                $.$$.System.Diagnostics.Debug.Assert$2(payload.Length > MaxCERContentSize, "payload.Length > MaxCERContentSize");
                /*int*/ let expectedSize = $.$sfa.System.Formats.Asn1.AsnWriter.DetermineCerBitStringTotalLength(tag, payload.Length);
                this.EnsureWriteCapacity(expectedSize);
                /*int*/ let savedOffset = this._offset;
                this.WriteTag(tag.AsConstructed());
                this.WriteLength(-1);
                /*byte[]*/ let ensureNoExtraCopy = this._buffer;
                /*ReadOnlySpan<byte>*/ let remainingData = payload;
                /*Span<byte>*/ let dest;
                /*Asn1Tag*/ let primitiveBitString = $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString;
                while(remainingData.Length > MaxCERContentSize)
                {
                    this.WriteTag(primitiveBitString);
                    this.WriteLength(MaxCERSegmentSize);
                    $.$$.System.Array.$WriteT1.call(this._buffer, 0, this._offset);
                    this._offset++;
                    dest = $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset);
                    remainingData.Slice(0, MaxCERContentSize).CopyTo(dest);
                    remainingData = remainingData.Slice$1(MaxCERContentSize);
                    this._offset += MaxCERContentSize;
                }
                this.WriteTag(primitiveBitString);
                this.WriteLength(((remainingData.Length + 1) | 0));
                $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(unusedBitCount, $.$$.System.Byte), this._offset);
                this._offset++;
                dest = $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset);
                remainingData.CopyTo(dest);
                this._offset += remainingData.Length;
                this.WriteEndOfContents();
                $.$$.System.Diagnostics.Debug.Assert$4(((this._offset - savedOffset) | 0) === expectedSize, `expected size was ${expectedSize}, actual was ${((this._offset - savedOffset) | 0)}`);
                $.$$.System.Diagnostics.Debug.Assert$2(this._buffer === ensureNoExtraCopy, `_buffer was replaced during ${"WriteConstructedCerBitString"}`);
            }
            /*void */ WriteNamedBitList$1(/*Enum*/ value, /*Asn1Tag?*/ tag)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 3/*UniversalTagNumber.BitString*/);
                this.WriteNamedBitList$2(tag?.Clone() ?? null, $.$$.System.Object.GetType.call(value), value);
            }
            /*void */ WriteNamedBitList$4(TEnum, /*TEnum*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 3/*UniversalTagNumber.BitString*/);
                this.WriteNamedBitList$2(tag?.Clone() ?? null, TEnum.$type, value);
            }
            /*void */ WriteNamedBitList(/*BitArray*/ value, /*Asn1Tag?*/ tag)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 3/*UniversalTagNumber.BitString*/);
                this.WriteBitArray(value, tag?.Clone() ?? null);
            }
            /*void */ WriteNamedBitList$2(/*Asn1Tag?*/ tag, /*Type*/ tEnum, /*Enum*/ value)
            {
                /*Type*/ let backingType = tEnum.GetEnumUnderlyingType();
                if (!tEnum.IsDefined($.$$.System.FlagsAttribute.$type, false))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_NamedBitListRequiresFlagsEnum, "tEnum");
                }
                /*ulong*/ let integralValue;
                if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.SByte.$type))
                {
                    integralValue = BigInt($.$cast($.$$.System.Convert.ToSByte$10(value), $.$$.System.Byte));
                }
                else if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.Int16.$type))
                {
                    integralValue = BigInt($.$cast($.$$.System.Convert.ToInt16$10(value), $.$$.System.UInt16));
                }
                else if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.Int32.$type))
                {
                    integralValue = BigInt(($.$$.System.Convert.ToInt32$10(value) >>> 0));
                }
                else if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.UInt64.$type))
                {
                    integralValue = $.$$.System.Convert.ToUInt64$10(value);
                }
                else 
                {
                    integralValue = $.$cast($.$$.System.Convert.ToInt64$10(value), $.$$.System.UInt64);
                }
                this.WriteNamedBitList$3(tag?.Clone() ?? null, integralValue);
            }
            /*void */ WriteNamedBitList$3(/*Asn1Tag?*/ tag, /*ulong*/ integralValue)
            {
                /*Span<byte>*/ let temp = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, $.$$.System.UInt64.$z, null);
                temp.Clear();
                /*int*/ let indexOfHighestSetBit = -1;
                for(/*int*/ let i = 0; integralValue !== 0n; integralValue >>= 1n, i++)
                {
                    if ((integralValue & 1n) !== 0n)
                    {
                        temp.get_Item($.trunc(i / 8)).$v |= $.$cast((128 >> (i % 8)), $.$$.System.Byte);
                        indexOfHighestSetBit = i;
                    }
                }
                if (indexOfHighestSetBit < 0)
                {
                    this.WriteBitString($.$$.System.ReadOnlySpan$$($.$$.System.Byte).Empty, 0, tag?.Clone() ?? null);
                }
                else 
                {
                    /*int*/ let byteLen = ((($.trunc(indexOfHighestSetBit / 8)) + 1) | 0);
                    /*int*/ let unusedBitCount = ((7 - (indexOfHighestSetBit % 8)) | 0);
                    this.WriteBitString($.$$.System.Span$$($.$$.System.Byte).op_Implicit(temp.Slice(0, byteLen)), unusedBitCount, tag?.Clone() ?? null);
                }
            }
            /*void */ WriteBitArray(/*BitArray*/ value, /*Asn1Tag?*/ tag)
            {
                if (value.Count === 0)
                {
                    this.WriteBitString($.$$.System.ReadOnlySpan$$($.$$.System.Byte).Empty, 0, tag?.Clone() ?? null);
                    return;
                }
                /*int*/ let requiredBytes = $.trunc(($.$checked(value.Count + 7, 1)) / 8);
                /*int*/ let unusedBits = ((((requiredBytes * 8) | 0) - value.Count) | 0);
                /*byte[]*/ let rented = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(requiredBytes);
                value.CopyTo(rented, 0);
                /*Span<byte>*/ let valueSpan = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, rented, 0, requiredBytes);
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReverseBitsPerByte(valueSpan);
                this.WriteBitString($.$$.System.Span$$($.$$.System.Byte).op_Implicit(valueSpan), unusedBits, tag?.Clone() ?? null);
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, requiredBytes);
            }
            /*void */ WriteCharacterString$1(/*UniversalTagNumber*/ encodingType, /*string*/ value, /*Asn1Tag?*/ tag)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.WriteCharacterString(encodingType, $.$$.System.MemoryExtensions.AsSpan$4(value), tag?.Clone() ?? null);
            }
            /*void */ WriteCharacterString(/*UniversalTagNumber*/ encodingType, /*ReadOnlySpan<char>*/ str, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, encodingType);
                /*Text.Encoding*/ let encoding = $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.GetEncoding(encodingType);
                this.WriteCharacterStringCore(tag ?? new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$5(encodingType, false), encoding, str);
            }
            /*void */ WriteCharacterStringCore(/*Asn1Tag*/ tag, /*Text.Encoding*/ encoding, /*ReadOnlySpan<char>*/ str)
            {
                /*int*/ let size = encoding.GetByteCount$4(str);
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (size > 1000/*AsnReader.MaxCERSegmentSize*/)
                    {
                        this.WriteConstructedCerCharacterString(tag, encoding, str, size);
                        return;
                    }
                }
                this.WriteTag(tag.AsPrimitive());
                this.WriteLength(size);
                /*Span<byte>*/ let dest = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, this._offset, size);
                /*int*/ let written = encoding.GetBytes$5(str, dest);
                if (written !== size)
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`Encoding produced different answer for GetByteCount (${size}) and GetBytes (${written})`);
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                this._offset += size;
            }
            /*void */ WriteConstructedCerCharacterString(/*Asn1Tag*/ tag, /*Text.Encoding*/ encoding, /*ReadOnlySpan<char>*/ str, /*int*/ size)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(size > 1000/*AsnReader.MaxCERSegmentSize*/, "size > AsnReader.MaxCERSegmentSize");
                /*byte[]*/ let tmp = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(size);
                /*int*/ let written = encoding.GetBytes$5(str, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(tmp));
                if (written !== size)
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`Encoding produced different answer for GetByteCount (${size}) and GetBytes (${written})`);
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                this.WriteConstructedCerOctetString(tag, $.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, tmp, 0, size)));
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(tmp, size);
            }
            /*void */ WriteBoolean(/*bool*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 1/*UniversalTagNumber.Boolean*/);
                this.WriteBooleanCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Boolean, value);
            }
            /*void */ WriteBooleanCore(/*Asn1Tag*/ tag, /*bool*/ value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(1);
                $.$$.System.Diagnostics.Debug.Assert$2(this._offset < this._buffer.length, "_offset < _buffer.Length");
                $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast((value ? 255 : 0), $.$$.System.Byte), this._offset);
                this._offset++;
            }
            /*void */ WriteNull(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 5/*UniversalTagNumber.Null*/);
                this.WriteNullCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Null);
            }
            /*void */ WriteNullCore(/*Asn1Tag*/ tag)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(0);
            }
            /*Scope */ PushSequence(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 16/*UniversalTagNumber.Sequence*/);
                return this.PushSequenceCore((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Sequence);
            }
            /*void */ PopSequence(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 16/*UniversalTagNumber.Sequence*/);
                this.PopSequenceCore((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Sequence);
            }
            /*Scope */ PushSequenceCore(/*Asn1Tag*/ tag)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tag.IsConstructed, "tag.IsConstructed");
                return this.PushTag(tag, 16/*UniversalTagNumber.Sequence*/);
            }
            /*void */ PopSequenceCore(/*Asn1Tag*/ tag)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tag.IsConstructed, "tag.IsConstructed");
                this.PopTag(tag, 16/*UniversalTagNumber.Sequence*/, false);
            }
            /*Scope */ PushSetOf(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 17/*UniversalTagNumber.SetOf*/);
                return this.PushSetOfCore((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.SetOf);
            }
            /*void */ PopSetOf(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 17/*UniversalTagNumber.SetOf*/);
                this.PopSetOfCore((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.SetOf);
            }
            /*Scope */ PushSetOfCore(/*Asn1Tag*/ tag)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tag.IsConstructed, "tag.IsConstructed");
                return this.PushTag(tag, 17/*UniversalTagNumber.SetOf*/);
            }
            /*void */ PopSetOfCore(/*Asn1Tag*/ tag)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(tag.IsConstructed, "tag.IsConstructed");
                /*bool*/ let sortContents = this.RuleSet === 1/*AsnEncodingRules.CER*/ || this.RuleSet === 2/*AsnEncodingRules.DER*/;
                this.PopTag(tag, 17/*UniversalTagNumber.SetOf*/, sortContents);
            }
            /*Scope */ PushOctetString(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 4/*UniversalTagNumber.OctetString*/);
                return this.PushTag((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedOctetString, 4/*UniversalTagNumber.OctetString*/);
            }
            /*void */ PopOctetString(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 4/*UniversalTagNumber.OctetString*/);
                this.PopTag((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedOctetString, 4/*UniversalTagNumber.OctetString*/, false);
            }
            /*void */ WriteOctetString(/*ReadOnlySpan<byte>*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 4/*UniversalTagNumber.OctetString*/);
                this.WriteOctetStringCore(tag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString, value);
            }
            /*void */ WriteOctetStringCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ octetString)
            {
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (octetString.Length > 1000/*AsnReader.MaxCERSegmentSize*/)
                    {
                        this.WriteConstructedCerOctetString(tag, octetString);
                        return;
                    }
                }
                this.WriteTag(tag.AsPrimitive());
                this.WriteLength(octetString.Length);
                octetString.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset));
                this._offset += octetString.Length;
            }
            /*void */ WriteConstructedCerOctetString(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ payload)
            {
                /*int*/ let MaxCERSegmentSize = 1000/*AsnReader.MaxCERSegmentSize*/;
                $.$$.System.Diagnostics.Debug.Assert$2(payload.Length > MaxCERSegmentSize, "payload.Length > MaxCERSegmentSize");
                this.WriteTag(tag.AsConstructed());
                this.WriteLength(-1);
                /*int*/ let lastSegmentSize;
                /*int*/ let fullSegments = $.$$.System.Math.DivRem$2(payload.Length, MaxCERSegmentSize, $.$ref(() => lastSegmentSize, ($v) => lastSegmentSize = $v, $.$$.System.Int32));
                /*int*/ let FullSegmentEncodedSize = 1004;
                $.$$.System.Diagnostics.Debug.Assert$2(FullSegmentEncodedSize === ((((((1 + 1) | 0) + MaxCERSegmentSize) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)) | 0), "FullSegmentEncodedSize == 1 + 1 + MaxCERSegmentSize + GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)");
                /*int*/ let remainingEncodedSize;
                if (lastSegmentSize === 0)
                {
                    remainingEncodedSize = 0;
                }
                else 
                {
                    remainingEncodedSize = ((((2 + lastSegmentSize) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(lastSegmentSize)) | 0);
                }
                /*int*/ let expectedSize = ((((((fullSegments * FullSegmentEncodedSize) | 0) + remainingEncodedSize) | 0) + 2) | 0);
                this.EnsureWriteCapacity(expectedSize);
                /*byte[]*/ let ensureNoExtraCopy = this._buffer;
                /*int*/ let savedOffset = this._offset;
                /*ReadOnlySpan<byte>*/ let remainingData = payload;
                /*Span<byte>*/ let dest;
                /*Asn1Tag*/ let primitiveOctetString = $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString;
                while(remainingData.Length > MaxCERSegmentSize)
                {
                    this.WriteTag(primitiveOctetString);
                    this.WriteLength(MaxCERSegmentSize);
                    dest = $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset);
                    remainingData.Slice(0, MaxCERSegmentSize).CopyTo(dest);
                    this._offset += MaxCERSegmentSize;
                    remainingData = remainingData.Slice$1(MaxCERSegmentSize);
                }
                this.WriteTag(primitiveOctetString);
                this.WriteLength(remainingData.Length);
                dest = $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset);
                remainingData.CopyTo(dest);
                this._offset += remainingData.Length;
                this.WriteEndOfContents();
                $.$$.System.Diagnostics.Debug.Assert$4(((this._offset - savedOffset) | 0) === expectedSize, `expected size was ${expectedSize}, actual was ${((this._offset - savedOffset) | 0)}`);
                $.$$.System.Diagnostics.Debug.Assert$2(this._buffer === ensureNoExtraCopy, `_buffer was replaced during ${"WriteConstructedCerOctetString"}`);
            }
            /*void */ WriteUtcTime$1(/*DateTimeOffset*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 23/*UniversalTagNumber.UtcTime*/);
                this.WriteUtcTimeCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.UtcTime, value);
            }
            /*void */ WriteUtcTime(/*DateTimeOffset*/ value, /*int*/ twoDigitYearMax, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 23/*UniversalTagNumber.UtcTime*/);
                value = value.ToUniversalTime();
                if (value.Year > twoDigitYearMax || value.Year <= ((twoDigitYearMax - 100) | 0))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("value");
                }
                this.WriteUtcTimeCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.UtcTime, value);
            }
            /*void */ WriteUtcTimeCore(/*Asn1Tag*/ tag, /*DateTimeOffset*/ value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                /*int*/ let UtcTimeValueLength = 13;
                this.WriteLength(UtcTimeValueLength);
                /*DateTimeOffset*/ let normalized = value.ToUniversalTime();
                /*int*/ let year = normalized.Year;
                /*int*/ let month = normalized.Month;
                /*int*/ let day = normalized.Day;
                /*int*/ let hour = normalized.Hour;
                /*int*/ let minute = normalized.Minute;
                /*int*/ let second = normalized.Second;
                /*Span<byte>*/ let baseSpan = $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset);
                /*StandardFormat*/ let format = new $.$$.System.Buffers.StandardFormat().$ctor$3(/*D*/ 68, 2);
                if (!$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(year % 100, baseSpan.Slice(0, 2), $.$discardRef(), format) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(month, baseSpan.Slice(2, 2), $.$discardRef(), format) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(day, baseSpan.Slice(4, 2), $.$discardRef(), format) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(hour, baseSpan.Slice(6, 2), $.$discardRef(), format) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(minute, baseSpan.Slice(8, 2), $.$discardRef(), format) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(second, baseSpan.Slice(10, 2), $.$discardRef(), format))
                {
                    $.$$.System.Diagnostics.Debug.Fail$1((() =>
                    {
                        var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendLiteral("Utf8Formatter.TryFormat failed to build components of ");
                        $handler.AppendFormatted($.$box(normalized, $.$$.System.DateTimeOffset), null, "O");
                        return $handler.ToStringAndClear                ();
                    })());
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                $.$$.System.Array.$WriteT1.call(this._buffer, /*Z*/ 90, ((this._offset + 12) | 0));
                this._offset += UtcTimeValueLength;
            }
            /*void */ WriteEnumeratedValue(/*Enum*/ value, /*Asn1Tag?*/ tag)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.WriteEnumeratedValue$1((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Enumerated, $.$$.System.Object.GetType.call(value), value);
            }
            /*void */ WriteEnumeratedValue$2(TEnum, /*TEnum*/ value, /*Asn1Tag?*/ tag)
            {
                this.WriteEnumeratedValue$1((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Enumerated, TEnum.$type, $.$box(value, TEnum));
            }
            /*void */ WriteEnumeratedValue$1(/*Asn1Tag*/ tag, /*Type*/ tEnum, /*object*/ value)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag, 10/*UniversalTagNumber.Enumerated*/);
                /*Type*/ let backingType = tEnum.GetEnumUnderlyingType();
                if (tEnum.IsDefined($.$$.System.FlagsAttribute.$type, false))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_EnumeratedValueRequiresNonFlagsEnum, "tEnum");
                }
                if ($.$$.System.Type.op_Equality$1(backingType, $.$$.System.UInt64.$type))
                {
                    /*ulong*/ let numericValue = $.$$.System.Convert.ToUInt64$10(value);
                    this.WriteNonNegativeIntegerCore(tag, numericValue);
                }
                else 
                {
                    /*long*/ let numericValue = $.$$.System.Convert.ToInt64$10(value);
                    this.WriteIntegerCore(tag, numericValue);
                }
            }
            /*void */ WriteGeneralizedTime(/*DateTimeOffset*/ value, /*bool*/ omitFractionalSeconds, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 24/*UniversalTagNumber.GeneralizedTime*/);
                this.WriteGeneralizedTimeCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.GeneralizedTime, value, omitFractionalSeconds);
            }
            /*void */ WriteGeneralizedTimeCore(/*Asn1Tag*/ tag, /*DateTimeOffset*/ value, /*bool*/ omitFractionalSeconds)
            {
                /*DateTimeOffset*/ let normalized = value.ToUniversalTime();
                $.$$.System.Diagnostics.Debug.Assert$2(normalized.Year <= 9999, "DateTimeOffset guards against this internally");
                /*scoped Span<byte>*/ let fraction = new ($.$$.System.Span$$($.$$.System.Byte))();
                if (!omitFractionalSeconds)
                {
                    /*long*/ let floatingTicks = normalized.Ticks % 10000000n;
                    if (floatingTicks !== 0n)
                    {
                        fraction = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 9, null);
                        /*decimal*/ let decimalTicks = $.$$.System.Decimal.op_Implicit$4(floatingTicks);
                        decimalTicks = $.$$.System.Decimal.op_Division(decimalTicks, $.$$.System.Decimal.op_Implicit$4(10000000n));
                        /*int*/ let bytesWritten;
                        if (!$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$4(decimalTicks, fraction, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32), new $.$$.System.Buffers.StandardFormat().$ctor$3(/*G*/ 71, 255)))
                        {
                            $.$$.System.Diagnostics.Debug.Fail$1(`Utf8Formatter.TryFormat could not format ${floatingTicks} / TicksPerSecond`);
                            throw new $.$$.System.InvalidOperationException().$ctor$9();
                        }
                        $.$$.System.Diagnostics.Debug.Assert$4(bytesWritten > 2, `${bytesWritten} should be > 2`);
                        $.$$.System.Diagnostics.Debug.Assert$2(fraction.get_Item(0).$v === /*0*/ 48, "fraction[0] == (byte)'0'");
                        $.$$.System.Diagnostics.Debug.Assert$2(fraction.get_Item(1).$v === /*.*/ 46, "fraction[1] == (byte)'.'");
                        fraction = fraction.Slice(1, ((bytesWritten - 1) | 0));
                    }
                }
                /*int*/ let IntegerPortionLength = ((((((((((4 + 2) | 0) + 2) | 0) + 2) | 0) + 2) | 0) + 2) | 0);
                /*int*/ let totalLength = ((((IntegerPortionLength + 1) | 0) + fraction.Length) | 0);
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(totalLength);
                /*int*/ let year = normalized.Year;
                /*int*/ let month = normalized.Month;
                /*int*/ let day = normalized.Day;
                /*int*/ let hour = normalized.Hour;
                /*int*/ let minute = normalized.Minute;
                /*int*/ let second = normalized.Second;
                /*Span<byte>*/ let baseSpan = $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset);
                /*StandardFormat*/ let d4 = new $.$$.System.Buffers.StandardFormat().$ctor$3(/*D*/ 68, 4);
                /*StandardFormat*/ let d2 = new $.$$.System.Buffers.StandardFormat().$ctor$3(/*D*/ 68, 2);
                if (!$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(year, baseSpan.Slice(0, 4), $.$discardRef(), d4) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(month, baseSpan.Slice(4, 2), $.$discardRef(), d2) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(day, baseSpan.Slice(6, 2), $.$discardRef(), d2) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(hour, baseSpan.Slice(8, 2), $.$discardRef(), d2) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(minute, baseSpan.Slice(10, 2), $.$discardRef(), d2) || !$.$$.System.Buffers.Text.Utf8Formatter.TryFormat$9(second, baseSpan.Slice(12, 2), $.$discardRef(), d2))
                {
                    $.$$.System.Diagnostics.Debug.Fail$1((() =>
                    {
                        var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendLiteral("Utf8Formatter.TryFormat failed to build components of ");
                        $handler.AppendFormatted($.$box(normalized, $.$$.System.DateTimeOffset), null, "O");
                        return $handler.ToStringAndClear                ();
                    })());
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                this._offset += IntegerPortionLength;
                fraction.CopyTo(baseSpan.Slice$1(IntegerPortionLength));
                this._offset += fraction.Length;
                $.$$.System.Array.$WriteT1.call(this._buffer, /*Z*/ 90, this._offset);
                this._offset++;
            }
            /*void */ WriteInteger(/*long*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            /*void */ WriteInteger$2(/*ulong*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 2/*UniversalTagNumber.Integer*/);
                this.WriteNonNegativeIntegerCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            /*void */ WriteInteger$3(/*BigInteger*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerCore$2((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            /*void */ WriteInteger$1(/*ReadOnlySpan<byte>*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerCore$1((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            /*void */ WriteIntegerUnsigned(/*ReadOnlySpan<byte>*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerUnsignedCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            /*void */ WriteIntegerCore(/*Asn1Tag*/ tag, /*long*/ value)
            {
                if (value >= 0n)
                {
                    this.WriteNonNegativeIntegerCore(tag, $.$cast(value, $.$$.System.UInt64));
                    return;
                }
                /*int*/ let valueLength;
                if (value >= BigInt(-128/*sbyte.MinValue*/))
                {
                    valueLength = 1;
                }
                else if (value >= BigInt(-32768/*short.MinValue*/))
                {
                    valueLength = 2;
                }
                else if (value >= $.$cast(18446744073701163008n, $.$$.System.Int64))
                {
                    valueLength = 3;
                }
                else if (value >= BigInt(-2147483648/*int.MinValue*/))
                {
                    valueLength = 4;
                }
                else if (value >= $.$cast(18446743523953737728n, $.$$.System.Int64))
                {
                    valueLength = 5;
                }
                else if (value >= $.$cast(18446603336221196288n, $.$$.System.Int64))
                {
                    valueLength = 6;
                }
                else if (value >= $.$cast(18410715276690587648n, $.$$.System.Int64))
                {
                    valueLength = 7;
                }
                else 
                {
                    valueLength = 8;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(valueLength);
                /*long*/ let remaining = value;
                /*int*/ let idx = ((((this._offset + valueLength) | 0) - 1) | 0);
                do
                {
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(remaining, $.$$.System.Byte), idx);
                    remaining >>= 8n;
                    idx--;
                }
                while(idx >= this._offset);
                if (valueLength > 1)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Array.$ReadT1.call(this._buffer, this._offset) !== 255 || $.$$.System.Array.$ReadT1.call(this._buffer, ((this._offset + 1) | 0)) < 128, "_buffer[_offset] != 0xFF || _buffer[_offset + 1] < 0x80");
                }
                this._offset += valueLength;
            }
            /*void */ WriteNonNegativeIntegerCore(/*Asn1Tag*/ tag, /*ulong*/ value)
            {
                /*int*/ let valueLength;
                if (value < 128n)
                {
                    valueLength = 1;
                }
                else if (value < 32768n)
                {
                    valueLength = 2;
                }
                else if (value < 8388608n)
                {
                    valueLength = 3;
                }
                else if (value < 2147483648n)
                {
                    valueLength = 4;
                }
                else if (value < 549755813888n)
                {
                    valueLength = 5;
                }
                else if (value < 140737488355328n)
                {
                    valueLength = 6;
                }
                else if (value < 36028797018963968n)
                {
                    valueLength = 7;
                }
                else if (value < 9223372036854775808n)
                {
                    valueLength = 8;
                }
                else 
                {
                    valueLength = 9;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(valueLength);
                /*ulong*/ let remaining = value;
                /*int*/ let idx = ((((this._offset + valueLength) | 0) - 1) | 0);
                do
                {
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(remaining, $.$$.System.Byte), idx);
                    remaining >>= 8n;
                    idx--;
                }
                while(idx >= this._offset);
                if (valueLength > 1)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Array.$ReadT1.call(this._buffer, this._offset) !== 0 || $.$$.System.Array.$ReadT1.call(this._buffer, ((this._offset + 1) | 0)) > 127, "_buffer[_offset] != 0 || _buffer[_offset + 1] > 0x7F");
                }
                this._offset += valueLength;
            }
            /*void */ WriteIntegerUnsignedCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ value)
            {
                if (value.IsEmpty)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_IntegerCannotBeEmpty, "value");
                }
                if (value.Length > 1 && value.get_Item(0).$v === 0 && value.get_Item(1).$v < 128)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_IntegerRedundantByte, "value");
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                if (value.get_Item(0).$v >= 128)
                {
                    this.WriteLength($.$checked(value.Length + 1, 1));
                    $.$$.System.Array.$WriteT1.call(this._buffer, 0, this._offset);
                    this._offset++;
                }
                else 
                {
                    this.WriteLength(value.Length);
                }
                value.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset));
                this._offset += value.Length;
            }
            /*void */ WriteIntegerCore$1(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ value)
            {
                if (value.IsEmpty)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_IntegerCannotBeEmpty, "value");
                }
                /*ushort*/ let bigEndianValue;
                if ($.$$.System.Buffers.Binary.BinaryPrimitives.TryReadUInt16BigEndian(value, $.$ref(() => bigEndianValue, ($v) => bigEndianValue = $v, $.$$.System.UInt16)))
                {
                    /*ushort*/ let RedundancyMask = 65408;
                    /*ushort*/ let masked = $.$cast((bigEndianValue & RedundancyMask), $.$$.System.UInt16);
                    if (masked === 0 || masked === RedundancyMask)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_IntegerRedundantByte, "value");
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(value.Length);
                value.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset));
                this._offset += value.Length;
            }
            /*void */ WriteIntegerCore$2(/*Asn1Tag*/ tag, /*BigInteger*/ value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(value.GetByteCount(false));
                /*int*/ let bytesWritten;
                value.TryWriteBytes($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32), false, true);
                this._offset += bytesWritten;
            }
            /*void */ WriteObjectIdentifier$1(/*string*/ oidValue, /*Asn1Tag?*/ tag)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(oidValue, "oidValue");
                this.WriteObjectIdentifier($.$$.System.MemoryExtensions.AsSpan$4(oidValue), tag?.Clone() ?? null);
            }
            /*void */ WriteObjectIdentifier(/*ReadOnlySpan<char>*/ oidValue, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone() ?? null, 6/*UniversalTagNumber.ObjectIdentifier*/);
                /*ReadOnlySpan<byte>*/ let wellKnownContents = $.$sfa.System.Formats.Asn1.WellKnownOids.GetContents(oidValue);
                if (!wellKnownContents.IsEmpty)
                {
                    this.WriteTag((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ObjectIdentifier);
                    this.WriteLength(wellKnownContents.Length);
                    wellKnownContents.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset));
                    this._offset += wellKnownContents.Length;
                    return;
                }
                this.WriteObjectIdentifierCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ObjectIdentifier, oidValue);
            }
            /*void */ WriteObjectIdentifierCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<char>*/ oidValue)
            {
                if (oidValue.Length < 3)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                }
                if (oidValue.get_Item(1).$v !== /*.*/ 46)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                }
                /*byte[]*/ let tmp = $.$sfa.System.Security.Cryptography.CryptoPool.Rent($.trunc(oidValue.Length / 2));
                /*int*/ let tmpOffset = 0;
                try
                {
                    /*int*/ let firstComponent = (() =>
                    {
                        let $switch1 = oidValue.get_Item(0).$v;
                        if ($switch1 === /*0*/ 48)
                        {
                            return 0;
                        }
                        if ($switch1 === /*1*/ 49)
                        {
                            return 1;
                        }
                        if ($switch1 === /*2*/ 50)
                        {
                            return 2;
                        }
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                    })();
                    /*ReadOnlySpan<char>*/ let remaining = oidValue.Slice$1(2);
                    /*BigInteger*/ let subIdentifier = $.$sfa.System.Formats.Asn1.AsnWriter.ParseSubIdentifier($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Char), () => remaining, ($v) => remaining = $v, null));
                    if (firstComponent <= 1 && $.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual$2(subIdentifier, 40n))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                    }
                    subIdentifier = $.$srn.System.Numerics.BigInteger.op_Addition(subIdentifier, $.$srn.System.Numerics.BigInteger.op_Implicit$4(((40 * firstComponent) | 0)));
                    /*int*/ let localLen = $.$sfa.System.Formats.Asn1.AsnWriter.EncodeSubIdentifier($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, tmp, tmpOffset), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Numerics.BigInteger, () => subIdentifier, ($v) => subIdentifier = $v, null));
                    tmpOffset += localLen;
                    while(!remaining.IsEmpty)
                    {
                        subIdentifier = $.$sfa.System.Formats.Asn1.AsnWriter.ParseSubIdentifier($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.ReadOnlySpan$$($.$$.System.Char), () => remaining, ($v) => remaining = $v, null));
                        localLen = $.$sfa.System.Formats.Asn1.AsnWriter.EncodeSubIdentifier($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, tmp, tmpOffset), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Numerics.BigInteger, () => subIdentifier, ($v) => subIdentifier = $v, null));
                        tmpOffset += localLen;
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(!tag.IsConstructed, "!tag.IsConstructed");
                    this.WriteTag(tag);
                    this.WriteLength(tmpOffset);
                    $.$$.System.Buffer.BlockCopy(tmp, 0, this._buffer, this._offset, tmpOffset);
                    this._offset += tmpOffset;
                }
                finally
                {
                    {
                        $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(tmp, tmpOffset);
                    }
                }
            }
            static /*BigInteger */ ParseSubIdentifier(/*ref ReadOnlySpan<char>*/ oidValue)
            {
                /*int*/ let endIndex = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, oidValue.$v, /*.*/ 46);
                if (endIndex === -1)
                {
                    endIndex = oidValue.$v.Length;
                }
                else if (endIndex === 0 || endIndex === ((oidValue.$v.Length - 1) | 0))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                }
                /*BigInteger*/ let value = $.$srn.System.Numerics.BigInteger.Zero;
                for(/*int*/ let position = 0; position < endIndex; position++)
                {
                    if (position > 0 && $.$srn.System.Numerics.BigInteger.op_Equality$2(value, 0n))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                    }
                    value = $.$srn.System.Numerics.BigInteger.op_Multiply(value, $.$srn.System.Numerics.BigInteger.op_Implicit$4(10));
                    value = $.$srn.System.Numerics.BigInteger.op_Addition(value, $.$srn.System.Numerics.BigInteger.op_Implicit$4($.$sfa.System.Formats.Asn1.AsnWriter.AtoI(oidValue.$v.get_Item(position).$v)));
                }
                oidValue.$v = oidValue.$v.Slice$1($.$$.System.Math.Min$4(oidValue.$v.Length, ((endIndex + 1) | 0)));
                return value;
            }
            static /*int */ AtoI(/*char*/ c)
            {
                if (c >= /*0*/ 48 && c <= /*9*/ 57)
                {
                    return c - /*0*/ 48;
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
            }
            static /*int */ EncodeSubIdentifier(/*Span<byte>*/ dest, /*ref BigInteger*/ subIdentifier)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(dest.Length > 0, "dest.Length > 0");
                if (subIdentifier.$v.IsZero)
                {
                    dest.get_Item(0).$v = 0;
                    return 1;
                }
                /*BigInteger*/ let unencoded = subIdentifier.$v;
                /*int*/ let idx = 0;
                do
                {
                    /*BigInteger*/ let cur = $.$srn.System.Numerics.BigInteger.op_BitwiseAnd(unencoded, $.$srn.System.Numerics.BigInteger.op_Implicit$4(127));
                    /*byte*/ let curByte = $.$srn.System.Numerics.BigInteger.op_Explicit(cur);
                    if ($.$srn.System.Numerics.BigInteger.op_Inequality$4(subIdentifier.$v, unencoded))
                    {
                        curByte |= 128;
                    }
                    unencoded = $.$srn.System.Numerics.BigInteger.op_RightShift(unencoded, 7);
                    dest.get_Item(idx).$v = curByte;
                    idx++;
                }
                while($.$srn.System.Numerics.BigInteger.op_Inequality$4(unencoded, $.$srn.System.Numerics.BigInteger.Zero));
                $.$$.System.MemoryExtensions.Reverse($.$$.System.Byte, dest.Slice(0, idx));
                return idx;
            }
            /*byte[]*/ _buffer = null;
            /*int*/ _offset = 0;
            /*Stack<StackFrame>?*/ _nestingStack = null;
            /*int*/ _encodeDepth = 0;
            /*AsnEncodingRules*/ RuleSet = 0;
            $ctor$2(/*AsnEncodingRules*/ ruleSet)
            {
                super.$ctor();
                {
                    if (ruleSet !== 0/*AsnEncodingRules.BER*/ && ruleSet !== 1/*AsnEncodingRules.CER*/ && ruleSet !== 2/*AsnEncodingRules.DER*/)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("ruleSet");
                    }
                    this.RuleSet = ruleSet;
                }
                return this;
            }
            $ctor$1(/*AsnEncodingRules*/ ruleSet, /*int*/ initialCapacity)
            {
                this.$ctor$2(ruleSet);
                {
                    if (initialCapacity < 0)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("initialCapacity", $.$sfa.System.SR.ArgumentOutOfRange_NeedNonNegNum);
                    }
                    if (initialCapacity > 0)
                    {
                        this._buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [initialCapacity], null);
                    }
                }
                return this;
            }
            /*void */ Reset()
            {
                if (this._encodeDepth !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_ModifyingWhileEncoding);
                }
                if (this._offset > 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._buffer !== null, "_buffer != null");
                    $.$$.System.Array.Clear(this._buffer, 0, this._offset);
                    this._offset = 0;
                    this._nestingStack?.Clear();
                }
            }
            /*int */ GetEncodedLength()
            {
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_EncodeUnbalancedStack);
                }
                return this._offset;
            }
            /*bool */ TryEncode(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_EncodeUnbalancedStack);
                }
                if (destination.Length < this._offset)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                if (this._offset === 0)
                {
                    bytesWritten.$v = 0;
                    return true;
                }
                bytesWritten.$v = this._offset;
                $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, 0, this._offset).CopyTo(destination);
                return true;
            }
            /*int */ Encode$1(/*Span<byte>*/ destination)
            {
                /*int*/ let bytesWritten;
                if (!this.TryEncode(destination, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_DestinationTooShort, "destination");
                }
                $.$$.System.Diagnostics.Debug.Assert$2(bytesWritten === this._offset, "bytesWritten == _offset");
                return bytesWritten;
            }
            /*byte[] */ Encode()
            {
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_EncodeUnbalancedStack);
                }
                if (this._offset === 0)
                {
                    return $.$$.System.Array.Empty($.$$.System.Byte);
                }
                return $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, 0, this._offset).ToArray();
            }
            /*TReturn */ Encode$2(TReturn, /*Func<ReadOnlySpan<byte>, TReturn>*/ encodeCallback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encodeCallback, "encodeCallback");
                this._encodeDepth = $.$checked(this._encodeDepth + 1, 1);
                try
                {
                    /*ReadOnlySpan<byte>*/ let encoded = this.EncodeAsSpan();
                    return encodeCallback.Invoke(encoded);
                }
                finally
                {
                    {
                        this._encodeDepth--;
                    }
                }
            }
            /*TReturn */ Encode$3(TState, TReturn, /*TState*/ state, /*Func<TState, ReadOnlySpan<byte>, TReturn>*/ encodeCallback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encodeCallback, "encodeCallback");
                this._encodeDepth = $.$checked(this._encodeDepth + 1, 1);
                try
                {
                    /*ReadOnlySpan<byte>*/ let encoded = this.EncodeAsSpan();
                    return encodeCallback.Invoke(state, encoded);
                }
                finally
                {
                    {
                        this._encodeDepth--;
                    }
                }
            }
            /*void */ Encode$4(TState, /*TState*/ state, /*Action<TState, ReadOnlySpan<byte>>*/ encodeCallback)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encodeCallback, "encodeCallback");
                this._encodeDepth = $.$checked(this._encodeDepth + 1, 1);
                try
                {
                    /*ReadOnlySpan<byte>*/ let encoded = this.EncodeAsSpan();
                    encodeCallback.Invoke(state, encoded);
                }
                finally
                {
                    {
                        this._encodeDepth--;
                    }
                }
            }
            /*ReadOnlySpan<byte> */ EncodeAsSpan()
            {
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_EncodeUnbalancedStack);
                }
                if (this._offset === 0)
                {
                    return $.$$.System.ReadOnlySpan$$($.$$.System.Byte).Empty;
                }
                return new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$3(this._buffer, 0, this._offset);
            }
            /*bool */ EncodedValueEquals(/*ReadOnlySpan<byte>*/ other)
            {
                return $.$$.System.MemoryExtensions.SequenceEqual$1($.$$.System.Byte, this.EncodeAsSpan(), other);
            }
            /*bool */ EncodedValueEquals$1(/*AsnWriter*/ other)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                return $.$$.System.MemoryExtensions.SequenceEqual$1($.$$.System.Byte, this.EncodeAsSpan(), other.EncodeAsSpan());
            }
            /*void */ EnsureWriteCapacity(/*int*/ pendingCount)
            {
                if (pendingCount < 0)
                {
                    throw new $.$$.System.OverflowException().$ctor$13();
                }
                if (this._encodeDepth !== 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_ModifyingWhileEncoding);
                }
                if (this._buffer === null || ((this._buffer.length - this._offset) | 0) < pendingCount)
                {
                    /*int*/ let BlockSize = 1024;
                    /*int*/ let blocks = $.trunc($.$checked($.$checked(this._offset + pendingCount, 1) + ($.$checked(BlockSize - 1, 1)), 1) / BlockSize);
                    /*byte[]?*/ let oldBytes = this._buffer;
                    $.$$.System.Array.Resize($.$$.System.Byte, $.$ref(() => this._buffer, ($v) => this._buffer = $v, $.$typeArray($.$$.System.Byte)), ((BlockSize * blocks) | 0));
                    /*byte[]?*/ let __ca1__;
                    if ((__ca1__ = oldBytes) !== null)
                    {
                        $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, __ca1__, 0, this._offset).Clear();
                    }
                    $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset).Fill(202);
                }
            }
            /*void */ WriteTag(/*Asn1Tag*/ tag)
            {
                /*int*/ let spaceRequired = tag.CalculateEncodedSize();
                this.EnsureWriteCapacity(spaceRequired);
                /*int*/ let written;
                if (!tag.TryEncode($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, this._offset, spaceRequired), $.$ref(() => written, ($v) => written = $v, $.$$.System.Int32)) || written !== spaceRequired)
                {
                    $.$$.System.Diagnostics.Debug.Fail$1(`TryWrite failed or written was wrong value (${written} vs ${spaceRequired})`);
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                this._offset += spaceRequired;
            }
            /*void */ WriteLength(/*int*/ length)
            {
                /*byte*/ let MultiByteMarker = 128;
                $.$$.System.Diagnostics.Debug.Assert$2(length >= -1, "length >= -1");
                if (length === -1)
                {
                    this.EnsureWriteCapacity(1);
                    $.$$.System.Array.$WriteT1.call(this._buffer, MultiByteMarker, this._offset);
                    this._offset++;
                    return;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(length >= 0, "length >= 0");
                if (length < MultiByteMarker)
                {
                    this.EnsureWriteCapacity(((1 + length) | 0));
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(length, $.$$.System.Byte), this._offset);
                    this._offset++;
                    return;
                }
                /*int*/ let lengthLength = $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(length);
                this.EnsureWriteCapacity(((((lengthLength + 1) | 0) + length) | 0));
                $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast((MultiByteMarker | lengthLength), $.$$.System.Byte), this._offset);
                /*int*/ let idx = ((this._offset + lengthLength) | 0);
                /*int*/ let remaining = length;
                do
                {
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(remaining, $.$$.System.Byte), idx);
                    remaining >>= 8;
                    idx--;
                }
                while(remaining > 0);
                $.$$.System.Diagnostics.Debug.Assert$2(idx === this._offset, "idx == _offset");
                this._offset += ((lengthLength + 1) | 0);
            }
            static /*int */ GetEncodedLengthSubsequentByteCount(/*int*/ length)
            {
                if (length < 0)
                {
                    throw new $.$$.System.OverflowException().$ctor$13();
                }
                if (length <= 127)
                {
                    return 0;
                }
                if (length <= 255/*byte.MaxValue*/)
                {
                    return 1;
                }
                if (length <= 65535/*ushort.MaxValue*/)
                {
                    return 2;
                }
                if (length <= 16777215)
                {
                    return 3;
                }
                return 4;
            }
            /*void */ CopyTo(/*AsnWriter*/ destination)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(destination, "destination");
                try
                {
                    destination.WriteEncodedValue(this.EncodeAsSpan());
                }
                catch(e)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$11(new $.$$.System.InvalidOperationException().$ctor$9().Message, e);
                }
            }
            /*void */ WriteEncodedValue(/*ReadOnlySpan<byte>*/ value)
            {
                /*int*/ let consumed;
                /*bool*/ let read = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadEncodedValue(value, this.RuleSet, $.$discardRef(), $.$discardRef(), $.$discardRef(), $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                if (!read || consumed !== value.Length)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_WriteEncodedValue_OneValueAtATime, "value");
                }
                this.EnsureWriteCapacity(value.Length);
                value.CopyTo($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._buffer, this._offset));
                this._offset += value.Length;
            }
            /*void */ WriteEndOfContents()
            {
                this.EnsureWriteCapacity(2);
                $.$$.System.Array.$WriteT1.call(this._buffer, 0, this._offset++);
                $.$$.System.Array.$WriteT1.call(this._buffer, 0, this._offset++);
            }
            /*Scope */ PushTag(/*Asn1Tag*/ tag, /*UniversalTagNumber*/ tagType)
            {
                this._nestingStack ??= new ($.$sc.System.Collections.Generic.Stack$$($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame))().$ctor$1();
                $.$$.System.Diagnostics.Debug.Assert$2(tag.IsConstructed, "tag.IsConstructed");
                this.WriteTag(tag);
                this._nestingStack.Push(new $.$sfa.System.Formats.Asn1.AsnWriter.StackFrame().$ctor$3(tag, this._offset, tagType));
                this.WriteLength(-1);
                return new $.$sfa.System.Formats.Asn1.AsnWriter.Scope().$ctor$3(this);
            }
            /*void */ PopTag(/*Asn1Tag*/ tag, /*UniversalTagNumber*/ tagType, /*bool*/ sortContents)
            {
                if (this._nestingStack === null || this._nestingStack.Count === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_PopWrongTag);
                }
                const { Item1: stackTag, Item2: lenOffset, Item3: stackTagType } = this._nestingStack.Peek();
                $.$$.System.Diagnostics.Debug.Assert$2(tag.IsConstructed, "tag.IsConstructed");
                if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Inequality(stackTag, tag) || stackTagType !== tagType)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_PopWrongTag);
                }
                this._nestingStack.Pop();
                if (sortContents)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(tagType === 17/*UniversalTagNumber.SetOf*/, "tagType == UniversalTagNumber.SetOf");
                    $.$sfa.System.Formats.Asn1.AsnWriter.SortContents(this._buffer, ((lenOffset + 1) | 0), this._offset);
                }
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/ && tagType !== 4/*UniversalTagNumber.OctetString*/)
                {
                    this.WriteEndOfContents();
                    return;
                }
                /*int*/ let containedLength = ((((this._offset - 1) | 0) - lenOffset) | 0);
                $.$$.System.Diagnostics.Debug.Assert$2(containedLength >= 0, "containedLength >= 0");
                /*int*/ let start = ((lenOffset + 1) | 0);
                if (tagType === 4/*UniversalTagNumber.OctetString*/)
                {
                    if (this.RuleSet !== 1/*AsnEncodingRules.CER*/ || containedLength <= 1000/*AsnDecoder.MaxCERSegmentSize*/)
                    {
                        /*int*/ let tagLen = tag.CalculateEncodedSize();
                        tag.AsPrimitive().Encode($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, ((lenOffset - tagLen) | 0), tagLen));
                    }
                    else 
                    {
                        /*int*/ let lastSegmentSize;
                        /*int*/ let fullSegments = $.$$.System.Math.DivRem$2(containedLength, 1000/*AsnDecoder.MaxCERSegmentSize*/, $.$ref(() => lastSegmentSize, ($v) => lastSegmentSize = $v, $.$$.System.Int32));
                        /*int*/ let requiredPadding = ((((((4 * fullSegments) | 0) + 2) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(lastSegmentSize)) | 0);
                        this.EnsureWriteCapacity(((requiredPadding + 2) | 0));
                        /*ReadOnlySpan<byte>*/ let src = $.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, start, containedLength));
                        /*Span<byte>*/ let dest = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, ((start + requiredPadding) | 0), containedLength);
                        src.CopyTo(dest);
                        /*int*/ let expectedEnd = ((((((start + containedLength) | 0) + requiredPadding) | 0) + 2) | 0);
                        this._offset = ((lenOffset - tag.CalculateEncodedSize()) | 0);
                        this.WriteConstructedCerOctetString(tag, $.$$.System.Span$$($.$$.System.Byte).op_Implicit(dest));
                        $.$$.System.Diagnostics.Debug.Assert$2(this._offset === expectedEnd, "_offset == expectedEnd");
                        return;
                    }
                }
                /*int*/ let shiftSize = $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(containedLength);
                if (shiftSize === 0)
                {
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(containedLength, $.$$.System.Byte), lenOffset);
                    return;
                }
                this.EnsureWriteCapacity(shiftSize);
                $.$$.System.Buffer.BlockCopy(this._buffer, start, this._buffer, ((start + shiftSize) | 0), containedLength);
                /*int*/ let tmp = this._offset;
                this._offset = lenOffset;
                this.WriteLength(containedLength);
                $.$$.System.Diagnostics.Debug.Assert$2(((((this._offset - lenOffset) | 0) - 1) | 0) === shiftSize, "_offset - lenOffset - 1 == shiftSize");
                this._offset = ((tmp + shiftSize) | 0);
            }
            static /*void */ SortContents(/*byte[]*/ buffer, /*int*/ start, /*int*/ end)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(buffer !== null, "buffer != null");
                $.$$.System.Diagnostics.Debug.Assert$2(end >= start, "end >= start");
                /*int*/ let len = ((end - start) | 0);
                if (len === 0)
                {
                    return;
                }
                /*var*/ let reader = new $.$sfa.System.Formats.Asn1.AsnReader().$ctor$1(new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))().$ctor$4(buffer, start, len), 0/*AsnEncodingRules.BER*/, new $.$sfa.System.Formats.Asn1.AsnReaderOptions());
                /*int*/ let pos = start;
                /*ReadOnlyMemory<byte>*/ let encoded = reader.ReadEncodedValue();
                if (!reader.HasData)
                {
                    return;
                }
                /*List<(int, int)>*/ let positions = new ($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32)))().$ctor$1();
                positions.Add(new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(pos, encoded.Length));
                pos += encoded.Length;
                do
                {
                    encoded = reader.ReadEncodedValue();
                    positions.Add(new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(pos, encoded.Length));
                    pos += encoded.Length;
                }
                while(reader.HasData);
                $.$$.System.Diagnostics.Debug.Assert$2(pos === end, "pos == end");
                /*var*/ let comparer = new $.$sfa.System.Formats.Asn1.AsnWriter.ArrayIndexSetOfValueComparer().$ctor$1(buffer);
                positions.Sort$1(comparer);
                /*byte[]*/ let tmp = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(len);
                pos = 0;
                var $en2 = positions.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var $t1 = $en2.Current;
                    /*int*/ let offset = $t1.Item1;
                    /*int*/ let length = $t1.Item2;
                    {
                        $.$$.System.Buffer.BlockCopy(buffer, offset, tmp, pos, length);
                        pos += length;
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(pos === len, "pos == len");
                $.$$.System.Buffer.BlockCopy(tmp, 0, buffer, start, len);
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(tmp, len);
            }
            static /*void */ CheckUniversalTag(/*Asn1Tag?*/ tag, /*UniversalTagNumber*/ universalTagNumber)
            {
                if (tag !== null)
                {
                    /*Asn1Tag*/ let value = $.$$.System.Nullable$$($.$sfa.System.Formats.Asn1.Asn1Tag).Value$get.call(tag);
                    if (value.TagClass === 0/*TagClass.Universal*/ && value.TagValue !== universalTagNumber)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_UniversalValueIsFixed, "tag");
                    }
                }
            }
            static $_ArrayIndexSetOfValueComparer;
            static get ArrayIndexSetOfValueComparer()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnWriter;
                return $cls.$_ArrayIndexSetOfValueComparer ??= $asm.$ncls("$sfa.System.Formats.Asn1.AsnWriter.ArrayIndexSetOfValueComparer", ($self) => class ArrayIndexSetOfValueComparer extends $.$$.System.Object
                {
                    /*byte[]*/ _data = null;
                    $ctor$1(/*byte[]*/ data)
                    {
                        super.$ctor();
                        {
                            this._data = data;
                        }
                        return this;
                    }
                    /*int */ Compare(/*(int, int)*/ x, /*(int, int)*/ y)
                    {
                        const { Item1: xOffset, Item2: xLength } = x.Clone();
                        const { Item1: yOffset, Item2: yLength } = y.Clone();
                        /*int*/ let value = $.$sfa.System.Formats.Asn1.SetOfValueComparer.Instance.Compare(new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))().$ctor$4(this._data, xOffset, xLength), new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))().$ctor$4(this._data, yOffset, yLength));
                        if (value === 0)
                        {
                            return ((xOffset - yOffset) | 0);
                        }
                        return value;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IComparer<(int, int)>.Compare((int, int), (int, int))
                    System$Collections$Generic$IComparer$$$Compare()
                    {
                        return this.Compare(...arguments);
                    }
                    static $h = 847726;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"x","p":$.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32).$h},{"n":"y","p":$.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32).$h}],"n":"Compare","d":847726,"h":12885749614,"f":16777217}],"l":[{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_data","d":847726,"h":4295815022,"f":4194306}],"c":[{"p":[{"n":"data","p":$.$typeArray($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$1","d":847726,"h":8590782318,"f":16777217}],"i":[$.$$.System.Collections.Generic.IComparer$$($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32)).$h],"d":782190,"h":847726}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IComparer$$($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32)) ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnWriter.ArrayIndexSetOfValueComparer`; }
                }, $cls, ($v) => $cls.$_ArrayIndexSetOfValueComparer = $v);
            }
            static $_StackFrame;
            static get StackFrame()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnWriter;
                return $cls.$_StackFrame ??= $asm.$nstr("$sfa.System.Formats.Asn1.AsnWriter.StackFrame", ($self) => class StackFrame extends $.$$.System.ValueType
                {
                    /*Asn1Tag*/ Tag;
                    /*int*/ Offset = 0;
                    /*UniversalTagNumber*/ ItemType = 0;
                    $ctor$3(/*Asn1Tag*/ tag, /*int*/ offset, /*UniversalTagNumber*/ itemType)
                    {
                        super.$ctor$1();
                        {
                            this.Tag = tag;
                            this.Offset = offset;
                            this.ItemType = itemType;
                        }
                        return this;
                    }
                    /*void */ Deconstruct(/*out Asn1Tag*/ tag, /*out int*/ offset, /*out UniversalTagNumber*/ itemType)
                    {
                        tag.$v = this.Tag;
                        offset.$v = this.Offset;
                        itemType.$v = this.ItemType;
                    }
                    /*bool */ Equals$2(/*StackFrame*/ other)
                    {
                        return this.Tag.Equals$2(other.Tag) && this.Offset === other.Offset && this.ItemType === other.ItemType;
                    }
                    static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
                    {
                        let other;
                        return $.$is(obj, $.$sfa.System.Formats.Asn1.AsnWriter.StackFrame, { set $v(v){ other = v; } }) && this.Equals$2(other);
                    }
                    //Static convention instance redirect
                    /*bool */ Equals$1() { return $.$sfa.System.Formats.Asn1.AsnWriter.StackFrame.Equals$1.apply(this, arguments); }
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        return $.$$.System.ValueTuple$$$$($.$sfa.System.Formats.Asn1.Asn1Tag, $.$$.System.Int32, $.$sfa.System.Formats.Asn1.UniversalTagNumber).GetHashCode.call(new ($.$$.System.ValueTuple$$$$($.$sfa.System.Formats.Asn1.Asn1Tag, $.$$.System.Int32, $.$sfa.System.Formats.Asn1.UniversalTagNumber))().$ctor$3(this.Tag, this.Offset, this.ItemType));
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$sfa.System.Formats.Asn1.AsnWriter.StackFrame.GetHashCode.apply(this, arguments); }
                    static /*bool */ op_Equality(/*StackFrame*/ left, /*StackFrame*/ right)
                    {
                        return left.Equals$2(right);
                    }
                    static /*bool */ op_Inequality(/*StackFrame*/ left, /*StackFrame*/ right)
                    {
                        return !left.Equals$2(right);
                    }
                    //Generated interface implemetation for System.IEquatable<System.Formats.Asn1.AsnWriter.StackFrame>.Equals(System.Formats.Asn1.AsnWriter.StackFrame)
                    System$IEquatable$$$Equals()
                    {
                        return this.Equals$2(...arguments);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Tag = this.Tag.Clone();
                        copy.Offset = this.Offset;
                        copy.ItemType = this.ItemType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Tag = $.$default($.$sfa.System.Formats.Asn1.Asn1Tag);
                        this.ItemType = 0;
                    }
                    static $h = 978798;
                    static $z = 13;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":126830,"g":{"r":0,"d":0,"h":12885880686,"f":50331649},"n":"Tag","d":978798,"h":8590913390,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":25770782574,"f":50331649},"n":"Offset","d":978798,"h":21475815278,"f":2097153},{"p":1634158,"g":{"r":0,"d":0,"h":38655684462,"f":50331649},"n":"ItemType","d":978798,"h":34360717166,"f":2097153}],"m":[{"r":65537,"p":[{"n":"tag","p":126830,"f":2},{"n":"offset","p":655361,"f":2},{"n":"itemType","p":1634158,"f":2}],"n":"Deconstruct","d":978798,"h":47245619054,"f":16777217},{"r":262145,"p":[{"n":"other","p":978798}],"n":"Equals","o":"@$2","d":978798,"h":51540586350,"f":16777217},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":978798,"h":55835553646,"f":16809985},{"r":655361,"n":"GetHashCode","d":978798,"h":60130520942,"f":16809985}],"c":[{"p":[{"n":"tag","p":126830},{"n":"offset","p":655361},{"n":"itemType","p":1634158}],"n":".ctor","o":"$ctor$3","d":978798,"h":42950651758,"f":16777224},{"n":".ctor","o":"$ctor$2","d":978798,"h":73015422830,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame).$h],"d":782190,"h":978798}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame) ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnWriter.StackFrame`; }
                }, $cls, ($v) => $cls.$_StackFrame = $v);
            }
            static $_Scope;
            static get Scope()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnWriter;
                return $cls.$_Scope ??= $asm.$nstr("$sfa.System.Formats.Asn1.AsnWriter.Scope", ($self) => class Scope extends $.$$.System.ValueType
                {
                    /*AsnWriter*/  get _writer() { return this.$getField(0, 4); }
                    /*AsnWriter*/  set _writer(value) { this.$setField(0, 4, value); }
                    /*StackFrame*/  get _frame() { return this.$getField(4, 13); }
                    /*StackFrame*/  set _frame(value) { this.$setField(4, 13, value); }
                    /*int*/  get _depth() { return this.$getField(17, 4); }
                    /*int*/  set _depth(value) { this.$setField(17, 4, value); }
                    $ctor$3(/*AsnWriter*/ writer)
                    {
                        super.$ctor$1();
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(writer._nestingStack !== null, "writer._nestingStack != null");
                            this._writer = writer;
                            this._frame = this._writer._nestingStack.Peek();
                            this._depth = this._writer._nestingStack.Count;
                        }
                        return this;
                    }
                    /*void */ Dispose()
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._writer === null || this._writer._nestingStack !== null, "_writer == null || _writer._nestingStack != null");
                        if (this._writer === null || this._writer._nestingStack.Count === 0)
                        {
                            return;
                        }
                        if ($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame.op_Equality(this._writer._nestingStack.Peek(), this._frame))
                        {
                            let $switch1 = this._frame.ItemType;
                            switch($switch1)
                            {
                                case 17/*UniversalTagNumber.SetOf*/:
                                this._writer.PopSetOf(this._frame.Tag);
                                break;
                                case 16/*UniversalTagNumber.Sequence*/:
                                this._writer.PopSequence(this._frame.Tag);
                                break;
                                case 4/*UniversalTagNumber.OctetString*/:
                                this._writer.PopOctetString(this._frame.Tag);
                                break;
                                default:
                                $.$$.System.Diagnostics.Debug.Fail$1(`No handler for ${this._frame.ItemType}`);
                                throw new $.$$.System.InvalidOperationException().$ctor$9();
                            }
                        }
                        else if (this._writer._nestingStack.Count > this._depth && this._writer._nestingStack.Contains(this._frame))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sfa.System.SR.AsnWriter_PopWrongTag);
                        }
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._writer = this._writer;
                        copy._frame = this._frame.Clone();
                        copy._depth = this._depth;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._writer = null;
                        this._frame = $.$default($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame);
                        this._depth = 0;
                    }
                    static $h = 913262;
                    static $z = 21;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"n":"Dispose","d":913262,"h":21475749742,"f":16777217}],"l":[{"t":782190,"n":"_writer","d":913262,"h":4295880558,"f":4194306},{"t":978798,"n":"_frame","d":913262,"h":8590847854,"f":4194306},{"t":655361,"n":"_depth","d":913262,"h":12885815150,"f":4194306}],"c":[{"p":[{"n":"writer","p":782190}],"n":".ctor","o":"$ctor$3","d":913262,"h":17180782446,"f":16777224},{"n":".ctor","o":"$ctor$2","d":913262,"h":25770717038,"f":16777217}],"i":[57540609],"d":782190,"h":913262}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnWriter.Scope`; }
                }, $cls, ($v) => $cls.$_Scope = $v);
            }
            //default member initializer
            constructor()
            {
                super();
                this._buffer = null;
                this.RuleSet = 0;
            }
            static $h = 782190;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":585582,"g":{"r":0,"d":0,"h":270583721838,"f":50331649},"n":"RuleSet","d":782190,"h":266288754542,"f":2097153}],"m":[{"r":65537,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"unusedBitCount","p":655361,"f":65,"v":0},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteBitString","d":782190,"h":4295749486,"f":16777217},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"bitString","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"unusedBitCount","p":655361}],"n":"WriteBitStringCore","d":782190,"h":8590716782,"f":16777218},{"r":262145,"p":[{"n":"lastByte","p":393217},{"n":"unusedBitCount","p":655361}],"n":"CheckValidLastByte","d":782190,"h":12885684078,"f":16777250},{"r":655361,"p":[{"n":"tag","p":126830},{"n":"contentLength","p":655361}],"n":"DetermineCerBitStringTotalLength","d":782190,"h":17180651374,"f":16777250},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"payload","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"unusedBitCount","p":655361}],"n":"WriteConstructedCerBitString","d":782190,"h":21475618670,"f":16777218},{"r":65537,"p":[{"n":"value","p":1048577},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteNamedBitList","o":"@$1","d":782190,"h":25770585966,"f":16777217},{"r":65537,"p":[{"n":"value","p":(TEnum) => TEnum.$h},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"g":["TEnum"],"n":"WriteNamedBitList","o":"@$4","d":782190,"h":30065553262,"f":16908289},{"r":65537,"p":[{"n":"value","p":24510465},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteNamedBitList","d":782190,"h":34360520558,"f":16777217},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h},{"n":"tEnum","p":142475265},{"n":"value","p":1048577}],"n":"WriteNamedBitList","o":"@$2","d":782190,"h":38655487854,"f":16777218},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h},{"n":"integralValue","p":983041}],"n":"WriteNamedBitList","o":"@$3","d":782190,"h":42950455150,"f":16777218},{"r":65537,"p":[{"n":"value","p":24510465},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h}],"n":"WriteBitArray","d":782190,"h":47245422446,"f":16777218},{"r":65537,"p":[{"n":"encodingType","p":1634158},{"n":"value","p":1310721},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteCharacterString","o":"@$1","d":782190,"h":51540389742,"f":16777217},{"r":65537,"p":[{"n":"encodingType","p":1634158},{"n":"str","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteCharacterString","d":782190,"h":55835357038,"f":16777217},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"encoding","p":121700353},{"n":"str","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"WriteCharacterStringCore","d":782190,"h":60130324334,"f":16777218},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"encoding","p":121700353},{"n":"str","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"size","p":655361}],"n":"WriteConstructedCerCharacterString","d":782190,"h":64425291630,"f":16777218},{"r":65537,"p":[{"n":"value","p":262145},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteBoolean","d":782190,"h":68720258926,"f":16777217},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"value","p":262145}],"n":"WriteBooleanCore","d":782190,"h":73015226222,"f":16777218},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteNull","d":782190,"h":77310193518,"f":16777217},{"r":65537,"p":[{"n":"tag","p":126830}],"n":"WriteNullCore","d":782190,"h":81605160814,"f":16777218},{"r":913262,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"PushSequence","d":782190,"h":85900128110,"f":16777217},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"PopSequence","d":782190,"h":90195095406,"f":16777217},{"r":913262,"p":[{"n":"tag","p":126830}],"n":"PushSequenceCore","d":782190,"h":94490062702,"f":16777218},{"r":65537,"p":[{"n":"tag","p":126830}],"n":"PopSequenceCore","d":782190,"h":98785029998,"f":16777218},{"r":913262,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"PushSetOf","d":782190,"h":103079997294,"f":16777217},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"PopSetOf","d":782190,"h":107374964590,"f":16777217},{"r":913262,"p":[{"n":"tag","p":126830}],"n":"PushSetOfCore","d":782190,"h":111669931886,"f":16777218},{"r":65537,"p":[{"n":"tag","p":126830}],"n":"PopSetOfCore","d":782190,"h":115964899182,"f":16777218},{"r":913262,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"PushOctetString","d":782190,"h":120259866478,"f":16777217},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"PopOctetString","d":782190,"h":124554833774,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteOctetString","d":782190,"h":128849801070,"f":16777217},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"octetString","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"WriteOctetStringCore","d":782190,"h":133144768366,"f":16777218},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"payload","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"WriteConstructedCerOctetString","d":782190,"h":137439735662,"f":16777218},{"r":65537,"p":[{"n":"value","p":34471937},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteUtcTime","o":"@$1","d":782190,"h":141734702958,"f":16777217},{"r":65537,"p":[{"n":"value","p":34471937},{"n":"twoDigitYearMax","p":655361},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteUtcTime","d":782190,"h":146029670254,"f":16777217},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"value","p":34471937}],"n":"WriteUtcTimeCore","d":782190,"h":150324637550,"f":16777218},{"r":65537,"p":[{"n":"value","p":1048577},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteEnumeratedValue","d":782190,"h":154619604846,"f":16777217},{"r":65537,"p":[{"n":"value","p":(TEnum) => TEnum.$h},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"g":["TEnum"],"n":"WriteEnumeratedValue","o":"@$2","d":782190,"h":158914572142,"f":16908289},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"tEnum","p":142475265},{"n":"value","p":131073}],"n":"WriteEnumeratedValue","o":"@$1","d":782190,"h":163209539438,"f":16777218},{"r":65537,"p":[{"n":"value","p":34471937},{"n":"omitFractionalSeconds","p":262145,"f":65,"v":false},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteGeneralizedTime","d":782190,"h":167504506734,"f":16777217},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"value","p":34471937},{"n":"omitFractionalSeconds","p":262145}],"n":"WriteGeneralizedTimeCore","d":782190,"h":171799474030,"f":16777218},{"r":65537,"p":[{"n":"value","p":917505},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteInteger","d":782190,"h":176094441326,"f":16777217},{"r":65537,"p":[{"n":"value","p":983041},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteInteger","o":"@$2","d":782190,"h":180389408622,"f":16777217,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"value","p":846197},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteInteger","o":"@$3","d":782190,"h":184684375918,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteInteger","o":"@$1","d":782190,"h":188979343214,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteIntegerUnsigned","d":782190,"h":193274310510,"f":16777217},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"value","p":917505}],"n":"WriteIntegerCore","d":782190,"h":197569277806,"f":16777218},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"value","p":983041}],"n":"WriteNonNegativeIntegerCore","d":782190,"h":201864245102,"f":16777218},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"WriteIntegerUnsignedCore","d":782190,"h":206159212398,"f":16777218},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"WriteIntegerCore","o":"@$1","d":782190,"h":210454179694,"f":16777218},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"value","p":846197}],"n":"WriteIntegerCore","o":"@$2","d":782190,"h":214749146990,"f":16777218},{"r":65537,"p":[{"n":"oidValue","p":1310721},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteObjectIdentifier","o":"@$1","d":782190,"h":219044114286,"f":16777217},{"r":65537,"p":[{"n":"oidValue","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteObjectIdentifier","d":782190,"h":223339081582,"f":16777217},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"oidValue","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"WriteObjectIdentifierCore","d":782190,"h":227634048878,"f":16777218},{"r":846197,"p":[{"n":"oidValue","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"f":4}],"n":"ParseSubIdentifier","d":782190,"h":231929016174,"f":16777250},{"r":655361,"p":[{"n":"c","p":458753}],"n":"AtoI","d":782190,"h":236223983470,"f":16777250},{"r":655361,"p":[{"n":"dest","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"subIdentifier","p":846197,"f":4}],"n":"EncodeSubIdentifier","d":782190,"h":240518950766,"f":16777250},{"r":65537,"n":"Reset","d":782190,"h":283468623726,"f":16777217},{"r":655361,"n":"GetEncodedLength","d":782190,"h":287763591022,"f":16777217},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryEncode","d":782190,"h":292058558318,"f":16777217},{"r":655361,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"Encode","o":"@$1","d":782190,"h":296353525614,"f":16777217},{"r":$.$typeArray($.$$.System.Byte).$h,"n":"Encode","d":782190,"h":300648492910,"f":16777217},{"r":(TReturn) => TReturn.$h,"p":[{"n":"encodeCallback","p":(TReturn) => $.$$.System.Func$$$($.$$.System.ReadOnlySpan$$($.$$.System.Byte), TReturn).$h}],"g":["TReturn"],"n":"Encode","o":"@$2","d":782190,"h":304943460206,"f":16908289},{"r":(TState, TReturn) => TReturn.$h,"p":[{"n":"state","p":(TState, TReturn) => TState.$h},{"n":"encodeCallback","p":(TState, TReturn) => $.$$.System.Func$$$$(TState, $.$$.System.ReadOnlySpan$$($.$$.System.Byte), TReturn).$h}],"g":["TState","TReturn"],"n":"Encode","o":"@$3","d":782190,"h":309238427502,"f":16908289},{"r":65537,"p":[{"n":"state","p":(TState) => TState.$h},{"n":"encodeCallback","p":(TState) => $.$$.System.Action$$$(TState, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)).$h}],"g":["TState"],"n":"Encode","o":"@$4","d":782190,"h":313533394798,"f":16908289},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"n":"EncodeAsSpan","d":782190,"h":317828362094,"f":16777218},{"r":262145,"p":[{"n":"other","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"EncodedValueEquals","d":782190,"h":322123329390,"f":16777217},{"r":262145,"p":[{"n":"other","p":782190}],"n":"EncodedValueEquals","o":"@$1","d":782190,"h":326418296686,"f":16777217},{"r":65537,"p":[{"n":"pendingCount","p":655361}],"n":"EnsureWriteCapacity","d":782190,"h":330713263982,"f":16777218},{"r":65537,"p":[{"n":"tag","p":126830}],"n":"WriteTag","d":782190,"h":335008231278,"f":16777218},{"r":65537,"p":[{"n":"length","p":655361}],"n":"WriteLength","d":782190,"h":339303198574,"f":16777218},{"r":655361,"p":[{"n":"length","p":655361}],"n":"GetEncodedLengthSubsequentByteCount","d":782190,"h":343598165870,"f":16777250},{"r":65537,"p":[{"n":"destination","p":782190}],"n":"CopyTo","d":782190,"h":347893133166,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"WriteEncodedValue","d":782190,"h":352188100462,"f":16777217},{"r":65537,"n":"WriteEndOfContents","d":782190,"h":356483067758,"f":16777218},{"r":913262,"p":[{"n":"tag","p":126830},{"n":"tagType","p":1634158}],"n":"PushTag","d":782190,"h":360778035054,"f":16777218},{"r":65537,"p":[{"n":"tag","p":126830},{"n":"tagType","p":1634158},{"n":"sortContents","p":262145,"f":65,"v":false}],"n":"PopTag","d":782190,"h":365073002350,"f":16777218},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"start","p":655361},{"n":"end","p":655361}],"n":"SortContents","d":782190,"h":369367969646,"f":16777250},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h},{"n":"universalTagNumber","p":1634158}],"n":"CheckUniversalTag","d":782190,"h":373662936942,"f":16777250}],"l":[{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_buffer","d":782190,"h":244813918062,"f":4194306},{"t":655361,"n":"_offset","d":782190,"h":249108885358,"f":4194306},{"t":$.$sc.System.Collections.Generic.Stack$$($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame).$h,"n":"_nestingStack","d":782190,"h":253403852654,"f":4194306},{"t":655361,"n":"_encodeDepth","d":782190,"h":257698819950,"f":4194306}],"c":[{"p":[{"n":"ruleSet","p":585582}],"n":".ctor","o":"$ctor$2","d":782190,"h":274878689134,"f":16777217},{"p":[{"n":"ruleSet","p":585582},{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$1","d":782190,"h":279173656430,"f":16777217}],"j":[847726,978798,913262],"h":782190}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.AsnWriter`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.WellKnownOids", ($self) => class WellKnownOids
        {
            static /*string? */ GetValue(/*ReadOnlySpan<byte>*/ contents)
            {
                return (() =>
                {
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 56 && contents[5] === 4 && contents[6] === 1))
                    {
                        return "1.2.840.10040.4.1";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 56 && contents[5] === 4 && contents[6] === 3))
                    {
                        return "1.2.840.10040.4.3";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 2 && contents[6] === 1))
                    {
                        return "1.2.840.10045.2.1";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 1 && contents[6] === 1))
                    {
                        return "1.2.840.10045.1.1";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 1 && contents[6] === 2))
                    {
                        return "1.2.840.10045.1.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 3 && contents[6] === 1 && contents[7] === 7))
                    {
                        return "1.2.840.10045.3.1.7";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 1))
                    {
                        return "1.2.840.10045.4.1";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 3 && contents[7] === 2))
                    {
                        return "1.2.840.10045.4.3.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 3 && contents[7] === 3))
                    {
                        return "1.2.840.10045.4.3.3";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 3 && contents[7] === 4))
                    {
                        return "1.2.840.10045.4.3.4";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 1))
                    {
                        return "1.2.840.113549.1.1.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 5))
                    {
                        return "1.2.840.113549.1.1.5";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 7))
                    {
                        return "1.2.840.113549.1.1.7";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 8))
                    {
                        return "1.2.840.113549.1.1.8";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 9))
                    {
                        return "1.2.840.113549.1.1.9";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 10))
                    {
                        return "1.2.840.113549.1.1.10";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 11))
                    {
                        return "1.2.840.113549.1.1.11";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 12))
                    {
                        return "1.2.840.113549.1.1.12";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 13))
                    {
                        return "1.2.840.113549.1.1.13";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 3))
                    {
                        return "1.2.840.113549.1.5.3";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 10))
                    {
                        return "1.2.840.113549.1.5.10";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 11))
                    {
                        return "1.2.840.113549.1.5.11";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 12))
                    {
                        return "1.2.840.113549.1.5.12";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 13))
                    {
                        return "1.2.840.113549.1.5.13";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 1))
                    {
                        return "1.2.840.113549.1.7.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 2))
                    {
                        return "1.2.840.113549.1.7.2";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 3))
                    {
                        return "1.2.840.113549.1.7.3";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 6))
                    {
                        return "1.2.840.113549.1.7.6";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 1))
                    {
                        return "1.2.840.113549.1.9.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 3))
                    {
                        return "1.2.840.113549.1.9.3";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 4))
                    {
                        return "1.2.840.113549.1.9.4";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 5))
                    {
                        return "1.2.840.113549.1.9.5";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 6))
                    {
                        return "1.2.840.113549.1.9.6";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 7))
                    {
                        return "1.2.840.113549.1.9.7";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 14))
                    {
                        return "1.2.840.113549.1.9.14";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 15))
                    {
                        return "1.2.840.113549.1.9.15";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 1 && contents[10] === 4))
                    {
                        return "1.2.840.113549.1.9.16.1.4";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 2 && contents[10] === 12))
                    {
                        return "1.2.840.113549.1.9.16.2.12";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 2 && contents[10] === 14))
                    {
                        return "1.2.840.113549.1.9.16.2.14";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 2 && contents[10] === 47))
                    {
                        return "1.2.840.113549.1.9.16.2.47";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 20))
                    {
                        return "1.2.840.113549.1.9.20";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 21))
                    {
                        return "1.2.840.113549.1.9.21";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 22 && contents[9] === 1))
                    {
                        return "1.2.840.113549.1.9.22.1";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 1 && contents[9] === 3))
                    {
                        return "1.2.840.113549.1.12.1.3";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 1 && contents[9] === 5))
                    {
                        return "1.2.840.113549.1.12.1.5";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 1 && contents[9] === 6))
                    {
                        return "1.2.840.113549.1.12.1.6";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 1))
                    {
                        return "1.2.840.113549.1.12.10.1.1";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 2))
                    {
                        return "1.2.840.113549.1.12.10.1.2";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 3))
                    {
                        return "1.2.840.113549.1.12.10.1.3";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 5))
                    {
                        return "1.2.840.113549.1.12.10.1.5";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 6))
                    {
                        return "1.2.840.113549.1.12.10.1.6";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 5))
                    {
                        return "1.2.840.113549.2.5";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 7))
                    {
                        return "1.2.840.113549.2.7";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 9))
                    {
                        return "1.2.840.113549.2.9";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 10))
                    {
                        return "1.2.840.113549.2.10";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 11))
                    {
                        return "1.2.840.113549.2.11";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 3 && contents[7] === 2))
                    {
                        return "1.2.840.113549.3.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 3 && contents[7] === 7))
                    {
                        return "1.2.840.113549.3.7";
                    }
                    if ((contents.Length === 9 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 17 && contents[8] === 1))
                    {
                        return "1.3.6.1.4.1.311.17.1";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 17 && contents[8] === 3 && contents[9] === 20))
                    {
                        return "1.3.6.1.4.1.311.17.3.20";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 20 && contents[8] === 2 && contents[9] === 3))
                    {
                        return "1.3.6.1.4.1.311.20.2.3";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 88 && contents[8] === 2 && contents[9] === 1))
                    {
                        return "1.3.6.1.4.1.311.88.2.1";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 88 && contents[8] === 2 && contents[9] === 2))
                    {
                        return "1.3.6.1.4.1.311.88.2.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 1))
                    {
                        return "1.3.6.1.5.5.7.3.1";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 2))
                    {
                        return "1.3.6.1.5.5.7.3.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 3))
                    {
                        return "1.3.6.1.5.5.7.3.3";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 4))
                    {
                        return "1.3.6.1.5.5.7.3.4";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 8))
                    {
                        return "1.3.6.1.5.5.7.3.8";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 9))
                    {
                        return "1.3.6.1.5.5.7.3.9";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 6 && contents[7] === 2))
                    {
                        return "1.3.6.1.5.5.7.6.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 48 && contents[7] === 1))
                    {
                        return "1.3.6.1.5.5.7.48.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 48 && contents[7] === 1 && contents[8] === 2))
                    {
                        return "1.3.6.1.5.5.7.48.1.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 48 && contents[7] === 2))
                    {
                        return "1.3.6.1.5.5.7.48.2";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 14 && contents[2] === 3 && contents[3] === 2 && contents[4] === 26))
                    {
                        return "1.3.14.3.2.26";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 14 && contents[2] === 3 && contents[3] === 2 && contents[4] === 7))
                    {
                        return "1.3.14.3.2.7";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 129 && contents[2] === 4 && contents[3] === 0 && contents[4] === 34))
                    {
                        return "1.3.132.0.34";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 129 && contents[2] === 4 && contents[3] === 0 && contents[4] === 35))
                    {
                        return "1.3.132.0.35";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 3))
                    {
                        return "2.5.4.3";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 5))
                    {
                        return "2.5.4.5";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 6))
                    {
                        return "2.5.4.6";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 7))
                    {
                        return "2.5.4.7";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 8))
                    {
                        return "2.5.4.8";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 10))
                    {
                        return "2.5.4.10";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 11))
                    {
                        return "2.5.4.11";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 97))
                    {
                        return "2.5.4.97";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 14))
                    {
                        return "2.5.29.14";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 15))
                    {
                        return "2.5.29.15";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 17))
                    {
                        return "2.5.29.17";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 19))
                    {
                        return "2.5.29.19";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 20))
                    {
                        return "2.5.29.20";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 35))
                    {
                        return "2.5.29.35";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 1 && contents[8] === 2))
                    {
                        return "2.16.840.1.101.3.4.1.2";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 1 && contents[8] === 22))
                    {
                        return "2.16.840.1.101.3.4.1.22";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 1 && contents[8] === 42))
                    {
                        return "2.16.840.1.101.3.4.1.42";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 2 && contents[8] === 1))
                    {
                        return "2.16.840.1.101.3.4.2.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 2 && contents[8] === 2))
                    {
                        return "2.16.840.1.101.3.4.2.2";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 2 && contents[8] === 3))
                    {
                        return "2.16.840.1.101.3.4.2.3";
                    }
                    if ((contents.Length === 6 && contents[0] === 103 && contents[1] === 129 && contents[2] === 12 && contents[3] === 1 && contents[4] === 2 && contents[5] === 1))
                    {
                        return "2.23.140.1.2.1";
                    }
                    if ((contents.Length === 6 && contents[0] === 103 && contents[1] === 129 && contents[2] === 12 && contents[3] === 1 && contents[4] === 2 && contents[5] === 2))
                    {
                        return "2.23.140.1.2.2";
                    }
                    return null;
                })();
            }
            static /*ReadOnlySpan<byte> */ GetContents(/*ReadOnlySpan<char>*/ value)
            {
                /*ReadOnlySpan<byte>*/ let data = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([ 42, 134, 72, 206, 56, 4, 1, 42, 134, 72, 206, 56, 4, 3, 42, 134, 72, 206, 61, 2, 1, 42, 134, 72, 206, 61, 1, 1, 42, 134, 72, 206, 61, 1, 2, 42, 134, 72, 206, 61, 3, 1, 7, 42, 134, 72, 206, 61, 4, 1, 42, 134, 72, 206, 61, 4, 3, 2, 42, 134, 72, 206, 61, 4, 3, 3, 42, 134, 72, 206, 61, 4, 3, 4, 42, 134, 72, 134, 247, 13, 1, 1, 1, 42, 134, 72, 134, 247, 13, 1, 1, 5, 42, 134, 72, 134, 247, 13, 1, 1, 7, 42, 134, 72, 134, 247, 13, 1, 1, 8, 42, 134, 72, 134, 247, 13, 1, 1, 9, 42, 134, 72, 134, 247, 13, 1, 1, 10, 42, 134, 72, 134, 247, 13, 1, 1, 11, 42, 134, 72, 134, 247, 13, 1, 1, 12, 42, 134, 72, 134, 247, 13, 1, 1, 13, 42, 134, 72, 134, 247, 13, 1, 5, 3, 42, 134, 72, 134, 247, 13, 1, 5, 10, 42, 134, 72, 134, 247, 13, 1, 5, 11, 42, 134, 72, 134, 247, 13, 1, 5, 12, 42, 134, 72, 134, 247, 13, 1, 5, 13, 42, 134, 72, 134, 247, 13, 1, 7, 1, 42, 134, 72, 134, 247, 13, 1, 7, 2, 42, 134, 72, 134, 247, 13, 1, 7, 3, 42, 134, 72, 134, 247, 13, 1, 7, 6, 42, 134, 72, 134, 247, 13, 1, 9, 1, 42, 134, 72, 134, 247, 13, 1, 9, 3, 42, 134, 72, 134, 247, 13, 1, 9, 4, 42, 134, 72, 134, 247, 13, 1, 9, 5, 42, 134, 72, 134, 247, 13, 1, 9, 6, 42, 134, 72, 134, 247, 13, 1, 9, 7, 42, 134, 72, 134, 247, 13, 1, 9, 14, 42, 134, 72, 134, 247, 13, 1, 9, 15, 42, 134, 72, 134, 247, 13, 1, 9, 16, 1, 4, 42, 134, 72, 134, 247, 13, 1, 9, 16, 2, 12, 42, 134, 72, 134, 247, 13, 1, 9, 16, 2, 14, 42, 134, 72, 134, 247, 13, 1, 9, 16, 2, 47, 42, 134, 72, 134, 247, 13, 1, 9, 20, 42, 134, 72, 134, 247, 13, 1, 9, 21, 42, 134, 72, 134, 247, 13, 1, 9, 22, 1, 42, 134, 72, 134, 247, 13, 1, 12, 1, 3, 42, 134, 72, 134, 247, 13, 1, 12, 1, 5, 42, 134, 72, 134, 247, 13, 1, 12, 1, 6, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 1, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 2, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 3, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 5, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 6, 42, 134, 72, 134, 247, 13, 2, 5, 42, 134, 72, 134, 247, 13, 2, 7, 42, 134, 72, 134, 247, 13, 2, 9, 42, 134, 72, 134, 247, 13, 2, 10, 42, 134, 72, 134, 247, 13, 2, 11, 42, 134, 72, 134, 247, 13, 3, 2, 42, 134, 72, 134, 247, 13, 3, 7, 43, 6, 1, 4, 1, 130, 55, 17, 1, 43, 6, 1, 4, 1, 130, 55, 17, 3, 20, 43, 6, 1, 4, 1, 130, 55, 20, 2, 3, 43, 6, 1, 4, 1, 130, 55, 88, 2, 1, 43, 6, 1, 4, 1, 130, 55, 88, 2, 2, 43, 6, 1, 5, 5, 7, 3, 1, 43, 6, 1, 5, 5, 7, 3, 2, 43, 6, 1, 5, 5, 7, 3, 3, 43, 6, 1, 5, 5, 7, 3, 4, 43, 6, 1, 5, 5, 7, 3, 8, 43, 6, 1, 5, 5, 7, 3, 9, 43, 6, 1, 5, 5, 7, 6, 2, 43, 6, 1, 5, 5, 7, 48, 1, 43, 6, 1, 5, 5, 7, 48, 1, 2, 43, 6, 1, 5, 5, 7, 48, 2, 43, 14, 3, 2, 26, 43, 14, 3, 2, 7, 43, 129, 4, 0, 34, 43, 129, 4, 0, 35, 85, 4, 3, 85, 4, 5, 85, 4, 6, 85, 4, 7, 85, 4, 8, 85, 4, 10, 85, 4, 11, 85, 4, 97, 85, 29, 14, 85, 29, 15, 85, 29, 17, 85, 29, 19, 85, 29, 20, 85, 29, 35, 96, 134, 72, 1, 101, 3, 4, 1, 2, 96, 134, 72, 1, 101, 3, 4, 1, 22, 96, 134, 72, 1, 101, 3, 4, 1, 42, 96, 134, 72, 1, 101, 3, 4, 2, 1, 96, 134, 72, 1, 101, 3, 4, 2, 2, 96, 134, 72, 1, 101, 3, 4, 2, 3, 103, 129, 12, 1, 2, 1, 103, 129, 12, 1, 2, 2 ]);
                return (() =>
                {
                    if (value === "1.2.840.10040.4.1")
                    {
                        return data.Slice(0, 7);
                    }
                    if (value === "1.2.840.10040.4.3")
                    {
                        return data.Slice(7, 7);
                    }
                    if (value === "1.2.840.10045.2.1")
                    {
                        return data.Slice(14, 7);
                    }
                    if (value === "1.2.840.10045.1.1")
                    {
                        return data.Slice(21, 7);
                    }
                    if (value === "1.2.840.10045.1.2")
                    {
                        return data.Slice(28, 7);
                    }
                    if (value === "1.2.840.10045.3.1.7")
                    {
                        return data.Slice(35, 8);
                    }
                    if (value === "1.2.840.10045.4.1")
                    {
                        return data.Slice(43, 7);
                    }
                    if (value === "1.2.840.10045.4.3.2")
                    {
                        return data.Slice(50, 8);
                    }
                    if (value === "1.2.840.10045.4.3.3")
                    {
                        return data.Slice(58, 8);
                    }
                    if (value === "1.2.840.10045.4.3.4")
                    {
                        return data.Slice(66, 8);
                    }
                    if (value === "1.2.840.113549.1.1.1")
                    {
                        return data.Slice(74, 9);
                    }
                    if (value === "1.2.840.113549.1.1.5")
                    {
                        return data.Slice(83, 9);
                    }
                    if (value === "1.2.840.113549.1.1.7")
                    {
                        return data.Slice(92, 9);
                    }
                    if (value === "1.2.840.113549.1.1.8")
                    {
                        return data.Slice(101, 9);
                    }
                    if (value === "1.2.840.113549.1.1.9")
                    {
                        return data.Slice(110, 9);
                    }
                    if (value === "1.2.840.113549.1.1.10")
                    {
                        return data.Slice(119, 9);
                    }
                    if (value === "1.2.840.113549.1.1.11")
                    {
                        return data.Slice(128, 9);
                    }
                    if (value === "1.2.840.113549.1.1.12")
                    {
                        return data.Slice(137, 9);
                    }
                    if (value === "1.2.840.113549.1.1.13")
                    {
                        return data.Slice(146, 9);
                    }
                    if (value === "1.2.840.113549.1.5.3")
                    {
                        return data.Slice(155, 9);
                    }
                    if (value === "1.2.840.113549.1.5.10")
                    {
                        return data.Slice(164, 9);
                    }
                    if (value === "1.2.840.113549.1.5.11")
                    {
                        return data.Slice(173, 9);
                    }
                    if (value === "1.2.840.113549.1.5.12")
                    {
                        return data.Slice(182, 9);
                    }
                    if (value === "1.2.840.113549.1.5.13")
                    {
                        return data.Slice(191, 9);
                    }
                    if (value === "1.2.840.113549.1.7.1")
                    {
                        return data.Slice(200, 9);
                    }
                    if (value === "1.2.840.113549.1.7.2")
                    {
                        return data.Slice(209, 9);
                    }
                    if (value === "1.2.840.113549.1.7.3")
                    {
                        return data.Slice(218, 9);
                    }
                    if (value === "1.2.840.113549.1.7.6")
                    {
                        return data.Slice(227, 9);
                    }
                    if (value === "1.2.840.113549.1.9.1")
                    {
                        return data.Slice(236, 9);
                    }
                    if (value === "1.2.840.113549.1.9.3")
                    {
                        return data.Slice(245, 9);
                    }
                    if (value === "1.2.840.113549.1.9.4")
                    {
                        return data.Slice(254, 9);
                    }
                    if (value === "1.2.840.113549.1.9.5")
                    {
                        return data.Slice(263, 9);
                    }
                    if (value === "1.2.840.113549.1.9.6")
                    {
                        return data.Slice(272, 9);
                    }
                    if (value === "1.2.840.113549.1.9.7")
                    {
                        return data.Slice(281, 9);
                    }
                    if (value === "1.2.840.113549.1.9.14")
                    {
                        return data.Slice(290, 9);
                    }
                    if (value === "1.2.840.113549.1.9.15")
                    {
                        return data.Slice(299, 9);
                    }
                    if (value === "1.2.840.113549.1.9.16.1.4")
                    {
                        return data.Slice(308, 11);
                    }
                    if (value === "1.2.840.113549.1.9.16.2.12")
                    {
                        return data.Slice(319, 11);
                    }
                    if (value === "1.2.840.113549.1.9.16.2.14")
                    {
                        return data.Slice(330, 11);
                    }
                    if (value === "1.2.840.113549.1.9.16.2.47")
                    {
                        return data.Slice(341, 11);
                    }
                    if (value === "1.2.840.113549.1.9.20")
                    {
                        return data.Slice(352, 9);
                    }
                    if (value === "1.2.840.113549.1.9.21")
                    {
                        return data.Slice(361, 9);
                    }
                    if (value === "1.2.840.113549.1.9.22.1")
                    {
                        return data.Slice(370, 10);
                    }
                    if (value === "1.2.840.113549.1.12.1.3")
                    {
                        return data.Slice(380, 10);
                    }
                    if (value === "1.2.840.113549.1.12.1.5")
                    {
                        return data.Slice(390, 10);
                    }
                    if (value === "1.2.840.113549.1.12.1.6")
                    {
                        return data.Slice(400, 10);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.1")
                    {
                        return data.Slice(410, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.2")
                    {
                        return data.Slice(421, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.3")
                    {
                        return data.Slice(432, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.5")
                    {
                        return data.Slice(443, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.6")
                    {
                        return data.Slice(454, 11);
                    }
                    if (value === "1.2.840.113549.2.5")
                    {
                        return data.Slice(465, 8);
                    }
                    if (value === "1.2.840.113549.2.7")
                    {
                        return data.Slice(473, 8);
                    }
                    if (value === "1.2.840.113549.2.9")
                    {
                        return data.Slice(481, 8);
                    }
                    if (value === "1.2.840.113549.2.10")
                    {
                        return data.Slice(489, 8);
                    }
                    if (value === "1.2.840.113549.2.11")
                    {
                        return data.Slice(497, 8);
                    }
                    if (value === "1.2.840.113549.3.2")
                    {
                        return data.Slice(505, 8);
                    }
                    if (value === "1.2.840.113549.3.7")
                    {
                        return data.Slice(513, 8);
                    }
                    if (value === "1.3.6.1.4.1.311.17.1")
                    {
                        return data.Slice(521, 9);
                    }
                    if (value === "1.3.6.1.4.1.311.17.3.20")
                    {
                        return data.Slice(530, 10);
                    }
                    if (value === "1.3.6.1.4.1.311.20.2.3")
                    {
                        return data.Slice(540, 10);
                    }
                    if (value === "1.3.6.1.4.1.311.88.2.1")
                    {
                        return data.Slice(550, 10);
                    }
                    if (value === "1.3.6.1.4.1.311.88.2.2")
                    {
                        return data.Slice(560, 10);
                    }
                    if (value === "1.3.6.1.5.5.7.3.1")
                    {
                        return data.Slice(570, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.2")
                    {
                        return data.Slice(578, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.3")
                    {
                        return data.Slice(586, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.4")
                    {
                        return data.Slice(594, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.8")
                    {
                        return data.Slice(602, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.9")
                    {
                        return data.Slice(610, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.6.2")
                    {
                        return data.Slice(618, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.48.1")
                    {
                        return data.Slice(626, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.48.1.2")
                    {
                        return data.Slice(634, 9);
                    }
                    if (value === "1.3.6.1.5.5.7.48.2")
                    {
                        return data.Slice(643, 8);
                    }
                    if (value === "1.3.14.3.2.26")
                    {
                        return data.Slice(651, 5);
                    }
                    if (value === "1.3.14.3.2.7")
                    {
                        return data.Slice(656, 5);
                    }
                    if (value === "1.3.132.0.34")
                    {
                        return data.Slice(661, 5);
                    }
                    if (value === "1.3.132.0.35")
                    {
                        return data.Slice(666, 5);
                    }
                    if (value === "2.5.4.3")
                    {
                        return data.Slice(671, 3);
                    }
                    if (value === "2.5.4.5")
                    {
                        return data.Slice(674, 3);
                    }
                    if (value === "2.5.4.6")
                    {
                        return data.Slice(677, 3);
                    }
                    if (value === "2.5.4.7")
                    {
                        return data.Slice(680, 3);
                    }
                    if (value === "2.5.4.8")
                    {
                        return data.Slice(683, 3);
                    }
                    if (value === "2.5.4.10")
                    {
                        return data.Slice(686, 3);
                    }
                    if (value === "2.5.4.11")
                    {
                        return data.Slice(689, 3);
                    }
                    if (value === "2.5.4.97")
                    {
                        return data.Slice(692, 3);
                    }
                    if (value === "2.5.29.14")
                    {
                        return data.Slice(695, 3);
                    }
                    if (value === "2.5.29.15")
                    {
                        return data.Slice(698, 3);
                    }
                    if (value === "2.5.29.17")
                    {
                        return data.Slice(701, 3);
                    }
                    if (value === "2.5.29.19")
                    {
                        return data.Slice(704, 3);
                    }
                    if (value === "2.5.29.20")
                    {
                        return data.Slice(707, 3);
                    }
                    if (value === "2.5.29.35")
                    {
                        return data.Slice(710, 3);
                    }
                    if (value === "2.16.840.1.101.3.4.1.2")
                    {
                        return data.Slice(713, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.1.22")
                    {
                        return data.Slice(722, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.1.42")
                    {
                        return data.Slice(731, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.2.1")
                    {
                        return data.Slice(740, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.2.2")
                    {
                        return data.Slice(749, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.2.3")
                    {
                        return data.Slice(758, 9);
                    }
                    if (value === "2.23.140.1.2.1")
                    {
                        return data.Slice(767, 6);
                    }
                    if (value === "2.23.140.1.2.2")
                    {
                        return data.Slice(773, 6);
                    }
                    return $.$$.System.ReadOnlySpan$$($.$$.System.Byte).Empty;
                })();
            }
            static $h = 1765230;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"contents","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"GetValue","d":1765230,"h":4296732526,"f":16777256},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"GetContents","d":1765230,"h":8591699822,"f":16777256}],"h":1765230}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.WellKnownOids`; }
        });
        
        $asm.$cls("$sfa.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 1830766;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":1830766,"h":4296798062,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":1830766,"h":8591765358,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":1830766,"h":12886732654,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":1830766,"h":17181699950,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":1830766,"h":21476667246,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityMessage","d":1830766,"h":25771634542,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":1830766,"h":30066601838,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":1830766,"h":34361569134,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":1830766,"h":38656536430,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":1830766,"h":42951503726,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":1830766,"h":47246471022,"f":4194344},{"t":1310721,"n":"ThreadAbortMessage","d":1830766,"h":51541438318,"f":4194344},{"t":1310721,"n":"ThreadResetAbortMessage","d":1830766,"h":55836405614,"f":4194344},{"t":1310721,"n":"ThreadAbortDiagId","d":1830766,"h":60131372910,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":1830766,"h":64426340206,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":1830766,"h":68721307502,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":1830766,"h":73016274798,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":1830766,"h":77311242094,"f":4194344},{"t":1310721,"n":"AuthenticationManagerMessage","d":1830766,"h":81606209390,"f":4194344},{"t":1310721,"n":"AuthenticationManagerDiagId","d":1830766,"h":85901176686,"f":4194344},{"t":1310721,"n":"RemotingApisMessage","d":1830766,"h":90196143982,"f":4194344},{"t":1310721,"n":"RemotingApisDiagId","d":1830766,"h":94491111278,"f":4194344},{"t":1310721,"n":"BinaryFormatterMessage","d":1830766,"h":98786078574,"f":4194344},{"t":1310721,"n":"BinaryFormatterDiagId","d":1830766,"h":103081045870,"f":4194344},{"t":1310721,"n":"CodeBaseMessage","d":1830766,"h":107376013166,"f":4194344},{"t":1310721,"n":"CodeBaseDiagId","d":1830766,"h":111670980462,"f":4194344},{"t":1310721,"n":"EscapeUriStringMessage","d":1830766,"h":115965947758,"f":4194344},{"t":1310721,"n":"EscapeUriStringDiagId","d":1830766,"h":120260915054,"f":4194344},{"t":1310721,"n":"WebRequestMessage","d":1830766,"h":124555882350,"f":4194344},{"t":1310721,"n":"WebRequestDiagId","d":1830766,"h":128850849646,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":1830766,"h":133145816942,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":1830766,"h":137440784238,"f":4194344},{"t":1310721,"n":"GetContextInfoMessage","d":1830766,"h":141735751534,"f":4194344},{"t":1310721,"n":"GetContextInfoDiagId","d":1830766,"h":146030718830,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairMessage","d":1830766,"h":150325686126,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":1830766,"h":154620653422,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":1830766,"h":158915620718,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":1830766,"h":163210588014,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":1830766,"h":167505555310,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":1830766,"h":171800522606,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":1830766,"h":176095489902,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":1830766,"h":180390457198,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":1830766,"h":184685424494,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":1830766,"h":188980391790,"f":4194344},{"t":1310721,"n":"RijndaelMessage","d":1830766,"h":193275359086,"f":4194344},{"t":1310721,"n":"RijndaelDiagId","d":1830766,"h":197570326382,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":1830766,"h":201865293678,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":1830766,"h":206160260974,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":1830766,"h":210455228270,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":1830766,"h":214750195566,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":1830766,"h":219045162862,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":1830766,"h":223340130158,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableMessage","d":1830766,"h":227635097454,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":1830766,"h":231930064750,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyMessage","d":1830766,"h":236225032046,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":1830766,"h":240519999342,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":1830766,"h":244814966638,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":1830766,"h":249109933934,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":1830766,"h":253404901230,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":1830766,"h":257699868526,"f":4194344},{"t":1310721,"n":"UseManagedSha1Message","d":1830766,"h":261994835822,"f":4194344},{"t":1310721,"n":"UseManagedSha1DiagId","d":1830766,"h":266289803118,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":1830766,"h":270584770414,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":1830766,"h":274879737710,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":1830766,"h":279174705006,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":1830766,"h":283469672302,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":1830766,"h":287764639598,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":1830766,"h":292059606894,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":1830766,"h":296354574190,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":1830766,"h":300649541486,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":1830766,"h":304944508782,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":1830766,"h":309239476078,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":1830766,"h":313534443374,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":1830766,"h":317829410670,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersMessage","d":1830766,"h":322124377966,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":1830766,"h":326419345262,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":1830766,"h":330714312558,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":1830766,"h":335009279854,"f":4194344},{"t":1310721,"n":"TlsVersion10and11Message","d":1830766,"h":339304247150,"f":4194344},{"t":1310721,"n":"TlsVersion10and11DiagId","d":1830766,"h":343599214446,"f":4194344},{"t":1310721,"n":"EncryptionPolicyMessage","d":1830766,"h":347894181742,"f":4194344},{"t":1310721,"n":"EncryptionPolicyDiagId","d":1830766,"h":352189149038,"f":4194344},{"t":1310721,"n":"EccXmlExportImportMessage","d":1830766,"h":356484116334,"f":4194344},{"t":1310721,"n":"EccXmlExportImportDiagId","d":1830766,"h":360779083630,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":1830766,"h":365074050926,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":1830766,"h":369369018222,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":1830766,"h":373663985518,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":1830766,"h":377958952814,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryMessage","d":1830766,"h":382253920110,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":1830766,"h":386548887406,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunMessage","d":1830766,"h":390843854702,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":1830766,"h":395138821998,"f":4194344},{"t":1310721,"n":"XmlSecureResolverMessage","d":1830766,"h":399433789294,"f":4194344},{"t":1310721,"n":"XmlSecureResolverDiagId","d":1830766,"h":403728756590,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":1830766,"h":408023723886,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":1830766,"h":412318691182,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":1830766,"h":416613658478,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":1830766,"h":420908625774,"f":4194344},{"t":1310721,"n":"LegacyFormatterMessage","d":1830766,"h":425203593070,"f":4194344},{"t":1310721,"n":"LegacyFormatterDiagId","d":1830766,"h":429498560366,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplMessage","d":1830766,"h":433793527662,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":1830766,"h":438088494958,"f":4194344},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":1830766,"h":442383462254,"f":4194344},{"t":1310721,"n":"RegexExtensibilityDiagId","d":1830766,"h":446678429550,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":1830766,"h":450973396846,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":1830766,"h":455268364142,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":1830766,"h":459563331438,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":1830766,"h":463858298734,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":1830766,"h":468153266030,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":1830766,"h":472448233326,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":1830766,"h":476743200622,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":1830766,"h":481038167918,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":1830766,"h":485333135214,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":1830766,"h":489628102510,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":1830766,"h":493923069806,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":1830766,"h":498218037102,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":1830766,"h":502513004398,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":1830766,"h":506807971694,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":1830766,"h":511102938990,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":1830766,"h":515397906286,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":1830766,"h":519692873582,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":1830766,"h":523987840878,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":1830766,"h":528282808174,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":1830766,"h":532577775470,"f":4194344}],"h":1830766}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$str("$sfa.System.Formats.Asn1.AsnReaderOptions", ($self) => class AsnReaderOptions extends $.$$.System.ValueType
        {
            /*int*/ static DefaultTwoDigitMax = 2049;
            /*ushort*/  get _twoDigitYearMax() { return this.$getField(0, 2); }
            /*ushort*/  set _twoDigitYearMax(value) { this.$setField(0, 2, value); }
            /*int */ get UtcTimeTwoDigitYearMax()
            {
                if (this._twoDigitYearMax === 0)
                {
                    return 2049/*DefaultTwoDigitMax*/;
                }
                return this._twoDigitYearMax;
            }
            /*int */ set UtcTimeTwoDigitYearMax(value)
            {
                if (value < 1 || value > 9999)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("value");
                }
                this._twoDigitYearMax = $.$cast(value, $.$$.System.UInt16);
            }
            /*bool*/ SkipSetSortOrderVerification = false;
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._twoDigitYearMax = this._twoDigitYearMax;
                copy.SkipSetSortOrderVerification = this.SkipSetSortOrderVerification;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._twoDigitYearMax = 0;
                this.SkipSetSortOrderVerification = false;
            }
            static $h = 716654;
            static $z = 3;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180585838,"f":50331649},"s":{"r":0,"d":0,"h":21475553134,"f":83886081},"n":"UtcTimeTwoDigitYearMax","d":716654,"h":12885618542,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":34360455022,"f":50331649},"s":{"r":0,"d":0,"h":38655422318,"f":83886081},"n":"SkipSetSortOrderVerification","d":716654,"h":30065487726,"f":2097153}],"l":[{"t":655361,"n":"DefaultTwoDigitMax","d":716654,"h":4295683950,"f":4194338},{"t":589825,"n":"_twoDigitYearMax","d":716654,"h":8590651246,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":716654,"h":42950389614,"f":16777217}],"h":716654}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Formats.Asn1.AsnReaderOptions`; }
        });
        
        $asm.$str("$sfa.System.Formats.Asn1.Asn1Tag", ($self) => class Asn1Tag extends $.$$.System.ValueType
        {
            /*Asn1Tag*/ static EndOfContents;
            /*Asn1Tag*/ static Boolean;
            /*Asn1Tag*/ static Integer;
            /*Asn1Tag*/ static PrimitiveBitString;
            /*Asn1Tag*/ static ConstructedBitString;
            /*Asn1Tag*/ static PrimitiveOctetString;
            /*Asn1Tag*/ static ConstructedOctetString;
            /*Asn1Tag*/ static Null;
            /*Asn1Tag*/ static ObjectIdentifier;
            /*Asn1Tag*/ static Enumerated;
            /*Asn1Tag*/ static Sequence;
            /*Asn1Tag*/ static SetOf;
            /*Asn1Tag*/ static UtcTime;
            /*Asn1Tag*/ static GeneralizedTime;
            /*byte*/ static ClassMask = 192;
            /*byte*/ static ConstructedMask = 32;
            /*byte*/ static ControlMask = 224;
            /*byte*/ static TagNumberMask = 31;
            /*byte*/  get _controlFlags() { return this.$getField(0, $.$$.System.Byte); }
            /*byte*/  set _controlFlags(value) { this.$setField(0, $.$$.System.Byte, value); }
            /*TagClass */ get TagClass()
            {
                return $.$cast((this._controlFlags & 192/*ClassMask*/), $.$sfa.System.Formats.Asn1.TagClass);
            }
            /*bool */ get IsConstructed()
            {
                return (this._controlFlags & 32/*ConstructedMask*/) !== 0;
            }
            /*int*/ TagValue = 0;
            $ctor$3(/*byte*/ controlFlags, /*int*/ tagValue)
            {
                super.$ctor$1();
                {
                    this._controlFlags = $.$cast((controlFlags & 224/*ControlMask*/), $.$$.System.Byte);
                    this.TagValue = tagValue;
                }
                return this;
            }
            $ctor$5(/*UniversalTagNumber*/ universalTagNumber, /*bool*/ isConstructed)
            {
                this.$ctor$3(isConstructed ? 32/*ConstructedMask*/ : 0, universalTagNumber);
                {
                    /*UniversalTagNumber*/ let ReservedIndex = $.$cast(15, $.$sfa.System.Formats.Asn1.UniversalTagNumber);
                    if (universalTagNumber < 0/*UniversalTagNumber.EndOfContents*/ || universalTagNumber > 36/*UniversalTagNumber.RelativeObjectIdentifierIRI*/ || universalTagNumber === ReservedIndex)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("universalTagNumber");
                    }
                }
                return this;
            }
            $ctor$4(/*TagClass*/ tagClass, /*int*/ tagValue, /*bool*/ isConstructed)
            {
                this.$ctor$3($.$cast(($.$cast(tagClass, $.$$.System.Byte) | (isConstructed ? 32/*ConstructedMask*/ : 0)), $.$$.System.Byte), tagValue);
                {
                    switch(tagClass)
                    {
                        case 0/*TagClass.Universal*/:
                        case 128/*TagClass.ContextSpecific*/:
                        case 64/*TagClass.Application*/:
                        case 192/*TagClass.Private*/:
                        break;
                        default:
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("tagClass");
                    }
                    if (tagValue < 0)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("tagValue");
                    }
                }
                return this;
            }
            /*Asn1Tag */ AsConstructed()
            {
                return new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3($.$cast((this._controlFlags | 32/*ConstructedMask*/), $.$$.System.Byte), this.TagValue);
            }
            /*Asn1Tag */ AsPrimitive()
            {
                return new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3($.$cast((this._controlFlags & ~32/*ConstructedMask*/), $.$$.System.Byte), this.TagValue);
            }
            static /*bool */ TryDecode(/*ReadOnlySpan<byte>*/ source, /*out Asn1Tag*/ tag, /*out int*/ bytesConsumed)
            {
                tag.$v = $.$default($.$sfa.System.Formats.Asn1.Asn1Tag);
                bytesConsumed.$v = 0;
                if (source.IsEmpty)
                {
                    return false;
                }
                /*byte*/ let first = source.get_Item(bytesConsumed.$v).$v;
                bytesConsumed.$v++;
                /*uint*/ let tagValue = ((first & 31/*TagNumberMask*/) >>> 0);
                if (tagValue === 31/*TagNumberMask*/)
                {
                    /*byte*/ let ContinuationFlag = 128;
                    /*byte*/ let ValueMask = ((ContinuationFlag - 1) | 0);
                    tagValue = 0;
                    /*byte*/ let current;
                    do
                    {
                        if (source.Length <= bytesConsumed.$v)
                        {
                            bytesConsumed.$v = 0;
                            return false;
                        }
                        current = source.get_Item(bytesConsumed.$v).$v;
                        /*byte*/ let currentValue = $.$cast((current & ValueMask), $.$$.System.Byte);
                        bytesConsumed.$v++;
                        /*int*/ let TooBigToShift = 33554432;
                        if (tagValue >= TooBigToShift)
                        {
                            bytesConsumed.$v = 0;
                            return false;
                        }
                        tagValue <<= 7;
                        tagValue |= currentValue;
                        if (tagValue === 0)
                        {
                            bytesConsumed.$v = 0;
                            return false;
                        }
                    }
                    while((current & ContinuationFlag) === ContinuationFlag);
                    if (tagValue <= 30)
                    {
                        bytesConsumed.$v = 0;
                        return false;
                    }
                    if (tagValue > 2147483647/*int.MaxValue*/)
                    {
                        bytesConsumed.$v = 0;
                        return false;
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(bytesConsumed.$v > 0, "bytesConsumed > 0");
                tag.$v = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(first, (tagValue | 0));
                return true;
            }
            static /*Asn1Tag */ Decode(/*ReadOnlySpan<byte>*/ source, /*out int*/ bytesConsumed)
            {
                /*Asn1Tag*/ let tag;
                if ($.$sfa.System.Formats.Asn1.Asn1Tag.TryDecode(source, $.$ref(() => tag, ($v) => tag = $v, $.$sfa.System.Formats.Asn1.Asn1Tag), bytesConsumed))
                {
                    return tag;
                }
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$8($.$sfa.System.SR.ContentException_InvalidTag);
            }
            /*int */ CalculateEncodedSize()
            {
                /*int*/ let SevenBits = 127;
                /*int*/ let FourteenBits = 16383;
                /*int*/ let TwentyOneBits = 2097151;
                /*int*/ let TwentyEightBits = 268435455;
                if (this.TagValue < 31/*TagNumberMask*/)
                {
                    return 1;
                }
                if (this.TagValue <= SevenBits)
                {
                    return 2;
                }
                if (this.TagValue <= FourteenBits)
                {
                    return 3;
                }
                if (this.TagValue <= TwentyOneBits)
                {
                    return 4;
                }
                if (this.TagValue <= TwentyEightBits)
                {
                    return 5;
                }
                return 6;
            }
            /*bool */ TryEncode(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                /*int*/ let spaceRequired = this.CalculateEncodedSize();
                if (destination.Length < spaceRequired)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                if (spaceRequired === 1)
                {
                    /*byte*/ let value = $.$cast((this._controlFlags | this.TagValue), $.$$.System.Byte);
                    destination.get_Item(0).$v = value;
                    bytesWritten.$v = 1;
                    return true;
                }
                /*byte*/ let firstByte = $.$cast((this._controlFlags | 31/*TagNumberMask*/), $.$$.System.Byte);
                destination.get_Item(0).$v = firstByte;
                /*int*/ let remaining = this.TagValue;
                /*int*/ let idx = ((spaceRequired - 1) | 0);
                while(remaining > 0)
                {
                    /*int*/ let segment = remaining & 127;
                    if (remaining !== this.TagValue)
                    {
                        segment |= 128;
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(segment <= 255/*byte.MaxValue*/, "segment <= byte.MaxValue");
                    destination.get_Item(idx).$v = $.$cast(segment, $.$$.System.Byte);
                    remaining >>= 7;
                    idx--;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(idx === 0, "idx == 0");
                bytesWritten.$v = spaceRequired;
                return true;
            }
            /*int */ Encode(/*Span<byte>*/ destination)
            {
                /*int*/ let bytesWritten;
                if (this.TryEncode(destination, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32)))
                {
                    return bytesWritten;
                }
                throw new $.$$.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_DestinationTooShort, "destination");
            }
            /*bool */ Equals$2(/*Asn1Tag*/ other)
            {
                return this._controlFlags === other._controlFlags && this.TagValue === other.TagValue;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let tag;
                return $.$is(obj, $.$sfa.System.Formats.Asn1.Asn1Tag, { set $v(v){ tag = v; } }) && this.Equals$2(tag);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sfa.System.Formats.Asn1.Asn1Tag.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return ((this._controlFlags << 24) >>> 0) ^ this.TagValue;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sfa.System.Formats.Asn1.Asn1Tag.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*Asn1Tag*/ left, /*Asn1Tag*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*Asn1Tag*/ left, /*Asn1Tag*/ right)
            {
                return !left.Equals$2(right);
            }
            /*bool */ HasSameClassAndValue(/*Asn1Tag*/ other)
            {
                return this.TagValue === other.TagValue && this.TagClass === other.TagClass;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let ConstructedPrefix = "Constructed ";
                /*string*/ let classAndValue;
                if (this.TagClass === 0/*TagClass.Universal*/)
                {
                    classAndValue = $.$$.System.Enum.ToStringT($.$sfa.System.Formats.Asn1.UniversalTagNumber, $.$$.System.UInt32, ($.$cast(this.TagValue, $.$sfa.System.Formats.Asn1.UniversalTagNumber)));
                }
                else 
                {
                    classAndValue = `${this.TagClass}-${this.TagValue}`;
                }
                if (this.IsConstructed)
                {
                    return ConstructedPrefix + classAndValue;
                }
                return classAndValue;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sfa.System.Formats.Asn1.Asn1Tag.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Formats.Asn1.Asn1Tag>.Equals(System.Formats.Asn1.Asn1Tag)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._controlFlags = this._controlFlags;
                copy.TagValue = this.TagValue;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._controlFlags = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.EndOfContents = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 0/*UniversalTagNumber.EndOfContents*/);
                }
                {
                    this.Boolean = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 1/*UniversalTagNumber.Boolean*/);
                }
                {
                    this.Integer = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 2/*UniversalTagNumber.Integer*/);
                }
                {
                    this.PrimitiveBitString = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 3/*UniversalTagNumber.BitString*/);
                }
                {
                    this.ConstructedBitString = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(32/*ConstructedMask*/, 3/*UniversalTagNumber.BitString*/);
                }
                {
                    this.PrimitiveOctetString = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 4/*UniversalTagNumber.OctetString*/);
                }
                {
                    this.ConstructedOctetString = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(32/*ConstructedMask*/, 4/*UniversalTagNumber.OctetString*/);
                }
                {
                    this.Null = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 5/*UniversalTagNumber.Null*/);
                }
                {
                    this.ObjectIdentifier = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 6/*UniversalTagNumber.ObjectIdentifier*/);
                }
                {
                    this.Enumerated = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 10/*UniversalTagNumber.Enumerated*/);
                }
                {
                    this.Sequence = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(32/*ConstructedMask*/, 16/*UniversalTagNumber.Sequence*/);
                }
                {
                    this.SetOf = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(32/*ConstructedMask*/, 17/*UniversalTagNumber.SetOf*/);
                }
                {
                    this.UtcTime = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 23/*UniversalTagNumber.UtcTime*/);
                }
                {
                    this.GeneralizedTime = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(0, 24/*UniversalTagNumber.GeneralizedTime*/);
                }
            }
            static $h = 126830;
            static $z = 5;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1568622,"g":{"r":0,"d":0,"h":90194440046,"f":50331649},"n":"TagClass","d":126830,"h":85899472750,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":98784374638,"f":50331649},"n":"IsConstructed","d":126830,"h":94489407342,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":111669276526,"f":50331649},"n":"TagValue","d":126830,"h":107374309230,"f":2097153}],"m":[{"r":126830,"n":"AsConstructed","d":126830,"h":128849145710,"f":16777217},{"r":126830,"n":"AsPrimitive","d":126830,"h":133144113006,"f":16777217},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"tag","p":126830,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryDecode","d":126830,"h":137439080302,"f":16777249},{"r":126830,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2}],"n":"Decode","d":126830,"h":141734047598,"f":16777249},{"r":655361,"n":"CalculateEncodedSize","d":126830,"h":146029014894,"f":16777217},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryEncode","d":126830,"h":150323982190,"f":16777217},{"r":655361,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"Encode","d":126830,"h":154618949486,"f":16777217},{"r":262145,"p":[{"n":"other","p":126830}],"n":"Equals","o":"@$2","d":126830,"h":158913916782,"f":16777217},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":126830,"h":163208884078,"f":16809985},{"r":655361,"n":"GetHashCode","d":126830,"h":167503851374,"f":16809985},{"r":262145,"p":[{"n":"other","p":126830}],"n":"HasSameClassAndValue","d":126830,"h":180388753262,"f":16777217},{"r":1310721,"n":"ToString","d":126830,"h":184683720558,"f":16809985}],"l":[{"t":126830,"n":"EndOfContents","d":126830,"h":4295094126,"f":4194344},{"t":126830,"n":"Boolean","d":126830,"h":8590061422,"f":4194337},{"t":126830,"n":"Integer","d":126830,"h":12885028718,"f":4194337},{"t":126830,"n":"PrimitiveBitString","d":126830,"h":17179996014,"f":4194337},{"t":126830,"n":"ConstructedBitString","d":126830,"h":21474963310,"f":4194337},{"t":126830,"n":"PrimitiveOctetString","d":126830,"h":25769930606,"f":4194337},{"t":126830,"n":"ConstructedOctetString","d":126830,"h":30064897902,"f":4194337},{"t":126830,"n":"Null","d":126830,"h":34359865198,"f":4194337},{"t":126830,"n":"ObjectIdentifier","d":126830,"h":38654832494,"f":4194337},{"t":126830,"n":"Enumerated","d":126830,"h":42949799790,"f":4194337},{"t":126830,"n":"Sequence","d":126830,"h":47244767086,"f":4194337},{"t":126830,"n":"SetOf","d":126830,"h":51539734382,"f":4194337},{"t":126830,"n":"UtcTime","d":126830,"h":55834701678,"f":4194337},{"t":126830,"n":"GeneralizedTime","d":126830,"h":60129668974,"f":4194337},{"t":393217,"n":"ClassMask","d":126830,"h":64424636270,"f":4194338},{"t":393217,"n":"ConstructedMask","d":126830,"h":68719603566,"f":4194338},{"t":393217,"n":"ControlMask","d":126830,"h":73014570862,"f":4194338},{"t":393217,"n":"TagNumberMask","d":126830,"h":77309538158,"f":4194338},{"t":393217,"n":"_controlFlags","d":126830,"h":81604505454,"f":4194306}],"c":[{"p":[{"n":"controlFlags","p":393217},{"n":"tagValue","p":655361}],"n":".ctor","o":"$ctor$3","d":126830,"h":115964243822,"f":16777218},{"p":[{"n":"universalTagNumber","p":1634158},{"n":"isConstructed","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$5","d":126830,"h":120259211118,"f":16777217},{"p":[{"n":"tagClass","p":1568622},{"n":"tagValue","p":655361},{"n":"isConstructed","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$4","d":126830,"h":124554178414,"f":16777217},{"n":".ctor","o":"$ctor$2","d":126830,"h":188978687854,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$sfa.System.Formats.Asn1.Asn1Tag).$h],"h":126830}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sfa.System.Formats.Asn1.Asn1Tag) ]; }
            static get $fullName() { return `System.Formats.Asn1.Asn1Tag`; }
        });
        
        $asm.$str("$sfa.System.Security.Cryptography.CryptoPoolLease", ($self) => class CryptoPoolLease extends $.$$.System.ValueType
        {
            /*byte[]?*/  get _rented() { return this.$getField(0, 4); }
            /*byte[]?*/  set _rented(value) { this.$setField(0, 4, value); }
            /*bool*/  get _skipClear() { return this.$getField(4, 1); }
            /*bool*/  set _skipClear(value) { this.$setField(4, 1, value); }
            /*Span<byte>*/ Span;
            /*bool */ get IsRented()
            {
                return !(this._rented === null);
            }
            /*void */ Dispose()
            {
                this.Return();
            }
            /*void */ Return()
            {
                this.Return$1(this._skipClear ? 0 : this.Span.Length);
            }
            /*void */ Return$1(/*int*/ clearSize)
            {
                if (!(this._rented === null))
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(this._rented, clearSize);
                    this._rented = null;
                }
                else if (!this._skipClear && clearSize > 0)
                {
                    /*Span<byte>*/ let toClear = this.Span.Slice(0, clearSize);
                    toClear.Clear();
                }
                this.Span = new ($.$$.System.Span$$($.$$.System.Byte))();
            }
            static /*CryptoPoolLease */ Rent(/*int*/ length, /*bool*/ skipClear)
            {
                /*byte[]*/ let rented = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(length);
                return (() =>
                {
                    //new $.$sfa.System.Security.Cryptography.CryptoPoolLease()
                    const $t1 = $.$sfa.System.Security.Cryptography.CryptoPoolLease;
                    const $i1 = new $t1();
                    $i1._rented = rented;
                    $i1._skipClear = skipClear;
                    $i1.Span = new ($.$$.System.Span$$($.$$.System.Byte))().$ctor$3(rented, 0, length);
                    return $i1;
                })();
            }
            static /*CryptoPoolLease */ RentConditionally(/*int*/ length, /*Span<byte>*/ currentBuffer, /*bool*/ skipClear, /*bool*/ skipClearIfNotRented)
            {
                return $.$sfa.System.Security.Cryptography.CryptoPoolLease.RentConditionally$1(length, currentBuffer, $.$discardRef(), skipClear, skipClearIfNotRented);
            }
            static /*CryptoPoolLease */ RentConditionally$1(/*int*/ length, /*Span<byte>*/ currentBuffer, /*out bool*/ rented, /*bool*/ skipClear, /*bool*/ skipClearIfNotRented)
            {
                if (currentBuffer.Length >= length)
                {
                    rented.$v = false;
                    return (() =>
                    {
                        //new $.$sfa.System.Security.Cryptography.CryptoPoolLease()
                        const $t1 = $.$sfa.System.Security.Cryptography.CryptoPoolLease;
                        const $i1 = new $t1();
                        $i1._rented = null;
                        $i1._skipClear = skipClearIfNotRented || skipClear;
                        $i1.Span = currentBuffer.Slice(0, length);
                        return $i1;
                    })();
                }
                rented.$v = true;
                return $.$sfa.System.Security.Cryptography.CryptoPoolLease.Rent(length, skipClear);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._rented = this._rented;
                copy._skipClear = this._skipClear;
                copy.Span = this.Span.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._rented = null;
                this._skipClear = false;
                this.Span = $.$default($.$$.System.Span$$($.$$.System.Byte));
            }
            static $h = 1961838;
            static $z = 10;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$$.System.Span$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":21476798318,"f":50331656},"s":{"r":0,"d":0,"h":25771765614,"f":83886082},"n":"Span","d":1961838,"h":17181831022,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":34361700206,"f":50331656},"n":"IsRented","d":1961838,"h":30066732910,"f":2097160}],"m":[{"r":65537,"n":"Dispose","d":1961838,"h":38656667502,"f":16777217},{"r":65537,"n":"Return","d":1961838,"h":42951634798,"f":16777224},{"r":65537,"p":[{"n":"clearSize","p":655361}],"n":"Return","o":"@$1","d":1961838,"h":47246602094,"f":16777218},{"r":1961838,"p":[{"n":"length","p":655361},{"n":"skipClear","p":262145,"f":65,"v":false}],"n":"Rent","d":1961838,"h":51541569390,"f":16777256},{"r":1961838,"p":[{"n":"length","p":655361},{"n":"currentBuffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"skipClear","p":262145,"f":65,"v":false},{"n":"skipClearIfNotRented","p":262145,"f":65,"v":false}],"n":"RentConditionally","d":1961838,"h":55836536686,"f":16777256},{"r":1961838,"p":[{"n":"length","p":655361},{"n":"currentBuffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"rented","p":262145,"f":2},{"n":"skipClear","p":262145,"f":65,"v":false},{"n":"skipClearIfNotRented","p":262145,"f":65,"v":false}],"n":"RentConditionally","o":"@$1","d":1961838,"h":60131503982,"f":16777256}],"l":[{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_rented","d":1961838,"h":4296929134,"f":4194306},{"t":262145,"n":"_skipClear","d":1961838,"h":8591896430,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":1961838,"h":64426471278,"f":16777217}],"i":[57540609],"h":1961838}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Security.Cryptography.CryptoPoolLease`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.T61Encoding", ($self) => class T61Encoding extends $.$$.System.Text.Encoding
        {
            /*UTF8Encoding*/ static s_utf8Encoding = null;
            /*Encoding*/ static s_latin1Encoding = null;
            /*int */ GetByteCount(/*char[]*/ chars, /*int*/ index, /*int*/ count)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetByteCount(chars, index, count);
            }
            /*int */ GetByteCount$3(/*char**/ chars, /*int*/ count)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetByteCount$3(chars, count);
            }
            /*int */ GetByteCount$6(/*string*/ s)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetByteCount$6(s);
            }
            /*int */ GetByteCount$4(/*ReadOnlySpan<char>*/ chars)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetByteCount$4(chars);
            }
            /*int */ GetBytes(/*char[]*/ chars, /*int*/ charIndex, /*int*/ charCount, /*byte[]*/ bytes, /*int*/ byteIndex)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetBytes(chars, charIndex, charCount, bytes, byteIndex);
            }
            /*int */ GetBytes$4(/*char**/ chars, /*int*/ charCount, /*byte**/ bytes, /*int*/ byteCount)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetBytes$4(chars, charCount, bytes, byteCount);
            }
            /*int */ GetCharCount(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetCharCount(bytes, index, count);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetCharCount(bytes, index, count);
                }
            }
            /*int */ GetCharCount$3(/*byte**/ bytes, /*int*/ count)
            {
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetCharCount$3(bytes, count);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetCharCount$3(bytes, count);
                }
            }
            /*int */ GetCharCount$4(/*ReadOnlySpan<byte>*/ bytes)
            {
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetCharCount$4(bytes);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetCharCount$4(bytes);
                }
            }
            /*int */ GetChars(/*byte[]*/ bytes, /*int*/ byteIndex, /*int*/ byteCount, /*char[]*/ chars, /*int*/ charIndex)
            {
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetChars(bytes, byteIndex, byteCount, chars, charIndex);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetChars(bytes, byteIndex, byteCount, chars, charIndex);
                }
            }
            /*int */ GetChars$4(/*byte**/ bytes, /*int*/ byteCount, /*char**/ chars, /*int*/ charCount)
            {
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetChars$4(bytes, byteCount, chars, charCount);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetChars$4(bytes, byteCount, chars, charCount);
                }
            }
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetMaxByteCount(charCount);
            }
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                return byteCount;
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$1();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_utf8Encoding = new $.$$.System.Text.UTF8Encoding().$ctor$5(false, true);
                }
                {
                    this.s_latin1Encoding = $.$$.System.Text.Encoding.GetEncoding$3("iso-8859-1");
                }
            }
            static $h = 1503086;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":121700353,"m":[{"r":655361,"p":[{"n":"chars","p":$.$typeArray($.$$.System.Char).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetByteCount","d":1503086,"h":12886404974,"f":16809985},{"r":655361,"p":[{"n":"chars","p":$.$typePointer($.$$.System.Char).$h},{"n":"count","p":655361}],"n":"GetByteCount","o":"@$3","d":1503086,"h":17181372270,"f":16809985},{"r":655361,"p":[{"n":"s","p":1310721}],"n":"GetByteCount","o":"@$6","d":1503086,"h":21476339566,"f":16809985},{"r":655361,"p":[{"n":"chars","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"GetByteCount","o":"@$4","d":1503086,"h":25771306862,"f":16809985},{"r":655361,"p":[{"n":"chars","p":$.$typeArray($.$$.System.Char).$h},{"n":"charIndex","p":655361},{"n":"charCount","p":655361},{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"byteIndex","p":655361}],"n":"GetBytes","d":1503086,"h":30066274158,"f":16809985},{"r":655361,"p":[{"n":"chars","p":$.$typePointer($.$$.System.Char).$h},{"n":"charCount","p":655361},{"n":"bytes","p":$.$typePointer($.$$.System.Byte).$h},{"n":"byteCount","p":655361}],"n":"GetBytes","o":"@$4","d":1503086,"h":34361241454,"f":16809985},{"r":655361,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetCharCount","d":1503086,"h":38656208750,"f":16809985},{"r":655361,"p":[{"n":"bytes","p":$.$typePointer($.$$.System.Byte).$h},{"n":"count","p":655361}],"n":"GetCharCount","o":"@$3","d":1503086,"h":42951176046,"f":16809985},{"r":655361,"p":[{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"GetCharCount","o":"@$4","d":1503086,"h":47246143342,"f":16809985},{"r":655361,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"byteIndex","p":655361},{"n":"byteCount","p":655361},{"n":"chars","p":$.$typeArray($.$$.System.Char).$h},{"n":"charIndex","p":655361}],"n":"GetChars","d":1503086,"h":51541110638,"f":16809985},{"r":655361,"p":[{"n":"bytes","p":$.$typePointer($.$$.System.Byte).$h},{"n":"byteCount","p":655361},{"n":"chars","p":$.$typePointer($.$$.System.Char).$h},{"n":"charCount","p":655361}],"n":"GetChars","o":"@$4","d":1503086,"h":55836077934,"f":16809985},{"r":655361,"p":[{"n":"charCount","p":655361}],"n":"GetMaxByteCount","d":1503086,"h":60131045230,"f":16809985},{"r":655361,"p":[{"n":"byteCount","p":655361}],"n":"GetMaxCharCount","d":1503086,"h":64426012526,"f":16809985}],"l":[{"t":124583937,"n":"s_utf8Encoding","d":1503086,"h":4296470382,"f":4194338},{"t":121700353,"n":"s_latin1Encoding","d":1503086,"h":8591437678,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$4","d":1503086,"h":68720979822,"f":16777217}],"i":[57212929],"h":1503086}; }
            static get $b() { return $.$$.System.Text.Encoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.T61Encoding`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.BMPEncoding", ($self) => class BMPEncoding extends $.$sfa.System.Formats.Asn1.SpanBasedEncoding
        {
            /*int */ GetBytes$9(/*ReadOnlySpan<char>*/ chars, /*Span<byte>*/ bytes, /*bool*/ write)
            {
                if (chars.IsEmpty)
                {
                    return 0;
                }
                /*int*/ let writeIdx = 0;
                for(/*int*/ let i = 0; i < chars.Length; i++)
                {
                    /*char*/ let c = chars.get_Item(i).$v;
                    if ($.$$.System.Char.IsSurrogate(c))
                    {
                        this.EncoderFallback.CreateFallbackBuffer().Fallback$1(c, i);
                        $.$$.System.Diagnostics.Debug.Fail$1("Fallback should have thrown");
                        throw new $.$$.System.InvalidOperationException().$ctor$9();
                    }
                    /*ushort*/ let val16 = c;
                    if (write)
                    {
                        bytes.get_Item(((writeIdx + 1) | 0)).$v = $.$cast(val16, $.$$.System.Byte);
                        bytes.get_Item(writeIdx).$v = $.$cast((val16 >>> 8), $.$$.System.Byte);
                    }
                    writeIdx += 2;
                }
                return writeIdx;
            }
            /*int */ GetChars$6(/*ReadOnlySpan<byte>*/ bytes, /*Span<char>*/ chars, /*bool*/ write)
            {
                if (bytes.IsEmpty)
                {
                    return 0;
                }
                if (bytes.Length % 2 !== 0)
                {
                    this.DecoderFallback.CreateFallbackBuffer().Fallback(bytes.Slice$1(((bytes.Length - 1) | 0)).ToArray(), ((bytes.Length - 1) | 0));
                    $.$$.System.Diagnostics.Debug.Fail$1("Fallback should have thrown");
                    throw new $.$$.System.InvalidOperationException().$ctor$9();
                }
                /*int*/ let writeIdx = 0;
                for(/*int*/ let i = 0; i < bytes.Length; i += 2)
                {
                    /*char*/ let c = $.$cast($.$$.System.Buffers.Binary.BinaryPrimitives.ReadInt16BigEndian(bytes.Slice$1(i)), $.$$.System.Char);
                    if ($.$$.System.Char.IsSurrogate(c))
                    {
                        this.DecoderFallback.CreateFallbackBuffer().Fallback(bytes.Slice(i, 2).ToArray(), i);
                        $.$$.System.Diagnostics.Debug.Fail$1("Fallback should have thrown");
                        throw new $.$$.System.InvalidOperationException().$ctor$9();
                    }
                    if (write)
                    {
                        chars.get_Item(writeIdx).$v = c;
                    }
                    writeIdx++;
                }
                return writeIdx;
            }
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                //checked
                {
                    return $.$checked(charCount * 2, 1);
                }
            }
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                return $.trunc(byteCount / 2);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 1044334;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1437550,"m":[{"r":655361,"p":[{"n":"chars","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"bytes","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"write","p":262145}],"n":"GetBytes","o":"@$9","d":1044334,"h":4296011630,"f":16809988},{"r":655361,"p":[{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"chars","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"write","p":262145}],"n":"GetChars","o":"@$6","d":1044334,"h":8590978926,"f":16809988},{"r":655361,"p":[{"n":"charCount","p":655361}],"n":"GetMaxByteCount","d":1044334,"h":12885946222,"f":16809985},{"r":655361,"p":[{"n":"byteCount","p":655361}],"n":"GetMaxCharCount","d":1044334,"h":17180913518,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$5","d":1044334,"h":21475880814,"f":16777217}],"i":[57212929],"h":1044334}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.SpanBasedEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.BMPEncoding`; }
        });
        
        $asm.$str("$sfa.System.Formats.Asn1.AsnEncodingRules", ($self) => class AsnEncodingRules extends $.$$.System.Enum
        {
            static BER = 0;
            static CER = 1;
            static DER = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "BER": 0n,
                    "CER": 1n,
                    "DER": 2n
                };
            }
            static $h = 585582;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":585582,"n":"BER","d":585582,"h":4295552878,"f":4194337},{"t":585582,"n":"CER","d":585582,"h":8590520174,"f":4194337},{"t":585582,"n":"DER","d":585582,"h":12885487470,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":585582,"h":17180454766,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":585582}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Formats.Asn1.AsnEncodingRules`; }
        });
        
        $asm.$str("$sfa.System.Formats.Asn1.TagClass", ($self) => class TagClass extends $.$$.System.Enum
        {
            static Universal = 0;
            static Application = 64;
            static ContextSpecific = 128;
            static Private = 192;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Universal": 0n,
                    "Application": 64n,
                    "ContextSpecific": 128n,
                    "Private": 192n
                };
            }
            static $h = 1568622;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1568622,"n":"Universal","d":1568622,"h":4296535918,"f":4194337},{"t":1568622,"n":"Application","d":1568622,"h":8591503214,"f":4194337},{"t":1568622,"n":"ContextSpecific","d":1568622,"h":12886470510,"f":4194337},{"t":1568622,"n":"Private","d":1568622,"h":17181437806,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1568622,"h":21476405102,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1568622}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Formats.Asn1.TagClass`; }
        });
        
        $asm.$str("$sfa.System.Formats.Asn1.UniversalTagNumber", ($self) => class UniversalTagNumber extends $.$$.System.Enum
        {
            static EndOfContents = 0;
            static Boolean = 1;
            static Integer = 2;
            static BitString = 3;
            static OctetString = 4;
            static Null = 5;
            static ObjectIdentifier = 6;
            static ObjectDescriptor = 7;
            static External = 8;
            static InstanceOf = 8;
            static Real = 9;
            static Enumerated = 10;
            static Embedded = 11;
            static UTF8String = 12;
            static RelativeObjectIdentifier = 13;
            static Time = 14;
            static Sequence = 16;
            static SequenceOf = 16;
            static Set = 17;
            static SetOf = 17;
            static NumericString = 18;
            static PrintableString = 19;
            static TeletexString = 20;
            static T61String = 20;
            static VideotexString = 21;
            static IA5String = 22;
            static UtcTime = 23;
            static GeneralizedTime = 24;
            static GraphicString = 25;
            static VisibleString = 26;
            static ISO646String = 26;
            static GeneralString = 27;
            static UniversalString = 28;
            static UnrestrictedCharacterString = 29;
            static BMPString = 30;
            static Date = 31;
            static TimeOfDay = 32;
            static DateTime = 33;
            static Duration = 34;
            static ObjectIdentifierIRI = 35;
            static RelativeObjectIdentifierIRI = 36;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "EndOfContents": 0n,
                    "Boolean": 1n,
                    "Integer": 2n,
                    "BitString": 3n,
                    "OctetString": 4n,
                    "Null": 5n,
                    "ObjectIdentifier": 6n,
                    "ObjectDescriptor": 7n,
                    "External": 8n,
                    "InstanceOf": 8n,
                    "Real": 9n,
                    "Enumerated": 10n,
                    "Embedded": 11n,
                    "UTF8String": 12n,
                    "RelativeObjectIdentifier": 13n,
                    "Time": 14n,
                    "Sequence": 16n,
                    "SequenceOf": 16n,
                    "Set": 17n,
                    "SetOf": 17n,
                    "NumericString": 18n,
                    "PrintableString": 19n,
                    "TeletexString": 20n,
                    "T61String": 20n,
                    "VideotexString": 21n,
                    "IA5String": 22n,
                    "UtcTime": 23n,
                    "GeneralizedTime": 24n,
                    "GraphicString": 25n,
                    "VisibleString": 26n,
                    "ISO646String": 26n,
                    "GeneralString": 27n,
                    "UniversalString": 28n,
                    "UnrestrictedCharacterString": 29n,
                    "BMPString": 30n,
                    "Date": 31n,
                    "TimeOfDay": 32n,
                    "DateTime": 33n,
                    "Duration": 34n,
                    "ObjectIdentifierIRI": 35n,
                    "RelativeObjectIdentifierIRI": 36n
                };
            }
            static $h = 1634158;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1634158,"n":"EndOfContents","d":1634158,"h":4296601454,"f":4194337},{"t":1634158,"n":"Boolean","d":1634158,"h":8591568750,"f":4194337},{"t":1634158,"n":"Integer","d":1634158,"h":12886536046,"f":4194337},{"t":1634158,"n":"BitString","d":1634158,"h":17181503342,"f":4194337},{"t":1634158,"n":"OctetString","d":1634158,"h":21476470638,"f":4194337},{"t":1634158,"n":"Null","d":1634158,"h":25771437934,"f":4194337},{"t":1634158,"n":"ObjectIdentifier","d":1634158,"h":30066405230,"f":4194337},{"t":1634158,"n":"ObjectDescriptor","d":1634158,"h":34361372526,"f":4194337},{"t":1634158,"n":"External","d":1634158,"h":38656339822,"f":4194337},{"t":1634158,"n":"InstanceOf","d":1634158,"h":42951307118,"f":4194337},{"t":1634158,"n":"Real","d":1634158,"h":47246274414,"f":4194337},{"t":1634158,"n":"Enumerated","d":1634158,"h":51541241710,"f":4194337},{"t":1634158,"n":"Embedded","d":1634158,"h":55836209006,"f":4194337},{"t":1634158,"n":"UTF8String","d":1634158,"h":60131176302,"f":4194337},{"t":1634158,"n":"RelativeObjectIdentifier","d":1634158,"h":64426143598,"f":4194337},{"t":1634158,"n":"Time","d":1634158,"h":68721110894,"f":4194337},{"t":1634158,"n":"Sequence","d":1634158,"h":73016078190,"f":4194337},{"t":1634158,"n":"SequenceOf","d":1634158,"h":77311045486,"f":4194337},{"t":1634158,"n":"Set","d":1634158,"h":81606012782,"f":4194337},{"t":1634158,"n":"SetOf","d":1634158,"h":85900980078,"f":4194337},{"t":1634158,"n":"NumericString","d":1634158,"h":90195947374,"f":4194337},{"t":1634158,"n":"PrintableString","d":1634158,"h":94490914670,"f":4194337},{"t":1634158,"n":"TeletexString","d":1634158,"h":98785881966,"f":4194337},{"t":1634158,"n":"T61String","d":1634158,"h":103080849262,"f":4194337},{"t":1634158,"n":"VideotexString","d":1634158,"h":107375816558,"f":4194337},{"t":1634158,"n":"IA5String","d":1634158,"h":111670783854,"f":4194337},{"t":1634158,"n":"UtcTime","d":1634158,"h":115965751150,"f":4194337},{"t":1634158,"n":"GeneralizedTime","d":1634158,"h":120260718446,"f":4194337},{"t":1634158,"n":"GraphicString","d":1634158,"h":124555685742,"f":4194337},{"t":1634158,"n":"VisibleString","d":1634158,"h":128850653038,"f":4194337},{"t":1634158,"n":"ISO646String","d":1634158,"h":133145620334,"f":4194337},{"t":1634158,"n":"GeneralString","d":1634158,"h":137440587630,"f":4194337},{"t":1634158,"n":"UniversalString","d":1634158,"h":141735554926,"f":4194337},{"t":1634158,"n":"UnrestrictedCharacterString","d":1634158,"h":146030522222,"f":4194337},{"t":1634158,"n":"BMPString","d":1634158,"h":150325489518,"f":4194337},{"t":1634158,"n":"Date","d":1634158,"h":154620456814,"f":4194337},{"t":1634158,"n":"TimeOfDay","d":1634158,"h":158915424110,"f":4194337},{"t":1634158,"n":"DateTime","d":1634158,"h":163210391406,"f":4194337},{"t":1634158,"n":"Duration","d":1634158,"h":167505358702,"f":4194337},{"t":1634158,"n":"ObjectIdentifierIRI","d":1634158,"h":171800325998,"f":4194337},{"t":1634158,"n":"RelativeObjectIdentifierIRI","d":1634158,"h":176095293294,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1634158,"h":180390260590,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1634158}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Formats.Asn1.UniversalTagNumber`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.IA5Encoding", ($self) => class IA5Encoding extends $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding
        {
            $ctor$7()
            {
                super.$ctor$5(0, 127);
                {
                }
                return this;
            }
            static $h = 1109870;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1306478,"c":[{"n":".ctor","o":"$ctor$7","d":1109870,"h":4296077166,"f":16777224}],"i":[57212929],"h":1109870}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.IA5Encoding`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.VisibleStringEncoding", ($self) => class VisibleStringEncoding extends $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding
        {
            $ctor$7()
            {
                super.$ctor$5(32, 126);
                {
                }
                return this;
            }
            static $h = 1699694;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1306478,"c":[{"n":".ctor","o":"$ctor$7","d":1699694,"h":4296666990,"f":16777224}],"i":[57212929],"h":1699694}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.VisibleStringEncoding`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.NumericStringEncoding", ($self) => class NumericStringEncoding extends $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding
        {
            $ctor$7()
            {
                super.$ctor$6("0123456789 ");
                {
                }
                return this;
            }
            static $h = 1175406;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1306478,"c":[{"n":".ctor","o":"$ctor$7","d":1175406,"h":4296142702,"f":16777224}],"i":[57212929],"h":1175406}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.NumericStringEncoding`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.PrintableStringEncoding", ($self) => class PrintableStringEncoding extends $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding
        {
            $ctor$7()
            {
                super.$ctor$6("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 '()+,-./:=?");
                {
                }
                return this;
            }
            static $h = 1240942;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1306478,"c":[{"n":".ctor","o":"$ctor$7","d":1240942,"h":4296208238,"f":16777224}],"i":[57212929],"h":1240942}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.PrintableStringEncoding`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.SetOfValueComparer", ($self) => class SetOfValueComparer extends $.$$.System.Object
        {
            /*SetOfValueComparer*/ static Instance = null;
            /*int */ Compare(/*ReadOnlyMemory<byte>*/ x, /*ReadOnlyMemory<byte>*/ y)
            {
                return $.$sfa.System.Formats.Asn1.SetOfValueComparer.Compare$1(x.Span, y.Span);
            }
            static /*int */ Compare$1(/*ReadOnlySpan<byte>*/ x, /*ReadOnlySpan<byte>*/ y)
            {
                /*int*/ let min = $.$$.System.Math.Min$4(x.Length, y.Length);
                /*int*/ let diff;
                /*int*/ let diffIndex = $.$$.System.MemoryExtensions.CommonPrefixLength$1($.$$.System.Byte, x, y);
                if (diffIndex !== min)
                {
                    return (($.$cast(x.get_Item(diffIndex).$v, $.$$.System.Int32) - y.get_Item(diffIndex).$v) | 0);
                }
                diff = ((x.Length - y.Length) | 0);
                return diff;
            }
            //Generated interface implemetation for System.Collections.Generic.IComparer<System.ReadOnlyMemory<byte>>.Compare(System.ReadOnlyMemory<byte>, System.ReadOnlyMemory<byte>)
            System$Collections$Generic$IComparer$$$Compare()
            {
                return this.Compare(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sfa.System.Formats.Asn1.SetOfValueComparer().$ctor$1();
                }
            }
            static $h = 1372014;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1372014,"g":{"r":0,"d":0,"h":12886273902,"f":50331688},"n":"Instance","d":1372014,"h":8591306606,"f":2097192}],"m":[{"r":655361,"p":[{"n":"x","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"y","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h}],"n":"Compare","d":1372014,"h":17181241198,"f":16777217},{"r":655361,"p":[{"n":"x","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"y","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"Compare","o":"@$1","d":1372014,"h":21476208494,"f":16777256}],"c":[{"n":".ctor","o":"$ctor$1","d":1372014,"h":25771175790,"f":16777217}],"i":[$.$$.System.Collections.Generic.IComparer$$($.$$.System.ReadOnlyMemory$$($.$$.System.Byte)).$h],"h":1372014}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IComparer$$($.$$.System.ReadOnlyMemory$$($.$$.System.Byte)) ]; }
            static get $fullName() { return `System.Formats.Asn1.SetOfValueComparer`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.AsnContentException", ($self) => class AsnContentException extends $.$$.System.Exception
        {
            $ctor$5()
            {
                super.$ctor$4($.$sfa.System.SR.ContentException_DefaultMessage);
                {
                }
                return this;
            }
            $ctor$8(/*string?*/ message)
            {
                super.$ctor$4(message ?? $.$sfa.System.SR.ContentException_DefaultMessage);
                {
                }
                return this;
            }
            $ctor$7(/*string?*/ message, /*Exception?*/ inner)
            {
                super.$ctor$3(message ?? $.$sfa.System.SR.ContentException_DefaultMessage, inner);
                {
                }
                return this;
            }
            $ctor$6(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$2(info, context);
                {
                }
                return this;
            }
            static $h = 257902;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47251457,"h":257902}; }
            static get $b() { return $.$$.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Formats.Asn1.AsnContentException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Numerics", "NetJs.System.Text.Encoding.Extensions"))