
(function ($global, $, $spc, $sc, $sdt, $sm, $spu, $sri, $stee, $st, $sr, $scc, $srn, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Formats.Asn1", 
    {"h":53400,"f":"System.Formats.Asn1","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Formats.Asn1","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Formats.Asn1","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sfa.System.Formats.Asn1.SpanBasedEncoding", ($self) => class SpanBasedEncoding extends $.$spc.System.Text.Encoding
        {
            $ctor$4()
            {
                super.$ctor$3(0, $.$spc.System.Text.EncoderFallback.ExceptionFallback, $.$spc.System.Text.DecoderFallback.ExceptionFallback);
                {
                }
                return this;
            }
            /*int */ GetByteCount$2(/*char[]*/ chars, /*int*/ index, /*int*/ count)
            {
                return this.GetByteCount$5(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$3(chars, index, count));
            }
            /*int */ GetByteCount$4(/*char**/ chars, /*int*/ count)
            {
                return this.GetByteCount$5(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(chars, count));
            }
            /*int */ GetByteCount$1(/*string*/ s)
            {
                return this.GetByteCount$5($.$spc.System.MemoryExtensions.AsSpan$3(s));
            }
            /*int */ GetByteCount$5(/*ReadOnlySpan<char>*/ chars)
            {
                return this.GetBytes$9(chars, $.$spc.System.Span$$($.$spc.System.Byte).Empty, false);
            }
            /*int */ GetBytes$2(/*char[]*/ chars, /*int*/ charIndex, /*int*/ charCount, /*byte[]*/ bytes, /*int*/ byteIndex)
            {
                return this.GetBytes$9(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$3(chars, charIndex, charCount), new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$3(bytes, byteIndex, ((bytes.length - byteIndex) | 0)), true);
            }
            /*int */ GetBytes$6(/*char**/ chars, /*int*/ charCount, /*byte**/ bytes, /*int*/ byteCount)
            {
                return this.GetBytes$9(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))().$ctor$4(chars, charCount), new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4(bytes, byteCount), true);
            }
            /*int */ GetCharCount$1(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                return this.GetCharCount$3(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$3(bytes, index, count));
            }
            /*int */ GetCharCount$2(/*byte**/ bytes, /*int*/ count)
            {
                return this.GetCharCount$3(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$4(bytes, count));
            }
            /*int */ GetCharCount$3(/*ReadOnlySpan<byte>*/ bytes)
            {
                return this.GetChars$6(bytes, $.$spc.System.Span$$($.$spc.System.Char).Empty, false);
            }
            /*int */ GetChars$2(/*byte[]*/ bytes, /*int*/ byteIndex, /*int*/ byteCount, /*char[]*/ chars, /*int*/ charIndex)
            {
                return this.GetChars$6(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$3(bytes, byteIndex, byteCount), new ($.$spc.System.Span$$($.$spc.System.Char))().$ctor$3(chars, charIndex, ((chars.length - charIndex) | 0)), true);
            }
            /*int */ GetChars$3(/*byte**/ bytes, /*int*/ byteCount, /*char**/ chars, /*int*/ charCount)
            {
                return this.GetChars$6(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$4(bytes, byteCount), new ($.$spc.System.Span$$($.$spc.System.Char))().$ctor$4(chars, charCount), true);
            }
            static $h = 1429656;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":121831425,"m":[{"r":655361,"p":[{"n":"chars","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"bytes","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"write","p":262145}],"n":"GetBytes","o":"@$9","d":1429656,"h":8591364248,"f":260},{"r":655361,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"chars","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"write","p":262145}],"n":"GetChars","o":"@$6","d":1429656,"h":12886331544,"f":260},{"r":655361,"p":[{"n":"chars","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetByteCount","o":"@$2","d":1429656,"h":17181298840,"f":32769},{"r":655361,"p":[{"n":"chars","p":0},{"n":"count","p":655361}],"n":"GetByteCount","o":"@$4","d":1429656,"h":21476266136,"f":32769},{"r":655361,"p":[{"n":"s","p":1310721}],"n":"GetByteCount","o":"@$1","d":1429656,"h":25771233432,"f":32769},{"r":655361,"p":[{"n":"chars","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"GetByteCount","o":"@$5","d":1429656,"h":30066200728,"f":32769},{"r":655361,"p":[{"n":"chars","p":0},{"n":"charIndex","p":655361},{"n":"charCount","p":655361},{"n":"bytes","p":0},{"n":"byteIndex","p":655361}],"n":"GetBytes","o":"@$2","d":1429656,"h":34361168024,"f":32769},{"r":655361,"p":[{"n":"chars","p":0},{"n":"charCount","p":655361},{"n":"bytes","p":0},{"n":"byteCount","p":655361}],"n":"GetBytes","o":"@$6","d":1429656,"h":38656135320,"f":32769},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetCharCount","o":"@$1","d":1429656,"h":42951102616,"f":32769},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"count","p":655361}],"n":"GetCharCount","o":"@$2","d":1429656,"h":47246069912,"f":32769},{"r":655361,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"GetCharCount","o":"@$3","d":1429656,"h":51541037208,"f":32769},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"byteIndex","p":655361},{"n":"byteCount","p":655361},{"n":"chars","p":0},{"n":"charIndex","p":655361}],"n":"GetChars","o":"@$2","d":1429656,"h":55836004504,"f":32769},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"byteCount","p":655361},{"n":"chars","p":0},{"n":"charCount","p":655361}],"n":"GetChars","o":"@$3","d":1429656,"h":60130971800,"f":32769}],"c":[{"n":".ctor","o":"$ctor$4","d":1429656,"h":4296396952,"f":4}],"i":[57147393],"h":1429656}; }
            static get $b() { return $.$spc.System.Text.Encoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.SpanBasedEncoding`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding", ($self) => class RestrictedAsciiStringEncoding extends $.$sfa.System.Formats.Asn1.SpanBasedEncoding
        {
            /*bool[]*/ _isAllowed = null;
            $ctor$5(/*byte*/ minCharAllowed, /*byte*/ maxCharAllowed)
            {
                super.$ctor$4();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(minCharAllowed <= maxCharAllowed, "minCharAllowed <= maxCharAllowed");
                    $.$spc.System.Diagnostics.Debug.Assert$1(maxCharAllowed <= 127, "maxCharAllowed <= 0x7F");
                    /*bool[]*/ let isAllowed = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Boolean), null, [128], null);
                    $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Boolean, isAllowed, minCharAllowed, ((maxCharAllowed - minCharAllowed + 1) | 0)).Fill(true);
                    this._isAllowed = isAllowed;
                }
                return this;
            }
            $ctor$6(/*string*/ allowedChars)
            {
                super.$ctor$4();
                {
                    /*bool[]*/ let isAllowed = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Boolean), null, [127], null);
                    var $en3 = $.$spc.System.String.GetEnumerator.call(allowedChars);
                    while ($en3.MoveNext())
                    {
                        var c = $en3.Current;
                        {
                            if (c >= isAllowed.length)
                            {
                                throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("allowedChars");
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Array.$ReadT1.call(isAllowed, c) === false, "isAllowed[c] == false");
                            $.$spc.System.Array.$WriteT1.call(isAllowed, true, c);
                        }
                    }
                    this._isAllowed = isAllowed;
                }
                return this;
            }
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                return charCount;
            }
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                return byteCount;
            }
            /*int */ GetBytes$9(/*ReadOnlySpan<char>*/ chars, /*Span<byte>*/ bytes, /*bool*/ write)
            {
                if (chars.IsEmpty)
                {
                    return 0;
                }
                for(/*int*/ let i = 0; i < chars.Length; i++)
                {
                    /*char*/ let c = chars.get_Item(i).$v;
                    if (c >= (this._isAllowed.length >>> 0) || !$.$spc.System.Array.$ReadT1.call(this._isAllowed, c))
                    {
                        this.EncoderFallback.CreateFallbackBuffer().Fallback(c, i);
                        $.$spc.System.Diagnostics.Debug.Fail("Fallback should have thrown");
                        throw new $.$spc.System.InvalidOperationException().$ctor$9();
                    }
                    if (write)
                    {
                        bytes.get_Item(i).$v = $.$cast(c, $.$spc.System.Byte);
                    }
                }
                return chars.Length;
            }
            /*int */ GetChars$6(/*ReadOnlySpan<byte>*/ bytes, /*Span<char>*/ chars, /*bool*/ write)
            {
                if (bytes.IsEmpty)
                {
                    return 0;
                }
                for(/*int*/ let i = 0; i < bytes.Length; i++)
                {
                    /*byte*/ let b = bytes.get_Item(i).$v;
                    if (b >= (this._isAllowed.length >>> 0) || !$.$spc.System.Array.$ReadT1.call(this._isAllowed, b))
                    {
                        this.DecoderFallback.CreateFallbackBuffer().Fallback($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), [b], null, null), i);
                        $.$spc.System.Diagnostics.Debug.Fail("Fallback should have thrown");
                        throw new $.$spc.System.InvalidOperationException().$ctor$9();
                    }
                    if (write)
                    {
                        chars.get_Item(i).$v = b;
                    }
                }
                return bytes.Length;
            }
            static $h = 1298584;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1429656,"m":[{"r":655361,"p":[{"n":"charCount","p":655361}],"n":"GetMaxByteCount","d":1298584,"h":17181167768,"f":32769},{"r":655361,"p":[{"n":"byteCount","p":655361}],"n":"GetMaxCharCount","d":1298584,"h":21476135064,"f":32769},{"r":655361,"p":[{"n":"chars","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"bytes","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"write","p":262145}],"n":"GetBytes","o":"@$9","d":1298584,"h":25771102360,"f":32772},{"r":655361,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"chars","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"write","p":262145}],"n":"GetChars","o":"@$6","d":1298584,"h":30066069656,"f":32772}],"l":[{"t":0,"n":"_isAllowed","d":1298584,"h":4296265880,"f":2}],"c":[{"p":[{"n":"minCharAllowed","p":393217},{"n":"maxCharAllowed","p":393217}],"n":".ctor","o":"$ctor$5","d":1298584,"h":8591233176,"f":4},{"p":[{"n":"allowedChars","p":1310721}],"n":".ctor","o":"$ctor$6","d":1298584,"h":12886200472,"f":4}],"i":[57147393],"h":1298584}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.SpanBasedEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.RestrictedAsciiStringEncoding`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.AsnCharacterStringEncodings", ($self) => class AsnCharacterStringEncodings
        {
            /*UTF8Encoding*/ static s_utf8Encoding = null;
            /*BMPEncoding*/ static s_bmpEncoding = null;
            /*IA5Encoding*/ static s_ia5Encoding = null;
            /*VisibleStringEncoding*/ static s_visibleStringEncoding = null;
            /*NumericStringEncoding*/ static s_numericStringEncoding = null;
            /*PrintableStringEncoding*/ static s_printableStringEncoding = null;
            /*T61Encoding*/ static s_t61Encoding = null;
            static /*Encoding */ GetEncoding(/*UniversalTagNumber*/ encodingType)
            {
                return (() =>
                {
                    if (encodingType === 12/*UniversalTagNumber.UTF8String*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_utf8Encoding;
                    }
                    if (encodingType === 18/*UniversalTagNumber.NumericString*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_numericStringEncoding;
                    }
                    if (encodingType === 19/*UniversalTagNumber.PrintableString*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_printableStringEncoding;
                    }
                    if (encodingType === 22/*UniversalTagNumber.IA5String*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_ia5Encoding;
                    }
                    if (encodingType === 26/*UniversalTagNumber.VisibleString*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_visibleStringEncoding;
                    }
                    if (encodingType === 30/*UniversalTagNumber.BMPString*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_bmpEncoding;
                    }
                    if (encodingType === 20/*UniversalTagNumber.T61String*/)
                    {
                        return $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.s_t61Encoding;
                    }
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("encodingType", $.$box(encodingType, $.$sfa.System.Formats.Asn1.UniversalTagNumber), null);
                })();
            }
            static /*int */ GetByteCount(/*this Encoding*/ encoding, /*ReadOnlySpan<char>*/ str)
            {
                if (str.IsEmpty)
                {
                    str = $.$spc.System.MemoryExtensions.AsSpan$3($.$spc.System.String.Empty);
                }
                {
                    /*fixed*/ 
                    {
                        /*char**/ let strPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Char, str);
                        return encoding.GetByteCount$4(strPtr, str.Length);
                    }
                }
            }
            static /*int */ GetBytes(/*this Encoding*/ encoding, /*ReadOnlySpan<char>*/ chars, /*Span<byte>*/ bytes)
            {
                if (chars.IsEmpty)
                {
                    chars = $.$spc.System.MemoryExtensions.AsSpan$3($.$spc.System.String.Empty);
                }
                if (bytes.IsEmpty)
                {
                    bytes = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit($.$spc.System.Array.Empty($.$spc.System.Byte));
                }
                {
                    /*fixed*/ 
                    {
                        /*char**/ let charsPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Char, chars);
                        /*fixed*/ 
                        {
                            /*byte**/ let bytesPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, bytes);
                            return encoding.GetBytes$6(charsPtr, chars.Length, bytesPtr, bytes.Length);
                        }
                    }
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_utf8Encoding = new $.$spc.System.Text.UTF8Encoding().$ctor$6(false, true);
                }
                {
                    this.s_bmpEncoding = new $.$sfa.System.Formats.Asn1.BMPEncoding().$ctor$5();
                }
                {
                    this.s_ia5Encoding = new $.$sfa.System.Formats.Asn1.IA5Encoding().$ctor$7();
                }
                {
                    this.s_visibleStringEncoding = new $.$sfa.System.Formats.Asn1.VisibleStringEncoding().$ctor$7();
                }
                {
                    this.s_numericStringEncoding = new $.$sfa.System.Formats.Asn1.NumericStringEncoding().$ctor$7();
                }
                {
                    this.s_printableStringEncoding = new $.$sfa.System.Formats.Asn1.PrintableStringEncoding().$ctor$7();
                }
                {
                    this.s_t61Encoding = new $.$sfa.System.Formats.Asn1.T61Encoding().$ctor$4();
                }
            }
            static $h = 184472;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":121831425,"p":[{"n":"encodingType","p":1626264}],"n":"GetEncoding","d":184472,"h":34359922840,"f":40},{"r":655361,"p":[{"n":"encoding","p":121831425},{"n":"str","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"GetByteCount","d":184472,"h":38654890136,"f":40},{"r":655361,"p":[{"n":"encoding","p":121831425},{"n":"chars","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"bytes","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetBytes","d":184472,"h":42949857432,"f":40}],"l":[{"t":124715009,"n":"s_utf8Encoding","d":184472,"h":4295151768,"f":34},{"t":1036440,"n":"s_bmpEncoding","d":184472,"h":8590119064,"f":34},{"t":1101976,"n":"s_ia5Encoding","d":184472,"h":12885086360,"f":34},{"t":1691800,"n":"s_visibleStringEncoding","d":184472,"h":17180053656,"f":34},{"t":1167512,"n":"s_numericStringEncoding","d":184472,"h":21475020952,"f":34},{"t":1233048,"n":"s_printableStringEncoding","d":184472,"h":25769988248,"f":34},{"t":1495192,"n":"s_t61Encoding","d":184472,"h":30064955544,"f":34}],"h":184472}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.AsnCharacterStringEncodings`; }
        });
        
        $asm.$cls("$sfa.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sfa.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Formats.Asn1", $.$sfa.System.SR.$type.Assembly);
                    $.$sfa.System.SR.s_resourceManager = temp;
                }
                return $.$sfa.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sfa.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sfa.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_DestinationTooShort()
            {
                return "Destination is too short.";
            }
            static /*string */ get Argument_EnumeratedValueRequiresNonFlagsEnum()
            {
                return "ASN.1 Enumerated values only apply to enum types without the [Flags] attribute.";
            }
            static /*string */ get Argument_EnumeratedValueBackingTypeNotSupported()
            {
                return "Enumerations with a backing type of '{0}' are not supported for ReadEnumeratedValue.";
            }
            static /*string */ FormatArgument_EnumeratedValueBackingTypeNotSupported(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Enumerations with a backing type of '{0}' are not supported for ReadEnumeratedValue.", arg1);
            }
            static /*string */ get Argument_InvalidOidValue()
            {
                return "The OID value is invalid.";
            }
            static /*string */ get Argument_NamedBitListRequiresFlagsEnum()
            {
                return "Named bit list operations require an enum with the [Flags] attribute.";
            }
            static /*string */ get Argument_SourceOverlapsDestination()
            {
                return "The destination buffer overlaps the source buffer.";
            }
            static /*string */ get Argument_Tag_NotCharacterString()
            {
                return "The specified tag has the Universal TagClass, but the TagValue does not correspond with a known character string type.";
            }
            static /*string */ get Argument_IntegerCannotBeEmpty()
            {
                return "An integer value cannot be empty.";
            }
            static /*string */ get Argument_IntegerRedundantByte()
            {
                return "The first 9 bits of the integer value all have the same value. Ensure the input is in big-endian byte order and that all redundant leading bytes have been removed.";
            }
            static /*string */ get Argument_UniversalValueIsFixed()
            {
                return "Tags with TagClass Universal must have the appropriate TagValue value for the data type being read or written.";
            }
            static /*string */ get Argument_UnusedBitCountMustBeZero()
            {
                return "Unused bit count must be 0 when the bit string is empty.";
            }
            static /*string */ get Argument_UnusedBitCountRange()
            {
                return "Unused bit count must be between 0 and 7, inclusive.";
            }
            static /*string */ get Argument_UnusedBitWasSet()
            {
                return "One or more of the bits covered by the provided unusedBitCount value is set. All unused bits must be cleared.";
            }
            static /*string */ get Argument_WriteEncodedValue_OneValueAtATime()
            {
                return "The input to WriteEncodedValue must represent a single encoded value with no trailing data.";
            }
            static /*string */ get ArgumentOutOfRange_NeedNonNegNum()
            {
                return "Non-negative number required.";
            }
            static /*string */ get AsnWriter_EncodeUnbalancedStack()
            {
                return "Encode cannot be called while a Sequence, Set-Of, or Octet String is still open.";
            }
            static /*string */ get AsnWriter_ModifyingWhileEncoding()
            {
                return "The AsnWriter cannot be written to while performing the Encode callback.";
            }
            static /*string */ get AsnWriter_PopWrongTag()
            {
                return "Cannot pop the requested tag as it is not currently in progress.";
            }
            static /*string */ get ContentException_CerRequiresIndefiniteLength()
            {
                return "A constructed tag used a definite length encoding, which is invalid for CER data. The input may be encoded with BER or DER.";
            }
            static /*string */ get ContentException_ConstructedEncodingRequired()
            {
                return "The encoded value uses a primitive encoding, which is invalid for '{0}' values.";
            }
            static /*string */ FormatContentException_ConstructedEncodingRequired(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The encoded value uses a primitive encoding, which is invalid for '{0}' values.", arg1);
            }
            static /*string */ get ContentException_DefaultMessage()
            {
                return "The ASN.1 value is invalid.";
            }
            static /*string */ get ContentException_EnumeratedValueTooBig()
            {
                return "The encoded enumerated value is larger than the value size of the '{0}' enum.";
            }
            static /*string */ FormatContentException_EnumeratedValueTooBig(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The encoded enumerated value is larger than the value size of the '{0}' enum.", arg1);
            }
            static /*string */ get ContentException_InvalidUnderCer_TryBerOrDer()
            {
                return "The encoded value is not valid under the selected encoding, but it may be valid under the BER or DER encoding.";
            }
            static /*string */ get ContentException_InvalidUnderCerOrDer_TryBer()
            {
                return "The encoded value is not valid under the selected encoding, but it may be valid under the BER encoding.";
            }
            static /*string */ get ContentException_InvalidUnderDer_TryBerOrCer()
            {
                return "The encoded value is not valid under the selected encoding, but it may be valid under the BER or CER encoding.";
            }
            static /*string */ get ContentException_InvalidTag()
            {
                return "The provided data does not represent a valid tag.";
            }
            static /*string */ get ContentException_LengthExceedsPayload()
            {
                return "The encoded length exceeds the number of bytes remaining in the input buffer.";
            }
            static /*string */ get ContentException_LengthRuleSetConstraint()
            {
                return "The encoded length is not valid under the requested encoding rules, the value may be valid under the BER encoding.";
            }
            static /*string */ get ContentException_LengthTooBig()
            {
                return "The encoded length exceeds the maximum supported by this library (Int32.MaxValue).";
            }
            static /*string */ get ContentException_NamedBitListValueTooBig()
            {
                return "The encoded named bit list value is larger than the value size of the '{0}' enum.";
            }
            static /*string */ FormatContentException_NamedBitListValueTooBig(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The encoded named bit list value is larger than the value size of the '{0}' enum.", arg1);
            }
            static /*string */ get ContentException_OidTooBig()
            {
                return "The encoded object identifier (OID) exceeds the limits supported by this library. Supported OIDs are limited to 64 arcs and each subidentifier is limited to a 128-bit value.";
            }
            static /*string */ get ContentException_PrimitiveEncodingRequired()
            {
                return "The encoded value uses a constructed encoding, which is invalid for '{0}' values.";
            }
            static /*string */ FormatContentException_PrimitiveEncodingRequired(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The encoded value uses a constructed encoding, which is invalid for '{0}' values.", arg1);
            }
            static /*string */ get ContentException_SetOfNotSorted()
            {
                return "The encoded set is not sorted as required by the current encoding rules. The value may be valid under the BER encoding, or you can ignore the sort validation by specifying skipSortValidation=true.";
            }
            static /*string */ get ContentException_TooMuchData()
            {
                return "The last expected value has been read, but the reader still has pending data. This value may be from a newer schema, or is corrupt.";
            }
            static /*string */ get ContentException_WrongTag()
            {
                return "The provided data is tagged with '{0}' class value '{1}', but it should have been '{2}' class value '{3}'.";
            }
            static /*string */ FormatContentException_WrongTag(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                return $.$spc.System.String.Format$4("The provided data is tagged with '{0}' class value '{1}', but it should have been '{2}' class value '{3}'.", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg1, arg2, arg3, arg4 ]));
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sfa.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sfa.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sfa.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sfa.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sfa.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sfa.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sfa.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2019480;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2019480}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.AsnDecoder", ($self) => class AsnDecoder
        {
            /*int*/ static MaxCERSegmentSize = 1000;
            /*int*/ static EndOfContentsEncodedLength = 2;
            static /*bool */ TryReadEncodedValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out Asn1Tag*/ tag, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed)
            {
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*Asn1Tag*/ let localTag;
                /*int*/ let tagLength;
                /*int?*/ let encodedLength;
                /*int*/ let lengthLength;
                if ($.$sfa.System.Formats.Asn1.Asn1Tag.TryDecode(source, $.$ref(() => localTag, ($v) => localTag = $v, $.$sfa.System.Formats.Asn1.Asn1Tag), $.$ref(() => tagLength, ($v) => tagLength = $v, $.$spc.System.Int32)) && $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadLength(source.Slice(tagLength), ruleSet, $.$ref(() => encodedLength, ($v) => encodedLength = $v, $.$typeNullable($.$spc.System.Int32)), $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$spc.System.Int32)))
                {
                    /*int*/ let headerLength = ((tagLength + lengthLength) | 0);
                    /*int*/ let len;
                    /*int*/ let consumed;
                    /*LengthValidity*/ let validity = $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateLength(source.Slice(headerLength), ruleSet, localTag, encodedLength, $.$ref(() => len, ($v) => len = $v, $.$spc.System.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32));
                    if (validity === 3/*LengthValidity.Valid*/)
                    {
                        tag.$v = localTag;
                        contentOffset.$v = headerLength;
                        contentLength.$v = len;
                        bytesConsumed.$v = ((headerLength + consumed) | 0);
                        return true;
                    }
                }
                tag.$v = new $.$sfa.System.Formats.Asn1.Asn1Tag();
                contentOffset.$v = contentLength.$v = bytesConsumed.$v = 0;
                return false;
            }
            static /*Asn1Tag */ ReadEncodedValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed)
            {
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*int*/ let tagLength;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.Asn1Tag.Decode(source, $.$ref(() => tagLength, ($v) => tagLength = $v, $.$spc.System.Int32));
                /*int*/ let lengthLength;
                /*int?*/ let encodedLength = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadLength(source.Slice(tagLength), ruleSet, $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$spc.System.Int32));
                /*int*/ let headerLength = ((tagLength + lengthLength) | 0);
                /*int*/ let len;
                /*int*/ let consumed;
                /*LengthValidity*/ let validity = $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateLength(source.Slice(headerLength), ruleSet, tag, encodedLength, $.$ref(() => len, ($v) => len = $v, $.$spc.System.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32));
                if (validity === 3/*LengthValidity.Valid*/)
                {
                    contentOffset.$v = headerLength;
                    contentLength.$v = len;
                    bytesConsumed.$v = ((headerLength + consumed) | 0);
                    return tag;
                }
                throw $.$sfa.System.Formats.Asn1.AsnDecoder.GetValidityException(validity);
            }
            static /*ReadOnlySpan<byte> */ GetPrimitiveContentSpan(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out int*/ bytesConsumed)
            {
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*int*/ let tagLength;
                /*Asn1Tag*/ let localTag = $.$sfa.System.Formats.Asn1.Asn1Tag.Decode(source, $.$ref(() => tagLength, ($v) => tagLength = $v, $.$spc.System.Int32));
                /*int*/ let lengthLength;
                /*int?*/ let encodedLength = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadLength(source.Slice(tagLength), ruleSet, $.$ref(() => lengthLength, ($v) => lengthLength = $v, $.$spc.System.Int32));
                /*int*/ let headerLength = ((tagLength + lengthLength) | 0);
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(localTag, expectedTag, tagNumber);
                if (localTag.IsConstructed)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.Format($.$sfa.System.SR.ContentException_PrimitiveEncodingRequired, $.$box(tagNumber, $.$sfa.System.Formats.Asn1.UniversalTagNumber)));
                }
                if (encodedLength === null)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*ReadOnlySpan<byte>*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(source, headerLength, $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(encodedLength));
                bytesConsumed.$v = ((headerLength + ret.Length) | 0);
                return ret;
            }
            static /*int? */ DecodeLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed)
            {
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*int*/ let read;
                /*int?*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadLength(source, ruleSet, $.$ref(() => read, ($v) => read = $v, $.$spc.System.Int32));
                bytesConsumed.$v = read;
                return ret;
            }
            static /*bool */ TryDecodeLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ decodedLength, /*out int*/ bytesConsumed)
            {
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                /*int?*/ let decoded;
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadLength(source, ruleSet, $.$ref(() => decoded, ($v) => decoded = $v, $.$typeNullable($.$spc.System.Int32)), $.$ref(() => read, ($v) => read = $v, $.$spc.System.Int32));
                bytesConsumed.$v = read;
                decodedLength.$v = decoded;
                return ret;
            }
            static /*bool */ TryReadLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ length, /*out int*/ bytesRead)
            {
                return $.$sfa.System.Formats.Asn1.AsnDecoder.DecodeLength$1(source, ruleSet, length, bytesRead) === 5/*LengthDecodeStatus.Success*/;
            }
            static /*int? */ ReadLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed)
            {
                /*int?*/ let length;
                /*LengthDecodeStatus*/ let status = $.$sfa.System.Formats.Asn1.AsnDecoder.DecodeLength$1(source, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$spc.System.Int32)), bytesConsumed);
                let $switchJumpState3;
                $switchJumpStart3: while(true)
                {
                    switch($switchJumpState3 ?? status)
                    {
                        case 5/*LengthDecodeStatus.Success*/:
                        return length;
                        case 3/*LengthDecodeStatus.LengthTooBig*/:
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_LengthTooBig);
                        case 4/*LengthDecodeStatus.LaxEncodingProhibited*/:
                        case 1/*LengthDecodeStatus.DerIndefinite*/:
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_LengthRuleSetConstraint);
                        case 0/*LengthDecodeStatus.NeedMoreData*/:
                        case 2/*LengthDecodeStatus.ReservedValue*/:
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        default:
                        $.$spc.System.Diagnostics.Debug.Fail(`No handler is present for status ${status}.`);
                        $switchJumpState3 = 0/*LengthDecodeStatus.NeedMoreData*/; /*goto case LengthDecodeStatus.NeedMoreData*/
                        continue $switchJumpStart3;
                    }
                    break;
                }
            }
            static /*LengthDecodeStatus */ DecodeLength$1(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ length, /*out int*/ bytesRead)
            {
                length.$v = null;
                bytesRead.$v = 0;
                $.$sfa.System.Formats.Asn1.AsnDecoder.AssertEncodingRules(ruleSet);
                if (source.IsEmpty)
                {
                    return 0/*LengthDecodeStatus.NeedMoreData*/;
                }
                /*byte*/ let lengthOrLengthLength = source.get_Item(bytesRead.$v).$v;
                bytesRead.$v++;
                /*byte*/ let MultiByteMarker = 128;
                if (lengthOrLengthLength === MultiByteMarker)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/)
                    {
                        bytesRead.$v = 0;
                        return 1/*LengthDecodeStatus.DerIndefinite*/;
                    }
                    return 5/*LengthDecodeStatus.Success*/;
                }
                if (lengthOrLengthLength < MultiByteMarker)
                {
                    length.$v = lengthOrLengthLength;
                    return 5/*LengthDecodeStatus.Success*/;
                }
                if (lengthOrLengthLength === 255)
                {
                    bytesRead.$v = 0;
                    return 2/*LengthDecodeStatus.ReservedValue*/;
                }
                /*byte*/ let lengthLength = $.$cast((lengthOrLengthLength & ~MultiByteMarker), $.$spc.System.Byte);
                if (((lengthLength + 1) | 0) > source.Length)
                {
                    bytesRead.$v = 0;
                    return 0/*LengthDecodeStatus.NeedMoreData*/;
                }
                /*bool*/ let minimalRepresentation = ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/;
                if (minimalRepresentation && lengthLength > $.$spc.System.Int32.$z)
                {
                    bytesRead.$v = 0;
                    return 3/*LengthDecodeStatus.LengthTooBig*/;
                }
                /*uint*/ let parsedLength = 0;
                for(/*int*/ let i = 0; i < lengthLength; i++)
                {
                    /*byte*/ let current = source.get_Item(bytesRead.$v).$v;
                    bytesRead.$v++;
                    if (parsedLength === 0)
                    {
                        if (minimalRepresentation && current === 0)
                        {
                            bytesRead.$v = 0;
                            return 4/*LengthDecodeStatus.LaxEncodingProhibited*/;
                        }
                        if (!minimalRepresentation && current !== 0)
                        {
                            if (((lengthLength - i) | 0) > $.$spc.System.Int32.$z)
                            {
                                bytesRead.$v = 0;
                                return 3/*LengthDecodeStatus.LengthTooBig*/;
                            }
                        }
                    }
                    parsedLength <<= 8;
                    parsedLength |= current;
                }
                if (parsedLength > 2147483647/*int.MaxValue*/)
                {
                    bytesRead.$v = 0;
                    return 3/*LengthDecodeStatus.LengthTooBig*/;
                }
                if (minimalRepresentation && parsedLength < MultiByteMarker)
                {
                    bytesRead.$v = 0;
                    return 4/*LengthDecodeStatus.LaxEncodingProhibited*/;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(bytesRead.$v > 0, "bytesRead > 0");
                length.$v = (parsedLength | 0);
                return 5/*LengthDecodeStatus.Success*/;
            }
            static /*Asn1Tag */ ReadTagAndLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int?*/ contentsLength, /*out int*/ bytesRead)
            {
                /*int*/ let tagBytesRead;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.Asn1Tag.Decode(source, $.$ref(() => tagBytesRead, ($v) => tagBytesRead = $v, $.$spc.System.Int32));
                /*int*/ let lengthBytesRead;
                /*int?*/ let length = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadLength(source.Slice(tagBytesRead), ruleSet, $.$ref(() => lengthBytesRead, ($v) => lengthBytesRead = $v, $.$spc.System.Int32));
                /*int*/ let allBytesRead = ((tagBytesRead + lengthBytesRead) | 0);
                if (tag.IsConstructed)
                {
                    if (ruleSet === 1/*AsnEncodingRules.CER*/ && length !== null)
                    {
                        throw $.$sfa.System.Formats.Asn1.AsnDecoder.GetValidityException(0/*LengthValidity.CerRequiresIndefinite*/);
                    }
                }
                else if (length === null)
                {
                    throw $.$sfa.System.Formats.Asn1.AsnDecoder.GetValidityException(1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/);
                }
                bytesRead.$v = allBytesRead;
                contentsLength.$v = length;
                return tag;
            }
            static /*void */ ValidateEndOfContents(/*Asn1Tag*/ tag, /*int?*/ length, /*int*/ headerLength)
            {
                if (tag.IsConstructed || length !== 0 || headerLength !== 2/*EndOfContentsEncodedLength*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
            }
            static /*LengthValidity */ ValidateLength(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ localTag, /*int?*/ encodedLength, /*out int*/ actualLength, /*out int*/ bytesConsumed)
            {
                if (localTag.IsConstructed)
                {
                    if (ruleSet === 1/*AsnEncodingRules.CER*/ && encodedLength !== null)
                    {
                        actualLength.$v = bytesConsumed.$v = 0;
                        return 0/*LengthValidity.CerRequiresIndefinite*/;
                    }
                }
                else if (encodedLength === null)
                {
                    actualLength.$v = bytesConsumed.$v = 0;
                    return 1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/;
                }
                if (encodedLength !== null)
                {
                    /*int*/ let len = $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(encodedLength);
                    /*int*/ let totalLength = len;
                    if (totalLength > source.Length)
                    {
                        actualLength.$v = bytesConsumed.$v = 0;
                        return 2/*LengthValidity.LengthExceedsInput*/;
                    }
                    actualLength.$v = len;
                    bytesConsumed.$v = len;
                    return 3/*LengthValidity.Valid*/;
                }
                actualLength.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(source, ruleSet);
                bytesConsumed.$v = ((actualLength.$v + 2/*EndOfContentsEncodedLength*/) | 0);
                return 3/*LengthValidity.Valid*/;
            }
            static /*AsnContentException */ GetValidityException(/*LengthValidity*/ validity)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(validity !== 3/*LengthValidity.Valid*/, "validity != LengthValidity.Valid");
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    switch($switchJumpState1 ?? validity)
                    {
                        case 0/*LengthValidity.CerRequiresIndefinite*/:
                        return new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_CerRequiresIndefiniteLength);
                        case 2/*LengthValidity.LengthExceedsInput*/:
                        return new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_LengthExceedsPayload);
                        case 1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/:
                        return new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        default:
                        $.$spc.System.Diagnostics.Debug.Fail(`No handler for validity ${validity}.`);
                        $switchJumpState1 = 1/*LengthValidity.PrimitiveEncodingRequiresDefinite*/; /*goto case LengthValidity.PrimitiveEncodingRequiresDefinite*/
                        continue $switchJumpStart1;
                    }
                    break;
                }
            }
            static /*int */ GetPrimitiveIntegerSize(/*Type*/ primitiveType)
            {
                if ($.$spc.System.Type.op_Equality$1(primitiveType, $.$spc.System.Byte.$type) || $.$spc.System.Type.op_Equality$1(primitiveType, $.$spc.System.SByte.$type))
                {
                    return 1;
                }
                if ($.$spc.System.Type.op_Equality$1(primitiveType, $.$spc.System.Int16.$type) || $.$spc.System.Type.op_Equality$1(primitiveType, $.$spc.System.UInt16.$type))
                {
                    return 2;
                }
                if ($.$spc.System.Type.op_Equality$1(primitiveType, $.$spc.System.Int32.$type) || $.$spc.System.Type.op_Equality$1(primitiveType, $.$spc.System.UInt32.$type))
                {
                    return 4;
                }
                if ($.$spc.System.Type.op_Equality$1(primitiveType, $.$spc.System.Int64.$type) || $.$spc.System.Type.op_Equality$1(primitiveType, $.$spc.System.UInt64.$type))
                {
                    return 8;
                }
                return 0;
            }
            static /*int */ SeekEndOfContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet)
            {
                /*ReadOnlySpan<byte>*/ let cur = source;
                /*int*/ let totalLen = 0;
                /*int*/ let depth = 1;
                while(!cur.IsEmpty)
                {
                    /*int?*/ let length;
                    /*int*/ let bytesRead;
                    /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(cur, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$spc.System.Int32)), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32));
                    if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents))
                    {
                        $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateEndOfContents(tag, length, bytesRead);
                        depth--;
                        if (depth === 0)
                        {
                            return totalLen;
                        }
                    }
                    if (length === null)
                    {
                        depth++;
                        cur = cur.Slice(bytesRead);
                        totalLen += bytesRead;
                    }
                    else 
                    {
                        /*ReadOnlySpan<byte>*/ let tlv = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(cur, 0, ((bytesRead + $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(length)) | 0));
                        cur = cur.Slice(tlv.Length);
                        totalLen += tlv.Length;
                    }
                }
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            static /*int */ ParseNonNegativeIntAndSlice(/*ref ReadOnlySpan<byte>*/ data, /*int*/ bytesToRead)
            {
                /*int*/ let value = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeInt($.$sfa.System.Formats.Asn1.AsnDecoder.Slice(data.$v, 0, bytesToRead));
                data.$v = data.$v.Slice(bytesToRead);
                return value;
            }
            static /*int */ ParseNonNegativeInt(/*ReadOnlySpan<byte>*/ data)
            {
                /*uint*/ let value;
                /*int*/ let consumed;
                if ($.$spc.System.Buffers.Text.Utf8Parser.TryParse$13(data, $.$ref(() => value, ($v) => value = $v, $.$spc.System.UInt32), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), /*\u0000*/ 0) && value <= 2147483647/*int.MaxValue*/ && consumed === data.Length)
                {
                    return (value | 0);
                }
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            static /*ReadOnlySpan<byte> */ SliceAtMost(/*ReadOnlySpan<byte>*/ source, /*int*/ longestPermitted)
            {
                /*int*/ let len = $.$spc.System.Math.Min$4(longestPermitted, source.Length);
                return source.Slice$1(0, len);
            }
            static /*ReadOnlySpan<byte> */ Slice(/*ReadOnlySpan<byte>*/ source, /*int*/ offset, /*int*/ length)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(offset >= 0, "offset >= 0");
                if (length < 0 || ((source.Length - offset) | 0) < length)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_LengthExceedsPayload);
                }
                return source.Slice$1(offset, length);
            }
            static /*ReadOnlySpan<byte> */ Slice$1(/*ReadOnlySpan<byte>*/ source, /*int*/ offset, /*int?*/ length)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(offset >= 0, "offset >= 0");
                if (length === null)
                {
                    return source.Slice(offset);
                }
                /*int*/ let lengthVal = $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(length);
                if (lengthVal < 0 || ((source.Length - offset) | 0) < lengthVal)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_LengthExceedsPayload);
                }
                return source.Slice$1(offset, lengthVal);
            }
            static /*ReadOnlyMemory<byte> */ Slice$2(/*ReadOnlyMemory<byte>*/ bigger, /*ReadOnlySpan<byte>*/ smaller)
            {
                if (smaller.IsEmpty)
                {
                    return new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))();
                }
                /*int*/ let offset;
                if ($.$spc.System.MemoryExtensions.Overlaps$3($.$spc.System.Byte, bigger.Span, smaller, $.$ref(() => offset, ($v) => offset = $v, $.$spc.System.Int32)))
                {
                    return bigger.Slice$1(offset, smaller.Length);
                }
                $.$spc.System.Diagnostics.Debug.Fail("AsnReader asked for a matching slice from a non-overlapping input");
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            static /*void */ AssertEncodingRules(/*AsnEncodingRules*/ ruleSet)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(ruleSet >= 0/*AsnEncodingRules.BER*/ && ruleSet <= 2/*AsnEncodingRules.DER*/, "ruleSet >= AsnEncodingRules.BER && ruleSet <= AsnEncodingRules.DER");
            }
            static /*void */ CheckEncodingRules(/*AsnEncodingRules*/ ruleSet)
            {
                if (ruleSet !== 0/*AsnEncodingRules.BER*/ && ruleSet !== 1/*AsnEncodingRules.CER*/ && ruleSet !== 2/*AsnEncodingRules.DER*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("ruleSet");
                }
            }
            static /*void */ CheckExpectedTag(/*Asn1Tag*/ tag, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber)
            {
                if (expectedTag.TagClass === 0/*TagClass.Universal*/ && expectedTag.TagValue !== tagNumber)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_UniversalValueIsFixed, "expectedTag");
                }
                if (expectedTag.TagClass !== tag.TagClass || expectedTag.TagValue !== tag.TagValue)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.Format$3($.$sfa.System.SR.ContentException_WrongTag, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ $.$box(tag.TagClass, $.$sfa.System.Formats.Asn1.TagClass), $.$box(tag.TagValue, $.$spc.System.Int32), $.$box(expectedTag.TagClass, $.$sfa.System.Formats.Asn1.TagClass), $.$box(expectedTag.TagValue, $.$spc.System.Int32) ], null, null)));
                }
            }
            static $_LengthDecodeStatus;
            static get LengthDecodeStatus()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnDecoder;
                return $cls.$_LengthDecodeStatus ??= $asm.$nstr("$sfa.System.Formats.Asn1.AsnDecoder.LengthDecodeStatus", ($self) => class LengthDecodeStatus extends $.$spc.System.Enum
                {
                    static NeedMoreData = 0;
                    static DerIndefinite = 1;
                    static ReservedValue = 2;
                    static LengthTooBig = 3;
                    static LaxEncodingProhibited = 4;
                    static Success = 5;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "NeedMoreData": 0n,
                            "DerIndefinite": 1n,
                            "ReservedValue": 2n,
                            "LengthTooBig": 3n,
                            "LaxEncodingProhibited": 4n,
                            "Success": 5n
                        };
                    }
                    static $h = 446616;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":446616,"n":"NeedMoreData","d":446616,"h":4295413912,"f":33},{"t":446616,"n":"DerIndefinite","d":446616,"h":8590381208,"f":33},{"t":446616,"n":"ReservedValue","d":446616,"h":12885348504,"f":33},{"t":446616,"n":"LengthTooBig","d":446616,"h":17180315800,"f":33},{"t":446616,"n":"LaxEncodingProhibited","d":446616,"h":21475283096,"f":33},{"t":446616,"n":"Success","d":446616,"h":25770250392,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":446616,"h":30065217688,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":315544,"h":446616}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnDecoder.LengthDecodeStatus`; }
                }, $cls, ($v) => $cls.$_LengthDecodeStatus = $v);
            }
            static $_LengthValidity;
            static get LengthValidity()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnDecoder;
                return $cls.$_LengthValidity ??= $asm.$nstr("$sfa.System.Formats.Asn1.AsnDecoder.LengthValidity", ($self) => class LengthValidity extends $.$spc.System.Enum
                {
                    static CerRequiresIndefinite = 0;
                    static PrimitiveEncodingRequiresDefinite = 1;
                    static LengthExceedsInput = 2;
                    static Valid = 3;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "CerRequiresIndefinite": 0n,
                            "PrimitiveEncodingRequiresDefinite": 1n,
                            "LengthExceedsInput": 2n,
                            "Valid": 3n
                        };
                    }
                    static $h = 512152;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":512152,"n":"CerRequiresIndefinite","d":512152,"h":4295479448,"f":33},{"t":512152,"n":"PrimitiveEncodingRequiresDefinite","d":512152,"h":8590446744,"f":33},{"t":512152,"n":"LengthExceedsInput","d":512152,"h":12885414040,"f":33},{"t":512152,"n":"Valid","d":512152,"h":17180381336,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":512152,"h":21475348632,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":315544,"h":512152}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnDecoder.LengthValidity`; }
                }, $cls, ($v) => $cls.$_LengthValidity = $v);
            }
            static /*bool */ TryReadPrimitiveBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let localUbc;
                /*ReadOnlySpan<byte>*/ let localValue;
                /*int*/ let consumed;
                /*byte*/ let normalizedLastByte;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveBitStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString, $.$discardRef(), $.$discardRef(), $.$ref(() => localUbc, ($v) => localUbc = $v, $.$spc.System.Int32), $.$ref(() => localValue, ($v) => localValue = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$spc.System.Byte)))
                {
                    if (localValue.Length === 0 || normalizedLastByte === localValue.get_Item(((localValue.Length - 1) | 0)).$v)
                    {
                        unusedBitCount.$v = localUbc;
                        value.$v = localValue;
                        bytesConsumed.$v = consumed;
                        return true;
                    }
                }
                unusedBitCount.$v = 0;
                value.$v = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))();
                bytesConsumed.$v = 0;
                return false;
            }
            static /*bool */ TryReadBitString(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                if ($.$spc.System.MemoryExtensions.Overlaps$2($.$spc.System.Byte, source, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(destination)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_SourceOverlapsDestination, "destination");
                }
                /*int*/ let localUbc;
                /*byte*/ let normalizedLastByte;
                /*int*/ let consumed;
                /*int?*/ let contentsLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let value;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveBitStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString, $.$ref(() => contentsLength, ($v) => contentsLength = $v, $.$typeNullable($.$spc.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$spc.System.Int32), $.$ref(() => localUbc, ($v) => localUbc = $v, $.$spc.System.Int32), $.$ref(() => value, ($v) => value = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$spc.System.Byte)))
                {
                    if (value.Length > destination.Length)
                    {
                        bytesConsumed.$v = 0;
                        bytesWritten.$v = 0;
                        unusedBitCount.$v = 0;
                        return false;
                    }
                    $.$sfa.System.Formats.Asn1.AsnDecoder.CopyBitStringValue(value, normalizedLastByte, destination);
                    bytesWritten.$v = value.Length;
                    bytesConsumed.$v = consumed;
                    unusedBitCount.$v = localUbc;
                    return true;
                }
                /*int*/ let bytesRead;
                /*int*/ let written;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedBitStringValue($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(source, headerLength, contentsLength), ruleSet, destination, contentsLength === null, $.$ref(() => localUbc, ($v) => localUbc = $v, $.$spc.System.Int32), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => written, ($v) => written = $v, $.$spc.System.Int32)))
                {
                    unusedBitCount.$v = localUbc;
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                    bytesWritten.$v = written;
                    return true;
                }
                bytesWritten.$v = bytesConsumed.$v = unusedBitCount.$v = 0;
                return false;
            }
            static /*byte[] */ ReadBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int?*/ let contentsLength;
                /*int*/ let headerLength;
                /*int*/ let localUbc;
                /*ReadOnlySpan<byte>*/ let localValue;
                /*int*/ let consumed;
                /*byte*/ let normalizedLastByte;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveBitStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString, $.$ref(() => contentsLength, ($v) => contentsLength = $v, $.$typeNullable($.$spc.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$spc.System.Int32), $.$ref(() => localUbc, ($v) => localUbc = $v, $.$spc.System.Int32), $.$ref(() => localValue, ($v) => localValue = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$spc.System.Byte)))
                {
                    /*byte[]*/ let ret = localValue.ToArray();
                    if (localValue.Length > 0)
                    {
                        $.$spc.System.Array.$WriteT1.call(ret, normalizedLastByte, ((ret.length - 1) | 0));
                    }
                    unusedBitCount.$v = localUbc;
                    bytesConsumed.$v = consumed;
                    return ret;
                }
                /*int*/ let tooBig = contentsLength ?? $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(source.Slice(headerLength), ruleSet);
                /*byte[]*/ let rented = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(tooBig);
                /*int*/ let bytesRead;
                /*int*/ let written;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedBitStringValue($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(source, headerLength, contentsLength), ruleSet, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(rented), contentsLength === null, $.$ref(() => localUbc, ($v) => localUbc = $v, $.$spc.System.Int32), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => written, ($v) => written = $v, $.$spc.System.Int32)))
                {
                    /*byte[]*/ let ret = $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, rented, 0, written).ToArray();
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, written);
                    unusedBitCount.$v = localUbc;
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                    return ret;
                }
                $.$spc.System.Diagnostics.Debug.Fail("TryCopyConstructedBitStringValue failed with a pre-allocated buffer");
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            static /*void */ ParsePrimitiveBitStringContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ unusedBitCount, /*out ReadOnlySpan<byte>*/ value, /*out byte*/ normalizedLastByte)
            {
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && source.Length > 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCer_TryBerOrDer);
                }
                if (source.Length === 0)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                unusedBitCount.$v = source.get_Item(0).$v;
                if (unusedBitCount.$v > 7)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                if (source.Length === 1)
                {
                    if (unusedBitCount.$v > 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(unusedBitCount.$v === 0, "unusedBitCount == 0");
                    value.$v = $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).Empty;
                    normalizedLastByte.$v = 0;
                    return;
                }
                /*int*/ let mask = -1 << unusedBitCount.$v;
                /*byte*/ let lastByte = source.get_Item(((source.Length - 1) | 0)).$v;
                /*byte*/ let maskedByte = $.$cast((lastByte & mask), $.$spc.System.Byte);
                if (maskedByte !== lastByte)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                normalizedLastByte.$v = maskedByte;
                value.$v = source.Slice(1);
            }
            static $_BitStringCopyAction;
            static get BitStringCopyAction()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnDecoder;
                return $cls.$_BitStringCopyAction ??= $asm.$ncls("$sfa.System.Formats.Asn1.AsnDecoder.BitStringCopyAction", ($self) => class BitStringCopyAction extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn)
                    {
                        this._target = target;
                        this.$nativeFunction = fn;
                        return this;
                    }
                    /*void*/ Invoke(/**/ $value, /*$.$spc.System.Byte*/ $normalizedLastByte, /**/ $destination)
                    {
                        return this.$nativeFunction.apply(this._target, arguments);
                    }
                    static $h = 381080;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"normalizedLastByte","p":393217},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Invoke","d":381080,"h":8590315672,"f":129},{"r":56950785,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"normalizedLastByte","p":393217},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":381080,"h":12885282968,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":381080,"h":17180250264,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":381080,"h":4295348376,"f":1}],"i":[57147393,113377281],"d":315544,"h":381080}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnDecoder.BitStringCopyAction`; }
                }, $cls, ($v) => $cls.$_BitStringCopyAction = $v);
            }
            static /*void */ CopyBitStringValue(/*ReadOnlySpan<byte>*/ value, /*byte*/ normalizedLastByte, /*Span<byte>*/ destination)
            {
                if (value.Length === 0)
                {
                    return;
                }
                value.CopyTo(destination);
                destination.get_Item(((value.Length - 1) | 0)).$v = normalizedLastByte;
            }
            static /*int */ CountConstructedBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*bool*/ isIndefinite)
            {
                /*Span<byte>*/ let destination = $.$spc.System.Span$$($.$spc.System.Byte).Empty;
                return $.$sfa.System.Formats.Asn1.AsnDecoder.ProcessConstructedBitString(source, ruleSet, destination, null, isIndefinite, $.$discardRef(), $.$discardRef());
            }
            static /*void */ CopyConstructedBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*bool*/ isIndefinite, /*out int*/ unusedBitCount, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                /*Span<byte>*/ let tmpDest = destination;
                bytesWritten.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.ProcessConstructedBitString(source, ruleSet, tmpDest, new $.$sfa.System.Formats.Asn1.AsnDecoder.BitStringCopyAction().$ctor(null, $.$sfa.System.Formats.Asn1.AsnDecoder.CopyBitStringValue), isIndefinite, unusedBitCount, bytesRead);
            }
            static /*int */ ProcessConstructedBitString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*BitStringCopyAction?*/ copyAction, /*bool*/ isIndefinite, /*out int*/ lastUnusedBitCount, /*out int*/ bytesRead)
            {
                lastUnusedBitCount.$v = 0;
                bytesRead.$v = 0;
                /*int*/ let lastSegmentLength = 1000/*MaxCERSegmentSize*/;
                /*ReadOnlySpan<byte>*/ let cur = source;
                /*Stack<(int Offset, int Length, bool Indefinite, int BytesRead)>?*/ let readerStack = null;
                /*int*/ let totalLength = 0;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedBitString;
                /*Span<byte>*/ let curDest = destination;
                while(true)
                {
                    while(!cur.IsEmpty)
                    {
                        /*int?*/ let length;
                        /*int*/ let headerLength;
                        tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(cur, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$spc.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$spc.System.Int32));
                        if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString))
                        {
                            if (lastUnusedBitCount.$v !== 0)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                            }
                            if (ruleSet === 1/*AsnEncodingRules.CER*/ && lastSegmentLength !== 1000/*MaxCERSegmentSize*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCer_TryBerOrDer);
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$1(length !== null, "length != null");
                            /*ReadOnlySpan<byte>*/ let encodedValue = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(cur, headerLength, $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(length));
                            /*ReadOnlySpan<byte>*/ let contents;
                            /*byte*/ let normalizedLastByte;
                            $.$sfa.System.Formats.Asn1.AsnDecoder.ParsePrimitiveBitStringContents(encodedValue, ruleSet, lastUnusedBitCount, $.$ref(() => contents, ($v) => contents = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)), $.$ref(() => normalizedLastByte, ($v) => normalizedLastByte = $v, $.$spc.System.Byte));
                            /*int*/ let localLen = ((headerLength + encodedValue.Length) | 0);
                            cur = cur.Slice(localLen);
                            bytesRead.$v += localLen;
                            totalLength += contents.Length;
                            lastSegmentLength = encodedValue.Length;
                            if (copyAction !== null)
                            {
                                copyAction.Invoke(contents, normalizedLastByte, curDest);
                                curDest = curDest.Slice(contents.Length);
                            }
                        }
                        else if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents) && isIndefinite)
                        {
                            $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateEndOfContents(tag, length, headerLength);
                            bytesRead.$v += headerLength;
                            if ($.$spc.System.Int32.op_GreaterThan$1((readerStack?.Count ?? null), 0))
                            {
                                const { Item1: topOffset, Item2: topLength, Item3: wasIndefinite, Item4: pushedBytesRead } = readerStack.Pop();
                                /*ReadOnlySpan<byte>*/ let topSpan = source.Slice$1(topOffset, topLength);
                                cur = topSpan.Slice(bytesRead.$v);
                                bytesRead.$v += pushedBytesRead;
                                isIndefinite = wasIndefinite;
                            }
                            else 
                            {
                                break;
                            }
                        }
                        else if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedBitString))
                        {
                            if (ruleSet === 1/*AsnEncodingRules.CER*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            readerStack ??= new ($.$sc.System.Collections.Generic.Stack$$($.$spc.System.ValueTuple$$$$$($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Boolean, $.$spc.System.Int32)))().$ctor$1();
                            /*int*/ let curOffset;
                            if (!$.$spc.System.MemoryExtensions.Overlaps$3($.$spc.System.Byte, source, cur, $.$ref(() => curOffset, ($v) => curOffset = $v, $.$spc.System.Int32)))
                            {
                                $.$spc.System.Diagnostics.Debug.Fail("Non-overlapping data encountered...");
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                            }
                            readerStack.Push(new ($.$spc.System.ValueTuple$$$$$($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Boolean, $.$spc.System.Int32))().$ctor$2(curOffset, cur.Length, isIndefinite, bytesRead.$v));
                            cur = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(cur, headerLength, length);
                            bytesRead.$v = headerLength;
                            isIndefinite = (length === null);
                        }
                        else 
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                    }
                    if (isIndefinite && $.$sfa.System.Formats.Asn1.Asn1Tag.op_Inequality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    if ($.$spc.System.Int32.op_GreaterThan$1((readerStack?.Count ?? null), 0))
                    {
                        const { Item1: topOffset, Item2: topLength, Item3: wasIndefinite, Item4: pushedBytesRead } = readerStack.Pop();
                        /*ReadOnlySpan<byte>*/ let tmpSpan = source.Slice$1(topOffset, topLength);
                        cur = tmpSpan.Slice(bytesRead.$v);
                        isIndefinite = wasIndefinite;
                        bytesRead.$v += pushedBytesRead;
                    }
                    else 
                    {
                        return totalLength;
                    }
                }
            }
            static /*bool */ TryCopyConstructedBitStringValue(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ dest, /*bool*/ isIndefinite, /*out int*/ unusedBitCount, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                /*int*/ let contentLength = $.$sfa.System.Formats.Asn1.AsnDecoder.CountConstructedBitString(source, ruleSet, isIndefinite);
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && contentLength < 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                if (dest.Length < contentLength)
                {
                    unusedBitCount.$v = 0;
                    bytesRead.$v = 0;
                    bytesWritten.$v = 0;
                    return false;
                }
                $.$sfa.System.Formats.Asn1.AsnDecoder.CopyConstructedBitString(source, ruleSet, dest, isIndefinite, unusedBitCount, bytesRead, bytesWritten);
                $.$spc.System.Diagnostics.Debug.Assert$1(bytesWritten.$v === contentLength, "bytesWritten == contentLength");
                return true;
            }
            static /*bool */ TryReadPrimitiveBitStringCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*out int?*/ contentsLength, /*out int*/ headerLength, /*out int*/ unusedBitCount, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed, /*out byte*/ normalizedLastByte)
            {
                /*Asn1Tag*/ let actualTag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(source, ruleSet, contentsLength, headerLength);
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(actualTag, expectedTag, 3/*UniversalTagNumber.BitString*/);
                /*ReadOnlySpan<byte>*/ let encodedValue = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(source, headerLength.$v, contentsLength.$v);
                if (actualTag.IsConstructed)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderDer_TryBerOrCer);
                    }
                    unusedBitCount.$v = 0;
                    value.$v = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))();
                    normalizedLastByte.$v = 0;
                    bytesConsumed.$v = 0;
                    return false;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Nullable$$($.$spc.System.Int32).HasValue$get.call(contentsLength.$v), "contentsLength.HasValue");
                $.$sfa.System.Formats.Asn1.AsnDecoder.ParsePrimitiveBitStringContents(encodedValue, ruleSet, unusedBitCount, value, normalizedLastByte);
                bytesConsumed.$v = ((headerLength.$v + encodedValue.Length) | 0);
                return true;
            }
            static /*bool */ ReadBoolean(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Boolean, 1/*UniversalTagNumber.Boolean*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32));
                if (contents.Length !== 1)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*byte*/ let val = contents.get_Item(0).$v;
                if (val === 0)
                {
                    bytesConsumed.$v = consumed;
                    return false;
                }
                if (val !== 255 && (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/))
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                bytesConsumed.$v = consumed;
                return true;
            }
            static /*ReadOnlySpan<byte> */ ReadEnumeratedBytes(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                return $.$sfa.System.Formats.Asn1.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Enumerated, 10/*UniversalTagNumber.Enumerated*/, bytesConsumed);
            }
            static /*TEnum */ ReadEnumeratedValue(TEnum, /*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*Type*/ let tEnum = TEnum.$type;
                return $.$cast($.$spc.System.Enum.ToObject(tEnum, $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEnumeratedValue$1(source, ruleSet, tEnum, bytesConsumed, expectedTag?.Clone())), TEnum);
            }
            static /*Enum */ ReadEnumeratedValue$1(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Type*/ enumType, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                if ($.$spc.System.Type.op_Equality$1(enumType, null))
                {
                    throw new $.$spc.System.ArgumentNullException().$ctor$16("enumType");
                }
                /*UniversalTagNumber*/ let TagNumber = 10/*UniversalTagNumber.Enumerated*/;
                /*Asn1Tag*/ let localTag = expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Enumerated;
                /*Type*/ let backingType = enumType.GetEnumUnderlyingType();
                if (enumType.IsDefined($.$spc.System.FlagsAttribute.$type, false))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_EnumeratedValueRequiresNonFlagsEnum, "enumType");
                }
                /*int*/ let sizeLimit = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveIntegerSize(backingType);
                if ($.$spc.System.Type.op_Equality$1(backingType, $.$spc.System.Int32.$type) || $.$spc.System.Type.op_Equality$1(backingType, $.$spc.System.Int64.$type) || $.$spc.System.Type.op_Equality$1(backingType, $.$spc.System.Int16.$type) || $.$spc.System.Type.op_Equality$1(backingType, $.$spc.System.SByte.$type))
                {
                    /*long*/ let value;
                    /*int*/ let consumed;
                    if (!$.$sfa.System.Formats.Asn1.AsnDecoder.TryReadSignedInteger(source, ruleSet, sizeLimit, localTag, TagNumber, $.$ref(() => value, ($v) => value = $v, $.$spc.System.Int64), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32)))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_EnumeratedValueTooBig);
                    }
                    bytesConsumed.$v = consumed;
                    return $.$cast($.$spc.System.Enum.ToObject$7(enumType, value), $.$spc.System.Enum);
                }
                if ($.$spc.System.Type.op_Equality$1(backingType, $.$spc.System.UInt32.$type) || $.$spc.System.Type.op_Equality$1(backingType, $.$spc.System.UInt64.$type) || $.$spc.System.Type.op_Equality$1(backingType, $.$spc.System.UInt16.$type) || $.$spc.System.Type.op_Equality$1(backingType, $.$spc.System.Byte.$type))
                {
                    /*ulong*/ let value;
                    /*int*/ let consumed;
                    if (!$.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUnsignedInteger(source, ruleSet, sizeLimit, localTag, TagNumber, $.$ref(() => value, ($v) => value = $v, $.$spc.System.UInt64), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32)))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_EnumeratedValueTooBig);
                    }
                    bytesConsumed.$v = consumed;
                    return $.$cast($.$spc.System.Enum.ToObject$8(enumType, value), $.$spc.System.Enum);
                }
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.Format($.$sfa.System.SR.Argument_EnumeratedValueBackingTypeNotSupported, backingType.FullName));
            }
            static /*DateTimeOffset */ ReadGeneralizedTime(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*byte[]?*/ let rented = null;
                /*int*/ let StackBufSize = 64;
                /*Span<byte>*/ let tmpSpace = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, StackBufSize, null);
                /*int*/ let bytesRead;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.GeneralizedTime, 24/*UniversalTagNumber.GeneralizedTime*/, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$spc.System.Byte)), tmpSpace);
                /*DateTimeOffset*/ let value = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseGeneralizedTime(ruleSet, contents);
                if (rented !== null)
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = bytesRead;
                return value;
            }
            static /*DateTimeOffset */ ParseGeneralizedTime(/*AsnEncodingRules*/ ruleSet, /*ReadOnlySpan<byte>*/ contentOctets)
            {
                /*bool*/ let strict = ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/;
                if (strict && contentOctets.Length < 15)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                else if (contentOctets.Length < 10)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*ReadOnlySpan<byte>*/ let contents = contentOctets;
                /*int*/ let year = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 4);
                /*int*/ let month = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let day = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let hour = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int?*/ let minute = null;
                /*int?*/ let second = null;
                /*ulong*/ let fraction = 0n;
                /*ulong*/ let fractionScale = 1n;
                /*byte*/ let lastFracDigit = 255;
                /*TimeSpan?*/ let timeOffset = null;
                /*bool*/ let isZulu = false;
                /*byte*/ let HmsState = 0;
                /*byte*/ let FracState = 1;
                /*byte*/ let SuffixState = 2;
                /*byte*/ let state = HmsState;
                /*static byte?*/  function GetNextState(/*byte*/ octet)
                {
                    if (octet === /*Z*/ 90 || octet === /*-*/ 45 || octet === /*+*/ 43)
                    {
                        return SuffixState;
                    }
                    if (octet === /*.*/ 46 || octet === /*,*/ 44)
                    {
                        return FracState;
                    }
                    return null;
                }
                while(state === HmsState && contents.Length !== 0)
                {
                    /*byte?*/ let nextState = GetNextState(contents.get_Item(0).$v);
                    if (nextState === null)
                    {
                        if (minute === null)
                        {
                            minute = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                        }
                        else if (second === null)
                        {
                            second = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                        }
                        else 
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                    }
                    else 
                    {
                        state = $.$spc.System.Nullable$$($.$spc.System.Byte).Value$get.call(nextState);
                    }
                }
                if (state === FracState)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!contents.IsEmpty, "!contents.IsEmpty");
                    /*byte*/ let octet = contents.get_Item(0).$v;
                    $.$spc.System.Diagnostics.Debug.Assert$1(state === GetNextState(octet), "state == GetNextState(octet)");
                    if (octet === /*.*/ 46)
                    {
                    }
                    else if (octet === /*,*/ 44)
                    {
                        if (strict)
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                        }
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Fail((() =>
                        {
                            var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(2, 2);
                            $handler.AppendLiteral("Unhandled value '");
                            $handler.AppendFormatted$8($.$box(octet, $.$spc.System.Byte), null, "X2");
                            $handler.AppendLiteral("' in ");
                            $handler.AppendFormatted$8($.$box("FracState", $.$spc.System.String), null, null);
                            return $handler.ToStringAndClear();
                        })());
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    contents = contents.Slice(1);
                    if (contents.IsEmpty)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    /*int*/ let fracLength;
                    if (!$.$spc.System.Buffers.Text.Utf8Parser.TryParse$14($.$sfa.System.Formats.Asn1.AsnDecoder.SliceAtMost(contents, 12), $.$ref(() => fraction, ($v) => fraction = $v, $.$spc.System.UInt64), $.$ref(() => fracLength, ($v) => fracLength = $v, $.$spc.System.Int32), /*\u0000*/ 0) || fracLength === 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    lastFracDigit = $.$cast((fraction % 10n), $.$spc.System.Byte);
                    for(/*int*/ let i = 0; i < fracLength; i++)
                    {
                        fractionScale *= 10n;
                    }
                    contents = contents.Slice(fracLength);
                    /*uint*/ let nonSemantic;
                    while($.$spc.System.Buffers.Text.Utf8Parser.TryParse$13($.$sfa.System.Formats.Asn1.AsnDecoder.SliceAtMost(contents, 9), $.$ref(() => nonSemantic, ($v) => nonSemantic = $v, $.$spc.System.UInt32), $.$ref(() => fracLength, ($v) => fracLength = $v, $.$spc.System.Int32), /*\u0000*/ 0))
                    {
                        contents = contents.Slice(fracLength);
                        lastFracDigit = $.$cast((nonSemantic % 10), $.$spc.System.Byte);
                    }
                    if (contents.Length !== 0)
                    {
                        /*byte?*/ let nextState = GetNextState(contents.get_Item(0).$v);
                        if (nextState === null)
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                        state = $.$spc.System.Nullable$$($.$spc.System.Byte).Value$get.call(nextState);
                    }
                }
                if (state === SuffixState)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!contents.IsEmpty, "!contents.IsEmpty");
                    /*byte*/ let octet = contents.get_Item(0).$v;
                    $.$spc.System.Diagnostics.Debug.Assert$1(state === GetNextState(octet), "state == GetNextState(octet)");
                    contents = contents.Slice(1);
                    if (octet === /*Z*/ 90)
                    {
                        timeOffset = $.$spc.System.TimeSpan.Zero;
                        isZulu = true;
                    }
                    else 
                    {
                        /*bool*/ let isMinus;
                        if (octet === /*+*/ 43)
                        {
                            isMinus = false;
                        }
                        else if (octet === /*-*/ 45)
                        {
                            isMinus = true;
                        }
                        else 
                        {
                            $.$spc.System.Diagnostics.Debug.Fail((() =>
                            {
                                var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(2, 2);
                                $handler.AppendLiteral("Unhandled value '");
                                $handler.AppendFormatted$8($.$box(octet, $.$spc.System.Byte), null, "X2");
                                $handler.AppendLiteral("' in ");
                                $handler.AppendFormatted$8($.$box("SuffixState", $.$spc.System.String), null, null);
                                return $handler.ToStringAndClear();
                            })());
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                        if (contents.IsEmpty)
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                        /*int*/ let offsetHour = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                        /*int*/ let offsetMinute = 0;
                        if (contents.Length !== 0)
                        {
                            offsetMinute = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                        }
                        if (offsetMinute > 59)
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                        /*TimeSpan*/ let tmp = new $.$spc.System.TimeSpan().$ctor$3(offsetHour, offsetMinute, 0);
                        if (isMinus)
                        {
                            tmp = $.$spc.System.TimeSpan.op_UnaryNegation(tmp);
                        }
                        timeOffset = tmp;
                    }
                }
                if (!contents.IsEmpty)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                if (strict)
                {
                    if (!isZulu || !$.$spc.System.Nullable$$($.$spc.System.Int32).HasValue$get.call(second))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                    if (lastFracDigit === 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                /*double*/ let frac = $.$cast(fraction, $.$spc.System.Double) / Number(fractionScale);
                /*TimeSpan*/ let fractionSpan = $.$spc.System.TimeSpan.Zero;
                if (!$.$spc.System.Nullable$$($.$spc.System.Int32).HasValue$get.call(minute))
                {
                    minute = 0;
                    second = 0;
                    if (fraction !== 0n)
                    {
                        fractionSpan = new $.$spc.System.TimeSpan().$ctor$2($.$cast((frac * Number(36000000000n)), $.$spc.System.Int64));
                    }
                }
                else if (!$.$spc.System.Nullable$$($.$spc.System.Int32).HasValue$get.call(second))
                {
                    second = 0;
                    if (fraction !== 0n)
                    {
                        fractionSpan = new $.$spc.System.TimeSpan().$ctor$2($.$cast((frac * Number(600000000n)), $.$spc.System.Int64));
                    }
                }
                else if (fraction !== 0n)
                {
                    fractionSpan = new $.$spc.System.TimeSpan().$ctor$2($.$cast((frac * Number(10000000n)), $.$spc.System.Int64));
                }
                /*DateTimeOffset*/ let value;
                try
                {
                    if (timeOffset === null)
                    {
                        value = new $.$spc.System.DateTimeOffset().$ctor$4(new $.$spc.System.DateTime().$ctor$11(year, month, day, hour, $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(minute), $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(second)));
                    }
                    else 
                    {
                        value = new $.$spc.System.DateTimeOffset().$ctor$7(year, month, day, hour, $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(minute), $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(second), $.$spc.System.Nullable$$($.$spc.System.TimeSpan).Value$get.call(timeOffset));
                    }
                    value = $.$spc.System.DateTimeOffset.op_Addition(value, fractionSpan);
                    return value;
                }
                catch(e)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$7($.$sfa.System.SR.ContentException_DefaultMessage, e);
                }
            }
            static /*ReadOnlySpan<byte> */ ReadIntegerBytes(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                return $.$sfa.System.Formats.Asn1.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, bytesConsumed);
            }
            static /*BigInteger */ ReadInteger(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadIntegerBytes(source, ruleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                /*BigInteger*/ let value = new $.$srn.System.Numerics.BigInteger().$ctor$10(contents, false, true);
                bytesConsumed.$v = consumed;
                return value;
            }
            static /*bool */ TryReadInt32(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*long*/ let longValue;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadSignedInteger(source, ruleSet, $.$spc.System.Int32.$z, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, $.$ref(() => longValue, ($v) => longValue = $v, $.$spc.System.Int64), bytesConsumed))
                {
                    value.$v = $.$cast(longValue, $.$spc.System.Int32);
                    return true;
                }
                value.$v = 0;
                return false;
            }
            static /*bool */ TryReadUInt32(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out uint*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*ulong*/ let ulongValue;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUnsignedInteger(source, ruleSet, $.$spc.System.UInt32.$z, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, $.$ref(() => ulongValue, ($v) => ulongValue = $v, $.$spc.System.UInt64), bytesConsumed))
                {
                    value.$v = $.$cast(ulongValue, $.$spc.System.UInt32);
                    return true;
                }
                value.$v = 0;
                return false;
            }
            static /*bool */ TryReadInt64(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out long*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadSignedInteger(source, ruleSet, $.$spc.System.Int64.$z, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, value, bytesConsumed);
            }
            static /*bool */ TryReadUInt64(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out ulong*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUnsignedInteger(source, ruleSet, $.$spc.System.UInt64.$z, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, 2/*UniversalTagNumber.Integer*/, value, bytesConsumed);
            }
            static /*ReadOnlySpan<byte> */ GetIntegerContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out int*/ bytesConsumed)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag, tagNumber, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32));
                if (contents.IsEmpty)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*ushort*/ let bigEndianValue;
                if ($.$spc.System.Buffers.Binary.BinaryPrimitives.TryReadUInt16BigEndian(contents, $.$ref(() => bigEndianValue, ($v) => bigEndianValue = $v, $.$spc.System.UInt16)))
                {
                    /*ushort*/ let RedundancyMask = 65408;
                    /*ushort*/ let masked = $.$cast((bigEndianValue & RedundancyMask), $.$spc.System.UInt16);
                    if (masked === 0 || masked === RedundancyMask)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                }
                bytesConsumed.$v = consumed;
                return contents;
            }
            static /*bool */ TryReadSignedInteger(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*int*/ sizeLimit, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out long*/ value, /*out int*/ bytesConsumed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(sizeLimit <= $.$spc.System.Int64.$z, "sizeLimit <= sizeof(long)");
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag, tagNumber, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32));
                if (contents.Length > sizeLimit)
                {
                    value.$v = 0n;
                    bytesConsumed.$v = 0;
                    return false;
                }
                /*bool*/ let isNegative = (contents.get_Item(0).$v & 128) !== 0;
                /*long*/ let accum = BigInt(isNegative ? -1 : 0);
                for(/*int*/ let i = 0; i < contents.Length; i++)
                {
                    accum <<= 8n;
                    accum |= BigInt(contents.get_Item(i).$v);
                }
                bytesConsumed.$v = consumed;
                value.$v = accum;
                return true;
            }
            static /*bool */ TryReadUnsignedInteger(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*int*/ sizeLimit, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ tagNumber, /*out ulong*/ value, /*out int*/ bytesConsumed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(sizeLimit <= $.$spc.System.UInt64.$z, "sizeLimit <= sizeof(ulong)");
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetIntegerContents(source, ruleSet, expectedTag, tagNumber, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32));
                /*bool*/ let isNegative = (contents.get_Item(0).$v & 128) !== 0;
                if (isNegative)
                {
                    bytesConsumed.$v = 0;
                    value.$v = 0n;
                    return false;
                }
                if (contents.Length > 1 && contents.get_Item(0).$v === 0)
                {
                    contents = contents.Slice(1);
                }
                if (contents.Length > sizeLimit)
                {
                    bytesConsumed.$v = 0;
                    value.$v = 0n;
                    return false;
                }
                /*ulong*/ let accum = 0n;
                for(/*int*/ let i = 0; i < contents.Length; i++)
                {
                    accum <<= 8n;
                    accum |= BigInt(contents.get_Item(i).$v);
                }
                bytesConsumed.$v = consumed;
                value.$v = accum;
                return true;
            }
            static /*TFlagsEnum */ ReadNamedBitListValue(TFlagsEnum, /*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*Type*/ let tFlagsEnum = TFlagsEnum.$type;
                /*int*/ let consumed;
                /*TFlagsEnum*/ let ret = $.$cast($.$spc.System.Enum.ToObject(tFlagsEnum, $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNamedBitListValue$1(source, ruleSet, tFlagsEnum, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone())), TFlagsEnum);
                bytesConsumed.$v = consumed;
                return ret;
            }
            static /*Enum */ ReadNamedBitListValue$1(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Type*/ flagsEnumType, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                if ($.$spc.System.Type.op_Equality$1(flagsEnumType, null))
                {
                    throw new $.$spc.System.ArgumentNullException().$ctor$16("flagsEnumType");
                }
                /*Type*/ let backingType = flagsEnumType.GetEnumUnderlyingType();
                if (!flagsEnumType.IsDefined($.$spc.System.FlagsAttribute.$type, false))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_NamedBitListRequiresFlagsEnum, "flagsEnumType");
                }
                /*Span<byte>*/ let stackSpan = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, $.$spc.System.UInt64.$z, null);
                /*int*/ let sizeLimit = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveIntegerSize(backingType);
                stackSpan = stackSpan.Slice$1(0, sizeLimit);
                /*int*/ let unusedBitCount;
                /*int*/ let consumed;
                /*int*/ let bytesWritten;
                /*bool*/ let read = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadBitString(source, stackSpan, ruleSet, $.$ref(() => unusedBitCount, ($v) => unusedBitCount = $v, $.$spc.System.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32), expectedTag?.Clone());
                if (!read)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.Format($.$sfa.System.SR.ContentException_NamedBitListValueTooBig, flagsEnumType.Name));
                }
                /*Enum*/ let ret;
                if (bytesWritten === 0)
                {
                    ret = $.$cast($.$spc.System.Enum.ToObject$3(flagsEnumType, 0), $.$spc.System.Enum);
                    bytesConsumed.$v = consumed;
                    return ret;
                }
                /*ReadOnlySpan<byte>*/ let valueSpan = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(stackSpan.Slice$1(0, bytesWritten));
                if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                {
                    /*byte*/ let lastByte = valueSpan.get_Item(((bytesWritten - 1) | 0)).$v;
                    /*byte*/ let testBit = $.$cast((1 << unusedBitCount), $.$spc.System.Byte);
                    if ((lastByte & testBit) === 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                ret = $.$cast($.$spc.System.Enum.ToObject$7(flagsEnumType, $.$sfa.System.Formats.Asn1.AsnDecoder.InterpretNamedBitListReversed(valueSpan)), $.$spc.System.Enum);
                bytesConsumed.$v = consumed;
                return ret;
            }
            static /*BitArray */ ReadNamedBitList(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let contentLength;
                /*Asn1Tag*/ let actualTag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEncodedValue(source, ruleSet, $.$discardRef(), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$spc.System.Int32), $.$discardRef());
                if (expectedTag !== null)
                {
                    $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(actualTag, $.$spc.System.Nullable$$($.$sfa.System.Formats.Asn1.Asn1Tag).Value$get.call(expectedTag), 3/*UniversalTagNumber.BitString*/);
                }
                /*byte[]*/ let rented = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(contentLength);
                /*int*/ let unusedBitCount;
                /*int*/ let consumed;
                /*int*/ let written;
                if (!$.$sfa.System.Formats.Asn1.AsnDecoder.TryReadBitString(source, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(rented), ruleSet, $.$ref(() => unusedBitCount, ($v) => unusedBitCount = $v, $.$spc.System.Int32), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), $.$ref(() => written, ($v) => written = $v, $.$spc.System.Int32), expectedTag?.Clone()))
                {
                    $.$spc.System.Diagnostics.Debug.Fail("TryReadBitString failed with an over-allocated buffer");
                    throw new $.$spc.System.InvalidOperationException().$ctor$9();
                }
                /*int*/ let validBitCount = $.$checked($.$checked(written * 8, 1) - unusedBitCount, 1);
                /*Span<byte>*/ let valueSpan = $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, rented, 0, written);
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReverseBitsPerByte(valueSpan);
                /*BitArray*/ let ret = new $.$spc.System.Collections.BitArray().$ctor$4(rented);
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, written);
                ret.Length = validBitCount;
                bytesConsumed.$v = consumed;
                return ret;
            }
            static /*long */ InterpretNamedBitListReversed(/*ReadOnlySpan<byte>*/ valueSpan)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(valueSpan.Length <= $.$spc.System.Int64.$z, "valueSpan.Length <= sizeof(long)");
                /*long*/ let accum = 0n;
                /*long*/ let currentBitValue = 1n;
                for(/*int*/ let byteIdx = 0; byteIdx < valueSpan.Length; byteIdx++)
                {
                    /*byte*/ let byteVal = valueSpan.get_Item(byteIdx).$v;
                    for(/*int*/ let bitIndex = 7; bitIndex >= 0; bitIndex--)
                    {
                        /*int*/ let test = 1 << bitIndex;
                        if ((byteVal & test) !== 0)
                        {
                            accum |= currentBitValue;
                        }
                        currentBitValue <<= 1n;
                    }
                }
                return accum;
            }
            static /*void */ ReverseBitsPerByte(/*Span<byte>*/ value)
            {
                for(/*int*/ let byteIdx = 0; byteIdx < value.Length; byteIdx++)
                {
                    value.get_Item(byteIdx).$v = $.$cast(((BigInt(value.get_Item(byteIdx).$v) * 8623620610n & 1136090292240n) % 1023n), $.$spc.System.Byte);
                }
            }
            static /*void */ ReadNull(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Null, 5/*UniversalTagNumber.Null*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32));
                if (contents.Length !== 0)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                bytesConsumed.$v = consumed;
            }
            static /*bool */ TryReadOctetString(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                if ($.$spc.System.MemoryExtensions.Overlaps$2($.$spc.System.Byte, source, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(destination)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_SourceOverlapsDestination, "destination");
                }
                /*int?*/ let contentLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let contents;
                /*int*/ let consumed;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString, 4/*UniversalTagNumber.OctetString*/, $.$ref(() => contentLength, ($v) => contentLength = $v, $.$typeNullable($.$spc.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$spc.System.Int32), $.$ref(() => contents, ($v) => contents = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32)))
                {
                    if (contents.Length > destination.Length)
                    {
                        bytesWritten.$v = 0;
                        bytesConsumed.$v = 0;
                        return false;
                    }
                    contents.CopyTo(destination);
                    bytesWritten.$v = contents.Length;
                    bytesConsumed.$v = consumed;
                    return true;
                }
                /*int*/ let bytesRead;
                /*bool*/ let copied = $.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedOctetStringContents($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(source, headerLength, contentLength), ruleSet, destination, contentLength === null, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), bytesWritten);
                if (copied)
                {
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                }
                else 
                {
                    bytesConsumed.$v = 0;
                }
                return copied;
            }
            static /*byte[] */ ReadOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*byte[]?*/ let rented = null;
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString, 4/*UniversalTagNumber.OctetString*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$spc.System.Byte)), new ($.$spc.System.Span$$($.$spc.System.Byte))());
                /*byte[]*/ let ret = contents.ToArray();
                if (rented !== null)
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = consumed;
                return ret;
            }
            static /*bool */ TryReadPrimitiveOctetStringCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*out int?*/ contentLength, /*out int*/ headerLength, /*out ReadOnlySpan<byte>*/ contents, /*out int*/ bytesConsumed)
            {
                /*Asn1Tag*/ let actualTag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(source, ruleSet, contentLength, headerLength);
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(actualTag, expectedTag, universalTagNumber);
                /*ReadOnlySpan<byte>*/ let encodedValue = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(source, headerLength.$v, contentLength.$v);
                if (actualTag.IsConstructed)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderDer_TryBerOrCer);
                    }
                    contents.$v = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))();
                    bytesConsumed.$v = 0;
                    return false;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Nullable$$($.$spc.System.Int32).HasValue$get.call(contentLength.$v), "contentLength.HasValue");
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && encodedValue.Length > 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCer_TryBerOrDer);
                }
                contents.$v = encodedValue;
                bytesConsumed.$v = ((headerLength.$v + encodedValue.Length) | 0);
                return true;
            }
            static /*bool */ TryReadPrimitiveOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString, 4/*UniversalTagNumber.OctetString*/, $.$discardRef(), $.$discardRef(), value, bytesConsumed);
            }
            static /*int */ CountConstructedOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*bool*/ isIndefinite)
            {
                /*int*/ let contentLength = $.$sfa.System.Formats.Asn1.AsnDecoder.CopyConstructedOctetString$1(source, ruleSet, $.$spc.System.Span$$($.$spc.System.Byte).Empty, false, isIndefinite, $.$discardRef());
                if (ruleSet === 1/*AsnEncodingRules.CER*/ && contentLength <= 1000/*MaxCERSegmentSize*/)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                }
                return contentLength;
            }
            static /*void */ CopyConstructedOctetString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*bool*/ isIndefinite, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                bytesWritten.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.CopyConstructedOctetString$1(source, ruleSet, destination, true, isIndefinite, bytesRead);
            }
            static /*int */ CopyConstructedOctetString$1(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ destination, /*bool*/ write, /*bool*/ isIndefinite, /*out int*/ bytesRead)
            {
                bytesRead.$v = 0;
                /*int*/ let lastSegmentLength = 1000/*MaxCERSegmentSize*/;
                /*ReadOnlySpan<byte>*/ let cur = source;
                /*Stack<(int Offset, int Length, bool IsIndefinite, int BytesRead)>?*/ let readerStack = null;
                /*int*/ let totalLength = 0;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedBitString;
                /*Span<byte>*/ let curDest = destination;
                while(true)
                {
                    while(!cur.IsEmpty)
                    {
                        /*int?*/ let length;
                        /*int*/ let headerLength;
                        tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(cur, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$spc.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$spc.System.Int32));
                        if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString))
                        {
                            if (ruleSet === 1/*AsnEncodingRules.CER*/ && lastSegmentLength !== 1000/*MaxCERSegmentSize*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$1(length !== null, "length != null");
                            /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(cur, headerLength, $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(length));
                            /*int*/ let localLen = ((headerLength + contents.Length) | 0);
                            cur = cur.Slice(localLen);
                            bytesRead.$v += localLen;
                            totalLength += contents.Length;
                            lastSegmentLength = contents.Length;
                            if (ruleSet === 1/*AsnEncodingRules.CER*/ && lastSegmentLength > 1000/*MaxCERSegmentSize*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            if (write)
                            {
                                contents.CopyTo(curDest);
                                curDest = curDest.Slice(contents.Length);
                            }
                        }
                        else if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents) && isIndefinite)
                        {
                            $.$sfa.System.Formats.Asn1.AsnDecoder.ValidateEndOfContents(tag, length, headerLength);
                            bytesRead.$v += headerLength;
                            if ($.$spc.System.Int32.op_GreaterThan$1((readerStack?.Count ?? null), 0))
                            {
                                const { Item1: topOffset, Item2: topLength, Item3: wasIndefinite, Item4: pushedBytesRead } = readerStack.Pop();
                                /*ReadOnlySpan<byte>*/ let topSpan = source.Slice$1(topOffset, topLength);
                                cur = topSpan.Slice(bytesRead.$v);
                                bytesRead.$v += pushedBytesRead;
                                isIndefinite = wasIndefinite;
                            }
                            else 
                            {
                                break;
                            }
                        }
                        else if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Equality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedOctetString))
                        {
                            if (ruleSet === 1/*AsnEncodingRules.CER*/)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                            }
                            readerStack ??= new ($.$sc.System.Collections.Generic.Stack$$($.$spc.System.ValueTuple$$$$$($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Boolean, $.$spc.System.Int32)))().$ctor$1();
                            /*int*/ let curOffset;
                            if (!$.$spc.System.MemoryExtensions.Overlaps$3($.$spc.System.Byte, source, cur, $.$ref(() => curOffset, ($v) => curOffset = $v, $.$spc.System.Int32)))
                            {
                                $.$spc.System.Diagnostics.Debug.Fail("Non-overlapping data encountered...");
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                            }
                            readerStack.Push(new ($.$spc.System.ValueTuple$$$$$($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Boolean, $.$spc.System.Int32))().$ctor$2(curOffset, cur.Length, isIndefinite, bytesRead.$v));
                            cur = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(cur, headerLength, length);
                            bytesRead.$v = headerLength;
                            isIndefinite = (length === null);
                        }
                        else 
                        {
                            throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                        }
                    }
                    if (isIndefinite && $.$sfa.System.Formats.Asn1.Asn1Tag.op_Inequality(tag, $.$sfa.System.Formats.Asn1.Asn1Tag.EndOfContents))
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    if ($.$spc.System.Int32.op_GreaterThan$1((readerStack?.Count ?? null), 0))
                    {
                        const { Item1: topOffset, Item2: topLength, Item3: wasIndefinite, Item4: pushedBytesRead } = readerStack.Pop();
                        /*ReadOnlySpan<byte>*/ let topSpan = source.Slice$1(topOffset, topLength);
                        cur = topSpan.Slice(bytesRead.$v);
                        isIndefinite = wasIndefinite;
                        bytesRead.$v += pushedBytesRead;
                    }
                    else 
                    {
                        return totalLength;
                    }
                }
            }
            static /*bool */ TryCopyConstructedOctetStringContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Span<byte>*/ dest, /*bool*/ isIndefinite, /*out int*/ bytesRead, /*out int*/ bytesWritten)
            {
                bytesRead.$v = 0;
                /*int*/ let contentLength = $.$sfa.System.Formats.Asn1.AsnDecoder.CountConstructedOctetString(source, ruleSet, isIndefinite);
                if (dest.Length < contentLength)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                $.$sfa.System.Formats.Asn1.AsnDecoder.CopyConstructedOctetString(source, ruleSet, dest, isIndefinite, bytesRead, bytesWritten);
                $.$spc.System.Diagnostics.Debug.Assert$1(bytesWritten.$v === contentLength, "bytesWritten == contentLength");
                return true;
            }
            static /*ReadOnlySpan<byte> */ GetOctetStringContents(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*out int*/ bytesConsumed, /*ref byte[]?*/ rented, /*Span<byte>*/ tmpSpace)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(rented.$v === null, "rented == null");
                /*int?*/ let contentLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let contents;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => contentLength, ($v) => contentLength = $v, $.$typeNullable($.$spc.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$spc.System.Int32), $.$ref(() => contents, ($v) => contents = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)), bytesConsumed))
                {
                    return contents;
                }
                contents = source.Slice(headerLength);
                /*int*/ let tooBig = contentLength ?? $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(contents, ruleSet);
                if (tmpSpace.Length > 0 && tooBig > tmpSpace.Length)
                {
                    /*bool*/ let isIndefinite = contentLength === null;
                    tooBig = $.$sfa.System.Formats.Asn1.AsnDecoder.CountConstructedOctetString(contents, ruleSet, isIndefinite);
                }
                if (tooBig > tmpSpace.Length)
                {
                    rented.$v = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(tooBig);
                    tmpSpace = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(rented.$v);
                }
                /*int*/ let bytesRead;
                /*int*/ let bytesWritten;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedOctetStringContents($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(source, headerLength, contentLength), ruleSet, tmpSpace, contentLength === null, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32)))
                {
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                    return $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(tmpSpace.Slice$1(0, bytesWritten));
                }
                $.$spc.System.Diagnostics.Debug.Fail("TryCopyConstructedOctetStringContents failed with a pre-allocated buffer");
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
            }
            static /*string */ ReadObjectIdentifier(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetPrimitiveContentSpan(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ObjectIdentifier, 6/*UniversalTagNumber.ObjectIdentifier*/, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32));
                /*string?*/ let wellKnown = $.$sfa.System.Formats.Asn1.WellKnownOids.GetValue(contents);
                if (!(wellKnown === null))
                {
                    bytesConsumed.$v = consumed;
                    return wellKnown;
                }
                /*string*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadObjectIdentifier$1(contents);
                bytesConsumed.$v = consumed;
                return ret;
            }
            static /*void */ ReadSubIdentifier(/*ReadOnlySpan<byte>*/ source, /*out int*/ bytesRead, /*out long?*/ smallValue, /*out BigInteger?*/ largeValue)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(source.Length > 0, "source.Length > 0");
                if (source.get_Item(0).$v === 128)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*int*/ let semanticBits = (() =>
                {
                    let $switch1 = source.get_Item(0).$v;
                    if ($switch1 >= 192)
                    {
                        return 0;
                    }
                    if ($switch1 >= 160)
                    {
                        return -1;
                    }
                    if ($switch1 >= 144)
                    {
                        return -2;
                    }
                    if ($switch1 >= 136)
                    {
                        return -3;
                    }
                    if ($switch1 >= 132)
                    {
                        return -4;
                    }
                    if ($switch1 >= 130)
                    {
                        return -5;
                    }
                    if ($switch1 >= 129)
                    {
                        return -6;
                    }
                    return 0;
                })();
                /*int*/ let end = -1;
                /*int*/ let idx;
                /*int*/ let MaxAllowedBits = 128;
                for(idx = 0; idx < source.Length; idx++)
                {
                    semanticBits += 7;
                    if (semanticBits > MaxAllowedBits)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_OidTooBig);
                    }
                    /*bool*/ let endOfIdentifier = (source.get_Item(idx).$v & 128) === 0;
                    if (endOfIdentifier)
                    {
                        end = idx;
                        break;
                    }
                }
                if (end < 0)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                bytesRead.$v = ((end + 1) | 0);
                /*long*/ let accum = 0n;
                if (bytesRead.$v <= 9)
                {
                    for(idx = 0; idx < bytesRead.$v; idx++)
                    {
                        /*byte*/ let cur = source.get_Item(idx).$v;
                        accum <<= 7n;
                        accum |= BigInt($.$cast((cur & 127), $.$spc.System.Byte));
                    }
                    largeValue.$v = null;
                    smallValue.$v = accum;
                    return;
                }
                /*int*/ let SemanticByteCount = 7;
                /*int*/ let ContentByteCount = 8;
                /*int*/ let bytesRequired = (((((($.trunc(bytesRead.$v / ContentByteCount)) + 1) | 0)) * SemanticByteCount) | 0);
                /*byte[]*/ let tmpBytes = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(bytesRequired);
                $.$spc.System.Array.Clear$1(tmpBytes, 0, tmpBytes.length);
                /*Span<byte>*/ let writeSpan = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(tmpBytes);
                /*Span<byte>*/ let accumValueBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, $.$spc.System.Int64.$z, null);
                /*int*/ let nextStop = bytesRead.$v;
                idx = ((bytesRead.$v - ContentByteCount) | 0);
                while(nextStop > 0)
                {
                    /*byte*/ let cur = source.get_Item(idx).$v;
                    accum <<= 7n;
                    accum |= BigInt($.$cast((cur & 127), $.$spc.System.Byte));
                    idx++;
                    if (idx >= nextStop)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(idx === nextStop, "idx == nextStop");
                        $.$spc.System.Diagnostics.Debug.Assert$1(writeSpan.Length >= SemanticByteCount, "writeSpan.Length >= SemanticByteCount");
                        $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian(accumValueBytes, accum);
                        $.$spc.System.Diagnostics.Debug.Assert$1(accumValueBytes.get_Item(7).$v === 0, "accumValueBytes[7] == 0");
                        accumValueBytes.Slice$1(0, SemanticByteCount).CopyTo(writeSpan);
                        writeSpan = writeSpan.Slice(SemanticByteCount);
                        accum = 0n;
                        nextStop -= ContentByteCount;
                        idx = $.$spc.System.Math.Max$4(0, ((nextStop - ContentByteCount) | 0));
                    }
                }
                /*int*/ let bytesWritten = ((tmpBytes.length - writeSpan.Length) | 0);
                /*int*/ let paddingByteCount = ((bytesRequired - bytesWritten) | 0);
                $.$spc.System.Diagnostics.Debug.Assert$1(paddingByteCount >= 0 && paddingByteCount < $.$spc.System.Int64.$z, "paddingByteCount >= 0 && paddingByteCount < sizeof(long)");
                largeValue.$v = new $.$srn.System.Numerics.BigInteger().$ctor$9(tmpBytes);
                smallValue.$v = null;
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(tmpBytes, bytesWritten);
            }
            static /*string */ ReadObjectIdentifier$1(/*ReadOnlySpan<byte>*/ contents)
            {
                if (contents.Length < 1)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*StringBuilder*/ let builder = new $.$spc.System.Text.StringBuilder().$ctor$2(((($.$cast(contents.Length, $.$spc.System.Byte)) * 4) | 0));
                /*int*/ let bytesRead;
                /*long?*/ let smallValue;
                /*BigInteger?*/ let largeValue;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadSubIdentifier(contents, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => smallValue, ($v) => smallValue = $v, $.$typeNullable($.$spc.System.Int64)), $.$ref(() => largeValue, ($v) => largeValue = $v, $.$typeNullable($.$srn.System.Numerics.BigInteger)));
                /*byte*/ let firstArc;
                if (smallValue !== null)
                {
                    /*long*/ let firstIdentifier = $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(smallValue);
                    if (firstIdentifier < 40n)
                    {
                        firstArc = 0;
                    }
                    else if (firstIdentifier < 80n)
                    {
                        firstArc = 1;
                        firstIdentifier -= 40n;
                    }
                    else 
                    {
                        firstArc = 2;
                        firstIdentifier -= 80n;
                    }
                    builder.Append$9(firstArc);
                    builder.Append$7(/*.*/ 46);
                    builder.Append$12(firstIdentifier);
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(largeValue !== null, "largeValue != null");
                    /*BigInteger*/ let firstIdentifier = $.$spc.System.Nullable$$($.$srn.System.Numerics.BigInteger).Value$get.call(largeValue);
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$srn.System.Numerics.BigInteger.op_GreaterThan$1(firstIdentifier, 9223372036854775807n), "firstIdentifier > long.MaxValue");
                    firstArc = 2;
                    firstIdentifier = $.$srn.System.Numerics.BigInteger.op_Subtraction(firstIdentifier, $.$srn.System.Numerics.BigInteger.op_Implicit$3(80));
                    builder.Append$9(firstArc);
                    builder.Append$7(/*.*/ 46);
                    builder.Append$2($.$srn.System.Numerics.BigInteger.ToString.call(firstIdentifier));
                }
                contents = contents.Slice(bytesRead);
                /*int*/ let MaxArcs = 64;
                /*int*/ let remainingArcs = ((MaxArcs - 2) | 0);
                while(!contents.IsEmpty)
                {
                    if (remainingArcs <= 0)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_OidTooBig);
                    }
                    remainingArcs--;
                    $.$sfa.System.Formats.Asn1.AsnDecoder.ReadSubIdentifier(contents, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => smallValue, ($v) => smallValue = $v, $.$typeNullable($.$spc.System.Int64)), $.$ref(() => largeValue, ($v) => largeValue = $v, $.$typeNullable($.$srn.System.Numerics.BigInteger)));
                    $.$spc.System.Diagnostics.Debug.Assert$1((smallValue === null) !== (largeValue === null), "(smallValue == null) != (largeValue == null)");
                    builder.Append$7(/*.*/ 46);
                    if (smallValue !== null)
                    {
                        builder.Append$12($.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(smallValue));
                    }
                    else 
                    {
                        builder.Append$2($.$srn.System.Numerics.BigInteger.ToString.call($.$spc.System.Nullable$$($.$srn.System.Numerics.BigInteger).Value$get.call(largeValue)));
                    }
                    contents = contents.Slice(bytesRead);
                }
                return $.$spc.System.Text.StringBuilder.ToString.call(builder);
            }
            static /*void */ ReadSequence(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*int?*/ let length;
                /*int*/ let headerLength;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(source, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$spc.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$spc.System.Int32));
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(tag, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Sequence, 16/*UniversalTagNumber.Sequence*/);
                if (!tag.IsConstructed)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.Format($.$sfa.System.SR.ContentException_ConstructedEncodingRequired, $.$box(16/*UniversalTagNumber.Sequence*/, $.$sfa.System.Formats.Asn1.UniversalTagNumber)));
                }
                if ($.$spc.System.Nullable$$($.$spc.System.Int32).HasValue$get.call(length))
                {
                    if ($.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(length) > ((source.Length - headerLength) | 0))
                    {
                        throw $.$sfa.System.Formats.Asn1.AsnDecoder.GetValidityException(2/*LengthValidity.LengthExceedsInput*/);
                    }
                    contentLength.$v = $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(length);
                    contentOffset.$v = headerLength;
                    bytesConsumed.$v = ((contentLength.$v + headerLength) | 0);
                }
                else 
                {
                    /*int*/ let len = $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(source.Slice(headerLength), ruleSet);
                    contentLength.$v = len;
                    contentOffset.$v = headerLength;
                    bytesConsumed.$v = ((((len + headerLength) | 0) + 2/*EndOfContentsEncodedLength*/) | 0);
                }
            }
            static /*void */ ReadSetOf(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ contentOffset, /*out int*/ contentLength, /*out int*/ bytesConsumed, /*bool*/ skipSortOrderValidation, /*Asn1Tag?*/ expectedTag)
            {
                /*int?*/ let length;
                /*int*/ let headerLength;
                /*Asn1Tag*/ let tag = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadTagAndLength(source, ruleSet, $.$ref(() => length, ($v) => length = $v, $.$typeNullable($.$spc.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$spc.System.Int32));
                $.$sfa.System.Formats.Asn1.AsnDecoder.CheckExpectedTag(tag, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.SetOf, 17/*UniversalTagNumber.SetOf*/);
                if (!tag.IsConstructed)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.Format($.$sfa.System.SR.ContentException_ConstructedEncodingRequired, $.$box(17/*UniversalTagNumber.SetOf*/, $.$sfa.System.Formats.Asn1.UniversalTagNumber)));
                }
                /*int*/ let suffix;
                /*ReadOnlySpan<byte>*/ let contents;
                if ($.$spc.System.Nullable$$($.$spc.System.Int32).HasValue$get.call(length))
                {
                    suffix = 0;
                    contents = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(source, headerLength, $.$spc.System.Nullable$$($.$spc.System.Int32).Value$get.call(length));
                }
                else 
                {
                    /*int*/ let actualLength = $.$sfa.System.Formats.Asn1.AsnDecoder.SeekEndOfContents(source.Slice(headerLength), ruleSet);
                    contents = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice(source, headerLength, actualLength);
                    suffix = 2/*EndOfContentsEncodedLength*/;
                }
                if (!skipSortOrderValidation)
                {
                    if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                    {
                        /*ReadOnlySpan<byte>*/ let remaining = contents;
                        /*ReadOnlySpan<byte>*/ let previous = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))();
                        while(!remaining.IsEmpty)
                        {
                            /*int*/ let consumed;
                            $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEncodedValue(remaining, ruleSet, $.$discardRef(), $.$discardRef(), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32));
                            /*ReadOnlySpan<byte>*/ let current = remaining.Slice$1(0, consumed);
                            remaining = remaining.Slice(consumed);
                            if ($.$sfa.System.Formats.Asn1.SetOfValueComparer.Compare$1(current, previous) < 0)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_SetOfNotSorted);
                            }
                            previous = current;
                        }
                    }
                }
                contentOffset.$v = headerLength;
                contentLength.$v = contents.Length;
                bytesConsumed.$v = ((((headerLength + contents.Length) | 0) + suffix) | 0);
            }
            static /*bool */ TryReadPrimitiveCharacterStringBytes(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*out ReadOnlySpan<byte>*/ value, /*out int*/ bytesConsumed)
            {
                /*UniversalTagNumber*/ let universalTagNumber = 22/*UniversalTagNumber.IA5String*/;
                if (expectedTag.TagClass === 0/*TagClass.Universal*/)
                {
                    universalTagNumber = $.$cast(expectedTag.TagValue, $.$sfa.System.Formats.Asn1.UniversalTagNumber);
                    if (!$.$sfa.System.Formats.Asn1.AsnDecoder.IsCharacterStringEncodingType(universalTagNumber))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_Tag_NotCharacterString, "expectedTag");
                    }
                }
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag, universalTagNumber, $.$discardRef(), $.$discardRef(), value, bytesConsumed);
            }
            static /*bool */ TryReadCharacterStringBytes(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*out int*/ bytesConsumed, /*out int*/ bytesWritten)
            {
                if ($.$spc.System.MemoryExtensions.Overlaps$2($.$spc.System.Byte, source, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(destination)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_SourceOverlapsDestination, "destination");
                }
                /*UniversalTagNumber*/ let universalTagNumber = 22/*UniversalTagNumber.IA5String*/;
                if (expectedTag.TagClass === 0/*TagClass.Universal*/)
                {
                    universalTagNumber = $.$cast(expectedTag.TagValue, $.$sfa.System.Formats.Asn1.UniversalTagNumber);
                    if (!$.$sfa.System.Formats.Asn1.AsnDecoder.IsCharacterStringEncodingType(universalTagNumber))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_Tag_NotCharacterString, "expectedTag");
                    }
                }
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterStringBytesCore(source, ruleSet, expectedTag, universalTagNumber, destination, bytesConsumed, bytesWritten);
            }
            static /*bool */ TryReadCharacterString(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*AsnEncodingRules*/ ruleSet, /*UniversalTagNumber*/ encodingType, /*out int*/ bytesConsumed, /*out int*/ charsWritten, /*Asn1Tag?*/ expectedTag)
            {
                /*Text.Encoding*/ let encoding = $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.GetEncoding(encodingType);
                return $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterStringCore$1(source, ruleSet, expectedTag ?? new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(encodingType, false), encodingType, encoding, destination, bytesConsumed, charsWritten);
            }
            static /*string */ ReadCharacterString(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*UniversalTagNumber*/ encodingType, /*out int*/ bytesConsumed, /*Asn1Tag?*/ expectedTag)
            {
                /*Text.Encoding*/ let encoding = $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.GetEncoding(encodingType);
                return $.$sfa.System.Formats.Asn1.AsnDecoder.ReadCharacterStringCore(source, ruleSet, expectedTag ?? new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(encodingType, false), encodingType, encoding, bytesConsumed);
            }
            static /*bool */ TryReadCharacterStringBytesCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten)
            {
                /*int?*/ let contentLength;
                /*int*/ let headerLength;
                /*ReadOnlySpan<byte>*/ let contents;
                /*int*/ let consumed;
                if ($.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetStringCore(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => contentLength, ($v) => contentLength = $v, $.$typeNullable($.$spc.System.Int32)), $.$ref(() => headerLength, ($v) => headerLength = $v, $.$spc.System.Int32), $.$ref(() => contents, ($v) => contents = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32)))
                {
                    if (contents.Length > destination.Length)
                    {
                        bytesWritten.$v = 0;
                        bytesConsumed.$v = 0;
                        return false;
                    }
                    contents.CopyTo(destination);
                    bytesWritten.$v = contents.Length;
                    bytesConsumed.$v = consumed;
                    return true;
                }
                /*int*/ let bytesRead;
                /*bool*/ let copied = $.$sfa.System.Formats.Asn1.AsnDecoder.TryCopyConstructedOctetStringContents($.$sfa.System.Formats.Asn1.AsnDecoder.Slice$1(source, headerLength, contentLength), ruleSet, destination, contentLength === null, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), bytesWritten);
                if (copied)
                {
                    bytesConsumed.$v = ((headerLength + bytesRead) | 0);
                }
                else 
                {
                    bytesConsumed.$v = 0;
                }
                return copied;
            }
            static /*bool */ TryReadCharacterStringCore(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Text.Encoding*/ encoding, /*out int*/ charsWritten)
            {
                try
                {
                    return encoding.TryGetChars(source, destination, charsWritten);
                }
                catch(e)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$7($.$sfa.System.SR.ContentException_DefaultMessage, e);
                }
            }
            static /*string */ ReadCharacterStringCore(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*Text.Encoding*/ encoding, /*out int*/ bytesConsumed)
            {
                /*byte[]?*/ let rented = null;
                /*int*/ let bytesRead;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$spc.System.Byte)), new ($.$spc.System.Span$$($.$spc.System.Byte))());
                /*string*/ let str;
                if (contents.Length === 0)
                {
                    str = $.$spc.System.String.Empty;
                }
                else 
                {
                    {
                        /*fixed*/ 
                        {
                            /*byte**/ let bytePtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, contents);
                            try
                            {
                                str = encoding.GetString(bytePtr, contents.Length);
                            }
                            catch(e)
                            {
                                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$7($.$sfa.System.SR.ContentException_DefaultMessage, e);
                            }
                        }
                    }
                }
                if (rented !== null)
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = bytesRead;
                return str;
            }
            static /*bool */ TryReadCharacterStringCore$1(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*Asn1Tag*/ expectedTag, /*UniversalTagNumber*/ universalTagNumber, /*Text.Encoding*/ encoding, /*Span<char>*/ destination, /*out int*/ bytesConsumed, /*out int*/ charsWritten)
            {
                /*byte[]?*/ let rented = null;
                /*int*/ let bytesRead;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag, universalTagNumber, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$spc.System.Byte)), new ($.$spc.System.Span$$($.$spc.System.Byte))());
                /*bool*/ let copied = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterStringCore(contents, destination, encoding, charsWritten);
                if (rented !== null)
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                if (copied)
                {
                    bytesConsumed.$v = bytesRead;
                }
                else 
                {
                    bytesConsumed.$v = 0;
                }
                return copied;
            }
            static /*bool */ IsCharacterStringEncodingType(/*UniversalTagNumber*/ encodingType)
            {
                switch(encodingType)
                {
                    case 30/*UniversalTagNumber.BMPString*/:
                    case 27/*UniversalTagNumber.GeneralString*/:
                    case 25/*UniversalTagNumber.GraphicString*/:
                    case 22/*UniversalTagNumber.IA5String*/:
                    case 26/*UniversalTagNumber.ISO646String*/:
                    case 18/*UniversalTagNumber.NumericString*/:
                    case 19/*UniversalTagNumber.PrintableString*/:
                    case 20/*UniversalTagNumber.TeletexString*/:
                    case 28/*UniversalTagNumber.UniversalString*/:
                    case 12/*UniversalTagNumber.UTF8String*/:
                    case 21/*UniversalTagNumber.VideotexString*/:
                    return true;
                }
                return false;
            }
            static /*DateTimeOffset */ ReadUtcTime(/*ReadOnlySpan<byte>*/ source, /*AsnEncodingRules*/ ruleSet, /*out int*/ bytesConsumed, /*int*/ twoDigitYearMax, /*Asn1Tag?*/ expectedTag)
            {
                if (twoDigitYearMax < 1 || twoDigitYearMax > 9999)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("twoDigitYearMax");
                }
                /*Span<byte>*/ let tmpSpace = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 17, null);
                /*byte[]?*/ let rented = null;
                /*int*/ let bytesRead;
                /*ReadOnlySpan<byte>*/ let contents = $.$sfa.System.Formats.Asn1.AsnDecoder.GetOctetStringContents(source, ruleSet, expectedTag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.UtcTime, 23/*UniversalTagNumber.UtcTime*/, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => rented, ($v) => rented = $v, $.$typeArray($.$spc.System.Byte)), tmpSpace);
                /*DateTimeOffset*/ let value = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseUtcTime(contents, ruleSet, twoDigitYearMax);
                if (rented !== null)
                {
                    $.$spc.System.Diagnostics.Debug.Fail(`UtcTime did not fit in tmpSpace (${contents.Length} total)`);
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, contents.Length);
                }
                bytesConsumed.$v = bytesRead;
                return value;
            }
            static /*DateTimeOffset */ ParseUtcTime(/*ReadOnlySpan<byte>*/ contentOctets, /*AsnEncodingRules*/ ruleSet, /*int*/ twoDigitYearMax)
            {
                /*int*/ let NoSecondsZulu = 11;
                /*int*/ let NoSecondsOffset = 15;
                /*int*/ let HasSecondsZulu = 13;
                /*int*/ let HasSecondsOffset = 17;
                if (ruleSet === 2/*AsnEncodingRules.DER*/ || ruleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (contentOctets.Length !== HasSecondsZulu)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidUnderCerOrDer_TryBer);
                    }
                }
                if (contentOctets.Length < NoSecondsZulu || contentOctets.Length > HasSecondsOffset || (contentOctets.Length & 1) !== 1)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*ReadOnlySpan<byte>*/ let contents = contentOctets;
                /*int*/ let year = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let month = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let day = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let hour = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let minute = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                /*int*/ let second = 0;
                /*int*/ let offsetHour = 0;
                /*int*/ let offsetMinute = 0;
                /*bool*/ let minus = false;
                if (contentOctets.Length === HasSecondsOffset || contentOctets.Length === HasSecondsZulu)
                {
                    second = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                }
                if (contentOctets.Length === NoSecondsZulu || contentOctets.Length === HasSecondsZulu)
                {
                    if (contents.get_Item(0).$v !== /*Z*/ 90)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(contentOctets.Length === NoSecondsOffset || contentOctets.Length === HasSecondsOffset, "contentOctets.Length == NoSecondsOffset ||\r\n                    contentOctets.Length == HasSecondsOffset");
                    if (contents.get_Item(0).$v === /*-*/ 45)
                    {
                        minus = true;
                    }
                    else if (contents.get_Item(0).$v !== /*+*/ 43)
                    {
                        throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                    }
                    contents = contents.Slice(1);
                    offsetHour = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                    offsetMinute = $.$sfa.System.Formats.Asn1.AsnDecoder.ParseNonNegativeIntAndSlice($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), () => contents, ($v) => contents = $v, null), 2);
                    $.$spc.System.Diagnostics.Debug.Assert$1(contents.IsEmpty, "contents.IsEmpty");
                }
                if (offsetMinute > 59)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$5();
                }
                /*TimeSpan*/ let offset = new $.$spc.System.TimeSpan().$ctor$3(offsetHour, offsetMinute, 0);
                if (minus)
                {
                    offset = $.$spc.System.TimeSpan.op_UnaryNegation(offset);
                }
                /*int*/ let century = $.trunc(twoDigitYearMax / 100);
                if (year > twoDigitYearMax % 100)
                {
                    century--;
                }
                /*int*/ let scaledYear = ((((century * 100) | 0) + year) | 0);
                try
                {
                    return new $.$spc.System.DateTimeOffset().$ctor$7(scaledYear, month, day, hour, minute, second, offset);
                }
                catch(e)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$7($.$sfa.System.SR.ContentException_DefaultMessage, e);
                }
            }
            static $h = 315544;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"tag","p":118936,"f":2},{"n":"contentOffset","p":655361,"f":2},{"n":"contentLength","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryReadEncodedValue","d":315544,"h":12885217432,"f":33},{"r":118936,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"contentOffset","p":655361,"f":2},{"n":"contentLength","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"ReadEncodedValue","d":315544,"h":17180184728,"f":33},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"expectedTag","p":118936},{"n":"tagNumber","p":1626264},{"n":"bytesConsumed","p":655361,"f":2}],"n":"GetPrimitiveContentSpan","d":315544,"h":21475152024,"f":34},{"r":$.$typeNullable($.$spc.System.Int32).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2}],"n":"DecodeLength","d":315544,"h":25770119320,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"decodedLength","p":$.$typeNullable($.$spc.System.Int32).$h,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryDecodeLength","d":315544,"h":30065086616,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"length","p":$.$typeNullable($.$spc.System.Int32).$h,"f":2},{"n":"bytesRead","p":655361,"f":2}],"n":"TryReadLength","d":315544,"h":34360053912,"f":34},{"r":$.$typeNullable($.$spc.System.Int32).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2}],"n":"ReadLength","d":315544,"h":38655021208,"f":34},{"r":446616,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"length","p":$.$typeNullable($.$spc.System.Int32).$h,"f":2},{"n":"bytesRead","p":655361,"f":2}],"n":"DecodeLength","o":"@$1","d":315544,"h":42949988504,"f":34},{"r":118936,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"contentsLength","p":$.$typeNullable($.$spc.System.Int32).$h,"f":2},{"n":"bytesRead","p":655361,"f":2}],"n":"ReadTagAndLength","d":315544,"h":47244955800,"f":34},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"length","p":$.$typeNullable($.$spc.System.Int32).$h},{"n":"headerLength","p":655361}],"n":"ValidateEndOfContents","d":315544,"h":51539923096,"f":34},{"r":512152,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"localTag","p":118936},{"n":"encodedLength","p":$.$typeNullable($.$spc.System.Int32).$h},{"n":"actualLength","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"ValidateLength","d":315544,"h":55834890392,"f":34},{"r":250008,"p":[{"n":"validity","p":512152}],"n":"GetValidityException","d":315544,"h":60129857688,"f":34},{"r":655361,"p":[{"n":"primitiveType","p":142606337}],"n":"GetPrimitiveIntegerSize","d":315544,"h":64424824984,"f":34},{"r":655361,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688}],"n":"SeekEndOfContents","d":315544,"h":68719792280,"f":34},{"r":655361,"p":[{"n":"data","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"f":4},{"n":"bytesToRead","p":655361}],"n":"ParseNonNegativeIntAndSlice","d":315544,"h":73014759576,"f":34},{"r":655361,"p":[{"n":"data","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"ParseNonNegativeInt","d":315544,"h":77309726872,"f":34},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"longestPermitted","p":655361}],"n":"SliceAtMost","d":315544,"h":81604694168,"f":34},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"Slice","d":315544,"h":85899661464,"f":34},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"offset","p":655361},{"n":"length","p":$.$typeNullable($.$spc.System.Int32).$h}],"n":"Slice","o":"@$1","d":315544,"h":90194628760,"f":34},{"r":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"p":[{"n":"bigger","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"smaller","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Slice","o":"@$2","d":315544,"h":94489596056,"f":40},{"r":65537,"p":[{"n":"ruleSet","p":577688}],"n":"AssertEncodingRules","d":315544,"h":98784563352,"f":34,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"ruleSet","p":577688}],"n":"CheckEncodingRules","d":315544,"h":103079530648,"f":40},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"expectedTag","p":118936},{"n":"tagNumber","p":1626264}],"n":"CheckExpectedTag","d":315544,"h":107374497944,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"unusedBitCount","p":655361,"f":2},{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadPrimitiveBitString","d":315544,"h":120259399832,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"unusedBitCount","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadBitString","d":315544,"h":124554367128,"f":33},{"r":0,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"unusedBitCount","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadBitString","d":315544,"h":128849334424,"f":33},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"unusedBitCount","p":655361,"f":2},{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"f":2},{"n":"normalizedLastByte","p":393217,"f":2}],"n":"ParsePrimitiveBitStringContents","d":315544,"h":133144301720,"f":34},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"normalizedLastByte","p":393217},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"CopyBitStringValue","d":315544,"h":141734236312,"f":34},{"r":655361,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"isIndefinite","p":262145}],"n":"CountConstructedBitString","d":315544,"h":146029203608,"f":34},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"isIndefinite","p":262145},{"n":"unusedBitCount","p":655361,"f":2},{"n":"bytesRead","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"CopyConstructedBitString","d":315544,"h":150324170904,"f":34},{"r":655361,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"copyAction","p":381080},{"n":"isIndefinite","p":262145},{"n":"lastUnusedBitCount","p":655361,"f":2},{"n":"bytesRead","p":655361,"f":2}],"n":"ProcessConstructedBitString","d":315544,"h":154619138200,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"dest","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"isIndefinite","p":262145},{"n":"unusedBitCount","p":655361,"f":2},{"n":"bytesRead","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryCopyConstructedBitStringValue","d":315544,"h":158914105496,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"expectedTag","p":118936},{"n":"contentsLength","p":$.$typeNullable($.$spc.System.Int32).$h,"f":2},{"n":"headerLength","p":655361,"f":2},{"n":"unusedBitCount","p":655361,"f":2},{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"normalizedLastByte","p":393217,"f":2}],"n":"TryReadPrimitiveBitStringCore","d":315544,"h":163209072792,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadBoolean","d":315544,"h":167504040088,"f":33},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadEnumeratedBytes","d":315544,"h":171799007384,"f":33},{"r":171802296320,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"g":["TEnum"],"n":"ReadEnumeratedValue","d":315544,"h":176093974680,"f":131105},{"r":1048577,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"enumType","p":142606337},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadEnumeratedValue","o":"@$1","d":315544,"h":180388941976,"f":33},{"r":34340865,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadGeneralizedTime","d":315544,"h":184683909272,"f":33},{"r":34340865,"p":[{"n":"ruleSet","p":577688},{"n":"contentOctets","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"ParseGeneralizedTime","d":315544,"h":188978876568,"f":34},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadIntegerBytes","d":315544,"h":193273843864,"f":33},{"r":830849,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadInteger","d":315544,"h":197568811160,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"value","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadInt32","d":315544,"h":201863778456,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"value","p":720897,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadUInt32","d":315544,"h":206158745752,"f":33,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"value","p":917505,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadInt64","d":315544,"h":210453713048,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"value","p":983041,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadUInt64","d":315544,"h":214748680344,"f":33,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"expectedTag","p":118936},{"n":"tagNumber","p":1626264},{"n":"bytesConsumed","p":655361,"f":2}],"n":"GetIntegerContents","d":315544,"h":219043647640,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"sizeLimit","p":655361},{"n":"expectedTag","p":118936},{"n":"tagNumber","p":1626264},{"n":"value","p":917505,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryReadSignedInteger","d":315544,"h":223338614936,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"sizeLimit","p":655361},{"n":"expectedTag","p":118936},{"n":"tagNumber","p":1626264},{"n":"value","p":983041,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryReadUnsignedInteger","d":315544,"h":227633582232,"f":34},{"r":227636871168,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"g":["TFlagsEnum"],"n":"ReadNamedBitListValue","d":315544,"h":231928549528,"f":131105},{"r":1048577,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"flagsEnumType","p":142606337},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadNamedBitListValue","o":"@$1","d":315544,"h":236223516824,"f":33},{"r":24379393,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadNamedBitList","d":315544,"h":240518484120,"f":33},{"r":917505,"p":[{"n":"valueSpan","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"InterpretNamedBitListReversed","d":315544,"h":244813451416,"f":34},{"r":65537,"p":[{"n":"value","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"ReverseBitsPerByte","d":315544,"h":249108418712,"f":40},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadNull","d":315544,"h":253403386008,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadOctetString","d":315544,"h":257698353304,"f":33},{"r":0,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadOctetString","d":315544,"h":261993320600,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"expectedTag","p":118936},{"n":"universalTagNumber","p":1626264},{"n":"contentLength","p":$.$typeNullable($.$spc.System.Int32).$h,"f":2},{"n":"headerLength","p":655361,"f":2},{"n":"contents","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryReadPrimitiveOctetStringCore","d":315544,"h":266288287896,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadPrimitiveOctetString","d":315544,"h":270583255192,"f":33},{"r":655361,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"isIndefinite","p":262145}],"n":"CountConstructedOctetString","d":315544,"h":274878222488,"f":34},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"isIndefinite","p":262145},{"n":"bytesRead","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"CopyConstructedOctetString","d":315544,"h":279173189784,"f":34},{"r":655361,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"write","p":262145},{"n":"isIndefinite","p":262145},{"n":"bytesRead","p":655361,"f":2}],"n":"CopyConstructedOctetString","o":"@$1","d":315544,"h":283468157080,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"dest","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"isIndefinite","p":262145},{"n":"bytesRead","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryCopyConstructedOctetStringContents","d":315544,"h":287763124376,"f":34},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"expectedTag","p":118936},{"n":"universalTagNumber","p":1626264},{"n":"bytesConsumed","p":655361,"f":2},{"n":"rented","p":0,"f":4},{"n":"tmpSpace","p":$.$spc.System.Span$$($.$spc.System.Byte).$h,"f":65}],"n":"GetOctetStringContents","d":315544,"h":292058091672,"f":34},{"r":1310721,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadObjectIdentifier","d":315544,"h":296353058968,"f":33},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"bytesRead","p":655361,"f":2},{"n":"smallValue","p":$.$typeNullable($.$spc.System.Int64).$h,"f":2},{"n":"largeValue","p":$.$typeNullable($.$srn.System.Numerics.BigInteger).$h,"f":2}],"n":"ReadSubIdentifier","d":315544,"h":300648026264,"f":34},{"r":1310721,"p":[{"n":"contents","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"ReadObjectIdentifier","o":"@$1","d":315544,"h":304942993560,"f":34},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"contentOffset","p":655361,"f":2},{"n":"contentLength","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadSequence","d":315544,"h":309237960856,"f":33},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"contentOffset","p":655361,"f":2},{"n":"contentLength","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2},{"n":"skipSortOrderValidation","p":262145,"f":65,"v":false},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadSetOf","d":315544,"h":313532928152,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"expectedTag","p":118936},{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryReadPrimitiveCharacterStringBytes","d":315544,"h":317827895448,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"expectedTag","p":118936},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryReadCharacterStringBytes","d":315544,"h":322122862744,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"ruleSet","p":577688},{"n":"encodingType","p":1626264},{"n":"bytesConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadCharacterString","d":315544,"h":326417830040,"f":33},{"r":1310721,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"encodingType","p":1626264},{"n":"bytesConsumed","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadCharacterString","d":315544,"h":330712797336,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"expectedTag","p":118936},{"n":"universalTagNumber","p":1626264},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryReadCharacterStringBytesCore","d":315544,"h":335007764632,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"encoding","p":121831425},{"n":"charsWritten","p":655361,"f":2}],"n":"TryReadCharacterStringCore","d":315544,"h":339302731928,"f":34},{"r":1310721,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"expectedTag","p":118936},{"n":"universalTagNumber","p":1626264},{"n":"encoding","p":121831425},{"n":"bytesConsumed","p":655361,"f":2}],"n":"ReadCharacterStringCore","d":315544,"h":343597699224,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"expectedTag","p":118936},{"n":"universalTagNumber","p":1626264},{"n":"encoding","p":121831425},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"charsWritten","p":655361,"f":2}],"n":"TryReadCharacterStringCore","o":"@$1","d":315544,"h":347892666520,"f":34},{"r":262145,"p":[{"n":"encodingType","p":1626264}],"n":"IsCharacterStringEncodingType","d":315544,"h":352187633816,"f":34},{"r":34340865,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"bytesConsumed","p":655361,"f":2},{"n":"twoDigitYearMax","p":655361,"f":65,"v":2049},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadUtcTime","d":315544,"h":356482601112,"f":33},{"r":34340865,"p":[{"n":"contentOctets","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"twoDigitYearMax","p":655361}],"n":"ParseUtcTime","d":315544,"h":360777568408,"f":34}],"l":[{"t":655361,"n":"MaxCERSegmentSize","d":315544,"h":4295282840,"f":40},{"t":655361,"n":"EndOfContentsEncodedLength","d":315544,"h":8590250136,"f":40}],"j":[446616,512152,381080],"h":315544}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.AsnDecoder`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.AsnReader", ($self) => class AsnReader extends $.$spc.System.Object
        {
            /*int*/ static MaxCERSegmentSize = 1000;
            /*ReadOnlyMemory<byte>*/ _data;
            /*AsnReaderOptions*/ _options;
            /*AsnEncodingRules*/ RuleSet = 0;
            /*bool */ get HasData()
            {
                return !this._data.IsEmpty;
            }
            $ctor$1(/*ReadOnlyMemory<byte>*/ data, /*AsnEncodingRules*/ ruleSet, /*AsnReaderOptions*/ options)
            {
                super.$ctor();
                {
                    $.$sfa.System.Formats.Asn1.AsnDecoder.CheckEncodingRules(ruleSet);
                    this._data = data;
                    this.RuleSet = ruleSet;
                    this._options = options.Clone();
                }
                return this;
            }
            /*void */ ThrowIfNotEmpty()
            {
                if (this.HasData)
                {
                    throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_TooMuchData);
                }
            }
            /*Asn1Tag */ PeekTag()
            {
                return $.$sfa.System.Formats.Asn1.Asn1Tag.Decode(this._data.Span, $.$discardRef());
            }
            /*ReadOnlyMemory<byte> */ PeekEncodedValue()
            {
                /*int*/ let bytesConsumed;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEncodedValue(this._data.Span, this.RuleSet, $.$discardRef(), $.$discardRef(), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32));
                return this._data.Slice$1(0, bytesConsumed);
            }
            /*ReadOnlyMemory<byte> */ PeekContentBytes()
            {
                /*int*/ let contentOffset;
                /*int*/ let contentLength;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEncodedValue(this._data.Span, this.RuleSet, $.$ref(() => contentOffset, ($v) => contentOffset = $v, $.$spc.System.Int32), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$spc.System.Int32), $.$discardRef());
                return this._data.Slice$1(contentOffset, contentLength);
            }
            /*ReadOnlyMemory<byte> */ ReadEncodedValue()
            {
                /*ReadOnlyMemory<byte>*/ let encodedValue = this.PeekEncodedValue();
                this._data = this._data.Slice(encodedValue.Length);
                return encodedValue;
            }
            /*AsnReader */ Clone()
            {
                return new $.$sfa.System.Formats.Asn1.AsnReader().$ctor$1(this._data, this.RuleSet, this._options.Clone());
            }
            /*AsnReader */ CloneAtSlice(/*int*/ start, /*int*/ length)
            {
                return new $.$sfa.System.Formats.Asn1.AsnReader().$ctor$1(this._data.Slice$1(start, length), this.RuleSet, this._options.Clone());
            }
            /*bool */ TryReadPrimitiveBitString(/*out int*/ unusedBitCount, /*out ReadOnlyMemory<byte>*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*ReadOnlySpan<byte>*/ let span;
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveBitString(this._data.Span, this.RuleSet, unusedBitCount, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                if (ret)
                {
                    value.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(this._data, span);
                    this._data = this._data.Slice(consumed);
                }
                else 
                {
                    value.$v = new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))();
                }
                return ret;
            }
            /*bool */ TryReadBitString(/*Span<byte>*/ destination, /*out int*/ unusedBitCount, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadBitString(this._data.Span, destination, this.RuleSet, unusedBitCount, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), bytesWritten, expectedTag?.Clone());
                if (ret)
                {
                    this._data = this._data.Slice(consumed);
                }
                return ret;
            }
            /*byte[] */ ReadBitString(/*out int*/ unusedBitCount, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*byte[]*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadBitString(this._data.Span, this.RuleSet, unusedBitCount, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return ret;
            }
            /*bool */ ReadBoolean(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let bytesConsumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadBoolean(this._data.Span, this.RuleSet, $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(bytesConsumed);
                return ret;
            }
            /*ReadOnlyMemory<byte> */ ReadEnumeratedBytes(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let bytes = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEnumeratedBytes(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                /*ReadOnlyMemory<byte>*/ let memory = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(this._data, bytes);
                this._data = this._data.Slice(consumed);
                return memory;
            }
            /*TEnum */ ReadEnumeratedValue(TEnum, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*TEnum*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEnumeratedValue(TEnum, this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return ret;
            }
            /*Enum */ ReadEnumeratedValue$1(/*Type*/ enumType, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*Enum*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadEnumeratedValue$1(this._data.Span, this.RuleSet, enumType, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return ret;
            }
            /*DateTimeOffset */ ReadGeneralizedTime(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*DateTimeOffset*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadGeneralizedTime(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return ret;
            }
            /*ReadOnlyMemory<byte> */ ReadIntegerBytes(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*ReadOnlySpan<byte>*/ let bytes = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadIntegerBytes(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                /*ReadOnlyMemory<byte>*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(this._data, bytes);
                this._data = this._data.Slice(consumed);
                return ret;
            }
            /*BigInteger */ ReadInteger(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*BigInteger*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadInteger(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return ret;
            }
            /*bool */ TryReadInt32(/*out int*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadInt32(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(read);
                return ret;
            }
            /*bool */ TryReadUInt32(/*out uint*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUInt32(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(read);
                return ret;
            }
            /*bool */ TryReadInt64(/*out long*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadInt64(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(read);
                return ret;
            }
            /*bool */ TryReadUInt64(/*out ulong*/ value, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let read;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadUInt64(this._data.Span, this.RuleSet, value, $.$ref(() => read, ($v) => read = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(read);
                return ret;
            }
            /*TFlagsEnum */ ReadNamedBitListValue(TFlagsEnum, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*TFlagsEnum*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNamedBitListValue(TFlagsEnum, this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return ret;
            }
            /*Enum */ ReadNamedBitListValue$1(/*Type*/ flagsEnumType, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*Enum*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNamedBitListValue$1(this._data.Span, this.RuleSet, flagsEnumType, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return ret;
            }
            /*BitArray */ ReadNamedBitList(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*BitArray*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNamedBitList(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return ret;
            }
            /*void */ ReadNull(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadNull(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
            }
            /*bool */ TryReadOctetString(/*Span<byte>*/ destination, /*out int*/ bytesWritten, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let bytesConsumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadOctetString(this._data.Span, destination, this.RuleSet, $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32), bytesWritten, expectedTag?.Clone());
                if (ret)
                {
                    this._data = this._data.Slice(bytesConsumed);
                }
                return ret;
            }
            /*byte[] */ ReadOctetString(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*byte[]*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadOctetString(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return ret;
            }
            /*bool */ TryReadPrimitiveOctetString(/*out ReadOnlyMemory<byte>*/ contents, /*Asn1Tag?*/ expectedTag)
            {
                /*ReadOnlySpan<byte>*/ let span;
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveOctetString(this._data.Span, this.RuleSet, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                if (ret)
                {
                    contents.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(this._data, span);
                    this._data = this._data.Slice(consumed);
                }
                else 
                {
                    contents.$v = new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))();
                }
                return ret;
            }
            /*string */ ReadObjectIdentifier(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*string*/ let oidValue = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadObjectIdentifier(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return oidValue;
            }
            /*AsnReader */ ReadSequence(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let contentStart;
                /*int*/ let contentLength;
                /*int*/ let bytesConsumed;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadSequence(this._data.Span, this.RuleSet, $.$ref(() => contentStart, ($v) => contentStart = $v, $.$spc.System.Int32), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$spc.System.Int32), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                /*AsnReader*/ let ret = this.CloneAtSlice(contentStart, contentLength);
                this._data = this._data.Slice(bytesConsumed);
                return ret;
            }
            /*AsnReader */ ReadSetOf(/*Asn1Tag?*/ expectedTag)
            {
                return this.ReadSetOf$1(this._options.SkipSetSortOrderVerification, expectedTag?.Clone());
            }
            /*AsnReader */ ReadSetOf$1(/*bool*/ skipSortOrderValidation, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let contentOffset;
                /*int*/ let contentLength;
                /*int*/ let bytesConsumed;
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReadSetOf(this._data.Span, this.RuleSet, $.$ref(() => contentOffset, ($v) => contentOffset = $v, $.$spc.System.Int32), $.$ref(() => contentLength, ($v) => contentLength = $v, $.$spc.System.Int32), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32), skipSortOrderValidation, expectedTag?.Clone());
                /*AsnReader*/ let ret = this.CloneAtSlice(contentOffset, contentLength);
                this._data = this._data.Slice(bytesConsumed);
                return ret;
            }
            /*bool */ TryReadPrimitiveCharacterStringBytes(/*Asn1Tag*/ expectedTag, /*out ReadOnlyMemory<byte>*/ contents)
            {
                /*ReadOnlySpan<byte>*/ let span;
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadPrimitiveCharacterStringBytes(this._data.Span, this.RuleSet, expectedTag, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32));
                if (ret)
                {
                    contents.$v = $.$sfa.System.Formats.Asn1.AsnDecoder.Slice$2(this._data, span);
                    this._data = this._data.Slice(consumed);
                }
                else 
                {
                    contents.$v = new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))();
                }
                return ret;
            }
            /*bool */ TryReadCharacterStringBytes(/*Span<byte>*/ destination, /*Asn1Tag*/ expectedTag, /*out int*/ bytesWritten)
            {
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterStringBytes(this._data.Span, destination, this.RuleSet, expectedTag, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), bytesWritten);
                if (ret)
                {
                    this._data = this._data.Slice(consumed);
                }
                return ret;
            }
            /*bool */ TryReadCharacterString(/*Span<char>*/ destination, /*UniversalTagNumber*/ encodingType, /*out int*/ charsWritten, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*bool*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadCharacterString(this._data.Span, destination, this.RuleSet, encodingType, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), charsWritten, expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return ret;
            }
            /*string */ ReadCharacterString(/*UniversalTagNumber*/ encodingType, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*string*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadCharacterString(this._data.Span, this.RuleSet, encodingType, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return ret;
            }
            /*DateTimeOffset */ ReadUtcTime(/*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*DateTimeOffset*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadUtcTime(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), this._options.UtcTimeTwoDigitYearMax, expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return ret;
            }
            /*DateTimeOffset */ ReadUtcTime$1(/*int*/ twoDigitYearMax, /*Asn1Tag?*/ expectedTag)
            {
                /*int*/ let consumed;
                /*DateTimeOffset*/ let ret = $.$sfa.System.Formats.Asn1.AsnDecoder.ReadUtcTime(this._data.Span, this.RuleSet, $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32), twoDigitYearMax, expectedTag?.Clone());
                this._data = this._data.Slice(consumed);
                return ret;
            }
            //default member initializer
            constructor()
            {
                super();
                this._data = $.$default($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte));
                this._options = $.$default($.$sfa.System.Formats.Asn1.AsnReaderOptions);
                this.RuleSet = 0;
            }
            static $h = 643224;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":577688,"g":{"r":0,"d":0,"h":25770447000,"f":1},"n":"RuleSet","d":643224,"h":21475479704,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360381592,"f":1},"n":"HasData","d":643224,"h":30065414296,"f":1}],"m":[{"r":65537,"n":"ThrowIfNotEmpty","d":643224,"h":42950316184,"f":1},{"r":118936,"n":"PeekTag","d":643224,"h":47245283480,"f":1},{"r":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"n":"PeekEncodedValue","d":643224,"h":51540250776,"f":1},{"r":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"n":"PeekContentBytes","d":643224,"h":55835218072,"f":1},{"r":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"n":"ReadEncodedValue","d":643224,"h":60130185368,"f":1},{"r":643224,"n":"Clone","d":643224,"h":64425152664,"f":1},{"r":643224,"p":[{"n":"start","p":655361},{"n":"length","p":655361}],"n":"CloneAtSlice","d":643224,"h":68720119960,"f":2},{"r":262145,"p":[{"n":"unusedBitCount","p":655361,"f":2},{"n":"value","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadPrimitiveBitString","d":643224,"h":73015087256,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"unusedBitCount","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadBitString","d":643224,"h":77310054552,"f":1},{"r":0,"p":[{"n":"unusedBitCount","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadBitString","d":643224,"h":81605021848,"f":1},{"r":262145,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadBoolean","d":643224,"h":85899989144,"f":1},{"r":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadEnumeratedBytes","d":643224,"h":90194956440,"f":1},{"r":90197917696,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"g":["TEnum"],"n":"ReadEnumeratedValue","d":643224,"h":94489923736,"f":131073},{"r":1048577,"p":[{"n":"enumType","p":142606337},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadEnumeratedValue","o":"@$1","d":643224,"h":98784891032,"f":1},{"r":34340865,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadGeneralizedTime","d":643224,"h":103079858328,"f":1},{"r":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadIntegerBytes","d":643224,"h":107374825624,"f":1},{"r":830849,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadInteger","d":643224,"h":111669792920,"f":1},{"r":262145,"p":[{"n":"value","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadInt32","d":643224,"h":115964760216,"f":1},{"r":262145,"p":[{"n":"value","p":720897,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadUInt32","d":643224,"h":120259727512,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":262145,"p":[{"n":"value","p":917505,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadInt64","d":643224,"h":124554694808,"f":1},{"r":262145,"p":[{"n":"value","p":983041,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadUInt64","d":643224,"h":128849662104,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":128852623360,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"g":["TFlagsEnum"],"n":"ReadNamedBitListValue","d":643224,"h":133144629400,"f":131073},{"r":1048577,"p":[{"n":"flagsEnumType","p":142606337},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadNamedBitListValue","o":"@$1","d":643224,"h":137439596696,"f":1},{"r":24379393,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadNamedBitList","d":643224,"h":141734563992,"f":1},{"r":65537,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadNull","d":643224,"h":146029531288,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadOctetString","d":643224,"h":150324498584,"f":1},{"r":0,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadOctetString","d":643224,"h":154619465880,"f":1},{"r":262145,"p":[{"n":"contents","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadPrimitiveOctetString","d":643224,"h":158914433176,"f":1},{"r":1310721,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadObjectIdentifier","d":643224,"h":163209400472,"f":1},{"r":643224,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadSequence","d":643224,"h":167504367768,"f":1},{"r":643224,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadSetOf","d":643224,"h":171799335064,"f":1},{"r":643224,"p":[{"n":"skipSortOrderValidation","p":262145},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadSetOf","o":"@$1","d":643224,"h":176094302360,"f":1},{"r":262145,"p":[{"n":"expectedTag","p":118936},{"n":"contents","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"f":2}],"n":"TryReadPrimitiveCharacterStringBytes","d":643224,"h":180389269656,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"expectedTag","p":118936},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryReadCharacterStringBytes","d":643224,"h":184684236952,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"encodingType","p":1626264},{"n":"charsWritten","p":655361,"f":2},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"TryReadCharacterString","d":643224,"h":188979204248,"f":1},{"r":1310721,"p":[{"n":"encodingType","p":1626264},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadCharacterString","d":643224,"h":193274171544,"f":1},{"r":34340865,"p":[{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadUtcTime","d":643224,"h":197569138840,"f":1},{"r":34340865,"p":[{"n":"twoDigitYearMax","p":655361},{"n":"expectedTag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"ReadUtcTime","o":"@$1","d":643224,"h":201864106136,"f":1}],"l":[{"t":655361,"n":"MaxCERSegmentSize","d":643224,"h":4295610520,"f":40},{"t":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"n":"_data","d":643224,"h":8590577816,"f":2},{"t":708760,"n":"_options","d":643224,"h":12885545112,"f":2}],"c":[{"p":[{"n":"data","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"ruleSet","p":577688},{"n":"options","p":708760,"f":65}],"n":".ctor","o":"$ctor$1","d":643224,"h":38655348888,"f":1}],"h":643224}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.AsnReader`; }
        });
        
        $asm.$cls("$sfa.System.Security.Cryptography.CryptoPool", ($self) => class CryptoPool
        {
            /*int*/ static ClearAll = -1;
            static /*byte[] */ Rent(/*int*/ minimumLength)
            {
                return $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(minimumLength);
            }
            static /*void */ Return(/*ArraySegment<byte>*/ arraySegment, /*int*/ clearSize)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(arraySegment.Array !== null, "arraySegment.Array != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(arraySegment.Offset === 0, "arraySegment.Offset == 0");
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(arraySegment.Array, clearSize === -1/*ClearAll*/ ? arraySegment.Count : clearSize);
            }
            static /*void */ Return$1(/*byte[]*/ array, /*int*/ clearSize)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(clearSize <= array.length, "clearSize <= array.Length");
                /*bool*/ let clearWholeArray = clearSize < 0;
                if (!clearWholeArray && clearSize !== 0)
                {
                    $.$spc.System.Array.Clear$1(array, 0, clearSize);
                }
                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(array, clearWholeArray);
            }
            static $h = 1888408;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":0,"p":[{"n":"minimumLength","p":655361}],"n":"Rent","d":1888408,"h":8591823000,"f":40},{"r":65537,"p":[{"n":"arraySegment","p":$.$spc.System.ArraySegment$$($.$spc.System.Byte).$h},{"n":"clearSize","p":655361,"f":65,"v":-1}],"n":"Return","d":1888408,"h":12886790296,"f":40},{"r":65537,"p":[{"n":"array","p":0},{"n":"clearSize","p":655361,"f":65,"v":-1}],"n":"Return","o":"@$1","d":1888408,"h":17181757592,"f":40}],"l":[{"t":655361,"n":"ClearAll","d":1888408,"h":4296855704,"f":40}],"h":1888408}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Security.Cryptography.CryptoPool`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.AsnWriter", ($self) => class AsnWriter extends $.$spc.System.Object
        {
            /*byte[]*/ _buffer = null;
            /*int*/ _offset = 0;
            /*Stack<StackFrame>?*/ _nestingStack = null;
            /*int*/ _encodeDepth = 0;
            /*AsnEncodingRules*/ RuleSet = 0;
            $ctor$1(/*AsnEncodingRules*/ ruleSet)
            {
                super.$ctor();
                {
                    if (ruleSet !== 0/*AsnEncodingRules.BER*/ && ruleSet !== 1/*AsnEncodingRules.CER*/ && ruleSet !== 2/*AsnEncodingRules.DER*/)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("ruleSet");
                    }
                    this.RuleSet = ruleSet;
                }
                return this;
            }
            $ctor$2(/*AsnEncodingRules*/ ruleSet, /*int*/ initialCapacity)
            {
                this.$ctor$1(ruleSet);
                {
                    if (initialCapacity < 0)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("initialCapacity", $.$sfa.System.SR.ArgumentOutOfRange_NeedNonNegNum);
                    }
                    if (initialCapacity > 0)
                    {
                        this._buffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [initialCapacity], null);
                    }
                }
                return this;
            }
            /*void */ Reset()
            {
                if (this._encodeDepth !== 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sfa.System.SR.AsnWriter_ModifyingWhileEncoding);
                }
                if (this._offset > 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._buffer !== null, "_buffer != null");
                    $.$spc.System.Array.Clear$1(this._buffer, 0, this._offset);
                    this._offset = 0;
                    this._nestingStack?.Clear();
                }
            }
            /*int */ GetEncodedLength()
            {
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sfa.System.SR.AsnWriter_EncodeUnbalancedStack);
                }
                return this._offset;
            }
            /*bool */ TryEncode(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sfa.System.SR.AsnWriter_EncodeUnbalancedStack);
                }
                if (destination.Length < this._offset)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                if (this._offset === 0)
                {
                    bytesWritten.$v = 0;
                    return true;
                }
                bytesWritten.$v = this._offset;
                $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, this._buffer, 0, this._offset).CopyTo(destination);
                return true;
            }
            /*int */ Encode(/*Span<byte>*/ destination)
            {
                /*int*/ let bytesWritten;
                if (!this.TryEncode(destination, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_DestinationTooShort, "destination");
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(bytesWritten === this._offset, "bytesWritten == _offset");
                return bytesWritten;
            }
            /*byte[] */ Encode$1()
            {
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sfa.System.SR.AsnWriter_EncodeUnbalancedStack);
                }
                if (this._offset === 0)
                {
                    return $.$spc.System.Array.Empty($.$spc.System.Byte);
                }
                return $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, this._buffer, 0, this._offset).ToArray();
            }
            /*TReturn */ Encode$2(TReturn, /*Func<ReadOnlySpan<byte>, TReturn>*/ encodeCallback)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(encodeCallback, "encodeCallback");
                this._encodeDepth = $.$checked(this._encodeDepth + 1, 1);
                try
                {
                    /*ReadOnlySpan<byte>*/ let encoded = this.EncodeAsSpan();
                    return encodeCallback.Invoke(encoded);
                }
                finally
                {
                    {
                        this._encodeDepth--;
                    }
                }
            }
            /*TReturn */ Encode$3(TState, TReturn, /*TState*/ state, /*Func<TState, ReadOnlySpan<byte>, TReturn>*/ encodeCallback)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(encodeCallback, "encodeCallback");
                this._encodeDepth = $.$checked(this._encodeDepth + 1, 1);
                try
                {
                    /*ReadOnlySpan<byte>*/ let encoded = this.EncodeAsSpan();
                    return encodeCallback.Invoke(state, encoded);
                }
                finally
                {
                    {
                        this._encodeDepth--;
                    }
                }
            }
            /*void */ Encode$4(TState, /*TState*/ state, /*Action<TState, ReadOnlySpan<byte>>*/ encodeCallback)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(encodeCallback, "encodeCallback");
                this._encodeDepth = $.$checked(this._encodeDepth + 1, 1);
                try
                {
                    /*ReadOnlySpan<byte>*/ let encoded = this.EncodeAsSpan();
                    encodeCallback.Invoke(state, encoded);
                }
                finally
                {
                    {
                        this._encodeDepth--;
                    }
                }
            }
            /*ReadOnlySpan<byte> */ EncodeAsSpan()
            {
                if (((this._nestingStack?.Count ?? null) ?? 0) !== 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sfa.System.SR.AsnWriter_EncodeUnbalancedStack);
                }
                if (this._offset === 0)
                {
                    return $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).Empty;
                }
                return new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$3(this._buffer, 0, this._offset);
            }
            /*bool */ EncodedValueEquals(/*ReadOnlySpan<byte>*/ other)
            {
                return $.$spc.System.MemoryExtensions.SequenceEqual$1($.$spc.System.Byte, this.EncodeAsSpan(), other);
            }
            /*bool */ EncodedValueEquals$1(/*AsnWriter*/ other)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(other, "other");
                return $.$spc.System.MemoryExtensions.SequenceEqual$1($.$spc.System.Byte, this.EncodeAsSpan(), other.EncodeAsSpan());
            }
            /*void */ EnsureWriteCapacity(/*int*/ pendingCount)
            {
                if (pendingCount < 0)
                {
                    throw new $.$spc.System.OverflowException().$ctor$13();
                }
                if (this._encodeDepth !== 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sfa.System.SR.AsnWriter_ModifyingWhileEncoding);
                }
                if (this._buffer === null || ((this._buffer.length - this._offset) | 0) < pendingCount)
                {
                    /*int*/ let BlockSize = 1024;
                    /*int*/ let blocks = $.trunc($.$checked($.$checked(this._offset + pendingCount, 1) + ($.$checked(BlockSize - 1, 1)), 1) / BlockSize);
                    /*byte[]?*/ let oldBytes = this._buffer;
                    $.$spc.System.Array.Resize($.$spc.System.Byte, $.$ref(() => this._buffer, ($v) => this._buffer = $v, $.$typeArray($.$spc.System.Byte)), ((BlockSize * blocks) | 0));
                    /*byte[]?*/ let __ca1__ = oldBytes;
                    if ((__ca1__ = oldBytes) !== null)
                    {
                        $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, __ca1__, 0, this._offset).Clear();
                    }
                    $.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset).Fill(202);
                }
            }
            /*void */ WriteTag(/*Asn1Tag*/ tag)
            {
                /*int*/ let spaceRequired = tag.CalculateEncodedSize();
                this.EnsureWriteCapacity(spaceRequired);
                /*int*/ let written;
                if (!tag.TryEncode($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, this._buffer, this._offset, spaceRequired), $.$ref(() => written, ($v) => written = $v, $.$spc.System.Int32)) || written !== spaceRequired)
                {
                    $.$spc.System.Diagnostics.Debug.Fail(`TryWrite failed or written was wrong value (${written} vs ${spaceRequired})`);
                    throw new $.$spc.System.InvalidOperationException().$ctor$9();
                }
                this._offset += spaceRequired;
            }
            /*void */ WriteLength(/*int*/ length)
            {
                /*byte*/ let MultiByteMarker = 128;
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= -1, "length >= -1");
                if (length === -1)
                {
                    this.EnsureWriteCapacity(1);
                    $.$spc.System.Array.$WriteT1.call(this._buffer, MultiByteMarker, this._offset);
                    this._offset++;
                    return;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 0, "length >= 0");
                if (length < MultiByteMarker)
                {
                    this.EnsureWriteCapacity(((1 + length) | 0));
                    $.$spc.System.Array.$WriteT1.call(this._buffer, $.$cast(length, $.$spc.System.Byte), this._offset);
                    this._offset++;
                    return;
                }
                /*int*/ let lengthLength = $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(length);
                this.EnsureWriteCapacity(((((lengthLength + 1) | 0) + length) | 0));
                $.$spc.System.Array.$WriteT1.call(this._buffer, $.$cast((MultiByteMarker | lengthLength), $.$spc.System.Byte), this._offset);
                /*int*/ let idx = ((this._offset + lengthLength) | 0);
                /*int*/ let remaining = length;
                do
                {
                    $.$spc.System.Array.$WriteT1.call(this._buffer, $.$cast(remaining, $.$spc.System.Byte), idx);
                    remaining >>= 8;
                    idx--;
                }
                while(remaining > 0);
                $.$spc.System.Diagnostics.Debug.Assert$1(idx === this._offset, "idx == _offset");
                this._offset += ((lengthLength + 1) | 0);
            }
            static /*int */ GetEncodedLengthSubsequentByteCount(/*int*/ length)
            {
                if (length < 0)
                {
                    throw new $.$spc.System.OverflowException().$ctor$13();
                }
                if (length <= 127)
                {
                    return 0;
                }
                if (length <= 255/*byte.MaxValue*/)
                {
                    return 1;
                }
                if (length <= 65535/*ushort.MaxValue*/)
                {
                    return 2;
                }
                if (length <= 16777215)
                {
                    return 3;
                }
                return 4;
            }
            /*void */ CopyTo(/*AsnWriter*/ destination)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(destination, "destination");
                try
                {
                    destination.WriteEncodedValue(this.EncodeAsSpan());
                }
                catch(e)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$11(new $.$spc.System.InvalidOperationException().$ctor$9().Message, e);
                }
            }
            /*void */ WriteEncodedValue(/*ReadOnlySpan<byte>*/ value)
            {
                /*int*/ let consumed;
                /*bool*/ let read = $.$sfa.System.Formats.Asn1.AsnDecoder.TryReadEncodedValue(value, this.RuleSet, $.$discardRef(), $.$discardRef(), $.$discardRef(), $.$ref(() => consumed, ($v) => consumed = $v, $.$spc.System.Int32));
                if (!read || consumed !== value.Length)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_WriteEncodedValue_OneValueAtATime, "value");
                }
                this.EnsureWriteCapacity(value.Length);
                value.CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset));
                this._offset += value.Length;
            }
            /*void */ WriteEndOfContents()
            {
                this.EnsureWriteCapacity(2);
                $.$spc.System.Array.$WriteT1.call(this._buffer, 0, this._offset++);
                $.$spc.System.Array.$WriteT1.call(this._buffer, 0, this._offset++);
            }
            /*Scope */ PushTag(/*Asn1Tag*/ tag, /*UniversalTagNumber*/ tagType)
            {
                this._nestingStack ??= new ($.$sc.System.Collections.Generic.Stack$$($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame))().$ctor$1();
                $.$spc.System.Diagnostics.Debug.Assert$1(tag.IsConstructed, "tag.IsConstructed");
                this.WriteTag(tag);
                this._nestingStack.Push(new $.$sfa.System.Formats.Asn1.AsnWriter.StackFrame().$ctor$2(tag, this._offset, tagType));
                this.WriteLength(-1);
                return new $.$sfa.System.Formats.Asn1.AsnWriter.Scope().$ctor$2(this);
            }
            /*void */ PopTag(/*Asn1Tag*/ tag, /*UniversalTagNumber*/ tagType, /*bool*/ sortContents)
            {
                if (this._nestingStack === null || this._nestingStack.Count === 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sfa.System.SR.AsnWriter_PopWrongTag);
                }
                const { Item1: stackTag, Item2: lenOffset, Item3: stackTagType } = this._nestingStack.Peek();
                $.$spc.System.Diagnostics.Debug.Assert$1(tag.IsConstructed, "tag.IsConstructed");
                if ($.$sfa.System.Formats.Asn1.Asn1Tag.op_Inequality(stackTag, tag) || stackTagType !== tagType)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sfa.System.SR.AsnWriter_PopWrongTag);
                }
                this._nestingStack.Pop();
                if (sortContents)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(tagType === 17/*UniversalTagNumber.SetOf*/, "tagType == UniversalTagNumber.SetOf");
                    $.$sfa.System.Formats.Asn1.AsnWriter.SortContents(this._buffer, ((lenOffset + 1) | 0), this._offset);
                }
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/ && tagType !== 4/*UniversalTagNumber.OctetString*/)
                {
                    this.WriteEndOfContents();
                    return;
                }
                /*int*/ let containedLength = ((((this._offset - 1) | 0) - lenOffset) | 0);
                $.$spc.System.Diagnostics.Debug.Assert$1(containedLength >= 0, "containedLength >= 0");
                /*int*/ let start = ((lenOffset + 1) | 0);
                if (tagType === 4/*UniversalTagNumber.OctetString*/)
                {
                    if (this.RuleSet !== 1/*AsnEncodingRules.CER*/ || containedLength <= 1000/*AsnDecoder.MaxCERSegmentSize*/)
                    {
                        /*int*/ let tagLen = tag.CalculateEncodedSize();
                        tag.AsPrimitive().Encode($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, this._buffer, ((lenOffset - tagLen) | 0), tagLen));
                    }
                    else 
                    {
                        /*int*/ let lastSegmentSize;
                        /*int*/ let fullSegments = $.$spc.System.Math.DivRem(containedLength, 1000/*AsnDecoder.MaxCERSegmentSize*/, $.$ref(() => lastSegmentSize, ($v) => lastSegmentSize = $v, $.$spc.System.Int32));
                        /*int*/ let requiredPadding = ((((((4 * fullSegments) | 0) + 2) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(lastSegmentSize)) | 0);
                        this.EnsureWriteCapacity(((requiredPadding + 2) | 0));
                        /*ReadOnlySpan<byte>*/ let src = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, this._buffer, start, containedLength));
                        /*Span<byte>*/ let dest = $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, this._buffer, ((start + requiredPadding) | 0), containedLength);
                        src.CopyTo(dest);
                        /*int*/ let expectedEnd = ((((((start + containedLength) | 0) + requiredPadding) | 0) + 2) | 0);
                        this._offset = ((lenOffset - tag.CalculateEncodedSize()) | 0);
                        this.WriteConstructedCerOctetString(tag, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(dest));
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._offset === expectedEnd, "_offset == expectedEnd");
                        return;
                    }
                }
                /*int*/ let shiftSize = $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(containedLength);
                if (shiftSize === 0)
                {
                    $.$spc.System.Array.$WriteT1.call(this._buffer, $.$cast(containedLength, $.$spc.System.Byte), lenOffset);
                    return;
                }
                this.EnsureWriteCapacity(shiftSize);
                $.$spc.System.Buffer.BlockCopy(this._buffer, start, this._buffer, ((start + shiftSize) | 0), containedLength);
                /*int*/ let tmp = this._offset;
                this._offset = lenOffset;
                this.WriteLength(containedLength);
                $.$spc.System.Diagnostics.Debug.Assert$1(((((this._offset - lenOffset) | 0) - 1) | 0) === shiftSize, "_offset - lenOffset - 1 == shiftSize");
                this._offset = ((tmp + shiftSize) | 0);
            }
            static /*void */ SortContents(/*byte[]*/ buffer, /*int*/ start, /*int*/ end)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(buffer !== null, "buffer != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(end >= start, "end >= start");
                /*int*/ let len = ((end - start) | 0);
                if (len === 0)
                {
                    return;
                }
                /*var*/ let reader = new $.$sfa.System.Formats.Asn1.AsnReader().$ctor$1(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(buffer, start, len), 0/*AsnEncodingRules.BER*/, new $.$sfa.System.Formats.Asn1.AsnReaderOptions());
                /*int*/ let pos = start;
                /*ReadOnlyMemory<byte>*/ let encoded = reader.ReadEncodedValue();
                if (!reader.HasData)
                {
                    return;
                }
                /*List<(int, int)>*/ let positions = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32)))().$ctor$1();
                positions.Add(new ($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32))().$ctor$2(pos, encoded.Length));
                pos += encoded.Length;
                do
                {
                    encoded = reader.ReadEncodedValue();
                    positions.Add(new ($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32))().$ctor$2(pos, encoded.Length));
                    pos += encoded.Length;
                }
                while(reader.HasData);
                $.$spc.System.Diagnostics.Debug.Assert$1(pos === end, "pos == end");
                /*var*/ let comparer = new $.$sfa.System.Formats.Asn1.AsnWriter.ArrayIndexSetOfValueComparer().$ctor$1(buffer);
                positions.Sort$1(comparer);
                /*byte[]*/ let tmp = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(len);
                pos = 0;
                var $en2 = positions.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var $t1 = $en2.Current;
                    /*int*/ let offset = $t1.Item1;
                    /*int*/ let length = $t1.Item2;
                    {
                        $.$spc.System.Buffer.BlockCopy(buffer, offset, tmp, pos, length);
                        pos += length;
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(pos === len, "pos == len");
                $.$spc.System.Buffer.BlockCopy(tmp, 0, buffer, start, len);
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(tmp, len);
            }
            static /*void */ CheckUniversalTag(/*Asn1Tag?*/ tag, /*UniversalTagNumber*/ universalTagNumber)
            {
                if (tag !== null)
                {
                    /*Asn1Tag*/ let value = $.$spc.System.Nullable$$($.$sfa.System.Formats.Asn1.Asn1Tag).Value$get.call(tag);
                    if (value.TagClass === 0/*TagClass.Universal*/ && value.TagValue !== universalTagNumber)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_UniversalValueIsFixed, "tag");
                    }
                }
            }
            static $_ArrayIndexSetOfValueComparer;
            static get ArrayIndexSetOfValueComparer()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnWriter;
                return $cls.$_ArrayIndexSetOfValueComparer ??= $asm.$ncls("$sfa.System.Formats.Asn1.AsnWriter.ArrayIndexSetOfValueComparer", ($self) => class ArrayIndexSetOfValueComparer extends $.$spc.System.Object
                {
                    /*byte[]*/ _data = null;
                    $ctor$1(/*byte[]*/ data)
                    {
                        super.$ctor();
                        {
                            this._data = data;
                        }
                        return this;
                    }
                    /*int */ Compare(/*(int, int)*/ x, /*(int, int)*/ y)
                    {
                        const { Item1: xOffset, Item2: xLength } = x.Clone();
                        const { Item1: yOffset, Item2: yLength } = y.Clone();
                        /*int*/ let value = $.$sfa.System.Formats.Asn1.SetOfValueComparer.Instance.Compare(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(this._data, xOffset, xLength), new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(this._data, yOffset, yLength));
                        if (value === 0)
                        {
                            return ((xOffset - yOffset) | 0);
                        }
                        return value;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IComparer<(int, int)>.Compare((int, int), (int, int))
                    System$Collections$Generic$IComparer$$$Compare()
                    {
                        return this.Compare(...arguments);
                    }
                    static $h = 839832;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"x","p":$.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32).$h},{"n":"y","p":$.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32).$h}],"n":"Compare","d":839832,"h":12885741720,"f":1}],"l":[{"t":0,"n":"_data","d":839832,"h":4295807128,"f":2}],"c":[{"p":[{"n":"data","p":0}],"n":".ctor","o":"$ctor$1","d":839832,"h":8590774424,"f":1}],"i":[$.$spc.System.Collections.Generic.IComparer$$($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32)).$h],"d":774296,"h":839832}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IComparer$$($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32)) ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnWriter.ArrayIndexSetOfValueComparer`; }
                }, $cls, ($v) => $cls.$_ArrayIndexSetOfValueComparer = $v);
            }
            static $_StackFrame;
            static get StackFrame()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnWriter;
                return $cls.$_StackFrame ??= $asm.$nstr("$sfa.System.Formats.Asn1.AsnWriter.StackFrame", ($self) => class StackFrame extends $.$spc.System.ValueType
                {
                    /*Asn1Tag*/ Tag;
                    /*int*/ Offset = 0;
                    /*UniversalTagNumber*/ ItemType = 0;
                    $ctor$2(/*Asn1Tag*/ tag, /*int*/ offset, /*UniversalTagNumber*/ itemType)
                    {
                        super.$ctor$1();
                        {
                            this.Tag = tag;
                            this.Offset = offset;
                            this.ItemType = itemType;
                        }
                        return this;
                    }
                    /*void */ Deconstruct(/*out Asn1Tag*/ tag, /*out int*/ offset, /*out UniversalTagNumber*/ itemType)
                    {
                        tag.$v = this.Tag;
                        offset.$v = this.Offset;
                        itemType.$v = this.ItemType;
                    }
                    /*bool */ Equals$2(/*StackFrame*/ other)
                    {
                        return this.Tag.Equals$2(other.Tag) && this.Offset === other.Offset && this.ItemType === other.ItemType;
                    }
                    static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
                    {
                        let other;
                        return $.$is(obj, $.$sfa.System.Formats.Asn1.AsnWriter.StackFrame, { set $v(v){ other = v; } }) && this.Equals$2(other);
                    }
                    //Static convention instance redirect
                    /*bool */ Equals() { return $.$sfa.System.Formats.Asn1.AsnWriter.StackFrame.Equals.apply(this, arguments); }
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        return $.$spc.System.ValueTuple$$$$($.$sfa.System.Formats.Asn1.Asn1Tag, $.$spc.System.Int32, $.$sfa.System.Formats.Asn1.UniversalTagNumber).GetHashCode.call(new ($.$spc.System.ValueTuple$$$$($.$sfa.System.Formats.Asn1.Asn1Tag, $.$spc.System.Int32, $.$sfa.System.Formats.Asn1.UniversalTagNumber))().$ctor$2(this.Tag, this.Offset, this.ItemType));
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$sfa.System.Formats.Asn1.AsnWriter.StackFrame.GetHashCode.apply(this, arguments); }
                    static /*bool */ op_Equality(/*StackFrame*/ left, /*StackFrame*/ right)
                    {
                        return left.Equals$2(right);
                    }
                    static /*bool */ op_Inequality(/*StackFrame*/ left, /*StackFrame*/ right)
                    {
                        return !left.Equals$2(right);
                    }
                    //Generated interface implemetation for System.IEquatable<System.Formats.Asn1.AsnWriter.StackFrame>.Equals(System.Formats.Asn1.AsnWriter.StackFrame)
                    System$IEquatable$$$Equals()
                    {
                        return this.Equals$2(...arguments);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Tag = this.Tag.Clone();
                        copy.Offset = this.Offset;
                        copy.ItemType = this.ItemType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Tag = $.$default($.$sfa.System.Formats.Asn1.Asn1Tag);
                        this.ItemType = 0;
                    }
                    static $h = 970904;
                    static $z = 13;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":118936,"g":{"r":0,"d":0,"h":12885872792,"f":1},"n":"Tag","d":970904,"h":8590905496,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25770774680,"f":1},"n":"Offset","d":970904,"h":21475807384,"f":1},{"p":1626264,"g":{"r":0,"d":0,"h":38655676568,"f":1},"n":"ItemType","d":970904,"h":34360709272,"f":1}],"m":[{"r":65537,"p":[{"n":"tag","p":118936,"f":2},{"n":"offset","p":655361,"f":2},{"n":"itemType","p":1626264,"f":2}],"n":"Deconstruct","d":970904,"h":47245611160,"f":1},{"r":262145,"p":[{"n":"other","p":970904}],"n":"Equals","o":"@$2","d":970904,"h":51540578456,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":970904,"h":55835545752,"f":32769},{"r":655361,"n":"GetHashCode","d":970904,"h":60130513048,"f":32769}],"c":[{"p":[{"n":"tag","p":118936},{"n":"offset","p":655361},{"n":"itemType","p":1626264}],"n":".ctor","o":"$ctor$2","d":970904,"h":42950643864,"f":8},{"n":".ctor","o":"$ctor$3","d":970904,"h":73015414936,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame).$h],"d":774296,"h":970904}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame) ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnWriter.StackFrame`; }
                }, $cls, ($v) => $cls.$_StackFrame = $v);
            }
            static $_Scope;
            static get Scope()
            {
                let $cls = $.$sfa.System.Formats.Asn1.AsnWriter;
                return $cls.$_Scope ??= $asm.$nstr("$sfa.System.Formats.Asn1.AsnWriter.Scope", ($self) => class Scope extends $.$spc.System.ValueType
                {
                    /*AsnWriter*/  get _writer() { return this.$getField(0, 4); }
                    /*AsnWriter*/  set _writer(value) { this.$setField(0, 4, value); }
                    /*StackFrame*/  get _frame() { return this.$getField(4, 13); }
                    /*StackFrame*/  set _frame(value) { this.$setField(4, 13, value); }
                    /*int*/  get _depth() { return this.$getField(17, 4); }
                    /*int*/  set _depth(value) { this.$setField(17, 4, value); }
                    $ctor$2(/*AsnWriter*/ writer)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(writer._nestingStack !== null, "writer._nestingStack != null");
                            this._writer = writer;
                            this._frame = this._writer._nestingStack.Peek();
                            this._depth = this._writer._nestingStack.Count;
                        }
                        return this;
                    }
                    /*void */ Dispose()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._writer === null || this._writer._nestingStack !== null, "_writer == null || _writer._nestingStack != null");
                        if (this._writer === null || this._writer._nestingStack.Count === 0)
                        {
                            return;
                        }
                        if ($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame.op_Equality(this._writer._nestingStack.Peek(), this._frame))
                        {
                            let $switch1 = this._frame.ItemType;
                            switch($switch1)
                            {
                                case 17/*UniversalTagNumber.SetOf*/:
                                this._writer.PopSetOf(this._frame.Tag);
                                break;
                                case 16/*UniversalTagNumber.Sequence*/:
                                this._writer.PopSequence(this._frame.Tag);
                                break;
                                case 4/*UniversalTagNumber.OctetString*/:
                                this._writer.PopOctetString(this._frame.Tag);
                                break;
                                default:
                                $.$spc.System.Diagnostics.Debug.Fail(`No handler for ${this._frame.ItemType}`);
                                throw new $.$spc.System.InvalidOperationException().$ctor$9();
                            }
                        }
                        else if (this._writer._nestingStack.Count > this._depth && this._writer._nestingStack.Contains(this._frame))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sfa.System.SR.AsnWriter_PopWrongTag);
                        }
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._writer = this._writer;
                        copy._frame = this._frame.Clone();
                        copy._depth = this._depth;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._writer = null;
                        this._frame = $.$default($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame);
                        this._depth = 0;
                    }
                    static $h = 905368;
                    static $z = 21;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"n":"Dispose","d":905368,"h":21475741848,"f":1}],"l":[{"t":774296,"n":"_writer","d":905368,"h":4295872664,"f":2},{"t":970904,"n":"_frame","d":905368,"h":8590839960,"f":2},{"t":655361,"n":"_depth","d":905368,"h":12885807256,"f":2}],"c":[{"p":[{"n":"writer","p":774296}],"n":".ctor","o":"$ctor$2","d":905368,"h":17180774552,"f":8},{"n":".ctor","o":"$ctor$3","d":905368,"h":25770709144,"f":1}],"i":[57475073],"d":774296,"h":905368}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `System.Formats.Asn1.AsnWriter.Scope`; }
                }, $cls, ($v) => $cls.$_Scope = $v);
            }
            /*void */ WriteBitString(/*ReadOnlySpan<byte>*/ value, /*int*/ unusedBitCount, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 3/*UniversalTagNumber.BitString*/);
                this.WriteBitStringCore(tag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString, value, unusedBitCount);
            }
            /*void */ WriteBitStringCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ bitString, /*int*/ unusedBitCount)
            {
                if (unusedBitCount < 0 || unusedBitCount > 7)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("unusedBitCount", $.$box(unusedBitCount, $.$spc.System.Int32), $.$sfa.System.SR.Argument_UnusedBitCountRange);
                }
                if (bitString.Length === 0 && unusedBitCount !== 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_UnusedBitCountMustBeZero, "unusedBitCount");
                }
                /*byte*/ let lastByte = bitString.IsEmpty ? 0 : bitString.get_Item(((bitString.Length - 1) | 0)).$v;
                if (!$.$sfa.System.Formats.Asn1.AsnWriter.CheckValidLastByte(lastByte, unusedBitCount))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_UnusedBitWasSet, "unusedBitCount");
                }
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (bitString.Length >= 1000/*AsnReader.MaxCERSegmentSize*/)
                    {
                        this.WriteConstructedCerBitString(tag, bitString, unusedBitCount);
                        return;
                    }
                }
                this.WriteTag(tag.AsPrimitive());
                this.WriteLength(((bitString.Length + 1) | 0));
                $.$spc.System.Array.$WriteT1.call(this._buffer, $.$cast(unusedBitCount, $.$spc.System.Byte), this._offset);
                this._offset++;
                bitString.CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset));
                this._offset += bitString.Length;
            }
            static /*bool */ CheckValidLastByte(/*byte*/ lastByte, /*int*/ unusedBitCount)
            {
                /*int*/ let mask = (((1 << unusedBitCount) - 1) | 0);
                return ((lastByte & mask) === 0);
            }
            static /*int */ DetermineCerBitStringTotalLength(/*Asn1Tag*/ tag, /*int*/ contentLength)
            {
                /*int*/ let MaxCERSegmentSize = 1000/*AsnReader.MaxCERSegmentSize*/;
                /*int*/ let MaxCERContentSize = ((MaxCERSegmentSize - 1) | 0);
                $.$spc.System.Diagnostics.Debug.Assert$1(contentLength > MaxCERContentSize, "contentLength > MaxCERContentSize");
                /*int*/ let lastContentSize;
                /*int*/ let fullSegments = $.$spc.System.Math.DivRem(contentLength, MaxCERContentSize, $.$ref(() => lastContentSize, ($v) => lastContentSize = $v, $.$spc.System.Int32));
                /*int*/ let FullSegmentEncodedSize = 1004;
                $.$spc.System.Diagnostics.Debug.Assert$1(FullSegmentEncodedSize === ((((((1 + 1) | 0) + MaxCERSegmentSize) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)) | 0), "FullSegmentEncodedSize == 1 + 1 + MaxCERSegmentSize + GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)");
                /*int*/ let remainingEncodedSize;
                if (lastContentSize === 0)
                {
                    remainingEncodedSize = 0;
                }
                else 
                {
                    remainingEncodedSize = ((((3 + lastContentSize) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(lastContentSize)) | 0);
                }
                return ((((((((fullSegments * FullSegmentEncodedSize) | 0) + remainingEncodedSize) | 0) + 3) | 0) + tag.CalculateEncodedSize()) | 0);
            }
            /*void */ WriteConstructedCerBitString(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ payload, /*int*/ unusedBitCount)
            {
                /*int*/ let MaxCERSegmentSize = 1000/*AsnReader.MaxCERSegmentSize*/;
                /*int*/ let MaxCERContentSize = ((MaxCERSegmentSize - 1) | 0);
                $.$spc.System.Diagnostics.Debug.Assert$1(payload.Length > MaxCERContentSize, "payload.Length > MaxCERContentSize");
                /*int*/ let expectedSize = $.$sfa.System.Formats.Asn1.AsnWriter.DetermineCerBitStringTotalLength(tag, payload.Length);
                this.EnsureWriteCapacity(expectedSize);
                /*int*/ let savedOffset = this._offset;
                this.WriteTag(tag.AsConstructed());
                this.WriteLength(-1);
                /*byte[]*/ let ensureNoExtraCopy = this._buffer;
                /*ReadOnlySpan<byte>*/ let remainingData = payload;
                /*Span<byte>*/ let dest;
                /*Asn1Tag*/ let primitiveBitString = $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveBitString;
                while(remainingData.Length > MaxCERContentSize)
                {
                    this.WriteTag(primitiveBitString);
                    this.WriteLength(MaxCERSegmentSize);
                    $.$spc.System.Array.$WriteT1.call(this._buffer, 0, this._offset);
                    this._offset++;
                    dest = $.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset);
                    remainingData.Slice$1(0, MaxCERContentSize).CopyTo(dest);
                    remainingData = remainingData.Slice(MaxCERContentSize);
                    this._offset += MaxCERContentSize;
                }
                this.WriteTag(primitiveBitString);
                this.WriteLength(((remainingData.Length + 1) | 0));
                $.$spc.System.Array.$WriteT1.call(this._buffer, $.$cast(unusedBitCount, $.$spc.System.Byte), this._offset);
                this._offset++;
                dest = $.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset);
                remainingData.CopyTo(dest);
                this._offset += remainingData.Length;
                this.WriteEndOfContents();
                $.$spc.System.Diagnostics.Debug.Assert$2(((this._offset - savedOffset) | 0) === expectedSize, `expected size was ${expectedSize}, actual was ${((this._offset - savedOffset) | 0)}`);
                $.$spc.System.Diagnostics.Debug.Assert$1(this._buffer === ensureNoExtraCopy, `_buffer was replaced during ${"WriteConstructedCerBitString"}`);
            }
            /*void */ WriteBoolean(/*bool*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 1/*UniversalTagNumber.Boolean*/);
                this.WriteBooleanCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Boolean, value);
            }
            /*void */ WriteBooleanCore(/*Asn1Tag*/ tag, /*bool*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(1);
                $.$spc.System.Diagnostics.Debug.Assert$1(this._offset < this._buffer.length, "_offset < _buffer.Length");
                $.$spc.System.Array.$WriteT1.call(this._buffer, $.$cast((value ? 255 : 0), $.$spc.System.Byte), this._offset);
                this._offset++;
            }
            /*void */ WriteEnumeratedValue(/*Enum*/ value, /*Asn1Tag?*/ tag)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                this.WriteEnumeratedValue$2((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Enumerated, $.$spc.System.Object.GetType.call(value), value);
            }
            /*void */ WriteEnumeratedValue$1(TEnum, /*TEnum*/ value, /*Asn1Tag?*/ tag)
            {
                this.WriteEnumeratedValue$2((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Enumerated, TEnum.$type, $.$box(value, TEnum));
            }
            /*void */ WriteEnumeratedValue$2(/*Asn1Tag*/ tag, /*Type*/ tEnum, /*object*/ value)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag, 10/*UniversalTagNumber.Enumerated*/);
                /*Type*/ let backingType = tEnum.GetEnumUnderlyingType();
                if (tEnum.IsDefined($.$spc.System.FlagsAttribute.$type, false))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_EnumeratedValueRequiresNonFlagsEnum, "tEnum");
                }
                if ($.$spc.System.Type.op_Equality$1(backingType, $.$spc.System.UInt64.$type))
                {
                    /*ulong*/ let numericValue = $.$spc.System.Convert.ToUInt64(value);
                    this.WriteNonNegativeIntegerCore(tag, numericValue);
                }
                else 
                {
                    /*long*/ let numericValue = $.$spc.System.Convert.ToInt64(value);
                    this.WriteIntegerCore(tag, numericValue);
                }
            }
            /*void */ WriteGeneralizedTime(/*DateTimeOffset*/ value, /*bool*/ omitFractionalSeconds, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 24/*UniversalTagNumber.GeneralizedTime*/);
                this.WriteGeneralizedTimeCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.GeneralizedTime, value, omitFractionalSeconds);
            }
            /*void */ WriteGeneralizedTimeCore(/*Asn1Tag*/ tag, /*DateTimeOffset*/ value, /*bool*/ omitFractionalSeconds)
            {
                /*DateTimeOffset*/ let normalized = value.ToUniversalTime();
                $.$spc.System.Diagnostics.Debug.Assert$1(normalized.Year <= 9999, "DateTimeOffset guards against this internally");
                /*scoped Span<byte>*/ let fraction = new ($.$spc.System.Span$$($.$spc.System.Byte))();
                if (!omitFractionalSeconds)
                {
                    /*long*/ let floatingTicks = normalized.Ticks % 10000000n;
                    if (floatingTicks !== 0n)
                    {
                        fraction = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 9, null);
                        /*decimal*/ let decimalTicks = $.$spc.System.Decimal.op_Implicit$7(floatingTicks);
                        decimalTicks = $.$spc.System.Decimal.op_Division(decimalTicks, $.$spc.System.Decimal.op_Implicit$7(10000000n));
                        /*int*/ let bytesWritten;
                        if (!$.$spc.System.Buffers.Text.Utf8Formatter.TryFormat$3(decimalTicks, fraction, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32), new $.$spc.System.Buffers.StandardFormat().$ctor$2(/*G*/ 71, 255)))
                        {
                            $.$spc.System.Diagnostics.Debug.Fail(`Utf8Formatter.TryFormat could not format ${floatingTicks} / TicksPerSecond`);
                            throw new $.$spc.System.InvalidOperationException().$ctor$9();
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$2(bytesWritten > 2, `${bytesWritten} should be > 2`);
                        $.$spc.System.Diagnostics.Debug.Assert$1(fraction.get_Item(0).$v === /*0*/ 48, "fraction[0] == (byte)'0'");
                        $.$spc.System.Diagnostics.Debug.Assert$1(fraction.get_Item(1).$v === /*.*/ 46, "fraction[1] == (byte)'.'");
                        fraction = fraction.Slice$1(1, ((bytesWritten - 1) | 0));
                    }
                }
                /*int*/ let IntegerPortionLength = ((((((((((4 + 2) | 0) + 2) | 0) + 2) | 0) + 2) | 0) + 2) | 0);
                /*int*/ let totalLength = ((((IntegerPortionLength + 1) | 0) + fraction.Length) | 0);
                $.$spc.System.Diagnostics.Debug.Assert$1(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(totalLength);
                /*int*/ let year = normalized.Year;
                /*int*/ let month = normalized.Month;
                /*int*/ let day = normalized.Day;
                /*int*/ let hour = normalized.Hour;
                /*int*/ let minute = normalized.Minute;
                /*int*/ let second = normalized.Second;
                /*Span<byte>*/ let baseSpan = $.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset);
                /*StandardFormat*/ let d4 = new $.$spc.System.Buffers.StandardFormat().$ctor$2(/*D*/ 68, 4);
                /*StandardFormat*/ let d2 = new $.$spc.System.Buffers.StandardFormat().$ctor$2(/*D*/ 68, 2);
                if (!$.$spc.System.Buffers.Text.Utf8Formatter.TryFormat$12(year, baseSpan.Slice$1(0, 4), $.$discardRef(), d4) || !$.$spc.System.Buffers.Text.Utf8Formatter.TryFormat$12(month, baseSpan.Slice$1(4, 2), $.$discardRef(), d2) || !$.$spc.System.Buffers.Text.Utf8Formatter.TryFormat$12(day, baseSpan.Slice$1(6, 2), $.$discardRef(), d2) || !$.$spc.System.Buffers.Text.Utf8Formatter.TryFormat$12(hour, baseSpan.Slice$1(8, 2), $.$discardRef(), d2) || !$.$spc.System.Buffers.Text.Utf8Formatter.TryFormat$12(minute, baseSpan.Slice$1(10, 2), $.$discardRef(), d2) || !$.$spc.System.Buffers.Text.Utf8Formatter.TryFormat$12(second, baseSpan.Slice$1(12, 2), $.$discardRef(), d2))
                {
                    $.$spc.System.Diagnostics.Debug.Fail((() =>
                    {
                        var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(1, 1);
                        $handler.AppendLiteral("Utf8Formatter.TryFormat failed to build components of ");
                        $handler.AppendFormatted$8($.$box(normalized, $.$spc.System.DateTimeOffset), null, "O");
                        return $handler.ToStringAndClear();
                    })());
                    throw new $.$spc.System.InvalidOperationException().$ctor$9();
                }
                this._offset += IntegerPortionLength;
                fraction.CopyTo(baseSpan.Slice(IntegerPortionLength));
                this._offset += fraction.Length;
                $.$spc.System.Array.$WriteT1.call(this._buffer, /*Z*/ 90, this._offset);
                this._offset++;
            }
            /*void */ WriteInteger(/*long*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            /*void */ WriteInteger$1(/*ulong*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 2/*UniversalTagNumber.Integer*/);
                this.WriteNonNegativeIntegerCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            /*void */ WriteInteger$2(/*BigInteger*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerCore$2((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            /*void */ WriteInteger$3(/*ReadOnlySpan<byte>*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerCore$1((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            /*void */ WriteIntegerUnsigned(/*ReadOnlySpan<byte>*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 2/*UniversalTagNumber.Integer*/);
                this.WriteIntegerUnsignedCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Integer, value);
            }
            /*void */ WriteIntegerCore(/*Asn1Tag*/ tag, /*long*/ value)
            {
                if (value >= 0n)
                {
                    this.WriteNonNegativeIntegerCore(tag, $.$cast(value, $.$spc.System.UInt64));
                    return;
                }
                /*int*/ let valueLength;
                if (value >= BigInt(-128/*sbyte.MinValue*/))
                {
                    valueLength = 1;
                }
                else if (value >= BigInt(-32768/*short.MinValue*/))
                {
                    valueLength = 2;
                }
                else if (value >= $.$cast(18446744073701163008n, $.$spc.System.Int64))
                {
                    valueLength = 3;
                }
                else if (value >= BigInt(-2147483648/*int.MinValue*/))
                {
                    valueLength = 4;
                }
                else if (value >= $.$cast(18446743523953737728n, $.$spc.System.Int64))
                {
                    valueLength = 5;
                }
                else if (value >= $.$cast(18446603336221196288n, $.$spc.System.Int64))
                {
                    valueLength = 6;
                }
                else if (value >= $.$cast(18410715276690587648n, $.$spc.System.Int64))
                {
                    valueLength = 7;
                }
                else 
                {
                    valueLength = 8;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(valueLength);
                /*long*/ let remaining = value;
                /*int*/ let idx = ((((this._offset + valueLength) | 0) - 1) | 0);
                do
                {
                    $.$spc.System.Array.$WriteT1.call(this._buffer, $.$cast(remaining, $.$spc.System.Byte), idx);
                    remaining >>= 8n;
                    idx--;
                }
                while(idx >= this._offset);
                if (valueLength > 1)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Array.$ReadT1.call(this._buffer, this._offset) !== 255 || $.$spc.System.Array.$ReadT1.call(this._buffer, ((this._offset + 1) | 0)) < 128, "_buffer[_offset] != 0xFF || _buffer[_offset + 1] < 0x80");
                }
                this._offset += valueLength;
            }
            /*void */ WriteNonNegativeIntegerCore(/*Asn1Tag*/ tag, /*ulong*/ value)
            {
                /*int*/ let valueLength;
                if (value < 128n)
                {
                    valueLength = 1;
                }
                else if (value < 32768n)
                {
                    valueLength = 2;
                }
                else if (value < 8388608n)
                {
                    valueLength = 3;
                }
                else if (value < 2147483648n)
                {
                    valueLength = 4;
                }
                else if (value < 549755813888n)
                {
                    valueLength = 5;
                }
                else if (value < 140737488355328n)
                {
                    valueLength = 6;
                }
                else if (value < 36028797018963968n)
                {
                    valueLength = 7;
                }
                else if (value < 9223372036854775808n)
                {
                    valueLength = 8;
                }
                else 
                {
                    valueLength = 9;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(valueLength);
                /*ulong*/ let remaining = value;
                /*int*/ let idx = ((((this._offset + valueLength) | 0) - 1) | 0);
                do
                {
                    $.$spc.System.Array.$WriteT1.call(this._buffer, $.$cast(remaining, $.$spc.System.Byte), idx);
                    remaining >>= 8n;
                    idx--;
                }
                while(idx >= this._offset);
                if (valueLength > 1)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Array.$ReadT1.call(this._buffer, this._offset) !== 0 || $.$spc.System.Array.$ReadT1.call(this._buffer, ((this._offset + 1) | 0)) > 127, "_buffer[_offset] != 0 || _buffer[_offset + 1] > 0x7F");
                }
                this._offset += valueLength;
            }
            /*void */ WriteIntegerUnsignedCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ value)
            {
                if (value.IsEmpty)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_IntegerCannotBeEmpty, "value");
                }
                if (value.Length > 1 && value.get_Item(0).$v === 0 && value.get_Item(1).$v < 128)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_IntegerRedundantByte, "value");
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                if (value.get_Item(0).$v >= 128)
                {
                    this.WriteLength($.$checked(value.Length + 1, 1));
                    $.$spc.System.Array.$WriteT1.call(this._buffer, 0, this._offset);
                    this._offset++;
                }
                else 
                {
                    this.WriteLength(value.Length);
                }
                value.CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset));
                this._offset += value.Length;
            }
            /*void */ WriteIntegerCore$1(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ value)
            {
                if (value.IsEmpty)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_IntegerCannotBeEmpty, "value");
                }
                /*ushort*/ let bigEndianValue;
                if ($.$spc.System.Buffers.Binary.BinaryPrimitives.TryReadUInt16BigEndian(value, $.$ref(() => bigEndianValue, ($v) => bigEndianValue = $v, $.$spc.System.UInt16)))
                {
                    /*ushort*/ let RedundancyMask = 65408;
                    /*ushort*/ let masked = $.$cast((bigEndianValue & RedundancyMask), $.$spc.System.UInt16);
                    if (masked === 0 || masked === RedundancyMask)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_IntegerRedundantByte, "value");
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(value.Length);
                value.CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset));
                this._offset += value.Length;
            }
            /*void */ WriteIntegerCore$2(/*Asn1Tag*/ tag, /*BigInteger*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(value.GetByteCount(false));
                /*int*/ let bytesWritten;
                value.TryWriteBytes($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32), false, true);
                this._offset += bytesWritten;
            }
            /*void */ WriteNamedBitList(/*Enum*/ value, /*Asn1Tag?*/ tag)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 3/*UniversalTagNumber.BitString*/);
                this.WriteNamedBitList$3(tag?.Clone(), $.$spc.System.Object.GetType.call(value), value);
            }
            /*void */ WriteNamedBitList$1(TEnum, /*TEnum*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 3/*UniversalTagNumber.BitString*/);
                this.WriteNamedBitList$3(tag?.Clone(), TEnum.$type, value);
            }
            /*void */ WriteNamedBitList$2(/*BitArray*/ value, /*Asn1Tag?*/ tag)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 3/*UniversalTagNumber.BitString*/);
                this.WriteBitArray(value, tag?.Clone());
            }
            /*void */ WriteNamedBitList$3(/*Asn1Tag?*/ tag, /*Type*/ tEnum, /*Enum*/ value)
            {
                /*Type*/ let backingType = tEnum.GetEnumUnderlyingType();
                if (!tEnum.IsDefined($.$spc.System.FlagsAttribute.$type, false))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_NamedBitListRequiresFlagsEnum, "tEnum");
                }
                /*ulong*/ let integralValue;
                if ($.$spc.System.Type.op_Equality$1(backingType, $.$spc.System.SByte.$type))
                {
                    integralValue = BigInt($.$cast($.$spc.System.Convert.ToSByte(value), $.$spc.System.Byte));
                }
                else if ($.$spc.System.Type.op_Equality$1(backingType, $.$spc.System.Int16.$type))
                {
                    integralValue = BigInt($.$cast($.$spc.System.Convert.ToInt16(value), $.$spc.System.UInt16));
                }
                else if ($.$spc.System.Type.op_Equality$1(backingType, $.$spc.System.Int32.$type))
                {
                    integralValue = BigInt(($.$spc.System.Convert.ToInt32(value) >>> 0));
                }
                else if ($.$spc.System.Type.op_Equality$1(backingType, $.$spc.System.UInt64.$type))
                {
                    integralValue = $.$spc.System.Convert.ToUInt64(value);
                }
                else 
                {
                    integralValue = $.$cast($.$spc.System.Convert.ToInt64(value), $.$spc.System.UInt64);
                }
                this.WriteNamedBitList$4(tag?.Clone(), integralValue);
            }
            /*void */ WriteNamedBitList$4(/*Asn1Tag?*/ tag, /*ulong*/ integralValue)
            {
                /*Span<byte>*/ let temp = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, $.$spc.System.UInt64.$z, null);
                temp.Clear();
                /*int*/ let indexOfHighestSetBit = -1;
                for(/*int*/ let i = 0; integralValue !== 0n; integralValue >>= 1n, i++)
                {
                    if ((integralValue & 1n) !== 0n)
                    {
                        temp.get_Item($.trunc(i / 8)).$v |= $.$cast((128 >> (i % 8)), $.$spc.System.Byte);
                        indexOfHighestSetBit = i;
                    }
                }
                if (indexOfHighestSetBit < 0)
                {
                    this.WriteBitString($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).Empty, 0, tag?.Clone());
                }
                else 
                {
                    /*int*/ let byteLen = ((($.trunc(indexOfHighestSetBit / 8)) + 1) | 0);
                    /*int*/ let unusedBitCount = ((7 - (indexOfHighestSetBit % 8)) | 0);
                    this.WriteBitString($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(temp.Slice$1(0, byteLen)), unusedBitCount, tag?.Clone());
                }
            }
            /*void */ WriteBitArray(/*BitArray*/ value, /*Asn1Tag?*/ tag)
            {
                if (value.Count === 0)
                {
                    this.WriteBitString($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).Empty, 0, tag?.Clone());
                    return;
                }
                /*int*/ let requiredBytes = $.trunc(($.$checked(value.Count + 7, 1)) / 8);
                /*int*/ let unusedBits = ((((requiredBytes * 8) | 0) - value.Count) | 0);
                /*byte[]*/ let rented = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(requiredBytes);
                value.CopyTo(rented, 0);
                /*Span<byte>*/ let valueSpan = $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, rented, 0, requiredBytes);
                $.$sfa.System.Formats.Asn1.AsnDecoder.ReverseBitsPerByte(valueSpan);
                this.WriteBitString($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(valueSpan), unusedBits, tag?.Clone());
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(rented, requiredBytes);
            }
            /*void */ WriteNull(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 5/*UniversalTagNumber.Null*/);
                this.WriteNullCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Null);
            }
            /*void */ WriteNullCore(/*Asn1Tag*/ tag)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                this.WriteLength(0);
            }
            /*Scope */ PushOctetString(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 4/*UniversalTagNumber.OctetString*/);
                return this.PushTag((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedOctetString, 4/*UniversalTagNumber.OctetString*/);
            }
            /*void */ PopOctetString(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 4/*UniversalTagNumber.OctetString*/);
                this.PopTag((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ConstructedOctetString, 4/*UniversalTagNumber.OctetString*/, false);
            }
            /*void */ WriteOctetString(/*ReadOnlySpan<byte>*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 4/*UniversalTagNumber.OctetString*/);
                this.WriteOctetStringCore(tag ?? $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString, value);
            }
            /*void */ WriteOctetStringCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ octetString)
            {
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (octetString.Length > 1000/*AsnReader.MaxCERSegmentSize*/)
                    {
                        this.WriteConstructedCerOctetString(tag, octetString);
                        return;
                    }
                }
                this.WriteTag(tag.AsPrimitive());
                this.WriteLength(octetString.Length);
                octetString.CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset));
                this._offset += octetString.Length;
            }
            /*void */ WriteConstructedCerOctetString(/*Asn1Tag*/ tag, /*ReadOnlySpan<byte>*/ payload)
            {
                /*int*/ let MaxCERSegmentSize = 1000/*AsnReader.MaxCERSegmentSize*/;
                $.$spc.System.Diagnostics.Debug.Assert$1(payload.Length > MaxCERSegmentSize, "payload.Length > MaxCERSegmentSize");
                this.WriteTag(tag.AsConstructed());
                this.WriteLength(-1);
                /*int*/ let lastSegmentSize;
                /*int*/ let fullSegments = $.$spc.System.Math.DivRem(payload.Length, MaxCERSegmentSize, $.$ref(() => lastSegmentSize, ($v) => lastSegmentSize = $v, $.$spc.System.Int32));
                /*int*/ let FullSegmentEncodedSize = 1004;
                $.$spc.System.Diagnostics.Debug.Assert$1(FullSegmentEncodedSize === ((((((1 + 1) | 0) + MaxCERSegmentSize) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)) | 0), "FullSegmentEncodedSize == 1 + 1 + MaxCERSegmentSize + GetEncodedLengthSubsequentByteCount(MaxCERSegmentSize)");
                /*int*/ let remainingEncodedSize;
                if (lastSegmentSize === 0)
                {
                    remainingEncodedSize = 0;
                }
                else 
                {
                    remainingEncodedSize = ((((2 + lastSegmentSize) | 0) + $.$sfa.System.Formats.Asn1.AsnWriter.GetEncodedLengthSubsequentByteCount(lastSegmentSize)) | 0);
                }
                /*int*/ let expectedSize = ((((((fullSegments * FullSegmentEncodedSize) | 0) + remainingEncodedSize) | 0) + 2) | 0);
                this.EnsureWriteCapacity(expectedSize);
                /*byte[]*/ let ensureNoExtraCopy = this._buffer;
                /*int*/ let savedOffset = this._offset;
                /*ReadOnlySpan<byte>*/ let remainingData = payload;
                /*Span<byte>*/ let dest;
                /*Asn1Tag*/ let primitiveOctetString = $.$sfa.System.Formats.Asn1.Asn1Tag.PrimitiveOctetString;
                while(remainingData.Length > MaxCERSegmentSize)
                {
                    this.WriteTag(primitiveOctetString);
                    this.WriteLength(MaxCERSegmentSize);
                    dest = $.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset);
                    remainingData.Slice$1(0, MaxCERSegmentSize).CopyTo(dest);
                    this._offset += MaxCERSegmentSize;
                    remainingData = remainingData.Slice(MaxCERSegmentSize);
                }
                this.WriteTag(primitiveOctetString);
                this.WriteLength(remainingData.Length);
                dest = $.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset);
                remainingData.CopyTo(dest);
                this._offset += remainingData.Length;
                this.WriteEndOfContents();
                $.$spc.System.Diagnostics.Debug.Assert$2(((this._offset - savedOffset) | 0) === expectedSize, `expected size was ${expectedSize}, actual was ${((this._offset - savedOffset) | 0)}`);
                $.$spc.System.Diagnostics.Debug.Assert$1(this._buffer === ensureNoExtraCopy, `_buffer was replaced during ${"WriteConstructedCerOctetString"}`);
            }
            /*void */ WriteObjectIdentifier(/*string*/ oidValue, /*Asn1Tag?*/ tag)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(oidValue, "oidValue");
                this.WriteObjectIdentifier$1($.$spc.System.MemoryExtensions.AsSpan$3(oidValue), tag?.Clone());
            }
            /*void */ WriteObjectIdentifier$1(/*ReadOnlySpan<char>*/ oidValue, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 6/*UniversalTagNumber.ObjectIdentifier*/);
                /*ReadOnlySpan<byte>*/ let wellKnownContents = $.$sfa.System.Formats.Asn1.WellKnownOids.GetContents(oidValue);
                if (!wellKnownContents.IsEmpty)
                {
                    this.WriteTag((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ObjectIdentifier);
                    this.WriteLength(wellKnownContents.Length);
                    wellKnownContents.CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset));
                    this._offset += wellKnownContents.Length;
                    return;
                }
                this.WriteObjectIdentifierCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.ObjectIdentifier, oidValue);
            }
            /*void */ WriteObjectIdentifierCore(/*Asn1Tag*/ tag, /*ReadOnlySpan<char>*/ oidValue)
            {
                if (oidValue.Length < 3)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                }
                if (oidValue.get_Item(1).$v !== /*.*/ 46)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                }
                /*byte[]*/ let tmp = $.$sfa.System.Security.Cryptography.CryptoPool.Rent($.trunc(oidValue.Length / 2));
                /*int*/ let tmpOffset = 0;
                try
                {
                    /*int*/ let firstComponent = (() =>
                    {
                        let $switch1 = oidValue.get_Item(0).$v;
                        if ($switch1 === /*0*/ 48)
                        {
                            return 0;
                        }
                        if ($switch1 === /*1*/ 49)
                        {
                            return 1;
                        }
                        if ($switch1 === /*2*/ 50)
                        {
                            return 2;
                        }
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                    })();
                    /*ReadOnlySpan<char>*/ let remaining = oidValue.Slice(2);
                    /*BigInteger*/ let subIdentifier = $.$sfa.System.Formats.Asn1.AsnWriter.ParseSubIdentifier($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Char), () => remaining, ($v) => remaining = $v, null));
                    if (firstComponent <= 1 && $.$srn.System.Numerics.BigInteger.op_GreaterThanOrEqual$1(subIdentifier, 40n))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                    }
                    subIdentifier = $.$srn.System.Numerics.BigInteger.op_Addition(subIdentifier, $.$srn.System.Numerics.BigInteger.op_Implicit$3(((40 * firstComponent) | 0)));
                    /*int*/ let localLen = $.$sfa.System.Formats.Asn1.AsnWriter.EncodeSubIdentifier($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, tmp, tmpOffset), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Numerics.BigInteger, () => subIdentifier, ($v) => subIdentifier = $v, null));
                    tmpOffset += localLen;
                    while(!remaining.IsEmpty)
                    {
                        subIdentifier = $.$sfa.System.Formats.Asn1.AsnWriter.ParseSubIdentifier($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.ReadOnlySpan$$($.$spc.System.Char), () => remaining, ($v) => remaining = $v, null));
                        localLen = $.$sfa.System.Formats.Asn1.AsnWriter.EncodeSubIdentifier($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, tmp, tmpOffset), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$srn.System.Numerics.BigInteger, () => subIdentifier, ($v) => subIdentifier = $v, null));
                        tmpOffset += localLen;
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(!tag.IsConstructed, "!tag.IsConstructed");
                    this.WriteTag(tag);
                    this.WriteLength(tmpOffset);
                    $.$spc.System.Buffer.BlockCopy(tmp, 0, this._buffer, this._offset, tmpOffset);
                    this._offset += tmpOffset;
                }
                finally
                {
                    {
                        $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(tmp, tmpOffset);
                    }
                }
            }
            static /*BigInteger */ ParseSubIdentifier(/*ref ReadOnlySpan<char>*/ oidValue)
            {
                /*int*/ let endIndex = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, oidValue.$v, /*.*/ 46);
                if (endIndex === -1)
                {
                    endIndex = oidValue.$v.Length;
                }
                else if (endIndex === 0 || endIndex === ((oidValue.$v.Length - 1) | 0))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                }
                /*BigInteger*/ let value = $.$srn.System.Numerics.BigInteger.Zero;
                for(/*int*/ let position = 0; position < endIndex; position++)
                {
                    if (position > 0 && $.$srn.System.Numerics.BigInteger.op_Equality$1(value, 0n))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
                    }
                    value = $.$srn.System.Numerics.BigInteger.op_Multiply(value, $.$srn.System.Numerics.BigInteger.op_Implicit$3(10));
                    value = $.$srn.System.Numerics.BigInteger.op_Addition(value, $.$srn.System.Numerics.BigInteger.op_Implicit$3($.$sfa.System.Formats.Asn1.AsnWriter.AtoI(oidValue.$v.get_Item(position).$v)));
                }
                oidValue.$v = oidValue.$v.Slice($.$spc.System.Math.Min$4(oidValue.$v.Length, ((endIndex + 1) | 0)));
                return value;
            }
            static /*int */ AtoI(/*char*/ c)
            {
                if (c >= /*0*/ 48 && c <= /*9*/ 57)
                {
                    return c - /*0*/ 48;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_InvalidOidValue, "oidValue");
            }
            static /*int */ EncodeSubIdentifier(/*Span<byte>*/ dest, /*ref BigInteger*/ subIdentifier)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(dest.Length > 0, "dest.Length > 0");
                if (subIdentifier.$v.IsZero)
                {
                    dest.get_Item(0).$v = 0;
                    return 1;
                }
                /*BigInteger*/ let unencoded = subIdentifier.$v;
                /*int*/ let idx = 0;
                do
                {
                    /*BigInteger*/ let cur = $.$srn.System.Numerics.BigInteger.op_BitwiseAnd(unencoded, $.$srn.System.Numerics.BigInteger.op_Implicit$3(127));
                    /*byte*/ let curByte = $.$srn.System.Numerics.BigInteger.op_Explicit(cur);
                    if ($.$srn.System.Numerics.BigInteger.op_Inequality(subIdentifier.$v, unencoded))
                    {
                        curByte |= 128;
                    }
                    unencoded = $.$srn.System.Numerics.BigInteger.op_RightShift(unencoded, 7);
                    dest.get_Item(idx).$v = curByte;
                    idx++;
                }
                while($.$srn.System.Numerics.BigInteger.op_Inequality(unencoded, $.$srn.System.Numerics.BigInteger.Zero));
                $.$spc.System.MemoryExtensions.Reverse($.$spc.System.Byte, dest.Slice$1(0, idx));
                return idx;
            }
            /*Scope */ PushSequence(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 16/*UniversalTagNumber.Sequence*/);
                return this.PushSequenceCore((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Sequence);
            }
            /*void */ PopSequence(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 16/*UniversalTagNumber.Sequence*/);
                this.PopSequenceCore((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.Sequence);
            }
            /*Scope */ PushSequenceCore(/*Asn1Tag*/ tag)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tag.IsConstructed, "tag.IsConstructed");
                return this.PushTag(tag, 16/*UniversalTagNumber.Sequence*/);
            }
            /*void */ PopSequenceCore(/*Asn1Tag*/ tag)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tag.IsConstructed, "tag.IsConstructed");
                this.PopTag(tag, 16/*UniversalTagNumber.Sequence*/, false);
            }
            /*Scope */ PushSetOf(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 17/*UniversalTagNumber.SetOf*/);
                return this.PushSetOfCore((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.SetOf);
            }
            /*void */ PopSetOf(/*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 17/*UniversalTagNumber.SetOf*/);
                this.PopSetOfCore((tag?.AsConstructed() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.SetOf);
            }
            /*Scope */ PushSetOfCore(/*Asn1Tag*/ tag)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tag.IsConstructed, "tag.IsConstructed");
                return this.PushTag(tag, 17/*UniversalTagNumber.SetOf*/);
            }
            /*void */ PopSetOfCore(/*Asn1Tag*/ tag)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(tag.IsConstructed, "tag.IsConstructed");
                /*bool*/ let sortContents = this.RuleSet === 1/*AsnEncodingRules.CER*/ || this.RuleSet === 2/*AsnEncodingRules.DER*/;
                this.PopTag(tag, 17/*UniversalTagNumber.SetOf*/, sortContents);
            }
            /*void */ WriteCharacterString(/*UniversalTagNumber*/ encodingType, /*string*/ value, /*Asn1Tag?*/ tag)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                this.WriteCharacterString$1(encodingType, $.$spc.System.MemoryExtensions.AsSpan$3(value), tag?.Clone());
            }
            /*void */ WriteCharacterString$1(/*UniversalTagNumber*/ encodingType, /*ReadOnlySpan<char>*/ str, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), encodingType);
                /*Text.Encoding*/ let encoding = $.$sfa.System.Formats.Asn1.AsnCharacterStringEncodings.GetEncoding(encodingType);
                this.WriteCharacterStringCore(tag ?? new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$3(encodingType, false), encoding, str);
            }
            /*void */ WriteCharacterStringCore(/*Asn1Tag*/ tag, /*Text.Encoding*/ encoding, /*ReadOnlySpan<char>*/ str)
            {
                /*int*/ let size = encoding.GetByteCount$5(str);
                if (this.RuleSet === 1/*AsnEncodingRules.CER*/)
                {
                    if (size > 1000/*AsnReader.MaxCERSegmentSize*/)
                    {
                        this.WriteConstructedCerCharacterString(tag, encoding, str, size);
                        return;
                    }
                }
                this.WriteTag(tag.AsPrimitive());
                this.WriteLength(size);
                /*Span<byte>*/ let dest = $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, this._buffer, this._offset, size);
                /*int*/ let written = encoding.GetBytes$7(str, dest);
                if (written !== size)
                {
                    $.$spc.System.Diagnostics.Debug.Fail(`Encoding produced different answer for GetByteCount (${size}) and GetBytes (${written})`);
                    throw new $.$spc.System.InvalidOperationException().$ctor$9();
                }
                this._offset += size;
            }
            /*void */ WriteConstructedCerCharacterString(/*Asn1Tag*/ tag, /*Text.Encoding*/ encoding, /*ReadOnlySpan<char>*/ str, /*int*/ size)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(size > 1000/*AsnReader.MaxCERSegmentSize*/, "size > AsnReader.MaxCERSegmentSize");
                /*byte[]*/ let tmp = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(size);
                /*int*/ let written = encoding.GetBytes$7(str, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(tmp));
                if (written !== size)
                {
                    $.$spc.System.Diagnostics.Debug.Fail(`Encoding produced different answer for GetByteCount (${size}) and GetBytes (${written})`);
                    throw new $.$spc.System.InvalidOperationException().$ctor$9();
                }
                this.WriteConstructedCerOctetString(tag, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, tmp, 0, size)));
                $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(tmp, size);
            }
            /*void */ WriteUtcTime(/*DateTimeOffset*/ value, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 23/*UniversalTagNumber.UtcTime*/);
                this.WriteUtcTimeCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.UtcTime, value);
            }
            /*void */ WriteUtcTime$1(/*DateTimeOffset*/ value, /*int*/ twoDigitYearMax, /*Asn1Tag?*/ tag)
            {
                $.$sfa.System.Formats.Asn1.AsnWriter.CheckUniversalTag(tag?.Clone(), 23/*UniversalTagNumber.UtcTime*/);
                value = value.ToUniversalTime();
                if (value.Year > twoDigitYearMax || value.Year <= ((twoDigitYearMax - 100) | 0))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("value");
                }
                this.WriteUtcTimeCore((tag?.AsPrimitive() ?? null) ?? $.$sfa.System.Formats.Asn1.Asn1Tag.UtcTime, value);
            }
            /*void */ WriteUtcTimeCore(/*Asn1Tag*/ tag, /*DateTimeOffset*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!tag.IsConstructed, "!tag.IsConstructed");
                this.WriteTag(tag);
                /*int*/ let UtcTimeValueLength = 13;
                this.WriteLength(UtcTimeValueLength);
                /*DateTimeOffset*/ let normalized = value.ToUniversalTime();
                /*int*/ let year = normalized.Year;
                /*int*/ let month = normalized.Month;
                /*int*/ let day = normalized.Day;
                /*int*/ let hour = normalized.Hour;
                /*int*/ let minute = normalized.Minute;
                /*int*/ let second = normalized.Second;
                /*Span<byte>*/ let baseSpan = $.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._buffer, this._offset);
                /*StandardFormat*/ let format = new $.$spc.System.Buffers.StandardFormat().$ctor$2(/*D*/ 68, 2);
                if (!$.$spc.System.Buffers.Text.Utf8Formatter.TryFormat$12(year % 100, baseSpan.Slice$1(0, 2), $.$discardRef(), format) || !$.$spc.System.Buffers.Text.Utf8Formatter.TryFormat$12(month, baseSpan.Slice$1(2, 2), $.$discardRef(), format) || !$.$spc.System.Buffers.Text.Utf8Formatter.TryFormat$12(day, baseSpan.Slice$1(4, 2), $.$discardRef(), format) || !$.$spc.System.Buffers.Text.Utf8Formatter.TryFormat$12(hour, baseSpan.Slice$1(6, 2), $.$discardRef(), format) || !$.$spc.System.Buffers.Text.Utf8Formatter.TryFormat$12(minute, baseSpan.Slice$1(8, 2), $.$discardRef(), format) || !$.$spc.System.Buffers.Text.Utf8Formatter.TryFormat$12(second, baseSpan.Slice$1(10, 2), $.$discardRef(), format))
                {
                    $.$spc.System.Diagnostics.Debug.Fail((() =>
                    {
                        var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(1, 1);
                        $handler.AppendLiteral("Utf8Formatter.TryFormat failed to build components of ");
                        $handler.AppendFormatted$8($.$box(normalized, $.$spc.System.DateTimeOffset), null, "O");
                        return $handler.ToStringAndClear();
                    })());
                    throw new $.$spc.System.InvalidOperationException().$ctor$9();
                }
                $.$spc.System.Array.$WriteT1.call(this._buffer, /*Z*/ 90, ((this._offset + 12) | 0));
                this._offset += UtcTimeValueLength;
            }
            //default member initializer
            constructor()
            {
                super();
                this._buffer = null;
                this.RuleSet = 0;
            }
            static $h = 774296;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":577688,"g":{"r":0,"d":0,"h":30065545368,"f":1},"n":"RuleSet","d":774296,"h":25770578072,"f":1}],"m":[{"r":65537,"n":"Reset","d":774296,"h":42950447256,"f":1},{"r":655361,"n":"GetEncodedLength","d":774296,"h":47245414552,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryEncode","d":774296,"h":51540381848,"f":1},{"r":655361,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Encode","d":774296,"h":55835349144,"f":1},{"r":0,"n":"Encode","o":"@$1","d":774296,"h":60130316440,"f":1},{"r":60133146624,"p":[{"n":"encodeCallback","p":(TReturn) => $.$spc.System.Func$$$($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), TReturn).$h}],"g":["TReturn"],"n":"Encode","o":"@$2","d":774296,"h":64425283736,"f":131073},{"r":64428179456,"p":[{"n":"state","p":64428113920},{"n":"encodeCallback","p":(TState, TReturn) => $.$spc.System.Func$$$$(TState, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte), TReturn).$h}],"g":["TState","TReturn"],"n":"Encode","o":"@$3","d":774296,"h":68720251032,"f":131073},{"r":65537,"p":[{"n":"state","p":68723081216},{"n":"encodeCallback","p":(TState) => $.$spc.System.Action$$$(TState, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)).$h}],"g":["TState"],"n":"Encode","o":"@$4","d":774296,"h":73015218328,"f":131073},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"n":"EncodeAsSpan","d":774296,"h":77310185624,"f":2},{"r":262145,"p":[{"n":"other","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"EncodedValueEquals","d":774296,"h":81605152920,"f":1},{"r":262145,"p":[{"n":"other","p":774296}],"n":"EncodedValueEquals","o":"@$1","d":774296,"h":85900120216,"f":1},{"r":65537,"p":[{"n":"pendingCount","p":655361}],"n":"EnsureWriteCapacity","d":774296,"h":90195087512,"f":2},{"r":65537,"p":[{"n":"tag","p":118936}],"n":"WriteTag","d":774296,"h":94490054808,"f":2},{"r":65537,"p":[{"n":"length","p":655361}],"n":"WriteLength","d":774296,"h":98785022104,"f":2},{"r":655361,"p":[{"n":"length","p":655361}],"n":"GetEncodedLengthSubsequentByteCount","d":774296,"h":103079989400,"f":34},{"r":65537,"p":[{"n":"destination","p":774296}],"n":"CopyTo","d":774296,"h":107374956696,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"WriteEncodedValue","d":774296,"h":111669923992,"f":1},{"r":65537,"n":"WriteEndOfContents","d":774296,"h":115964891288,"f":2},{"r":905368,"p":[{"n":"tag","p":118936},{"n":"tagType","p":1626264}],"n":"PushTag","d":774296,"h":120259858584,"f":2},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"tagType","p":1626264},{"n":"sortContents","p":262145,"f":65,"v":false}],"n":"PopTag","d":774296,"h":124554825880,"f":2},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"start","p":655361},{"n":"end","p":655361}],"n":"SortContents","d":774296,"h":128849793176,"f":34},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h},{"n":"universalTagNumber","p":1626264}],"n":"CheckUniversalTag","d":774296,"h":133144760472,"f":34},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"unusedBitCount","p":655361,"f":65,"v":0},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteBitString","d":774296,"h":150324629656,"f":1},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"bitString","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"unusedBitCount","p":655361}],"n":"WriteBitStringCore","d":774296,"h":154619596952,"f":2},{"r":262145,"p":[{"n":"lastByte","p":393217},{"n":"unusedBitCount","p":655361}],"n":"CheckValidLastByte","d":774296,"h":158914564248,"f":34},{"r":655361,"p":[{"n":"tag","p":118936},{"n":"contentLength","p":655361}],"n":"DetermineCerBitStringTotalLength","d":774296,"h":163209531544,"f":34},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"payload","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"unusedBitCount","p":655361}],"n":"WriteConstructedCerBitString","d":774296,"h":167504498840,"f":2},{"r":65537,"p":[{"n":"value","p":262145},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteBoolean","d":774296,"h":171799466136,"f":1},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"value","p":262145}],"n":"WriteBooleanCore","d":774296,"h":176094433432,"f":2},{"r":65537,"p":[{"n":"value","p":1048577},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteEnumeratedValue","d":774296,"h":180389400728,"f":1},{"r":65537,"p":[{"n":"value","p":180392230912},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"g":["TEnum"],"n":"WriteEnumeratedValue","o":"@$1","d":774296,"h":184684368024,"f":131073},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"tEnum","p":142606337},{"n":"value","p":131073}],"n":"WriteEnumeratedValue","o":"@$2","d":774296,"h":188979335320,"f":2},{"r":65537,"p":[{"n":"value","p":34340865},{"n":"omitFractionalSeconds","p":262145,"f":65,"v":false},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteGeneralizedTime","d":774296,"h":193274302616,"f":1},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"value","p":34340865},{"n":"omitFractionalSeconds","p":262145}],"n":"WriteGeneralizedTimeCore","d":774296,"h":197569269912,"f":2},{"r":65537,"p":[{"n":"value","p":917505},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteInteger","d":774296,"h":201864237208,"f":1},{"r":65537,"p":[{"n":"value","p":983041},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteInteger","o":"@$1","d":774296,"h":206159204504,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"value","p":830849},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteInteger","o":"@$2","d":774296,"h":210454171800,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteInteger","o":"@$3","d":774296,"h":214749139096,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteIntegerUnsigned","d":774296,"h":219044106392,"f":1},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"value","p":917505}],"n":"WriteIntegerCore","d":774296,"h":223339073688,"f":2},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"value","p":983041}],"n":"WriteNonNegativeIntegerCore","d":774296,"h":227634040984,"f":2},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"WriteIntegerUnsignedCore","d":774296,"h":231929008280,"f":2},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"WriteIntegerCore","o":"@$1","d":774296,"h":236223975576,"f":2},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"value","p":830849}],"n":"WriteIntegerCore","o":"@$2","d":774296,"h":240518942872,"f":2},{"r":65537,"p":[{"n":"value","p":1048577},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteNamedBitList","d":774296,"h":244813910168,"f":1},{"r":65537,"p":[{"n":"value","p":244816740352},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"g":["TEnum"],"n":"WriteNamedBitList","o":"@$1","d":774296,"h":249108877464,"f":131073},{"r":65537,"p":[{"n":"value","p":24379393},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteNamedBitList","o":"@$2","d":774296,"h":253403844760,"f":1},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h},{"n":"tEnum","p":142606337},{"n":"value","p":1048577}],"n":"WriteNamedBitList","o":"@$3","d":774296,"h":257698812056,"f":2},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h},{"n":"integralValue","p":983041}],"n":"WriteNamedBitList","o":"@$4","d":774296,"h":261993779352,"f":2},{"r":65537,"p":[{"n":"value","p":24379393},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h}],"n":"WriteBitArray","d":774296,"h":266288746648,"f":2},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteNull","d":774296,"h":270583713944,"f":1},{"r":65537,"p":[{"n":"tag","p":118936}],"n":"WriteNullCore","d":774296,"h":274878681240,"f":2},{"r":905368,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"PushOctetString","d":774296,"h":279173648536,"f":1},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"PopOctetString","d":774296,"h":283468615832,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteOctetString","d":774296,"h":287763583128,"f":1},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"octetString","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"WriteOctetStringCore","d":774296,"h":292058550424,"f":2},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"payload","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"WriteConstructedCerOctetString","d":774296,"h":296353517720,"f":2},{"r":65537,"p":[{"n":"oidValue","p":1310721},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteObjectIdentifier","d":774296,"h":300648485016,"f":1},{"r":65537,"p":[{"n":"oidValue","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteObjectIdentifier","o":"@$1","d":774296,"h":304943452312,"f":1},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"oidValue","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"WriteObjectIdentifierCore","d":774296,"h":309238419608,"f":2},{"r":830849,"p":[{"n":"oidValue","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"f":4}],"n":"ParseSubIdentifier","d":774296,"h":313533386904,"f":34},{"r":655361,"p":[{"n":"c","p":458753}],"n":"AtoI","d":774296,"h":317828354200,"f":34},{"r":655361,"p":[{"n":"dest","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"subIdentifier","p":830849,"f":4}],"n":"EncodeSubIdentifier","d":774296,"h":322123321496,"f":34},{"r":905368,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"PushSequence","d":774296,"h":326418288792,"f":1},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"PopSequence","d":774296,"h":330713256088,"f":1},{"r":905368,"p":[{"n":"tag","p":118936}],"n":"PushSequenceCore","d":774296,"h":335008223384,"f":2},{"r":65537,"p":[{"n":"tag","p":118936}],"n":"PopSequenceCore","d":774296,"h":339303190680,"f":2},{"r":905368,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"PushSetOf","d":774296,"h":343598157976,"f":1},{"r":65537,"p":[{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"PopSetOf","d":774296,"h":347893125272,"f":1},{"r":905368,"p":[{"n":"tag","p":118936}],"n":"PushSetOfCore","d":774296,"h":352188092568,"f":2},{"r":65537,"p":[{"n":"tag","p":118936}],"n":"PopSetOfCore","d":774296,"h":356483059864,"f":2},{"r":65537,"p":[{"n":"encodingType","p":1626264},{"n":"value","p":1310721},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteCharacterString","d":774296,"h":360778027160,"f":1},{"r":65537,"p":[{"n":"encodingType","p":1626264},{"n":"str","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteCharacterString","o":"@$1","d":774296,"h":365072994456,"f":1},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"encoding","p":121831425},{"n":"str","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"WriteCharacterStringCore","d":774296,"h":369367961752,"f":2},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"encoding","p":121831425},{"n":"str","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"size","p":655361}],"n":"WriteConstructedCerCharacterString","d":774296,"h":373662929048,"f":2},{"r":65537,"p":[{"n":"value","p":34340865},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteUtcTime","d":774296,"h":377957896344,"f":1},{"r":65537,"p":[{"n":"value","p":34340865},{"n":"twoDigitYearMax","p":655361},{"n":"tag","p":$.$typeNullable($.$sfa.System.Formats.Asn1.Asn1Tag).$h,"f":65}],"n":"WriteUtcTime","o":"@$1","d":774296,"h":382252863640,"f":1},{"r":65537,"p":[{"n":"tag","p":118936},{"n":"value","p":34340865}],"n":"WriteUtcTimeCore","d":774296,"h":386547830936,"f":2}],"l":[{"t":0,"n":"_buffer","d":774296,"h":4295741592,"f":2},{"t":655361,"n":"_offset","d":774296,"h":8590708888,"f":2},{"t":$.$sc.System.Collections.Generic.Stack$$($.$sfa.System.Formats.Asn1.AsnWriter.StackFrame).$h,"n":"_nestingStack","d":774296,"h":12885676184,"f":2},{"t":655361,"n":"_encodeDepth","d":774296,"h":17180643480,"f":2}],"c":[{"p":[{"n":"ruleSet","p":577688}],"n":".ctor","o":"$ctor$1","d":774296,"h":34360512664,"f":1},{"p":[{"n":"ruleSet","p":577688},{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$2","d":774296,"h":38655479960,"f":1}],"j":[839832,970904,905368],"h":774296}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.AsnWriter`; }
        });
        
        $asm.$cls("$sfa.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 1822872;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":1822872,"h":4296790168,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":1822872,"h":8591757464,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":1822872,"h":12886724760,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":1822872,"h":17181692056,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":1822872,"h":21476659352,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":1822872,"h":25771626648,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":1822872,"h":30066593944,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":1822872,"h":34361561240,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":1822872,"h":38656528536,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":1822872,"h":42951495832,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":1822872,"h":47246463128,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":1822872,"h":51541430424,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":1822872,"h":55836397720,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":1822872,"h":60131365016,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":1822872,"h":64426332312,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":1822872,"h":68721299608,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":1822872,"h":73016266904,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":1822872,"h":77311234200,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":1822872,"h":81606201496,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":1822872,"h":85901168792,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":1822872,"h":90196136088,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":1822872,"h":94491103384,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":1822872,"h":98786070680,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":1822872,"h":103081037976,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":1822872,"h":107376005272,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":1822872,"h":111670972568,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":1822872,"h":115965939864,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":1822872,"h":120260907160,"f":40},{"t":1310721,"n":"WebRequestMessage","d":1822872,"h":124555874456,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":1822872,"h":128850841752,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":1822872,"h":133145809048,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":1822872,"h":137440776344,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":1822872,"h":141735743640,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":1822872,"h":146030710936,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":1822872,"h":150325678232,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":1822872,"h":154620645528,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":1822872,"h":158915612824,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":1822872,"h":163210580120,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":1822872,"h":167505547416,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":1822872,"h":171800514712,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":1822872,"h":176095482008,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":1822872,"h":180390449304,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":1822872,"h":184685416600,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":1822872,"h":188980383896,"f":40},{"t":1310721,"n":"RijndaelMessage","d":1822872,"h":193275351192,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":1822872,"h":197570318488,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":1822872,"h":201865285784,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":1822872,"h":206160253080,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":1822872,"h":210455220376,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":1822872,"h":214750187672,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":1822872,"h":219045154968,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":1822872,"h":223340122264,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":1822872,"h":227635089560,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":1822872,"h":231930056856,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":1822872,"h":236225024152,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":1822872,"h":240519991448,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":1822872,"h":244814958744,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":1822872,"h":249109926040,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":1822872,"h":253404893336,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":1822872,"h":257699860632,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":1822872,"h":261994827928,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":1822872,"h":266289795224,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":1822872,"h":270584762520,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":1822872,"h":274879729816,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":1822872,"h":279174697112,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":1822872,"h":283469664408,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":1822872,"h":287764631704,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":1822872,"h":292059599000,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":1822872,"h":296354566296,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":1822872,"h":300649533592,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":1822872,"h":304944500888,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":1822872,"h":309239468184,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":1822872,"h":313534435480,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":1822872,"h":317829402776,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":1822872,"h":322124370072,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":1822872,"h":326419337368,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":1822872,"h":330714304664,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":1822872,"h":335009271960,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":1822872,"h":339304239256,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":1822872,"h":343599206552,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":1822872,"h":347894173848,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":1822872,"h":352189141144,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":1822872,"h":356484108440,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":1822872,"h":360779075736,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":1822872,"h":365074043032,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":1822872,"h":369369010328,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":1822872,"h":373663977624,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":1822872,"h":377958944920,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":1822872,"h":382253912216,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":1822872,"h":386548879512,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":1822872,"h":390843846808,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":1822872,"h":395138814104,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":1822872,"h":399433781400,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":1822872,"h":403728748696,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":1822872,"h":408023715992,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":1822872,"h":412318683288,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":1822872,"h":416613650584,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":1822872,"h":420908617880,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":1822872,"h":425203585176,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":1822872,"h":429498552472,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":1822872,"h":433793519768,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":1822872,"h":438088487064,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":1822872,"h":442383454360,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":1822872,"h":446678421656,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":1822872,"h":450973388952,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":1822872,"h":455268356248,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":1822872,"h":459563323544,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":1822872,"h":463858290840,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":1822872,"h":468153258136,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":1822872,"h":472448225432,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":1822872,"h":476743192728,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":1822872,"h":481038160024,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":1822872,"h":485333127320,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":1822872,"h":489628094616,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":1822872,"h":493923061912,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":1822872,"h":498218029208,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":1822872,"h":502512996504,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":1822872,"h":506807963800,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":1822872,"h":511102931096,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":1822872,"h":515397898392,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":1822872,"h":519692865688,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":1822872,"h":523987832984,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":1822872,"h":528282800280,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":1822872,"h":532577767576,"f":40}],"h":1822872}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.WellKnownOids", ($self) => class WellKnownOids
        {
            static /*string? */ GetValue(/*ReadOnlySpan<byte>*/ contents)
            {
                return (() =>
                {
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 56 && contents[5] === 4 && contents[6] === 1))
                    {
                        return "1.2.840.10040.4.1";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 56 && contents[5] === 4 && contents[6] === 3))
                    {
                        return "1.2.840.10040.4.3";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 2 && contents[6] === 1))
                    {
                        return "1.2.840.10045.2.1";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 1 && contents[6] === 1))
                    {
                        return "1.2.840.10045.1.1";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 1 && contents[6] === 2))
                    {
                        return "1.2.840.10045.1.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 3 && contents[6] === 1 && contents[7] === 7))
                    {
                        return "1.2.840.10045.3.1.7";
                    }
                    if ((contents.Length === 7 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 1))
                    {
                        return "1.2.840.10045.4.1";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 3 && contents[7] === 2))
                    {
                        return "1.2.840.10045.4.3.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 3 && contents[7] === 3))
                    {
                        return "1.2.840.10045.4.3.3";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 206 && contents[4] === 61 && contents[5] === 4 && contents[6] === 3 && contents[7] === 4))
                    {
                        return "1.2.840.10045.4.3.4";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 1))
                    {
                        return "1.2.840.113549.1.1.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 5))
                    {
                        return "1.2.840.113549.1.1.5";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 7))
                    {
                        return "1.2.840.113549.1.1.7";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 8))
                    {
                        return "1.2.840.113549.1.1.8";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 9))
                    {
                        return "1.2.840.113549.1.1.9";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 10))
                    {
                        return "1.2.840.113549.1.1.10";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 11))
                    {
                        return "1.2.840.113549.1.1.11";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 12))
                    {
                        return "1.2.840.113549.1.1.12";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 1 && contents[8] === 13))
                    {
                        return "1.2.840.113549.1.1.13";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 3))
                    {
                        return "1.2.840.113549.1.5.3";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 10))
                    {
                        return "1.2.840.113549.1.5.10";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 11))
                    {
                        return "1.2.840.113549.1.5.11";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 12))
                    {
                        return "1.2.840.113549.1.5.12";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 5 && contents[8] === 13))
                    {
                        return "1.2.840.113549.1.5.13";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 1))
                    {
                        return "1.2.840.113549.1.7.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 2))
                    {
                        return "1.2.840.113549.1.7.2";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 3))
                    {
                        return "1.2.840.113549.1.7.3";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 7 && contents[8] === 6))
                    {
                        return "1.2.840.113549.1.7.6";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 1))
                    {
                        return "1.2.840.113549.1.9.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 3))
                    {
                        return "1.2.840.113549.1.9.3";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 4))
                    {
                        return "1.2.840.113549.1.9.4";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 5))
                    {
                        return "1.2.840.113549.1.9.5";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 6))
                    {
                        return "1.2.840.113549.1.9.6";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 7))
                    {
                        return "1.2.840.113549.1.9.7";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 14))
                    {
                        return "1.2.840.113549.1.9.14";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 15))
                    {
                        return "1.2.840.113549.1.9.15";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 1 && contents[10] === 4))
                    {
                        return "1.2.840.113549.1.9.16.1.4";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 2 && contents[10] === 12))
                    {
                        return "1.2.840.113549.1.9.16.2.12";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 2 && contents[10] === 14))
                    {
                        return "1.2.840.113549.1.9.16.2.14";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 16 && contents[9] === 2 && contents[10] === 47))
                    {
                        return "1.2.840.113549.1.9.16.2.47";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 20))
                    {
                        return "1.2.840.113549.1.9.20";
                    }
                    if ((contents.Length === 9 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 21))
                    {
                        return "1.2.840.113549.1.9.21";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 9 && contents[8] === 22 && contents[9] === 1))
                    {
                        return "1.2.840.113549.1.9.22.1";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 1 && contents[9] === 3))
                    {
                        return "1.2.840.113549.1.12.1.3";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 1 && contents[9] === 5))
                    {
                        return "1.2.840.113549.1.12.1.5";
                    }
                    if ((contents.Length === 10 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 1 && contents[9] === 6))
                    {
                        return "1.2.840.113549.1.12.1.6";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 1))
                    {
                        return "1.2.840.113549.1.12.10.1.1";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 2))
                    {
                        return "1.2.840.113549.1.12.10.1.2";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 3))
                    {
                        return "1.2.840.113549.1.12.10.1.3";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 5))
                    {
                        return "1.2.840.113549.1.12.10.1.5";
                    }
                    if ((contents.Length === 11 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 1 && contents[7] === 12 && contents[8] === 10 && contents[9] === 1 && contents[10] === 6))
                    {
                        return "1.2.840.113549.1.12.10.1.6";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 5))
                    {
                        return "1.2.840.113549.2.5";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 7))
                    {
                        return "1.2.840.113549.2.7";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 9))
                    {
                        return "1.2.840.113549.2.9";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 10))
                    {
                        return "1.2.840.113549.2.10";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 2 && contents[7] === 11))
                    {
                        return "1.2.840.113549.2.11";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 3 && contents[7] === 2))
                    {
                        return "1.2.840.113549.3.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 42 && contents[1] === 134 && contents[2] === 72 && contents[3] === 134 && contents[4] === 247 && contents[5] === 13 && contents[6] === 3 && contents[7] === 7))
                    {
                        return "1.2.840.113549.3.7";
                    }
                    if ((contents.Length === 9 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 17 && contents[8] === 1))
                    {
                        return "1.3.6.1.4.1.311.17.1";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 17 && contents[8] === 3 && contents[9] === 20))
                    {
                        return "1.3.6.1.4.1.311.17.3.20";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 20 && contents[8] === 2 && contents[9] === 3))
                    {
                        return "1.3.6.1.4.1.311.20.2.3";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 88 && contents[8] === 2 && contents[9] === 1))
                    {
                        return "1.3.6.1.4.1.311.88.2.1";
                    }
                    if ((contents.Length === 10 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 4 && contents[4] === 1 && contents[5] === 130 && contents[6] === 55 && contents[7] === 88 && contents[8] === 2 && contents[9] === 2))
                    {
                        return "1.3.6.1.4.1.311.88.2.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 1))
                    {
                        return "1.3.6.1.5.5.7.3.1";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 2))
                    {
                        return "1.3.6.1.5.5.7.3.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 3))
                    {
                        return "1.3.6.1.5.5.7.3.3";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 4))
                    {
                        return "1.3.6.1.5.5.7.3.4";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 8))
                    {
                        return "1.3.6.1.5.5.7.3.8";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 3 && contents[7] === 9))
                    {
                        return "1.3.6.1.5.5.7.3.9";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 6 && contents[7] === 2))
                    {
                        return "1.3.6.1.5.5.7.6.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 48 && contents[7] === 1))
                    {
                        return "1.3.6.1.5.5.7.48.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 48 && contents[7] === 1 && contents[8] === 2))
                    {
                        return "1.3.6.1.5.5.7.48.1.2";
                    }
                    if ((contents.Length === 8 && contents[0] === 43 && contents[1] === 6 && contents[2] === 1 && contents[3] === 5 && contents[4] === 5 && contents[5] === 7 && contents[6] === 48 && contents[7] === 2))
                    {
                        return "1.3.6.1.5.5.7.48.2";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 14 && contents[2] === 3 && contents[3] === 2 && contents[4] === 26))
                    {
                        return "1.3.14.3.2.26";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 14 && contents[2] === 3 && contents[3] === 2 && contents[4] === 7))
                    {
                        return "1.3.14.3.2.7";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 129 && contents[2] === 4 && contents[3] === 0 && contents[4] === 34))
                    {
                        return "1.3.132.0.34";
                    }
                    if ((contents.Length === 5 && contents[0] === 43 && contents[1] === 129 && contents[2] === 4 && contents[3] === 0 && contents[4] === 35))
                    {
                        return "1.3.132.0.35";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 3))
                    {
                        return "2.5.4.3";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 5))
                    {
                        return "2.5.4.5";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 6))
                    {
                        return "2.5.4.6";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 7))
                    {
                        return "2.5.4.7";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 8))
                    {
                        return "2.5.4.8";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 10))
                    {
                        return "2.5.4.10";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 11))
                    {
                        return "2.5.4.11";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 4 && contents[2] === 97))
                    {
                        return "2.5.4.97";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 14))
                    {
                        return "2.5.29.14";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 15))
                    {
                        return "2.5.29.15";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 17))
                    {
                        return "2.5.29.17";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 19))
                    {
                        return "2.5.29.19";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 20))
                    {
                        return "2.5.29.20";
                    }
                    if ((contents.Length === 3 && contents[0] === 85 && contents[1] === 29 && contents[2] === 35))
                    {
                        return "2.5.29.35";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 1 && contents[8] === 2))
                    {
                        return "2.16.840.1.101.3.4.1.2";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 1 && contents[8] === 22))
                    {
                        return "2.16.840.1.101.3.4.1.22";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 1 && contents[8] === 42))
                    {
                        return "2.16.840.1.101.3.4.1.42";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 2 && contents[8] === 1))
                    {
                        return "2.16.840.1.101.3.4.2.1";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 2 && contents[8] === 2))
                    {
                        return "2.16.840.1.101.3.4.2.2";
                    }
                    if ((contents.Length === 9 && contents[0] === 96 && contents[1] === 134 && contents[2] === 72 && contents[3] === 1 && contents[4] === 101 && contents[5] === 3 && contents[6] === 4 && contents[7] === 2 && contents[8] === 3))
                    {
                        return "2.16.840.1.101.3.4.2.3";
                    }
                    if ((contents.Length === 6 && contents[0] === 103 && contents[1] === 129 && contents[2] === 12 && contents[3] === 1 && contents[4] === 2 && contents[5] === 1))
                    {
                        return "2.23.140.1.2.1";
                    }
                    if ((contents.Length === 6 && contents[0] === 103 && contents[1] === 129 && contents[2] === 12 && contents[3] === 1 && contents[4] === 2 && contents[5] === 2))
                    {
                        return "2.23.140.1.2.2";
                    }
                    return null;
                })();
            }
            static /*ReadOnlySpan<byte> */ GetContents(/*ReadOnlySpan<char>*/ value)
            {
                /*ReadOnlySpan<byte>*/ let data = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 42, 134, 72, 206, 56, 4, 1, 42, 134, 72, 206, 56, 4, 3, 42, 134, 72, 206, 61, 2, 1, 42, 134, 72, 206, 61, 1, 1, 42, 134, 72, 206, 61, 1, 2, 42, 134, 72, 206, 61, 3, 1, 7, 42, 134, 72, 206, 61, 4, 1, 42, 134, 72, 206, 61, 4, 3, 2, 42, 134, 72, 206, 61, 4, 3, 3, 42, 134, 72, 206, 61, 4, 3, 4, 42, 134, 72, 134, 247, 13, 1, 1, 1, 42, 134, 72, 134, 247, 13, 1, 1, 5, 42, 134, 72, 134, 247, 13, 1, 1, 7, 42, 134, 72, 134, 247, 13, 1, 1, 8, 42, 134, 72, 134, 247, 13, 1, 1, 9, 42, 134, 72, 134, 247, 13, 1, 1, 10, 42, 134, 72, 134, 247, 13, 1, 1, 11, 42, 134, 72, 134, 247, 13, 1, 1, 12, 42, 134, 72, 134, 247, 13, 1, 1, 13, 42, 134, 72, 134, 247, 13, 1, 5, 3, 42, 134, 72, 134, 247, 13, 1, 5, 10, 42, 134, 72, 134, 247, 13, 1, 5, 11, 42, 134, 72, 134, 247, 13, 1, 5, 12, 42, 134, 72, 134, 247, 13, 1, 5, 13, 42, 134, 72, 134, 247, 13, 1, 7, 1, 42, 134, 72, 134, 247, 13, 1, 7, 2, 42, 134, 72, 134, 247, 13, 1, 7, 3, 42, 134, 72, 134, 247, 13, 1, 7, 6, 42, 134, 72, 134, 247, 13, 1, 9, 1, 42, 134, 72, 134, 247, 13, 1, 9, 3, 42, 134, 72, 134, 247, 13, 1, 9, 4, 42, 134, 72, 134, 247, 13, 1, 9, 5, 42, 134, 72, 134, 247, 13, 1, 9, 6, 42, 134, 72, 134, 247, 13, 1, 9, 7, 42, 134, 72, 134, 247, 13, 1, 9, 14, 42, 134, 72, 134, 247, 13, 1, 9, 15, 42, 134, 72, 134, 247, 13, 1, 9, 16, 1, 4, 42, 134, 72, 134, 247, 13, 1, 9, 16, 2, 12, 42, 134, 72, 134, 247, 13, 1, 9, 16, 2, 14, 42, 134, 72, 134, 247, 13, 1, 9, 16, 2, 47, 42, 134, 72, 134, 247, 13, 1, 9, 20, 42, 134, 72, 134, 247, 13, 1, 9, 21, 42, 134, 72, 134, 247, 13, 1, 9, 22, 1, 42, 134, 72, 134, 247, 13, 1, 12, 1, 3, 42, 134, 72, 134, 247, 13, 1, 12, 1, 5, 42, 134, 72, 134, 247, 13, 1, 12, 1, 6, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 1, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 2, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 3, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 5, 42, 134, 72, 134, 247, 13, 1, 12, 10, 1, 6, 42, 134, 72, 134, 247, 13, 2, 5, 42, 134, 72, 134, 247, 13, 2, 7, 42, 134, 72, 134, 247, 13, 2, 9, 42, 134, 72, 134, 247, 13, 2, 10, 42, 134, 72, 134, 247, 13, 2, 11, 42, 134, 72, 134, 247, 13, 3, 2, 42, 134, 72, 134, 247, 13, 3, 7, 43, 6, 1, 4, 1, 130, 55, 17, 1, 43, 6, 1, 4, 1, 130, 55, 17, 3, 20, 43, 6, 1, 4, 1, 130, 55, 20, 2, 3, 43, 6, 1, 4, 1, 130, 55, 88, 2, 1, 43, 6, 1, 4, 1, 130, 55, 88, 2, 2, 43, 6, 1, 5, 5, 7, 3, 1, 43, 6, 1, 5, 5, 7, 3, 2, 43, 6, 1, 5, 5, 7, 3, 3, 43, 6, 1, 5, 5, 7, 3, 4, 43, 6, 1, 5, 5, 7, 3, 8, 43, 6, 1, 5, 5, 7, 3, 9, 43, 6, 1, 5, 5, 7, 6, 2, 43, 6, 1, 5, 5, 7, 48, 1, 43, 6, 1, 5, 5, 7, 48, 1, 2, 43, 6, 1, 5, 5, 7, 48, 2, 43, 14, 3, 2, 26, 43, 14, 3, 2, 7, 43, 129, 4, 0, 34, 43, 129, 4, 0, 35, 85, 4, 3, 85, 4, 5, 85, 4, 6, 85, 4, 7, 85, 4, 8, 85, 4, 10, 85, 4, 11, 85, 4, 97, 85, 29, 14, 85, 29, 15, 85, 29, 17, 85, 29, 19, 85, 29, 20, 85, 29, 35, 96, 134, 72, 1, 101, 3, 4, 1, 2, 96, 134, 72, 1, 101, 3, 4, 1, 22, 96, 134, 72, 1, 101, 3, 4, 1, 42, 96, 134, 72, 1, 101, 3, 4, 2, 1, 96, 134, 72, 1, 101, 3, 4, 2, 2, 96, 134, 72, 1, 101, 3, 4, 2, 3, 103, 129, 12, 1, 2, 1, 103, 129, 12, 1, 2, 2 ]);
                return (() =>
                {
                    if (value === "1.2.840.10040.4.1")
                    {
                        return data.Slice$1(0, 7);
                    }
                    if (value === "1.2.840.10040.4.3")
                    {
                        return data.Slice$1(7, 7);
                    }
                    if (value === "1.2.840.10045.2.1")
                    {
                        return data.Slice$1(14, 7);
                    }
                    if (value === "1.2.840.10045.1.1")
                    {
                        return data.Slice$1(21, 7);
                    }
                    if (value === "1.2.840.10045.1.2")
                    {
                        return data.Slice$1(28, 7);
                    }
                    if (value === "1.2.840.10045.3.1.7")
                    {
                        return data.Slice$1(35, 8);
                    }
                    if (value === "1.2.840.10045.4.1")
                    {
                        return data.Slice$1(43, 7);
                    }
                    if (value === "1.2.840.10045.4.3.2")
                    {
                        return data.Slice$1(50, 8);
                    }
                    if (value === "1.2.840.10045.4.3.3")
                    {
                        return data.Slice$1(58, 8);
                    }
                    if (value === "1.2.840.10045.4.3.4")
                    {
                        return data.Slice$1(66, 8);
                    }
                    if (value === "1.2.840.113549.1.1.1")
                    {
                        return data.Slice$1(74, 9);
                    }
                    if (value === "1.2.840.113549.1.1.5")
                    {
                        return data.Slice$1(83, 9);
                    }
                    if (value === "1.2.840.113549.1.1.7")
                    {
                        return data.Slice$1(92, 9);
                    }
                    if (value === "1.2.840.113549.1.1.8")
                    {
                        return data.Slice$1(101, 9);
                    }
                    if (value === "1.2.840.113549.1.1.9")
                    {
                        return data.Slice$1(110, 9);
                    }
                    if (value === "1.2.840.113549.1.1.10")
                    {
                        return data.Slice$1(119, 9);
                    }
                    if (value === "1.2.840.113549.1.1.11")
                    {
                        return data.Slice$1(128, 9);
                    }
                    if (value === "1.2.840.113549.1.1.12")
                    {
                        return data.Slice$1(137, 9);
                    }
                    if (value === "1.2.840.113549.1.1.13")
                    {
                        return data.Slice$1(146, 9);
                    }
                    if (value === "1.2.840.113549.1.5.3")
                    {
                        return data.Slice$1(155, 9);
                    }
                    if (value === "1.2.840.113549.1.5.10")
                    {
                        return data.Slice$1(164, 9);
                    }
                    if (value === "1.2.840.113549.1.5.11")
                    {
                        return data.Slice$1(173, 9);
                    }
                    if (value === "1.2.840.113549.1.5.12")
                    {
                        return data.Slice$1(182, 9);
                    }
                    if (value === "1.2.840.113549.1.5.13")
                    {
                        return data.Slice$1(191, 9);
                    }
                    if (value === "1.2.840.113549.1.7.1")
                    {
                        return data.Slice$1(200, 9);
                    }
                    if (value === "1.2.840.113549.1.7.2")
                    {
                        return data.Slice$1(209, 9);
                    }
                    if (value === "1.2.840.113549.1.7.3")
                    {
                        return data.Slice$1(218, 9);
                    }
                    if (value === "1.2.840.113549.1.7.6")
                    {
                        return data.Slice$1(227, 9);
                    }
                    if (value === "1.2.840.113549.1.9.1")
                    {
                        return data.Slice$1(236, 9);
                    }
                    if (value === "1.2.840.113549.1.9.3")
                    {
                        return data.Slice$1(245, 9);
                    }
                    if (value === "1.2.840.113549.1.9.4")
                    {
                        return data.Slice$1(254, 9);
                    }
                    if (value === "1.2.840.113549.1.9.5")
                    {
                        return data.Slice$1(263, 9);
                    }
                    if (value === "1.2.840.113549.1.9.6")
                    {
                        return data.Slice$1(272, 9);
                    }
                    if (value === "1.2.840.113549.1.9.7")
                    {
                        return data.Slice$1(281, 9);
                    }
                    if (value === "1.2.840.113549.1.9.14")
                    {
                        return data.Slice$1(290, 9);
                    }
                    if (value === "1.2.840.113549.1.9.15")
                    {
                        return data.Slice$1(299, 9);
                    }
                    if (value === "1.2.840.113549.1.9.16.1.4")
                    {
                        return data.Slice$1(308, 11);
                    }
                    if (value === "1.2.840.113549.1.9.16.2.12")
                    {
                        return data.Slice$1(319, 11);
                    }
                    if (value === "1.2.840.113549.1.9.16.2.14")
                    {
                        return data.Slice$1(330, 11);
                    }
                    if (value === "1.2.840.113549.1.9.16.2.47")
                    {
                        return data.Slice$1(341, 11);
                    }
                    if (value === "1.2.840.113549.1.9.20")
                    {
                        return data.Slice$1(352, 9);
                    }
                    if (value === "1.2.840.113549.1.9.21")
                    {
                        return data.Slice$1(361, 9);
                    }
                    if (value === "1.2.840.113549.1.9.22.1")
                    {
                        return data.Slice$1(370, 10);
                    }
                    if (value === "1.2.840.113549.1.12.1.3")
                    {
                        return data.Slice$1(380, 10);
                    }
                    if (value === "1.2.840.113549.1.12.1.5")
                    {
                        return data.Slice$1(390, 10);
                    }
                    if (value === "1.2.840.113549.1.12.1.6")
                    {
                        return data.Slice$1(400, 10);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.1")
                    {
                        return data.Slice$1(410, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.2")
                    {
                        return data.Slice$1(421, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.3")
                    {
                        return data.Slice$1(432, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.5")
                    {
                        return data.Slice$1(443, 11);
                    }
                    if (value === "1.2.840.113549.1.12.10.1.6")
                    {
                        return data.Slice$1(454, 11);
                    }
                    if (value === "1.2.840.113549.2.5")
                    {
                        return data.Slice$1(465, 8);
                    }
                    if (value === "1.2.840.113549.2.7")
                    {
                        return data.Slice$1(473, 8);
                    }
                    if (value === "1.2.840.113549.2.9")
                    {
                        return data.Slice$1(481, 8);
                    }
                    if (value === "1.2.840.113549.2.10")
                    {
                        return data.Slice$1(489, 8);
                    }
                    if (value === "1.2.840.113549.2.11")
                    {
                        return data.Slice$1(497, 8);
                    }
                    if (value === "1.2.840.113549.3.2")
                    {
                        return data.Slice$1(505, 8);
                    }
                    if (value === "1.2.840.113549.3.7")
                    {
                        return data.Slice$1(513, 8);
                    }
                    if (value === "1.3.6.1.4.1.311.17.1")
                    {
                        return data.Slice$1(521, 9);
                    }
                    if (value === "1.3.6.1.4.1.311.17.3.20")
                    {
                        return data.Slice$1(530, 10);
                    }
                    if (value === "1.3.6.1.4.1.311.20.2.3")
                    {
                        return data.Slice$1(540, 10);
                    }
                    if (value === "1.3.6.1.4.1.311.88.2.1")
                    {
                        return data.Slice$1(550, 10);
                    }
                    if (value === "1.3.6.1.4.1.311.88.2.2")
                    {
                        return data.Slice$1(560, 10);
                    }
                    if (value === "1.3.6.1.5.5.7.3.1")
                    {
                        return data.Slice$1(570, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.2")
                    {
                        return data.Slice$1(578, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.3")
                    {
                        return data.Slice$1(586, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.4")
                    {
                        return data.Slice$1(594, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.8")
                    {
                        return data.Slice$1(602, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.3.9")
                    {
                        return data.Slice$1(610, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.6.2")
                    {
                        return data.Slice$1(618, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.48.1")
                    {
                        return data.Slice$1(626, 8);
                    }
                    if (value === "1.3.6.1.5.5.7.48.1.2")
                    {
                        return data.Slice$1(634, 9);
                    }
                    if (value === "1.3.6.1.5.5.7.48.2")
                    {
                        return data.Slice$1(643, 8);
                    }
                    if (value === "1.3.14.3.2.26")
                    {
                        return data.Slice$1(651, 5);
                    }
                    if (value === "1.3.14.3.2.7")
                    {
                        return data.Slice$1(656, 5);
                    }
                    if (value === "1.3.132.0.34")
                    {
                        return data.Slice$1(661, 5);
                    }
                    if (value === "1.3.132.0.35")
                    {
                        return data.Slice$1(666, 5);
                    }
                    if (value === "2.5.4.3")
                    {
                        return data.Slice$1(671, 3);
                    }
                    if (value === "2.5.4.5")
                    {
                        return data.Slice$1(674, 3);
                    }
                    if (value === "2.5.4.6")
                    {
                        return data.Slice$1(677, 3);
                    }
                    if (value === "2.5.4.7")
                    {
                        return data.Slice$1(680, 3);
                    }
                    if (value === "2.5.4.8")
                    {
                        return data.Slice$1(683, 3);
                    }
                    if (value === "2.5.4.10")
                    {
                        return data.Slice$1(686, 3);
                    }
                    if (value === "2.5.4.11")
                    {
                        return data.Slice$1(689, 3);
                    }
                    if (value === "2.5.4.97")
                    {
                        return data.Slice$1(692, 3);
                    }
                    if (value === "2.5.29.14")
                    {
                        return data.Slice$1(695, 3);
                    }
                    if (value === "2.5.29.15")
                    {
                        return data.Slice$1(698, 3);
                    }
                    if (value === "2.5.29.17")
                    {
                        return data.Slice$1(701, 3);
                    }
                    if (value === "2.5.29.19")
                    {
                        return data.Slice$1(704, 3);
                    }
                    if (value === "2.5.29.20")
                    {
                        return data.Slice$1(707, 3);
                    }
                    if (value === "2.5.29.35")
                    {
                        return data.Slice$1(710, 3);
                    }
                    if (value === "2.16.840.1.101.3.4.1.2")
                    {
                        return data.Slice$1(713, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.1.22")
                    {
                        return data.Slice$1(722, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.1.42")
                    {
                        return data.Slice$1(731, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.2.1")
                    {
                        return data.Slice$1(740, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.2.2")
                    {
                        return data.Slice$1(749, 9);
                    }
                    if (value === "2.16.840.1.101.3.4.2.3")
                    {
                        return data.Slice$1(758, 9);
                    }
                    if (value === "2.23.140.1.2.1")
                    {
                        return data.Slice$1(767, 6);
                    }
                    if (value === "2.23.140.1.2.2")
                    {
                        return data.Slice$1(773, 6);
                    }
                    return $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).Empty;
                })();
            }
            static $h = 1757336;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"contents","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"GetValue","d":1757336,"h":4296724632,"f":40},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"GetContents","d":1757336,"h":8591691928,"f":40}],"h":1757336}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Formats.Asn1.WellKnownOids`; }
        });
        
        $asm.$str("$sfa.System.Formats.Asn1.AsnReaderOptions", ($self) => class AsnReaderOptions extends $.$spc.System.ValueType
        {
            /*int*/ static DefaultTwoDigitMax = 2049;
            /*ushort*/  get _twoDigitYearMax() { return this.$getField(0, 2); }
            /*ushort*/  set _twoDigitYearMax(value) { this.$setField(0, 2, value); }
            /*int */ get UtcTimeTwoDigitYearMax()
            {
                if (this._twoDigitYearMax === 0)
                {
                    return 2049/*DefaultTwoDigitMax*/;
                }
                return this._twoDigitYearMax;
            }
            /*int */ set UtcTimeTwoDigitYearMax(value)
            {
                if (value < 1 || value > 9999)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("value");
                }
                this._twoDigitYearMax = $.$cast(value, $.$spc.System.UInt16);
            }
            /*bool*/ SkipSetSortOrderVerification = false;
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._twoDigitYearMax = this._twoDigitYearMax;
                copy.SkipSetSortOrderVerification = this.SkipSetSortOrderVerification;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._twoDigitYearMax = 0;
                this.SkipSetSortOrderVerification = false;
            }
            static $h = 708760;
            static $z = 3;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180577944,"f":1},"s":{"r":0,"d":0,"h":21475545240,"f":1},"n":"UtcTimeTwoDigitYearMax","d":708760,"h":12885610648,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360447128,"f":1},"s":{"r":0,"d":0,"h":38655414424,"f":1},"n":"SkipSetSortOrderVerification","d":708760,"h":30065479832,"f":1}],"l":[{"t":655361,"n":"DefaultTwoDigitMax","d":708760,"h":4295676056,"f":34},{"t":589825,"n":"_twoDigitYearMax","d":708760,"h":8590643352,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":708760,"h":42950381720,"f":1}],"h":708760}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Formats.Asn1.AsnReaderOptions`; }
        });
        
        $asm.$str("$sfa.System.Formats.Asn1.Asn1Tag", ($self) => class Asn1Tag extends $.$spc.System.ValueType
        {
            /*byte*/ static ClassMask = 192;
            /*byte*/ static ConstructedMask = 32;
            /*byte*/ static ControlMask = 224;
            /*byte*/ static TagNumberMask = 31;
            /*byte*/  get _controlFlags() { return this.$getField(0, $.$spc.System.Byte); }
            /*byte*/  set _controlFlags(value) { this.$setField(0, $.$spc.System.Byte, value); }
            /*TagClass */ get TagClass()
            {
                return $.$cast((this._controlFlags & 192/*ClassMask*/), $.$sfa.System.Formats.Asn1.TagClass);
            }
            /*bool */ get IsConstructed()
            {
                return (this._controlFlags & 32/*ConstructedMask*/) !== 0;
            }
            /*int*/ TagValue = 0;
            $ctor$2(/*byte*/ controlFlags, /*int*/ tagValue)
            {
                super.$ctor$1();
                {
                    this._controlFlags = $.$cast((controlFlags & 224/*ControlMask*/), $.$spc.System.Byte);
                    this.TagValue = tagValue;
                }
                return this;
            }
            $ctor$3(/*UniversalTagNumber*/ universalTagNumber, /*bool*/ isConstructed)
            {
                this.$ctor$2(isConstructed ? 32/*ConstructedMask*/ : 0, universalTagNumber);
                {
                    /*UniversalTagNumber*/ let ReservedIndex = $.$cast(15, $.$sfa.System.Formats.Asn1.UniversalTagNumber);
                    if (universalTagNumber < 0/*UniversalTagNumber.EndOfContents*/ || universalTagNumber > 36/*UniversalTagNumber.RelativeObjectIdentifierIRI*/ || universalTagNumber === ReservedIndex)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("universalTagNumber");
                    }
                }
                return this;
            }
            $ctor$4(/*TagClass*/ tagClass, /*int*/ tagValue, /*bool*/ isConstructed)
            {
                this.$ctor$2($.$cast(($.$cast(tagClass, $.$spc.System.Byte) | (isConstructed ? 32/*ConstructedMask*/ : 0)), $.$spc.System.Byte), tagValue);
                {
                    switch(tagClass)
                    {
                        case 0/*TagClass.Universal*/:
                        case 128/*TagClass.ContextSpecific*/:
                        case 64/*TagClass.Application*/:
                        case 192/*TagClass.Private*/:
                        break;
                        default:
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("tagClass");
                    }
                    if (tagValue < 0)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("tagValue");
                    }
                }
                return this;
            }
            /*Asn1Tag */ AsConstructed()
            {
                return new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2($.$cast((this._controlFlags | 32/*ConstructedMask*/), $.$spc.System.Byte), this.TagValue);
            }
            /*Asn1Tag */ AsPrimitive()
            {
                return new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2($.$cast((this._controlFlags & ~32/*ConstructedMask*/), $.$spc.System.Byte), this.TagValue);
            }
            static /*bool */ TryDecode(/*ReadOnlySpan<byte>*/ source, /*out Asn1Tag*/ tag, /*out int*/ bytesConsumed)
            {
                tag.$v = $.$default($.$sfa.System.Formats.Asn1.Asn1Tag);
                bytesConsumed.$v = 0;
                if (source.IsEmpty)
                {
                    return false;
                }
                /*byte*/ let first = source.get_Item(bytesConsumed.$v).$v;
                bytesConsumed.$v++;
                /*uint*/ let tagValue = ((first & 31/*TagNumberMask*/) >>> 0);
                if (tagValue === 31/*TagNumberMask*/)
                {
                    /*byte*/ let ContinuationFlag = 128;
                    /*byte*/ let ValueMask = ((ContinuationFlag - 1) | 0);
                    tagValue = 0;
                    /*byte*/ let current;
                    do
                    {
                        if (source.Length <= bytesConsumed.$v)
                        {
                            bytesConsumed.$v = 0;
                            return false;
                        }
                        current = source.get_Item(bytesConsumed.$v).$v;
                        /*byte*/ let currentValue = $.$cast((current & ValueMask), $.$spc.System.Byte);
                        bytesConsumed.$v++;
                        /*int*/ let TooBigToShift = 33554432;
                        if (tagValue >= TooBigToShift)
                        {
                            bytesConsumed.$v = 0;
                            return false;
                        }
                        tagValue <<= 7;
                        tagValue |= currentValue;
                        if (tagValue === 0)
                        {
                            bytesConsumed.$v = 0;
                            return false;
                        }
                    }
                    while((current & ContinuationFlag) === ContinuationFlag);
                    if (tagValue <= 30)
                    {
                        bytesConsumed.$v = 0;
                        return false;
                    }
                    if (tagValue > 2147483647/*int.MaxValue*/)
                    {
                        bytesConsumed.$v = 0;
                        return false;
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(bytesConsumed.$v > 0, "bytesConsumed > 0");
                tag.$v = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(first, (tagValue | 0));
                return true;
            }
            static /*Asn1Tag */ Decode(/*ReadOnlySpan<byte>*/ source, /*out int*/ bytesConsumed)
            {
                /*Asn1Tag*/ let tag;
                if ($.$sfa.System.Formats.Asn1.Asn1Tag.TryDecode(source, $.$ref(() => tag, ($v) => tag = $v, $.$sfa.System.Formats.Asn1.Asn1Tag), bytesConsumed))
                {
                    return tag;
                }
                throw new $.$sfa.System.Formats.Asn1.AsnContentException().$ctor$6($.$sfa.System.SR.ContentException_InvalidTag);
            }
            /*int */ CalculateEncodedSize()
            {
                /*int*/ let SevenBits = 127;
                /*int*/ let FourteenBits = 16383;
                /*int*/ let TwentyOneBits = 2097151;
                /*int*/ let TwentyEightBits = 268435455;
                if (this.TagValue < 31/*TagNumberMask*/)
                {
                    return 1;
                }
                if (this.TagValue <= SevenBits)
                {
                    return 2;
                }
                if (this.TagValue <= FourteenBits)
                {
                    return 3;
                }
                if (this.TagValue <= TwentyOneBits)
                {
                    return 4;
                }
                if (this.TagValue <= TwentyEightBits)
                {
                    return 5;
                }
                return 6;
            }
            /*bool */ TryEncode(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                /*int*/ let spaceRequired = this.CalculateEncodedSize();
                if (destination.Length < spaceRequired)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                if (spaceRequired === 1)
                {
                    /*byte*/ let value = $.$cast((this._controlFlags | this.TagValue), $.$spc.System.Byte);
                    destination.get_Item(0).$v = value;
                    bytesWritten.$v = 1;
                    return true;
                }
                /*byte*/ let firstByte = $.$cast((this._controlFlags | 31/*TagNumberMask*/), $.$spc.System.Byte);
                destination.get_Item(0).$v = firstByte;
                /*int*/ let remaining = this.TagValue;
                /*int*/ let idx = ((spaceRequired - 1) | 0);
                while(remaining > 0)
                {
                    /*int*/ let segment = remaining & 127;
                    if (remaining !== this.TagValue)
                    {
                        segment |= 128;
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(segment <= 255/*byte.MaxValue*/, "segment <= byte.MaxValue");
                    destination.get_Item(idx).$v = $.$cast(segment, $.$spc.System.Byte);
                    remaining >>= 7;
                    idx--;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(idx === 0, "idx == 0");
                bytesWritten.$v = spaceRequired;
                return true;
            }
            /*int */ Encode(/*Span<byte>*/ destination)
            {
                /*int*/ let bytesWritten;
                if (this.TryEncode(destination, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32)))
                {
                    return bytesWritten;
                }
                throw new $.$spc.System.ArgumentException().$ctor$13($.$sfa.System.SR.Argument_DestinationTooShort, "destination");
            }
            /*bool */ Equals$2(/*Asn1Tag*/ other)
            {
                return this._controlFlags === other._controlFlags && this.TagValue === other.TagValue;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let tag;
                return $.$is(obj, $.$sfa.System.Formats.Asn1.Asn1Tag, { set $v(v){ tag = v; } }) && this.Equals$2(tag);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sfa.System.Formats.Asn1.Asn1Tag.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return ((this._controlFlags << 24) >>> 0) ^ this.TagValue;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sfa.System.Formats.Asn1.Asn1Tag.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*Asn1Tag*/ left, /*Asn1Tag*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*Asn1Tag*/ left, /*Asn1Tag*/ right)
            {
                return !left.Equals$2(right);
            }
            /*bool */ HasSameClassAndValue(/*Asn1Tag*/ other)
            {
                return this.TagValue === other.TagValue && this.TagClass === other.TagClass;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let ConstructedPrefix = "Constructed ";
                /*string*/ let classAndValue;
                if (this.TagClass === 0/*TagClass.Universal*/)
                {
                    classAndValue = $.$spc.System.Enum.ToStringT($.$sfa.System.Formats.Asn1.UniversalTagNumber, $.$spc.System.UInt32, ($.$cast(this.TagValue, $.$sfa.System.Formats.Asn1.UniversalTagNumber)));
                }
                else 
                {
                    classAndValue = `${this.TagClass}-${this.TagValue}`;
                }
                if (this.IsConstructed)
                {
                    return ConstructedPrefix + classAndValue;
                }
                return classAndValue;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sfa.System.Formats.Asn1.Asn1Tag.ToString.apply(this, arguments); }
            /*Asn1Tag*/ static EndOfContents;
            /*Asn1Tag*/ static Boolean;
            /*Asn1Tag*/ static Integer;
            /*Asn1Tag*/ static PrimitiveBitString;
            /*Asn1Tag*/ static ConstructedBitString;
            /*Asn1Tag*/ static PrimitiveOctetString;
            /*Asn1Tag*/ static ConstructedOctetString;
            /*Asn1Tag*/ static Null;
            /*Asn1Tag*/ static ObjectIdentifier;
            /*Asn1Tag*/ static Enumerated;
            /*Asn1Tag*/ static Sequence;
            /*Asn1Tag*/ static SetOf;
            /*Asn1Tag*/ static UtcTime;
            /*Asn1Tag*/ static GeneralizedTime;
            //Generated interface implemetation for System.IEquatable<System.Formats.Asn1.Asn1Tag>.Equals(System.Formats.Asn1.Asn1Tag)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$5()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._controlFlags = this._controlFlags;
                copy.TagValue = this.TagValue;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._controlFlags = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.EndOfContents = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(0, 0/*UniversalTagNumber.EndOfContents*/);
                }
                {
                    this.Boolean = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(0, 1/*UniversalTagNumber.Boolean*/);
                }
                {
                    this.Integer = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(0, 2/*UniversalTagNumber.Integer*/);
                }
                {
                    this.PrimitiveBitString = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(0, 3/*UniversalTagNumber.BitString*/);
                }
                {
                    this.ConstructedBitString = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(32/*ConstructedMask*/, 3/*UniversalTagNumber.BitString*/);
                }
                {
                    this.PrimitiveOctetString = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(0, 4/*UniversalTagNumber.OctetString*/);
                }
                {
                    this.ConstructedOctetString = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(32/*ConstructedMask*/, 4/*UniversalTagNumber.OctetString*/);
                }
                {
                    this.Null = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(0, 5/*UniversalTagNumber.Null*/);
                }
                {
                    this.ObjectIdentifier = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(0, 6/*UniversalTagNumber.ObjectIdentifier*/);
                }
                {
                    this.Enumerated = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(0, 10/*UniversalTagNumber.Enumerated*/);
                }
                {
                    this.Sequence = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(32/*ConstructedMask*/, 16/*UniversalTagNumber.Sequence*/);
                }
                {
                    this.SetOf = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(32/*ConstructedMask*/, 17/*UniversalTagNumber.SetOf*/);
                }
                {
                    this.UtcTime = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(0, 23/*UniversalTagNumber.UtcTime*/);
                }
                {
                    this.GeneralizedTime = new $.$sfa.System.Formats.Asn1.Asn1Tag().$ctor$2(0, 24/*UniversalTagNumber.GeneralizedTime*/);
                }
            }
            static $h = 118936;
            static $z = 5;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1560728,"g":{"r":0,"d":0,"h":30064890008,"f":1},"n":"TagClass","d":118936,"h":25769922712,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38654824600,"f":1},"n":"IsConstructed","d":118936,"h":34359857304,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51539726488,"f":1},"n":"TagValue","d":118936,"h":47244759192,"f":1}],"m":[{"r":118936,"n":"AsConstructed","d":118936,"h":68719595672,"f":1},{"r":118936,"n":"AsPrimitive","d":118936,"h":73014562968,"f":1},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"tag","p":118936,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"TryDecode","d":118936,"h":77309530264,"f":33},{"r":118936,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2}],"n":"Decode","d":118936,"h":81604497560,"f":33},{"r":655361,"n":"CalculateEncodedSize","d":118936,"h":85899464856,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryEncode","d":118936,"h":90194432152,"f":1},{"r":655361,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Encode","d":118936,"h":94489399448,"f":1},{"r":262145,"p":[{"n":"other","p":118936}],"n":"Equals","o":"@$2","d":118936,"h":98784366744,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":118936,"h":103079334040,"f":32769},{"r":655361,"n":"GetHashCode","d":118936,"h":107374301336,"f":32769},{"r":262145,"p":[{"n":"other","p":118936}],"n":"HasSameClassAndValue","d":118936,"h":120259203224,"f":1},{"r":1310721,"n":"ToString","d":118936,"h":124554170520,"f":32769}],"l":[{"t":393217,"n":"ClassMask","d":118936,"h":4295086232,"f":34},{"t":393217,"n":"ConstructedMask","d":118936,"h":8590053528,"f":34},{"t":393217,"n":"ControlMask","d":118936,"h":12885020824,"f":34},{"t":393217,"n":"TagNumberMask","d":118936,"h":17179988120,"f":34},{"t":393217,"n":"_controlFlags","d":118936,"h":21474955416,"f":2},{"t":118936,"n":"EndOfContents","d":118936,"h":128849137816,"f":40},{"t":118936,"n":"Boolean","d":118936,"h":133144105112,"f":33},{"t":118936,"n":"Integer","d":118936,"h":137439072408,"f":33},{"t":118936,"n":"PrimitiveBitString","d":118936,"h":141734039704,"f":33},{"t":118936,"n":"ConstructedBitString","d":118936,"h":146029007000,"f":33},{"t":118936,"n":"PrimitiveOctetString","d":118936,"h":150323974296,"f":33},{"t":118936,"n":"ConstructedOctetString","d":118936,"h":154618941592,"f":33},{"t":118936,"n":"Null","d":118936,"h":158913908888,"f":33},{"t":118936,"n":"ObjectIdentifier","d":118936,"h":163208876184,"f":33},{"t":118936,"n":"Enumerated","d":118936,"h":167503843480,"f":33},{"t":118936,"n":"Sequence","d":118936,"h":171798810776,"f":33},{"t":118936,"n":"SetOf","d":118936,"h":176093778072,"f":33},{"t":118936,"n":"UtcTime","d":118936,"h":180388745368,"f":33},{"t":118936,"n":"GeneralizedTime","d":118936,"h":184683712664,"f":33}],"c":[{"p":[{"n":"controlFlags","p":393217},{"n":"tagValue","p":655361}],"n":".ctor","o":"$ctor$2","d":118936,"h":55834693784,"f":2},{"p":[{"n":"universalTagNumber","p":1626264},{"n":"isConstructed","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$3","d":118936,"h":60129661080,"f":1},{"p":[{"n":"tagClass","p":1560728},{"n":"tagValue","p":655361},{"n":"isConstructed","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$4","d":118936,"h":64424628376,"f":1},{"n":".ctor","o":"$ctor$5","d":118936,"h":188978679960,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sfa.System.Formats.Asn1.Asn1Tag).$h],"h":118936}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sfa.System.Formats.Asn1.Asn1Tag) ]; }
            static get $fullName() { return `System.Formats.Asn1.Asn1Tag`; }
        });
        
        $asm.$str("$sfa.System.Security.Cryptography.CryptoPoolLease", ($self) => class CryptoPoolLease extends $.$spc.System.ValueType
        {
            /*byte[]?*/  get _rented() { return this.$getField(0, 4); }
            /*byte[]?*/  set _rented(value) { this.$setField(0, 4, value); }
            /*bool*/  get _skipClear() { return this.$getField(4, 1); }
            /*bool*/  set _skipClear(value) { this.$setField(4, 1, value); }
            /*Span<byte>*/ Span;
            /*bool */ get IsRented()
            {
                return !(this._rented === null);
            }
            /*void */ Dispose()
            {
                this.Return();
            }
            /*void */ Return()
            {
                this.Return$1(this._skipClear ? 0 : this.Span.Length);
            }
            /*void */ Return$1(/*int*/ clearSize)
            {
                if (!(this._rented === null))
                {
                    $.$sfa.System.Security.Cryptography.CryptoPool.Return$1(this._rented, clearSize);
                    this._rented = null;
                }
                else if (!this._skipClear && clearSize > 0)
                {
                    /*Span<byte>*/ let toClear = this.Span.Slice$1(0, clearSize);
                    toClear.Clear();
                }
                this.Span = new ($.$spc.System.Span$$($.$spc.System.Byte))();
            }
            static /*CryptoPoolLease */ Rent(/*int*/ length, /*bool*/ skipClear)
            {
                /*byte[]*/ let rented = $.$sfa.System.Security.Cryptography.CryptoPool.Rent(length);
                return (() =>
                {
                    //new $.$sfa.System.Security.Cryptography.CryptoPoolLease()
                    const $t1 = $.$sfa.System.Security.Cryptography.CryptoPoolLease;
                    const $i1 = new $t1();
                    $i1._rented = rented;
                    $i1._skipClear = skipClear;
                    $i1.Span = new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$3(rented, 0, length);
                    return $i1;
                })();
            }
            static /*CryptoPoolLease */ RentConditionally(/*int*/ length, /*Span<byte>*/ currentBuffer, /*bool*/ skipClear, /*bool*/ skipClearIfNotRented)
            {
                return $.$sfa.System.Security.Cryptography.CryptoPoolLease.RentConditionally$1(length, currentBuffer, $.$discardRef(), skipClear, skipClearIfNotRented);
            }
            static /*CryptoPoolLease */ RentConditionally$1(/*int*/ length, /*Span<byte>*/ currentBuffer, /*out bool*/ rented, /*bool*/ skipClear, /*bool*/ skipClearIfNotRented)
            {
                if (currentBuffer.Length >= length)
                {
                    rented.$v = false;
                    return (() =>
                    {
                        //new $.$sfa.System.Security.Cryptography.CryptoPoolLease()
                        const $t1 = $.$sfa.System.Security.Cryptography.CryptoPoolLease;
                        const $i1 = new $t1();
                        $i1._rented = null;
                        $i1._skipClear = skipClearIfNotRented || skipClear;
                        $i1.Span = currentBuffer.Slice$1(0, length);
                        return $i1;
                    })();
                }
                rented.$v = true;
                return $.$sfa.System.Security.Cryptography.CryptoPoolLease.Rent(length, skipClear);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._rented = this._rented;
                copy._skipClear = this._skipClear;
                copy.Span = this.Span.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._rented = null;
                this._skipClear = false;
                this.Span = $.$default($.$spc.System.Span$$($.$spc.System.Byte));
            }
            static $h = 1953944;
            static $z = 10;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.Span$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":21476790424,"f":8},"s":{"r":0,"d":0,"h":25771757720,"f":2},"n":"Span","d":1953944,"h":17181823128,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":34361692312,"f":8},"n":"IsRented","d":1953944,"h":30066725016,"f":8}],"m":[{"r":65537,"n":"Dispose","d":1953944,"h":38656659608,"f":1},{"r":65537,"n":"Return","d":1953944,"h":42951626904,"f":8},{"r":65537,"p":[{"n":"clearSize","p":655361}],"n":"Return","o":"@$1","d":1953944,"h":47246594200,"f":2},{"r":1953944,"p":[{"n":"length","p":655361},{"n":"skipClear","p":262145,"f":65,"v":false}],"n":"Rent","d":1953944,"h":51541561496,"f":40},{"r":1953944,"p":[{"n":"length","p":655361},{"n":"currentBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"skipClear","p":262145,"f":65,"v":false},{"n":"skipClearIfNotRented","p":262145,"f":65,"v":false}],"n":"RentConditionally","d":1953944,"h":55836528792,"f":40},{"r":1953944,"p":[{"n":"length","p":655361},{"n":"currentBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"rented","p":262145,"f":2},{"n":"skipClear","p":262145,"f":65,"v":false},{"n":"skipClearIfNotRented","p":262145,"f":65,"v":false}],"n":"RentConditionally","o":"@$1","d":1953944,"h":60131496088,"f":40}],"l":[{"t":0,"n":"_rented","d":1953944,"h":4296921240,"f":2},{"t":262145,"n":"_skipClear","d":1953944,"h":8591888536,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1953944,"h":64426463384,"f":1}],"i":[57475073],"h":1953944}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Security.Cryptography.CryptoPoolLease`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.T61Encoding", ($self) => class T61Encoding extends $.$spc.System.Text.Encoding
        {
            /*UTF8Encoding*/ static s_utf8Encoding = null;
            /*Encoding*/ static s_latin1Encoding = null;
            /*int */ GetByteCount$2(/*char[]*/ chars, /*int*/ index, /*int*/ count)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetByteCount$2(chars, index, count);
            }
            /*int */ GetByteCount$4(/*char**/ chars, /*int*/ count)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetByteCount$4(chars, count);
            }
            /*int */ GetByteCount$1(/*string*/ s)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetByteCount$1(s);
            }
            /*int */ GetByteCount$5(/*ReadOnlySpan<char>*/ chars)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetByteCount$5(chars);
            }
            /*int */ GetBytes$2(/*char[]*/ chars, /*int*/ charIndex, /*int*/ charCount, /*byte[]*/ bytes, /*int*/ byteIndex)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetBytes$2(chars, charIndex, charCount, bytes, byteIndex);
            }
            /*int */ GetBytes$6(/*char**/ chars, /*int*/ charCount, /*byte**/ bytes, /*int*/ byteCount)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetBytes$6(chars, charCount, bytes, byteCount);
            }
            /*int */ GetCharCount$1(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetCharCount$1(bytes, index, count);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetCharCount$1(bytes, index, count);
                }
            }
            /*int */ GetCharCount$2(/*byte**/ bytes, /*int*/ count)
            {
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetCharCount$2(bytes, count);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetCharCount$2(bytes, count);
                }
            }
            /*int */ GetCharCount$3(/*ReadOnlySpan<byte>*/ bytes)
            {
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetCharCount$3(bytes);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetCharCount$3(bytes);
                }
            }
            /*int */ GetChars$2(/*byte[]*/ bytes, /*int*/ byteIndex, /*int*/ byteCount, /*char[]*/ chars, /*int*/ charIndex)
            {
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetChars$2(bytes, byteIndex, byteCount, chars, charIndex);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetChars$2(bytes, byteIndex, byteCount, chars, charIndex);
                }
            }
            /*int */ GetChars$3(/*byte**/ bytes, /*int*/ byteCount, /*char**/ chars, /*int*/ charCount)
            {
                try
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetChars$3(bytes, byteCount, chars, charCount);
                }
                catch($e)
                {
                    return $.$sfa.System.Formats.Asn1.T61Encoding.s_latin1Encoding.GetChars$3(bytes, byteCount, chars, charCount);
                }
            }
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                return $.$sfa.System.Formats.Asn1.T61Encoding.s_utf8Encoding.GetMaxByteCount(charCount);
            }
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                return byteCount;
            }
            //default reference type constructor overload
            $ctor$4()
            {
                super.$ctor$1();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_utf8Encoding = new $.$spc.System.Text.UTF8Encoding().$ctor$6(false, true);
                }
                {
                    this.s_latin1Encoding = $.$spc.System.Text.Encoding.GetEncoding$2("iso-8859-1");
                }
            }
            static $h = 1495192;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":121831425,"m":[{"r":655361,"p":[{"n":"chars","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetByteCount","o":"@$2","d":1495192,"h":12886397080,"f":32769},{"r":655361,"p":[{"n":"chars","p":0},{"n":"count","p":655361}],"n":"GetByteCount","o":"@$4","d":1495192,"h":17181364376,"f":32769},{"r":655361,"p":[{"n":"s","p":1310721}],"n":"GetByteCount","o":"@$1","d":1495192,"h":21476331672,"f":32769},{"r":655361,"p":[{"n":"chars","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"GetByteCount","o":"@$5","d":1495192,"h":25771298968,"f":32769},{"r":655361,"p":[{"n":"chars","p":0},{"n":"charIndex","p":655361},{"n":"charCount","p":655361},{"n":"bytes","p":0},{"n":"byteIndex","p":655361}],"n":"GetBytes","o":"@$2","d":1495192,"h":30066266264,"f":32769},{"r":655361,"p":[{"n":"chars","p":0},{"n":"charCount","p":655361},{"n":"bytes","p":0},{"n":"byteCount","p":655361}],"n":"GetBytes","o":"@$6","d":1495192,"h":34361233560,"f":32769},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetCharCount","o":"@$1","d":1495192,"h":38656200856,"f":32769},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"count","p":655361}],"n":"GetCharCount","o":"@$2","d":1495192,"h":42951168152,"f":32769},{"r":655361,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"GetCharCount","o":"@$3","d":1495192,"h":47246135448,"f":32769},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"byteIndex","p":655361},{"n":"byteCount","p":655361},{"n":"chars","p":0},{"n":"charIndex","p":655361}],"n":"GetChars","o":"@$2","d":1495192,"h":51541102744,"f":32769},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"byteCount","p":655361},{"n":"chars","p":0},{"n":"charCount","p":655361}],"n":"GetChars","o":"@$3","d":1495192,"h":55836070040,"f":32769},{"r":655361,"p":[{"n":"charCount","p":655361}],"n":"GetMaxByteCount","d":1495192,"h":60131037336,"f":32769},{"r":655361,"p":[{"n":"byteCount","p":655361}],"n":"GetMaxCharCount","d":1495192,"h":64426004632,"f":32769}],"l":[{"t":124715009,"n":"s_utf8Encoding","d":1495192,"h":4296462488,"f":34},{"t":121831425,"n":"s_latin1Encoding","d":1495192,"h":8591429784,"f":34}],"c":[{"n":".ctor","o":"$ctor$4","d":1495192,"h":68720971928,"f":1}],"i":[57147393],"h":1495192}; }
            static get $b() { return $.$spc.System.Text.Encoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.T61Encoding`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.BMPEncoding", ($self) => class BMPEncoding extends $.$sfa.System.Formats.Asn1.SpanBasedEncoding
        {
            /*int */ GetBytes$9(/*ReadOnlySpan<char>*/ chars, /*Span<byte>*/ bytes, /*bool*/ write)
            {
                if (chars.IsEmpty)
                {
                    return 0;
                }
                /*int*/ let writeIdx = 0;
                for(/*int*/ let i = 0; i < chars.Length; i++)
                {
                    /*char*/ let c = chars.get_Item(i).$v;
                    if ($.$spc.System.Char.IsSurrogate(c))
                    {
                        this.EncoderFallback.CreateFallbackBuffer().Fallback(c, i);
                        $.$spc.System.Diagnostics.Debug.Fail("Fallback should have thrown");
                        throw new $.$spc.System.InvalidOperationException().$ctor$9();
                    }
                    /*ushort*/ let val16 = c;
                    if (write)
                    {
                        bytes.get_Item(((writeIdx + 1) | 0)).$v = $.$cast(val16, $.$spc.System.Byte);
                        bytes.get_Item(writeIdx).$v = $.$cast((val16 >>> 8), $.$spc.System.Byte);
                    }
                    writeIdx += 2;
                }
                return writeIdx;
            }
            /*int */ GetChars$6(/*ReadOnlySpan<byte>*/ bytes, /*Span<char>*/ chars, /*bool*/ write)
            {
                if (bytes.IsEmpty)
                {
                    return 0;
                }
                if (bytes.Length % 2 !== 0)
                {
                    this.DecoderFallback.CreateFallbackBuffer().Fallback(bytes.Slice(((bytes.Length - 1) | 0)).ToArray(), ((bytes.Length - 1) | 0));
                    $.$spc.System.Diagnostics.Debug.Fail("Fallback should have thrown");
                    throw new $.$spc.System.InvalidOperationException().$ctor$9();
                }
                /*int*/ let writeIdx = 0;
                for(/*int*/ let i = 0; i < bytes.Length; i += 2)
                {
                    /*char*/ let c = $.$cast($.$spc.System.Buffers.Binary.BinaryPrimitives.ReadInt16BigEndian(bytes.Slice(i)), $.$spc.System.Char);
                    if ($.$spc.System.Char.IsSurrogate(c))
                    {
                        this.DecoderFallback.CreateFallbackBuffer().Fallback(bytes.Slice$1(i, 2).ToArray(), i);
                        $.$spc.System.Diagnostics.Debug.Fail("Fallback should have thrown");
                        throw new $.$spc.System.InvalidOperationException().$ctor$9();
                    }
                    if (write)
                    {
                        chars.get_Item(writeIdx).$v = c;
                    }
                    writeIdx++;
                }
                return writeIdx;
            }
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                //checked
                {
                    return $.$checked(charCount * 2, 1);
                }
            }
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                return $.trunc(byteCount / 2);
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$4();
                return this;
            }
            static $h = 1036440;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1429656,"m":[{"r":655361,"p":[{"n":"chars","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"bytes","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"write","p":262145}],"n":"GetBytes","o":"@$9","d":1036440,"h":4296003736,"f":32772},{"r":655361,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"chars","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"write","p":262145}],"n":"GetChars","o":"@$6","d":1036440,"h":8590971032,"f":32772},{"r":655361,"p":[{"n":"charCount","p":655361}],"n":"GetMaxByteCount","d":1036440,"h":12885938328,"f":32769},{"r":655361,"p":[{"n":"byteCount","p":655361}],"n":"GetMaxCharCount","d":1036440,"h":17180905624,"f":32769}],"c":[{"n":".ctor","o":"$ctor$5","d":1036440,"h":21475872920,"f":1}],"i":[57147393],"h":1036440}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.SpanBasedEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.BMPEncoding`; }
        });
        
        $asm.$str("$sfa.System.Formats.Asn1.AsnEncodingRules", ($self) => class AsnEncodingRules extends $.$spc.System.Enum
        {
            static BER = 0;
            static CER = 1;
            static DER = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "BER": 0n,
                    "CER": 1n,
                    "DER": 2n
                };
            }
            static $h = 577688;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":577688,"n":"BER","d":577688,"h":4295544984,"f":33},{"t":577688,"n":"CER","d":577688,"h":8590512280,"f":33},{"t":577688,"n":"DER","d":577688,"h":12885479576,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":577688,"h":17180446872,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":577688}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Formats.Asn1.AsnEncodingRules`; }
        });
        
        $asm.$str("$sfa.System.Formats.Asn1.TagClass", ($self) => class TagClass extends $.$spc.System.Enum
        {
            static Universal = 0;
            static Application = 64;
            static ContextSpecific = 128;
            static Private = 192;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Universal": 0n,
                    "Application": 64n,
                    "ContextSpecific": 128n,
                    "Private": 192n
                };
            }
            static $h = 1560728;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1560728,"n":"Universal","d":1560728,"h":4296528024,"f":33},{"t":1560728,"n":"Application","d":1560728,"h":8591495320,"f":33},{"t":1560728,"n":"ContextSpecific","d":1560728,"h":12886462616,"f":33},{"t":1560728,"n":"Private","d":1560728,"h":17181429912,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1560728,"h":21476397208,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1560728}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Formats.Asn1.TagClass`; }
        });
        
        $asm.$str("$sfa.System.Formats.Asn1.UniversalTagNumber", ($self) => class UniversalTagNumber extends $.$spc.System.Enum
        {
            static EndOfContents = 0;
            static Boolean = 1;
            static Integer = 2;
            static BitString = 3;
            static OctetString = 4;
            static Null = 5;
            static ObjectIdentifier = 6;
            static ObjectDescriptor = 7;
            static External = 8;
            static InstanceOf = 8;
            static Real = 9;
            static Enumerated = 10;
            static Embedded = 11;
            static UTF8String = 12;
            static RelativeObjectIdentifier = 13;
            static Time = 14;
            static Sequence = 16;
            static SequenceOf = 16;
            static Set = 17;
            static SetOf = 17;
            static NumericString = 18;
            static PrintableString = 19;
            static TeletexString = 20;
            static T61String = 20;
            static VideotexString = 21;
            static IA5String = 22;
            static UtcTime = 23;
            static GeneralizedTime = 24;
            static GraphicString = 25;
            static VisibleString = 26;
            static ISO646String = 26;
            static GeneralString = 27;
            static UniversalString = 28;
            static UnrestrictedCharacterString = 29;
            static BMPString = 30;
            static Date = 31;
            static TimeOfDay = 32;
            static DateTime = 33;
            static Duration = 34;
            static ObjectIdentifierIRI = 35;
            static RelativeObjectIdentifierIRI = 36;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "EndOfContents": 0n,
                    "Boolean": 1n,
                    "Integer": 2n,
                    "BitString": 3n,
                    "OctetString": 4n,
                    "Null": 5n,
                    "ObjectIdentifier": 6n,
                    "ObjectDescriptor": 7n,
                    "External": 8n,
                    "InstanceOf": 8n,
                    "Real": 9n,
                    "Enumerated": 10n,
                    "Embedded": 11n,
                    "UTF8String": 12n,
                    "RelativeObjectIdentifier": 13n,
                    "Time": 14n,
                    "Sequence": 16n,
                    "SequenceOf": 16n,
                    "Set": 17n,
                    "SetOf": 17n,
                    "NumericString": 18n,
                    "PrintableString": 19n,
                    "TeletexString": 20n,
                    "T61String": 20n,
                    "VideotexString": 21n,
                    "IA5String": 22n,
                    "UtcTime": 23n,
                    "GeneralizedTime": 24n,
                    "GraphicString": 25n,
                    "VisibleString": 26n,
                    "ISO646String": 26n,
                    "GeneralString": 27n,
                    "UniversalString": 28n,
                    "UnrestrictedCharacterString": 29n,
                    "BMPString": 30n,
                    "Date": 31n,
                    "TimeOfDay": 32n,
                    "DateTime": 33n,
                    "Duration": 34n,
                    "ObjectIdentifierIRI": 35n,
                    "RelativeObjectIdentifierIRI": 36n
                };
            }
            static $h = 1626264;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1626264,"n":"EndOfContents","d":1626264,"h":4296593560,"f":33},{"t":1626264,"n":"Boolean","d":1626264,"h":8591560856,"f":33},{"t":1626264,"n":"Integer","d":1626264,"h":12886528152,"f":33},{"t":1626264,"n":"BitString","d":1626264,"h":17181495448,"f":33},{"t":1626264,"n":"OctetString","d":1626264,"h":21476462744,"f":33},{"t":1626264,"n":"Null","d":1626264,"h":25771430040,"f":33},{"t":1626264,"n":"ObjectIdentifier","d":1626264,"h":30066397336,"f":33},{"t":1626264,"n":"ObjectDescriptor","d":1626264,"h":34361364632,"f":33},{"t":1626264,"n":"External","d":1626264,"h":38656331928,"f":33},{"t":1626264,"n":"InstanceOf","d":1626264,"h":42951299224,"f":33},{"t":1626264,"n":"Real","d":1626264,"h":47246266520,"f":33},{"t":1626264,"n":"Enumerated","d":1626264,"h":51541233816,"f":33},{"t":1626264,"n":"Embedded","d":1626264,"h":55836201112,"f":33},{"t":1626264,"n":"UTF8String","d":1626264,"h":60131168408,"f":33},{"t":1626264,"n":"RelativeObjectIdentifier","d":1626264,"h":64426135704,"f":33},{"t":1626264,"n":"Time","d":1626264,"h":68721103000,"f":33},{"t":1626264,"n":"Sequence","d":1626264,"h":73016070296,"f":33},{"t":1626264,"n":"SequenceOf","d":1626264,"h":77311037592,"f":33},{"t":1626264,"n":"Set","d":1626264,"h":81606004888,"f":33},{"t":1626264,"n":"SetOf","d":1626264,"h":85900972184,"f":33},{"t":1626264,"n":"NumericString","d":1626264,"h":90195939480,"f":33},{"t":1626264,"n":"PrintableString","d":1626264,"h":94490906776,"f":33},{"t":1626264,"n":"TeletexString","d":1626264,"h":98785874072,"f":33},{"t":1626264,"n":"T61String","d":1626264,"h":103080841368,"f":33},{"t":1626264,"n":"VideotexString","d":1626264,"h":107375808664,"f":33},{"t":1626264,"n":"IA5String","d":1626264,"h":111670775960,"f":33},{"t":1626264,"n":"UtcTime","d":1626264,"h":115965743256,"f":33},{"t":1626264,"n":"GeneralizedTime","d":1626264,"h":120260710552,"f":33},{"t":1626264,"n":"GraphicString","d":1626264,"h":124555677848,"f":33},{"t":1626264,"n":"VisibleString","d":1626264,"h":128850645144,"f":33},{"t":1626264,"n":"ISO646String","d":1626264,"h":133145612440,"f":33},{"t":1626264,"n":"GeneralString","d":1626264,"h":137440579736,"f":33},{"t":1626264,"n":"UniversalString","d":1626264,"h":141735547032,"f":33},{"t":1626264,"n":"UnrestrictedCharacterString","d":1626264,"h":146030514328,"f":33},{"t":1626264,"n":"BMPString","d":1626264,"h":150325481624,"f":33},{"t":1626264,"n":"Date","d":1626264,"h":154620448920,"f":33},{"t":1626264,"n":"TimeOfDay","d":1626264,"h":158915416216,"f":33},{"t":1626264,"n":"DateTime","d":1626264,"h":163210383512,"f":33},{"t":1626264,"n":"Duration","d":1626264,"h":167505350808,"f":33},{"t":1626264,"n":"ObjectIdentifierIRI","d":1626264,"h":171800318104,"f":33},{"t":1626264,"n":"RelativeObjectIdentifierIRI","d":1626264,"h":176095285400,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1626264,"h":180390252696,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1626264}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Formats.Asn1.UniversalTagNumber`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.IA5Encoding", ($self) => class IA5Encoding extends $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding
        {
            $ctor$7()
            {
                super.$ctor$5(0, 127);
                {
                }
                return this;
            }
            static $h = 1101976;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1298584,"c":[{"n":".ctor","o":"$ctor$7","d":1101976,"h":4296069272,"f":8}],"i":[57147393],"h":1101976}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.IA5Encoding`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.VisibleStringEncoding", ($self) => class VisibleStringEncoding extends $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding
        {
            $ctor$7()
            {
                super.$ctor$5(32, 126);
                {
                }
                return this;
            }
            static $h = 1691800;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1298584,"c":[{"n":".ctor","o":"$ctor$7","d":1691800,"h":4296659096,"f":8}],"i":[57147393],"h":1691800}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.VisibleStringEncoding`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.NumericStringEncoding", ($self) => class NumericStringEncoding extends $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding
        {
            $ctor$7()
            {
                super.$ctor$6("0123456789 ");
                {
                }
                return this;
            }
            static $h = 1167512;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1298584,"c":[{"n":".ctor","o":"$ctor$7","d":1167512,"h":4296134808,"f":8}],"i":[57147393],"h":1167512}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.NumericStringEncoding`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.PrintableStringEncoding", ($self) => class PrintableStringEncoding extends $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding
        {
            $ctor$7()
            {
                super.$ctor$6("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 '()+,-./:=?");
                {
                }
                return this;
            }
            static $h = 1233048;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1298584,"c":[{"n":".ctor","o":"$ctor$7","d":1233048,"h":4296200344,"f":8}],"i":[57147393],"h":1233048}; }
            static get $b() { return $.$sfa.System.Formats.Asn1.RestrictedAsciiStringEncoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Formats.Asn1.PrintableStringEncoding`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.SetOfValueComparer", ($self) => class SetOfValueComparer extends $.$spc.System.Object
        {
            /*SetOfValueComparer*/ static Instance = null;
            /*int */ Compare(/*ReadOnlyMemory<byte>*/ x, /*ReadOnlyMemory<byte>*/ y)
            {
                return $.$sfa.System.Formats.Asn1.SetOfValueComparer.Compare$1(x.Span, y.Span);
            }
            static /*int */ Compare$1(/*ReadOnlySpan<byte>*/ x, /*ReadOnlySpan<byte>*/ y)
            {
                /*int*/ let min = $.$spc.System.Math.Min$4(x.Length, y.Length);
                /*int*/ let diff;
                /*int*/ let diffIndex = $.$spc.System.MemoryExtensions.CommonPrefixLength$2($.$spc.System.Byte, x, y);
                if (diffIndex !== min)
                {
                    return (($.$cast(x.get_Item(diffIndex).$v, $.$spc.System.Int32) - y.get_Item(diffIndex).$v) | 0);
                }
                diff = ((x.Length - y.Length) | 0);
                return diff;
            }
            //Generated interface implemetation for System.Collections.Generic.IComparer<System.ReadOnlyMemory<byte>>.Compare(System.ReadOnlyMemory<byte>, System.ReadOnlyMemory<byte>)
            System$Collections$Generic$IComparer$$$Compare()
            {
                return this.Compare(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sfa.System.Formats.Asn1.SetOfValueComparer().$ctor$1();
                }
            }
            static $h = 1364120;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1364120,"g":{"r":0,"d":0,"h":12886266008,"f":40},"n":"Instance","d":1364120,"h":8591298712,"f":40}],"m":[{"r":655361,"p":[{"n":"x","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"y","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h}],"n":"Compare","d":1364120,"h":17181233304,"f":1},{"r":655361,"p":[{"n":"x","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"y","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Compare","o":"@$1","d":1364120,"h":21476200600,"f":40}],"c":[{"n":".ctor","o":"$ctor$1","d":1364120,"h":25771167896,"f":1}],"i":[$.$spc.System.Collections.Generic.IComparer$$($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte)).$h],"h":1364120}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IComparer$$($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte)) ]; }
            static get $fullName() { return `System.Formats.Asn1.SetOfValueComparer`; }
        });
        
        $asm.$cls("$sfa.System.Formats.Asn1.AsnContentException", ($self) => class AsnContentException extends $.$spc.System.Exception
        {
            $ctor$5()
            {
                super.$ctor$2($.$sfa.System.SR.ContentException_DefaultMessage);
                {
                }
                return this;
            }
            $ctor$6(/*string?*/ message)
            {
                super.$ctor$2(message ?? $.$sfa.System.SR.ContentException_DefaultMessage);
                {
                }
                return this;
            }
            $ctor$7(/*string?*/ message, /*Exception?*/ inner)
            {
                super.$ctor$3(message ?? $.$sfa.System.SR.ContentException_DefaultMessage, inner);
                {
                }
                return this;
            }
            $ctor$8(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$4(info, context);
                {
                }
                return this;
            }
            static $h = 250008;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47185921,"h":250008}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Formats.Asn1.AsnContentException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.Numerics", "NetJs.System.Runtime.InteropServices"))