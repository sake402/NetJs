
//--TRIMMABLE-BOUNDARY-START(34)
(async function () {
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $sic) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.IO.Compression.Brotli", 
    {
  "h": 34,
  "f": "System.IO.Compression.Brotli",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.IO.Compression.Brotli",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.IO.Compression.Brotli",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65570)
        $asm.$cls(`$sicb.SIC.BrotliCompressionOptions`, ($self) => class BrotliCompressionOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295032866)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032866);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032866)
            
            //--TRIMMABLE-BOUNDARY-START(17179934754)
            /*int */ get Quality()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Quality(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17179934754)
            
            //--TRIMMABLE-BOUNDARY-START(4295032866)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295032866)
            
            static $h = 65570;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17179934754),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12884967458,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25769869346,
        "f": 83886081
      },
      "n": "Quality",
      "d": 65570,
      "h": 17179934754,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179934754)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032866),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65570,
      "h": 4295032866,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032866)
  ],
  "h": 65570
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Compression.BrotliCompressionOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Compression${separator}BrotliCompressionOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65570)
        
        

        //--TRIMMABLE-BOUNDARY-START(131106)
        $asm.$str(`$sicb.SIC.BrotliDecoder`, ($self) => class BrotliDecoder extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295098402)
            /*object*/ _dummy = null;
            //--TRIMMABLE-BOUNDARY-END(4295098402)
            
            //--TRIMMABLE-BOUNDARY-START(8590065698)
            /*int*/ _dummyPrimitive = 0;
            //--TRIMMABLE-BOUNDARY-END(8590065698)
            
            //--TRIMMABLE-BOUNDARY-START(17180000290)
            /*System.Buffers.OperationStatus */ Decompress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180000290)
            
            //--TRIMMABLE-BOUNDARY-START(21474967586)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21474967586)
            
            //--TRIMMABLE-BOUNDARY-START(25769934882)
            static /*bool */ TryDecompress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25769934882)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(12885032994)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885032994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885032994)
            
            //--TRIMMABLE-BOUNDARY-START(12885032994)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885032994)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            static $h = 131106;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180000290),
    {
      "r": 50200577,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "Decompress",
      "d": 131106,
      "h": 17180000290,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180000290),
//--TRIMMABLE-BOUNDARY-START(21474967586),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 131106,
      "h": 21474967586,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474967586),
//--TRIMMABLE-BOUNDARY-START(25769934882),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryDecompress",
      "d": 131106,
      "h": 25769934882,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769934882)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098402),
    {
      "t": 131073,
      "n": "_dummy",
      "d": 131106,
      "h": 4295098402,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098402),
//--TRIMMABLE-BOUNDARY-START(8590065698),
    {
      "t": 655361,
      "n": "_dummyPrimitive",
      "d": 131106,
      "h": 8590065698,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065698)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885032994),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131106,
      "h": 12885032994,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885032994)
  ],
  "h": 131106
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Compression.BrotliDecoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Compression${separator}BrotliDecoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131106)
        
        

        //--TRIMMABLE-BOUNDARY-START(196642)
        $asm.$str(`$sicb.SIC.BrotliEncoder`, ($self) => class BrotliEncoder extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295163938)
            /*object*/ _dummy = null;
            //--TRIMMABLE-BOUNDARY-END(4295163938)
            
            //--TRIMMABLE-BOUNDARY-START(8590131234)
            /*int*/ _dummyPrimitive = 0;
            //--TRIMMABLE-BOUNDARY-END(8590131234)
            
            //--TRIMMABLE-BOUNDARY-START(17180065826)
            $ctor$3(/*int*/ quality, /*int*/ window)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065826);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065826)
            
            //--TRIMMABLE-BOUNDARY-START(21475033122)
            /*System.Buffers.OperationStatus */ Compress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475033122)
            
            //--TRIMMABLE-BOUNDARY-START(25770000418)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25770000418)
            
            //--TRIMMABLE-BOUNDARY-START(30064967714)
            /*System.Buffers.OperationStatus */ Flush(/*System.Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30064967714)
            
            //--TRIMMABLE-BOUNDARY-START(34359935010)
            static /*int */ GetMaxCompressedLength(/*int*/ inputSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359935010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34359935010)
            
            //--TRIMMABLE-BOUNDARY-START(42949869602)
            static /*bool */ TryCompress$1(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42949869602)
            
            //--TRIMMABLE-BOUNDARY-START(38654902306)
            static /*bool */ TryCompress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesWritten, /*int*/ quality, /*int*/ window)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38654902306)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(12885098530)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098530)
            
            //--TRIMMABLE-BOUNDARY-START(12885098530)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885098530)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            static $h = 196642;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475033122),
    {
      "r": 50200577,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesConsumed",
          "p": 655361,
          "f": 2
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "Compress",
      "d": 196642,
      "h": 21475033122,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475033122),
//--TRIMMABLE-BOUNDARY-START(25770000418),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 196642,
      "h": 25770000418,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770000418),
//--TRIMMABLE-BOUNDARY-START(30064967714),
    {
      "r": 50200577,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "Flush",
      "d": 196642,
      "h": 30064967714,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064967714),
//--TRIMMABLE-BOUNDARY-START(34359935010),
    {
      "r": 655361,
      "p": [
        {
          "n": "inputSize",
          "p": 655361
        }
      ],
      "n": "GetMaxCompressedLength",
      "d": 196642,
      "h": 34359935010,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34359935010),
//--TRIMMABLE-BOUNDARY-START(42949869602),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryCompress",
      "o": "@$1",
      "d": 196642,
      "h": 42949869602,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949869602),
//--TRIMMABLE-BOUNDARY-START(38654902306),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "quality",
          "p": 655361
        },
        {
          "n": "window",
          "p": 655361
        }
      ],
      "n": "TryCompress",
      "d": 196642,
      "h": 38654902306,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654902306)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295163938),
    {
      "t": 131073,
      "n": "_dummy",
      "d": 196642,
      "h": 4295163938,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295163938),
//--TRIMMABLE-BOUNDARY-START(8590131234),
    {
      "t": 655361,
      "n": "_dummyPrimitive",
      "d": 196642,
      "h": 8590131234,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590131234)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180065826),
    {
      "p": [
        {
          "n": "quality",
          "p": 655361
        },
        {
          "n": "window",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196642,
      "h": 17180065826,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065826),
//--TRIMMABLE-BOUNDARY-START(12885098530),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196642,
      "h": 12885098530,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098530)
  ],
  "h": 196642
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Compression.BrotliEncoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Compression${separator}BrotliEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196642)
        
        

        //--TRIMMABLE-BOUNDARY-START(262178)
        $asm.$cls(`$sicb.SIC.BrotliStream`, ($self) => class BrotliStream extends $.$$.SI.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(4295229474)
            $ctor$3(/*System.IO.Stream*/ stream, /*System.IO.Compression.BrotliCompressionOptions*/ compressionOptions, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229474);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229474)
            
            //--TRIMMABLE-BOUNDARY-START(12885164066)
            $ctor$5(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionLevel*/ compressionLevel)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885164066);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885164066)
            
            //--TRIMMABLE-BOUNDARY-START(8590196770)
            $ctor$4(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionLevel*/ compressionLevel, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196770);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196770)
            
            //--TRIMMABLE-BOUNDARY-START(21475098658)
            $ctor$7(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionMode*/ mode)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475098658);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098658)
            
            //--TRIMMABLE-BOUNDARY-START(17180131362)
            $ctor$6(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionMode*/ mode, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180131362);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131362)
            
            //--TRIMMABLE-BOUNDARY-START(25770065954)
            /*System.IO.Stream */ get BaseStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770065954)
            
            //--TRIMMABLE-BOUNDARY-START(38654967842)
            /*bool */ get CanRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38654967842)
            
            //--TRIMMABLE-BOUNDARY-START(42949935138)
            /*bool */ get CanSeek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784509986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42949935138)
            
            //--TRIMMABLE-BOUNDARY-START(47244902434)
            /*bool */ get CanWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374444578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47244902434)
            
            //--TRIMMABLE-BOUNDARY-START(128849281058)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964379170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128849281058)
            
            //--TRIMMABLE-BOUNDARY-START(133144248354)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554313762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503986722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(133144248354)
            
            //--TRIMMABLE-BOUNDARY-START(30065033250)
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065033250)
            
            //--TRIMMABLE-BOUNDARY-START(34360000546)
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360000546)
            
            //--TRIMMABLE-BOUNDARY-START(51539869730)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539869730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51539869730)
            
            //--TRIMMABLE-BOUNDARY-START(55834837026)
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55834837026)
            
            //--TRIMMABLE-BOUNDARY-START(60129804322)
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129804322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60129804322)
            
            //--TRIMMABLE-BOUNDARY-START(64424771618)
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424771618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64424771618)
            
            //--TRIMMABLE-BOUNDARY-START(68719738914)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719738914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68719738914)
            
            //--TRIMMABLE-BOUNDARY-START(73014706210)
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73014706210)
            
            //--TRIMMABLE-BOUNDARY-START(137439215650)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439215650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137439215650)
            
            //--TRIMMABLE-BOUNDARY-START(141734182946)
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734182946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(141734182946)
            
            //--TRIMMABLE-BOUNDARY-START(146029150242)
            /*System.Threading.Tasks.Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029150242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(146029150242)
            
            //--TRIMMABLE-BOUNDARY-START(150324117538)
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324117538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(150324117538)
            
            //--TRIMMABLE-BOUNDARY-START(154619084834)
            /*int */ ReadByte()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619084834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(154619084834)
            
            //--TRIMMABLE-BOUNDARY-START(158914052130)
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914052130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(158914052130)
            
            //--TRIMMABLE-BOUNDARY-START(171798954018)
            /*void */ SetLength(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798954018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(171798954018)
            
            //--TRIMMABLE-BOUNDARY-START(176093921314)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093921314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(176093921314)
            
            //--TRIMMABLE-BOUNDARY-START(180388888610)
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388888610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(180388888610)
            
            //--TRIMMABLE-BOUNDARY-START(184683855906)
            /*System.Threading.Tasks.Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683855906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(184683855906)
            
            //--TRIMMABLE-BOUNDARY-START(188978823202)
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978823202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(188978823202)
            
            //--TRIMMABLE-BOUNDARY-START(193273790498)
            /*void */ WriteByte(/*byte*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273790498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(193273790498)
            
            static $h = 262178;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.Stream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770065954),
    {
      "p": 95748097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604640802,
        "f": 50331649
      },
      "n": "BaseStream",
      "d": 262178,
      "h": 25770065954,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770065954),
//--TRIMMABLE-BOUNDARY-START(38654967842),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194575394,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 262178,
      "h": 38654967842,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38654967842),
//--TRIMMABLE-BOUNDARY-START(42949935138),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784509986,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 262178,
      "h": 42949935138,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42949935138),
//--TRIMMABLE-BOUNDARY-START(47244902434),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374444578,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 262178,
      "h": 47244902434,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47244902434),
//--TRIMMABLE-BOUNDARY-START(128849281058),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964379170,
        "f": 50364417
      },
      "n": "Length",
      "d": 262178,
      "h": 128849281058,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(128849281058),
//--TRIMMABLE-BOUNDARY-START(133144248354),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554313762,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167503986722,
        "f": 83918849
      },
      "n": "Position",
      "d": 262178,
      "h": 133144248354,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133144248354)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065033250),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginRead",
      "d": 262178,
      "h": 30065033250,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065033250),
//--TRIMMABLE-BOUNDARY-START(34360000546),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginWrite",
      "d": 262178,
      "h": 34360000546,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360000546),
//--TRIMMABLE-BOUNDARY-START(51539869730),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 262178,
      "h": 51539869730,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51539869730),
//--TRIMMABLE-BOUNDARY-START(55834837026),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 262178,
      "h": 55834837026,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55834837026),
//--TRIMMABLE-BOUNDARY-START(60129804322),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndRead",
      "d": 262178,
      "h": 60129804322,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60129804322),
//--TRIMMABLE-BOUNDARY-START(64424771618),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndWrite",
      "d": 262178,
      "h": 64424771618,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64424771618),
//--TRIMMABLE-BOUNDARY-START(68719738914),
    {
      "r": 65537,
      "n": "Flush",
      "d": 262178,
      "h": 68719738914,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68719738914),
//--TRIMMABLE-BOUNDARY-START(73014706210),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 262178,
      "h": 73014706210,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73014706210),
//--TRIMMABLE-BOUNDARY-START(137439215650),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 262178,
      "h": 137439215650,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137439215650),
//--TRIMMABLE-BOUNDARY-START(141734182946),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 262178,
      "h": 141734182946,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(141734182946),
//--TRIMMABLE-BOUNDARY-START(146029150242),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "d": 262178,
      "h": 146029150242,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029150242),
//--TRIMMABLE-BOUNDARY-START(150324117538),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 262178,
      "h": 150324117538,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324117538),
//--TRIMMABLE-BOUNDARY-START(154619084834),
    {
      "r": 655361,
      "n": "ReadByte",
      "d": 262178,
      "h": 154619084834,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154619084834),
//--TRIMMABLE-BOUNDARY-START(158914052130),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 262178,
      "h": 158914052130,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158914052130),
//--TRIMMABLE-BOUNDARY-START(171798954018),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 262178,
      "h": 171798954018,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171798954018),
//--TRIMMABLE-BOUNDARY-START(176093921314),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 262178,
      "h": 176093921314,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176093921314),
//--TRIMMABLE-BOUNDARY-START(180388888610),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 262178,
      "h": 180388888610,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180388888610),
//--TRIMMABLE-BOUNDARY-START(184683855906),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "d": 262178,
      "h": 184683855906,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184683855906),
//--TRIMMABLE-BOUNDARY-START(188978823202),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 262178,
      "h": 188978823202,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(188978823202),
//--TRIMMABLE-BOUNDARY-START(193273790498),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        }
      ],
      "n": "WriteByte",
      "d": 262178,
      "h": 193273790498,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193273790498)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229474),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "compressionOptions",
          "p": 65570
        },
        {
          "n": "leaveOpen",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262178,
      "h": 4295229474,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229474),
//--TRIMMABLE-BOUNDARY-START(12885164066),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "compressionLevel",
          "p": 720929
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 262178,
      "h": 12885164066,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885164066),
//--TRIMMABLE-BOUNDARY-START(8590196770),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "compressionLevel",
          "p": 720929
        },
        {
          "n": "leaveOpen",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 262178,
      "h": 8590196770,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590196770),
//--TRIMMABLE-BOUNDARY-START(21475098658),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "mode",
          "p": 786465
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 262178,
      "h": 21475098658,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475098658),
//--TRIMMABLE-BOUNDARY-START(17180131362),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "mode",
          "p": 786465
        },
        {
          "n": "leaveOpen",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 262178,
      "h": 17180131362,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131362)
  ],
  "h": 262178
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Compression.BrotliStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Compression${separator}BrotliStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262178)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.IO.Compression"));
})();
//--TRIMMABLE-BOUNDARY-END(34)
