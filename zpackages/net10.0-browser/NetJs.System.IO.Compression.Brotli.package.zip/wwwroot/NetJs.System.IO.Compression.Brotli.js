
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $sic) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Compression.Brotli", 
    {"h":37614,"f":"System.IO.Compression.Brotli","v":"1.0.35.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Compression.Brotli","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Compression.Brotli","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sicb.System.IO.Compression.BrotliCompressionOptions", ($self) => class BrotliCompressionOptions extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Quality()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Quality(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 103150;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885005038,"f":50331649},"s":{"r":0,"d":0,"h":17179972334,"f":83886081},"n":"Quality","d":103150,"h":8590037742,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":103150,"h":4295070446,"f":16777217}],"h":103150}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.Compression.BrotliCompressionOptions`; }
        });
        
        $asm.$str("$sicb.System.IO.Compression.BrotliDecoder", ($self) => class BrotliDecoder extends $.$$.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Buffers.OperationStatus */ Decompress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            static /*bool */ TryDecompress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 168686;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":18743297,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"Decompress","d":168686,"h":12885070574,"f":16777217},{"r":65537,"n":"Dispose","d":168686,"h":17180037870,"f":16777217},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryDecompress","d":168686,"h":21475005166,"f":16777249}],"l":[{"t":131073,"n":"_dummy","d":168686,"h":4295135982,"f":4194306},{"t":655361,"n":"_dummyPrimitive","d":168686,"h":8590103278,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":168686,"h":25769972462,"f":16777217}],"i":[57540609],"h":168686}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.IO.Compression.BrotliDecoder`; }
        });
        
        $asm.$str("$sicb.System.IO.Compression.BrotliEncoder", ($self) => class BrotliEncoder extends $.$$.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$3(/*int*/ quality, /*int*/ window)
            {
                super.$ctor$1();
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*System.Buffers.OperationStatus */ Compress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*System.Buffers.OperationStatus */ Flush(/*System.Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ GetMaxCompressedLength(/*int*/ inputSize)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ TryCompress$1(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ TryCompress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesWritten, /*int*/ quality, /*int*/ window)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 234222;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":18743297,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"Compress","d":234222,"h":17180103406,"f":16777217},{"r":65537,"n":"Dispose","d":234222,"h":21475070702,"f":16777217},{"r":18743297,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"Flush","d":234222,"h":25770037998,"f":16777217},{"r":655361,"p":[{"n":"inputSize","p":655361}],"n":"GetMaxCompressedLength","d":234222,"h":30065005294,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryCompress","o":"@$1","d":234222,"h":34359972590,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2},{"n":"quality","p":655361},{"n":"window","p":655361}],"n":"TryCompress","d":234222,"h":38654939886,"f":16777249}],"l":[{"t":131073,"n":"_dummy","d":234222,"h":4295201518,"f":4194306},{"t":655361,"n":"_dummyPrimitive","d":234222,"h":8590168814,"f":4194306}],"c":[{"p":[{"n":"quality","p":655361},{"n":"window","p":655361}],"n":".ctor","o":"$ctor$3","d":234222,"h":12885136110,"f":16777217},{"n":".ctor","o":"$ctor$2","d":234222,"h":42949907182,"f":16777217}],"i":[57540609],"h":234222}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.IO.Compression.BrotliEncoder`; }
        });
        
        $asm.$cls("$sicb.System.IO.Compression.BrotliStream", ($self) => class BrotliStream extends $.$$.System.IO.Stream
        {
            $ctor$7(/*System.IO.Stream*/ stream, /*System.IO.Compression.BrotliCompressionOptions*/ compressionOptions, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionLevel*/ compressionLevel)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$3(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionLevel*/ compressionLevel, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionMode*/ mode)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionMode*/ mode, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IO.Stream */ get BaseStream()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanRead()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 299758;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":62193665,"g":{"r":0,"d":0,"h":30065070830,"f":50331649},"n":"BaseStream","d":299758,"h":25770103534,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":38655005422,"f":50364417},"n":"CanRead","d":299758,"h":34360038126,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":47244940014,"f":50364417},"n":"CanSeek","d":299758,"h":42949972718,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":55834874606,"f":50364417},"n":"CanWrite","d":299758,"h":51539907310,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":64424809198,"f":50364417},"n":"Length","d":299758,"h":60129841902,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":73014743790,"f":50364417},"s":{"r":0,"d":0,"h":77309711086,"f":83918849},"n":"Position","d":299758,"h":68719776494,"f":2129921}],"m":[{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginRead","d":299758,"h":81604678382,"f":16809985},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":299758,"h":85899645678,"f":16809985},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":299758,"h":90194612974,"f":16809988},{"r":135987201,"n":"DisposeAsync","d":299758,"h":94489580270,"f":16809985},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":299758,"h":98784547566,"f":16809985},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":299758,"h":103079514862,"f":16809985},{"r":65537,"n":"Flush","d":299758,"h":107374482158,"f":16809985},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"FlushAsync","o":"@$1","d":299758,"h":111669449454,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":299758,"h":115964416750,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"Read","o":"@$1","d":299758,"h":120259384046,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","d":299758,"h":124554351342,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","o":"@$2","d":299758,"h":128849318638,"f":16809985},{"r":655361,"n":"ReadByte","d":299758,"h":133144285934,"f":16809985},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":299758,"h":137439253230,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":299758,"h":141734220526,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":299758,"h":146029187822,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"Write","o":"@$1","d":299758,"h":150324155118,"f":16809985},{"r":133169153,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"WriteAsync","d":299758,"h":154619122414,"f":16809985},{"r":135987201,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","o":"@$2","d":299758,"h":158914089710,"f":16809985},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":299758,"h":163209057006,"f":16809985}],"c":[{"p":[{"n":"stream","p":62193665},{"n":"compressionOptions","p":103150},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$7","d":299758,"h":4295267054,"f":16777217},{"p":[{"n":"stream","p":62193665},{"n":"compressionLevel","p":782893}],"n":".ctor","o":"$ctor$4","d":299758,"h":8590234350,"f":16777217},{"p":[{"n":"stream","p":62193665},{"n":"compressionLevel","p":782893},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":299758,"h":12885201646,"f":16777217},{"p":[{"n":"stream","p":62193665},{"n":"mode","p":848429}],"n":".ctor","o":"$ctor$6","d":299758,"h":17180168942,"f":16777217},{"p":[{"n":"stream","p":62193665},{"n":"mode","p":848429},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":299758,"h":21475136238,"f":16777217}],"i":[57540609,56950785],"h":299758}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.BrotliStream`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.IO.Compression"))