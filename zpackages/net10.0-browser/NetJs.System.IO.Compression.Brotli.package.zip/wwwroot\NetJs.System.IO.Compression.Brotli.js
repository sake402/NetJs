
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $sic) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Compression.Brotli", 
    {"h":60093,"f":"System.IO.Compression.Brotli","v":"1.0.35.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Compression.Brotli","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Compression.Brotli","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sicb.System.IO.Compression.BrotliCompressionOptions", ($self) => class BrotliCompressionOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Quality()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Quality(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 125629;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885027517,"f":1},"s":{"r":0,"d":0,"h":17179994813,"f":1},"n":"Quality","d":125629,"h":8590060221,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":125629,"h":4295092925,"f":1}],"h":125629}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.BrotliCompressionOptions`; }
        });
        
        $asm.$str("$sicb.System.IO.Compression.BrotliDecoder", ($self) => class BrotliDecoder extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Buffers.OperationStatus */ Decompress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            static /*bool */ TryDecompress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 191165;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":18677761,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"Decompress","d":191165,"h":12885093053,"f":1},{"r":65537,"n":"Dispose","d":191165,"h":17180060349,"f":1},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryDecompress","d":191165,"h":21475027645,"f":33}],"l":[{"t":131073,"n":"_dummy","d":191165,"h":4295158461,"f":2},{"t":655361,"n":"_dummyPrimitive","d":191165,"h":8590125757,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":191165,"h":25769994941,"f":1}],"i":[57540609],"h":191165}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.Compression.BrotliDecoder`; }
        });
        
        $asm.$str("$sicb.System.IO.Compression.BrotliEncoder", ($self) => class BrotliEncoder extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$2(/*int*/ quality, /*int*/ window)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*System.Buffers.OperationStatus */ Compress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*System.Buffers.OperationStatus */ Flush(/*System.Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ GetMaxCompressedLength(/*int*/ inputSize)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ TryCompress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ TryCompress$1(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesWritten, /*int*/ quality, /*int*/ window)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 256701;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":18677761,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"Compress","d":256701,"h":17180125885,"f":1},{"r":65537,"n":"Dispose","d":256701,"h":21475093181,"f":1},{"r":18677761,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"Flush","d":256701,"h":25770060477,"f":1},{"r":655361,"p":[{"n":"inputSize","p":655361}],"n":"GetMaxCompressedLength","d":256701,"h":30065027773,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryCompress","d":256701,"h":34359995069,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2},{"n":"quality","p":655361},{"n":"window","p":655361}],"n":"TryCompress","o":"@$1","d":256701,"h":38654962365,"f":33}],"l":[{"t":131073,"n":"_dummy","d":256701,"h":4295223997,"f":2},{"t":655361,"n":"_dummyPrimitive","d":256701,"h":8590191293,"f":2}],"c":[{"p":[{"n":"quality","p":655361},{"n":"window","p":655361}],"n":".ctor","o":"$ctor$2","d":256701,"h":12885158589,"f":1},{"n":".ctor","o":"$ctor$3","d":256701,"h":42949929661,"f":1}],"i":[57540609],"h":256701}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.Compression.BrotliEncoder`; }
        });
        
        $asm.$cls("$sicb.System.IO.Compression.BrotliStream", ($self) => class BrotliStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.IO.Stream*/ stream, /*System.IO.Compression.BrotliCompressionOptions*/ compressionOptions, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionLevel*/ compressionLevel)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionLevel*/ compressionLevel, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionMode*/ mode)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionMode*/ mode, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IO.Stream */ get BaseStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 322237;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":62193665,"g":{"r":0,"d":0,"h":30065093309,"f":1},"n":"BaseStream","d":322237,"h":25770126013,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655027901,"f":32769},"n":"CanRead","d":322237,"h":34360060605,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":47244962493,"f":32769},"n":"CanSeek","d":322237,"h":42949995197,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":55834897085,"f":32769},"n":"CanWrite","d":322237,"h":51539929789,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":64424831677,"f":32769},"n":"Length","d":322237,"h":60129864381,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":73014766269,"f":32769},"s":{"r":0,"d":0,"h":77309733565,"f":32769},"n":"Position","d":322237,"h":68719798973,"f":32769}],"m":[{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginRead","d":322237,"h":81604700861,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":322237,"h":85899668157,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":322237,"h":90194635453,"f":32772},{"r":136118273,"n":"DisposeAsync","d":322237,"h":94489602749,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":322237,"h":98784570045,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":322237,"h":103079537341,"f":32769},{"r":65537,"n":"Flush","d":322237,"h":107374504637,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":322237,"h":111669471933,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":322237,"h":115964439229,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":322237,"h":120259406525,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":322237,"h":124554373821,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":322237,"h":128849341117,"f":32769},{"r":655361,"n":"ReadByte","d":322237,"h":133144308413,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":322237,"h":137439275709,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":322237,"h":141734243005,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":322237,"h":146029210301,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":322237,"h":150324177597,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":322237,"h":154619144893,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":322237,"h":158914112189,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":322237,"h":163209079485,"f":32769}],"c":[{"p":[{"n":"stream","p":62193665},{"n":"compressionOptions","p":125629},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$3","d":322237,"h":4295289533,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"compressionLevel","p":778231}],"n":".ctor","o":"$ctor$4","d":322237,"h":8590256829,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"compressionLevel","p":778231},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":322237,"h":12885224125,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"mode","p":843767}],"n":".ctor","o":"$ctor$6","d":322237,"h":17180191421,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"mode","p":843767},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$7","d":322237,"h":21475158717,"f":1}],"i":[57540609,56950785],"h":322237}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.BrotliStream`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.IO.Compression"))