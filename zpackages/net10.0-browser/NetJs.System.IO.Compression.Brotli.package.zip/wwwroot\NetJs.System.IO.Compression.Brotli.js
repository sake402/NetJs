
(function ($global, $, $spc, $sc, $sdt, $sm, $spu, $st, $sr, $scc, $sris, $sic) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Compression.Brotli", 
    {"h":47602,"f":"System.IO.Compression.Brotli","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Compression.Brotli","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Compression.Brotli","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sicb.System.IO.Compression.BrotliCompressionOptions", ($self) => class BrotliCompressionOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Quality()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Quality(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 113138;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885015026,"f":1},"s":{"r":0,"d":0,"h":17179982322,"f":1},"n":"Quality","d":113138,"h":8590047730,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":113138,"h":4295080434,"f":1}],"h":113138}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.BrotliCompressionOptions`; }
        });
        
        $asm.$str("$sicb.System.IO.Compression.BrotliDecoder", ($self) => class BrotliDecoder extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Buffers.OperationStatus */ Decompress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            static /*bool */ TryDecompress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 178674;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":18612225,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2}],"n":"Decompress","d":178674,"h":12885080562,"f":1},{"r":65537,"n":"Dispose","d":178674,"h":17180047858,"f":1},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryDecompress","d":178674,"h":21475015154,"f":33}],"l":[{"t":131073,"n":"_dummy","d":178674,"h":4295145970,"f":2},{"t":655361,"n":"_dummyPrimitive","d":178674,"h":8590113266,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":178674,"h":25769982450,"f":1}],"i":[57475073],"h":178674}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.Compression.BrotliDecoder`; }
        });
        
        $asm.$str("$sicb.System.IO.Compression.BrotliEncoder", ($self) => class BrotliEncoder extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$2(/*int*/ quality, /*int*/ window)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*System.Buffers.OperationStatus */ Compress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesConsumed, /*out int*/ bytesWritten, /*bool*/ isFinalBlock)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*System.Buffers.OperationStatus */ Flush(/*System.Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ GetMaxCompressedLength(/*int*/ inputSize)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ TryCompress(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ TryCompress$1(/*System.ReadOnlySpan<byte>*/ source, /*System.Span<byte>*/ destination, /*out int*/ bytesWritten, /*int*/ quality, /*int*/ window)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 244210;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":18612225,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"bytesWritten","p":655361,"f":2},{"n":"isFinalBlock","p":262145}],"n":"Compress","d":244210,"h":17180113394,"f":1},{"r":65537,"n":"Dispose","d":244210,"h":21475080690,"f":1},{"r":18612225,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"Flush","d":244210,"h":25770047986,"f":1},{"r":655361,"p":[{"n":"inputSize","p":655361}],"n":"GetMaxCompressedLength","d":244210,"h":30065015282,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryCompress","d":244210,"h":34359982578,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2},{"n":"quality","p":655361},{"n":"window","p":655361}],"n":"TryCompress","o":"@$1","d":244210,"h":38654949874,"f":33}],"l":[{"t":131073,"n":"_dummy","d":244210,"h":4295211506,"f":2},{"t":655361,"n":"_dummyPrimitive","d":244210,"h":8590178802,"f":2}],"c":[{"p":[{"n":"quality","p":655361},{"n":"window","p":655361}],"n":".ctor","o":"$ctor$2","d":244210,"h":12885146098,"f":1},{"n":".ctor","o":"$ctor$3","d":244210,"h":42949917170,"f":1}],"i":[57475073],"h":244210}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.Compression.BrotliEncoder`; }
        });
        
        $asm.$cls("$sicb.System.IO.Compression.BrotliStream", ($self) => class BrotliStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.IO.Stream*/ stream, /*System.IO.Compression.BrotliCompressionOptions*/ compressionOptions, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionLevel*/ compressionLevel)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionLevel*/ compressionLevel, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionMode*/ mode)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Stream*/ stream, /*System.IO.Compression.CompressionMode*/ mode, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IO.Stream */ get BaseStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 309746;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":62128129,"g":{"r":0,"d":0,"h":30065080818,"f":1},"n":"BaseStream","d":309746,"h":25770113522,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655015410,"f":32769},"n":"CanRead","d":309746,"h":34360048114,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":47244950002,"f":32769},"n":"CanSeek","d":309746,"h":42949982706,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":55834884594,"f":32769},"n":"CanWrite","d":309746,"h":51539917298,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":64424819186,"f":32769},"n":"Length","d":309746,"h":60129851890,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":73014753778,"f":32769},"s":{"r":0,"d":0,"h":77309721074,"f":32769},"n":"Position","d":309746,"h":68719786482,"f":32769}],"m":[{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginRead","d":309746,"h":81604688370,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":309746,"h":85899655666,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":309746,"h":90194622962,"f":32772},{"r":136118273,"n":"DisposeAsync","d":309746,"h":94489590258,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":309746,"h":98784557554,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":309746,"h":103079524850,"f":32769},{"r":65537,"n":"Flush","d":309746,"h":107374492146,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":309746,"h":111669459442,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":309746,"h":115964426738,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":309746,"h":120259394034,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":309746,"h":124554361330,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":309746,"h":128849328626,"f":32769},{"r":655361,"n":"ReadByte","d":309746,"h":133144295922,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":309746,"h":137439263218,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":309746,"h":141734230514,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":309746,"h":146029197810,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":309746,"h":150324165106,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":309746,"h":154619132402,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":309746,"h":158914099698,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":309746,"h":163209066994,"f":32769}],"c":[{"p":[{"n":"stream","p":62128129},{"n":"compressionOptions","p":113138},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$3","d":309746,"h":4295277042,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"compressionLevel","p":765023}],"n":".ctor","o":"$ctor$4","d":309746,"h":8590244338,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"compressionLevel","p":765023},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":309746,"h":12885211634,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"mode","p":830559}],"n":".ctor","o":"$ctor$6","d":309746,"h":17180178930,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"mode","p":830559},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$7","d":309746,"h":21475146226,"f":1}],"i":[57475073,56885249],"h":309746}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.BrotliStream`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.IO.Compression"))