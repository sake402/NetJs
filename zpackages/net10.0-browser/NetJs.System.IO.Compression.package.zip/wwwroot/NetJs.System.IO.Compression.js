
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Compression", 
    {"h":62866,"f":"System.IO.Compression","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Compression","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Compression","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sic.Interop", ($self) => class Interop
        {
            static $_Sys;
            static get Sys()
            {
                let $cls = $.$sic.Interop;
                return $cls.$_Sys ??= $asm.$ncls("$sic.Interop.Sys", ($self) => class Sys
                {
                    static /*int */ PathConf(/*string*/ path, /*PathConfName*/ name)
                    {
                        return -1;
                    }
                    static /*int */ FStat(/*SafeHandle*/ fd, /*out FileStatus*/ output)
                    {
                        output.$v = new $.$sic.Interop.Sys.FileStatus();
                        return -1;
                    }
                    static /*int */ Stat(/*string*/ path, /*out FileStatus*/ output)
                    {
                        output.$v = new $.$sic.Interop.Sys.FileStatus();
                        return -1;
                    }
                    static /*int */ LStat(/*string*/ path, /*out FileStatus*/ output)
                    {
                        output.$v = new $.$sic.Interop.Sys.FileStatus();
                        return -1;
                    }
                    static $_PathConfName;
                    static get PathConfName()
                    {
                        let $cls = $.$sic.Interop.Sys;
                        return $cls.$_PathConfName ??= $asm.$nstr("$sic.Interop.Sys.PathConfName", ($self) => class PathConfName extends $.$spc.System.Enum
                        {
                            static PC_LINK_MAX = 1;
                            static PC_MAX_CANON = 2;
                            static PC_MAX_INPUT = 3;
                            static PC_NAME_MAX = 4;
                            static PC_PATH_MAX = 5;
                            static PC_PIPE_BUF = 6;
                            static PC_CHOWN_RESTRICTED = 7;
                            static PC_NO_TRUNC = 8;
                            static PC_VDISABLE = 9;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "PC_LINK_MAX": 1n,
                                    "PC_MAX_CANON": 2n,
                                    "PC_MAX_INPUT": 3n,
                                    "PC_NAME_MAX": 4n,
                                    "PC_PATH_MAX": 5n,
                                    "PC_PIPE_BUF": 6n,
                                    "PC_CHOWN_RESTRICTED": 7n,
                                    "PC_NO_TRUNC": 8n,
                                    "PC_VDISABLE": 9n
                                };
                            }
                            static $h = 521618;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":521618,"n":"PC_LINK_MAX","d":521618,"h":4295488914,"f":33},{"t":521618,"n":"PC_MAX_CANON","d":521618,"h":8590456210,"f":33},{"t":521618,"n":"PC_MAX_INPUT","d":521618,"h":12885423506,"f":33},{"t":521618,"n":"PC_NAME_MAX","d":521618,"h":17180390802,"f":33},{"t":521618,"n":"PC_PATH_MAX","d":521618,"h":21475358098,"f":33},{"t":521618,"n":"PC_PIPE_BUF","d":521618,"h":25770325394,"f":33},{"t":521618,"n":"PC_CHOWN_RESTRICTED","d":521618,"h":30065292690,"f":33},{"t":521618,"n":"PC_NO_TRUNC","d":521618,"h":34360259986,"f":33},{"t":521618,"n":"PC_VDISABLE","d":521618,"h":38655227282,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":521618,"h":42950194578,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":259474,"h":521618}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.PathConfName`; }
                        }, $cls, ($v) => $cls.$_PathConfName = $v);
                    }
                    static $_FileStatus;
                    static get FileStatus()
                    {
                        let $cls = $.$sic.Interop.Sys;
                        return $cls.$_FileStatus ??= $asm.$nstr("$sic.Interop.Sys.FileStatus", ($self) => class FileStatus extends $.$spc.System.ValueType
                        {
                            /*FileStatusFlags*/  get Flags() { return this.$getField(0, $.$sic.Interop.Sys.FileStatusFlags); }
                            /*FileStatusFlags*/  set Flags(value) { this.$setField(0, $.$sic.Interop.Sys.FileStatusFlags, value); }
                            /*int*/  get Mode() { return this.$getField(4, $.$spc.System.Int32); }
                            /*int*/  set Mode(value) { this.$setField(4, $.$spc.System.Int32, value); }
                            /*uint*/  get Uid() { return this.$getField(8, $.$spc.System.UInt32); }
                            /*uint*/  set Uid(value) { this.$setField(8, $.$spc.System.UInt32, value); }
                            /*uint*/  get Gid() { return this.$getField(12, $.$spc.System.UInt32); }
                            /*uint*/  set Gid(value) { this.$setField(12, $.$spc.System.UInt32, value); }
                            /*long*/  get Size() { return this.$getField(16, $.$spc.System.Int64); }
                            /*long*/  set Size(value) { this.$setField(16, $.$spc.System.Int64, value); }
                            /*long*/  get ATime() { return this.$getField(24, $.$spc.System.Int64); }
                            /*long*/  set ATime(value) { this.$setField(24, $.$spc.System.Int64, value); }
                            /*long*/  get ATimeNsec() { return this.$getField(32, $.$spc.System.Int64); }
                            /*long*/  set ATimeNsec(value) { this.$setField(32, $.$spc.System.Int64, value); }
                            /*long*/  get MTime() { return this.$getField(40, $.$spc.System.Int64); }
                            /*long*/  set MTime(value) { this.$setField(40, $.$spc.System.Int64, value); }
                            /*long*/  get MTimeNsec() { return this.$getField(48, $.$spc.System.Int64); }
                            /*long*/  set MTimeNsec(value) { this.$setField(48, $.$spc.System.Int64, value); }
                            /*long*/  get CTime() { return this.$getField(56, $.$spc.System.Int64); }
                            /*long*/  set CTime(value) { this.$setField(56, $.$spc.System.Int64, value); }
                            /*long*/  get CTimeNsec() { return this.$getField(64, $.$spc.System.Int64); }
                            /*long*/  set CTimeNsec(value) { this.$setField(64, $.$spc.System.Int64, value); }
                            /*long*/  get BirthTime() { return this.$getField(72, $.$spc.System.Int64); }
                            /*long*/  set BirthTime(value) { this.$setField(72, $.$spc.System.Int64, value); }
                            /*long*/  get BirthTimeNsec() { return this.$getField(80, $.$spc.System.Int64); }
                            /*long*/  set BirthTimeNsec(value) { this.$setField(80, $.$spc.System.Int64, value); }
                            /*long*/  get Dev() { return this.$getField(88, $.$spc.System.Int64); }
                            /*long*/  set Dev(value) { this.$setField(88, $.$spc.System.Int64, value); }
                            /*long*/  get RDev() { return this.$getField(96, $.$spc.System.Int64); }
                            /*long*/  set RDev(value) { this.$setField(96, $.$spc.System.Int64, value); }
                            /*long*/  get Ino() { return this.$getField(104, $.$spc.System.Int64); }
                            /*long*/  set Ino(value) { this.$setField(104, $.$spc.System.Int64, value); }
                            /*uint*/  get UserFlags() { return this.$getField(112, $.$spc.System.UInt32); }
                            /*uint*/  set UserFlags(value) { this.$setField(112, $.$spc.System.UInt32, value); }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy.Flags = this.Flags;
                                copy.Mode = this.Mode;
                                copy.Uid = this.Uid;
                                copy.Gid = this.Gid;
                                copy.Size = this.Size;
                                copy.ATime = this.ATime;
                                copy.ATimeNsec = this.ATimeNsec;
                                copy.MTime = this.MTime;
                                copy.MTimeNsec = this.MTimeNsec;
                                copy.CTime = this.CTime;
                                copy.CTimeNsec = this.CTimeNsec;
                                copy.BirthTime = this.BirthTime;
                                copy.BirthTimeNsec = this.BirthTimeNsec;
                                copy.Dev = this.Dev;
                                copy.RDev = this.RDev;
                                copy.Ino = this.Ino;
                                copy.UserFlags = this.UserFlags;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this.Flags = 0;
                                this.Mode = 0;
                                this.Uid = 0;
                                this.Gid = 0;
                                this.Size = 0n;
                                this.ATime = 0n;
                                this.ATimeNsec = 0n;
                                this.MTime = 0n;
                                this.MTimeNsec = 0n;
                                this.CTime = 0n;
                                this.CTimeNsec = 0n;
                                this.BirthTime = 0n;
                                this.BirthTimeNsec = 0n;
                                this.Dev = 0n;
                                this.RDev = 0n;
                                this.Ino = 0n;
                                this.UserFlags = 0;
                            }
                            static $h = 325010;
                            static $z = 116;
                            static $f = 0b10100010000001010000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":390546,"n":"Flags","d":325010,"h":4295292306,"f":8},{"t":655361,"n":"Mode","d":325010,"h":8590259602,"f":8},{"t":720897,"n":"Uid","d":325010,"h":12885226898,"f":8},{"t":720897,"n":"Gid","d":325010,"h":17180194194,"f":8},{"t":917505,"n":"Size","d":325010,"h":21475161490,"f":8},{"t":917505,"n":"ATime","d":325010,"h":25770128786,"f":8},{"t":917505,"n":"ATimeNsec","d":325010,"h":30065096082,"f":8},{"t":917505,"n":"MTime","d":325010,"h":34360063378,"f":8},{"t":917505,"n":"MTimeNsec","d":325010,"h":38655030674,"f":8},{"t":917505,"n":"CTime","d":325010,"h":42949997970,"f":8},{"t":917505,"n":"CTimeNsec","d":325010,"h":47244965266,"f":8},{"t":917505,"n":"BirthTime","d":325010,"h":51539932562,"f":8},{"t":917505,"n":"BirthTimeNsec","d":325010,"h":55834899858,"f":8},{"t":917505,"n":"Dev","d":325010,"h":60129867154,"f":8},{"t":917505,"n":"RDev","d":325010,"h":64424834450,"f":8},{"t":917505,"n":"Ino","d":325010,"h":68719801746,"f":8},{"t":720897,"n":"UserFlags","d":325010,"h":73014769042,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":325010,"h":77309736338,"f":1}],"d":259474,"h":325010,"a":[{"t":109903873,"c":4404871169,"a":[{"v":0,"t":105381889}]}]}; }
                            static get $b() { return $.$spc.System.ValueType; }
                            static get $fullName() { return `Interop.Sys.FileStatus`; }
                        }, $cls, ($v) => $cls.$_FileStatus = $v);
                    }
                    static $_FileTypes;
                    static get FileTypes()
                    {
                        let $cls = $.$sic.Interop.Sys;
                        return $cls.$_FileTypes ??= $asm.$ncls("$sic.Interop.Sys.FileTypes", ($self) => class FileTypes
                        {
                            /*int*/ static S_IFMT = 61440;
                            /*int*/ static S_IFIFO = 4096;
                            /*int*/ static S_IFCHR = 8192;
                            /*int*/ static S_IFDIR = 16384;
                            /*int*/ static S_IFBLK = 24576;
                            /*int*/ static S_IFREG = 32768;
                            /*int*/ static S_IFLNK = 40960;
                            /*int*/ static S_IFSOCK = 49152;
                            static $h = 456082;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"S_IFMT","d":456082,"h":4295423378,"f":40},{"t":655361,"n":"S_IFIFO","d":456082,"h":8590390674,"f":40},{"t":655361,"n":"S_IFCHR","d":456082,"h":12885357970,"f":40},{"t":655361,"n":"S_IFDIR","d":456082,"h":17180325266,"f":40},{"t":655361,"n":"S_IFBLK","d":456082,"h":21475292562,"f":40},{"t":655361,"n":"S_IFREG","d":456082,"h":25770259858,"f":40},{"t":655361,"n":"S_IFLNK","d":456082,"h":30065227154,"f":40},{"t":655361,"n":"S_IFSOCK","d":456082,"h":34360194450,"f":40}],"d":259474,"h":456082}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `Interop.Sys.FileTypes`; }
                        }, $cls, ($v) => $cls.$_FileTypes = $v);
                    }
                    static $_FileStatusFlags;
                    static get FileStatusFlags()
                    {
                        let $cls = $.$sic.Interop.Sys;
                        return $cls.$_FileStatusFlags ??= $asm.$nstr("$sic.Interop.Sys.FileStatusFlags", ($self) => class FileStatusFlags extends $.$spc.System.Enum
                        {
                            static None = 0;
                            static HasBirthTime = 1;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "None": 0n,
                                    "HasBirthTime": 1n
                                };
                            }
                            static $h = 390546;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":390546,"n":"None","d":390546,"h":4295357842,"f":33},{"t":390546,"n":"HasBirthTime","d":390546,"h":8590325138,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":390546,"h":12885292434,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":259474,"h":390546,"a":[{"t":47710209,"c":4342677505}]}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.FileStatusFlags`; }
                        }, $cls, ($v) => $cls.$_FileStatusFlags = $v);
                    }
                    static $h = 259474;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"path","p":1310721},{"n":"name","p":521618}],"n":"PathConf","d":259474,"h":8590194066,"f":34,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_PathConf","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109576193},{"n":"output","p":325010,"f":2}],"n":"FStat","d":259474,"h":25770063250,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FStat","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"path","p":1310721},{"n":"output","p":325010,"f":2}],"n":"Stat","d":259474,"h":30065030546,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Stat","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"path","p":1310721},{"n":"output","p":325010,"f":2}],"n":"LStat","d":259474,"h":34359997842,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_LStat","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]}],"j":[521618,325010,456082,390546],"d":128402,"h":259474}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Sys`; }
                }, $cls, ($v) => $cls.$_Sys = $v);
            }
            static $_ZLib;
            static get ZLib()
            {
                let $cls = $.$sic.Interop;
                return $cls.$_ZLib ??= $asm.$ncls("$sic.Interop.ZLib", ($self) => class ZLib
                {
                    static /*ZLibNative.ErrorCode */ DeflateInit2_(/*ZLibNative.ZStream**/ stream, /*ZLibNative.CompressionLevel*/ level, /*ZLibNative.CompressionMethod*/ method, /*int*/ windowBits, /*int*/ memLevel, /*ZLibNative.CompressionStrategy*/ strategy)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*ZLibNative.ErrorCode */ Deflate(/*ZLibNative.ZStream**/ stream, /*ZLibNative.FlushCode*/ flush)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*ZLibNative.ErrorCode */ DeflateEnd(/*ZLibNative.ZStream**/ stream)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*ZLibNative.ErrorCode */ InflateInit2_(/*ZLibNative.ZStream**/ stream, /*int*/ windowBits)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*ZLibNative.ErrorCode */ InflateReset2_(/*ZLibNative.ZStream**/ stream, /*int*/ windowBits)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*ZLibNative.ErrorCode */ Inflate(/*ZLibNative.ZStream**/ stream, /*ZLibNative.FlushCode*/ flush)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*ZLibNative.ErrorCode */ InflateEnd(/*ZLibNative.ZStream**/ stream)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*uint */ crc32(/*uint*/ crc, /*byte**/ buffer, /*int*/ len)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static $h = 587154;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":4978066,"p":[{"n":"stream","p":0},{"n":"level","p":4781458},{"n":"method","p":4846994},{"n":"windowBits","p":655361},{"n":"memLevel","p":655361},{"n":"strategy","p":4912530}],"n":"DeflateInit2_","d":587154,"h":4295554450,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_DeflateInit2_","t":1310721}]}]},{"r":4978066,"p":[{"n":"stream","p":0},{"n":"flush","p":5043602}],"n":"Deflate","d":587154,"h":8590521746,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_Deflate","t":1310721}]}]},{"r":4978066,"p":[{"n":"stream","p":0}],"n":"DeflateEnd","d":587154,"h":12885489042,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_DeflateEnd","t":1310721}]}]},{"r":4978066,"p":[{"n":"stream","p":0},{"n":"windowBits","p":655361}],"n":"InflateInit2_","d":587154,"h":17180456338,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_InflateInit2_","t":1310721}]}]},{"r":4978066,"p":[{"n":"stream","p":0},{"n":"windowBits","p":655361}],"n":"InflateReset2_","d":587154,"h":21475423634,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_InflateReset2_","t":1310721}]}]},{"r":4978066,"p":[{"n":"stream","p":0},{"n":"flush","p":5043602}],"n":"Inflate","d":587154,"h":25770390930,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_Inflate","t":1310721}]}]},{"r":4978066,"p":[{"n":"stream","p":0}],"n":"InflateEnd","d":587154,"h":30065358226,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_InflateEnd","t":1310721}]}]},{"r":720897,"p":[{"n":"crc","p":720897},{"n":"buffer","p":0},{"n":"len","p":655361}],"n":"crc32","d":587154,"h":34360325522,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_Crc32","t":1310721}]}]}],"d":128402,"h":587154}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.ZLib`; }
                }, $cls, ($v) => $cls.$_ZLib = $v);
            }
            static $_Libraries;
            static get Libraries()
            {
                let $cls = $.$sic.Interop;
                return $cls.$_Libraries ??= $asm.$ncls("$sic.Interop.Libraries", ($self) => class Libraries
                {
                    /*string*/ static libc = null;
                    /*string*/ static SystemNative = null;
                    /*string*/ static NetSecurityNative = null;
                    /*string*/ static CryptoNative = null;
                    /*string*/ static CompressionNative = null;
                    /*string*/ static GlobalizationNative = null;
                    /*string*/ static IOPortsNative = null;
                    /*string*/ static HostPolicy = null;
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.libc = "libc";
                        }
                        {
                            this.SystemNative = "libSystem.Native";
                        }
                        {
                            this.NetSecurityNative = "libSystem.Net.Security.Native";
                        }
                        {
                            this.CryptoNative = "libSystem.Security.Cryptography.Native.OpenSsl";
                        }
                        {
                            this.CompressionNative = "libSystem.IO.Compression.Native";
                        }
                        {
                            this.GlobalizationNative = "libSystem.Globalization.Native";
                        }
                        {
                            this.IOPortsNative = "libSystem.IO.Ports.Native";
                        }
                        {
                            this.HostPolicy = "libhostpolicy";
                        }
                    }
                    static $h = 193938;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"libc","d":193938,"h":4295161234,"f":40},{"t":1310721,"n":"SystemNative","d":193938,"h":8590128530,"f":40},{"t":1310721,"n":"NetSecurityNative","d":193938,"h":12885095826,"f":40},{"t":1310721,"n":"CryptoNative","d":193938,"h":17180063122,"f":40},{"t":1310721,"n":"CompressionNative","d":193938,"h":21475030418,"f":40},{"t":1310721,"n":"GlobalizationNative","d":193938,"h":25769997714,"f":40},{"t":1310721,"n":"IOPortsNative","d":193938,"h":30064965010,"f":40},{"t":1310721,"n":"HostPolicy","d":193938,"h":34359932306,"f":40}],"d":128402,"h":193938}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Libraries`; }
                }, $cls, ($v) => $cls.$_Libraries = $v);
            }
            static $h = 128402;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"j":[259474,587154,193938],"h":128402}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipGenericExtraField", ($self) => class ZipGenericExtraField extends $.$spc.System.Object
        {
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.ZipGenericExtraField;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.ZipGenericExtraField.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static Tag = 2;
                    /*int*/ static Size = 2;
                    static $h = 3601810;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Tag","d":3601810,"h":4298569106,"f":33},{"t":655361,"n":"Size","d":3601810,"h":8593536402,"f":33}],"d":3536274,"h":3601810}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipGenericExtraField.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.ZipGenericExtraField;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.ZipGenericExtraField.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Tag = 0;
                    /*int*/ static Size = 2;
                    /*int*/ static DynamicData = 4;
                    static $h = 3667346;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Tag","d":3667346,"h":4298634642,"f":33},{"t":655361,"n":"Size","d":3667346,"h":8593601938,"f":33},{"t":655361,"n":"DynamicData","d":3667346,"h":12888569234,"f":33}],"d":3536274,"h":3667346}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipGenericExtraField.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            /*Task *//*async*/  WriteBlockAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let extraFieldHeader = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [4/*SizeOfHeader*/], null);
                    this.WriteBlockCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(extraFieldHeader));
                    await stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(extraFieldHeader), cancellationToken).ConfigureAwait(false);
                    await stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(this.Data), cancellationToken).ConfigureAwait(false);
                });
            }
            static /*Task *//*async*/  WriteAllBlocksAsync(/*List<ZipGenericExtraField>?*/ fields, /*ReadOnlyMemory<byte>*/ trailingExtraFieldData, /*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (fields !== null)
                    {
                        var $en4 = fields.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var field = $en4.Current;
                            {
                                await field.WriteBlockAsync(stream, cancellationToken).ConfigureAwait(false);
                            }
                        }
                    }
                    if (!trailingExtraFieldData.IsEmpty)
                    {
                        await stream.WriteAsync$2(trailingExtraFieldData, cancellationToken).ConfigureAwait(false);
                    }
                });
            }
            /*int*/ static SizeOfHeader = 4;
            /*ushort*/ _tag = 0;
            /*ushort*/ _size = 0;
            /*byte[]?*/ _data = null;
            /*ushort */ get Tag()
            {
                return this._tag;
            }
            /*ushort */ get Size()
            {
                return this._size;
            }
            /*byte[] */ get Data()
            {
                return this._data ??= $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [  ], null, null);
            }
            /*void */ WriteBlock(/*Stream*/ stream)
            {
                /*Span<byte>*/ let extraFieldHeader = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 4/*SizeOfHeader*/, null);
                this.WriteBlockCore(extraFieldHeader);
                stream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(extraFieldHeader));
                stream.Write$1($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this.Data));
            }
            /*void */ WriteBlockCore(/*Span<byte>*/ extraFieldHeader)
            {
                let $t1 = extraFieldHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t1.Slice$1(0/*FieldLocations.Tag*/, $t1.Length - 0/*FieldLocations.Tag*/), this._tag);
                let $t2 = extraFieldHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t2.Slice$1(2/*FieldLocations.Size*/, $t2.Length - 2/*FieldLocations.Size*/), this._size);
            }
            static /*bool */ TryReadBlock(/*ReadOnlySpan<byte>*/ bytes, /*out int*/ bytesConsumed, /*out ZipGenericExtraField*/ field)
            {
                field.$v = new $.$sic.System.IO.Compression.ZipGenericExtraField().$ctor$1();
                bytesConsumed.$v = 0;
                if (bytes.Length < 4/*SizeOfHeader*/)
                {
                    return false;
                }
                let $t1 = bytes;
                field.$v._tag = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t1.Slice$1(0/*FieldLocations.Tag*/, $t1.Length - 0/*FieldLocations.Tag*/));
                let $t2 = bytes;
                field.$v._size = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t2.Slice$1(2/*FieldLocations.Size*/, $t2.Length - 2/*FieldLocations.Size*/));
                if ((((bytes.Length - 4/*SizeOfHeader*/) | 0)) < field.$v._size)
                {
                    return false;
                }
                field.$v._data = bytes.Slice$1(4/*FieldLocations.DynamicData*/, field.$v._size).ToArray();
                bytesConsumed.$v = ((field.$v.Size + 4/*SizeOfHeader*/) | 0);
                return true;
            }
            static /*List<ZipGenericExtraField> */ ParseExtraField(/*ReadOnlySpan<byte>*/ extraFieldData, /*out ReadOnlySpan<byte>*/ trailingExtraFieldData)
            {
                /*List<ZipGenericExtraField>*/ let extraFields = new ($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField))().$ctor$1();
                /*int*/ let totalBytesConsumed = 0;
                let $t1 = extraFieldData;
                /*int*/ let currBytesConsumed;
                /*ZipGenericExtraField*/ let field;
                while($.$sic.System.IO.Compression.ZipGenericExtraField.TryReadBlock($t1.Slice$1(totalBytesConsumed, $t1.Length - totalBytesConsumed), $.$ref(() => currBytesConsumed, ($v) => currBytesConsumed = $v, $.$spc.System.Int32), $.$ref(() => field, ($v) => field = $v, $.$sic.System.IO.Compression.ZipGenericExtraField)))
                {
                    totalBytesConsumed += currBytesConsumed;
                    extraFields.Add(field);
                }
                let $t4 = extraFieldData;
                trailingExtraFieldData.$v = $t4.Slice$1(totalBytesConsumed, $t4.Length - totalBytesConsumed);
                return extraFields;
            }
            static /*int */ TotalSize(/*List<ZipGenericExtraField>?*/ fields, /*int*/ trailingDataLength)
            {
                /*int*/ let size = trailingDataLength;
                if (fields !== null)
                {
                    var $en3 = fields.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var field = $en3.Current;
                        {
                            size += ((field.Size + 4/*SizeOfHeader*/) | 0);
                        }
                    }
                }
                return size;
            }
            static /*void */ WriteAllBlocks(/*List<ZipGenericExtraField>?*/ fields, /*ReadOnlySpan<byte>*/ trailingExtraFieldData, /*Stream*/ stream)
            {
                if (fields !== null)
                {
                    var $en3 = fields.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var field = $en3.Current;
                        {
                            field.WriteBlock(stream);
                        }
                    }
                }
                if (!trailingExtraFieldData.IsEmpty)
                {
                    stream.Write$1(trailingExtraFieldData);
                }
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 3536274;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":589825,"g":{"r":0,"d":0,"h":42953209234,"f":1},"n":"Tag","d":3536274,"h":38658241938,"f":1},{"p":589825,"g":{"r":0,"d":0,"h":51543143826,"f":1},"n":"Size","d":3536274,"h":47248176530,"f":1},{"p":0,"g":{"r":0,"d":0,"h":60133078418,"f":1},"n":"Data","d":3536274,"h":55838111122,"f":1}],"m":[{"r":133300225,"p":[{"n":"stream","p":62193665},{"n":"cancellationToken","p":125960193}],"n":"WriteBlockAsync","d":3536274,"h":12888438162,"f":4097},{"r":133300225,"p":[{"n":"fields","p":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h},{"n":"trailingExtraFieldData","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"stream","p":62193665},{"n":"cancellationToken","p":125960193}],"n":"WriteAllBlocksAsync","d":3536274,"h":17183405458,"f":4129},{"r":65537,"p":[{"n":"stream","p":62193665}],"n":"WriteBlock","d":3536274,"h":64428045714,"f":1},{"r":65537,"p":[{"n":"extraFieldHeader","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"WriteBlockCore","d":3536274,"h":68723013010,"f":2},{"r":262145,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"field","p":3536274,"f":2}],"n":"TryReadBlock","d":3536274,"h":73017980306,"f":33},{"r":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h,"p":[{"n":"extraFieldData","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"trailingExtraFieldData","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"f":2}],"n":"ParseExtraField","d":3536274,"h":77312947602,"f":33},{"r":655361,"p":[{"n":"fields","p":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h},{"n":"trailingDataLength","p":655361}],"n":"TotalSize","d":3536274,"h":81607914898,"f":33},{"r":65537,"p":[{"n":"fields","p":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h},{"n":"trailingExtraFieldData","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"stream","p":62193665}],"n":"WriteAllBlocks","d":3536274,"h":85902882194,"f":33}],"l":[{"t":655361,"n":"SizeOfHeader","d":3536274,"h":21478372754,"f":34},{"t":589825,"n":"_tag","d":3536274,"h":25773340050,"f":2},{"t":589825,"n":"_size","d":3536274,"h":30068307346,"f":2},{"t":0,"n":"_data","d":3536274,"h":34363274642,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":3536274,"h":90197849490,"f":1}],"j":[3601810,3667346],"h":3536274}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.ZipGenericExtraField`; }
        });
        
        $asm.$cls("$sic.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sic.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.IO.Compression", $.$sic.System.SR.$type.Assembly);
                    $.$sic.System.SR.s_resourceManager = temp;
                }
                return $.$sic.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sic.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sic.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentOutOfRange_Enum()
            {
                return "Enum value was out of legal range.";
            }
            static /*string */ get CannotReadFromDeflateStream()
            {
                return "Reading from the compression stream is not supported.";
            }
            static /*string */ get CannotWriteToDeflateStream()
            {
                return "Writing to the compression stream is not supported.";
            }
            static /*string */ get GenericInvalidData()
            {
                return "Found invalid data while decoding.";
            }
            static /*string */ get InvalidBeginCall()
            {
                return "Only one asynchronous reader or writer is allowed time at one time.";
            }
            static /*string */ get InvalidBlockLength()
            {
                return "Block length does not match with its complement.";
            }
            static /*string */ get InvalidHuffmanData()
            {
                return "Failed to construct a huffman tree using the length array. The stream might be corrupted.";
            }
            static /*string */ get NotSupported()
            {
                return "This operation is not supported.";
            }
            static /*string */ get NotSupported_UnreadableStream()
            {
                return "Stream does not support reading.";
            }
            static /*string */ get NotSupported_UnwritableStream()
            {
                return "Stream does not support writing.";
            }
            static /*string */ get UnknownBlockType()
            {
                return "Unknown block type. Stream might be corrupted.";
            }
            static /*string */ get UnknownState()
            {
                return "Decoder is in some unknown state. This might be caused by corrupted data.";
            }
            static /*string */ get ZLibErrorDLLLoadError()
            {
                return "The underlying compression routine could not be loaded correctly.";
            }
            static /*string */ get ZLibErrorInconsistentStream()
            {
                return "The stream state of the underlying compression routine is inconsistent.";
            }
            static /*string */ get ZLibErrorIncorrectInitParameters()
            {
                return "The underlying compression routine received incorrect initialization parameters.";
            }
            static /*string */ get ZLibErrorNotEnoughMemory()
            {
                return "The underlying compression routine could not reserve sufficient memory.";
            }
            static /*string */ get ZLibErrorVersionMismatch()
            {
                return "The version of the underlying compression routine does not match expected version.";
            }
            static /*string */ get ZLibErrorUnexpected()
            {
                return "The underlying compression routine returned an unexpected error code.";
            }
            static /*string */ get CDCorrupt()
            {
                return "Central Directory corrupt.";
            }
            static /*string */ get CentralDirectoryInvalid()
            {
                return "Central Directory is invalid.";
            }
            static /*string */ get CreateInReadMode()
            {
                return "Cannot create entries on an archive opened in read mode.";
            }
            static /*string */ get CreateModeCapabilities()
            {
                return "Cannot use create mode on a non-writable stream.";
            }
            static /*string */ get CreateModeCreateEntryWhileOpen()
            {
                return "Entries cannot be created while previously created entries are still open.";
            }
            static /*string */ get CreateModeWriteOnceAndOneEntryAtATime()
            {
                return "Entries in create mode may only be written to once, and only one entry may be held open at a time.";
            }
            static /*string */ get DateTimeOutOfRange()
            {
                return "The DateTimeOffset specified cannot be converted into a Zip file timestamp.";
            }
            static /*string */ get DeletedEntry()
            {
                return "Cannot modify deleted entry.";
            }
            static /*string */ get DeleteOnlyInUpdate()
            {
                return "Delete can only be used when the archive is in Update mode.";
            }
            static /*string */ get DeleteOpenEntry()
            {
                return "Cannot delete an entry currently open for writing.";
            }
            static /*string */ get EntriesInCreateMode()
            {
                return "Cannot access entries in Create mode.";
            }
            static /*string */ get EntryNameAndCommentEncodingNotSupported()
            {
                return "The specified encoding is not supported for entry names and comments.";
            }
            static /*string */ get EntryNamesTooLong()
            {
                return "Entry names cannot require more than 2^16 bits.";
            }
            static /*string */ get EntryTooLarge()
            {
                return "Entries larger than 4GB are not supported in Update mode.";
            }
            static /*string */ get EOCDNotFound()
            {
                return "End of Central Directory record could not be found.";
            }
            static /*string */ get FieldTooBigCompressedSize()
            {
                return "Compressed Size cannot be held in an Int64.";
            }
            static /*string */ get FieldTooBigLocalHeaderOffset()
            {
                return "Local Header Offset cannot be held in an Int64.";
            }
            static /*string */ get FieldTooBigNumEntries()
            {
                return "Number of Entries cannot be held in an Int64.";
            }
            static /*string */ get FieldTooBigOffsetToCD()
            {
                return "Offset to Central Directory cannot be held in an Int64.";
            }
            static /*string */ get FieldTooBigOffsetToZip64EOCD()
            {
                return "Offset to Zip64 End Of Central Directory record cannot be held in an Int64.";
            }
            static /*string */ get FieldTooBigUncompressedSize()
            {
                return "Uncompressed Size cannot be held in an Int64.";
            }
            static /*string */ get FrozenAfterWrite()
            {
                return "Cannot modify entry in Create mode after entry has been opened for writing.";
            }
            static /*string */ get HiddenStreamName()
            {
                return "A stream from ZipArchiveEntry has been disposed.";
            }
            static /*string */ get LengthAfterWrite()
            {
                return "Length properties are unavailable once an entry has been opened for writing.";
            }
            static /*string */ get LocalFileHeaderCorrupt()
            {
                return "A local file header is corrupt.";
            }
            static /*string */ get NumEntriesWrong()
            {
                return "Number of entries expected in End Of Central Directory does not correspond to number of entries in Central Directory.";
            }
            static /*string */ get ReadingNotSupported()
            {
                return "This stream from ZipArchiveEntry does not support reading.";
            }
            static /*string */ get ReadModeCapabilities()
            {
                return "Cannot use read mode on a non-readable stream.";
            }
            static /*string */ get ReadOnlyArchive()
            {
                return "Cannot modify read-only archive.";
            }
            static /*string */ get SeekingNotSupported()
            {
                return "This stream from ZipArchiveEntry does not support seeking.";
            }
            static /*string */ get SetLengthRequiresSeekingAndWriting()
            {
                return "SetLength requires a stream that supports seeking and writing.";
            }
            static /*string */ get SplitSpanned()
            {
                return "Split or spanned archives are not supported.";
            }
            static /*string */ get TruncatedData()
            {
                return "Found truncated data while decoding.";
            }
            static /*string */ get UnexpectedEndOfStream()
            {
                return "Zip file corrupt: unexpected end of stream reached.";
            }
            static /*string */ get UnsupportedCompression()
            {
                return "The archive entry was compressed using an unsupported compression method.";
            }
            static /*string */ get UnsupportedCompressionMethod()
            {
                return "The archive entry was compressed using {0} and is not supported.";
            }
            static /*string */ FormatUnsupportedCompressionMethod(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The archive entry was compressed using {0} and is not supported.", arg1);
            }
            static /*string */ get UpdateModeCapabilities()
            {
                return "Update mode requires a stream with read, write, and seek capabilities.";
            }
            static /*string */ get UpdateModeOneStream()
            {
                return "Entries cannot be opened multiple times in Update mode.";
            }
            static /*string */ get WritingNotSupported()
            {
                return "This stream from ZipArchiveEntry does not support writing.";
            }
            static /*string */ get Zip64EOCDNotWhereExpected()
            {
                return "Zip 64 End of Central Directory Record not where indicated.";
            }
            static /*string */ get PlatformNotSupported_Compression()
            {
                return "System.IO.Compression is not supported on this platform.";
            }
            static /*string */ get InvalidOffsetToZip64EOCD()
            {
                return "Invalid offset to the Zip64 End of Central Directory record.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sic.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sic.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sic.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sic.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sic.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sic.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 5436818;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":5436818}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.Zip64ExtraField", ($self) => class Zip64ExtraField extends $.$spc.System.Object
        {
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.Zip64ExtraField;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.Zip64ExtraField.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static UncompressedSize = 8;
                    /*int*/ static CompressedSize = 8;
                    /*int*/ static LocalHeaderOffset = 8;
                    /*int*/ static StartDiskNumber = 4;
                    static $h = 2422162;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"UncompressedSize","d":2422162,"h":4297389458,"f":33},{"t":655361,"n":"CompressedSize","d":2422162,"h":8592356754,"f":33},{"t":655361,"n":"LocalHeaderOffset","d":2422162,"h":12887324050,"f":33},{"t":655361,"n":"StartDiskNumber","d":2422162,"h":17182291346,"f":33}],"d":2356626,"h":2422162}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.Zip64ExtraField.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.Zip64ExtraField;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.Zip64ExtraField.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Tag = 0;
                    /*int*/ static Size = 2;
                    /*int*/ static UncompressedSize = 4;
                    /*int*/ static CompressedSize = 12;
                    /*int*/ static LocalHeaderOffset = 20;
                    /*int*/ static StartDiskNumber = 28;
                    static $h = 2487698;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Tag","d":2487698,"h":4297454994,"f":33},{"t":655361,"n":"Size","d":2487698,"h":8592422290,"f":33},{"t":655361,"n":"UncompressedSize","d":2487698,"h":12887389586,"f":33},{"t":655361,"n":"CompressedSize","d":2487698,"h":17182356882,"f":33},{"t":655361,"n":"LocalHeaderOffset","d":2487698,"h":21477324178,"f":33},{"t":655361,"n":"StartDiskNumber","d":2487698,"h":25772291474,"f":33}],"d":2356626,"h":2487698}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.Zip64ExtraField.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            /*ValueTask */ WriteBlockAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                cancellationToken.ThrowIfCancellationRequested();
                /*byte[]*/ let extraFieldData = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [this.TotalSize], null);
                this.WriteBlockCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(extraFieldData));
                return stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(extraFieldData), cancellationToken);
            }
            /*int*/ static OffsetToFirstField = 4;
            /*ushort*/ static TagConstant = 1;
            /*ushort*/ _size = 0;
            /*long?*/ _uncompressedSize = null;
            /*long?*/ _compressedSize = null;
            /*long?*/ _localHeaderOffset = null;
            /*uint?*/ _startDiskNumber = null;
            /*ushort */ get TotalSize()
            {
                return $.$cast((((this._size + 4) | 0)), $.$spc.System.UInt16);
            }
            /*long? */ get UncompressedSize()
            {
                return this._uncompressedSize;
            }
            /*long? */ set UncompressedSize(value)
            {
                this._uncompressedSize = value;
                this.UpdateSize();
            }
            /*long? */ get CompressedSize()
            {
                return this._compressedSize;
            }
            /*long? */ set CompressedSize(value)
            {
                this._compressedSize = value;
                this.UpdateSize();
            }
            /*long? */ get LocalHeaderOffset()
            {
                return this._localHeaderOffset;
            }
            /*long? */ set LocalHeaderOffset(value)
            {
                this._localHeaderOffset = value;
                this.UpdateSize();
            }
            /*uint? */ get StartDiskNumber()
            {
                return this._startDiskNumber;
            }
            /*void */ UpdateSize()
            {
                this._size = 0;
                if (this._uncompressedSize !== null)
                {
                    this._size += 8/*FieldLengths.UncompressedSize*/;
                }
                if (this._compressedSize !== null)
                {
                    this._size += 8/*FieldLengths.CompressedSize*/;
                }
                if (this._localHeaderOffset !== null)
                {
                    this._size += 8/*FieldLengths.LocalHeaderOffset*/;
                }
                if (this._startDiskNumber !== null)
                {
                    this._size += 4/*FieldLengths.StartDiskNumber*/;
                }
            }
            static /*Zip64ExtraField */ GetJustZip64Block(/*ReadOnlySpan<byte>*/ extraFieldData, /*bool*/ readUncompressedSize, /*bool*/ readCompressedSize, /*bool*/ readLocalHeaderOffset, /*bool*/ readStartDiskNumber)
            {
                /*Zip64ExtraField*/ let zip64Field;
                /*int*/ let totalBytesConsumed = 0;
                /*int*/ let currBytesConsumed;
                /*ZipGenericExtraField*/ let currentExtraField;
                while($.$sic.System.IO.Compression.ZipGenericExtraField.TryReadBlock(extraFieldData.Slice(totalBytesConsumed), $.$ref(() => currBytesConsumed, ($v) => currBytesConsumed = $v, $.$spc.System.Int32), $.$ref(() => currentExtraField, ($v) => currentExtraField = $v, $.$sic.System.IO.Compression.ZipGenericExtraField)))
                {
                    totalBytesConsumed += currBytesConsumed;
                    if ($.$sic.System.IO.Compression.Zip64ExtraField.TryGetZip64BlockFromGenericExtraField(currentExtraField, readUncompressedSize, readCompressedSize, readLocalHeaderOffset, readStartDiskNumber, $.$ref(() => zip64Field, ($v) => zip64Field = $v, $.$sic.System.IO.Compression.Zip64ExtraField)))
                    {
                        return zip64Field;
                    }
                }
                zip64Field = (() =>
                {
                    //new $.$sic.System.IO.Compression.Zip64ExtraField()
                    const $t3 = $.$sic.System.IO.Compression.Zip64ExtraField;
                    const $i3 = new $t3();
                    $i3._compressedSize = null;
                    $i3._uncompressedSize = null;
                    $i3._localHeaderOffset = null;
                    $i3._startDiskNumber = null;
                    return $i3;
                })();
                return zip64Field;
            }
            static /*bool */ TryGetZip64BlockFromGenericExtraField(/*ZipGenericExtraField*/ extraField, /*bool*/ readUncompressedSize, /*bool*/ readCompressedSize, /*bool*/ readLocalHeaderOffset, /*bool*/ readStartDiskNumber, /*out Zip64ExtraField*/ zip64Block)
            {
                /*int*/ let MaximumExtraFieldLength = ((((((8/*FieldLengths.UncompressedSize*/ + 8/*FieldLengths.CompressedSize*/) | 0) + 8/*FieldLengths.LocalHeaderOffset*/) | 0) + 4/*FieldLengths.StartDiskNumber*/) | 0);
                zip64Block.$v = (() =>
                {
                    //new $.$sic.System.IO.Compression.Zip64ExtraField()
                    const $t1 = $.$sic.System.IO.Compression.Zip64ExtraField;
                    const $i1 = new $t1();
                    $i1._compressedSize = null;
                    $i1._uncompressedSize = null;
                    $i1._localHeaderOffset = null;
                    $i1._startDiskNumber = null;
                    return $i1;
                })();
                if (extraField.Tag !== 1/*TagConstant*/)
                {
                    return false;
                }
                zip64Block.$v._size = extraField.Size;
                /*ReadOnlySpan<byte>*/ let data = $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(extraField.Data);
                if (data.Length < 8/*FieldLengths.UncompressedSize*/)
                {
                    return true;
                }
                /*bool*/ let readAllFields = extraField.Size >= MaximumExtraFieldLength;
                if (readUncompressedSize)
                {
                    zip64Block.$v._uncompressedSize = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadInt64LittleEndian(data);
                    data = data.Slice(8/*FieldLengths.UncompressedSize*/);
                }
                else if (readAllFields)
                {
                    data = data.Slice(8/*FieldLengths.UncompressedSize*/);
                }
                if (data.Length < 8/*FieldLengths.CompressedSize*/)
                {
                    return true;
                }
                if (readCompressedSize)
                {
                    zip64Block.$v._compressedSize = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadInt64LittleEndian(data);
                    data = data.Slice(8/*FieldLengths.CompressedSize*/);
                }
                else if (readAllFields)
                {
                    data = data.Slice(8/*FieldLengths.CompressedSize*/);
                }
                if (data.Length < 8/*FieldLengths.LocalHeaderOffset*/)
                {
                    return true;
                }
                if (readLocalHeaderOffset)
                {
                    zip64Block.$v._localHeaderOffset = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadInt64LittleEndian(data);
                    data = data.Slice(8/*FieldLengths.LocalHeaderOffset*/);
                }
                else if (readAllFields)
                {
                    data = data.Slice(8/*FieldLengths.LocalHeaderOffset*/);
                }
                if (data.Length < 4/*FieldLengths.StartDiskNumber*/)
                {
                    return true;
                }
                if (readStartDiskNumber)
                {
                    zip64Block.$v._startDiskNumber = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(data);
                }
                if (zip64Block.$v._uncompressedSize < 0)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigUncompressedSize);
                }
                if (zip64Block.$v._compressedSize < 0)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigCompressedSize);
                }
                if (zip64Block.$v._localHeaderOffset < 0)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigLocalHeaderOffset);
                }
                return true;
            }
            static /*Zip64ExtraField */ GetAndRemoveZip64Block(/*List<ZipGenericExtraField>*/ extraFields, /*bool*/ readUncompressedSize, /*bool*/ readCompressedSize, /*bool*/ readLocalHeaderOffset, /*bool*/ readStartDiskNumber)
            {
                /*Zip64ExtraField*/ let zip64Field = (() =>
                {
                    //new $.$sic.System.IO.Compression.Zip64ExtraField()
                    const $t1 = $.$sic.System.IO.Compression.Zip64ExtraField;
                    const $i1 = new $t1();
                    $i1._compressedSize = null;
                    $i1._uncompressedSize = null;
                    $i1._localHeaderOffset = null;
                    $i1._startDiskNumber = null;
                    return $i1;
                })();
                /*bool*/ let zip64FieldFound = false;
                extraFields.RemoveAll(new ($.$spc.System.Predicate$$($.$sic.System.IO.Compression.ZipGenericExtraField))().$ctor(this,  (/*ef*/ ef) =>
                {
                    if (ef.Tag === 1/*TagConstant*/)
                    {
                        if (!zip64FieldFound)
                        {
                            if ($.$sic.System.IO.Compression.Zip64ExtraField.TryGetZip64BlockFromGenericExtraField(ef, readUncompressedSize, readCompressedSize, readLocalHeaderOffset, readStartDiskNumber, $.$ref(() => zip64Field, ($v) => zip64Field = $v, $.$sic.System.IO.Compression.Zip64ExtraField)))
                            {
                                zip64FieldFound = true;
                            }
                        }
                        return true;
                    }
                    return false;
                }, {"r":262145,"p":[{"n":"ef","p":3536274}],"n":"","d":2356626,"h":0,"f":1048578}));
                return zip64Field;
            }
            static /*void */ RemoveZip64Blocks(/*List<ZipGenericExtraField>*/ extraFields)
            {
                extraFields.RemoveAll(new ($.$spc.System.Predicate$$($.$sic.System.IO.Compression.ZipGenericExtraField))().$ctor(this,  (/*field*/ field) =>
                {
                    return field.Tag === 1/*TagConstant*/;
                }, {"r":262145,"p":[{"n":"field","p":3536274}],"n":"","d":2356626,"h":0,"f":1048578}));
            }
            /*void */ WriteBlockCore(/*Span<byte>*/ extraFieldData)
            {
                /*int*/ let startOffset = 4/*ZipGenericExtraField.FieldLocations.DynamicData*/;
                let $t1 = extraFieldData;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t1.Slice$1(0/*FieldLocations.Tag*/, $t1.Length - 0/*FieldLocations.Tag*/), 1/*TagConstant*/);
                let $t2 = extraFieldData;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t2.Slice$1(2/*FieldLocations.Size*/, $t2.Length - 2/*FieldLocations.Size*/), this._size);
                if (this._uncompressedSize !== null)
                {
                    let $t3 = extraFieldData;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t3.Slice$1(startOffset, $t3.Length - startOffset), $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(this._uncompressedSize));
                    startOffset += 8/*FieldLengths.UncompressedSize*/;
                }
                if (this._compressedSize !== null)
                {
                    let $t3 = extraFieldData;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t3.Slice$1(startOffset, $t3.Length - startOffset), $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(this._compressedSize));
                    startOffset += 8/*FieldLengths.CompressedSize*/;
                }
                if (this._localHeaderOffset !== null)
                {
                    let $t3 = extraFieldData;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t3.Slice$1(startOffset, $t3.Length - startOffset), $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(this._localHeaderOffset));
                    startOffset += 8/*FieldLengths.LocalHeaderOffset*/;
                }
                if (this._startDiskNumber !== null)
                {
                    let $t3 = extraFieldData;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t3.Slice$1(startOffset, $t3.Length - startOffset), $.$spc.System.Nullable$$($.$spc.System.UInt32).Value$get.call(this._startDiskNumber));
                }
            }
            /*void */ WriteBlock(/*Stream*/ stream)
            {
                /*Span<byte>*/ let extraFieldData = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, this.TotalSize, null);
                this.WriteBlockCore(extraFieldData);
                stream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(extraFieldData));
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2356626;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":589825,"g":{"r":0,"d":0,"h":51541964178,"f":1},"n":"TotalSize","d":2356626,"h":47246996882,"f":1},{"p":$.$typeNullable($.$spc.System.Int64).$h,"g":{"r":0,"d":0,"h":60131898770,"f":1},"s":{"r":0,"d":0,"h":64426866066,"f":1},"n":"UncompressedSize","d":2356626,"h":55836931474,"f":1},{"p":$.$typeNullable($.$spc.System.Int64).$h,"g":{"r":0,"d":0,"h":73016800658,"f":1},"s":{"r":0,"d":0,"h":77311767954,"f":1},"n":"CompressedSize","d":2356626,"h":68721833362,"f":1},{"p":$.$typeNullable($.$spc.System.Int64).$h,"g":{"r":0,"d":0,"h":85901702546,"f":1},"s":{"r":0,"d":0,"h":90196669842,"f":1},"n":"LocalHeaderOffset","d":2356626,"h":81606735250,"f":1},{"p":$.$typeNullable($.$spc.System.UInt32).$h,"g":{"r":0,"d":0,"h":98786604434,"f":1},"n":"StartDiskNumber","d":2356626,"h":94491637138,"f":1}],"m":[{"r":136118273,"p":[{"n":"stream","p":62193665},{"n":"cancellationToken","p":125960193}],"n":"WriteBlockAsync","d":2356626,"h":12887258514,"f":1},{"r":65537,"n":"UpdateSize","d":2356626,"h":103081571730,"f":2},{"r":2356626,"p":[{"n":"extraFieldData","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"readUncompressedSize","p":262145},{"n":"readCompressedSize","p":262145},{"n":"readLocalHeaderOffset","p":262145},{"n":"readStartDiskNumber","p":262145}],"n":"GetJustZip64Block","d":2356626,"h":107376539026,"f":33},{"r":262145,"p":[{"n":"extraField","p":3536274},{"n":"readUncompressedSize","p":262145},{"n":"readCompressedSize","p":262145},{"n":"readLocalHeaderOffset","p":262145},{"n":"readStartDiskNumber","p":262145},{"n":"zip64Block","p":2356626,"f":2}],"n":"TryGetZip64BlockFromGenericExtraField","d":2356626,"h":111671506322,"f":34},{"r":2356626,"p":[{"n":"extraFields","p":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h},{"n":"readUncompressedSize","p":262145},{"n":"readCompressedSize","p":262145},{"n":"readLocalHeaderOffset","p":262145},{"n":"readStartDiskNumber","p":262145}],"n":"GetAndRemoveZip64Block","d":2356626,"h":115966473618,"f":33},{"r":65537,"p":[{"n":"extraFields","p":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h}],"n":"RemoveZip64Blocks","d":2356626,"h":120261440914,"f":33},{"r":65537,"p":[{"n":"extraFieldData","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"WriteBlockCore","d":2356626,"h":124556408210,"f":1},{"r":65537,"p":[{"n":"stream","p":62193665}],"n":"WriteBlock","d":2356626,"h":128851375506,"f":1}],"l":[{"t":655361,"n":"OffsetToFirstField","d":2356626,"h":17182225810,"f":33},{"t":589825,"n":"TagConstant","d":2356626,"h":21477193106,"f":34},{"t":589825,"n":"_size","d":2356626,"h":25772160402,"f":2},{"t":$.$typeNullable($.$spc.System.Int64).$h,"n":"_uncompressedSize","d":2356626,"h":30067127698,"f":2},{"t":$.$typeNullable($.$spc.System.Int64).$h,"n":"_compressedSize","d":2356626,"h":34362094994,"f":2},{"t":$.$typeNullable($.$spc.System.Int64).$h,"n":"_localHeaderOffset","d":2356626,"h":38657062290,"f":2},{"t":$.$typeNullable($.$spc.System.UInt32).$h,"n":"_startDiskNumber","d":2356626,"h":42952029586,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":2356626,"h":133146342802,"f":1}],"j":[2422162,2487698],"h":2356626}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.Zip64ExtraField`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator", ($self) => class Zip64EndOfCentralDirectoryLocator extends $.$spc.System.Object
        {
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static Signature = 4;
                    /*int*/ static NumberOfDiskWithZip64EOCD = 4;
                    /*int*/ static OffsetOfZip64EOCD = 8;
                    /*int*/ static TotalNumberOfDisks = 4;
                    static $h = 2028946;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":2028946,"h":4296996242,"f":33},{"t":655361,"n":"NumberOfDiskWithZip64EOCD","d":2028946,"h":8591963538,"f":33},{"t":655361,"n":"OffsetOfZip64EOCD","d":2028946,"h":12886930834,"f":33},{"t":655361,"n":"TotalNumberOfDisks","d":2028946,"h":17181898130,"f":33}],"d":1963410,"h":2028946}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.Zip64EndOfCentralDirectoryLocator.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Signature = 0;
                    /*int*/ static NumberOfDiskWithZip64EOCD = 4;
                    /*int*/ static OffsetOfZip64EOCD = 8;
                    /*int*/ static TotalNumberOfDisks = 16;
                    static $h = 2094482;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":2094482,"h":4297061778,"f":33},{"t":655361,"n":"NumberOfDiskWithZip64EOCD","d":2094482,"h":8592029074,"f":33},{"t":655361,"n":"OffsetOfZip64EOCD","d":2094482,"h":12886996370,"f":33},{"t":655361,"n":"TotalNumberOfDisks","d":2094482,"h":17181963666,"f":33}],"d":1963410,"h":2094482}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.Zip64EndOfCentralDirectoryLocator.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            static /*Task<Zip64EndOfCentralDirectoryLocator> *//*async*/  TryReadBlockAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator), $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [20/*TotalSize*/], null);
                    /*int*/ let bytesRead = await stream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(blockContents), blockContents.length, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    /*Zip64EndOfCentralDirectoryLocator?*/ let zip64EOCDLocator;
                    /*bool*/ let zip64eocdLocatorProper = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.TryReadBlockCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockContents), bytesRead, $.$ref(() => zip64EOCDLocator, ($v) => zip64EOCDLocator = $v, $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator));
                    $.$spc.System.Diagnostics.Debug.Assert$1(zip64eocdLocatorProper && zip64EOCDLocator !== null, "zip64eocdLocatorProper && zip64EOCDLocator != null");
                    return zip64EOCDLocator;
                });
            }
            static /*ValueTask */ WriteBlockAsync(/*Stream*/ stream, /*long*/ zip64EOCDRecordStart, /*CancellationToken*/ cancellationToken)
            {
                cancellationToken.ThrowIfCancellationRequested();
                /*byte[]*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [20/*TotalSize*/], null);
                $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.WriteBlockCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockContents), zip64EOCDRecordStart);
                return stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(blockContents), cancellationToken);
            }
            /*byte[]*/ static SignatureConstantBytes = null;
            /*int*/ static TotalSize = 20;
            /*int*/ static SizeOfBlockWithoutSignature = 16;
            /*uint*/ NumberOfDiskWithZip64EOCD = 0;
            /*ulong*/ OffsetOfZip64EOCD = 0n;
            /*uint*/ TotalNumberOfDisks = 0;
            static /*bool */ TryReadBlockCore(/*Span<byte>*/ blockContents, /*int*/ bytesRead, /*out Zip64EndOfCentralDirectoryLocator?*/ zip64EOCDLocator)
            {
                zip64EOCDLocator.$v = null;
                if (bytesRead < 20/*TotalSize*/ || !$.$spc.System.MemoryExtensions.StartsWith$1($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockContents), $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.SignatureConstantBytes)))
                {
                    return false;
                }
                zip64EOCDLocator.$v = (() =>
                {
                    //new $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator()
                    const $t1 = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator;
                    const $i1 = new $t1();
                    let $t2 = blockContents;
                    $i1.NumberOfDiskWithZip64EOCD = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t2.Slice$1(4/*FieldLocations.NumberOfDiskWithZip64EOCD*/, $t2.Length - 4/*FieldLocations.NumberOfDiskWithZip64EOCD*/)));
                    let $t3 = blockContents;
                    $i1.OffsetOfZip64EOCD = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t3.Slice$1(8/*FieldLocations.OffsetOfZip64EOCD*/, $t3.Length - 8/*FieldLocations.OffsetOfZip64EOCD*/)));
                    let $t4 = blockContents;
                    $i1.TotalNumberOfDisks = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t4.Slice$1(16/*FieldLocations.TotalNumberOfDisks*/, $t4.Length - 16/*FieldLocations.TotalNumberOfDisks*/)));
                    return $i1;
                })();
                return true;
            }
            static /*Zip64EndOfCentralDirectoryLocator */ TryReadBlock(/*Stream*/ stream)
            {
                /*Span<byte>*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 20/*TotalSize*/, null);
                /*int*/ let bytesRead = stream.ReadAtLeast(blockContents, blockContents.Length, false);
                /*Zip64EndOfCentralDirectoryLocator?*/ let zip64EOCDLocator;
                /*bool*/ let zip64eocdLocatorProper = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.TryReadBlockCore(blockContents, bytesRead, $.$ref(() => zip64EOCDLocator, ($v) => zip64EOCDLocator = $v, $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator));
                $.$spc.System.Diagnostics.Debug.Assert$1(zip64eocdLocatorProper && zip64EOCDLocator !== null, "zip64eocdLocatorProper && zip64EOCDLocator != null");
                return zip64EOCDLocator;
            }
            static /*void */ WriteBlockCore(/*Span<byte>*/ blockContents, /*long*/ zip64EOCDRecordStart)
            {
                let $t1 = blockContents;
                $.$spc.System.MemoryExtensions.CopyTo($.$spc.System.Byte, $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.SignatureConstantBytes, $t1.Slice$1(0/*FieldLocations.Signature*/, $t1.Length - 0/*FieldLocations.Signature*/));
                let $t2 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t2.Slice$1(4/*FieldLocations.NumberOfDiskWithZip64EOCD*/, $t2.Length - 4/*FieldLocations.NumberOfDiskWithZip64EOCD*/), 0);
                let $t3 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t3.Slice$1(8/*FieldLocations.OffsetOfZip64EOCD*/, $t3.Length - 8/*FieldLocations.OffsetOfZip64EOCD*/), zip64EOCDRecordStart);
                let $t4 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t4.Slice$1(16/*FieldLocations.TotalNumberOfDisks*/, $t4.Length - 16/*FieldLocations.TotalNumberOfDisks*/), 1);
            }
            static /*void */ WriteBlock(/*Stream*/ stream, /*long*/ zip64EOCDRecordStart)
            {
                /*Span<byte>*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 20/*TotalSize*/, null);
                $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.WriteBlockCore(blockContents, zip64EOCDRecordStart);
                stream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockContents));
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SignatureConstantBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [ 80, 75, 6, 7 ], null, null);
                }
            }
            static $h = 1963410;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator).$h,"p":[{"n":"stream","p":62193665},{"n":"cancellationToken","p":125960193}],"n":"TryReadBlockAsync","d":1963410,"h":12886865298,"f":4129},{"r":136118273,"p":[{"n":"stream","p":62193665},{"n":"zip64EOCDRecordStart","p":917505},{"n":"cancellationToken","p":125960193}],"n":"WriteBlockAsync","d":1963410,"h":17181832594,"f":33},{"r":262145,"p":[{"n":"blockContents","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesRead","p":655361},{"n":"zip64EOCDLocator","p":1963410,"f":2}],"n":"TryReadBlockCore","d":1963410,"h":47246603666,"f":34},{"r":1963410,"p":[{"n":"stream","p":62193665}],"n":"TryReadBlock","d":1963410,"h":51541570962,"f":33},{"r":65537,"p":[{"n":"blockContents","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"zip64EOCDRecordStart","p":917505}],"n":"WriteBlockCore","d":1963410,"h":55836538258,"f":34},{"r":65537,"p":[{"n":"stream","p":62193665},{"n":"zip64EOCDRecordStart","p":917505}],"n":"WriteBlock","d":1963410,"h":60131505554,"f":33}],"l":[{"t":0,"n":"SignatureConstantBytes","d":1963410,"h":21476799890,"f":33},{"t":655361,"n":"TotalSize","d":1963410,"h":25771767186,"f":33},{"t":655361,"n":"SizeOfBlockWithoutSignature","d":1963410,"h":30066734482,"f":33},{"t":720897,"n":"NumberOfDiskWithZip64EOCD","d":1963410,"h":34361701778,"f":1},{"t":983041,"n":"OffsetOfZip64EOCD","d":1963410,"h":38656669074,"f":1},{"t":720897,"n":"TotalNumberOfDisks","d":1963410,"h":42951636370,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1963410,"h":64426472850,"f":1}],"j":[2028946,2094482],"h":1963410}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Zip64EndOfCentralDirectoryLocator`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipHelper", ($self) => class ZipHelper
        {
            static /*Task<bool> *//*async*/  SeekBackwardsToSignatureAsync(/*Stream*/ stream, /*ReadOnlyMemory<byte>*/ signatureToFind, /*int*/ maxBytesToRead, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    $.$spc.System.Diagnostics.Debug.Assert$1(signatureToFind.Length !== 0, "signatureToFind.Length != 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(maxBytesToRead > 0, "maxBytesToRead > 0");
                    /*int*/ let bufferPointer = 0;
                    /*byte[]*/ let buffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(4096/*BackwardsSeekingBufferSize*/);
                    /*Memory<byte>*/ let bufferMemory = $.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, buffer, 0, 4096/*BackwardsSeekingBufferSize*/);
                    try
                    {
                        /*bool*/ let outOfBytes = false;
                        /*bool*/ let signatureFound = false;
                        /*int*/ let totalBytesRead = 0;
                        while(!signatureFound && !outOfBytes && totalBytesRead < maxBytesToRead)
                        {
                            /*int*/ let overlap = totalBytesRead === 0 ? 0 : signatureToFind.Length;
                            if (((((maxBytesToRead - totalBytesRead) | 0) + overlap) | 0) < bufferMemory.Length)
                            {
                                bufferMemory = bufferMemory.Slice$1(0, ((((maxBytesToRead - totalBytesRead) | 0) + overlap) | 0));
                            }
                            /*int*/ let bytesRead = await $.$sic.System.IO.Compression.ZipHelper.SeekBackwardsAndReadAsync(stream, bufferMemory, overlap, cancellationToken).ConfigureAwait$2(false);
                            outOfBytes = bytesRead < bufferMemory.Length;
                            if (bytesRead < bufferMemory.Length)
                            {
                                bufferMemory = bufferMemory.Slice$1(0, bytesRead);
                            }
                            bufferPointer = $.$spc.System.MemoryExtensions.LastIndexOf$4($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(bufferMemory.Span), signatureToFind.Span);
                            $.$spc.System.Diagnostics.Debug.Assert$1(bufferPointer < bufferMemory.Length, "bufferPointer < bufferMemory.Length");
                            totalBytesRead += ((bytesRead - overlap) | 0);
                            if (bufferPointer !== -1)
                            {
                                signatureFound = true;
                                break;
                            }
                        }
                        if (!signatureFound)
                        {
                            return false;
                        }
                        else 
                        {
                            stream.Seek(BigInt(bufferPointer), 1/*SeekOrigin.Current*/);
                            return true;
                        }
                    }
                    finally
                    {
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(buffer, false);
                        }
                    }
                });
            }
            static /*Task<int> *//*async*/  SeekBackwardsAndReadAsync(/*Stream*/ stream, /*Memory<byte>*/ buffer, /*int*/ overlap, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*int*/ let bytesRead;
                    if (stream.Position >= BigInt(buffer.Length))
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(overlap <= buffer.Length, "overlap <= buffer.Length");
                        stream.Seek(BigInt(-(((buffer.Length - overlap) | 0))), 1/*SeekOrigin.Current*/);
                        bytesRead = await stream.ReadAtLeastAsync(buffer, buffer.Length, true, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                        stream.Seek(BigInt(-buffer.Length), 1/*SeekOrigin.Current*/);
                    }
                    else 
                    {
                        /*int*/ let bytesToRead = $.$cast(stream.Position, $.$spc.System.Int32);
                        stream.Seek(0n, 0/*SeekOrigin.Begin*/);
                        bytesRead = await stream.ReadAtLeastAsync(buffer, bytesToRead, true, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                        stream.Seek(0n, 0/*SeekOrigin.Begin*/);
                    }
                    return bytesRead;
                });
            }
            /*uint*/ static Mask32Bit = 4294967295;
            /*ushort*/ static Mask16Bit = 65535;
            /*int*/ static BackwardsSeekingBufferSize = 4096;
            /*int*/ static ValidZipDate_YearMin = 1980;
            /*int*/ static ValidZipDate_YearMax = 2107;
            /*DateTime*/ static s_invalidDateIndicator;
            static /*Encoding */ GetEncoding(/*string*/ text)
            {
                if ($.$spc.System.MemoryExtensions.ContainsAnyExceptInRange$1($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(text), 32, 126))
                {
                    return $.$spc.System.Text.Encoding.UTF8;
                }
                return $.$spc.System.Text.Encoding.ASCII;
            }
            static /*DateTime */ DosTimeToDateTime(/*uint*/ dateTime)
            {
                if (dateTime === 0)
                {
                    return $.$sic.System.IO.Compression.ZipHelper.s_invalidDateIndicator;
                }
                /*int*/ let year = ((1980/*ValidZipDate_YearMin*/ + (dateTime >>> 25)) | 0);
                /*int*/ let month = (((dateTime >>> 21) & 15) | 0);
                /*int*/ let day = (((dateTime >>> 16) & 31) | 0);
                /*int*/ let hour = (((dateTime >>> 11) & 31) | 0);
                /*int*/ let minute = (((dateTime >>> 5) & 63) | 0);
                /*int*/ let second = (((((dateTime & 31) * 2) >>> 0)) | 0);
                try
                {
                    return new $.$spc.System.DateTime().$ctor$14(year, month, day, hour, minute, second, 0);
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.ArgumentOutOfRangeException)
                    {
                        return $.$sic.System.IO.Compression.ZipHelper.s_invalidDateIndicator;
                    }
                    else if ($e instanceof $.$spc.System.ArgumentException)
                    {
                        return $.$sic.System.IO.Compression.ZipHelper.s_invalidDateIndicator;
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            static /*uint */ DateTimeToDosTime(/*DateTime*/ dateTime)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(1980/*ValidZipDate_YearMin*/ <= dateTime.Year && dateTime.Year <= 2107/*ValidZipDate_YearMax*/, "ValidZipDate_YearMin <= dateTime.Year && dateTime.Year <= ValidZipDate_YearMax");
                /*int*/ let ret = ((((dateTime.Year - 1980/*ValidZipDate_YearMin*/) | 0)) & 127);
                ret = (((ret << 4) + dateTime.Month) | 0);
                ret = (((ret << 5) + dateTime.Day) | 0);
                ret = (((ret << 5) + dateTime.Hour) | 0);
                ret = (((ret << 6) + dateTime.Minute) | 0);
                ret = (((ret << 5) + ($.trunc(dateTime.Second / 2))) | 0);
                return (ret >>> 0);
            }
            static /*bool */ SeekBackwardsToSignature(/*Stream*/ stream, /*ReadOnlySpan<byte>*/ signatureToFind, /*int*/ maxBytesToRead)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(signatureToFind.Length !== 0, "signatureToFind.Length != 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(maxBytesToRead > 0, "maxBytesToRead > 0");
                /*int*/ let bufferPointer = 0;
                /*byte[]*/ let buffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(4096/*BackwardsSeekingBufferSize*/);
                /*Span<byte>*/ let bufferSpan = $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, buffer, 0, 4096/*BackwardsSeekingBufferSize*/);
                try
                {
                    /*bool*/ let outOfBytes = false;
                    /*bool*/ let signatureFound = false;
                    /*int*/ let totalBytesRead = 0;
                    while(!signatureFound && !outOfBytes && totalBytesRead < maxBytesToRead)
                    {
                        /*int*/ let overlap = totalBytesRead === 0 ? 0 : signatureToFind.Length;
                        if (((((maxBytesToRead - totalBytesRead) | 0) + overlap) | 0) < bufferSpan.Length)
                        {
                            bufferSpan = bufferSpan.Slice$1(0, ((((maxBytesToRead - totalBytesRead) | 0) + overlap) | 0));
                        }
                        /*int*/ let bytesRead = $.$sic.System.IO.Compression.ZipHelper.SeekBackwardsAndRead(stream, bufferSpan, overlap);
                        outOfBytes = bytesRead < bufferSpan.Length;
                        if (bytesRead < bufferSpan.Length)
                        {
                            bufferSpan = bufferSpan.Slice$1(0, bytesRead);
                        }
                        bufferPointer = $.$spc.System.MemoryExtensions.LastIndexOf$4($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(bufferSpan), signatureToFind);
                        $.$spc.System.Diagnostics.Debug.Assert$1(bufferPointer < bufferSpan.Length, "bufferPointer < bufferSpan.Length");
                        totalBytesRead += ((bytesRead - overlap) | 0);
                        if (bufferPointer !== -1)
                        {
                            signatureFound = true;
                            break;
                        }
                    }
                    if (!signatureFound)
                    {
                        return false;
                    }
                    else 
                    {
                        stream.Seek(BigInt(bufferPointer), 1/*SeekOrigin.Current*/);
                        return true;
                    }
                }
                finally
                {
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(buffer, false);
                    }
                }
            }
            static /*int */ SeekBackwardsAndRead(/*Stream*/ stream, /*Span<byte>*/ buffer, /*int*/ overlap)
            {
                /*int*/ let bytesRead;
                if (stream.Position >= BigInt(buffer.Length))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(overlap <= buffer.Length, "overlap <= buffer.Length");
                    stream.Seek(BigInt(-(((buffer.Length - overlap) | 0))), 1/*SeekOrigin.Current*/);
                    bytesRead = stream.ReadAtLeast(buffer, buffer.Length, true);
                    stream.Seek(BigInt(-buffer.Length), 1/*SeekOrigin.Current*/);
                }
                else 
                {
                    /*int*/ let bytesToRead = $.$cast(stream.Position, $.$spc.System.Int32);
                    stream.Seek(0n, 0/*SeekOrigin.Begin*/);
                    bytesRead = stream.ReadAtLeast(buffer, bytesToRead, true);
                    stream.Seek(0n, 0/*SeekOrigin.Begin*/);
                }
                return bytesRead;
            }
            static /*byte[] */ GetEncodedTruncatedBytesFromString(/*string?*/ text, /*Encoding?*/ encoding, /*int*/ maxBytes, /*out bool*/ isUTF8)
            {
                if ($.$spc.System.String.IsNullOrEmpty(text))
                {
                    isUTF8.$v = false;
                    return $.$spc.System.Array.Empty($.$spc.System.Byte);
                }
                encoding ??= $.$sic.System.IO.Compression.ZipHelper.GetEncoding(text);
                isUTF8.$v = encoding.CodePage === 65001;
                if (maxBytes === 0)
                {
                    return encoding.GetBytes$3(text);
                }
                /*byte[]*/ let bytes;
                if (isUTF8.$v && encoding.GetMaxByteCount(text.length) > maxBytes)
                {
                    /*int*/ let totalCodePoints = 0;
                    var $en3 = $.$spc.System.String.EnumerateRunes.call(text).GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var rune = $en3.Current;
                        {
                            if (((totalCodePoints + rune.Utf8SequenceLength) | 0) > maxBytes)
                            {
                                break;
                            }
                            totalCodePoints += rune.Utf8SequenceLength;
                        }
                    }
                    bytes = encoding.GetBytes$3(text);
                    $.$spc.System.Diagnostics.Debug.Assert$1(totalCodePoints > 0, "totalCodePoints > 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(totalCodePoints <= bytes.length, "totalCodePoints <= bytes.Length");
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetSubArray($.$spc.System.Byte, bytes, new $.$spc.System.Range().$ctor$2($.$spc.System.Index.op_Implicit(0), $.$spc.System.Index.op_Implicit(totalCodePoints)));
                }
                bytes = encoding.GetBytes$3(text);
                return maxBytes < bytes.length ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetSubArray($.$spc.System.Byte, bytes, new $.$spc.System.Range().$ctor$2($.$spc.System.Index.op_Implicit(0), $.$spc.System.Index.op_Implicit(maxBytes))) : bytes;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_invalidDateIndicator = new $.$spc.System.DateTime().$ctor$11(1980/*ValidZipDate_YearMin*/, 1, 1, 0, 0, 0);
                }
            }
            static $h = 3732882;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean).$h,"p":[{"n":"stream","p":62193665},{"n":"signatureToFind","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"maxBytesToRead","p":655361},{"n":"cancellationToken","p":125960193}],"n":"SeekBackwardsToSignatureAsync","d":3732882,"h":4298700178,"f":4136},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"stream","p":62193665},{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"overlap","p":655361},{"n":"cancellationToken","p":125960193}],"n":"SeekBackwardsAndReadAsync","d":3732882,"h":8593667474,"f":4130},{"r":121831425,"p":[{"n":"text","p":1310721}],"n":"GetEncoding","d":3732882,"h":38658438546,"f":40},{"r":34209793,"p":[{"n":"dateTime","p":720897}],"n":"DosTimeToDateTime","d":3732882,"h":42953405842,"f":40},{"r":720897,"p":[{"n":"dateTime","p":34209793}],"n":"DateTimeToDosTime","d":3732882,"h":47248373138,"f":40},{"r":262145,"p":[{"n":"stream","p":62193665},{"n":"signatureToFind","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"maxBytesToRead","p":655361}],"n":"SeekBackwardsToSignature","d":3732882,"h":51543340434,"f":40},{"r":655361,"p":[{"n":"stream","p":62193665},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"overlap","p":655361}],"n":"SeekBackwardsAndRead","d":3732882,"h":55838307730,"f":34},{"r":0,"p":[{"n":"text","p":1310721},{"n":"encoding","p":121831425},{"n":"maxBytes","p":655361},{"n":"isUTF8","p":262145,"f":2}],"n":"GetEncodedTruncatedBytesFromString","d":3732882,"h":60133275026,"f":40}],"l":[{"t":720897,"n":"Mask32Bit","d":3732882,"h":12888634770,"f":40},{"t":589825,"n":"Mask16Bit","d":3732882,"h":17183602066,"f":40},{"t":655361,"n":"BackwardsSeekingBufferSize","d":3732882,"h":21478569362,"f":34},{"t":655361,"n":"ValidZipDate_YearMin","d":3732882,"h":25773536658,"f":40},{"t":655361,"n":"ValidZipDate_YearMax","d":3732882,"h":30068503954,"f":40},{"t":34209793,"n":"s_invalidDateIndicator","d":3732882,"h":34363471250,"f":34}],"h":3732882}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ZipHelper`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.InputBuffer", ($self) => class InputBuffer extends $.$spc.System.Object
        {
            /*Memory<byte>*/ _buffer;
            /*uint*/ _bitBuffer = 0;
            /*int*/ _bitsInBuffer = 0;
            /*int */ get AvailableBits()
            {
                return this._bitsInBuffer;
            }
            /*int */ get AvailableBytes()
            {
                return ((this._buffer.Length + ($.trunc(this._bitsInBuffer / 8))) | 0);
            }
            /*bool */ EnsureBitsAvailable(/*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(0 < count && count <= 16, "count is invalid.");
                if (this._bitsInBuffer < count)
                {
                    if (this.NeedsInput())
                    {
                        return false;
                    }
                    this._bitBuffer |= (this._buffer.Span.get_Item(0).$v << this._bitsInBuffer) >>> 0;
                    this._buffer = this._buffer.Slice(1);
                    this._bitsInBuffer += 8;
                    if (this._bitsInBuffer < count)
                    {
                        if (this.NeedsInput())
                        {
                            return false;
                        }
                        this._bitBuffer |= (this._buffer.Span.get_Item(0).$v << this._bitsInBuffer) >>> 0;
                        this._buffer = this._buffer.Slice(1);
                        this._bitsInBuffer += 8;
                    }
                }
                return true;
            }
            /*uint */ TryLoad16Bits()
            {
                if (this._bitsInBuffer < 8)
                {
                    if (this._buffer.Length > 1)
                    {
                        /*Span<byte>*/ let span = this._buffer.Span;
                        this._bitBuffer |= (span.get_Item(0).$v << this._bitsInBuffer) >>> 0;
                        this._bitBuffer |= (span.get_Item(1).$v << (((this._bitsInBuffer + 8) | 0))) >>> 0;
                        this._buffer = this._buffer.Slice(2);
                        this._bitsInBuffer += 16;
                    }
                    else if (this._buffer.Length !== 0)
                    {
                        this._bitBuffer |= (this._buffer.Span.get_Item(0).$v << this._bitsInBuffer) >>> 0;
                        this._buffer = this._buffer.Slice(1);
                        this._bitsInBuffer += 8;
                    }
                }
                else if (this._bitsInBuffer < 16)
                {
                    if (!this._buffer.IsEmpty)
                    {
                        this._bitBuffer |= (this._buffer.Span.get_Item(0).$v << this._bitsInBuffer) >>> 0;
                        this._buffer = this._buffer.Slice(1);
                        this._bitsInBuffer += 8;
                    }
                }
                return this._bitBuffer;
            }
            static /*uint */ GetBitMask(/*int*/ count)
            {
                return ((((1 << count) >>> 0) - 1) >>> 0);
            }
            /*int */ GetBits(/*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(0 < count && count <= 16, "count is invalid.");
                if (!this.EnsureBitsAvailable(count))
                {
                    return -1;
                }
                /*int*/ let result = ((this._bitBuffer & $.$sic.System.IO.Compression.InputBuffer.GetBitMask(count)) | 0);
                this._bitBuffer >>= count;
                this._bitsInBuffer -= count;
                return result;
            }
            /*int */ CopyTo(/*Memory<byte>*/ output)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bitsInBuffer % 8 === 0, "_bitsInBuffer % 8 == 0");
                /*int*/ let bytesFromBitBuffer = 0;
                while(this._bitsInBuffer > 0 && !output.IsEmpty)
                {
                    output.Span.get_Item(0).$v = $.$cast(this._bitBuffer, $.$spc.System.Byte);
                    output = output.Slice(1);
                    this._bitBuffer >>= 8;
                    this._bitsInBuffer -= 8;
                    bytesFromBitBuffer++;
                }
                if (output.IsEmpty)
                {
                    return bytesFromBitBuffer;
                }
                /*int*/ let length = $.$spc.System.Math.Min$4(output.Length, this._buffer.Length);
                this._buffer.Slice$1(0, length).CopyTo(output);
                this._buffer = this._buffer.Slice(length);
                return ((bytesFromBitBuffer + length) | 0);
            }
            /*int */ CopyTo$1(/*byte[]*/ output, /*int*/ offset, /*int*/ length)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(output !== null, "output != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(offset >= 0, "offset >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 0, "length >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(offset <= ((output.length - length) | 0), "offset <= output.Length - length");
                $.$spc.System.Diagnostics.Debug.Assert$1((this._bitsInBuffer % 8) === 0, "(_bitsInBuffer % 8) == 0");
                return this.CopyTo($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, output, offset, length));
            }
            /*bool */ NeedsInput()
            {
                return this._buffer.IsEmpty;
            }
            /*void */ SetInput(/*Memory<byte>*/ buffer)
            {
                if (this._buffer.IsEmpty)
                {
                    this._buffer = buffer;
                }
            }
            /*void */ SetInput$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ length)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(buffer !== null, "buffer != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(offset >= 0, "offset >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 0, "length >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(offset <= ((buffer.length - length) | 0), "offset <= buffer.Length - length");
                this.SetInput($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, buffer, offset, length));
            }
            /*void */ SkipBits(/*int*/ n)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bitsInBuffer >= n, "No enough bits in the buffer, Did you call EnsureBitsAvailable?");
                this._bitBuffer >>= n;
                this._bitsInBuffer -= n;
            }
            /*void */ SkipToByteBoundary()
            {
                this._bitBuffer >>= (this._bitsInBuffer % 8);
                this._bitsInBuffer -= (this._bitsInBuffer % 8);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._buffer = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
            }
            static $h = 1570194;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21476406674,"f":1},"n":"AvailableBits","d":1570194,"h":17181439378,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30066341266,"f":1},"n":"AvailableBytes","d":1570194,"h":25771373970,"f":1}],"m":[{"r":262145,"p":[{"n":"count","p":655361}],"n":"EnsureBitsAvailable","d":1570194,"h":34361308562,"f":1},{"r":720897,"n":"TryLoad16Bits","d":1570194,"h":38656275858,"f":1},{"r":720897,"p":[{"n":"count","p":655361}],"n":"GetBitMask","d":1570194,"h":42951243154,"f":34},{"r":655361,"p":[{"n":"count","p":655361}],"n":"GetBits","d":1570194,"h":47246210450,"f":1},{"r":655361,"p":[{"n":"output","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h}],"n":"CopyTo","d":1570194,"h":51541177746,"f":1},{"r":655361,"p":[{"n":"output","p":0},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"CopyTo","o":"@$1","d":1570194,"h":55836145042,"f":1},{"r":262145,"n":"NeedsInput","d":1570194,"h":60131112338,"f":1},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h}],"n":"SetInput","d":1570194,"h":64426079634,"f":1},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"SetInput","o":"@$1","d":1570194,"h":68721046930,"f":1},{"r":65537,"p":[{"n":"n","p":655361}],"n":"SkipBits","d":1570194,"h":73016014226,"f":1},{"r":65537,"n":"SkipToByteBoundary","d":1570194,"h":77310981522,"f":1}],"l":[{"t":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"n":"_buffer","d":1570194,"h":4296537490,"f":2},{"t":720897,"n":"_bitBuffer","d":1570194,"h":8591504786,"f":2},{"t":655361,"n":"_bitsInBuffer","d":1570194,"h":12886472082,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1570194,"h":81605948818,"f":1}],"h":1570194}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.InputBuffer`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.OutputWindow", ($self) => class OutputWindow extends $.$spc.System.Object
        {
            /*int*/ static WindowSize = 262144;
            /*int*/ static WindowMask = 262143;
            /*byte[]*/ _window = null;
            /*int*/ _end = 0;
            /*int*/ _bytesUsed = 0;
            /*void */ ClearBytesUsed()
            {
                this._bytesUsed = 0;
            }
            /*void */ Write(/*byte*/ b)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bytesUsed < 262144/*WindowSize*/, "Can't add byte when window is full!");
                $.$spc.System.Array.$WriteT1.call(this._window, b, this._end++);
                this._end &= 262143/*WindowMask*/;
                ++this._bytesUsed;
            }
            /*void */ WriteLengthDistance(/*int*/ length, /*int*/ distance)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((((this._bytesUsed + length) | 0)) <= 262144/*WindowSize*/, "No Enough space");
                this._bytesUsed += length;
                /*int*/ let copyStart = (((this._end - distance) | 0)) & 262143/*WindowMask*/;
                /*int*/ let border = ((262144/*WindowSize*/ - length) | 0);
                if (copyStart <= border && this._end < border)
                {
                    if (length <= distance)
                    {
                        $.$spc.System.Array.Copy$1(this._window, copyStart, this._window, this._end, length);
                        this._end += length;
                    }
                    else 
                    {
                        while(length-- > 0)
                        {
                            $.$spc.System.Array.$WriteT1.call(this._window, $.$spc.System.Array.$ReadT1.call(this._window, copyStart++), this._end++);
                        }
                    }
                }
                else 
                {
                    while(length-- > 0)
                    {
                        $.$spc.System.Array.$WriteT1.call(this._window, $.$spc.System.Array.$ReadT1.call(this._window, copyStart++), this._end++);
                        this._end &= 262143/*WindowMask*/;
                        copyStart &= 262143/*WindowMask*/;
                    }
                }
            }
            /*int */ CopyFrom(/*InputBuffer*/ input, /*int*/ length)
            {
                length = $.$spc.System.Math.Min$4($.$spc.System.Math.Min$4(length, ((262144/*WindowSize*/ - this._bytesUsed) | 0)), input.AvailableBytes);
                /*int*/ let copied;
                /*int*/ let tailLen = ((262144/*WindowSize*/ - this._end) | 0);
                if (length > tailLen)
                {
                    copied = input.CopyTo$1(this._window, this._end, tailLen);
                    if (copied === tailLen)
                    {
                        copied += input.CopyTo$1(this._window, 0, ((length - tailLen) | 0));
                    }
                }
                else 
                {
                    copied = input.CopyTo$1(this._window, this._end, length);
                }
                this._end = (((this._end + copied) | 0)) & 262143/*WindowMask*/;
                this._bytesUsed += copied;
                return copied;
            }
            /*int */ get FreeBytes()
            {
                return ((262144/*WindowSize*/ - this._bytesUsed) | 0);
            }
            /*int */ get AvailableBytes()
            {
                return this._bytesUsed;
            }
            /*int */ CopyTo(/*Span<byte>*/ output)
            {
                /*int*/ let copy_end;
                if (output.Length > this._bytesUsed)
                {
                    copy_end = this._end;
                    output = output.Slice$1(0, this._bytesUsed);
                }
                else 
                {
                    copy_end = (((((this._end - this._bytesUsed) | 0) + output.Length) | 0)) & 262143/*WindowMask*/;
                }
                /*int*/ let copied = output.Length;
                /*int*/ let tailLen = ((output.Length - copy_end) | 0);
                if (tailLen > 0)
                {
                    $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, this._window, ((262144/*WindowSize*/ - tailLen) | 0), tailLen).CopyTo(output);
                    output = output.Slice$1(tailLen, copy_end);
                }
                $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, this._window, ((copy_end - output.Length) | 0), output.Length).CopyTo(output);
                this._bytesUsed -= copied;
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bytesUsed >= 0, "check this function and find why we copied more bytes than we have");
                return copied;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._window = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [262144/*WindowSize*/], null);
            }
            static $h = 1701266;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":47246341522,"f":1},"n":"FreeBytes","d":1701266,"h":42951374226,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55836276114,"f":1},"n":"AvailableBytes","d":1701266,"h":51541308818,"f":1}],"m":[{"r":65537,"n":"ClearBytesUsed","d":1701266,"h":25771505042,"f":8},{"r":65537,"p":[{"n":"b","p":393217}],"n":"Write","d":1701266,"h":30066472338,"f":1},{"r":65537,"p":[{"n":"length","p":655361},{"n":"distance","p":655361}],"n":"WriteLengthDistance","d":1701266,"h":34361439634,"f":1},{"r":655361,"p":[{"n":"input","p":1570194},{"n":"length","p":655361}],"n":"CopyFrom","d":1701266,"h":38656406930,"f":1},{"r":655361,"p":[{"n":"output","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"CopyTo","d":1701266,"h":60131243410,"f":1}],"l":[{"t":655361,"n":"WindowSize","d":1701266,"h":4296668562,"f":34},{"t":655361,"n":"WindowMask","d":1701266,"h":8591635858,"f":34},{"t":0,"n":"_window","d":1701266,"h":12886603154,"f":2},{"t":655361,"n":"_end","d":1701266,"h":17181570450,"f":2},{"t":655361,"n":"_bytesUsed","d":1701266,"h":21476537746,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1701266,"h":64426210706,"f":1}],"h":1701266}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.OutputWindow`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZLibNative", ($self) => class ZLibNative
        {
            /*IntPtr*/ static ZNullPtr = 0;
            static $_FlushCode;
            static get FlushCode()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_FlushCode ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.FlushCode", ($self) => class FlushCode extends $.$spc.System.Enum
                {
                    static NoFlush = 0;
                    static SyncFlush = 2;
                    static Finish = 4;
                    static Block = 5;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "NoFlush": 0n,
                            "SyncFlush": 2n,
                            "Finish": 4n,
                            "Block": 5n
                        };
                    }
                    static $h = 5043602;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5043602,"n":"NoFlush","d":5043602,"h":4300010898,"f":33},{"t":5043602,"n":"SyncFlush","d":5043602,"h":8594978194,"f":33},{"t":5043602,"n":"Finish","d":5043602,"h":12889945490,"f":33},{"t":5043602,"n":"Block","d":5043602,"h":17184912786,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5043602,"h":21479880082,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":4715922,"h":5043602}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZLibNative.FlushCode`; }
                }, $cls, ($v) => $cls.$_FlushCode = $v);
            }
            static $_ErrorCode;
            static get ErrorCode()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_ErrorCode ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.ErrorCode", ($self) => class ErrorCode extends $.$spc.System.Enum
                {
                    static Ok = 0;
                    static StreamEnd = 1;
                    static StreamError = -2;
                    static DataError = -3;
                    static MemError = -4;
                    static BufError = -5;
                    static VersionError = -6;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Ok": 0n,
                            "StreamEnd": 1n,
                            "StreamError": -2n,
                            "DataError": -3n,
                            "MemError": -4n,
                            "BufError": -5n,
                            "VersionError": -6n
                        };
                    }
                    static $h = 4978066;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4978066,"n":"Ok","d":4978066,"h":4299945362,"f":33},{"t":4978066,"n":"StreamEnd","d":4978066,"h":8594912658,"f":33},{"t":4978066,"n":"StreamError","d":4978066,"h":12889879954,"f":33},{"t":4978066,"n":"DataError","d":4978066,"h":17184847250,"f":33},{"t":4978066,"n":"MemError","d":4978066,"h":21479814546,"f":33},{"t":4978066,"n":"BufError","d":4978066,"h":25774781842,"f":33},{"t":4978066,"n":"VersionError","d":4978066,"h":30069749138,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4978066,"h":34364716434,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":4715922,"h":4978066}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZLibNative.ErrorCode`; }
                }, $cls, ($v) => $cls.$_ErrorCode = $v);
            }
            static $_CompressionStrategy;
            static get CompressionStrategy()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_CompressionStrategy ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.CompressionStrategy", ($self) => class CompressionStrategy extends $.$spc.System.Enum
                {
                    static DefaultStrategy = 0;
                    static Filtered = 1;
                    static HuffmanOnly = 2;
                    static RunLengthEncoding = 3;
                    static Fixed = 4;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "DefaultStrategy": 0n,
                            "Filtered": 1n,
                            "HuffmanOnly": 2n,
                            "RunLengthEncoding": 3n,
                            "Fixed": 4n
                        };
                    }
                    static $h = 4912530;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4912530,"n":"DefaultStrategy","d":4912530,"h":4299879826,"f":33},{"t":4912530,"n":"Filtered","d":4912530,"h":8594847122,"f":33},{"t":4912530,"n":"HuffmanOnly","d":4912530,"h":12889814418,"f":33},{"t":4912530,"n":"RunLengthEncoding","d":4912530,"h":17184781714,"f":33},{"t":4912530,"n":"Fixed","d":4912530,"h":21479749010,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4912530,"h":25774716306,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":4715922,"h":4912530}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZLibNative.CompressionStrategy`; }
                }, $cls, ($v) => $cls.$_CompressionStrategy = $v);
            }
            static $_CompressionMethod;
            static get CompressionMethod()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_CompressionMethod ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.CompressionMethod", ($self) => class CompressionMethod extends $.$spc.System.Enum
                {
                    static Deflated = 8;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Deflated": 8n
                        };
                    }
                    static $h = 4846994;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4846994,"n":"Deflated","d":4846994,"h":4299814290,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4846994,"h":8594781586,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":4715922,"h":4846994}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZLibNative.CompressionMethod`; }
                }, $cls, ($v) => $cls.$_CompressionMethod = $v);
            }
            /*int*/ static Deflate_DefaultWindowBits = -15;
            /*int*/ static ZLib_DefaultWindowBits = 15;
            /*int*/ static GZip_DefaultWindowBits = 31;
            /*int*/ static Deflate_DefaultMemLevel = 8;
            /*int*/ static Deflate_NoCompressionMemLevel = 7;
            /*byte*/ static GZip_Header_ID1 = 31;
            /*byte*/ static GZip_Header_ID2 = 139;
            static $_ZLibStreamHandle;
            static get ZLibStreamHandle()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_ZLibStreamHandle ??= $asm.$ncls("$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle", ($self) => class ZLibStreamHandle extends $.$spc.System.Runtime.InteropServices.SafeHandle
                {
                    static $_State;
                    static get State()
                    {
                        let $cls = $.$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle;
                        return $cls.$_State ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle.State", ($self) => class State extends $.$spc.System.Enum
                        {
                            static NotInitialized = 0;
                            static InitializedForDeflate = 1;
                            static InitializedForInflate = 2;
                            static Disposed = 3;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "NotInitialized": 0n,
                                    "InitializedForDeflate": 1n,
                                    "InitializedForInflate": 2n,
                                    "Disposed": 3n
                                };
                            }
                            static $h = 5174674;
                            static $z = 4;
                            static $f = 0b110000011010001001;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5174674,"n":"NotInitialized","d":5174674,"h":4300141970,"f":33},{"t":5174674,"n":"InitializedForDeflate","d":5174674,"h":8595109266,"f":33},{"t":5174674,"n":"InitializedForInflate","d":5174674,"h":12890076562,"f":33},{"t":5174674,"n":"Disposed","d":5174674,"h":17185043858,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5174674,"h":21480011154,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":5109138,"h":5174674}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `System.IO.Compression.ZLibNative.ZLibStreamHandle.State`; }
                        }, $cls, ($v) => $cls.$_State = $v);
                    }
                    /*ZStream*/ _zStream;
                    /*State*/ _initializationState = 0;
                    $ctor$3()
                    {
                        super.$ctor$2(new $.$spc.System.IntPtr().$ctor$2(-1), true);
                        {
                            this._initializationState = 0/*State.NotInitialized*/;
                            this.SetHandle($.$spc.System.IntPtr.Zero);
                        }
                        return this;
                    }
                    /*bool */ get IsInvalid()
                    {
                        return this.handle === new $.$spc.System.IntPtr().$ctor$2(-1);
                    }
                    /*State */ get InitializationState()
                    {
                        return this._initializationState;
                    }
                    /*bool */ ReleaseHandle()
                    {
                        return (() =>
                        {
                            if (this.InitializationState === 0/*State.NotInitialized*/)
                            {
                                return true;
                            }
                            if (this.InitializationState === 1/*State.InitializedForDeflate*/)
                            {
                                return (this.DeflateEnd() === 0/*ErrorCode.Ok*/);
                            }
                            if (this.InitializationState === 2/*State.InitializedForInflate*/)
                            {
                                return (this.InflateEnd() === 0/*ErrorCode.Ok*/);
                            }
                            if (this.InitializationState === 3/*State.Disposed*/)
                            {
                                return true;
                            }
                            return false;
                        })();
                    }
                    /*IntPtr */ get NextIn()
                    {
                        return this._zStream.nextIn;
                    }
                    /*IntPtr */ set NextIn(value)
                    {
                        this._zStream.nextIn = value;
                    }
                    /*uint */ get AvailIn()
                    {
                        return this._zStream.availIn;
                    }
                    /*uint */ set AvailIn(value)
                    {
                        this._zStream.availIn = value;
                    }
                    /*IntPtr */ get NextOut()
                    {
                        return this._zStream.nextOut;
                    }
                    /*IntPtr */ set NextOut(value)
                    {
                        this._zStream.nextOut = value;
                    }
                    /*uint */ get AvailOut()
                    {
                        return this._zStream.availOut;
                    }
                    /*uint */ set AvailOut(value)
                    {
                        this._zStream.availOut = value;
                    }
                    /*void */ EnsureNotDisposed()
                    {
                        $.$spc.System.ObjectDisposedException.ThrowIf(this.InitializationState === 3/*State.Disposed*/, this);
                    }
                    /*void */ EnsureState(/*State*/ requiredState)
                    {
                        if (this.InitializationState !== requiredState)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10("InitializationState != " + $.$spc.System.Enum.ToStringT($.$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle.State, $.$spc.System.UInt32, requiredState));
                        }
                    }
                    /*ErrorCode */ DeflateInit2_(/*CompressionLevel*/ level, /*int*/ windowBits, /*int*/ memLevel, /*CompressionStrategy*/ strategy)
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(0/*State.NotInitialized*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            /*ErrorCode*/ let errC = $.$sic.Interop.ZLib.DeflateInit2_(stream, level, 8/*CompressionMethod.Deflated*/, windowBits, memLevel, strategy);
                            this._initializationState = 1/*State.InitializedForDeflate*/;
                            return errC;
                        }
                    }
                    /*ErrorCode */ Deflate(/*FlushCode*/ flush)
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(1/*State.InitializedForDeflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            return $.$sic.Interop.ZLib.Deflate(stream, flush);
                        }
                    }
                    /*ErrorCode */ DeflateEnd()
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(1/*State.InitializedForDeflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            /*ErrorCode*/ let errC = $.$sic.Interop.ZLib.DeflateEnd(stream);
                            this._initializationState = 3/*State.Disposed*/;
                            return errC;
                        }
                    }
                    /*ErrorCode */ InflateInit2_(/*int*/ windowBits)
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(0/*State.NotInitialized*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            /*ErrorCode*/ let errC = $.$sic.Interop.ZLib.InflateInit2_(stream, windowBits);
                            this._initializationState = 2/*State.InitializedForInflate*/;
                            return errC;
                        }
                    }
                    /*ErrorCode */ InflateReset2_(/*int*/ windowBits)
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(2/*State.InitializedForInflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            return $.$sic.Interop.ZLib.InflateReset2_(stream, windowBits);
                        }
                    }
                    /*ErrorCode */ Inflate(/*FlushCode*/ flush)
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(2/*State.InitializedForInflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            return $.$sic.Interop.ZLib.Inflate(stream, flush);
                        }
                    }
                    /*ErrorCode */ InflateEnd()
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(2/*State.InitializedForInflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            /*ErrorCode*/ let errC = $.$sic.Interop.ZLib.InflateEnd(stream);
                            this._initializationState = 3/*State.Disposed*/;
                            return errC;
                        }
                    }
                    /*string */ GetErrorMessage()
                    {
                        return this._zStream.msg !== $.$sic.System.IO.Compression.ZLibNative.ZNullPtr ? $.$spc.System.Runtime.InteropServices.Marshal.PtrToStringUTF8(this._zStream.msg) : $.$spc.System.String.Empty;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._zStream = $.$default($.$sic.System.IO.Compression.ZLibNative.ZStream);
                    }
                    static $h = 5109138;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":109576193,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25774912914,"f":32769},"n":"IsInvalid","d":5109138,"h":21479945618,"f":32769},{"p":5174674,"g":{"r":0,"d":0,"h":34364847506,"f":1},"n":"InitializationState","d":5109138,"h":30069880210,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":47249749394,"f":1},"s":{"r":0,"d":0,"h":51544716690,"f":1},"n":"NextIn","d":5109138,"h":42954782098,"f":1},{"p":720897,"g":{"r":0,"d":0,"h":60134651282,"f":1},"s":{"r":0,"d":0,"h":64429618578,"f":1},"n":"AvailIn","d":5109138,"h":55839683986,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":73019553170,"f":1},"s":{"r":0,"d":0,"h":77314520466,"f":1},"n":"NextOut","d":5109138,"h":68724585874,"f":1},{"p":720897,"g":{"r":0,"d":0,"h":85904455058,"f":1},"s":{"r":0,"d":0,"h":90199422354,"f":1},"n":"AvailOut","d":5109138,"h":81609487762,"f":1}],"m":[{"r":262145,"n":"ReleaseHandle","d":5109138,"h":38659814802,"f":32772},{"r":65537,"n":"EnsureNotDisposed","d":5109138,"h":94494389650,"f":2},{"r":65537,"p":[{"n":"requiredState","p":5174674}],"n":"EnsureState","d":5109138,"h":98789356946,"f":2},{"r":4978066,"p":[{"n":"level","p":4781458},{"n":"windowBits","p":655361},{"n":"memLevel","p":655361},{"n":"strategy","p":4912530}],"n":"DeflateInit2_","d":5109138,"h":103084324242,"f":1},{"r":4978066,"p":[{"n":"flush","p":5043602}],"n":"Deflate","d":5109138,"h":107379291538,"f":1},{"r":4978066,"n":"DeflateEnd","d":5109138,"h":111674258834,"f":1},{"r":4978066,"p":[{"n":"windowBits","p":655361}],"n":"InflateInit2_","d":5109138,"h":115969226130,"f":1},{"r":4978066,"p":[{"n":"windowBits","p":655361}],"n":"InflateReset2_","d":5109138,"h":120264193426,"f":1},{"r":4978066,"p":[{"n":"flush","p":5043602}],"n":"Inflate","d":5109138,"h":124559160722,"f":1},{"r":4978066,"n":"InflateEnd","d":5109138,"h":128854128018,"f":1},{"r":1310721,"n":"GetErrorMessage","d":5109138,"h":133149095314,"f":1}],"l":[{"t":5240210,"n":"_zStream","d":5109138,"h":8595043730,"f":2},{"t":5174674,"n":"_initializationState","d":5109138,"h":12890011026,"f":2}],"c":[{"n":".ctor","o":"$ctor$3","d":5109138,"h":17184978322,"f":1}],"i":[57540609],"j":[5174674],"d":4715922,"h":5109138}; }
                    static get $b() { return $.$spc.System.Runtime.InteropServices.SafeHandle; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `System.IO.Compression.ZLibNative.ZLibStreamHandle`; }
                }, $cls, ($v) => $cls.$_ZLibStreamHandle = $v);
            }
            static /*ErrorCode */ CreateZLibStreamForDeflate(/*out ZLibStreamHandle*/ zLibStreamHandle, /*CompressionLevel*/ level, /*int*/ windowBits, /*int*/ memLevel, /*CompressionStrategy*/ strategy)
            {
                zLibStreamHandle.$v = new $.$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle().$ctor$3();
                return zLibStreamHandle.$v.DeflateInit2_(level, windowBits, memLevel, strategy);
            }
            static /*ErrorCode */ CreateZLibStreamForInflate(/*out ZLibStreamHandle*/ zLibStreamHandle, /*int*/ windowBits)
            {
                zLibStreamHandle.$v = new $.$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle().$ctor$3();
                return zLibStreamHandle.$v.InflateInit2_(windowBits);
            }
            static $_CompressionLevel;
            static get CompressionLevel()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_CompressionLevel ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.CompressionLevel", ($self) => class CompressionLevel extends $.$spc.System.Enum
                {
                    static NoCompression = 0;
                    static BestSpeed = 1;
                    static DefaultCompression = -1;
                    static BestCompression = 9;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "NoCompression": 0n,
                            "BestSpeed": 1n,
                            "DefaultCompression": -1n,
                            "BestCompression": 9n
                        };
                    }
                    static $h = 4781458;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4781458,"n":"NoCompression","d":4781458,"h":4299748754,"f":33},{"t":4781458,"n":"BestSpeed","d":4781458,"h":8594716050,"f":33},{"t":4781458,"n":"DefaultCompression","d":4781458,"h":12889683346,"f":33},{"t":4781458,"n":"BestCompression","d":4781458,"h":17184650642,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4781458,"h":21479617938,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":4715922,"h":4781458}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `ZLibNative.CompressionLevel`; }
                }, $cls, ($v) => $cls.$_CompressionLevel = $v);
            }
            static $_ZStream;
            static get ZStream()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_ZStream ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.ZStream", ($self) => class ZStream extends $.$spc.System.ValueType
                {
                    /*IntPtr*/  get nextIn() { return this.$getField(0, $.$spc.System.IntPtr); }
                    /*IntPtr*/  set nextIn(value) { this.$setField(0, $.$spc.System.IntPtr, value); }
                    /*IntPtr*/  get nextOut() { return this.$getField(4, $.$spc.System.IntPtr); }
                    /*IntPtr*/  set nextOut(value) { this.$setField(4, $.$spc.System.IntPtr, value); }
                    /*IntPtr*/  get msg() { return this.$getField(8, $.$spc.System.IntPtr); }
                    /*IntPtr*/  set msg(value) { this.$setField(8, $.$spc.System.IntPtr, value); }
                    /*IntPtr*/  get internalState() { return this.$getField(12, $.$spc.System.IntPtr); }
                    /*IntPtr*/  set internalState(value) { this.$setField(12, $.$spc.System.IntPtr, value); }
                    /*uint*/  get availIn() { return this.$getField(16, $.$spc.System.UInt32); }
                    /*uint*/  set availIn(value) { this.$setField(16, $.$spc.System.UInt32, value); }
                    /*uint*/  get availOut() { return this.$getField(20, $.$spc.System.UInt32); }
                    /*uint*/  set availOut(value) { this.$setField(20, $.$spc.System.UInt32, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.nextIn = this.nextIn;
                        copy.nextOut = this.nextOut;
                        copy.msg = this.msg;
                        copy.internalState = this.internalState;
                        copy.availIn = this.availIn;
                        copy.availOut = this.availOut;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.nextIn = 0;
                        this.nextOut = 0;
                        this.msg = 0;
                        this.internalState = 0;
                        this.availIn = 0;
                        this.availOut = 0;
                    }
                    static $h = 5240210;
                    static $z = 24;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":786433,"n":"nextIn","d":5240210,"h":4300207506,"f":8},{"t":786433,"n":"nextOut","d":5240210,"h":8595174802,"f":8},{"t":786433,"n":"msg","d":5240210,"h":12890142098,"f":8},{"t":786433,"n":"internalState","d":5240210,"h":17185109394,"f":2},{"t":720897,"n":"availIn","d":5240210,"h":21480076690,"f":8},{"t":720897,"n":"availOut","d":5240210,"h":25775043986,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":5240210,"h":30070011282,"f":1}],"d":4715922,"h":5240210,"a":[{"t":109903873,"c":4404871169,"a":[{"v":0,"t":105381889}],"n":[{"n":"CharSet","v":2,"t":98500609}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.IO.Compression.ZLibNative.ZStream`; }
                }, $cls, ($v) => $cls.$_ZStream = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ZNullPtr = $.$spc.System.IntPtr.Zero;
                }
            }
            static $h = 4715922;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":4978066,"p":[{"n":"zLibStreamHandle","p":5109138,"f":2},{"n":"level","p":4781458},{"n":"windowBits","p":655361},{"n":"memLevel","p":655361},{"n":"strategy","p":4912530}],"n":"CreateZLibStreamForDeflate","d":4715922,"h":60134258066,"f":33},{"r":4978066,"p":[{"n":"zLibStreamHandle","p":5109138,"f":2},{"n":"windowBits","p":655361}],"n":"CreateZLibStreamForInflate","d":4715922,"h":64429225362,"f":33}],"l":[{"t":786433,"n":"ZNullPtr","d":4715922,"h":4299683218,"f":40},{"t":655361,"n":"Deflate_DefaultWindowBits","d":4715922,"h":25774519698,"f":33},{"t":655361,"n":"ZLib_DefaultWindowBits","d":4715922,"h":30069486994,"f":33},{"t":655361,"n":"GZip_DefaultWindowBits","d":4715922,"h":34364454290,"f":33},{"t":655361,"n":"Deflate_DefaultMemLevel","d":4715922,"h":38659421586,"f":33},{"t":655361,"n":"Deflate_NoCompressionMemLevel","d":4715922,"h":42954388882,"f":33},{"t":393217,"n":"GZip_Header_ID1","d":4715922,"h":47249356178,"f":33},{"t":393217,"n":"GZip_Header_ID2","d":4715922,"h":51544323474,"f":33}],"j":[5043602,4978066,4912530,4846994,5109138,4781458,5240210],"h":4715922}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.ZLibNative`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.Crc32Helper", ($self) => class Crc32Helper
        {
            static /*uint */ UpdateCrc32(/*uint*/ crc32, /*byte[]*/ buffer, /*int*/ offset, /*int*/ length)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((buffer !== null) && (offset >= 0) && (length >= 0) && (offset <= ((buffer.length - length) | 0)), "(buffer != null) && (offset >= 0) && (length >= 0) && (offset <= buffer.Length - length)");
                /*fixed*/ 
                {
                    /*byte**/ let bufferPtr = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$spc.System.Byte, buffer, offset, false, true);
                    return $.$sic.Interop.ZLib.crc32(crc32, bufferPtr, length);
                }
            }
            static /*uint */ UpdateCrc32$1(/*uint*/ crc32, /*ReadOnlySpan<byte>*/ buffer)
            {
                /*fixed*/ 
                {
                    /*byte**/ let bufferPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, buffer);
                    return $.$sic.Interop.ZLib.crc32(crc32, bufferPtr, buffer.Length);
                }
            }
            static $h = 914834;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":720897,"p":[{"n":"crc32","p":720897},{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"UpdateCrc32","d":914834,"h":4295882130,"f":33},{"r":720897,"p":[{"n":"crc32","p":720897},{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"UpdateCrc32","o":"@$1","d":914834,"h":8590849426,"f":33}],"h":914834}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.Crc32Helper`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord", ($self) => class Zip64EndOfCentralDirectoryRecord extends $.$spc.System.Object
        {
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static Signature = 4;
                    /*int*/ static SizeOfThisRecord = 8;
                    /*int*/ static VersionMadeBy = 2;
                    /*int*/ static VersionNeededToExtract = 2;
                    /*int*/ static NumberOfThisDisk = 4;
                    /*int*/ static NumberOfDiskWithStartOfCD = 4;
                    /*int*/ static NumberOfEntriesOnThisDisk = 8;
                    /*int*/ static NumberOfEntriesTotal = 8;
                    /*int*/ static SizeOfCentralDirectory = 8;
                    /*int*/ static OffsetOfCentralDirectory = 8;
                    static $h = 2225554;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":2225554,"h":4297192850,"f":33},{"t":655361,"n":"SizeOfThisRecord","d":2225554,"h":8592160146,"f":33},{"t":655361,"n":"VersionMadeBy","d":2225554,"h":12887127442,"f":33},{"t":655361,"n":"VersionNeededToExtract","d":2225554,"h":17182094738,"f":33},{"t":655361,"n":"NumberOfThisDisk","d":2225554,"h":21477062034,"f":33},{"t":655361,"n":"NumberOfDiskWithStartOfCD","d":2225554,"h":25772029330,"f":33},{"t":655361,"n":"NumberOfEntriesOnThisDisk","d":2225554,"h":30066996626,"f":33},{"t":655361,"n":"NumberOfEntriesTotal","d":2225554,"h":34361963922,"f":33},{"t":655361,"n":"SizeOfCentralDirectory","d":2225554,"h":38656931218,"f":33},{"t":655361,"n":"OffsetOfCentralDirectory","d":2225554,"h":42951898514,"f":33}],"d":2160018,"h":2225554}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.Zip64EndOfCentralDirectoryRecord.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Signature = 0;
                    /*int*/ static SizeOfThisRecord = 4;
                    /*int*/ static VersionMadeBy = 12;
                    /*int*/ static VersionNeededToExtract = 14;
                    /*int*/ static NumberOfThisDisk = 16;
                    /*int*/ static NumberOfDiskWithStartOfCD = 20;
                    /*int*/ static NumberOfEntriesOnThisDisk = 24;
                    /*int*/ static NumberOfEntriesTotal = 32;
                    /*int*/ static SizeOfCentralDirectory = 40;
                    /*int*/ static OffsetOfCentralDirectory = 48;
                    static $h = 2291090;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":2291090,"h":4297258386,"f":33},{"t":655361,"n":"SizeOfThisRecord","d":2291090,"h":8592225682,"f":33},{"t":655361,"n":"VersionMadeBy","d":2291090,"h":12887192978,"f":33},{"t":655361,"n":"VersionNeededToExtract","d":2291090,"h":17182160274,"f":33},{"t":655361,"n":"NumberOfThisDisk","d":2291090,"h":21477127570,"f":33},{"t":655361,"n":"NumberOfDiskWithStartOfCD","d":2291090,"h":25772094866,"f":33},{"t":655361,"n":"NumberOfEntriesOnThisDisk","d":2291090,"h":30067062162,"f":33},{"t":655361,"n":"NumberOfEntriesTotal","d":2291090,"h":34362029458,"f":33},{"t":655361,"n":"SizeOfCentralDirectory","d":2291090,"h":38656996754,"f":33},{"t":655361,"n":"OffsetOfCentralDirectory","d":2291090,"h":42951964050,"f":33}],"d":2160018,"h":2291090}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.Zip64EndOfCentralDirectoryRecord.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            static /*Task<Zip64EndOfCentralDirectoryRecord> *//*async*/  TryReadBlockAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord), $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [56/*BlockConstantSectionSize*/], null);
                    /*int*/ let bytesRead = await stream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(blockContents), blockContents.length, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    /*Zip64EndOfCentralDirectoryRecord?*/ let zip64EOCDRecord;
                    if (!$.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.TryReadBlockCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockContents), bytesRead, $.$ref(() => zip64EOCDRecord, ($v) => zip64EOCDRecord = $v, $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord)))
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.Zip64EOCDNotWhereExpected);
                    }
                    return zip64EOCDRecord;
                });
            }
            static /*ValueTask */ WriteBlockAsync(/*Stream*/ stream, /*long*/ numberOfEntries, /*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory, /*CancellationToken*/ cancellationToken)
            {
                cancellationToken.ThrowIfCancellationRequested();
                /*byte[]*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [56/*BlockConstantSectionSize*/], null);
                $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.WriteBlockCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockContents), numberOfEntries, startOfCentralDirectory, sizeOfCentralDirectory);
                return stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(blockContents), cancellationToken);
            }
            static /*ReadOnlySpan<byte> */ get SignatureConstantBytes()
            {
                return this.$cacheSignatureConstantBytes ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 80, 75, 6, 6 ]);
            }
            /*int*/ static BlockConstantSectionSize = 56;
            /*ulong*/ static NormalSize = 0x2Cn;
            /*long*/ static TotalSize = 56n;
            /*ulong*/ SizeOfThisRecord = 0n;
            /*ushort*/ VersionMadeBy = 0;
            /*ushort*/ VersionNeededToExtract = 0;
            /*uint*/ NumberOfThisDisk = 0;
            /*uint*/ NumberOfDiskWithStartOfCD = 0;
            /*ulong*/ NumberOfEntriesOnThisDisk = 0n;
            /*ulong*/ NumberOfEntriesTotal = 0n;
            /*ulong*/ SizeOfCentralDirectory = 0n;
            /*ulong*/ OffsetOfCentralDirectory = 0n;
            static /*bool */ TryReadBlockCore(/*Span<byte>*/ blockContents, /*int*/ bytesRead, /*out Zip64EndOfCentralDirectoryRecord?*/ zip64EOCDRecord)
            {
                zip64EOCDRecord.$v = null;
                if (bytesRead < 56/*BlockConstantSectionSize*/)
                {
                    return false;
                }
                if (!$.$spc.System.MemoryExtensions.StartsWith$1($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockContents), $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.SignatureConstantBytes))
                {
                    return false;
                }
                zip64EOCDRecord.$v = (() =>
                {
                    //new $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord()
                    const $t1 = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord;
                    const $i1 = new $t1();
                    let $t2 = blockContents;
                    $i1.SizeOfThisRecord = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t2.Slice$1(4/*FieldLocations.SizeOfThisRecord*/, $t2.Length - 4/*FieldLocations.SizeOfThisRecord*/)));
                    let $t3 = blockContents;
                    $i1.VersionMadeBy = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t3.Slice$1(12/*FieldLocations.VersionMadeBy*/, $t3.Length - 12/*FieldLocations.VersionMadeBy*/)));
                    let $t4 = blockContents;
                    $i1.VersionNeededToExtract = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t4.Slice$1(14/*FieldLocations.VersionNeededToExtract*/, $t4.Length - 14/*FieldLocations.VersionNeededToExtract*/)));
                    let $t5 = blockContents;
                    $i1.NumberOfThisDisk = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t5.Slice$1(16/*FieldLocations.NumberOfThisDisk*/, $t5.Length - 16/*FieldLocations.NumberOfThisDisk*/)));
                    let $t6 = blockContents;
                    $i1.NumberOfDiskWithStartOfCD = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t6.Slice$1(20/*FieldLocations.NumberOfDiskWithStartOfCD*/, $t6.Length - 20/*FieldLocations.NumberOfDiskWithStartOfCD*/)));
                    let $t7 = blockContents;
                    $i1.NumberOfEntriesOnThisDisk = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t7.Slice$1(24/*FieldLocations.NumberOfEntriesOnThisDisk*/, $t7.Length - 24/*FieldLocations.NumberOfEntriesOnThisDisk*/)));
                    let $t8 = blockContents;
                    $i1.NumberOfEntriesTotal = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t8.Slice$1(32/*FieldLocations.NumberOfEntriesTotal*/, $t8.Length - 32/*FieldLocations.NumberOfEntriesTotal*/)));
                    let $t9 = blockContents;
                    $i1.SizeOfCentralDirectory = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t9.Slice$1(40/*FieldLocations.SizeOfCentralDirectory*/, $t9.Length - 40/*FieldLocations.SizeOfCentralDirectory*/)));
                    let $t10 = blockContents;
                    $i1.OffsetOfCentralDirectory = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t10.Slice$1(48/*FieldLocations.OffsetOfCentralDirectory*/, $t10.Length - 48/*FieldLocations.OffsetOfCentralDirectory*/)));
                    return $i1;
                })();
                return true;
            }
            static /*Zip64EndOfCentralDirectoryRecord */ TryReadBlock(/*Stream*/ stream)
            {
                /*Span<byte>*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 56/*BlockConstantSectionSize*/, null);
                /*int*/ let bytesRead = stream.ReadAtLeast(blockContents, blockContents.Length, false);
                /*Zip64EndOfCentralDirectoryRecord?*/ let zip64EOCDRecord;
                if (!$.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.TryReadBlockCore(blockContents, bytesRead, $.$ref(() => zip64EOCDRecord, ($v) => zip64EOCDRecord = $v, $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord)))
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.Zip64EOCDNotWhereExpected);
                }
                return zip64EOCDRecord;
            }
            static /*void */ WriteBlockCore(/*Span<byte>*/ blockContents, /*long*/ numberOfEntries, /*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory)
            {
                let $t1 = blockContents;
                $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.SignatureConstantBytes.CopyTo($t1.Slice$1(0/*FieldLocations.Signature*/, $t1.Length - 0/*FieldLocations.Signature*/));
                let $t2 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt64LittleEndian($t2.Slice$1(4/*FieldLocations.SizeOfThisRecord*/, $t2.Length - 4/*FieldLocations.SizeOfThisRecord*/), 44n);
                let $t3 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t3.Slice$1(12/*FieldLocations.VersionMadeBy*/, $t3.Length - 12/*FieldLocations.VersionMadeBy*/), 45/*ZipVersionNeededValues.Zip64*/);
                let $t4 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t4.Slice$1(14/*FieldLocations.VersionNeededToExtract*/, $t4.Length - 14/*FieldLocations.VersionNeededToExtract*/), 45/*ZipVersionNeededValues.Zip64*/);
                let $t5 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t5.Slice$1(16/*FieldLocations.NumberOfThisDisk*/, $t5.Length - 16/*FieldLocations.NumberOfThisDisk*/), 0);
                let $t6 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t6.Slice$1(20/*FieldLocations.NumberOfDiskWithStartOfCD*/, $t6.Length - 20/*FieldLocations.NumberOfDiskWithStartOfCD*/), 0);
                let $t7 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t7.Slice$1(24/*FieldLocations.NumberOfEntriesOnThisDisk*/, $t7.Length - 24/*FieldLocations.NumberOfEntriesOnThisDisk*/), numberOfEntries);
                let $t8 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t8.Slice$1(32/*FieldLocations.NumberOfEntriesTotal*/, $t8.Length - 32/*FieldLocations.NumberOfEntriesTotal*/), numberOfEntries);
                let $t9 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t9.Slice$1(40/*FieldLocations.SizeOfCentralDirectory*/, $t9.Length - 40/*FieldLocations.SizeOfCentralDirectory*/), sizeOfCentralDirectory);
                let $t10 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t10.Slice$1(48/*FieldLocations.OffsetOfCentralDirectory*/, $t10.Length - 48/*FieldLocations.OffsetOfCentralDirectory*/), startOfCentralDirectory);
            }
            static /*void */ WriteBlock(/*Stream*/ stream, /*long*/ numberOfEntries, /*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory)
            {
                /*Span<byte>*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 56/*BlockConstantSectionSize*/, null);
                $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.WriteBlockCore(blockContents, numberOfEntries, startOfCentralDirectory, sizeOfCentralDirectory);
                stream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockContents));
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2160018;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":25771963794,"f":33},"n":"SignatureConstantBytes","d":2160018,"h":21476996498,"f":33}],"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord).$h,"p":[{"n":"stream","p":62193665},{"n":"cancellationToken","p":125960193}],"n":"TryReadBlockAsync","d":2160018,"h":12887061906,"f":4129},{"r":136118273,"p":[{"n":"stream","p":62193665},{"n":"numberOfEntries","p":917505},{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505},{"n":"cancellationToken","p":125960193}],"n":"WriteBlockAsync","d":2160018,"h":17182029202,"f":33},{"r":262145,"p":[{"n":"blockContents","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesRead","p":655361},{"n":"zip64EOCDRecord","p":2160018,"f":2}],"n":"TryReadBlockCore","d":2160018,"h":81606538642,"f":34},{"r":2160018,"p":[{"n":"stream","p":62193665}],"n":"TryReadBlock","d":2160018,"h":85901505938,"f":33},{"r":65537,"p":[{"n":"blockContents","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"numberOfEntries","p":917505},{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505}],"n":"WriteBlockCore","d":2160018,"h":90196473234,"f":34},{"r":65537,"p":[{"n":"stream","p":62193665},{"n":"numberOfEntries","p":917505},{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505}],"n":"WriteBlock","d":2160018,"h":94491440530,"f":33}],"l":[{"t":655361,"n":"BlockConstantSectionSize","d":2160018,"h":30066931090,"f":34},{"t":983041,"n":"NormalSize","d":2160018,"h":34361898386,"f":34},{"t":917505,"n":"TotalSize","d":2160018,"h":38656865682,"f":33},{"t":983041,"n":"SizeOfThisRecord","d":2160018,"h":42951832978,"f":1},{"t":589825,"n":"VersionMadeBy","d":2160018,"h":47246800274,"f":1},{"t":589825,"n":"VersionNeededToExtract","d":2160018,"h":51541767570,"f":1},{"t":720897,"n":"NumberOfThisDisk","d":2160018,"h":55836734866,"f":1},{"t":720897,"n":"NumberOfDiskWithStartOfCD","d":2160018,"h":60131702162,"f":1},{"t":983041,"n":"NumberOfEntriesOnThisDisk","d":2160018,"h":64426669458,"f":1},{"t":983041,"n":"NumberOfEntriesTotal","d":2160018,"h":68721636754,"f":1},{"t":983041,"n":"SizeOfCentralDirectory","d":2160018,"h":73016604050,"f":1},{"t":983041,"n":"OffsetOfCentralDirectory","d":2160018,"h":77311571346,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":2160018,"h":98786407826,"f":1}],"j":[2225554,2291090],"h":2160018}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Zip64EndOfCentralDirectoryRecord`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.InflaterManaged", ($self) => class InflaterManaged extends $.$spc.System.Object
        {
            static /*ReadOnlySpan<byte> */ get ExtraLengthBits()
            {
                return this.$cacheExtraLengthBits ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 16 ]);
            }
            static /*ReadOnlySpan<byte> */ get LengthBase()
            {
                return this.$cacheLengthBase ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 3 ]);
            }
            static /*ReadOnlySpan<ushort> */ get DistanceBasePosition()
            {
                return this.$cacheDistanceBasePosition ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16))().$ctor$2([ 1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 32769, 49153 ]);
            }
            static /*ReadOnlySpan<byte> */ get CodeOrder()
            {
                return this.$cacheCodeOrder ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15 ]);
            }
            static /*ReadOnlySpan<byte> */ get StaticDistanceTreeTable()
            {
                return this.$cacheStaticDistanceTreeTable ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 0, 16, 8, 24, 4, 20, 12, 28, 2, 18, 10, 26, 6, 22, 14, 30, 1, 17, 9, 25, 5, 21, 13, 29, 3, 19, 11, 27, 7, 23, 15, 31 ]);
            }
            /*OutputWindow*/ _output = null;
            /*InputBuffer*/ _input = null;
            /*HuffmanTree?*/ _literalLengthTree = null;
            /*HuffmanTree?*/ _distanceTree = null;
            /*InflaterState*/ _state = 0;
            /*int*/ _bfinal = 0;
            /*BlockType*/ _blockType = 0;
            /*byte[]*/ _blockLengthBuffer = null;
            /*int*/ _blockLength = 0;
            /*int*/ _length = 0;
            /*int*/ _distanceCode = 0;
            /*int*/ _extraBits = 0;
            /*int*/ _loopCounter = 0;
            /*int*/ _literalLengthCodeCount = 0;
            /*int*/ _distanceCodeCount = 0;
            /*int*/ _codeLengthCodeCount = 0;
            /*int*/ _codeArraySize = 0;
            /*int*/ _lengthCode = 0;
            /*byte[]*/ _codeList = null;
            /*byte[]*/ _codeLengthTreeCodeLength = null;
            /*bool*/ _deflate64 = false;
            /*HuffmanTree?*/ _codeLengthTree = null;
            /*long*/ _uncompressedSize = 0n;
            /*long*/ _currentInflatedCount = 0n;
            $ctor$1(/*bool*/ deflate64, /*long*/ uncompressedSize)
            {
                super.$ctor();
                {
                    this._output = new $.$sic.System.IO.Compression.OutputWindow().$ctor$1();
                    this._input = new $.$sic.System.IO.Compression.InputBuffer().$ctor$1();
                    this._codeList = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [((288/*HuffmanTree.MaxLiteralTreeElements*/ + 32/*HuffmanTree.MaxDistTreeElements*/) | 0)], null);
                    this._codeLengthTreeCodeLength = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [19/*HuffmanTree.NumberOfCodeLengthTreeElements*/], null);
                    this._deflate64 = deflate64;
                    this._uncompressedSize = uncompressedSize;
                    this._state = 2/*InflaterState.ReadingBFinal*/;
                }
                return this;
            }
            /*void */ SetInput(/*Memory<byte>*/ inputBytes)
            {
                return this._input.SetInput(inputBytes);
            }
            /*void */ SetInput$1(/*byte[]*/ inputBytes, /*int*/ offset, /*int*/ length)
            {
                return this._input.SetInput$1(inputBytes, offset, length);
            }
            /*bool */ Finished()
            {
                return this._state === 24/*InflaterState.Done*/ || this._state === 23/*InflaterState.VerifyingFooter*/;
            }
            /*int */ get AvailableOutput()
            {
                return this._output.AvailableBytes;
            }
            /*int */ Inflate(/*Span<byte>*/ bytes)
            {
                /*int*/ let count = 0;
                do
                {
                    /*int*/ let copied = 0;
                    if (this._uncompressedSize === BigInt(-1))
                    {
                        copied = this._output.CopyTo(bytes);
                    }
                    else 
                    {
                        if (this._uncompressedSize > this._currentInflatedCount)
                        {
                            bytes = bytes.Slice$1(0, $.$cast($.$spc.System.Math.Min$5(BigInt(bytes.Length), this._uncompressedSize - this._currentInflatedCount), $.$spc.System.Int32));
                            copied = this._output.CopyTo(bytes);
                            this._currentInflatedCount += BigInt(copied);
                        }
                        else 
                        {
                            this._state = 24/*InflaterState.Done*/;
                            this._output.ClearBytesUsed();
                        }
                    }
                    if (copied > 0)
                    {
                        bytes = bytes.Slice(copied);
                        count += copied;
                    }
                    if (bytes.IsEmpty)
                    {
                        break;
                    }
                }
                while(!this.Finished() && this.Decode());
                return count;
            }
            /*int */ Inflate$1(/*byte[]*/ bytes, /*int*/ offset, /*int*/ length)
            {
                return this.Inflate($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, bytes, offset, length));
            }
            /*bool */ Decode()
            {
                /*bool*/ let eob = false;
                /*bool*/ let result;
                if (this.Finished())
                {
                    return true;
                }
                if (this._state === 2/*InflaterState.ReadingBFinal*/)
                {
                    if (!this._input.EnsureBitsAvailable(1))
                    {
                        return false;
                    }
                    this._bfinal = this._input.GetBits(1);
                    this._state = 3/*InflaterState.ReadingBType*/;
                }
                if (this._state === 3/*InflaterState.ReadingBType*/)
                {
                    if (!this._input.EnsureBitsAvailable(2))
                    {
                        this._state = 3/*InflaterState.ReadingBType*/;
                        return false;
                    }
                    this._blockType = $.$cast(this._input.GetBits(2), $.$sic.System.IO.Compression.BlockType);
                    if (this._blockType === 2/*BlockType.Dynamic*/)
                    {
                        this._state = 4/*InflaterState.ReadingNumLitCodes*/;
                    }
                    else if (this._blockType === 1/*BlockType.Static*/)
                    {
                        this._literalLengthTree = $.$sic.System.IO.Compression.HuffmanTree.StaticLiteralLengthTree;
                        this._distanceTree = $.$sic.System.IO.Compression.HuffmanTree.StaticDistanceTree;
                        this._state = 10/*InflaterState.DecodeTop*/;
                    }
                    else if (this._blockType === 0/*BlockType.Uncompressed*/)
                    {
                        this._state = 15/*InflaterState.UncompressedAligning*/;
                    }
                    else 
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.UnknownBlockType);
                    }
                }
                if (this._blockType === 2/*BlockType.Dynamic*/)
                {
                    if (this._state < 10/*InflaterState.DecodeTop*/)
                    {
                        result = this.DecodeDynamicBlockHeader();
                    }
                    else 
                    {
                        result = this.DecodeBlock($.$ref(() => eob, ($v) => eob = $v, $.$spc.System.Boolean));
                    }
                }
                else if (this._blockType === 1/*BlockType.Static*/)
                {
                    result = this.DecodeBlock($.$ref(() => eob, ($v) => eob = $v, $.$spc.System.Boolean));
                }
                else if (this._blockType === 0/*BlockType.Uncompressed*/)
                {
                    result = this.DecodeUncompressedBlock($.$ref(() => eob, ($v) => eob = $v, $.$spc.System.Boolean));
                }
                else 
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.UnknownBlockType);
                }
                if (eob && (this._bfinal !== 0))
                {
                    this._state = 24/*InflaterState.Done*/;
                }
                return result;
            }
            /*bool */ DecodeUncompressedBlock(/*out bool*/ end_of_block)
            {
                end_of_block.$v = false;
                while(true)
                {
                    let $switchJumpState1;
                    $switchJumpStart1: while(true)
                    {
                        switch($switchJumpState1 ?? this._state)
                        {
                            case 15/*InflaterState.UncompressedAligning*/:
                            this._input.SkipToByteBoundary();
                            this._state = 16/*InflaterState.UncompressedByte1*/;
                            $switchJumpState1 = 16/*InflaterState.UncompressedByte1*/; /*goto case InflaterState.UncompressedByte1*/
                            continue $switchJumpStart1;
                            case 16/*InflaterState.UncompressedByte1*/:
                            case 17/*InflaterState.UncompressedByte2*/:
                            case 18/*InflaterState.UncompressedByte3*/:
                            case 19/*InflaterState.UncompressedByte4*/:
                            /*int*/ let bits = this._input.GetBits(8);
                            if (bits < 0)
                            {
                                return false;
                            }
                            $.$spc.System.Array.$WriteT1.call(this._blockLengthBuffer, $.$cast(bits, $.$spc.System.Byte), this._state - 16/*InflaterState.UncompressedByte1*/);
                            if (this._state === 19/*InflaterState.UncompressedByte4*/)
                            {
                                this._blockLength = (($.$spc.System.Array.$ReadT1.call(this._blockLengthBuffer, 0) + ((($.$cast($.$spc.System.Array.$ReadT1.call(this._blockLengthBuffer, 1), $.$spc.System.Int32)) * 256) | 0)) | 0);
                                /*int*/ let blockLengthComplement = (($.$spc.System.Array.$ReadT1.call(this._blockLengthBuffer, 2) + ((($.$cast($.$spc.System.Array.$ReadT1.call(this._blockLengthBuffer, 3), $.$spc.System.Int32)) * 256) | 0)) | 0);
                                if ($.$cast(this._blockLength, $.$spc.System.UInt16) !== $.$cast((~blockLengthComplement), $.$spc.System.UInt16))
                                {
                                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.InvalidBlockLength);
                                }
                            }
                            this._state += 1;
                            break;
                            case 20/*InflaterState.DecodingUncompressed*/:
                            /*int*/ let bytesCopied = this._output.CopyFrom(this._input, this._blockLength);
                            this._blockLength -= bytesCopied;
                            if (this._blockLength === 0)
                            {
                                this._state = 2/*InflaterState.ReadingBFinal*/;
                                end_of_block.$v = true;
                                return true;
                            }
                            if (this._output.FreeBytes === 0)
                            {
                                return true;
                            }
                            return false;
                            default:
                            $.$spc.System.Diagnostics.Debug.Fail("check why we are here!");
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.UnknownState);
                        }
                        break;
                    }
                }
            }
            /*bool */ DecodeBlock(/*out bool*/ end_of_block_code_seen)
            {
                end_of_block_code_seen.$v = false;
                /*int*/ let freeBytes = this._output.FreeBytes;
                while(freeBytes > 65536)
                {
                    /*int*/ let symbol;
                    let $switchJumpState1;
                    $switchJumpStart1: while(true)
                    {
                        switch($switchJumpState1 ?? this._state)
                        {
                            case 10/*InflaterState.DecodeTop*/:
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._literalLengthTree !== null, "_literalLengthTree != null");
                            symbol = this._literalLengthTree.GetNextSymbol(this._input);
                            if (symbol < 0)
                            {
                                return false;
                            }
                            if (symbol < 256)
                            {
                                this._output.Write($.$cast(symbol, $.$spc.System.Byte));
                                --freeBytes;
                            }
                            else if (symbol === 256)
                            {
                                end_of_block_code_seen.$v = true;
                                this._state = 2/*InflaterState.ReadingBFinal*/;
                                return true;
                            }
                            else 
                            {
                                symbol -= 257;
                                if (symbol < 8)
                                {
                                    symbol += 3;
                                    this._extraBits = 0;
                                }
                                else if (!this._deflate64 && symbol === 28)
                                {
                                    symbol = 258;
                                    this._extraBits = 0;
                                }
                                else 
                                {
                                    if (BigInt((symbol >>> 0)) >= BigInt($.$sic.System.IO.Compression.InflaterManaged.ExtraLengthBits.Length))
                                    {
                                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData);
                                    }
                                    this._extraBits = $.$sic.System.IO.Compression.InflaterManaged.ExtraLengthBits.get_Item(symbol).$v;
                                    $.$spc.System.Diagnostics.Debug.Assert$1(this._extraBits !== 0, "We handle other cases separately!");
                                }
                                this._length = symbol;
                                $switchJumpState1 = 11/*InflaterState.HaveInitialLength*/; /*goto case InflaterState.HaveInitialLength*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 11/*InflaterState.HaveInitialLength*/:
                            if (this._extraBits > 0)
                            {
                                this._state = 11/*InflaterState.HaveInitialLength*/;
                                /*int*/ let bits = this._input.GetBits(this._extraBits);
                                if (bits < 0)
                                {
                                    return false;
                                }
                                if (this._length < 0 || this._length >= $.$sic.System.IO.Compression.InflaterManaged.LengthBase.Length)
                                {
                                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData);
                                }
                                this._length = (($.$sic.System.IO.Compression.InflaterManaged.LengthBase.get_Item(this._length).$v + bits) | 0);
                            }
                            this._state = 12/*InflaterState.HaveFullLength*/;
                            $switchJumpState1 = 12/*InflaterState.HaveFullLength*/; /*goto case InflaterState.HaveFullLength*/
                            continue $switchJumpStart1;
                            case 12/*InflaterState.HaveFullLength*/:
                            if (this._blockType === 2/*BlockType.Dynamic*/)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._distanceTree !== null, "_distanceTree != null");
                                this._distanceCode = this._distanceTree.GetNextSymbol(this._input);
                            }
                            else 
                            {
                                this._distanceCode = this._input.GetBits(5);
                                if (this._distanceCode >= 0)
                                {
                                    this._distanceCode = $.$sic.System.IO.Compression.InflaterManaged.StaticDistanceTreeTable.get_Item(this._distanceCode).$v;
                                }
                            }
                            if (this._distanceCode < 0)
                            {
                                return false;
                            }
                            this._state = 13/*InflaterState.HaveDistCode*/;
                            $switchJumpState1 = 13/*InflaterState.HaveDistCode*/; /*goto case InflaterState.HaveDistCode*/
                            continue $switchJumpStart1;
                            case 13/*InflaterState.HaveDistCode*/:
                            /*int*/ let offset;
                            if (this._distanceCode > 3)
                            {
                                this._extraBits = (((this._distanceCode - 2) | 0)) >> 1;
                                /*int*/ let bits = this._input.GetBits(this._extraBits);
                                if (bits < 0)
                                {
                                    return false;
                                }
                                offset = (($.$sic.System.IO.Compression.InflaterManaged.DistanceBasePosition.get_Item(this._distanceCode).$v + bits) | 0);
                            }
                            else 
                            {
                                offset = ((this._distanceCode + 1) | 0);
                            }
                            this._output.WriteLengthDistance(this._length, offset);
                            freeBytes -= this._length;
                            this._state = 10/*InflaterState.DecodeTop*/;
                            break;
                            default:
                            $.$spc.System.Diagnostics.Debug.Fail("check why we are here!");
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.UnknownState);
                        }
                        break;
                    }
                }
                return true;
            }
            /*bool */ DecodeDynamicBlockHeader()
            {
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    switch($switchJumpState1 ?? this._state)
                    {
                        case 4/*InflaterState.ReadingNumLitCodes*/:
                        this._literalLengthCodeCount = this._input.GetBits(5);
                        if (this._literalLengthCodeCount < 0)
                        {
                            return false;
                        }
                        this._literalLengthCodeCount += 257;
                        this._state = 5/*InflaterState.ReadingNumDistCodes*/;
                        $switchJumpState1 = 5/*InflaterState.ReadingNumDistCodes*/; /*goto case InflaterState.ReadingNumDistCodes*/
                        continue $switchJumpStart1;
                        case 5/*InflaterState.ReadingNumDistCodes*/:
                        this._distanceCodeCount = this._input.GetBits(5);
                        if (this._distanceCodeCount < 0)
                        {
                            return false;
                        }
                        this._distanceCodeCount += 1;
                        this._state = 6/*InflaterState.ReadingNumCodeLengthCodes*/;
                        $switchJumpState1 = 6/*InflaterState.ReadingNumCodeLengthCodes*/; /*goto case InflaterState.ReadingNumCodeLengthCodes*/
                        continue $switchJumpStart1;
                        case 6/*InflaterState.ReadingNumCodeLengthCodes*/:
                        this._codeLengthCodeCount = this._input.GetBits(4);
                        if (this._codeLengthCodeCount < 0)
                        {
                            return false;
                        }
                        this._codeLengthCodeCount += 4;
                        this._loopCounter = 0;
                        this._state = 7/*InflaterState.ReadingCodeLengthCodes*/;
                        $switchJumpState1 = 7/*InflaterState.ReadingCodeLengthCodes*/; /*goto case InflaterState.ReadingCodeLengthCodes*/
                        continue $switchJumpStart1;
                        case 7/*InflaterState.ReadingCodeLengthCodes*/:
                        while(this._loopCounter < this._codeLengthCodeCount)
                        {
                            /*int*/ let bits = this._input.GetBits(3);
                            if (bits < 0)
                            {
                                return false;
                            }
                            $.$spc.System.Array.$WriteT1.call(this._codeLengthTreeCodeLength, $.$cast(bits, $.$spc.System.Byte), $.$sic.System.IO.Compression.InflaterManaged.CodeOrder.get_Item(this._loopCounter).$v);
                            ++this._loopCounter;
                        }
                        for(/*int*/ let i = this._codeLengthCodeCount; i < $.$sic.System.IO.Compression.InflaterManaged.CodeOrder.Length; i++)
                        {
                            $.$spc.System.Array.$WriteT1.call(this._codeLengthTreeCodeLength, 0, $.$sic.System.IO.Compression.InflaterManaged.CodeOrder.get_Item(i).$v);
                        }
                        this._codeLengthTree = new $.$sic.System.IO.Compression.HuffmanTree().$ctor$1(this._codeLengthTreeCodeLength);
                        this._codeArraySize = ((this._literalLengthCodeCount + this._distanceCodeCount) | 0);
                        this._loopCounter = 0;
                        this._state = 8/*InflaterState.ReadingTreeCodesBefore*/;
                        $switchJumpState1 = 8/*InflaterState.ReadingTreeCodesBefore*/; /*goto case InflaterState.ReadingTreeCodesBefore*/
                        continue $switchJumpStart1;
                        case 8/*InflaterState.ReadingTreeCodesBefore*/:
                        case 9/*InflaterState.ReadingTreeCodesAfter*/:
                        while(this._loopCounter < this._codeArraySize)
                        {
                            if (this._state === 8/*InflaterState.ReadingTreeCodesBefore*/)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._codeLengthTree !== null, "_codeLengthTree != null");
                                if ((this._lengthCode = this._codeLengthTree.GetNextSymbol(this._input)) < 0)
                                {
                                    return false;
                                }
                            }
                            if (this._lengthCode <= 15)
                            {
                                $.$spc.System.Array.$WriteT1.call(this._codeList, $.$cast(this._lengthCode, $.$spc.System.Byte), this._loopCounter++);
                            }
                            else 
                            {
                                /*int*/ let repeatCount;
                                if (this._lengthCode === 16)
                                {
                                    if (!this._input.EnsureBitsAvailable(2))
                                    {
                                        this._state = 9/*InflaterState.ReadingTreeCodesAfter*/;
                                        return false;
                                    }
                                    if (this._loopCounter === 0)
                                    {
                                        throw new $.$spc.System.IO.InvalidDataException().$ctor$9();
                                    }
                                    /*byte*/ let previousCode = $.$spc.System.Array.$ReadT1.call(this._codeList, ((this._loopCounter - 1) | 0));
                                    repeatCount = ((this._input.GetBits(2) + 3) | 0);
                                    if (((this._loopCounter + repeatCount) | 0) > this._codeArraySize)
                                    {
                                        throw new $.$spc.System.IO.InvalidDataException().$ctor$9();
                                    }
                                    for(/*int*/ let j = 0; j < repeatCount; j++)
                                    {
                                        $.$spc.System.Array.$WriteT1.call(this._codeList, previousCode, this._loopCounter++);
                                    }
                                }
                                else if (this._lengthCode === 17)
                                {
                                    if (!this._input.EnsureBitsAvailable(3))
                                    {
                                        this._state = 9/*InflaterState.ReadingTreeCodesAfter*/;
                                        return false;
                                    }
                                    repeatCount = ((this._input.GetBits(3) + 3) | 0);
                                    if (((this._loopCounter + repeatCount) | 0) > this._codeArraySize)
                                    {
                                        throw new $.$spc.System.IO.InvalidDataException().$ctor$9();
                                    }
                                    for(/*int*/ let j = 0; j < repeatCount; j++)
                                    {
                                        $.$spc.System.Array.$WriteT1.call(this._codeList, 0, this._loopCounter++);
                                    }
                                }
                                else 
                                {
                                    if (!this._input.EnsureBitsAvailable(7))
                                    {
                                        this._state = 9/*InflaterState.ReadingTreeCodesAfter*/;
                                        return false;
                                    }
                                    repeatCount = ((this._input.GetBits(7) + 11) | 0);
                                    if (((this._loopCounter + repeatCount) | 0) > this._codeArraySize)
                                    {
                                        throw new $.$spc.System.IO.InvalidDataException().$ctor$9();
                                    }
                                    for(/*int*/ let j = 0; j < repeatCount; j++)
                                    {
                                        $.$spc.System.Array.$WriteT1.call(this._codeList, 0, this._loopCounter++);
                                    }
                                }
                            }
                            this._state = 8/*InflaterState.ReadingTreeCodesBefore*/;
                        }
                        break;
                        default:
                        $.$spc.System.Diagnostics.Debug.Fail("check why we are here!");
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.UnknownState);
                    }
                    break;
                }
                /*byte[]*/ let literalTreeCodeLength = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [288/*HuffmanTree.MaxLiteralTreeElements*/], null);
                /*byte[]*/ let distanceTreeCodeLength = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [32/*HuffmanTree.MaxDistTreeElements*/], null);
                $.$spc.System.Array.Copy(this._codeList, literalTreeCodeLength, this._literalLengthCodeCount);
                $.$spc.System.Array.Copy$1(this._codeList, this._literalLengthCodeCount, distanceTreeCodeLength, 0, this._distanceCodeCount);
                if ($.$spc.System.Array.$ReadT1.call(literalTreeCodeLength, 256/*HuffmanTree.EndOfBlockCode*/) === 0)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$9();
                }
                this._literalLengthTree = new $.$sic.System.IO.Compression.HuffmanTree().$ctor$1(literalTreeCodeLength);
                this._distanceTree = new $.$sic.System.IO.Compression.HuffmanTree().$ctor$1(distanceTreeCodeLength);
                this._state = 10/*InflaterState.DecodeTop*/;
                return true;
            }
            //default member initializer
            constructor()
            {
                super();
                this._blockLengthBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [4], null);
            }
            static $h = 1439122;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":8591373714,"f":34},"n":"ExtraLengthBits","d":1439122,"h":4296406418,"f":34},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":17181308306,"f":34},"n":"LengthBase","d":1439122,"h":12886341010,"f":34},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16).$h,"g":{"r":0,"d":0,"h":25771242898,"f":34},"n":"DistanceBasePosition","d":1439122,"h":21476275602,"f":34},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":34361177490,"f":34},"n":"CodeOrder","d":1439122,"h":30066210194,"f":34},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":42951112082,"f":34},"n":"StaticDistanceTreeTable","d":1439122,"h":38656144786,"f":34},{"p":655361,"g":{"r":0,"d":0,"h":171800130962,"f":1},"n":"AvailableOutput","d":1439122,"h":167505163666,"f":1}],"m":[{"r":65537,"p":[{"n":"inputBytes","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h}],"n":"SetInput","d":1439122,"h":154620261778,"f":1},{"r":65537,"p":[{"n":"inputBytes","p":0},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"SetInput","o":"@$1","d":1439122,"h":158915229074,"f":1},{"r":262145,"n":"Finished","d":1439122,"h":163210196370,"f":1},{"r":655361,"p":[{"n":"bytes","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Inflate","d":1439122,"h":176095098258,"f":1},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"Inflate","o":"@$1","d":1439122,"h":180390065554,"f":1},{"r":262145,"n":"Decode","d":1439122,"h":184685032850,"f":2},{"r":262145,"p":[{"n":"end_of_block","p":262145,"f":2}],"n":"DecodeUncompressedBlock","d":1439122,"h":188980000146,"f":2},{"r":262145,"p":[{"n":"end_of_block_code_seen","p":262145,"f":2}],"n":"DecodeBlock","d":1439122,"h":193274967442,"f":2},{"r":262145,"n":"DecodeDynamicBlockHeader","d":1439122,"h":197569934738,"f":2}],"l":[{"t":1701266,"n":"_output","d":1439122,"h":47246079378,"f":2},{"t":1570194,"n":"_input","d":1439122,"h":51541046674,"f":2},{"t":1308050,"n":"_literalLengthTree","d":1439122,"h":55836013970,"f":2},{"t":1308050,"n":"_distanceTree","d":1439122,"h":60130981266,"f":2},{"t":1504658,"n":"_state","d":1439122,"h":64425948562,"f":2},{"t":655361,"n":"_bfinal","d":1439122,"h":68720915858,"f":2},{"t":652690,"n":"_blockType","d":1439122,"h":73015883154,"f":2},{"t":0,"n":"_blockLengthBuffer","d":1439122,"h":77310850450,"f":2},{"t":655361,"n":"_blockLength","d":1439122,"h":81605817746,"f":2},{"t":655361,"n":"_length","d":1439122,"h":85900785042,"f":2},{"t":655361,"n":"_distanceCode","d":1439122,"h":90195752338,"f":2},{"t":655361,"n":"_extraBits","d":1439122,"h":94490719634,"f":2},{"t":655361,"n":"_loopCounter","d":1439122,"h":98785686930,"f":2},{"t":655361,"n":"_literalLengthCodeCount","d":1439122,"h":103080654226,"f":2},{"t":655361,"n":"_distanceCodeCount","d":1439122,"h":107375621522,"f":2},{"t":655361,"n":"_codeLengthCodeCount","d":1439122,"h":111670588818,"f":2},{"t":655361,"n":"_codeArraySize","d":1439122,"h":115965556114,"f":2},{"t":655361,"n":"_lengthCode","d":1439122,"h":120260523410,"f":2},{"t":0,"n":"_codeList","d":1439122,"h":124555490706,"f":2},{"t":0,"n":"_codeLengthTreeCodeLength","d":1439122,"h":128850458002,"f":2},{"t":262145,"n":"_deflate64","d":1439122,"h":133145425298,"f":2},{"t":1308050,"n":"_codeLengthTree","d":1439122,"h":137440392594,"f":2},{"t":917505,"n":"_uncompressedSize","d":1439122,"h":141735359890,"f":2},{"t":917505,"n":"_currentInflatedCount","d":1439122,"h":146030327186,"f":2}],"c":[{"p":[{"n":"deflate64","p":262145},{"n":"uncompressedSize","p":917505}],"n":".ctor","o":"$ctor$1","d":1439122,"h":150325294482,"f":8}],"h":1439122}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.InflaterManaged`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZLibCompressionOptions", ($self) => class ZLibCompressionOptions extends $.$spc.System.Object
        {
            /*int*/ _compressionLevel = -1;
            /*ZLibCompressionStrategy*/ _strategy = 0;
            /*int */ get CompressionLevel()
            {
                return this._compressionLevel;
            }
            /*int */ set CompressionLevel(value)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, value, -1, "value");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, value, 9, "value");
                this._compressionLevel = value;
            }
            /*ZLibCompressionStrategy */ get CompressionStrategy()
            {
                return this._strategy;
            }
            /*ZLibCompressionStrategy */ set CompressionStrategy(value)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, value, 0/*ZLibCompressionStrategy.Default*/, "value");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, value, 4/*ZLibCompressionStrategy.Fixed*/, "value");
                this._strategy = value;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 4519314;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17184388498,"f":1},"s":{"r":0,"d":0,"h":21479355794,"f":1},"n":"CompressionLevel","d":4519314,"h":12889421202,"f":1},{"p":4584850,"g":{"r":0,"d":0,"h":30069290386,"f":1},"s":{"r":0,"d":0,"h":34364257682,"f":1},"n":"CompressionStrategy","d":4519314,"h":25774323090,"f":1}],"l":[{"t":655361,"n":"_compressionLevel","d":4519314,"h":4299486610,"f":2},{"t":4584850,"n":"_strategy","d":4519314,"h":8594453906,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":4519314,"h":38659224978,"f":1}],"h":4519314}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.ZLibCompressionOptions`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipArchiveEntryConstants", ($self) => class ZipArchiveEntryConstants
        {
            /*uint*/ static DefaultFileExternalAttributes = 2175008768;
            /*uint*/ static DefaultDirectoryExternalAttributes = 1106051072;
            static $h = 3011986;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":720897,"n":"DefaultFileExternalAttributes","d":3011986,"h":4297979282,"f":40},{"t":720897,"n":"DefaultDirectoryExternalAttributes","d":3011986,"h":8592946578,"f":40}],"h":3011986}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.ZipArchiveEntryConstants`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.HuffmanTree", ($self) => class HuffmanTree extends $.$spc.System.Object
        {
            /*int*/ static MaxLiteralTreeElements = 288;
            /*int*/ static MaxDistTreeElements = 32;
            /*int*/ static EndOfBlockCode = 256;
            /*int*/ static NumberOfCodeLengthTreeElements = 19;
            /*int*/ _tableBits = 0;
            /*short[]*/ _table = null;
            /*short[]*/ _left = null;
            /*short[]*/ _right = null;
            /*byte[]*/ _codeLengthArray = null;
            /*uint[]?*/ _codeArrayDebug = null;
            /*int*/ _tableMask = 0;
            /*HuffmanTree*/ static StaticLiteralLengthTree = null;
            /*HuffmanTree*/ static StaticDistanceTree = null;
            $ctor$1(/*byte[]*/ codeLengths)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(codeLengths.length === 288/*MaxLiteralTreeElements*/ || codeLengths.length === 32/*MaxDistTreeElements*/ || codeLengths.length === 19/*NumberOfCodeLengthTreeElements*/, "we only expect three kinds of Length here");
                    this._codeLengthArray = codeLengths;
                    if (this._codeLengthArray.length === 288/*MaxLiteralTreeElements*/)
                    {
                        this._tableBits = 9;
                    }
                    else 
                    {
                        this._tableBits = 7;
                    }
                    this._tableMask = (((1 << this._tableBits) - 1) | 0);
                    this._table = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int16), null, [1 << this._tableBits], null);
                    this._left = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int16), null, [((2 * this._codeLengthArray.length) | 0)], null);
                    this._right = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int16), null, [((2 * this._codeLengthArray.length) | 0)], null);
                    this.CreateTable();
                }
                return this;
            }
            static /*byte[] */ GetStaticLiteralTreeLength()
            {
                /*byte[]*/ let literalTreeLength = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [288/*MaxLiteralTreeElements*/], null);
                $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, literalTreeLength, 0, 144).Fill(8);
                $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, literalTreeLength, 144, 112).Fill(9);
                $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, literalTreeLength, 256, 24).Fill(7);
                $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, literalTreeLength, 280, 8).Fill(8);
                return literalTreeLength;
            }
            static /*byte[] */ GetStaticDistanceTreeLength()
            {
                /*byte[]*/ let staticDistanceTreeLength = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [32/*MaxDistTreeElements*/], null);
                $.$spc.System.Array.Fill($.$spc.System.Byte, staticDistanceTreeLength, 5);
                return staticDistanceTreeLength;
            }
            static /*uint */ BitReverse(/*uint*/ code, /*int*/ length)
            {
                /*uint*/ let new_code = 0;
                $.$spc.System.Diagnostics.Debug.Assert$1(length > 0 && length <= 16, "Invalid len");
                do
                {
                    new_code |= (code & 1);
                    new_code <<= 1;
                    code >>= 1;
                }
                while(--length > 0);
                return new_code >>> 1;
            }
            /*uint[] */ CalculateHuffmanCode()
            {
                /*Span<uint>*/ let bitLengthCount = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, 17, null);
                bitLengthCount.Clear();
                let $i1 = 0;
                let $arr1 = this._codeLengthArray;
                while ($i1 < $arr1.length)
                {
                    let codeLength = $arr1[$i1++];
                    bitLengthCount.get_Item(codeLength).$v++;
                }
                bitLengthCount.get_Item(0).$v = 0;
                /*Span<uint>*/ let nextCode = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, 17, null);
                nextCode.Clear();
                /*uint*/ let tempCode = 0;
                for(/*int*/ let bits = 1; bits <= 16; bits++)
                {
                    tempCode = ((((tempCode + bitLengthCount.get_Item(((bits - 1) | 0)).$v) >>> 0)) << 1) >>> 0;
                    nextCode.get_Item(bits).$v = tempCode;
                }
                /*uint[]*/ let code = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [288/*MaxLiteralTreeElements*/], null);
                for(/*int*/ let i = 0; i < this._codeLengthArray.length; i++)
                {
                    /*int*/ let len = $.$spc.System.Array.$ReadT1.call(this._codeLengthArray, i);
                    if (len > 0)
                    {
                        $.$spc.System.Array.$WriteT1.call(code, $.$sic.System.IO.Compression.HuffmanTree.BitReverse(nextCode.get_Item(len).$v, len), i);
                        nextCode.get_Item(len).$v++;
                    }
                }
                return code;
            }
            /*void */ CreateTable()
            {
                /*uint[]*/ let codeArray = this.CalculateHuffmanCode();
                this._codeArrayDebug = codeArray;
                /*short*/ let avail = $.$cast(this._codeLengthArray.length, $.$spc.System.Int16);
                for(/*int*/ let ch = 0; ch < this._codeLengthArray.length; ch++)
                {
                    /*int*/ let len = $.$spc.System.Array.$ReadT1.call(this._codeLengthArray, ch);
                    if (len > 0)
                    {
                        /*int*/ let start = ($.$spc.System.Array.$ReadT1.call(codeArray, ch) | 0);
                        if (len <= this._tableBits)
                        {
                            /*int*/ let increment = 1 << len;
                            if (start >= increment)
                            {
                                throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.InvalidHuffmanData);
                            }
                            /*int*/ let locs = 1 << (((this._tableBits - len) | 0));
                            for(/*int*/ let j = 0; j < locs; j++)
                            {
                                $.$spc.System.Array.$WriteT1.call(this._table, $.$cast(ch, $.$spc.System.Int16), start);
                                start += increment;
                            }
                        }
                        else 
                        {
                            /*int*/ let overflowBits = ((len - this._tableBits) | 0);
                            /*int*/ let codeBitMask = 1 << this._tableBits;
                            /*int*/ let index = start & ((((1 << this._tableBits) - 1) | 0));
                            /*short[]*/ let array = this._table;
                            do
                            {
                                /*short*/ let value = $.$spc.System.Array.$ReadT1.call(array, index);
                                if (value === 0)
                                {
                                    $.$spc.System.Array.$WriteT1.call(array, $.$cast(-avail, $.$spc.System.Int16), index);
                                    value = $.$cast(-avail, $.$spc.System.Int16);
                                    avail++;
                                }
                                if (value > 0)
                                {
                                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.InvalidHuffmanData);
                                }
                                $.$spc.System.Diagnostics.Debug.Assert$1(value < 0, "CreateTable: Only negative numbers are used for tree pointers!");
                                if ((start & codeBitMask) === 0)
                                {
                                    array = this._left;
                                }
                                else 
                                {
                                    array = this._right;
                                }
                                index = -value;
                                if (index >= array.length)
                                {
                                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.InvalidHuffmanData);
                                }
                                codeBitMask <<= 1;
                                overflowBits--;
                            }
                            while(overflowBits !== 0);
                            $.$spc.System.Array.$WriteT1.call(array, $.$cast(ch, $.$spc.System.Int16), index);
                        }
                    }
                }
            }
            /*int */ GetNextSymbol(/*InputBuffer*/ input)
            {
                /*uint*/ let bitBuffer = input.TryLoad16Bits();
                if (input.AvailableBits === 0)
                {
                    return -1;
                }
                /*int*/ let symbol = this._table[bitBuffer & this._tableMask];
                if (symbol < 0)
                {
                    /*uint*/ let mask = (1 << this._tableBits) >>> 0;
                    do
                    {
                        symbol = -symbol;
                        if ((bitBuffer & mask) === 0)
                        {
                            symbol = $.$spc.System.Array.$ReadT1.call(this._left, symbol);
                        }
                        else 
                        {
                            symbol = $.$spc.System.Array.$ReadT1.call(this._right, symbol);
                        }
                        mask <<= 1;
                    }
                    while(symbol < 0);
                }
                /*int*/ let codeLength = $.$spc.System.Array.$ReadT1.call(this._codeLengthArray, symbol);
                if (codeLength <= 0)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.InvalidHuffmanData);
                }
                if (codeLength > input.AvailableBits)
                {
                    return -1;
                }
                input.SkipBits(codeLength);
                return symbol;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.StaticLiteralLengthTree = new $.$sic.System.IO.Compression.HuffmanTree().$ctor$1($.$sic.System.IO.Compression.HuffmanTree.GetStaticLiteralTreeLength());
                }
                {
                    this.StaticDistanceTree = new $.$sic.System.IO.Compression.HuffmanTree().$ctor$1($.$sic.System.IO.Compression.HuffmanTree.GetStaticDistanceTreeLength());
                }
            }
            static $h = 1308050;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1308050,"g":{"r":0,"d":0,"h":60130850194,"f":33},"n":"StaticLiteralLengthTree","d":1308050,"h":55835882898,"f":33},{"p":1308050,"g":{"r":0,"d":0,"h":73015752082,"f":33},"n":"StaticDistanceTree","d":1308050,"h":68720784786,"f":33}],"m":[{"r":0,"n":"GetStaticLiteralTreeLength","d":1308050,"h":81605686674,"f":34},{"r":0,"n":"GetStaticDistanceTreeLength","d":1308050,"h":85900653970,"f":34},{"r":720897,"p":[{"n":"code","p":720897},{"n":"length","p":655361}],"n":"BitReverse","d":1308050,"h":90195621266,"f":34},{"r":0,"n":"CalculateHuffmanCode","d":1308050,"h":94490588562,"f":2},{"r":65537,"n":"CreateTable","d":1308050,"h":98785555858,"f":2},{"r":655361,"p":[{"n":"input","p":1570194}],"n":"GetNextSymbol","d":1308050,"h":103080523154,"f":1}],"l":[{"t":655361,"n":"MaxLiteralTreeElements","d":1308050,"h":4296275346,"f":40},{"t":655361,"n":"MaxDistTreeElements","d":1308050,"h":8591242642,"f":40},{"t":655361,"n":"EndOfBlockCode","d":1308050,"h":12886209938,"f":40},{"t":655361,"n":"NumberOfCodeLengthTreeElements","d":1308050,"h":17181177234,"f":40},{"t":655361,"n":"_tableBits","d":1308050,"h":21476144530,"f":2},{"t":0,"n":"_table","d":1308050,"h":25771111826,"f":2},{"t":0,"n":"_left","d":1308050,"h":30066079122,"f":2},{"t":0,"n":"_right","d":1308050,"h":34361046418,"f":2},{"t":0,"n":"_codeLengthArray","d":1308050,"h":38656013714,"f":2},{"t":0,"n":"_codeArrayDebug","d":1308050,"h":42950981010,"f":2},{"t":655361,"n":"_tableMask","d":1308050,"h":47245948306,"f":2}],"c":[{"p":[{"n":"codeLengths","p":0}],"n":".ctor","o":"$ctor$1","d":1308050,"h":77310719378,"f":1}],"h":1308050}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.HuffmanTree`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipCentralDirectoryFileHeader", ($self) => class ZipCentralDirectoryFileHeader extends $.$spc.System.Object
        {
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static Signature = 4;
                    /*int*/ static VersionMadeBySpecification = 1;
                    /*int*/ static VersionMadeByCompatibility = 1;
                    /*int*/ static VersionNeededToExtract = 2;
                    /*int*/ static GeneralPurposeBitFlags = 2;
                    /*int*/ static CompressionMethod = 2;
                    /*int*/ static LastModified = 4;
                    /*int*/ static Crc32 = 4;
                    /*int*/ static CompressedSize = 4;
                    /*int*/ static UncompressedSize = 4;
                    /*int*/ static FilenameLength = 2;
                    /*int*/ static ExtraFieldLength = 2;
                    /*int*/ static FileCommentLength = 2;
                    /*int*/ static DiskNumberStart = 2;
                    /*int*/ static InternalFileAttributes = 2;
                    /*int*/ static ExternalFileAttributes = 4;
                    /*int*/ static RelativeOffsetOfLocalHeader = 4;
                    static $h = 3208594;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":3208594,"h":4298175890,"f":33},{"t":655361,"n":"VersionMadeBySpecification","d":3208594,"h":8593143186,"f":33},{"t":655361,"n":"VersionMadeByCompatibility","d":3208594,"h":12888110482,"f":33},{"t":655361,"n":"VersionNeededToExtract","d":3208594,"h":17183077778,"f":33},{"t":655361,"n":"GeneralPurposeBitFlags","d":3208594,"h":21478045074,"f":33},{"t":655361,"n":"CompressionMethod","d":3208594,"h":25773012370,"f":33},{"t":655361,"n":"LastModified","d":3208594,"h":30067979666,"f":33},{"t":655361,"n":"Crc32","d":3208594,"h":34362946962,"f":33},{"t":655361,"n":"CompressedSize","d":3208594,"h":38657914258,"f":33},{"t":655361,"n":"UncompressedSize","d":3208594,"h":42952881554,"f":33},{"t":655361,"n":"FilenameLength","d":3208594,"h":47247848850,"f":33},{"t":655361,"n":"ExtraFieldLength","d":3208594,"h":51542816146,"f":33},{"t":655361,"n":"FileCommentLength","d":3208594,"h":55837783442,"f":33},{"t":655361,"n":"DiskNumberStart","d":3208594,"h":60132750738,"f":33},{"t":655361,"n":"InternalFileAttributes","d":3208594,"h":64427718034,"f":33},{"t":655361,"n":"ExternalFileAttributes","d":3208594,"h":68722685330,"f":33},{"t":655361,"n":"RelativeOffsetOfLocalHeader","d":3208594,"h":73017652626,"f":33}],"d":3143058,"h":3208594}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipCentralDirectoryFileHeader.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Signature = 0;
                    /*int*/ static VersionMadeBySpecification = 4;
                    /*int*/ static VersionMadeByCompatibility = 5;
                    /*int*/ static VersionNeededToExtract = 6;
                    /*int*/ static GeneralPurposeBitFlags = 8;
                    /*int*/ static CompressionMethod = 10;
                    /*int*/ static LastModified = 12;
                    /*int*/ static Crc32 = 16;
                    /*int*/ static CompressedSize = 20;
                    /*int*/ static UncompressedSize = 24;
                    /*int*/ static FilenameLength = 28;
                    /*int*/ static ExtraFieldLength = 30;
                    /*int*/ static FileCommentLength = 32;
                    /*int*/ static DiskNumberStart = 34;
                    /*int*/ static InternalFileAttributes = 36;
                    /*int*/ static ExternalFileAttributes = 38;
                    /*int*/ static RelativeOffsetOfLocalHeader = 42;
                    /*int*/ static DynamicData = 46;
                    static $h = 3274130;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":3274130,"h":4298241426,"f":33},{"t":655361,"n":"VersionMadeBySpecification","d":3274130,"h":8593208722,"f":33},{"t":655361,"n":"VersionMadeByCompatibility","d":3274130,"h":12888176018,"f":33},{"t":655361,"n":"VersionNeededToExtract","d":3274130,"h":17183143314,"f":33},{"t":655361,"n":"GeneralPurposeBitFlags","d":3274130,"h":21478110610,"f":33},{"t":655361,"n":"CompressionMethod","d":3274130,"h":25773077906,"f":33},{"t":655361,"n":"LastModified","d":3274130,"h":30068045202,"f":33},{"t":655361,"n":"Crc32","d":3274130,"h":34363012498,"f":33},{"t":655361,"n":"CompressedSize","d":3274130,"h":38657979794,"f":33},{"t":655361,"n":"UncompressedSize","d":3274130,"h":42952947090,"f":33},{"t":655361,"n":"FilenameLength","d":3274130,"h":47247914386,"f":33},{"t":655361,"n":"ExtraFieldLength","d":3274130,"h":51542881682,"f":33},{"t":655361,"n":"FileCommentLength","d":3274130,"h":55837848978,"f":33},{"t":655361,"n":"DiskNumberStart","d":3274130,"h":60132816274,"f":33},{"t":655361,"n":"InternalFileAttributes","d":3274130,"h":64427783570,"f":33},{"t":655361,"n":"ExternalFileAttributes","d":3274130,"h":68722750866,"f":33},{"t":655361,"n":"RelativeOffsetOfLocalHeader","d":3274130,"h":73017718162,"f":33},{"t":655361,"n":"DynamicData","d":3274130,"h":77312685458,"f":33}],"d":3143058,"h":3274130}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipCentralDirectoryFileHeader.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            static /*Task<(bool, int, ZipCentralDirectoryFileHeader?)> *//*async*/  TryReadBlockAsync(/*ReadOnlyMemory<byte>*/ buffer, /*Stream*/ furtherReads, /*bool*/ saveExtraFieldsAndComments, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.ValueTuple$$$$($.$spc.System.Boolean, $.$spc.System.Int32, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader)), $.$spc.System.ValueTuple$$$$($.$spc.System.Boolean, $.$spc.System.Int32, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader), async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*ZipCentralDirectoryFileHeader?*/ let header;
                    /*int*/ let bytesRead;
                    /*uint*/ let compressedSizeSmall;
                    /*uint*/ let uncompressedSizeSmall;
                    /*ushort*/ let diskNumberStartSmall;
                    /*uint*/ let relativeOffsetOfLocalHeaderSmall;
                    if (!$.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.TryReadBlockInitialize(buffer.Span, $.$ref(() => header, ($v) => header = $v, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => compressedSizeSmall, ($v) => compressedSizeSmall = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeSmall, ($v) => uncompressedSizeSmall = $v, $.$spc.System.UInt32), $.$ref(() => diskNumberStartSmall, ($v) => diskNumberStartSmall = $v, $.$spc.System.UInt16), $.$ref(() => relativeOffsetOfLocalHeaderSmall, ($v) => relativeOffsetOfLocalHeaderSmall = $v, $.$spc.System.UInt32)))
                    {
                        return new ($.$spc.System.ValueTuple$$$$($.$spc.System.Boolean, $.$spc.System.Int32, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader))().$ctor$2(false, 0, null);
                    }
                    /*byte[]?*/ let arrayPoolBuffer = null;
                    try
                    {
                        /*int*/ let dynamicHeaderSize = ((header.FilenameLength + header.ExtraFieldLength + header.FileCommentLength) | 0);
                        /*int*/ let remainingBufferLength = ((buffer.Length - 46/*FieldLocations.DynamicData*/) | 0);
                        /*int*/ let bytesToRead = ((dynamicHeaderSize - remainingBufferLength) | 0);
                        /*scoped ReadOnlySpan<byte>*/ let dynamicHeader;
                        if (bytesToRead <= 0)
                        {
                            let $t7 = buffer.Span;
                            dynamicHeader = $t7.Slice$1(46/*FieldLocations.DynamicData*/, $t7.Length - 46/*FieldLocations.DynamicData*/);
                        }
                        else 
                        {
                            if (dynamicHeaderSize > 512/*StackAllocationThreshold*/)
                            {
                                arrayPoolBuffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(dynamicHeaderSize);
                            }
                            /*byte[]*/ let collatedHeader = dynamicHeaderSize <= 512/*StackAllocationThreshold*/ ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [dynamicHeaderSize], null) : $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, arrayPoolBuffer, 0, dynamicHeaderSize).ToArray();
                            let $t7 = buffer;
                            $t7.Slice$1(46/*FieldLocations.DynamicData*/, $t7.Length - 46/*FieldLocations.DynamicData*/).CopyTo($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(collatedHeader));
                            $.$spc.System.Diagnostics.Debug.Assert$1(bytesToRead === $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetSubArray($.$spc.System.Byte, collatedHeader, $.$spc.System.Range.StartAt($.$spc.System.Index.op_Implicit(remainingBufferLength))).length, "bytesToRead == collatedHeader[remainingBufferLength..].Length");
                            /*int*/ let realBytesRead = await furtherReads.ReadAtLeastAsync($.$spc.System.MemoryExtensions.AsMemory$9($.$spc.System.Byte, collatedHeader, $.$spc.System.Range.StartAt($.$spc.System.Index.op_Implicit(remainingBufferLength))), bytesToRead, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                            if (realBytesRead !== bytesToRead)
                            {
                                return new ($.$spc.System.ValueTuple$$$$($.$spc.System.Boolean, $.$spc.System.Int32, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader))().$ctor$2(false, bytesRead, null);
                            }
                            dynamicHeader = $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(collatedHeader);
                        }
                        /*Zip64ExtraField*/ let zip64;
                        $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.TryReadBlockFinalize(header, dynamicHeader, dynamicHeaderSize, uncompressedSizeSmall, compressedSizeSmall, diskNumberStartSmall, relativeOffsetOfLocalHeaderSmall, saveExtraFieldsAndComments, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => zip64, ($v) => zip64 = $v, $.$sic.System.IO.Compression.Zip64ExtraField));
                    }
                    finally
                    {
                        {
                            if (arrayPoolBuffer !== null)
                            {
                                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(arrayPoolBuffer, false);
                            }
                        }
                    }
                    return new ($.$spc.System.ValueTuple$$$$($.$spc.System.Boolean, $.$spc.System.Int32, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader))().$ctor$2(true, bytesRead, header);
                });
            }
            static /*ReadOnlySpan<byte> */ get SignatureConstantBytes()
            {
                return this.$cacheSignatureConstantBytes ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 80, 75, 1, 2 ]);
            }
            /*int*/ static StackAllocationThreshold = 512;
            /*int*/ static BlockConstantSectionSize = 46;
            /*byte*/ VersionMadeByCompatibility = 0;
            /*byte*/ VersionMadeBySpecification = 0;
            /*ushort*/ VersionNeededToExtract = 0;
            /*ushort*/ GeneralPurposeBitFlag = 0;
            /*ushort*/ CompressionMethod = 0;
            /*uint*/ LastModified = 0;
            /*uint*/ Crc32 = 0;
            /*long*/ CompressedSize = 0n;
            /*long*/ UncompressedSize = 0n;
            /*ushort*/ FilenameLength = 0;
            /*ushort*/ ExtraFieldLength = 0;
            /*ushort*/ FileCommentLength = 0;
            /*uint*/ DiskNumberStart = 0;
            /*ushort*/ InternalFileAttributes = 0;
            /*uint*/ ExternalFileAttributes = 0;
            /*long*/ RelativeOffsetOfLocalHeader = 0n;
            /*byte[]*/ Filename = null;
            /*byte[]*/ FileComment = null;
            /*List<ZipGenericExtraField>?*/ ExtraFields = null;
            /*byte[]?*/ TrailingExtraFieldData = null;
            static /*bool */ TryReadBlockInitialize(/*ReadOnlySpan<byte>*/ buffer, /*out ZipCentralDirectoryFileHeader?*/ header, /*out int*/ bytesRead, /*out uint*/ compressedSizeSmall, /*out uint*/ uncompressedSizeSmall, /*out ushort*/ diskNumberStartSmall, /*out uint*/ relativeOffsetOfLocalHeaderSmall)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(buffer.Length >= 46/*BlockConstantSectionSize*/, "buffer.Length >= BlockConstantSectionSize");
                header.$v = null;
                bytesRead.$v = 0;
                compressedSizeSmall.$v = 0;
                uncompressedSizeSmall.$v = 0;
                diskNumberStartSmall.$v = 0;
                relativeOffsetOfLocalHeaderSmall.$v = 0;
                if (!$.$spc.System.MemoryExtensions.StartsWith$1($.$spc.System.Byte, buffer, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.SignatureConstantBytes))
                {
                    return false;
                }
                header.$v = (() =>
                {
                    //new $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader()
                    const $t1 = $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader;
                    const $i1 = new $t1();
                    $i1.VersionMadeBySpecification = buffer.get_Item(4/*FieldLocations.VersionMadeBySpecification*/).$v;
                    $i1.VersionMadeByCompatibility = buffer.get_Item(5/*FieldLocations.VersionMadeByCompatibility*/).$v;
                    let $t2 = buffer;
                    $i1.VersionNeededToExtract = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t2.Slice$1(6/*FieldLocations.VersionNeededToExtract*/, $t2.Length - 6/*FieldLocations.VersionNeededToExtract*/));
                    let $t3 = buffer;
                    $i1.GeneralPurposeBitFlag = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t3.Slice$1(8/*FieldLocations.GeneralPurposeBitFlags*/, $t3.Length - 8/*FieldLocations.GeneralPurposeBitFlags*/));
                    let $t4 = buffer;
                    $i1.CompressionMethod = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t4.Slice$1(10/*FieldLocations.CompressionMethod*/, $t4.Length - 10/*FieldLocations.CompressionMethod*/));
                    let $t5 = buffer;
                    $i1.LastModified = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($t5.Slice$1(12/*FieldLocations.LastModified*/, $t5.Length - 12/*FieldLocations.LastModified*/));
                    let $t6 = buffer;
                    $i1.Crc32 = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($t6.Slice$1(16/*FieldLocations.Crc32*/, $t6.Length - 16/*FieldLocations.Crc32*/));
                    let $t7 = buffer;
                    $i1.FilenameLength = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t7.Slice$1(28/*FieldLocations.FilenameLength*/, $t7.Length - 28/*FieldLocations.FilenameLength*/));
                    let $t8 = buffer;
                    $i1.ExtraFieldLength = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t8.Slice$1(30/*FieldLocations.ExtraFieldLength*/, $t8.Length - 30/*FieldLocations.ExtraFieldLength*/));
                    let $t9 = buffer;
                    $i1.FileCommentLength = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t9.Slice$1(32/*FieldLocations.FileCommentLength*/, $t9.Length - 32/*FieldLocations.FileCommentLength*/));
                    let $t10 = buffer;
                    $i1.InternalFileAttributes = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t10.Slice$1(36/*FieldLocations.InternalFileAttributes*/, $t10.Length - 36/*FieldLocations.InternalFileAttributes*/));
                    let $t11 = buffer;
                    $i1.ExternalFileAttributes = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($t11.Slice$1(38/*FieldLocations.ExternalFileAttributes*/, $t11.Length - 38/*FieldLocations.ExternalFileAttributes*/));
                    return $i1;
                })();
                let $t2 = buffer;
                compressedSizeSmall.$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($t2.Slice$1(20/*FieldLocations.CompressedSize*/, $t2.Length - 20/*FieldLocations.CompressedSize*/));
                let $t3 = buffer;
                uncompressedSizeSmall.$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($t3.Slice$1(24/*FieldLocations.UncompressedSize*/, $t3.Length - 24/*FieldLocations.UncompressedSize*/));
                let $t4 = buffer;
                diskNumberStartSmall.$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t4.Slice$1(34/*FieldLocations.DiskNumberStart*/, $t4.Length - 34/*FieldLocations.DiskNumberStart*/));
                let $t5 = buffer;
                relativeOffsetOfLocalHeaderSmall.$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($t5.Slice$1(42/*FieldLocations.RelativeOffsetOfLocalHeader*/, $t5.Length - 42/*FieldLocations.RelativeOffsetOfLocalHeader*/));
                return true;
            }
            static /*void */ TryReadBlockFinalize(/*ZipCentralDirectoryFileHeader*/ header, /*ReadOnlySpan<byte>*/ dynamicHeader, /*int*/ dynamicHeaderSize, /*uint*/ uncompressedSizeSmall, /*uint*/ compressedSizeSmall, /*ushort*/ diskNumberStartSmall, /*uint*/ relativeOffsetOfLocalHeaderSmall, /*bool*/ saveExtraFieldsAndComments, /*ref int*/ bytesRead, /*out Zip64ExtraField*/ zip64)
            {
                let $t1 = dynamicHeader;
                header.Filename = $t1.Slice$1(0, header.FilenameLength).ToArray();
                /*bool*/ let uncompressedSizeInZip64 = uncompressedSizeSmall === 4294967295/*ZipHelper.Mask32Bit*/;
                /*bool*/ let compressedSizeInZip64 = compressedSizeSmall === 4294967295/*ZipHelper.Mask32Bit*/;
                /*bool*/ let relativeOffsetInZip64 = relativeOffsetOfLocalHeaderSmall === 4294967295/*ZipHelper.Mask32Bit*/;
                /*bool*/ let diskNumberStartInZip64 = diskNumberStartSmall === 65535/*ZipHelper.Mask16Bit*/;
                /*ReadOnlySpan<byte>*/ let zipExtraFields = dynamicHeader.Slice$1(header.FilenameLength, header.ExtraFieldLength);
                if (saveExtraFieldsAndComments)
                {
                    /*ReadOnlySpan<byte>*/ let trailingDataSpan;
                    header.ExtraFields = $.$sic.System.IO.Compression.ZipGenericExtraField.ParseExtraField(zipExtraFields, $.$ref(() => trailingDataSpan, ($v) => trailingDataSpan = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)));
                    zip64.$v = $.$sic.System.IO.Compression.Zip64ExtraField.GetAndRemoveZip64Block(header.ExtraFields, uncompressedSizeInZip64, compressedSizeInZip64, relativeOffsetInZip64, diskNumberStartInZip64);
                    header.TrailingExtraFieldData = trailingDataSpan.ToArray();
                }
                else 
                {
                    header.ExtraFields = null;
                    header.TrailingExtraFieldData = null;
                    zip64.$v = $.$sic.System.IO.Compression.Zip64ExtraField.GetJustZip64Block(zipExtraFields, uncompressedSizeInZip64, compressedSizeInZip64, relativeOffsetInZip64, diskNumberStartInZip64);
                }
                header.FileComment = dynamicHeader.Slice$1(header.FilenameLength + header.ExtraFieldLength, header.FileCommentLength).ToArray();
                bytesRead.$v = ((46/*FieldLocations.DynamicData*/ + dynamicHeaderSize) | 0);
                header.UncompressedSize = zip64.$v.UncompressedSize ?? BigInt(uncompressedSizeSmall);
                header.CompressedSize = zip64.$v.CompressedSize ?? BigInt(compressedSizeSmall);
                header.RelativeOffsetOfLocalHeader = zip64.$v.LocalHeaderOffset ?? BigInt(relativeOffsetOfLocalHeaderSmall);
                header.DiskNumberStart = zip64.$v.StartDiskNumber ?? diskNumberStartSmall;
            }
            static /*bool */ TryReadBlock(/*ReadOnlySpan<byte>*/ buffer, /*Stream*/ furtherReads, /*bool*/ saveExtraFieldsAndComments, /*out int*/ bytesRead, /*out ZipCentralDirectoryFileHeader?*/ header)
            {
                /*uint*/ let compressedSizeSmall;
                /*uint*/ let uncompressedSizeSmall;
                /*ushort*/ let diskNumberStartSmall;
                /*uint*/ let relativeOffsetOfLocalHeaderSmall;
                if (!$.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.TryReadBlockInitialize(buffer, header, bytesRead, $.$ref(() => compressedSizeSmall, ($v) => compressedSizeSmall = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeSmall, ($v) => uncompressedSizeSmall = $v, $.$spc.System.UInt32), $.$ref(() => diskNumberStartSmall, ($v) => diskNumberStartSmall = $v, $.$spc.System.UInt16), $.$ref(() => relativeOffsetOfLocalHeaderSmall, ($v) => relativeOffsetOfLocalHeaderSmall = $v, $.$spc.System.UInt32)))
                {
                    return false;
                }
                /*byte[]?*/ let arrayPoolBuffer = null;
                try
                {
                    /*int*/ let dynamicHeaderSize = ((header.$v.FilenameLength + header.$v.ExtraFieldLength + header.$v.FileCommentLength) | 0);
                    /*int*/ let remainingBufferLength = ((buffer.Length - 46/*FieldLocations.DynamicData*/) | 0);
                    /*int*/ let bytesToRead = ((dynamicHeaderSize - remainingBufferLength) | 0);
                    /*scoped ReadOnlySpan<byte>*/ let dynamicHeader;
                    if (bytesToRead <= 0)
                    {
                        let $t7 = buffer;
                        dynamicHeader = $t7.Slice$1(46/*FieldLocations.DynamicData*/, $t7.Length - 46/*FieldLocations.DynamicData*/);
                    }
                    else 
                    {
                        if (dynamicHeaderSize > 512/*StackAllocationThreshold*/)
                        {
                            arrayPoolBuffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(dynamicHeaderSize);
                        }
                        /*Span<byte>*/ let collatedHeader = dynamicHeaderSize <= 512/*StackAllocationThreshold*/ ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 512/*StackAllocationThreshold*/, null).Slice$1(0, dynamicHeaderSize) : $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, arrayPoolBuffer, 0, dynamicHeaderSize);
                        let $t7 = buffer;
                        $t7.Slice$1(46/*FieldLocations.DynamicData*/, $t7.Length - 46/*FieldLocations.DynamicData*/).CopyTo(collatedHeader);
                        let $t8 = collatedHeader;
                        $.$spc.System.Diagnostics.Debug.Assert$1(bytesToRead === $t8.Slice$1(remainingBufferLength, $t8.Length - remainingBufferLength).Length, "bytesToRead == collatedHeader[remainingBufferLength..].Length");
                        let $t9 = collatedHeader;
                        /*int*/ let realBytesRead = furtherReads.ReadAtLeast($t9.Slice$1(remainingBufferLength, $t9.Length - remainingBufferLength), bytesToRead, false);
                        if (realBytesRead !== bytesToRead)
                        {
                            return false;
                        }
                        dynamicHeader = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(collatedHeader);
                    }
                    /*Zip64ExtraField*/ let zip64;
                    $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.TryReadBlockFinalize(header.$v, dynamicHeader, dynamicHeaderSize, uncompressedSizeSmall, compressedSizeSmall, diskNumberStartSmall, relativeOffsetOfLocalHeaderSmall, saveExtraFieldsAndComments, bytesRead, $.$ref(() => zip64, ($v) => zip64 = $v, $.$sic.System.IO.Compression.Zip64ExtraField));
                }
                finally
                {
                    {
                        if (arrayPoolBuffer !== null)
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(arrayPoolBuffer, false);
                        }
                    }
                }
                return true;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Filename = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [  ], null, null);
                this.FileComment = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [  ], null, null);
            }
            static $h = 3143058;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":21477979538,"f":33},"n":"SignatureConstantBytes","d":3143058,"h":17183012242,"f":33}],"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.ValueTuple$$$$($.$spc.System.Boolean, $.$spc.System.Int32, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader)).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"furtherReads","p":62193665},{"n":"saveExtraFieldsAndComments","p":262145},{"n":"cancellationToken","p":125960193}],"n":"TryReadBlockAsync","d":3143058,"h":12888044946,"f":4129},{"r":262145,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"header","p":3143058,"f":2},{"n":"bytesRead","p":655361,"f":2},{"n":"compressedSizeSmall","p":720897,"f":2},{"n":"uncompressedSizeSmall","p":720897,"f":2},{"n":"diskNumberStartSmall","p":589825,"f":2},{"n":"relativeOffsetOfLocalHeaderSmall","p":720897,"f":2}],"n":"TryReadBlockInitialize","d":3143058,"h":120262227346,"f":34},{"r":65537,"p":[{"n":"header","p":3143058},{"n":"dynamicHeader","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"dynamicHeaderSize","p":655361},{"n":"uncompressedSizeSmall","p":720897},{"n":"compressedSizeSmall","p":720897},{"n":"diskNumberStartSmall","p":589825},{"n":"relativeOffsetOfLocalHeaderSmall","p":720897},{"n":"saveExtraFieldsAndComments","p":262145},{"n":"bytesRead","p":655361,"f":4},{"n":"zip64","p":2356626,"f":2}],"n":"TryReadBlockFinalize","d":3143058,"h":124557194642,"f":34},{"r":262145,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"furtherReads","p":62193665},{"n":"saveExtraFieldsAndComments","p":262145},{"n":"bytesRead","p":655361,"f":2},{"n":"header","p":3143058,"f":2}],"n":"TryReadBlock","d":3143058,"h":128852161938,"f":33}],"l":[{"t":655361,"n":"StackAllocationThreshold","d":3143058,"h":25772946834,"f":34},{"t":655361,"n":"BlockConstantSectionSize","d":3143058,"h":30067914130,"f":33},{"t":393217,"n":"VersionMadeByCompatibility","d":3143058,"h":34362881426,"f":1},{"t":393217,"n":"VersionMadeBySpecification","d":3143058,"h":38657848722,"f":1},{"t":589825,"n":"VersionNeededToExtract","d":3143058,"h":42952816018,"f":1},{"t":589825,"n":"GeneralPurposeBitFlag","d":3143058,"h":47247783314,"f":1},{"t":589825,"n":"CompressionMethod","d":3143058,"h":51542750610,"f":1},{"t":720897,"n":"LastModified","d":3143058,"h":55837717906,"f":1},{"t":720897,"n":"Crc32","d":3143058,"h":60132685202,"f":1},{"t":917505,"n":"CompressedSize","d":3143058,"h":64427652498,"f":1},{"t":917505,"n":"UncompressedSize","d":3143058,"h":68722619794,"f":1},{"t":589825,"n":"FilenameLength","d":3143058,"h":73017587090,"f":1},{"t":589825,"n":"ExtraFieldLength","d":3143058,"h":77312554386,"f":1},{"t":589825,"n":"FileCommentLength","d":3143058,"h":81607521682,"f":1},{"t":720897,"n":"DiskNumberStart","d":3143058,"h":85902488978,"f":1},{"t":589825,"n":"InternalFileAttributes","d":3143058,"h":90197456274,"f":1},{"t":720897,"n":"ExternalFileAttributes","d":3143058,"h":94492423570,"f":1},{"t":917505,"n":"RelativeOffsetOfLocalHeader","d":3143058,"h":98787390866,"f":1},{"t":0,"n":"Filename","d":3143058,"h":103082358162,"f":1},{"t":0,"n":"FileComment","d":3143058,"h":107377325458,"f":1},{"t":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h,"n":"ExtraFields","d":3143058,"h":111672292754,"f":1},{"t":0,"n":"TrailingExtraFieldData","d":3143058,"h":115967260050,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":3143058,"h":133147129234,"f":1}],"j":[3208594,3274130],"h":3143058}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.ZipCentralDirectoryFileHeader`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock", ($self) => class ZipEndOfCentralDirectoryBlock extends $.$spc.System.Object
        {
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static Signature = 4;
                    /*int*/ static NumberOfThisDisk = 2;
                    /*int*/ static NumberOfTheDiskWithTheStartOfTheCentralDirectory = 2;
                    /*int*/ static NumberOfEntriesInTheCentralDirectoryOnThisDisk = 2;
                    /*int*/ static NumberOfEntriesInTheCentralDirectory = 2;
                    /*int*/ static SizeOfCentralDirectory = 4;
                    /*int*/ static OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber = 4;
                    /*int*/ static ArchiveCommentLength = 2;
                    static $h = 3405202;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":3405202,"h":4298372498,"f":33},{"t":655361,"n":"NumberOfThisDisk","d":3405202,"h":8593339794,"f":33},{"t":655361,"n":"NumberOfTheDiskWithTheStartOfTheCentralDirectory","d":3405202,"h":12888307090,"f":33},{"t":655361,"n":"NumberOfEntriesInTheCentralDirectoryOnThisDisk","d":3405202,"h":17183274386,"f":33},{"t":655361,"n":"NumberOfEntriesInTheCentralDirectory","d":3405202,"h":21478241682,"f":33},{"t":655361,"n":"SizeOfCentralDirectory","d":3405202,"h":25773208978,"f":33},{"t":655361,"n":"OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber","d":3405202,"h":30068176274,"f":33},{"t":655361,"n":"ArchiveCommentLength","d":3405202,"h":34363143570,"f":33}],"d":3339666,"h":3405202}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipEndOfCentralDirectoryBlock.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Signature = 0;
                    /*int*/ static NumberOfThisDisk = 4;
                    /*int*/ static NumberOfTheDiskWithTheStartOfTheCentralDirectory = 6;
                    /*int*/ static NumberOfEntriesInTheCentralDirectoryOnThisDisk = 8;
                    /*int*/ static NumberOfEntriesInTheCentralDirectory = 10;
                    /*int*/ static SizeOfCentralDirectory = 12;
                    /*int*/ static OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber = 16;
                    /*int*/ static ArchiveCommentLength = 20;
                    /*int*/ static DynamicData = 22;
                    static $h = 3470738;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":3470738,"h":4298438034,"f":33},{"t":655361,"n":"NumberOfThisDisk","d":3470738,"h":8593405330,"f":33},{"t":655361,"n":"NumberOfTheDiskWithTheStartOfTheCentralDirectory","d":3470738,"h":12888372626,"f":33},{"t":655361,"n":"NumberOfEntriesInTheCentralDirectoryOnThisDisk","d":3470738,"h":17183339922,"f":33},{"t":655361,"n":"NumberOfEntriesInTheCentralDirectory","d":3470738,"h":21478307218,"f":33},{"t":655361,"n":"SizeOfCentralDirectory","d":3470738,"h":25773274514,"f":33},{"t":655361,"n":"OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber","d":3470738,"h":30068241810,"f":33},{"t":655361,"n":"ArchiveCommentLength","d":3470738,"h":34363209106,"f":33},{"t":655361,"n":"DynamicData","d":3470738,"h":38658176402,"f":33}],"d":3339666,"h":3470738}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipEndOfCentralDirectoryBlock.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            static /*Task *//*async*/  WriteBlockAsync(/*Stream*/ stream, /*long*/ numberOfEntries, /*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory, /*byte[]*/ archiveComment, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [22/*TotalSize*/], null);
                    $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.WriteBlockInitialize($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockContents), numberOfEntries, startOfCentralDirectory, sizeOfCentralDirectory, archiveComment);
                    await stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(blockContents), cancellationToken).ConfigureAwait(false);
                    if (archiveComment.length > 0)
                    {
                        await stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(archiveComment), cancellationToken).ConfigureAwait(false);
                    }
                });
            }
            static /*Task<ZipEndOfCentralDirectoryBlock> *//*async*/  ReadBlockAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock), $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [22/*TotalSize*/], null);
                    /*int*/ let bytesRead = await stream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(blockContents), blockContents.length, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    /*ZipEndOfCentralDirectoryBlock?*/ let eocdBlock;
                    /*bool*/ let readComment;
                    if (!$.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.TryReadBlockInitialize(stream, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockContents), bytesRead, $.$ref(() => eocdBlock, ($v) => eocdBlock = $v, $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock), $.$ref(() => readComment, ($v) => readComment = $v, $.$spc.System.Boolean)))
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.EOCDNotFound);
                    }
                    else if (readComment)
                    {
                        stream.ReadExactly($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(eocdBlock._archiveComment));
                    }
                    return eocdBlock;
                });
            }
            /*byte[]*/ static SignatureConstantBytes = null;
            /*int*/ static TotalSize = 22;
            /*int*/ static SizeOfBlockWithoutSignature = 18;
            /*int*/ static ZipFileCommentMaxLength = 65535;
            /*uint*/ Signature = 0;
            /*ushort*/ NumberOfThisDisk = 0;
            /*ushort*/ NumberOfTheDiskWithTheStartOfTheCentralDirectory = 0;
            /*ushort*/ NumberOfEntriesInTheCentralDirectoryOnThisDisk = 0;
            /*ushort*/ NumberOfEntriesInTheCentralDirectory = 0;
            /*uint*/ SizeOfCentralDirectory = 0;
            /*uint*/ OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber = 0;
            /*byte[]?*/ _archiveComment = null;
            /*byte[] */ get ArchiveComment()
            {
                return this._archiveComment ??= $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [  ], null, null);
            }
            static /*void */ WriteBlockInitialize(/*Span<byte>*/ blockContents, /*long*/ numberOfEntries, /*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory, /*byte[]*/ archiveComment)
            {
                /*ushort*/ let numberOfEntriesTruncated = numberOfEntries > BigInt(65535/*ushort.MaxValue*/) ? 65535/*ZipHelper.Mask16Bit*/ : $.$cast(numberOfEntries, $.$spc.System.UInt16);
                /*uint*/ let startOfCentralDirectoryTruncated = startOfCentralDirectory > BigInt(4294967295/*uint.MaxValue*/) ? 4294967295/*ZipHelper.Mask32Bit*/ : $.$cast(startOfCentralDirectory, $.$spc.System.UInt32);
                /*uint*/ let sizeOfCentralDirectoryTruncated = sizeOfCentralDirectory > BigInt(4294967295/*uint.MaxValue*/) ? 4294967295/*ZipHelper.Mask32Bit*/ : $.$cast(sizeOfCentralDirectory, $.$spc.System.UInt32);
                let $t1 = blockContents;
                $.$spc.System.MemoryExtensions.CopyTo($.$spc.System.Byte, $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.SignatureConstantBytes, $t1.Slice$1(0/*FieldLocations.Signature*/, $t1.Length - 0/*FieldLocations.Signature*/));
                let $t2 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t2.Slice$1(4/*FieldLocations.NumberOfThisDisk*/, $t2.Length - 4/*FieldLocations.NumberOfThisDisk*/), 0);
                let $t3 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t3.Slice$1(6/*FieldLocations.NumberOfTheDiskWithTheStartOfTheCentralDirectory*/, $t3.Length - 6/*FieldLocations.NumberOfTheDiskWithTheStartOfTheCentralDirectory*/), 0);
                let $t4 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t4.Slice$1(8/*FieldLocations.NumberOfEntriesInTheCentralDirectoryOnThisDisk*/, $t4.Length - 8/*FieldLocations.NumberOfEntriesInTheCentralDirectoryOnThisDisk*/), numberOfEntriesTruncated);
                let $t5 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t5.Slice$1(10/*FieldLocations.NumberOfEntriesInTheCentralDirectory*/, $t5.Length - 10/*FieldLocations.NumberOfEntriesInTheCentralDirectory*/), numberOfEntriesTruncated);
                let $t6 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t6.Slice$1(12/*FieldLocations.SizeOfCentralDirectory*/, $t6.Length - 12/*FieldLocations.SizeOfCentralDirectory*/), sizeOfCentralDirectoryTruncated);
                let $t7 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t7.Slice$1(16/*FieldLocations.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber*/, $t7.Length - 16/*FieldLocations.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber*/), startOfCentralDirectoryTruncated);
                $.$spc.System.Diagnostics.Debug.Assert$1(archiveComment.length <= 65535/*ZipFileCommentMaxLength*/, "archiveComment.Length <= ZipFileCommentMaxLength");
                let $t8 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t8.Slice$1(20/*FieldLocations.ArchiveCommentLength*/, $t8.Length - 20/*FieldLocations.ArchiveCommentLength*/), $.$cast(archiveComment.length, $.$spc.System.UInt16));
            }
            static /*void */ WriteBlock(/*Stream*/ stream, /*long*/ numberOfEntries, /*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory, /*byte[]*/ archiveComment)
            {
                /*Span<byte>*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 22/*TotalSize*/, null);
                $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.WriteBlockInitialize(blockContents, numberOfEntries, startOfCentralDirectory, sizeOfCentralDirectory, archiveComment);
                stream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockContents));
                if (archiveComment.length > 0)
                {
                    stream.Write$1($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(archiveComment));
                }
            }
            static /*bool */ TryReadBlockInitialize(/*Stream*/ stream, /*Span<byte>*/ blockContents, /*int*/ bytesRead, /*out ZipEndOfCentralDirectoryBlock?*/ eocdBlock, /*out bool*/ readComment)
            {
                readComment.$v = false;
                eocdBlock.$v = null;
                if (bytesRead < 22/*TotalSize*/)
                {
                    return false;
                }
                if (!$.$spc.System.MemoryExtensions.StartsWith$1($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockContents), $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.SignatureConstantBytes)))
                {
                    return false;
                }
                eocdBlock.$v = (() =>
                {
                    //new $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock()
                    const $t1 = $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock;
                    const $i1 = new $t1();
                    let $t2 = blockContents;
                    $i1.Signature = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t2.Slice$1(0/*FieldLocations.Signature*/, $t2.Length - 0/*FieldLocations.Signature*/)));
                    let $t3 = blockContents;
                    $i1.NumberOfThisDisk = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t3.Slice$1(4/*FieldLocations.NumberOfThisDisk*/, $t3.Length - 4/*FieldLocations.NumberOfThisDisk*/)));
                    let $t4 = blockContents;
                    $i1.NumberOfTheDiskWithTheStartOfTheCentralDirectory = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t4.Slice$1(6/*FieldLocations.NumberOfTheDiskWithTheStartOfTheCentralDirectory*/, $t4.Length - 6/*FieldLocations.NumberOfTheDiskWithTheStartOfTheCentralDirectory*/)));
                    let $t5 = blockContents;
                    $i1.NumberOfEntriesInTheCentralDirectoryOnThisDisk = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t5.Slice$1(8/*FieldLocations.NumberOfEntriesInTheCentralDirectoryOnThisDisk*/, $t5.Length - 8/*FieldLocations.NumberOfEntriesInTheCentralDirectoryOnThisDisk*/)));
                    let $t6 = blockContents;
                    $i1.NumberOfEntriesInTheCentralDirectory = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t6.Slice$1(10/*FieldLocations.NumberOfEntriesInTheCentralDirectory*/, $t6.Length - 10/*FieldLocations.NumberOfEntriesInTheCentralDirectory*/)));
                    let $t7 = blockContents;
                    $i1.SizeOfCentralDirectory = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t7.Slice$1(12/*FieldLocations.SizeOfCentralDirectory*/, $t7.Length - 12/*FieldLocations.SizeOfCentralDirectory*/)));
                    let $t8 = blockContents;
                    $i1.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t8.Slice$1(16/*FieldLocations.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber*/, $t8.Length - 16/*FieldLocations.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber*/)));
                    return $i1;
                })();
                let $t2 = blockContents;
                /*ushort*/ let commentLength = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t2.Slice$1(20/*FieldLocations.ArchiveCommentLength*/, $t2.Length - 20/*FieldLocations.ArchiveCommentLength*/)));
                if (stream.Position + BigInt(commentLength) > stream.Length)
                {
                    return false;
                }
                if (commentLength === 0)
                {
                    eocdBlock.$v._archiveComment = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [  ], null, null);
                }
                else 
                {
                    eocdBlock.$v._archiveComment = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [commentLength], null);
                    readComment.$v = true;
                }
                return true;
            }
            static /*ZipEndOfCentralDirectoryBlock */ ReadBlock(/*Stream*/ stream)
            {
                /*Span<byte>*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 22/*TotalSize*/, null);
                /*int*/ let bytesRead = stream.ReadAtLeast(blockContents, blockContents.Length, false);
                /*ZipEndOfCentralDirectoryBlock?*/ let eocdBlock;
                /*bool*/ let readComment;
                if (!$.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.TryReadBlockInitialize(stream, blockContents, bytesRead, $.$ref(() => eocdBlock, ($v) => eocdBlock = $v, $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock), $.$ref(() => readComment, ($v) => readComment = $v, $.$spc.System.Boolean)))
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.EOCDNotFound);
                }
                else if (readComment)
                {
                    stream.ReadExactly($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(eocdBlock._archiveComment));
                }
                return eocdBlock;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SignatureConstantBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [ 80, 75, 5, 6 ], null, null);
                }
            }
            static $h = 3339666;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":77312750994,"f":1},"n":"ArchiveComment","d":3339666,"h":73017783698,"f":1}],"m":[{"r":133300225,"p":[{"n":"stream","p":62193665},{"n":"numberOfEntries","p":917505},{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505},{"n":"archiveComment","p":0},{"n":"cancellationToken","p":125960193}],"n":"WriteBlockAsync","d":3339666,"h":12888241554,"f":4129},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock).$h,"p":[{"n":"stream","p":62193665},{"n":"cancellationToken","p":125960193}],"n":"ReadBlockAsync","d":3339666,"h":17183208850,"f":4129},{"r":65537,"p":[{"n":"blockContents","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"numberOfEntries","p":917505},{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505},{"n":"archiveComment","p":0}],"n":"WriteBlockInitialize","d":3339666,"h":81607718290,"f":34},{"r":65537,"p":[{"n":"stream","p":62193665},{"n":"numberOfEntries","p":917505},{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505},{"n":"archiveComment","p":0}],"n":"WriteBlock","d":3339666,"h":85902685586,"f":33},{"r":262145,"p":[{"n":"stream","p":62193665},{"n":"blockContents","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesRead","p":655361},{"n":"eocdBlock","p":3339666,"f":2},{"n":"readComment","p":262145,"f":2}],"n":"TryReadBlockInitialize","d":3339666,"h":90197652882,"f":34},{"r":3339666,"p":[{"n":"stream","p":62193665}],"n":"ReadBlock","d":3339666,"h":94492620178,"f":33}],"l":[{"t":0,"n":"SignatureConstantBytes","d":3339666,"h":21478176146,"f":33},{"t":655361,"n":"TotalSize","d":3339666,"h":25773143442,"f":33},{"t":655361,"n":"SizeOfBlockWithoutSignature","d":3339666,"h":30068110738,"f":33},{"t":655361,"n":"ZipFileCommentMaxLength","d":3339666,"h":34363078034,"f":33},{"t":720897,"n":"Signature","d":3339666,"h":38658045330,"f":1},{"t":589825,"n":"NumberOfThisDisk","d":3339666,"h":42953012626,"f":1},{"t":589825,"n":"NumberOfTheDiskWithTheStartOfTheCentralDirectory","d":3339666,"h":47247979922,"f":1},{"t":589825,"n":"NumberOfEntriesInTheCentralDirectoryOnThisDisk","d":3339666,"h":51542947218,"f":1},{"t":589825,"n":"NumberOfEntriesInTheCentralDirectory","d":3339666,"h":55837914514,"f":1},{"t":720897,"n":"SizeOfCentralDirectory","d":3339666,"h":60132881810,"f":1},{"t":720897,"n":"OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber","d":3339666,"h":64427849106,"f":1},{"t":0,"n":"_archiveComment","d":3339666,"h":68722816402,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":3339666,"h":98787587474,"f":1}],"j":[3405202,3470738],"h":3339666}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.ZipEndOfCentralDirectoryBlock`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipArchiveEntry", ($self) => class ZipArchiveEntry extends $.$spc.System.Object
        {
            /*ZipVersionMadeByPlatform*/ static CurrentZipPlatform = 3;
            static /*string */ ParseFileName(/*string*/ path, /*ZipVersionMadeByPlatform*/ madeByPlatform)
            {
                return madeByPlatform === 0/*ZipVersionMadeByPlatform.Windows*/ ? $.$sic.System.IO.Compression.ZipArchiveEntry.GetFileName_Windows(path) : $.$sic.System.IO.Compression.ZipArchiveEntry.GetFileName_Unix(path);
            }
            /*Task<Stream> *//*async*/  OpenAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.Stream), $.$spc.System.IO.Stream, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    this.ThrowIfInvalidArchive();
                    let $switch1 = this._archive.Mode;
                    switch($switch1)
                    {
                        case 0/*ZipArchiveMode.Read*/:
                        return await this.OpenInReadModeAsync(true, cancellationToken).ConfigureAwait$2(false);
                        case 1/*ZipArchiveMode.Create*/:
                        return this.OpenInWriteMode();
                        case 2/*ZipArchiveMode.Update*/:
                        default:
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._archive.Mode === 2/*ZipArchiveMode.Update*/, "_archive.Mode == ZipArchiveMode.Update");
                        return await this.OpenInUpdateModeAsync(cancellationToken).ConfigureAwait$2(false);
                    }
                });
            }
            /*Task<long> *//*async*/  GetOffsetOfCompressedDataAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int64), $.$spc.System.Int64, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (this._storedOffsetOfCompressedData === null)
                    {
                        this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader, 0/*SeekOrigin.Begin*/);
                        if (!await $.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlockAsync(this._archive.ArchiveStream, cancellationToken).ConfigureAwait$2(false))
                        {
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.LocalFileHeaderCorrupt);
                        }
                        this._storedOffsetOfCompressedData = this._archive.ArchiveStream.Position;
                    }
                    return $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(this._storedOffsetOfCompressedData);
                });
            }
            /*Task<MemoryStream> *//*async*/  GetUncompressedDataAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.MemoryStream), $.$spc.System.IO.MemoryStream, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (this._storedUncompressedData === null)
                    {
                        this._storedUncompressedData = new $.$spc.System.IO.MemoryStream().$ctor$4($.$cast(this._uncompressedSize, $.$spc.System.Int32));
                        if (this._originallyInArchive)
                        {
                            /*Stream*/ let decompressor = await this.OpenInReadModeAsync(false, cancellationToken).ConfigureAwait$2(false);
                            let $disposable1 = null;
                            try
                            {
                                $disposable1 = decompressor;
                                try
                                {
                                    await decompressor.CopyToAsync$2(this._storedUncompressedData, cancellationToken).ConfigureAwait(false);
                                }
                                catch($e)
                                {
                                    await this._storedUncompressedData.DisposeAsync().ConfigureAwait(false);
                                    this._storedUncompressedData = null;
                                    this._currentlyOpenForWrite = false;
                                    this._everOpenedForWrite = false;
                                    throw $e;
                                }
                            }
                            finally
                            {
                                $disposable1?.System$IDisposable$Dispose();
                            }
                        }
                        if (this.CompressionMethod !== 0/*CompressionMethodValues.Stored*/)
                        {
                            this.CompressionMethod = 8/*CompressionMethodValues.Deflate*/;
                        }
                    }
                    return this._storedUncompressedData;
                });
            }
            /*Task *//*async*/  WriteAndFinishLocalEntryAsync(/*bool*/ forceWrite, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await this.CloseStreamsAsync().ConfigureAwait(false);
                    await this.WriteLocalFileHeaderAndDataIfNeededAsync(forceWrite, cancellationToken).ConfigureAwait(false);
                    await this.UnloadStreamsAsync().ConfigureAwait(false);
                });
            }
            /*Task *//*async*/  WriteCentralDirectoryFileHeaderAsync(/*bool*/ forceWrite, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*Zip64ExtraField?*/ let zip64ExtraField;
                    /*uint*/ let compressedSizeTruncated;
                    /*uint*/ let uncompressedSizeTruncated;
                    /*ushort*/ let extraFieldLength;
                    /*uint*/ let offsetOfLocalHeaderTruncated;
                    if (this.WriteCentralDirectoryFileHeaderInitialize(forceWrite, $.$ref(() => zip64ExtraField, ($v) => zip64ExtraField = $v, $.$sic.System.IO.Compression.Zip64ExtraField), $.$ref(() => compressedSizeTruncated, ($v) => compressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeTruncated, ($v) => uncompressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => extraFieldLength, ($v) => extraFieldLength = $v, $.$spc.System.UInt16), $.$ref(() => offsetOfLocalHeaderTruncated, ($v) => offsetOfLocalHeaderTruncated = $v, $.$spc.System.UInt32)))
                    {
                        /*byte[]*/ let cdStaticHeader = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/], null);
                        this.WriteCentralDirectoryFileHeaderPrepare($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(cdStaticHeader), compressedSizeTruncated, uncompressedSizeTruncated, extraFieldLength, offsetOfLocalHeaderTruncated);
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(cdStaticHeader), cancellationToken).ConfigureAwait(false);
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(this._storedEntryNameBytes), cancellationToken).ConfigureAwait(false);
                        if (zip64ExtraField !== null)
                        {
                            await zip64ExtraField.WriteBlockAsync(this._archive.ArchiveStream, cancellationToken).ConfigureAwait(false);
                        }
                        await $.$sic.System.IO.Compression.ZipGenericExtraField.WriteAllBlocksAsync(this._cdUnknownExtraFields, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(this._cdTrailingExtraFieldData ?? $.$spc.System.Array.Empty($.$spc.System.Byte)), this._archive.ArchiveStream, cancellationToken).ConfigureAwait(false);
                        if (this._fileComment.length > 0)
                        {
                            await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(this._fileComment), cancellationToken).ConfigureAwait(false);
                        }
                    }
                });
            }
            /*Task *//*async*/  LoadLocalHeaderExtraFieldIfNeededAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    $.$spc.System.Diagnostics.Debug.Assert$1(await this.GetIsOpenableAsync(false, true, cancellationToken).ConfigureAwait$2(false), "await GetIsOpenableAsync(false, true, cancellationToken).ConfigureAwait(false)");
                    if (this._originallyInArchive)
                    {
                        this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader, 0/*SeekOrigin.Begin*/);
                        $.$tupleUnpack(($tp) =>
                        {
                            this._lhUnknownExtraFields = $tp.Item1;
                            this._lhTrailingExtraFieldData = $tp.Item2;
                        }).$v = await $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldsAsync(this._archive.ArchiveStream, cancellationToken).ConfigureAwait$2(false);
                    }
                });
            }
            /*Task *//*async*/  LoadCompressedBytesIfNeededAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    $.$spc.System.Diagnostics.Debug.Assert$1(await this.GetIsOpenableAsync(false, true, cancellationToken).ConfigureAwait$2(false), "await GetIsOpenableAsync(false, true, cancellationToken).ConfigureAwait(false)");
                    if (!this._everOpenedForWrite && this._originallyInArchive)
                    {
                        /*int*/ let maxSingleBufferSize;
                        this._compressedBytes = this.LoadCompressedBytesIfNeededInitialize($.$ref(() => maxSingleBufferSize, ($v) => maxSingleBufferSize = $v, $.$spc.System.Int32));
                        this._archive.ArchiveStream.Seek(await this.GetOffsetOfCompressedDataAsync(cancellationToken).ConfigureAwait$2(false), 0/*SeekOrigin.Begin*/);
                        for(/*int*/ let i = 0; i < ((this._compressedBytes.length - 1) | 0); i++)
                        {
                            await this._archive.ArchiveStream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit($.$spc.System.Array.$ReadT1.call(this._compressedBytes, i)), maxSingleBufferSize, true, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                        }
                        await this._archive.ArchiveStream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit($.$spc.System.Array.$ReadT1.call(this._compressedBytes, ((this._compressedBytes.length - 1) | 0))), $.$cast((this._compressedSize % BigInt(maxSingleBufferSize)), $.$spc.System.Int32), true, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    }
                });
            }
            /*Task<bool> *//*async*/  GetIsOpenableAsync(/*bool*/ needToUncompress, /*bool*/ needToLoadIntoMemory, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*bool*/ let result;
        $.$tupleUnpack(($tp) =>
                    {
                        result = $tp.Item1;
                        _ = $tp.Item2;
                    }).$v = await this.IsOpenableAsync(needToUncompress, needToLoadIntoMemory, cancellationToken).ConfigureAwait$2(false);
                    return result;
                });
            }
            /*Task *//*async*/  ThrowIfNotOpenableAsync(/*bool*/ needToUncompress, /*bool*/ needToLoadIntoMemory, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    const { Item1: openable, Item2: message } = await this.IsOpenableAsync(needToUncompress, needToLoadIntoMemory, cancellationToken).ConfigureAwait$2(false);
                    if (!openable)
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10(message);
                    }
                });
            }
            /*Task<Stream> *//*async*/  OpenInReadModeAsync(/*bool*/ checkOpenable, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.Stream), $.$spc.System.IO.Stream, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (checkOpenable)
                    {
                        await this.ThrowIfNotOpenableAsync(true, false, cancellationToken).ConfigureAwait(false);
                    }
                    return this.OpenInReadModeGetDataCompressor(await this.GetOffsetOfCompressedDataAsync(cancellationToken).ConfigureAwait$2(false));
                });
            }
            /*Task<WrappedStream> *//*async*/  OpenInUpdateModeAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.WrappedStream), $.$sic.System.IO.Compression.WrappedStream, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (this._currentlyOpenForWrite)
                    {
                        throw new $.$spc.System.IO.IOException().$ctor$10($.$sic.System.SR.UpdateModeOneStream);
                    }
                    await this.ThrowIfNotOpenableAsync(true, true, cancellationToken).ConfigureAwait(false);
                    this._everOpenedForWrite = true;
                    this.Changes |= 4/*ZipArchive.ChangeState.StoredData*/;
                    this._currentlyOpenForWrite = true;
                    /*Stream*/ let uncompressedData = await this.GetUncompressedDataAsync(cancellationToken).ConfigureAwait$2(false);
                    uncompressedData.Seek(0n, 0/*SeekOrigin.Begin*/);
                    return new $.$sic.System.IO.Compression.WrappedStream().$ctor$5(uncompressedData, this, new ($.$spc.System.Action$$($.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor(this,  (/*thisRef*/ thisRef) =>
                    {
                        thisRef._currentlyOpenForWrite = false;
                    }, {"r":65537,"p":[{"n":"thisRef","p":2684306}],"n":"","d":2684306,"h":0,"f":1048578}));
                });
            }
            /*Task<(bool, string?)> *//*async*/  IsOpenableAsync(/*bool*/ needToUncompress, /*bool*/ needToLoadIntoMemory, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String)), $.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String), async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*string?*/ let message = null;
                    if (!this._originallyInArchive)
                    {
                        return new ($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String))().$ctor$2(true, message);
                    }
                    if (!this.IsOpenableInitialVerifications(needToUncompress, $.$ref(() => message, ($v) => message = $v, $.$spc.System.String)))
                    {
                        return new ($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String))().$ctor$2(false, message);
                    }
                    if (!await $.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlockAsync(this._archive.ArchiveStream, cancellationToken).ConfigureAwait$2(false))
                    {
                        message = $.$sic.System.SR.LocalFileHeaderCorrupt;
                        return new ($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String))().$ctor$2(false, message);
                    }
                    /*long*/ let offsetOfCompressedData = await this.GetOffsetOfCompressedDataAsync(cancellationToken).ConfigureAwait$2(false);
                    if (!this.IsOpenableFinalVerifications(needToLoadIntoMemory, offsetOfCompressedData, $.$ref(() => message, ($v) => message = $v, $.$spc.System.String)))
                    {
                        return new ($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String))().$ctor$2(false, message);
                    }
                    return new ($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String))().$ctor$2(true, message);
                });
            }
            /*Task<bool> *//*async*/  WriteLocalFileHeaderAsync(/*bool*/ isEmptyFile, /*bool*/ forceWrite, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*Zip64ExtraField?*/ let zip64ExtraField;
                    /*uint*/ let compressedSizeTruncated;
                    /*uint*/ let uncompressedSizeTruncated;
                    /*ushort*/ let extraFieldLength;
                    if (this.WriteLocalFileHeaderInitialize(isEmptyFile, forceWrite, $.$ref(() => zip64ExtraField, ($v) => zip64ExtraField = $v, $.$sic.System.IO.Compression.Zip64ExtraField), $.$ref(() => compressedSizeTruncated, ($v) => compressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeTruncated, ($v) => uncompressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => extraFieldLength, ($v) => extraFieldLength = $v, $.$spc.System.UInt16)))
                    {
                        /*byte[]*/ let lfStaticHeader = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [30/*ZipLocalFileHeader.SizeOfLocalHeader*/], null);
                        this.WriteLocalFileHeaderPrepare($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(lfStaticHeader), compressedSizeTruncated, uncompressedSizeTruncated, extraFieldLength);
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(lfStaticHeader), cancellationToken).ConfigureAwait(false);
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(this._storedEntryNameBytes), cancellationToken).ConfigureAwait(false);
                        if (zip64ExtraField !== null)
                        {
                            await zip64ExtraField.WriteBlockAsync(this._archive.ArchiveStream, cancellationToken).ConfigureAwait(false);
                        }
                        await $.$sic.System.IO.Compression.ZipGenericExtraField.WriteAllBlocksAsync(this._lhUnknownExtraFields, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(this._lhTrailingExtraFieldData ?? $.$spc.System.Array.Empty($.$spc.System.Byte)), this._archive.ArchiveStream, cancellationToken).ConfigureAwait(false);
                    }
                    return zip64ExtraField !== null;
                });
            }
            /*Task *//*async*/  WriteLocalFileHeaderAndDataIfNeededAsync(/*bool*/ forceWrite, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (this._storedUncompressedData !== null || this._compressedBytes !== null)
                    {
                        if (this._storedUncompressedData !== null)
                        {
                            this._uncompressedSize = this._storedUncompressedData.Length;
                            /*DirectToArchiveWriterStream*/ let entryWriter = new $.$sic.System.IO.Compression.ZipArchiveEntry.DirectToArchiveWriterStream().$ctor$3(this.GetDataCompressor(this._archive.ArchiveStream, true, null), this);
                            let $disposable1 = null;
                            try
                            {
                                $disposable1 = entryWriter;
                                this._storedUncompressedData.Seek(0n, 0/*SeekOrigin.Begin*/);
                                await this._storedUncompressedData.CopyToAsync$2(entryWriter, cancellationToken).ConfigureAwait(false);
                                await this._storedUncompressedData.DisposeAsync().ConfigureAwait(false);
                                this._storedUncompressedData = null;
                            }
                            finally
                            {
                                $disposable1?.System$IDisposable$Dispose();
                            }
                        }
                        else 
                        {
                            if (this._uncompressedSize === 0n)
                            {
                                this._compressedSize = 0n;
                            }
                            await this.WriteLocalFileHeaderAsync(this._uncompressedSize === 0n, true, cancellationToken).ConfigureAwait$2(false);
                            if (this._uncompressedSize !== 0n)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._compressedBytes !== null, "_compressedBytes != null");
                                let $i1 = 0;
                                let $arr1 = this._compressedBytes;
                                while ($i1 < $arr1.length)
                                {
                                    let compressedBytes = $arr1[$i1++];
                                    await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(compressedBytes), cancellationToken).ConfigureAwait(false);
                                }
                            }
                        }
                    }
                    else 
                    {
                        if (this._archive.Mode === 2/*ZipArchiveMode.Update*/ || !this._everOpenedForWrite)
                        {
                            this._everOpenedForWrite = true;
                            await this.WriteLocalFileHeaderAsync(this._uncompressedSize === 0n, forceWrite, cancellationToken).ConfigureAwait$2(false);
                            if (this._compressedSize !== 0n)
                            {
                                this._archive.ArchiveStream.Seek(this._compressedSize, 1/*SeekOrigin.Current*/);
                            }
                        }
                    }
                });
            }
            /*Task *//*async*/  WriteCrcAndSizesInLocalHeaderAsync(/*bool*/ zip64HeaderUsed, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let writeBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [20/*Zip64DataDescriptorCrcAndSizesBufferLength*/], null);
                    /*long*/ let finalPosition;
                    /*bool*/ let pretendStreaming;
                    /*uint*/ let compressedSizeTruncated;
                    /*uint*/ let uncompressedSizeTruncated;
                    this.WriteCrcAndSizesInLocalHeaderInitialize(zip64HeaderUsed, $.$ref(() => finalPosition, ($v) => finalPosition = $v, $.$spc.System.Int64), $.$ref(() => pretendStreaming, ($v) => pretendStreaming = $v, $.$spc.System.Boolean), $.$ref(() => compressedSizeTruncated, ($v) => compressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeTruncated, ($v) => uncompressedSizeTruncated = $v, $.$spc.System.UInt32));
                    if (pretendStreaming)
                    {
                        this.WriteCrcAndSizesInLocalHeaderPrepareForZip64PretendStreaming($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(writeBuffer));
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, writeBuffer, 0, 4/*MetadataBufferLength*/)), cancellationToken).ConfigureAwait(false);
                    }
                    this.WriteCrcAndSizesInLocalHeaderPrepareFor32bitValuesWriting(pretendStreaming, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(writeBuffer), compressedSizeTruncated, uncompressedSizeTruncated);
                    await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, writeBuffer, 0, 12/*CrcAndSizesBufferLength*/)), cancellationToken).ConfigureAwait(false);
                    if (zip64HeaderUsed)
                    {
                        this.WriteCrcAndSizesInLocalHeaderPrepareForWritingWhenZip64HeaderUsed($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(writeBuffer));
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, writeBuffer, 0, 16/*Zip64SizesBufferLength*/)), cancellationToken).ConfigureAwait(false);
                    }
                    this._archive.ArchiveStream.Seek(finalPosition, 0/*SeekOrigin.Begin*/);
                    if (pretendStreaming)
                    {
                        this.WriteCrcAndSizesInLocalHeaderPrepareForWritingDataDescriptor($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(writeBuffer));
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, writeBuffer, 0, 20/*Zip64DataDescriptorCrcAndSizesBufferLength*/)), cancellationToken).ConfigureAwait(false);
                    }
                });
            }
            /*ValueTask */ WriteDataDescriptorAsync(/*CancellationToken*/ cancellationToken)
            {
                cancellationToken.ThrowIfCancellationRequested();
                /*byte[]*/ let dataDescriptor = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [24/*MaxSizeOfDataDescriptor*/], null);
                /*int*/ let bytesToWrite = this.PrepareToWriteDataDescriptor($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(dataDescriptor));
                return this._archive.ArchiveStream.WriteAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, dataDescriptor, 0, bytesToWrite)), cancellationToken);
            }
            /*Task *//*async*/  UnloadStreamsAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (this._storedUncompressedData !== null)
                    {
                        await this._storedUncompressedData.DisposeAsync().ConfigureAwait(false);
                    }
                    this._compressedBytes = null;
                    this._outstandingWriteStream = null;
                });
            }
            /*Task *//*async*/  CloseStreamsAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (this._outstandingWriteStream !== null)
                    {
                        await this._outstandingWriteStream.DisposeAsync().ConfigureAwait(false);
                    }
                });
            }
            /*ZipArchive*/ _archive = null;
            /*bool*/ _originallyInArchive = false;
            /*uint*/ _diskNumberStart = 0;
            /*ZipVersionMadeByPlatform*/ _versionMadeByPlatform = 0;
            /*ZipVersionNeededValues*/ _versionMadeBySpecification = 0;
            /*ZipVersionNeededValues*/ _versionToExtract = 0;
            /*BitFlagValues*/ _generalPurposeBitFlag = 0;
            /*bool*/ _isEncrypted = false;
            /*CompressionMethodValues*/ _storedCompressionMethod = 0;
            /*DateTimeOffset*/ _lastModified;
            /*long*/ _compressedSize = 0n;
            /*long*/ _uncompressedSize = 0n;
            /*long*/ _offsetOfLocalHeader = 0n;
            /*long?*/ _storedOffsetOfCompressedData = null;
            /*uint*/ _crc32 = 0;
            /*byte[][]?*/ _compressedBytes = null;
            /*MemoryStream?*/ _storedUncompressedData = null;
            /*bool*/ _currentlyOpenForWrite = false;
            /*bool*/ _everOpenedForWrite = false;
            /*Stream?*/ _outstandingWriteStream = null;
            /*uint*/ _externalFileAttr = 0;
            /*string*/ _storedEntryName = null;
            /*byte[]*/ _storedEntryNameBytes = null;
            /*List<ZipGenericExtraField>?*/ _cdUnknownExtraFields = null;
            /*byte[]?*/ _cdTrailingExtraFieldData = null;
            /*List<ZipGenericExtraField>?*/ _lhUnknownExtraFields = null;
            /*byte[]?*/ _lhTrailingExtraFieldData = null;
            /*byte[]*/ _fileComment = null;
            /*CompressionLevel*/ _compressionLevel = 0;
            $ctor$1(/*ZipArchive*/ archive, /*ZipCentralDirectoryFileHeader*/ cd)
            {
                super.$ctor();
                {
                    this._archive = archive;
                    this._originallyInArchive = true;
                    this.Changes = 0/*ZipArchive.ChangeState.Unchanged*/;
                    this._diskNumberStart = cd.DiskNumberStart;
                    this._versionMadeByPlatform = $.$cast(cd.VersionMadeByCompatibility, $.$sic.System.IO.Compression.ZipVersionMadeByPlatform);
                    this._versionMadeBySpecification = $.$cast(cd.VersionMadeBySpecification, $.$sic.System.IO.Compression.ZipVersionNeededValues);
                    this._versionToExtract = $.$cast(cd.VersionNeededToExtract, $.$sic.System.IO.Compression.ZipVersionNeededValues);
                    this._generalPurposeBitFlag = $.$cast(cd.GeneralPurposeBitFlag, $.$sic.System.IO.Compression.ZipArchiveEntry.BitFlagValues);
                    this._isEncrypted = (this._generalPurposeBitFlag & 1/*BitFlagValues.IsEncrypted*/) !== 0;
                    this.CompressionMethod = $.$cast(cd.CompressionMethod, $.$sic.System.IO.Compression.ZipArchiveEntry.CompressionMethodValues);
                    this._lastModified = new $.$spc.System.DateTimeOffset().$ctor$4($.$sic.System.IO.Compression.ZipHelper.DosTimeToDateTime(cd.LastModified));
                    this._compressedSize = cd.CompressedSize;
                    this._uncompressedSize = cd.UncompressedSize;
                    this._externalFileAttr = cd.ExternalFileAttributes;
                    this._offsetOfLocalHeader = cd.RelativeOffsetOfLocalHeader;
                    this._storedOffsetOfCompressedData = null;
                    this._crc32 = cd.Crc32;
                    this._compressedBytes = null;
                    this._storedUncompressedData = null;
                    this._currentlyOpenForWrite = false;
                    this._everOpenedForWrite = false;
                    this._outstandingWriteStream = null;
                    this._storedEntryNameBytes = cd.Filename;
                    this._storedEntryName = this.DecodeEntryString(this._storedEntryNameBytes);
                    this.DetectEntryNameVersion();
                    this._lhUnknownExtraFields = null;
                    this._cdUnknownExtraFields = cd.ExtraFields;
                    this._cdTrailingExtraFieldData = cd.TrailingExtraFieldData;
                    this._fileComment = cd.FileComment;
                    this._compressionLevel = $.$sic.System.IO.Compression.ZipArchiveEntry.MapCompressionLevel(this._generalPurposeBitFlag, this.CompressionMethod);
                }
                return this;
            }
            $ctor$2(/*ZipArchive*/ archive, /*string*/ entryName, /*CompressionLevel*/ compressionLevel)
            {
                this.$ctor$3(archive, entryName);
                {
                    this._compressionLevel = compressionLevel;
                    if (this._compressionLevel === 2/*CompressionLevel.NoCompression*/)
                    {
                        this.CompressionMethod = 0/*CompressionMethodValues.Stored*/;
                    }
                    this._generalPurposeBitFlag = $.$sic.System.IO.Compression.ZipArchiveEntry.MapDeflateCompressionOption(this._generalPurposeBitFlag, this._compressionLevel, this.CompressionMethod);
                }
                return this;
            }
            $ctor$3(/*ZipArchive*/ archive, /*string*/ entryName)
            {
                super.$ctor();
                {
                    this._archive = archive;
                    this._originallyInArchive = false;
                    this._diskNumberStart = 0;
                    this._versionMadeByPlatform = 3/*CurrentZipPlatform*/;
                    this._versionMadeBySpecification = 10/*ZipVersionNeededValues.Default*/;
                    this._versionToExtract = 10/*ZipVersionNeededValues.Default*/;
                    this._compressionLevel = 0/*CompressionLevel.Optimal*/;
                    this.CompressionMethod = 8/*CompressionMethodValues.Deflate*/;
                    this._generalPurposeBitFlag = $.$sic.System.IO.Compression.ZipArchiveEntry.MapDeflateCompressionOption(0, this._compressionLevel, this.CompressionMethod);
                    this._lastModified = $.$spc.System.DateTimeOffset.Now;
                    this._compressedSize = 0n;
                    this._uncompressedSize = 0n;
                    this._externalFileAttr = $.$spc.System.String.EndsWith$3.call(entryName, $.$spc.System.IO.Path.DirectorySeparatorChar) || $.$spc.System.String.EndsWith$3.call(entryName, $.$spc.System.IO.Path.AltDirectorySeparatorChar) ? 1106051072/*DefaultDirectoryExternalAttributes*/ : 2175008768/*DefaultFileExternalAttributes*/;
                    this._offsetOfLocalHeader = 0n;
                    this._storedOffsetOfCompressedData = null;
                    this._crc32 = 0;
                    this._compressedBytes = null;
                    this._storedUncompressedData = null;
                    this._currentlyOpenForWrite = false;
                    this._everOpenedForWrite = false;
                    this._outstandingWriteStream = null;
                    this.FullName = entryName;
                    this._cdUnknownExtraFields = null;
                    this._lhUnknownExtraFields = null;
                    this._fileComment = $.$spc.System.Array.Empty($.$spc.System.Byte);
                    if (this._storedEntryNameBytes.length > 65535/*ushort.MaxValue*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$sic.System.SR.EntryNamesTooLong);
                    }
                    if (this._archive.Mode === 1/*ZipArchiveMode.Create*/)
                    {
                        this._archive.AcquireArchiveStream(this);
                    }
                    this.Changes = 0/*ZipArchive.ChangeState.Unchanged*/;
                }
                return this;
            }
            /*ZipArchive */ get Archive()
            {
                return this._archive;
            }
            /*uint */ get Crc32()
            {
                return this._crc32;
            }
            /*bool */ get IsEncrypted()
            {
                return this._isEncrypted;
            }
            /*long */ get CompressedLength()
            {
                if (this._everOpenedForWrite)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.LengthAfterWrite);
                }
                return this._compressedSize;
            }
            /*int */ get ExternalAttributes()
            {
                return (this._externalFileAttr | 0);
            }
            /*int */ set ExternalAttributes(value)
            {
                this.ThrowIfInvalidArchive();
                this._externalFileAttr = (value >>> 0);
                this.Changes |= 1/*ZipArchive.ChangeState.FixedLengthMetadata*/;
            }
            /*string */ get Comment()
            {
                return this.DecodeEntryString(this._fileComment);
            }
            /*string */ set Comment(value)
            {
                /*bool*/ let isUTF8;
                this._fileComment = $.$sic.System.IO.Compression.ZipHelper.GetEncodedTruncatedBytesFromString(value, this._archive.EntryNameAndCommentEncoding, 65535/*ushort.MaxValue*/, $.$ref(() => isUTF8, ($v) => isUTF8 = $v, $.$spc.System.Boolean));
                if (isUTF8)
                {
                    this._generalPurposeBitFlag |= 2048/*BitFlagValues.UnicodeFileNameAndComment*/;
                }
                this.Changes |= 2/*ZipArchive.ChangeState.DynamicLengthMetadata*/;
            }
            /*string */ get FullName()
            {
                return this._storedEntryName;
            }
            /*string */ set FullName(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "FullName");
                /*bool*/ let isUTF8;
                this._storedEntryNameBytes = $.$sic.System.IO.Compression.ZipHelper.GetEncodedTruncatedBytesFromString(value, this._archive.EntryNameAndCommentEncoding, 0, $.$ref(() => isUTF8, ($v) => isUTF8 = $v, $.$spc.System.Boolean));
                this._storedEntryName = value;
                if (isUTF8)
                {
                    this._generalPurposeBitFlag |= 2048/*BitFlagValues.UnicodeFileNameAndComment*/;
                }
                else 
                {
                    this._generalPurposeBitFlag &= ~2048/*BitFlagValues.UnicodeFileNameAndComment*/;
                }
                this.DetectEntryNameVersion();
            }
            /*DateTimeOffset */ get LastWriteTime()
            {
                return this._lastModified;
            }
            /*DateTimeOffset */ set LastWriteTime(value)
            {
                this.ThrowIfInvalidArchive();
                if (this._archive.Mode === 0/*ZipArchiveMode.Read*/)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadOnlyArchive);
                }
                if (this._archive.Mode === 1/*ZipArchiveMode.Create*/ && this._everOpenedForWrite)
                {
                    throw new $.$spc.System.IO.IOException().$ctor$10($.$sic.System.SR.FrozenAfterWrite);
                }
                if (value.DateTime.Year < 1980/*ZipHelper.ValidZipDate_YearMin*/ || value.DateTime.Year > 2107/*ZipHelper.ValidZipDate_YearMax*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("value", $.$sic.System.SR.DateTimeOutOfRange);
                }
                this._lastModified = value;
                this.Changes |= 1/*ZipArchive.ChangeState.FixedLengthMetadata*/;
            }
            /*long */ get Length()
            {
                if (this._everOpenedForWrite)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.LengthAfterWrite);
                }
                return this._uncompressedSize;
            }
            /*string */ get Name()
            {
                return $.$sic.System.IO.Compression.ZipArchiveEntry.ParseFileName(this.FullName, this._versionMadeByPlatform);
            }
            /*ZipArchive.ChangeState*/ Changes = 0;
            /*bool */ get OriginallyInArchive()
            {
                return this._originallyInArchive;
            }
            /*long */ get OffsetOfLocalHeader()
            {
                return this._offsetOfLocalHeader;
            }
            /*void */ Delete()
            {
                if (this._archive === null)
                {
                    return;
                }
                if (this._currentlyOpenForWrite)
                {
                    throw new $.$spc.System.IO.IOException().$ctor$10($.$sic.System.SR.DeleteOpenEntry);
                }
                if (this._archive.Mode !== 2/*ZipArchiveMode.Update*/)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.DeleteOnlyInUpdate);
                }
                this._archive.ThrowIfDisposed();
                this._archive.RemoveEntry(this);
                this._archive = null;
                this.UnloadStreams();
            }
            /*Stream */ Open()
            {
                this.ThrowIfInvalidArchive();
                let $switch1 = this._archive.Mode;
                switch($switch1)
                {
                    case 0/*ZipArchiveMode.Read*/:
                    return this.OpenInReadMode(true);
                    case 1/*ZipArchiveMode.Create*/:
                    return this.OpenInWriteMode();
                    case 2/*ZipArchiveMode.Update*/:
                    default:
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._archive.Mode === 2/*ZipArchiveMode.Update*/, "_archive.Mode == ZipArchiveMode.Update");
                    return this.OpenInUpdateMode();
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.FullName;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sic.System.IO.Compression.ZipArchiveEntry.ToString.apply(this, arguments); }
            /*string */ DecodeEntryString(/*byte[]*/ entryStringBytes)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(entryStringBytes !== null, "entryStringBytes != null");
                /*Encoding*/ let readEntryStringEncoding = (this._generalPurposeBitFlag & 2048/*BitFlagValues.UnicodeFileNameAndComment*/) === 2048/*BitFlagValues.UnicodeFileNameAndComment*/ ? $.$spc.System.Text.Encoding.UTF8 : (this._archive?.EntryNameAndCommentEncoding ?? null) ?? $.$spc.System.Text.Encoding.UTF8;
                return readEntryStringEncoding.GetString$2(entryStringBytes);
            }
            /*bool*/ static s_allowLargeZipArchiveEntriesInUpdateMode = false;
            /*bool */ get EverOpenedForWrite()
            {
                return this._everOpenedForWrite;
            }
            /*long */ GetOffsetOfCompressedData()
            {
                if (this._storedOffsetOfCompressedData === null)
                {
                    this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader, 0/*SeekOrigin.Begin*/);
                    if (!$.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlock(this._archive.ArchiveStream))
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.LocalFileHeaderCorrupt);
                    }
                    this._storedOffsetOfCompressedData = this._archive.ArchiveStream.Position;
                }
                return $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(this._storedOffsetOfCompressedData);
            }
            /*MemoryStream */ GetUncompressedData()
            {
                if (this._storedUncompressedData === null)
                {
                    this._storedUncompressedData = new $.$spc.System.IO.MemoryStream().$ctor$4($.$cast(this._uncompressedSize, $.$spc.System.Int32));
                    if (this._originallyInArchive)
                    {
                        let decompressor = null;
                        try
                        {
                            decompressor = this.OpenInReadMode(false);
                            try
                            {
                                decompressor.CopyTo(this._storedUncompressedData);
                            }
                            catch($e)
                            {
                                this._storedUncompressedData.Dispose();
                                this._storedUncompressedData = null;
                                this._currentlyOpenForWrite = false;
                                this._everOpenedForWrite = false;
                                throw $e;
                            }
                        }
                        finally
                        {
                            decompressor?.System$IDisposable$Dispose();
                        }
                    }
                    if (this.CompressionMethod !== 0/*CompressionMethodValues.Stored*/)
                    {
                        this.CompressionMethod = 8/*CompressionMethodValues.Deflate*/;
                    }
                }
                return this._storedUncompressedData;
            }
            /*CompressionMethodValues */ get CompressionMethod()
            {
                return this._storedCompressionMethod;
            }
            /*CompressionMethodValues */ set CompressionMethod(value)
            {
                if (value === 8/*CompressionMethodValues.Deflate*/)
                {
                    this.VersionToExtractAtLeast(20/*ZipVersionNeededValues.Deflate*/);
                }
                else if (value === 9/*CompressionMethodValues.Deflate64*/)
                {
                    this.VersionToExtractAtLeast(21/*ZipVersionNeededValues.Deflate64*/);
                }
                this._storedCompressionMethod = value;
            }
            /*void */ WriteAndFinishLocalEntry(/*bool*/ forceWrite)
            {
                this.CloseStreams();
                this.WriteLocalFileHeaderAndDataIfNeeded(forceWrite);
                this.UnloadStreams();
            }
            /*bool */ WriteCentralDirectoryFileHeaderInitialize(/*bool*/ forceWrite, /*out Zip64ExtraField?*/ zip64ExtraField, /*out uint*/ compressedSizeTruncated, /*out uint*/ uncompressedSizeTruncated, /*out ushort*/ extraFieldLength, /*out uint*/ offsetOfLocalHeaderTruncated)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._storedEntryNameBytes.length <= 65535/*ushort.MaxValue*/, "_storedEntryNameBytes.Length <= ushort.MaxValue");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._fileComment.length <= 65535/*ushort.MaxValue*/, "_fileComment.Length <= ushort.MaxValue");
                zip64ExtraField.$v = null;
                if (this.AreSizesTooLarge)
                {
                    compressedSizeTruncated.$v = 4294967295/*ZipHelper.Mask32Bit*/;
                    uncompressedSizeTruncated.$v = 4294967295/*ZipHelper.Mask32Bit*/;
                    zip64ExtraField.$v = (() =>
                    {
                        //new $.$sic.System.IO.Compression.Zip64ExtraField()
                        const $t1 = $.$sic.System.IO.Compression.Zip64ExtraField;
                        const $i1 = new $t1();
                        $i1.CompressedSize = this._compressedSize;
                        $i1.UncompressedSize = this._uncompressedSize;
                        return $i1;
                    })();
                }
                else 
                {
                    compressedSizeTruncated.$v = $.$cast(this._compressedSize, $.$spc.System.UInt32);
                    uncompressedSizeTruncated.$v = $.$cast(this._uncompressedSize, $.$spc.System.UInt32);
                }
                if (this.IsOffsetTooLarge)
                {
                    offsetOfLocalHeaderTruncated.$v = 4294967295/*ZipHelper.Mask32Bit*/;
                    zip64ExtraField.$v ??= new $.$sic.System.IO.Compression.Zip64ExtraField().$ctor$1();
                    zip64ExtraField.$v.LocalHeaderOffset = this._offsetOfLocalHeader;
                }
                else 
                {
                    offsetOfLocalHeaderTruncated.$v = $.$cast(this._offsetOfLocalHeader, $.$spc.System.UInt32);
                }
                if (zip64ExtraField.$v !== null)
                {
                    this.VersionToExtractAtLeast(45/*ZipVersionNeededValues.Zip64*/);
                }
                const $t1 = this._cdTrailingExtraFieldData;
                /*int*/ let currExtraFieldDataLength = $.$sic.System.IO.Compression.ZipGenericExtraField.TotalSize(this._cdUnknownExtraFields, $.$ifnn($t1, ($t) => $t.length) ?? 0);
                /*int*/ let bigExtraFieldLength = (((zip64ExtraField.$v !== null ? zip64ExtraField.$v.TotalSize : 0) + currExtraFieldDataLength) | 0);
                if (bigExtraFieldLength > 65535/*ushort.MaxValue*/)
                {
                    extraFieldLength.$v = $.$cast((zip64ExtraField.$v !== null ? zip64ExtraField.$v.TotalSize : 0), $.$spc.System.UInt16);
                    this._cdUnknownExtraFields = null;
                }
                else 
                {
                    extraFieldLength.$v = $.$cast(bigExtraFieldLength, $.$spc.System.UInt16);
                }
                if (this._originallyInArchive && this.Changes === 0/*ZipArchive.ChangeState.Unchanged*/ && !forceWrite)
                {
                    /*long*/ let centralDirectoryHeaderLength = BigInt(((((((46/*ZipCentralDirectoryFileHeader.FieldLocations.DynamicData*/ + this._storedEntryNameBytes.length) | 0) + (zip64ExtraField.$v !== null ? zip64ExtraField.$v.TotalSize : 0)) | 0) + currExtraFieldDataLength) | 0) + this._fileComment.length);
                    this._archive.ArchiveStream.Seek(centralDirectoryHeaderLength, 1/*SeekOrigin.Current*/);
                    return false;
                }
                return true;
            }
            /*void */ WriteCentralDirectoryFileHeaderPrepare(/*Span<byte>*/ cdStaticHeader, /*uint*/ compressedSizeTruncated, /*uint*/ uncompressedSizeTruncated, /*ushort*/ extraFieldLength, /*uint*/ offsetOfLocalHeaderTruncated)
            {
                let $t1 = cdStaticHeader;
                $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.SignatureConstantBytes.CopyTo($t1.Slice$1(0/*ZipCentralDirectoryFileHeader.FieldLocations.Signature*/, $t1.Length - 0/*ZipCentralDirectoryFileHeader.FieldLocations.Signature*/));
                cdStaticHeader.get_Item(4/*ZipCentralDirectoryFileHeader.FieldLocations.VersionMadeBySpecification*/).$v = $.$cast(this._versionMadeBySpecification, $.$spc.System.Byte);
                cdStaticHeader.get_Item(5/*ZipCentralDirectoryFileHeader.FieldLocations.VersionMadeByCompatibility*/).$v = 3/*CurrentZipPlatform*/;
                let $t2 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t2.Slice$1(6/*ZipCentralDirectoryFileHeader.FieldLocations.VersionNeededToExtract*/, $t2.Length - 6/*ZipCentralDirectoryFileHeader.FieldLocations.VersionNeededToExtract*/), this._versionToExtract);
                let $t3 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t3.Slice$1(8/*ZipCentralDirectoryFileHeader.FieldLocations.GeneralPurposeBitFlags*/, $t3.Length - 8/*ZipCentralDirectoryFileHeader.FieldLocations.GeneralPurposeBitFlags*/), this._generalPurposeBitFlag);
                let $t4 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t4.Slice$1(10/*ZipCentralDirectoryFileHeader.FieldLocations.CompressionMethod*/, $t4.Length - 10/*ZipCentralDirectoryFileHeader.FieldLocations.CompressionMethod*/), this.CompressionMethod);
                let $t5 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t5.Slice$1(12/*ZipCentralDirectoryFileHeader.FieldLocations.LastModified*/, $t5.Length - 12/*ZipCentralDirectoryFileHeader.FieldLocations.LastModified*/), $.$sic.System.IO.Compression.ZipHelper.DateTimeToDosTime(this._lastModified.DateTime));
                let $t6 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t6.Slice$1(16/*ZipCentralDirectoryFileHeader.FieldLocations.Crc32*/, $t6.Length - 16/*ZipCentralDirectoryFileHeader.FieldLocations.Crc32*/), this._crc32);
                let $t7 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t7.Slice$1(20/*ZipCentralDirectoryFileHeader.FieldLocations.CompressedSize*/, $t7.Length - 20/*ZipCentralDirectoryFileHeader.FieldLocations.CompressedSize*/), compressedSizeTruncated);
                let $t8 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t8.Slice$1(24/*ZipCentralDirectoryFileHeader.FieldLocations.UncompressedSize*/, $t8.Length - 24/*ZipCentralDirectoryFileHeader.FieldLocations.UncompressedSize*/), uncompressedSizeTruncated);
                let $t9 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t9.Slice$1(28/*ZipCentralDirectoryFileHeader.FieldLocations.FilenameLength*/, $t9.Length - 28/*ZipCentralDirectoryFileHeader.FieldLocations.FilenameLength*/), $.$cast(this._storedEntryNameBytes.length, $.$spc.System.UInt16));
                let $t10 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t10.Slice$1(30/*ZipCentralDirectoryFileHeader.FieldLocations.ExtraFieldLength*/, $t10.Length - 30/*ZipCentralDirectoryFileHeader.FieldLocations.ExtraFieldLength*/), extraFieldLength);
                let $t11 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t11.Slice$1(32/*ZipCentralDirectoryFileHeader.FieldLocations.FileCommentLength*/, $t11.Length - 32/*ZipCentralDirectoryFileHeader.FieldLocations.FileCommentLength*/), $.$cast(this._fileComment.length, $.$spc.System.UInt16));
                let $t12 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t12.Slice$1(34/*ZipCentralDirectoryFileHeader.FieldLocations.DiskNumberStart*/, $t12.Length - 34/*ZipCentralDirectoryFileHeader.FieldLocations.DiskNumberStart*/), 0);
                let $t13 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t13.Slice$1(36/*ZipCentralDirectoryFileHeader.FieldLocations.InternalFileAttributes*/, $t13.Length - 36/*ZipCentralDirectoryFileHeader.FieldLocations.InternalFileAttributes*/), 0);
                let $t14 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t14.Slice$1(38/*ZipCentralDirectoryFileHeader.FieldLocations.ExternalFileAttributes*/, $t14.Length - 38/*ZipCentralDirectoryFileHeader.FieldLocations.ExternalFileAttributes*/), this._externalFileAttr);
                let $t15 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t15.Slice$1(42/*ZipCentralDirectoryFileHeader.FieldLocations.RelativeOffsetOfLocalHeader*/, $t15.Length - 42/*ZipCentralDirectoryFileHeader.FieldLocations.RelativeOffsetOfLocalHeader*/), offsetOfLocalHeaderTruncated);
            }
            /*void */ WriteCentralDirectoryFileHeader(/*bool*/ forceWrite)
            {
                /*Zip64ExtraField?*/ let zip64ExtraField;
                /*uint*/ let compressedSizeTruncated;
                /*uint*/ let uncompressedSizeTruncated;
                /*ushort*/ let extraFieldLength;
                /*uint*/ let offsetOfLocalHeaderTruncated;
                if (this.WriteCentralDirectoryFileHeaderInitialize(forceWrite, $.$ref(() => zip64ExtraField, ($v) => zip64ExtraField = $v, $.$sic.System.IO.Compression.Zip64ExtraField), $.$ref(() => compressedSizeTruncated, ($v) => compressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeTruncated, ($v) => uncompressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => extraFieldLength, ($v) => extraFieldLength = $v, $.$spc.System.UInt16), $.$ref(() => offsetOfLocalHeaderTruncated, ($v) => offsetOfLocalHeaderTruncated = $v, $.$spc.System.UInt32)))
                {
                    /*Span<byte>*/ let cdStaticHeader = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/, null);
                    this.WriteCentralDirectoryFileHeaderPrepare(cdStaticHeader, compressedSizeTruncated, uncompressedSizeTruncated, extraFieldLength, offsetOfLocalHeaderTruncated);
                    this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(cdStaticHeader));
                    this._archive.ArchiveStream.Write$1($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this._storedEntryNameBytes));
                    zip64ExtraField?.WriteBlock(this._archive.ArchiveStream);
                    $.$sic.System.IO.Compression.ZipGenericExtraField.WriteAllBlocks(this._cdUnknownExtraFields, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this._cdTrailingExtraFieldData ?? $.$spc.System.Array.Empty($.$spc.System.Byte)), this._archive.ArchiveStream);
                    if (this._fileComment.length > 0)
                    {
                        this._archive.ArchiveStream.Write$1($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this._fileComment));
                    }
                }
            }
            /*void */ LoadLocalHeaderExtraFieldIfNeeded()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsOpenable(false, true, $.$discardRef()), "IsOpenable(false, true, out _)");
                if (this._originallyInArchive)
                {
                    this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader, 0/*SeekOrigin.Begin*/);
                    this._lhUnknownExtraFields = $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFields(this._archive.ArchiveStream, $.$ref(() => this._lhTrailingExtraFieldData, ($v) => this._lhTrailingExtraFieldData = $v, $.$typeArray($.$spc.System.Byte)));
                }
            }
            /*byte[][] */ LoadCompressedBytesIfNeededInitialize(/*out int*/ maxSingleBufferSize)
            {
                maxSingleBufferSize.$v = $.$spc.System.Array.MaxLength;
                /*byte[][]*/ let compressedBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$spc.System.Byte)), null, [(this._compressedSize / BigInt(maxSingleBufferSize.$v)) + 1n], null);
                for(/*int*/ let i = 0; i < ((compressedBytes.length - 1) | 0); i++)
                {
                    $.$spc.System.Array.$WriteT1.call(compressedBytes, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [maxSingleBufferSize.$v], null), i);
                }
                $.$spc.System.Array.$WriteT1.call(compressedBytes, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [this._compressedSize % BigInt(maxSingleBufferSize.$v)], null), ((compressedBytes.length - 1) | 0));
                return compressedBytes;
            }
            /*void */ LoadCompressedBytesIfNeeded()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsOpenable(false, true, $.$discardRef()), "IsOpenable(false, true, out _)");
                if (!this._everOpenedForWrite && this._originallyInArchive)
                {
                    /*int*/ let maxSingleBufferSize;
                    this._compressedBytes = this.LoadCompressedBytesIfNeededInitialize($.$ref(() => maxSingleBufferSize, ($v) => maxSingleBufferSize = $v, $.$spc.System.Int32));
                    this._archive.ArchiveStream.Seek(this.GetOffsetOfCompressedData(), 0/*SeekOrigin.Begin*/);
                    for(/*int*/ let i = 0; i < ((this._compressedBytes.length - 1) | 0); i++)
                    {
                        this._archive.ArchiveStream.ReadAtLeast($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit($.$spc.System.Array.$ReadT1.call(this._compressedBytes, i)), maxSingleBufferSize, true);
                    }
                    this._archive.ArchiveStream.ReadAtLeast($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit($.$spc.System.Array.$ReadT1.call(this._compressedBytes, ((this._compressedBytes.length - 1) | 0))), $.$cast((this._compressedSize % BigInt(maxSingleBufferSize)), $.$spc.System.Int32), true);
                }
            }
            /*void */ ThrowIfNotOpenable(/*bool*/ needToUncompress, /*bool*/ needToLoadIntoMemory)
            {
                /*string?*/ let message;
                if (!this.IsOpenable(needToUncompress, needToLoadIntoMemory, $.$ref(() => message, ($v) => message = $v, $.$spc.System.String)))
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10(message);
                }
            }
            /*void */ DetectEntryNameVersion()
            {
                if ($.$spc.System.String.op_Equality($.$sic.System.IO.Compression.ZipArchiveEntry.ParseFileName(this._storedEntryName, this._versionMadeByPlatform), ""))
                {
                    this.VersionToExtractAtLeast(20/*ZipVersionNeededValues.ExplicitDirectory*/);
                }
            }
            /*CheckSumAndSizeWriteStream */ GetDataCompressor(/*Stream*/ backingStream, /*bool*/ leaveBackingStreamOpen, /*EventHandler?*/ onClose)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.CompressionMethod === 8/*CompressionMethodValues.Deflate*/ || this.CompressionMethod === 0/*CompressionMethodValues.Stored*/, "CompressionMethod == CompressionMethodValues.Deflate\r\n                || CompressionMethod == CompressionMethodValues.Stored");
                /*bool*/ let isIntermediateStream = true;
                /*Stream*/ let compressorStream;
                switch(this.CompressionMethod)
                {
                    case 0/*CompressionMethodValues.Stored*/:
                    compressorStream = backingStream;
                    isIntermediateStream = false;
                    break;
                    case 8/*CompressionMethodValues.Deflate*/:
                    case 9/*CompressionMethodValues.Deflate64*/:
                    default:
                    compressorStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$7(backingStream, this._compressionLevel, leaveBackingStreamOpen);
                    break;
                }
                /*bool*/ let leaveCompressorStreamOpenOnClose = leaveBackingStreamOpen && !isIntermediateStream;
                /*var*/ let checkSumStream = new $.$sic.System.IO.Compression.CheckSumAndSizeWriteStream().$ctor$3(compressorStream, backingStream, leaveCompressorStreamOpenOnClose, this, onClose, new ($.$spc.System.Action$$$$$$$($.$spc.System.Int64, $.$spc.System.Int64, $.$spc.System.UInt32, $.$spc.System.IO.Stream, $.$sic.System.IO.Compression.ZipArchiveEntry, $.$spc.System.EventHandler))().$ctor(this,  (/*long*/ initialPosition, /*long*/ currentPosition, /*uint*/ checkSum, /*Stream*/ backing, /*ZipArchiveEntry*/ thisRef, /*EventHandler?*/ closeHandler) =>
                {
                    thisRef._crc32 = checkSum;
                    thisRef._uncompressedSize = currentPosition;
                    thisRef._compressedSize = backing.Position - initialPosition;
                    closeHandler?.Invoke(thisRef, $.$spc.System.EventArgs.Empty);
                }, {"r":65537,"p":[{"n":"initialPosition","p":917505},{"n":"currentPosition","p":917505},{"n":"checkSum","p":720897},{"n":"backing","p":62193665},{"n":"thisRef","p":2684306},{"n":"closeHandler","p":47054849}],"n":"","d":2684306,"h":0,"f":1048578}));
                return checkSumStream;
            }
            /*Stream */ GetDataDecompressor(/*Stream*/ compressedStreamToRead)
            {
                /*Stream?*/ let uncompressedStream;
                switch(this.CompressionMethod)
                {
                    case 8/*CompressionMethodValues.Deflate*/:
                    uncompressedStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$3(compressedStreamToRead, 0/*CompressionMode.Decompress*/, this._uncompressedSize);
                    break;
                    case 9/*CompressionMethodValues.Deflate64*/:
                    uncompressedStream = new $.$sic.System.IO.Compression.DeflateManagedStream().$ctor$3(compressedStreamToRead, 9/*CompressionMethodValues.Deflate64*/, this._uncompressedSize);
                    break;
                    case 0/*CompressionMethodValues.Stored*/:
                    default:
                    $.$spc.System.Diagnostics.Debug.Assert$1(this.CompressionMethod === 0/*CompressionMethodValues.Stored*/, "CompressionMethod == CompressionMethodValues.Stored");
                    uncompressedStream = compressedStreamToRead;
                    break;
                }
                return uncompressedStream;
            }
            /*Stream */ OpenInReadMode(/*bool*/ checkOpenable)
            {
                if (checkOpenable)
                {
                    this.ThrowIfNotOpenable(true, false);
                }
                return this.OpenInReadModeGetDataCompressor(this.GetOffsetOfCompressedData());
            }
            /*Stream */ OpenInReadModeGetDataCompressor(/*long*/ offsetOfCompressedData)
            {
                /*Stream*/ let compressedStream = new $.$sic.System.IO.Compression.SubReadStream().$ctor$3(this._archive.ArchiveStream, offsetOfCompressedData, this._compressedSize);
                return this.GetDataDecompressor(compressedStream);
            }
            /*WrappedStream */ OpenInWriteMode()
            {
                if (this._everOpenedForWrite)
                {
                    throw new $.$spc.System.IO.IOException().$ctor$10($.$sic.System.SR.CreateModeWriteOnceAndOneEntryAtATime);
                }
                this._archive.DebugAssertIsStillArchiveStreamOwner(this);
                this._everOpenedForWrite = true;
                this.Changes |= 4/*ZipArchive.ChangeState.StoredData*/;
                /*CheckSumAndSizeWriteStream*/ let crcSizeStream = this.GetDataCompressor(this._archive.ArchiveStream, true, new $.$spc.System.EventHandler().$ctor(this,  (/*object?*/ o, /*EventArgs*/ e) =>
                {
                    /*var*/ let entry = $.$cast(o, $.$sic.System.IO.Compression.ZipArchiveEntry);
                    entry._archive.ReleaseArchiveStream(entry);
                    entry._outstandingWriteStream = null;
                }, {"r":65537,"p":[{"n":"o","p":131073},{"n":"e","p":46989313}],"n":"","d":2684306,"h":0,"f":1048578}));
                this._outstandingWriteStream = new $.$sic.System.IO.Compression.ZipArchiveEntry.DirectToArchiveWriterStream().$ctor$3(crcSizeStream, this);
                return new $.$sic.System.IO.Compression.WrappedStream().$ctor$3(this._outstandingWriteStream, true);
            }
            /*WrappedStream */ OpenInUpdateMode()
            {
                if (this._currentlyOpenForWrite)
                {
                    throw new $.$spc.System.IO.IOException().$ctor$10($.$sic.System.SR.UpdateModeOneStream);
                }
                this.ThrowIfNotOpenable(true, true);
                this._everOpenedForWrite = true;
                this.Changes |= 4/*ZipArchive.ChangeState.StoredData*/;
                this._currentlyOpenForWrite = true;
                /*Stream*/ let uncompressedData = this.GetUncompressedData();
                uncompressedData.Seek(0n, 0/*SeekOrigin.Begin*/);
                return new $.$sic.System.IO.Compression.WrappedStream().$ctor$5(uncompressedData, this, new ($.$spc.System.Action$$($.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor(this,  (/*thisRef*/ thisRef) =>
                {
                    thisRef._currentlyOpenForWrite = false;
                }, {"r":65537,"p":[{"n":"thisRef","p":2684306}],"n":"","d":2684306,"h":0,"f":1048578}));
            }
            /*bool */ IsOpenable(/*bool*/ needToUncompress, /*bool*/ needToLoadIntoMemory, /*out string?*/ message)
            {
                message.$v = null;
                if (this._originallyInArchive)
                {
                    if (!this.IsOpenableInitialVerifications(needToUncompress, message))
                    {
                        return false;
                    }
                    if (!$.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlock(this._archive.ArchiveStream))
                    {
                        message.$v = $.$sic.System.SR.LocalFileHeaderCorrupt;
                        return false;
                    }
                    /*long*/ let offsetOfCompressedData = this.GetOffsetOfCompressedData();
                    if (!this.IsOpenableFinalVerifications(needToLoadIntoMemory, offsetOfCompressedData, message))
                    {
                        return false;
                    }
                    return true;
                }
                return true;
            }
            /*bool */ IsOpenableInitialVerifications(/*bool*/ needToUncompress, /*out string?*/ message)
            {
                message.$v = null;
                if (needToUncompress)
                {
                    if (this.CompressionMethod !== 0/*CompressionMethodValues.Stored*/ && this.CompressionMethod !== 8/*CompressionMethodValues.Deflate*/ && this.CompressionMethod !== 9/*CompressionMethodValues.Deflate64*/)
                    {
                        message.$v = (() =>
                        {
                            if ((this.CompressionMethod === 12/*CompressionMethodValues.BZip2*/) || (this.CompressionMethod === 14/*CompressionMethodValues.LZMA*/))
                            {
                                return $.$sic.System.SR.Format($.$sic.System.SR.UnsupportedCompressionMethod, $.$spc.System.Enum.ToStringT($.$sic.System.IO.Compression.ZipArchiveEntry.CompressionMethodValues, $.$spc.System.UInt16, this.CompressionMethod));
                            }
                            return $.$sic.System.SR.UnsupportedCompression;
                        })();
                        return false;
                    }
                }
                if (this._diskNumberStart !== this._archive.NumberOfThisDisk)
                {
                    message.$v = $.$sic.System.SR.SplitSpanned;
                    return false;
                }
                if (this._offsetOfLocalHeader > this._archive.ArchiveStream.Length)
                {
                    message.$v = $.$sic.System.SR.LocalFileHeaderCorrupt;
                    return false;
                }
                this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader, 0/*SeekOrigin.Begin*/);
                return true;
            }
            /*bool */ IsOpenableFinalVerifications(/*bool*/ needToLoadIntoMemory, /*long*/ offsetOfCompressedData, /*out string?*/ message)
            {
                message.$v = null;
                if (offsetOfCompressedData + this._compressedSize > this._archive.ArchiveStream.Length)
                {
                    message.$v = $.$sic.System.SR.LocalFileHeaderCorrupt;
                    return false;
                }
                if (needToLoadIntoMemory)
                {
                    if (this._compressedSize > BigInt(2147483647/*int.MaxValue*/))
                    {
                        if (!$.$sic.System.IO.Compression.ZipArchiveEntry.s_allowLargeZipArchiveEntriesInUpdateMode)
                        {
                            message.$v = $.$sic.System.SR.EntryTooLarge;
                            return false;
                        }
                    }
                }
                return true;
            }
            /*bool */ get AreSizesTooLarge()
            {
                return this._compressedSize > BigInt(4294967295/*uint.MaxValue*/) || this._uncompressedSize > BigInt(4294967295/*uint.MaxValue*/);
            }
            static /*CompressionLevel */ MapCompressionLevel(/*BitFlagValues*/ generalPurposeBitFlag, /*CompressionMethodValues*/ compressionMethod)
            {
                if (compressionMethod === 8/*CompressionMethodValues.Deflate*/ || compressionMethod === 9/*CompressionMethodValues.Deflate64*/)
                {
                    return (() =>
                    {
                        let $switch1 = ($.$cast(generalPurposeBitFlag, $.$spc.System.Int32) & 6);
                        if ($switch1 === 0)
                        {
                            return 0/*CompressionLevel.Optimal*/;
                        }
                        if ($switch1 === 2)
                        {
                            return 3/*CompressionLevel.SmallestSize*/;
                        }
                        if ($switch1 === 4)
                        {
                            return 1/*CompressionLevel.Fastest*/;
                        }
                        if ($switch1 === 6)
                        {
                            return 1/*CompressionLevel.Fastest*/;
                        }
                        return 0/*CompressionLevel.Optimal*/;
                    })();
                }
                else 
                {
                    return 2/*CompressionLevel.NoCompression*/;
                }
            }
            static /*BitFlagValues */ MapDeflateCompressionOption(/*BitFlagValues*/ generalPurposeBitFlag, /*CompressionLevel*/ compressionLevel, /*CompressionMethodValues*/ compressionMethod)
            {
                /*ushort*/ let deflateCompressionOptions = $.$cast((compressionMethod === 8/*CompressionMethodValues.Deflate*/ || compressionMethod === 9/*CompressionMethodValues.Deflate64*/ ? (() =>
                {
                    if (compressionLevel === 0/*CompressionLevel.Optimal*/)
                    {
                        return 0;
                    }
                    if (compressionLevel === 3/*CompressionLevel.SmallestSize*/)
                    {
                        return 2;
                    }
                    if (compressionLevel === 1/*CompressionLevel.Fastest*/)
                    {
                        return 6;
                    }
                    if (compressionLevel === 2/*CompressionLevel.NoCompression*/)
                    {
                        return 6;
                    }
                    return 0;
                })() : 0), $.$spc.System.UInt16);
                return $.$cast((($.$cast(generalPurposeBitFlag, $.$spc.System.Int32) & ~6) | deflateCompressionOptions), $.$sic.System.IO.Compression.ZipArchiveEntry.BitFlagValues);
            }
            /*bool */ get IsOffsetTooLarge()
            {
                return this._offsetOfLocalHeader > BigInt(4294967295/*uint.MaxValue*/);
            }
            /*bool */ get ShouldUseZIP64()
            {
                return this.AreSizesTooLarge || this.IsOffsetTooLarge;
            }
            /*bool */ WriteLocalFileHeaderInitialize(/*bool*/ isEmptyFile, /*bool*/ forceWrite, /*out Zip64ExtraField?*/ zip64ExtraField, /*out uint*/ compressedSizeTruncated, /*out uint*/ uncompressedSizeTruncated, /*out ushort*/ extraFieldLength)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._storedEntryNameBytes.length <= 65535/*ushort.MaxValue*/, "_storedEntryNameBytes.Length <= ushort.MaxValue");
                zip64ExtraField.$v = null;
                this._offsetOfLocalHeader = this._archive.ArchiveStream.Position;
                if (isEmptyFile)
                {
                    this.CompressionMethod = 0/*CompressionMethodValues.Stored*/;
                    compressedSizeTruncated.$v = 0;
                    uncompressedSizeTruncated.$v = 0;
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._compressedSize === 0n, "_compressedSize == 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._uncompressedSize === 0n, "_uncompressedSize == 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._crc32 === 0, "_crc32 == 0");
                }
                else 
                {
                    if (this._archive.Mode === 1/*ZipArchiveMode.Create*/ && this._archive.ArchiveStream.CanSeek === false)
                    {
                        this._generalPurposeBitFlag |= 8/*BitFlagValues.DataDescriptor*/;
                        compressedSizeTruncated.$v = 0;
                        uncompressedSizeTruncated.$v = 0;
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._crc32 === 0, "_crc32 == 0");
                    }
                    else 
                    {
                        this._generalPurposeBitFlag &= ~8/*BitFlagValues.DataDescriptor*/;
                        if (this.ShouldUseZIP64)
                        {
                            compressedSizeTruncated.$v = 4294967295/*ZipHelper.Mask32Bit*/;
                            uncompressedSizeTruncated.$v = 4294967295/*ZipHelper.Mask32Bit*/;
                            zip64ExtraField.$v = (() =>
                            {
                                //new $.$sic.System.IO.Compression.Zip64ExtraField()
                                const $t1 = $.$sic.System.IO.Compression.Zip64ExtraField;
                                const $i1 = new $t1();
                                $i1.CompressedSize = this._compressedSize;
                                $i1.UncompressedSize = this._uncompressedSize;
                                return $i1;
                            })();
                            this.VersionToExtractAtLeast(45/*ZipVersionNeededValues.Zip64*/);
                        }
                        else 
                        {
                            compressedSizeTruncated.$v = $.$cast(this._compressedSize, $.$spc.System.UInt32);
                            uncompressedSizeTruncated.$v = $.$cast(this._uncompressedSize, $.$spc.System.UInt32);
                        }
                    }
                }
                this._offsetOfLocalHeader = this._archive.ArchiveStream.Position;
                const $t1 = this._lhTrailingExtraFieldData;
                /*int*/ let currExtraFieldDataLength = $.$sic.System.IO.Compression.ZipGenericExtraField.TotalSize(this._lhUnknownExtraFields, $.$ifnn($t1, ($t) => $t.length) ?? 0);
                /*int*/ let bigExtraFieldLength = (((zip64ExtraField.$v !== null ? zip64ExtraField.$v.TotalSize : 0) + currExtraFieldDataLength) | 0);
                if (bigExtraFieldLength > 65535/*ushort.MaxValue*/)
                {
                    extraFieldLength.$v = $.$cast((zip64ExtraField.$v !== null ? zip64ExtraField.$v.TotalSize : 0), $.$spc.System.UInt16);
                    this._lhUnknownExtraFields = null;
                }
                else 
                {
                    extraFieldLength.$v = $.$cast(bigExtraFieldLength, $.$spc.System.UInt16);
                }
                if (this._originallyInArchive && this.Changes === 0/*ZipArchive.ChangeState.Unchanged*/ && !forceWrite)
                {
                    this._archive.ArchiveStream.Seek(BigInt(30/*ZipLocalFileHeader.SizeOfLocalHeader*/ + this._storedEntryNameBytes.length), 1/*SeekOrigin.Current*/);
                    if (zip64ExtraField.$v !== null)
                    {
                        this._archive.ArchiveStream.Seek(BigInt(zip64ExtraField.$v.TotalSize), 1/*SeekOrigin.Current*/);
                    }
                    this._archive.ArchiveStream.Seek(BigInt(currExtraFieldDataLength), 1/*SeekOrigin.Current*/);
                    return false;
                }
                return true;
            }
            /*void */ WriteLocalFileHeaderPrepare(/*Span<byte>*/ lfStaticHeader, /*uint*/ compressedSizeTruncated, /*uint*/ uncompressedSizeTruncated, /*ushort*/ extraFieldLength)
            {
                let $t1 = lfStaticHeader;
                $.$sic.System.IO.Compression.ZipLocalFileHeader.SignatureConstantBytes.CopyTo($t1.Slice$1(0/*ZipLocalFileHeader.FieldLocations.Signature*/, $t1.Length - 0/*ZipLocalFileHeader.FieldLocations.Signature*/));
                let $t2 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t2.Slice$1(4/*ZipLocalFileHeader.FieldLocations.VersionNeededToExtract*/, $t2.Length - 4/*ZipLocalFileHeader.FieldLocations.VersionNeededToExtract*/), this._versionToExtract);
                let $t3 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t3.Slice$1(6/*ZipLocalFileHeader.FieldLocations.GeneralPurposeBitFlags*/, $t3.Length - 6/*ZipLocalFileHeader.FieldLocations.GeneralPurposeBitFlags*/), this._generalPurposeBitFlag);
                let $t4 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t4.Slice$1(8/*ZipLocalFileHeader.FieldLocations.CompressionMethod*/, $t4.Length - 8/*ZipLocalFileHeader.FieldLocations.CompressionMethod*/), this.CompressionMethod);
                let $t5 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t5.Slice$1(10/*ZipLocalFileHeader.FieldLocations.LastModified*/, $t5.Length - 10/*ZipLocalFileHeader.FieldLocations.LastModified*/), $.$sic.System.IO.Compression.ZipHelper.DateTimeToDosTime(this._lastModified.DateTime));
                let $t6 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t6.Slice$1(14/*ZipLocalFileHeader.FieldLocations.Crc32*/, $t6.Length - 14/*ZipLocalFileHeader.FieldLocations.Crc32*/), this._crc32);
                let $t7 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t7.Slice$1(18/*ZipLocalFileHeader.FieldLocations.CompressedSize*/, $t7.Length - 18/*ZipLocalFileHeader.FieldLocations.CompressedSize*/), compressedSizeTruncated);
                let $t8 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t8.Slice$1(22/*ZipLocalFileHeader.FieldLocations.UncompressedSize*/, $t8.Length - 22/*ZipLocalFileHeader.FieldLocations.UncompressedSize*/), uncompressedSizeTruncated);
                let $t9 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t9.Slice$1(26/*ZipLocalFileHeader.FieldLocations.FilenameLength*/, $t9.Length - 26/*ZipLocalFileHeader.FieldLocations.FilenameLength*/), $.$cast(this._storedEntryNameBytes.length, $.$spc.System.UInt16));
                let $t10 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t10.Slice$1(28/*ZipLocalFileHeader.FieldLocations.ExtraFieldLength*/, $t10.Length - 28/*ZipLocalFileHeader.FieldLocations.ExtraFieldLength*/), extraFieldLength);
            }
            /*bool */ WriteLocalFileHeader(/*bool*/ isEmptyFile, /*bool*/ forceWrite)
            {
                /*Zip64ExtraField?*/ let zip64ExtraField;
                /*uint*/ let compressedSizeTruncated;
                /*uint*/ let uncompressedSizeTruncated;
                /*ushort*/ let extraFieldLength;
                if (this.WriteLocalFileHeaderInitialize(isEmptyFile, forceWrite, $.$ref(() => zip64ExtraField, ($v) => zip64ExtraField = $v, $.$sic.System.IO.Compression.Zip64ExtraField), $.$ref(() => compressedSizeTruncated, ($v) => compressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeTruncated, ($v) => uncompressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => extraFieldLength, ($v) => extraFieldLength = $v, $.$spc.System.UInt16)))
                {
                    /*Span<byte>*/ let lfStaticHeader = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 30/*ZipLocalFileHeader.SizeOfLocalHeader*/, null);
                    this.WriteLocalFileHeaderPrepare(lfStaticHeader, compressedSizeTruncated, uncompressedSizeTruncated, extraFieldLength);
                    this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(lfStaticHeader));
                    this._archive.ArchiveStream.Write$1($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this._storedEntryNameBytes));
                    zip64ExtraField?.WriteBlock(this._archive.ArchiveStream);
                    $.$sic.System.IO.Compression.ZipGenericExtraField.WriteAllBlocks(this._lhUnknownExtraFields, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this._lhTrailingExtraFieldData ?? $.$spc.System.Array.Empty($.$spc.System.Byte)), this._archive.ArchiveStream);
                }
                return zip64ExtraField !== null;
            }
            /*void */ WriteLocalFileHeaderAndDataIfNeeded(/*bool*/ forceWrite)
            {
                if (this._storedUncompressedData !== null || this._compressedBytes !== null)
                {
                    if (this._storedUncompressedData !== null)
                    {
                        this._uncompressedSize = this._storedUncompressedData.Length;
                        let entryWriter = null;
                        try
                        {
                            entryWriter = new $.$sic.System.IO.Compression.ZipArchiveEntry.DirectToArchiveWriterStream().$ctor$3(this.GetDataCompressor(this._archive.ArchiveStream, true, null), this);
                            this._storedUncompressedData.Seek(0n, 0/*SeekOrigin.Begin*/);
                            this._storedUncompressedData.CopyTo(entryWriter);
                            this._storedUncompressedData.Dispose();
                            this._storedUncompressedData = null;
                        }
                        finally
                        {
                            entryWriter?.System$IDisposable$Dispose();
                        }
                    }
                    else 
                    {
                        if (this._uncompressedSize === 0n)
                        {
                            this._compressedSize = 0n;
                        }
                        this.WriteLocalFileHeader(this._uncompressedSize === 0n, true);
                        if (this._uncompressedSize !== 0n)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._compressedBytes !== null, "_compressedBytes != null");
                            let $i1 = 0;
                            let $arr1 = this._compressedBytes;
                            while ($i1 < $arr1.length)
                            {
                                let compressedBytes = $arr1[$i1++];
                                this._archive.ArchiveStream.Write(compressedBytes, 0, compressedBytes.length);
                            }
                        }
                    }
                }
                else 
                {
                    if (this._archive.Mode === 2/*ZipArchiveMode.Update*/ || !this._everOpenedForWrite)
                    {
                        this._everOpenedForWrite = true;
                        this.WriteLocalFileHeader(this._uncompressedSize === 0n, forceWrite);
                        if (this._compressedSize !== 0n)
                        {
                            this._archive.ArchiveStream.Seek(this._compressedSize, 1/*SeekOrigin.Current*/);
                        }
                    }
                }
            }
            /*int*/ static MetadataBufferLength = 4;
            /*int*/ static CrcAndSizesBufferLength = 12;
            /*int*/ static Zip64SizesBufferLength = 16;
            /*int*/ static Zip64DataDescriptorCrcAndSizesBufferLength = 20;
            /*void */ WriteCrcAndSizesInLocalHeader(/*bool*/ zip64HeaderUsed)
            {
                /*Span<byte>*/ let writeBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 20/*Zip64DataDescriptorCrcAndSizesBufferLength*/, null);
                /*long*/ let finalPosition;
                /*bool*/ let pretendStreaming;
                /*uint*/ let compressedSizeTruncated;
                /*uint*/ let uncompressedSizeTruncated;
                this.WriteCrcAndSizesInLocalHeaderInitialize(zip64HeaderUsed, $.$ref(() => finalPosition, ($v) => finalPosition = $v, $.$spc.System.Int64), $.$ref(() => pretendStreaming, ($v) => pretendStreaming = $v, $.$spc.System.Boolean), $.$ref(() => compressedSizeTruncated, ($v) => compressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeTruncated, ($v) => uncompressedSizeTruncated = $v, $.$spc.System.UInt32));
                if (pretendStreaming)
                {
                    this.WriteCrcAndSizesInLocalHeaderPrepareForZip64PretendStreaming(writeBuffer);
                    let $t5 = writeBuffer;
                    this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t5.Slice$1(0, 4/*MetadataBufferLength*/)));
                }
                this.WriteCrcAndSizesInLocalHeaderPrepareFor32bitValuesWriting(pretendStreaming, writeBuffer, compressedSizeTruncated, uncompressedSizeTruncated);
                let $t5 = writeBuffer;
                this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t5.Slice$1(0, 12/*CrcAndSizesBufferLength*/)));
                if (zip64HeaderUsed)
                {
                    this.WriteCrcAndSizesInLocalHeaderPrepareForWritingWhenZip64HeaderUsed(writeBuffer);
                    let $t6 = writeBuffer;
                    this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t6.Slice$1(0, 16/*Zip64SizesBufferLength*/)));
                }
                this._archive.ArchiveStream.Seek(finalPosition, 0/*SeekOrigin.Begin*/);
                if (pretendStreaming)
                {
                    this.WriteCrcAndSizesInLocalHeaderPrepareForWritingDataDescriptor(writeBuffer);
                    let $t6 = writeBuffer;
                    this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t6.Slice$1(0, 20/*Zip64DataDescriptorCrcAndSizesBufferLength*/)));
                }
            }
            /*void */ WriteCrcAndSizesInLocalHeaderInitialize(/*bool*/ zip64HeaderUsed, /*out long*/ finalPosition, /*out bool*/ pretendStreaming, /*out uint*/ compressedSizeTruncated, /*out uint*/ uncompressedSizeTruncated)
            {
                finalPosition.$v = this._archive.ArchiveStream.Position;
                /*bool*/ let zip64Needed = this.ShouldUseZIP64;
                pretendStreaming.$v = zip64Needed && !zip64HeaderUsed;
                compressedSizeTruncated.$v = zip64Needed ? 4294967295/*ZipHelper.Mask32Bit*/ : $.$cast(this._compressedSize, $.$spc.System.UInt32);
                uncompressedSizeTruncated.$v = zip64Needed ? 4294967295/*ZipHelper.Mask32Bit*/ : $.$cast(this._uncompressedSize, $.$spc.System.UInt32);
            }
            /*void */ WriteCrcAndSizesInLocalHeaderPrepareForZip64PretendStreaming(/*Span<byte>*/ writeBuffer)
            {
                /*int*/ let relativeVersionToExtractLocation = ((4/*ZipLocalFileHeader.FieldLocations.VersionNeededToExtract*/ - 4/*ZipLocalFileHeader.FieldLocations.VersionNeededToExtract*/) | 0);
                /*int*/ let relativeGeneralPurposeBitFlagsLocation = ((6/*ZipLocalFileHeader.FieldLocations.GeneralPurposeBitFlags*/ - 4/*ZipLocalFileHeader.FieldLocations.VersionNeededToExtract*/) | 0);
                this.VersionToExtractAtLeast(45/*ZipVersionNeededValues.Zip64*/);
                this._generalPurposeBitFlag |= 8/*BitFlagValues.DataDescriptor*/;
                this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader + BigInt(4/*ZipLocalFileHeader.FieldLocations.VersionNeededToExtract*/), 0/*SeekOrigin.Begin*/);
                let $t1 = writeBuffer;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t1.Slice$1(relativeVersionToExtractLocation, $t1.Length - relativeVersionToExtractLocation), this._versionToExtract);
                let $t2 = writeBuffer;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t2.Slice$1(relativeGeneralPurposeBitFlagsLocation, $t2.Length - relativeGeneralPurposeBitFlagsLocation), this._generalPurposeBitFlag);
            }
            /*void */ WriteCrcAndSizesInLocalHeaderPrepareFor32bitValuesWriting(/*bool*/ pretendStreaming, /*Span<byte>*/ writeBuffer, /*uint*/ compressedSizeTruncated, /*uint*/ uncompressedSizeTruncated)
            {
                this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader + BigInt(14/*ZipLocalFileHeader.FieldLocations.Crc32*/), 0/*SeekOrigin.Begin*/);
                if (!pretendStreaming)
                {
                    /*int*/ let relativeCrc32Location = ((14/*ZipLocalFileHeader.FieldLocations.Crc32*/ - 14/*ZipLocalFileHeader.FieldLocations.Crc32*/) | 0);
                    /*int*/ let relativeCompressedSizeLocation = ((18/*ZipLocalFileHeader.FieldLocations.CompressedSize*/ - 14/*ZipLocalFileHeader.FieldLocations.Crc32*/) | 0);
                    /*int*/ let relativeUncompressedSizeLocation = ((22/*ZipLocalFileHeader.FieldLocations.UncompressedSize*/ - 14/*ZipLocalFileHeader.FieldLocations.Crc32*/) | 0);
                    let $t1 = writeBuffer;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t1.Slice$1(relativeCrc32Location, $t1.Length - relativeCrc32Location), this._crc32);
                    let $t2 = writeBuffer;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t2.Slice$1(relativeCompressedSizeLocation, $t2.Length - relativeCompressedSizeLocation), compressedSizeTruncated);
                    let $t3 = writeBuffer;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t3.Slice$1(relativeUncompressedSizeLocation, $t3.Length - relativeUncompressedSizeLocation), uncompressedSizeTruncated);
                }
                else 
                {
                    let $t1 = writeBuffer;
                    $t1.Slice$1(0, 12/*CrcAndSizesBufferLength*/).Clear();
                }
            }
            /*void */ WriteCrcAndSizesInLocalHeaderPrepareForWritingWhenZip64HeaderUsed(/*Span<byte>*/ writeBuffer)
            {
                /*int*/ let relativeUncompressedSizeLocation = ((4/*Zip64ExtraField.FieldLocations.UncompressedSize*/ - 4/*Zip64ExtraField.FieldLocations.UncompressedSize*/) | 0);
                /*int*/ let relativeCompressedSizeLocation = ((12/*Zip64ExtraField.FieldLocations.CompressedSize*/ - 4/*Zip64ExtraField.FieldLocations.UncompressedSize*/) | 0);
                this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader + BigInt(30/*ZipLocalFileHeader.SizeOfLocalHeader*/) + BigInt(this._storedEntryNameBytes.length) + BigInt(4/*Zip64ExtraField.OffsetToFirstField*/), 0/*SeekOrigin.Begin*/);
                let $t1 = writeBuffer;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t1.Slice$1(relativeUncompressedSizeLocation, $t1.Length - relativeUncompressedSizeLocation), this._uncompressedSize);
                let $t2 = writeBuffer;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t2.Slice$1(relativeCompressedSizeLocation, $t2.Length - relativeCompressedSizeLocation), this._compressedSize);
            }
            /*void */ WriteCrcAndSizesInLocalHeaderPrepareForWritingDataDescriptor(/*Span<byte>*/ writeBuffer)
            {
                /*int*/ let relativeCrc32Location = ((4/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.Crc32*/ - 4/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.Crc32*/) | 0);
                /*int*/ let relativeCompressedSizeLocation = ((8/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.CompressedSize*/ - 4/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.Crc32*/) | 0);
                /*int*/ let relativeUncompressedSizeLocation = ((16/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.UncompressedSize*/ - 4/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.Crc32*/) | 0);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian(writeBuffer.Slice(relativeCrc32Location), this._crc32);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian(writeBuffer.Slice(relativeCompressedSizeLocation), this._compressedSize);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian(writeBuffer.Slice(relativeUncompressedSizeLocation), this._uncompressedSize);
            }
            /*int*/ static MaxSizeOfDataDescriptor = 24;
            /*void */ WriteDataDescriptor()
            {
                /*Span<byte>*/ let dataDescriptor = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 24/*MaxSizeOfDataDescriptor*/, null);
                /*int*/ let bytesToWrite = this.PrepareToWriteDataDescriptor(dataDescriptor);
                let $t1 = dataDescriptor;
                this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t1.Slice$1(0, bytesToWrite)));
            }
            /*int */ PrepareToWriteDataDescriptor(/*Span<byte>*/ dataDescriptor)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((this._generalPurposeBitFlag & 8/*BitFlagValues.DataDescriptor*/) !== 0, "(_generalPurposeBitFlag & BitFlagValues.DataDescriptor) != 0");
                /*int*/ let bytesToWrite;
                let $t1 = dataDescriptor;
                $.$sic.System.IO.Compression.ZipLocalFileHeader.DataDescriptorSignatureConstantBytes.CopyTo($t1.Slice$1(0/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.Signature*/, $t1.Length - 0/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.Signature*/));
                let $t2 = dataDescriptor;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t2.Slice$1(4/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.Crc32*/, $t2.Length - 4/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.Crc32*/), this._crc32);
                if (this.AreSizesTooLarge)
                {
                    let $t3 = dataDescriptor;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t3.Slice$1(8/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.CompressedSize*/, $t3.Length - 8/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.CompressedSize*/), this._compressedSize);
                    let $t4 = dataDescriptor;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t4.Slice$1(16/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.UncompressedSize*/, $t4.Length - 16/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.UncompressedSize*/), this._uncompressedSize);
                    bytesToWrite = ((16/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.UncompressedSize*/ + 8/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLengths.UncompressedSize*/) | 0);
                }
                else 
                {
                    let $t3 = dataDescriptor;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t3.Slice$1(8/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.CompressedSize*/, $t3.Length - 8/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.CompressedSize*/), $.$cast(this._compressedSize, $.$spc.System.UInt32));
                    let $t4 = dataDescriptor;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t4.Slice$1(12/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.UncompressedSize*/, $t4.Length - 12/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.UncompressedSize*/), $.$cast(this._uncompressedSize, $.$spc.System.UInt32));
                    bytesToWrite = ((12/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.UncompressedSize*/ + 4/*ZipLocalFileHeader.ZipDataDescriptor.FieldLengths.UncompressedSize*/) | 0);
                }
                return bytesToWrite;
            }
            /*void */ UnloadStreams()
            {
                this._storedUncompressedData?.Dispose();
                this._compressedBytes = null;
                this._outstandingWriteStream = null;
            }
            /*void */ CloseStreams()
            {
                this._outstandingWriteStream?.Dispose();
            }
            /*void */ VersionToExtractAtLeast(/*ZipVersionNeededValues*/ value)
            {
                if (this._versionToExtract < value)
                {
                    this._versionToExtract = value;
                    this.Changes |= 1/*ZipArchive.ChangeState.FixedLengthMetadata*/;
                }
                if (this._versionMadeBySpecification < value)
                {
                    this._versionMadeBySpecification = value;
                    this.Changes |= 1/*ZipArchive.ChangeState.FixedLengthMetadata*/;
                }
            }
            /*void */ ThrowIfInvalidArchive()
            {
                if (this._archive === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.DeletedEntry);
                }
                this._archive.ThrowIfDisposed();
            }
            static /*string */ GetFileName_Windows(/*string*/ path)
            {
                /*int*/ let i = $.$spc.System.MemoryExtensions.LastIndexOfAny$6($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(path), /*\\*/ 92, /*/*/ 47, /*:*/ 58);
                return i >= 0 ? $.$spc.System.String.Substring.call(path, ((i + 1) | 0)) : path;
            }
            static /*string */ GetFileName_Unix(/*string*/ path)
            {
                /*int*/ let i = $.$spc.System.String.LastIndexOf.call(path, /*/*/ 47);
                return i >= 0 ? $.$spc.System.String.Substring.call(path, ((i + 1) | 0)) : path;
            }
            static $_DirectToArchiveWriterStream;
            static get DirectToArchiveWriterStream()
            {
                let $cls = $.$sic.System.IO.Compression.ZipArchiveEntry;
                return $cls.$_DirectToArchiveWriterStream ??= $asm.$ncls("$sic.System.IO.Compression.ZipArchiveEntry.DirectToArchiveWriterStream", ($self) => class DirectToArchiveWriterStream extends $.$spc.System.IO.Stream
                {
                    /*long*/ _position = 0n;
                    /*CheckSumAndSizeWriteStream*/ _crcSizeStream = null;
                    /*bool*/ _everWritten = false;
                    /*bool*/ _isDisposed = false;
                    /*ZipArchiveEntry*/ _entry = null;
                    /*bool*/ _usedZip64inLH = false;
                    /*bool*/ _canWrite = false;
                    $ctor$3(/*CheckSumAndSizeWriteStream*/ crcSizeStream, /*ZipArchiveEntry*/ entry)
                    {
                        super.$ctor$2();
                        {
                            this._position = 0n;
                            this._crcSizeStream = crcSizeStream;
                            this._everWritten = false;
                            this._isDisposed = false;
                            this._entry = entry;
                            this._usedZip64inLH = false;
                            this._canWrite = true;
                        }
                        return this;
                    }
                    /*long */ get Length()
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
                    }
                    /*long */ get Position()
                    {
                        this.ThrowIfDisposed();
                        return this._position;
                    }
                    /*long */ set Position(value)
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
                    }
                    /*bool */ get CanRead()
                    {
                        return false;
                    }
                    /*bool */ get CanSeek()
                    {
                        return false;
                    }
                    /*bool */ get CanWrite()
                    {
                        return this._canWrite;
                    }
                    /*void */ ThrowIfDisposed()
                    {
                        if (this._isDisposed)
                        {
                            throw new $.$spc.System.ObjectDisposedException().$ctor$15($.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this)), $.$sic.System.SR.HiddenStreamName);
                        }
                    }
                    /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
                    }
                    /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
                    }
                    /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
                    }
                    /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
                    }
                    /*void */ SetLength(/*long*/ value)
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SetLengthRequiresSeekingAndWriting);
                    }
                    /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
                    {
                        $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                        this.ThrowIfDisposed();
                        $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                        if (count === 0)
                        {
                            return;
                        }
                        if (!this._everWritten)
                        {
                            this._everWritten = true;
                            this._usedZip64inLH = this._entry.WriteLocalFileHeader(false, true);
                        }
                        this._crcSizeStream.Write(buffer, offset, count);
                        this._position += BigInt(count);
                    }
                    /*void */ Write$1(/*ReadOnlySpan<byte>*/ source)
                    {
                        this.ThrowIfDisposed();
                        $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                        if (source.Length === 0)
                        {
                            return;
                        }
                        if (!this._everWritten)
                        {
                            this._everWritten = true;
                            this._usedZip64inLH = this._entry.WriteLocalFileHeader(false, true);
                        }
                        this._crcSizeStream.Write$1(source);
                        this._position += BigInt(source.Length);
                    }
                    /*void */ WriteByte(/*byte*/ value)
                    {
                        return this.Write$1(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$5($.$ref(() => value, undefined, $.$spc.System.Byte)));
                    }
                    /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
                    {
                        $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                        return this.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count), cancellationToken).AsTask();
                    }
                    /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        this.ThrowIfDisposed();
                        $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                        return !buffer.IsEmpty ? Core.call(this, buffer, cancellationToken) : new $.$spc.System.Threading.Tasks.ValueTask();
                        /*ValueTask*/ /*async*/  function Core(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                        {
                            return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                            {
                                if (!this._everWritten)
                                {
                                    this._everWritten = true;
                                    this._usedZip64inLH = await this._entry.WriteLocalFileHeaderAsync(false, true, cancellationToken).ConfigureAwait$2(false);
                                }
                                await this._crcSizeStream.WriteAsync$2(buffer, cancellationToken).ConfigureAwait(false);
                                this._position += BigInt(buffer.Length);
                            });
                        }
                    }
                    /*void */ Flush()
                    {
                        this.ThrowIfDisposed();
                        $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                        this._crcSizeStream.Flush();
                    }
                    /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
                    {
                        this.ThrowIfDisposed();
                        $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                        return this._crcSizeStream.FlushAsync$1(cancellationToken);
                    }
                    /*void */ Dispose$1(/*bool*/ disposing)
                    {
                        if (disposing && !this._isDisposed)
                        {
                            this._crcSizeStream.Dispose();
                            if (!this._everWritten)
                            {
                                this._entry.WriteLocalFileHeader(true, true);
                            }
                            else 
                            {
                                if (this._entry._archive.ArchiveStream.CanSeek)
                                {
                                    this._entry.WriteCrcAndSizesInLocalHeader(this._usedZip64inLH);
                                }
                                else 
                                {
                                    this._entry.WriteDataDescriptor();
                                }
                            }
                            this._canWrite = false;
                            this._isDisposed = true;
                        }
                        super.Dispose$1(disposing);
                    }
                    /*ValueTask *//*async*/  DisposeAsync()
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                        {
                            if (!this._isDisposed)
                            {
                                await this._crcSizeStream.DisposeAsync().ConfigureAwait(false);
                                if (!this._everWritten)
                                {
                                    await this._entry.WriteLocalFileHeaderAsync(true, true, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait$2(false);
                                }
                                else 
                                {
                                    if (this._entry._archive.ArchiveStream.CanSeek)
                                    {
                                        await this._entry.WriteCrcAndSizesInLocalHeaderAsync(this._usedZip64inLH, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                                    }
                                    else 
                                    {
                                        await this._entry.WriteDataDescriptorAsync(new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                                    }
                                }
                                this._canWrite = false;
                                this._isDisposed = true;
                            }
                            await super.DisposeAsync().ConfigureAwait(false);
                        });
                    }
                    static $h = 2880914;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":917505,"g":{"r":0,"d":0,"h":42952553874,"f":32769},"n":"Length","d":2880914,"h":38657586578,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":51542488466,"f":32769},"s":{"r":0,"d":0,"h":55837455762,"f":32769},"n":"Position","d":2880914,"h":47247521170,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":64427390354,"f":32769},"n":"CanRead","d":2880914,"h":60132423058,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":73017324946,"f":32769},"n":"CanSeek","d":2880914,"h":68722357650,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":81607259538,"f":32769},"n":"CanWrite","d":2880914,"h":77312292242,"f":32769}],"m":[{"r":65537,"n":"ThrowIfDisposed","d":2880914,"h":85902226834,"f":2},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":2880914,"h":90197194130,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":2880914,"h":94492161426,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":2880914,"h":98787128722,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":2880914,"h":103082096018,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":2880914,"h":107377063314,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":2880914,"h":111672030610,"f":32769},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":2880914,"h":115966997906,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":2880914,"h":120261965202,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":2880914,"h":124556932498,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":2880914,"h":128851899794,"f":32769},{"r":65537,"n":"Flush","d":2880914,"h":133146867090,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":2880914,"h":137441834386,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":2880914,"h":141736801682,"f":32772},{"r":136118273,"n":"DisposeAsync","d":2880914,"h":146031768978,"f":36865}],"l":[{"t":917505,"n":"_position","d":2880914,"h":4297848210,"f":2},{"t":718226,"n":"_crcSizeStream","d":2880914,"h":8592815506,"f":2},{"t":262145,"n":"_everWritten","d":2880914,"h":12887782802,"f":2},{"t":262145,"n":"_isDisposed","d":2880914,"h":17182750098,"f":2},{"t":2684306,"n":"_entry","d":2880914,"h":21477717394,"f":2},{"t":262145,"n":"_usedZip64inLH","d":2880914,"h":25772684690,"f":2},{"t":262145,"n":"_canWrite","d":2880914,"h":30067651986,"f":2}],"c":[{"p":[{"n":"crcSizeStream","p":718226},{"n":"entry","p":2684306}],"n":".ctor","o":"$ctor$3","d":2880914,"h":34362619282,"f":1}],"i":[57540609,56950785],"d":2684306,"h":2880914}; }
                    static get $b() { return $.$spc.System.IO.Stream; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
                    static get $fullName() { return `System.IO.Compression.ZipArchiveEntry.DirectToArchiveWriterStream`; }
                }, $cls, ($v) => $cls.$_DirectToArchiveWriterStream = $v);
            }
            static $_BitFlagValues;
            static get BitFlagValues()
            {
                let $cls = $.$sic.System.IO.Compression.ZipArchiveEntry;
                return $cls.$_BitFlagValues ??= $asm.$nstr("$sic.System.IO.Compression.ZipArchiveEntry.BitFlagValues", ($self) => class BitFlagValues extends $.$spc.System.Enum
                {
                    static IsEncrypted = 1;
                    static DataDescriptor = 8;
                    static UnicodeFileNameAndComment = 2048;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "IsEncrypted": 1n,
                            "DataDescriptor": 8n,
                            "UnicodeFileNameAndComment": 2048n
                        };
                    }
                    static $h = 2749842;
                    static $z = 2;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.UInt16; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":589825,"l":[{"t":2749842,"n":"IsEncrypted","d":2749842,"h":4297717138,"f":33},{"t":2749842,"n":"DataDescriptor","d":2749842,"h":8592684434,"f":33},{"t":2749842,"n":"UnicodeFileNameAndComment","d":2749842,"h":12887651730,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2749842,"h":17182619026,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":2684306,"h":2749842,"a":[{"t":47710209,"c":4342677505}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZipArchiveEntry.BitFlagValues`; }
                }, $cls, ($v) => $cls.$_BitFlagValues = $v);
            }
            static $_CompressionMethodValues;
            static get CompressionMethodValues()
            {
                let $cls = $.$sic.System.IO.Compression.ZipArchiveEntry;
                return $cls.$_CompressionMethodValues ??= $asm.$nstr("$sic.System.IO.Compression.ZipArchiveEntry.CompressionMethodValues", ($self) => class CompressionMethodValues extends $.$spc.System.Enum
                {
                    static Stored = 0;
                    static Deflate = 8;
                    static Deflate64 = 9;
                    static BZip2 = 12;
                    static LZMA = 14;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Stored": 0n,
                            "Deflate": 8n,
                            "Deflate64": 9n,
                            "BZip2": 12n,
                            "LZMA": 14n
                        };
                    }
                    static $h = 2815378;
                    static $z = 2;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.UInt16; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":589825,"l":[{"t":2815378,"n":"Stored","d":2815378,"h":4297782674,"f":33},{"t":2815378,"n":"Deflate","d":2815378,"h":8592749970,"f":33},{"t":2815378,"n":"Deflate64","d":2815378,"h":12887717266,"f":33},{"t":2815378,"n":"BZip2","d":2815378,"h":17182684562,"f":33},{"t":2815378,"n":"LZMA","d":2815378,"h":21477651858,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2815378,"h":25772619154,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":2684306,"h":2815378}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZipArchiveEntry.CompressionMethodValues`; }
                }, $cls, ($v) => $cls.$_CompressionMethodValues = $v);
            }
            static $_LocalHeaderOffsetComparer;
            static get LocalHeaderOffsetComparer()
            {
                let $cls = $.$sic.System.IO.Compression.ZipArchiveEntry;
                return $cls.$_LocalHeaderOffsetComparer ??= $asm.$ncls("$sic.System.IO.Compression.ZipArchiveEntry.LocalHeaderOffsetComparer", ($self) => class LocalHeaderOffsetComparer extends $.$spc.System.Collections.Generic.Comparer$$($.$sic.System.IO.Compression.ZipArchiveEntry)
                {
                    /*LocalHeaderOffsetComparer*/ static s_instance = null;
                    static /*LocalHeaderOffsetComparer */ get Instance()
                    {
                        return $.$sic.System.IO.Compression.ZipArchiveEntry.LocalHeaderOffsetComparer.s_instance;
                    }
                    /*int */ Compare(/*ZipArchiveEntry?*/ x, /*ZipArchiveEntry?*/ y)
                    {
                        /*long*/ let xOffset = x !== null && !x.OriginallyInArchive ? 9223372036854775807n : (x?.OffsetOfLocalHeader ?? null) ?? -9223372036854775808n;
                        /*long*/ let yOffset = y !== null && !y.OriginallyInArchive ? 9223372036854775807n : (y?.OffsetOfLocalHeader ?? null) ?? -9223372036854775808n;
                        return $.$spc.System.Int64.CompareTo$1.call(xOffset, yOffset);
                    }
                    //default reference type constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        return this;
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.s_instance = new $.$sic.System.IO.Compression.ZipArchiveEntry.LocalHeaderOffsetComparer().$ctor$2();
                        }
                    }
                    static $h = 2946450;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":2946450,"g":{"r":0,"d":0,"h":12887848338,"f":33},"n":"Instance","d":2946450,"h":8592881042,"f":33}],"m":[{"r":655361,"p":[{"n":"x","p":2684306},{"n":"y","p":2684306}],"n":"Compare","d":2946450,"h":17182815634,"f":32769}],"l":[{"t":2946450,"n":"s_instance","d":2946450,"h":4297913746,"f":34}],"c":[{"n":".ctor","o":"$ctor$2","d":2946450,"h":21477782930,"f":1}],"i":[31457281,$.$spc.System.Collections.Generic.IComparer$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h],"d":2684306,"h":2946450}; }
                    static get $b() { return $.$spc.System.Collections.Generic.Comparer$$($.$sic.System.IO.Compression.ZipArchiveEntry); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IComparer, $.$spc.System.Collections.Generic.IComparer$$($.$sic.System.IO.Compression.ZipArchiveEntry) ]; }
                    static get $fullName() { return `System.IO.Compression.ZipArchiveEntry.LocalHeaderOffsetComparer`; }
                }, $cls, ($v) => $cls.$_LocalHeaderOffsetComparer = $v);
            }
            //default member initializer
            constructor()
            {
                super();
                this._lastModified = $.$default($.$spc.System.DateTimeOffset);
                this.Changes = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_allowLargeZipArchiveEntriesInUpdateMode = $.$spc.System.IntPtr.Size > 4;
                }
            }
            static $h = 2684306;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2553234,"g":{"r":0,"d":0,"h":231930918290,"f":1},"n":"Archive","d":2684306,"h":227635950994,"f":1},{"p":720897,"g":{"r":0,"d":0,"h":240520852882,"f":1},"n":"Crc32","d":2684306,"h":236225885586,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"p":262145,"g":{"r":0,"d":0,"h":249110787474,"f":1},"n":"IsEncrypted","d":2684306,"h":244815820178,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":257700722066,"f":1},"n":"CompressedLength","d":2684306,"h":253405754770,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":266290656658,"f":1},"s":{"r":0,"d":0,"h":270585623954,"f":1},"n":"ExternalAttributes","d":2684306,"h":261995689362,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":279175558546,"f":1},"s":{"r":0,"d":0,"h":283470525842,"f":1},"n":"Comment","d":2684306,"h":274880591250,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":292060460434,"f":1},"s":{"r":0,"d":0,"h":296355427730,"f":2},"n":"FullName","d":2684306,"h":287765493138,"f":1},{"p":34406401,"g":{"r":0,"d":0,"h":304945362322,"f":1},"s":{"r":0,"d":0,"h":309240329618,"f":1},"n":"LastWriteTime","d":2684306,"h":300650395026,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":317830264210,"f":1},"n":"Length","d":2684306,"h":313535296914,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":326420198802,"f":1},"n":"Name","d":2684306,"h":322125231506,"f":1},{"p":2618770,"g":{"r":0,"d":0,"h":339305100690,"f":8},"s":{"r":0,"d":0,"h":343600067986,"f":2},"n":"Changes","d":2684306,"h":335010133394,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":352190002578,"f":8},"n":"OriginallyInArchive","d":2684306,"h":347895035282,"f":8},{"p":917505,"g":{"r":0,"d":0,"h":360779937170,"f":8},"n":"OffsetOfLocalHeader","d":2684306,"h":356484969874,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":390844708242,"f":8},"n":"EverOpenedForWrite","d":2684306,"h":386549740946,"f":8},{"p":2815378,"g":{"r":0,"d":0,"h":408024577426,"f":2},"s":{"r":0,"d":0,"h":412319544722,"f":2},"n":"CompressionMethod","d":2684306,"h":403729610130,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":498218890642,"f":2},"n":"AreSizesTooLarge","d":2684306,"h":493923923346,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":515398759826,"f":2},"n":"IsOffsetTooLarge","d":2684306,"h":511103792530,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":523988694418,"f":2},"n":"ShouldUseZIP64","d":2684306,"h":519693727122,"f":2}],"m":[{"r":1310721,"p":[{"n":"path","p":1310721},{"n":"madeByPlatform","p":4388242}],"n":"ParseFileName","d":2684306,"h":8592618898,"f":40},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.Stream).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"OpenAsync","d":2684306,"h":12887586194,"f":4097},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int64).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"GetOffsetOfCompressedDataAsync","d":2684306,"h":17182553490,"f":4104},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.MemoryStream).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"GetUncompressedDataAsync","d":2684306,"h":21477520786,"f":4098},{"r":133300225,"p":[{"n":"forceWrite","p":262145},{"n":"cancellationToken","p":125960193}],"n":"WriteAndFinishLocalEntryAsync","d":2684306,"h":25772488082,"f":4104},{"r":133300225,"p":[{"n":"forceWrite","p":262145},{"n":"cancellationToken","p":125960193}],"n":"WriteCentralDirectoryFileHeaderAsync","d":2684306,"h":30067455378,"f":4104},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"LoadLocalHeaderExtraFieldIfNeededAsync","d":2684306,"h":34362422674,"f":4104},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"LoadCompressedBytesIfNeededAsync","d":2684306,"h":38657389970,"f":4104},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean).$h,"p":[{"n":"needToUncompress","p":262145},{"n":"needToLoadIntoMemory","p":262145},{"n":"cancellationToken","p":125960193}],"n":"GetIsOpenableAsync","d":2684306,"h":42952357266,"f":4098},{"r":133300225,"p":[{"n":"needToUncompress","p":262145},{"n":"needToLoadIntoMemory","p":262145},{"n":"cancellationToken","p":125960193}],"n":"ThrowIfNotOpenableAsync","d":2684306,"h":47247324562,"f":4104},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.Stream).$h,"p":[{"n":"checkOpenable","p":262145},{"n":"cancellationToken","p":125960193}],"n":"OpenInReadModeAsync","d":2684306,"h":51542291858,"f":4098},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.WrappedStream).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"OpenInUpdateModeAsync","d":2684306,"h":55837259154,"f":4098},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String)).$h,"p":[{"n":"needToUncompress","p":262145},{"n":"needToLoadIntoMemory","p":262145},{"n":"cancellationToken","p":125960193}],"n":"IsOpenableAsync","d":2684306,"h":60132226450,"f":4098},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean).$h,"p":[{"n":"isEmptyFile","p":262145},{"n":"forceWrite","p":262145},{"n":"cancellationToken","p":125960193}],"n":"WriteLocalFileHeaderAsync","d":2684306,"h":64427193746,"f":4098},{"r":133300225,"p":[{"n":"forceWrite","p":262145},{"n":"cancellationToken","p":125960193}],"n":"WriteLocalFileHeaderAndDataIfNeededAsync","d":2684306,"h":68722161042,"f":4098},{"r":133300225,"p":[{"n":"zip64HeaderUsed","p":262145},{"n":"cancellationToken","p":125960193}],"n":"WriteCrcAndSizesInLocalHeaderAsync","d":2684306,"h":73017128338,"f":4098},{"r":136118273,"p":[{"n":"cancellationToken","p":125960193}],"n":"WriteDataDescriptorAsync","d":2684306,"h":77312095634,"f":2},{"r":133300225,"n":"UnloadStreamsAsync","d":2684306,"h":81607062930,"f":4098},{"r":133300225,"n":"CloseStreamsAsync","d":2684306,"h":85902030226,"f":4098},{"r":65537,"n":"Delete","d":2684306,"h":365074904466,"f":1},{"r":62193665,"n":"Open","d":2684306,"h":369369871762,"f":1},{"r":1310721,"n":"ToString","d":2684306,"h":373664839058,"f":32769},{"r":1310721,"p":[{"n":"entryStringBytes","p":0}],"n":"DecodeEntryString","d":2684306,"h":377959806354,"f":2},{"r":917505,"n":"GetOffsetOfCompressedData","d":2684306,"h":395139675538,"f":8},{"r":61014017,"n":"GetUncompressedData","d":2684306,"h":399434642834,"f":2},{"r":65537,"p":[{"n":"forceWrite","p":262145}],"n":"WriteAndFinishLocalEntry","d":2684306,"h":416614512018,"f":8},{"r":262145,"p":[{"n":"forceWrite","p":262145},{"n":"zip64ExtraField","p":2356626,"f":2},{"n":"compressedSizeTruncated","p":720897,"f":2},{"n":"uncompressedSizeTruncated","p":720897,"f":2},{"n":"extraFieldLength","p":589825,"f":2},{"n":"offsetOfLocalHeaderTruncated","p":720897,"f":2}],"n":"WriteCentralDirectoryFileHeaderInitialize","d":2684306,"h":420909479314,"f":2},{"r":65537,"p":[{"n":"cdStaticHeader","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"compressedSizeTruncated","p":720897},{"n":"uncompressedSizeTruncated","p":720897},{"n":"extraFieldLength","p":589825},{"n":"offsetOfLocalHeaderTruncated","p":720897}],"n":"WriteCentralDirectoryFileHeaderPrepare","d":2684306,"h":425204446610,"f":2},{"r":65537,"p":[{"n":"forceWrite","p":262145}],"n":"WriteCentralDirectoryFileHeader","d":2684306,"h":429499413906,"f":8},{"r":65537,"n":"LoadLocalHeaderExtraFieldIfNeeded","d":2684306,"h":433794381202,"f":8},{"r":0,"p":[{"n":"maxSingleBufferSize","p":655361,"f":2}],"n":"LoadCompressedBytesIfNeededInitialize","d":2684306,"h":438089348498,"f":2},{"r":65537,"n":"LoadCompressedBytesIfNeeded","d":2684306,"h":442384315794,"f":8},{"r":65537,"p":[{"n":"needToUncompress","p":262145},{"n":"needToLoadIntoMemory","p":262145}],"n":"ThrowIfNotOpenable","d":2684306,"h":446679283090,"f":8},{"r":65537,"n":"DetectEntryNameVersion","d":2684306,"h":450974250386,"f":2},{"r":718226,"p":[{"n":"backingStream","p":62193665},{"n":"leaveBackingStreamOpen","p":262145},{"n":"onClose","p":47054849}],"n":"GetDataCompressor","d":2684306,"h":455269217682,"f":2},{"r":62193665,"p":[{"n":"compressedStreamToRead","p":62193665}],"n":"GetDataDecompressor","d":2684306,"h":459564184978,"f":2},{"r":62193665,"p":[{"n":"checkOpenable","p":262145}],"n":"OpenInReadMode","d":2684306,"h":463859152274,"f":2},{"r":62193665,"p":[{"n":"offsetOfCompressedData","p":917505}],"n":"OpenInReadModeGetDataCompressor","d":2684306,"h":468154119570,"f":2},{"r":1897874,"n":"OpenInWriteMode","d":2684306,"h":472449086866,"f":2},{"r":1897874,"n":"OpenInUpdateMode","d":2684306,"h":476744054162,"f":2},{"r":262145,"p":[{"n":"needToUncompress","p":262145},{"n":"needToLoadIntoMemory","p":262145},{"n":"message","p":1310721,"f":2}],"n":"IsOpenable","d":2684306,"h":481039021458,"f":2},{"r":262145,"p":[{"n":"needToUncompress","p":262145},{"n":"message","p":1310721,"f":2}],"n":"IsOpenableInitialVerifications","d":2684306,"h":485333988754,"f":2},{"r":262145,"p":[{"n":"needToLoadIntoMemory","p":262145},{"n":"offsetOfCompressedData","p":917505},{"n":"message","p":1310721,"f":2}],"n":"IsOpenableFinalVerifications","d":2684306,"h":489628956050,"f":2},{"r":783762,"p":[{"n":"generalPurposeBitFlag","p":2749842},{"n":"compressionMethod","p":2815378}],"n":"MapCompressionLevel","d":2684306,"h":502513857938,"f":34},{"r":2749842,"p":[{"n":"generalPurposeBitFlag","p":2749842},{"n":"compressionLevel","p":783762},{"n":"compressionMethod","p":2815378}],"n":"MapDeflateCompressionOption","d":2684306,"h":506808825234,"f":34},{"r":262145,"p":[{"n":"isEmptyFile","p":262145},{"n":"forceWrite","p":262145},{"n":"zip64ExtraField","p":2356626,"f":2},{"n":"compressedSizeTruncated","p":720897,"f":2},{"n":"uncompressedSizeTruncated","p":720897,"f":2},{"n":"extraFieldLength","p":589825,"f":2}],"n":"WriteLocalFileHeaderInitialize","d":2684306,"h":528283661714,"f":2},{"r":65537,"p":[{"n":"lfStaticHeader","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"compressedSizeTruncated","p":720897},{"n":"uncompressedSizeTruncated","p":720897},{"n":"extraFieldLength","p":589825}],"n":"WriteLocalFileHeaderPrepare","d":2684306,"h":532578629010,"f":2},{"r":262145,"p":[{"n":"isEmptyFile","p":262145},{"n":"forceWrite","p":262145}],"n":"WriteLocalFileHeader","d":2684306,"h":536873596306,"f":2},{"r":65537,"p":[{"n":"forceWrite","p":262145}],"n":"WriteLocalFileHeaderAndDataIfNeeded","d":2684306,"h":541168563602,"f":2},{"r":65537,"p":[{"n":"zip64HeaderUsed","p":262145}],"n":"WriteCrcAndSizesInLocalHeader","d":2684306,"h":562643400082,"f":2},{"r":65537,"p":[{"n":"zip64HeaderUsed","p":262145},{"n":"finalPosition","p":917505,"f":2},{"n":"pretendStreaming","p":262145,"f":2},{"n":"compressedSizeTruncated","p":720897,"f":2},{"n":"uncompressedSizeTruncated","p":720897,"f":2}],"n":"WriteCrcAndSizesInLocalHeaderInitialize","d":2684306,"h":566938367378,"f":2},{"r":65537,"p":[{"n":"writeBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"WriteCrcAndSizesInLocalHeaderPrepareForZip64PretendStreaming","d":2684306,"h":571233334674,"f":2},{"r":65537,"p":[{"n":"pretendStreaming","p":262145},{"n":"writeBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"compressedSizeTruncated","p":720897},{"n":"uncompressedSizeTruncated","p":720897}],"n":"WriteCrcAndSizesInLocalHeaderPrepareFor32bitValuesWriting","d":2684306,"h":575528301970,"f":2},{"r":65537,"p":[{"n":"writeBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"WriteCrcAndSizesInLocalHeaderPrepareForWritingWhenZip64HeaderUsed","d":2684306,"h":579823269266,"f":2},{"r":65537,"p":[{"n":"writeBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"WriteCrcAndSizesInLocalHeaderPrepareForWritingDataDescriptor","d":2684306,"h":584118236562,"f":2},{"r":65537,"n":"WriteDataDescriptor","d":2684306,"h":592708171154,"f":2},{"r":655361,"p":[{"n":"dataDescriptor","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"PrepareToWriteDataDescriptor","d":2684306,"h":597003138450,"f":2},{"r":65537,"n":"UnloadStreams","d":2684306,"h":601298105746,"f":2},{"r":65537,"n":"CloseStreams","d":2684306,"h":605593073042,"f":2},{"r":65537,"p":[{"n":"value","p":4453778}],"n":"VersionToExtractAtLeast","d":2684306,"h":609888040338,"f":2},{"r":65537,"n":"ThrowIfInvalidArchive","d":2684306,"h":614183007634,"f":2},{"r":1310721,"p":[{"n":"path","p":1310721}],"n":"GetFileName_Windows","d":2684306,"h":618477974930,"f":34},{"r":1310721,"p":[{"n":"path","p":1310721}],"n":"GetFileName_Unix","d":2684306,"h":622772942226,"f":34}],"l":[{"t":4388242,"n":"CurrentZipPlatform","d":2684306,"h":4297651602,"f":40},{"t":2553234,"n":"_archive","d":2684306,"h":90196997522,"f":2},{"t":262145,"n":"_originallyInArchive","d":2684306,"h":94491964818,"f":2},{"t":720897,"n":"_diskNumberStart","d":2684306,"h":98786932114,"f":2},{"t":4388242,"n":"_versionMadeByPlatform","d":2684306,"h":103081899410,"f":2},{"t":4453778,"n":"_versionMadeBySpecification","d":2684306,"h":107376866706,"f":2},{"t":4453778,"n":"_versionToExtract","d":2684306,"h":111671834002,"f":2},{"t":2749842,"n":"_generalPurposeBitFlag","d":2684306,"h":115966801298,"f":2},{"t":262145,"n":"_isEncrypted","d":2684306,"h":120261768594,"f":2},{"t":2815378,"n":"_storedCompressionMethod","d":2684306,"h":124556735890,"f":2},{"t":34406401,"n":"_lastModified","d":2684306,"h":128851703186,"f":2},{"t":917505,"n":"_compressedSize","d":2684306,"h":133146670482,"f":2},{"t":917505,"n":"_uncompressedSize","d":2684306,"h":137441637778,"f":2},{"t":917505,"n":"_offsetOfLocalHeader","d":2684306,"h":141736605074,"f":2},{"t":$.$typeNullable($.$spc.System.Int64).$h,"n":"_storedOffsetOfCompressedData","d":2684306,"h":146031572370,"f":2},{"t":720897,"n":"_crc32","d":2684306,"h":150326539666,"f":2},{"t":0,"n":"_compressedBytes","d":2684306,"h":154621506962,"f":2},{"t":61014017,"n":"_storedUncompressedData","d":2684306,"h":158916474258,"f":2},{"t":262145,"n":"_currentlyOpenForWrite","d":2684306,"h":163211441554,"f":2},{"t":262145,"n":"_everOpenedForWrite","d":2684306,"h":167506408850,"f":2},{"t":62193665,"n":"_outstandingWriteStream","d":2684306,"h":171801376146,"f":2},{"t":720897,"n":"_externalFileAttr","d":2684306,"h":176096343442,"f":2},{"t":1310721,"n":"_storedEntryName","d":2684306,"h":180391310738,"f":2},{"t":0,"n":"_storedEntryNameBytes","d":2684306,"h":184686278034,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h,"n":"_cdUnknownExtraFields","d":2684306,"h":188981245330,"f":2},{"t":0,"n":"_cdTrailingExtraFieldData","d":2684306,"h":193276212626,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h,"n":"_lhUnknownExtraFields","d":2684306,"h":197571179922,"f":2},{"t":0,"n":"_lhTrailingExtraFieldData","d":2684306,"h":201866147218,"f":2},{"t":0,"n":"_fileComment","d":2684306,"h":206161114514,"f":2},{"t":783762,"n":"_compressionLevel","d":2684306,"h":210456081810,"f":2},{"t":262145,"n":"s_allowLargeZipArchiveEntriesInUpdateMode","d":2684306,"h":382254773650,"f":34},{"t":655361,"n":"MetadataBufferLength","d":2684306,"h":545463530898,"f":34},{"t":655361,"n":"CrcAndSizesBufferLength","d":2684306,"h":549758498194,"f":34},{"t":655361,"n":"Zip64SizesBufferLength","d":2684306,"h":554053465490,"f":34},{"t":655361,"n":"Zip64DataDescriptorCrcAndSizesBufferLength","d":2684306,"h":558348432786,"f":34},{"t":655361,"n":"MaxSizeOfDataDescriptor","d":2684306,"h":588413203858,"f":34}],"c":[{"p":[{"n":"archive","p":2553234},{"n":"cd","p":3143058}],"n":".ctor","o":"$ctor$1","d":2684306,"h":214751049106,"f":8},{"p":[{"n":"archive","p":2553234},{"n":"entryName","p":1310721},{"n":"compressionLevel","p":783762}],"n":".ctor","o":"$ctor$2","d":2684306,"h":219046016402,"f":8},{"p":[{"n":"archive","p":2553234},{"n":"entryName","p":1310721}],"n":".ctor","o":"$ctor$3","d":2684306,"h":223340983698,"f":8}],"j":[2880914,2749842,2815378,2946450],"h":2684306}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.ZipArchiveEntry`; }
        });
        
        $asm.$cls("$sic.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 5371282;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":5371282,"h":4300338578,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":5371282,"h":8595305874,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":5371282,"h":12890273170,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":5371282,"h":17185240466,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":5371282,"h":21480207762,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":5371282,"h":25775175058,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":5371282,"h":30070142354,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":5371282,"h":34365109650,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":5371282,"h":38660076946,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":5371282,"h":42955044242,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":5371282,"h":47250011538,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":5371282,"h":51544978834,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":5371282,"h":55839946130,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":5371282,"h":60134913426,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":5371282,"h":64429880722,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":5371282,"h":68724848018,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":5371282,"h":73019815314,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":5371282,"h":77314782610,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":5371282,"h":81609749906,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":5371282,"h":85904717202,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":5371282,"h":90199684498,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":5371282,"h":94494651794,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":5371282,"h":98789619090,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":5371282,"h":103084586386,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":5371282,"h":107379553682,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":5371282,"h":111674520978,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":5371282,"h":115969488274,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":5371282,"h":120264455570,"f":40},{"t":1310721,"n":"WebRequestMessage","d":5371282,"h":124559422866,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":5371282,"h":128854390162,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":5371282,"h":133149357458,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":5371282,"h":137444324754,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":5371282,"h":141739292050,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":5371282,"h":146034259346,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":5371282,"h":150329226642,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":5371282,"h":154624193938,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":5371282,"h":158919161234,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":5371282,"h":163214128530,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":5371282,"h":167509095826,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":5371282,"h":171804063122,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":5371282,"h":176099030418,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":5371282,"h":180393997714,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":5371282,"h":184688965010,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":5371282,"h":188983932306,"f":40},{"t":1310721,"n":"RijndaelMessage","d":5371282,"h":193278899602,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":5371282,"h":197573866898,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":5371282,"h":201868834194,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":5371282,"h":206163801490,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":5371282,"h":210458768786,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":5371282,"h":214753736082,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":5371282,"h":219048703378,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":5371282,"h":223343670674,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":5371282,"h":227638637970,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":5371282,"h":231933605266,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":5371282,"h":236228572562,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":5371282,"h":240523539858,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":5371282,"h":244818507154,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":5371282,"h":249113474450,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":5371282,"h":253408441746,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":5371282,"h":257703409042,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":5371282,"h":261998376338,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":5371282,"h":266293343634,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":5371282,"h":270588310930,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":5371282,"h":274883278226,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":5371282,"h":279178245522,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":5371282,"h":283473212818,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":5371282,"h":287768180114,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":5371282,"h":292063147410,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":5371282,"h":296358114706,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":5371282,"h":300653082002,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":5371282,"h":304948049298,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":5371282,"h":309243016594,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":5371282,"h":313537983890,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":5371282,"h":317832951186,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":5371282,"h":322127918482,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":5371282,"h":326422885778,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":5371282,"h":330717853074,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":5371282,"h":335012820370,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":5371282,"h":339307787666,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":5371282,"h":343602754962,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":5371282,"h":347897722258,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":5371282,"h":352192689554,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":5371282,"h":356487656850,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":5371282,"h":360782624146,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":5371282,"h":365077591442,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":5371282,"h":369372558738,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":5371282,"h":373667526034,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":5371282,"h":377962493330,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":5371282,"h":382257460626,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":5371282,"h":386552427922,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":5371282,"h":390847395218,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":5371282,"h":395142362514,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":5371282,"h":399437329810,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":5371282,"h":403732297106,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":5371282,"h":408027264402,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":5371282,"h":412322231698,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":5371282,"h":416617198994,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":5371282,"h":420912166290,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":5371282,"h":425207133586,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":5371282,"h":429502100882,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":5371282,"h":433797068178,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":5371282,"h":438092035474,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":5371282,"h":442387002770,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":5371282,"h":446681970066,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":5371282,"h":450976937362,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":5371282,"h":455271904658,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":5371282,"h":459566871954,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":5371282,"h":463861839250,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":5371282,"h":468156806546,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":5371282,"h":472451773842,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":5371282,"h":476746741138,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":5371282,"h":481041708434,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":5371282,"h":485336675730,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":5371282,"h":489631643026,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":5371282,"h":493926610322,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":5371282,"h":498221577618,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":5371282,"h":502516544914,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":5371282,"h":506811512210,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":5371282,"h":511106479506,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":5371282,"h":515401446802,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":5371282,"h":519696414098,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":5371282,"h":523991381394,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":5371282,"h":528286348690,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":5371282,"h":532581315986,"f":40}],"h":5371282}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.Inflater", ($self) => class Inflater extends $.$spc.System.Object
        {
            /*int*/ static MinWindowBits = -15;
            /*int*/ static MaxWindowBits = 47;
            /*bool*/ _nonEmptyInput = false;
            /*bool*/ _finished = false;
            /*bool*/ _isDisposed = false;
            /*int*/ _windowBits = 0;
            /*ZLibNative.ZLibStreamHandle*/ _zlibStream = null;
            /*MemoryHandle*/ _inputBufferHandle;
            /*long*/ _uncompressedSize = 0n;
            /*long*/ _currentInflatedCount = 0n;
            /*object */ get SyncLock()
            {
                return this;
            }
            $ctor$1(/*int*/ windowBits, /*long*/ uncompressedSize)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(windowBits >= -15/*MinWindowBits*/ && windowBits <= 47/*MaxWindowBits*/, "windowBits >= MinWindowBits && windowBits <= MaxWindowBits");
                    this._finished = false;
                    this._nonEmptyInput = false;
                    this._isDisposed = false;
                    this._windowBits = windowBits;
                    this.InflateInit(windowBits);
                    this._uncompressedSize = uncompressedSize;
                }
                return this;
            }
            /*int */ get AvailableOutput()
            {
                return (this._zlibStream.AvailOut | 0);
            }
            /*bool */ Finished()
            {
                return this._finished;
            }
            /*bool */ Inflate(/*out byte*/ b)
            {
                /*fixed*/ 
                {
                    /*byte**/ let bufPtr = b;
                    /*int*/ let bytesRead = this.InflateVerified(bufPtr, 1);
                    $.$spc.System.Diagnostics.Debug.Assert$1(bytesRead === 0 || bytesRead === 1, "bytesRead == 0 || bytesRead == 1");
                    return bytesRead !== 0;
                }
            }
            /*int */ Inflate$1(/*byte[]*/ bytes, /*int*/ offset, /*int*/ length)
            {
                if (length === 0)
                {
                    return 0;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(null !== bytes, "Can't pass in a null output buffer!");
                /*fixed*/ 
                {
                    /*byte**/ let bufPtr = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$spc.System.Byte, bytes, null, false, true);
                    return this.InflateVerified(bufPtr.Add(offset), length);
                }
            }
            /*int */ Inflate$2(/*Span<byte>*/ destination)
            {
                if (destination.Length === 0)
                {
                    return 0;
                }
                /*fixed*/ 
                {
                    /*byte**/ let bufPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, destination);
                    return this.InflateVerified(bufPtr, destination.Length);
                }
            }
            /*int */ InflateVerified(/*byte**/ bufPtr, /*int*/ length)
            {
                try
                {
                    /*int*/ let bytesRead = 0;
                    if (this._uncompressedSize === BigInt(-1))
                    {
                        this.ReadOutput(bufPtr, length, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32));
                    }
                    else 
                    {
                        if (this._uncompressedSize > this._currentInflatedCount)
                        {
                            length = $.$cast($.$spc.System.Math.Min$5(BigInt(length), this._uncompressedSize - this._currentInflatedCount), $.$spc.System.Int32);
                            this.ReadOutput(bufPtr, length, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32));
                            this._currentInflatedCount += BigInt(bytesRead);
                        }
                        else 
                        {
                            this._finished = true;
                            this._zlibStream.AvailIn = 0;
                        }
                    }
                    return bytesRead;
                }
                finally
                {
                    {
                        if (0 === this._zlibStream.AvailIn && this.IsInputBufferHandleAllocated)
                        {
                            this.DeallocateInputBufferHandle();
                        }
                    }
                }
            }
            /*void */ ReadOutput(/*byte**/ bufPtr, /*int*/ length, /*out int*/ bytesRead)
            {
                if (this.ReadInflateOutput(bufPtr, length, 0/*ZLibNative.FlushCode.NoFlush*/, bytesRead) === 1/*ZLibNative.ErrorCode.StreamEnd*/)
                {
                    if (!this.NeedsInput() && this.IsGzipStream() && this.IsInputBufferHandleAllocated)
                    {
                        this._finished = this.ResetStreamForLeftoverInput();
                    }
                    else 
                    {
                        this._finished = true;
                    }
                }
            }
            /*bool */ ResetStreamForLeftoverInput()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.NeedsInput(), "!NeedsInput()");
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsGzipStream(), "IsGzipStream()");
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsInputBufferHandleAllocated, "IsInputBufferHandleAllocated");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        /*byte**/ let nextInPointer = $.$cast(this._zlibStream.NextIn, $.$typePointer($.$spc.System.Byte));
                        /*uint*/ let nextAvailIn = this._zlibStream.AvailIn;
                        if (nextInPointer.$v !== 31/*ZLibNative.GZip_Header_ID1*/ || (nextAvailIn > 1 && (nextInPointer.Add(1)).$v !== 139/*ZLibNative.GZip_Header_ID2*/))
                        {
                            return true;
                        }
                        this._zlibStream.InflateReset2_(this._windowBits);
                        this._finished = false;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
                return false;
            }
            /*bool */ IsGzipStream()
            {
                return this._windowBits >= 24 && this._windowBits <= 31;
            }
            /*bool */ NeedsInput()
            {
                return this._zlibStream.AvailIn === 0;
            }
            /*bool */ NonEmptyInput()
            {
                return this._nonEmptyInput;
            }
            /*void */ SetInput(/*byte[]*/ inputBuffer, /*int*/ startIndex, /*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.NeedsInput(), "We have something left in previous input!");
                $.$spc.System.Diagnostics.Debug.Assert$1(inputBuffer !== null, "inputBuffer != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(startIndex >= 0 && count >= 0 && ((count + startIndex) | 0) <= inputBuffer.length, "startIndex >= 0 && count >= 0 && count + startIndex <= inputBuffer.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.IsInputBufferHandleAllocated, "!IsInputBufferHandleAllocated");
                this.SetInput$1($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, inputBuffer, startIndex, count)));
            }
            /*void */ SetInput$1(/*ReadOnlyMemory<byte>*/ inputBuffer)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.NeedsInput(), "We have something left in previous input!");
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.IsInputBufferHandleAllocated, "!IsInputBufferHandleAllocated");
                if (inputBuffer.IsEmpty)
                {
                    return;
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        this._inputBufferHandle = inputBuffer.Pin();
                        this._zlibStream.NextIn = $.$spc.System.IntPtr.op_Explicit$2(this._inputBufferHandle.Pointer);
                        this._zlibStream.AvailIn = (inputBuffer.Length >>> 0);
                        this._finished = false;
                        this._nonEmptyInput = true;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                if (!this._isDisposed)
                {
                    if (disposing)
                    {
                        this._zlibStream.Dispose();
                    }
                    if (this.IsInputBufferHandleAllocated)
                    {
                        this.DeallocateInputBufferHandle();
                    }
                    this._isDisposed = true;
                }
            }
            /*void */ Dispose$1()
            {
                this.Dispose(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            $dtor()
            {
                this.Dispose(false);
            }
            /*void */ InflateInit(/*int*/ windowBits)
            {
                /*ZLibNative.ErrorCode*/ let error;
                try
                {
                    error = $.$sic.System.IO.Compression.ZLibNative.CreateZLibStreamForInflate($.$ref(() => this._zlibStream, ($v) => this._zlibStream = $v, $.$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle), windowBits);
                }
                catch(exception)
                {
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$16($.$sic.System.SR.ZLibErrorDLLLoadError, exception);
                }
                switch(error)
                {
                    case 0/*ZLibNative.ErrorCode.Ok*/:
                    return;
                    case -4/*ZLibNative.ErrorCode.MemError*/:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorNotEnoughMemory, "inflateInit2_", error, this._zlibStream.GetErrorMessage());
                    case -6/*ZLibNative.ErrorCode.VersionError*/:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorVersionMismatch, "inflateInit2_", error, this._zlibStream.GetErrorMessage());
                    case -2/*ZLibNative.ErrorCode.StreamError*/:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorIncorrectInitParameters, "inflateInit2_", error, this._zlibStream.GetErrorMessage());
                    default:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorUnexpected, "inflateInit2_", error, this._zlibStream.GetErrorMessage());
                }
            }
            /*ZLibNative.ErrorCode */ ReadInflateOutput(/*byte**/ bufPtr, /*int*/ length, /*ZLibNative.FlushCode*/ flushCode, /*out int*/ bytesRead)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        this._zlibStream.NextOut = $.$cast(bufPtr, $.$spc.System.IntPtr);
                        this._zlibStream.AvailOut = (length >>> 0);
                        /*ZLibNative.ErrorCode*/ let errC = this.Inflate$3(flushCode);
                        bytesRead.$v = ((length - (this._zlibStream.AvailOut | 0)) | 0);
                        return errC;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*ZLibNative.ErrorCode */ Inflate$3(/*ZLibNative.FlushCode*/ flushCode)
            {
                /*ZLibNative.ErrorCode*/ let errC;
                try
                {
                    errC = this._zlibStream.Inflate(flushCode);
                }
                catch(cause)
                {
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$16($.$sic.System.SR.ZLibErrorDLLLoadError, cause);
                }
                switch(errC)
                {
                    case 0/*ZLibNative.ErrorCode.Ok*/:
                    case 1/*ZLibNative.ErrorCode.StreamEnd*/:
                    return errC;
                    case -5/*ZLibNative.ErrorCode.BufError*/:
                    return errC;
                    case -4/*ZLibNative.ErrorCode.MemError*/:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorNotEnoughMemory, "inflate_", errC, this._zlibStream.GetErrorMessage());
                    case -3/*ZLibNative.ErrorCode.DataError*/:
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.UnsupportedCompression);
                    case -2/*ZLibNative.ErrorCode.StreamError*/:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorInconsistentStream, "inflate_", errC, this._zlibStream.GetErrorMessage());
                    default:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorUnexpected, "inflate_", errC, this._zlibStream.GetErrorMessage());
                }
            }
            /*void */ DeallocateInputBufferHandle()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsInputBufferHandleAllocated, "IsInputBufferHandleAllocated");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        this._zlibStream.AvailIn = 0;
                        this._zlibStream.NextIn = $.$sic.System.IO.Compression.ZLibNative.ZNullPtr;
                        this._inputBufferHandle.Dispose();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*bool */ get IsInputBufferHandleAllocated()
            {
                return $.$spc.NetJs.RefOrPointer.Compare(this._inputBufferHandle.Pointer, new $.$typePointer($.$spc.System.Void)()) != 0;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose$1(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._inputBufferHandle = $.$default($.$spc.System.Buffers.MemoryHandle);
                $.$finalizer(this);
            }
            static $h = 1373586;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":51540981138,"f":2},"n":"SyncLock","d":1373586,"h":47246013842,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":64425883026,"f":1},"n":"AvailableOutput","d":1373586,"h":60130915730,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":154620196242,"f":2},"n":"IsInputBufferHandleAllocated","d":1373586,"h":150325228946,"f":2}],"m":[{"r":262145,"n":"Finished","d":1373586,"h":68720850322,"f":1},{"r":262145,"p":[{"n":"b","p":393217,"f":2}],"n":"Inflate","d":1373586,"h":73015817618,"f":1},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"Inflate","o":"@$1","d":1373586,"h":77310784914,"f":1},{"r":655361,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Inflate","o":"@$2","d":1373586,"h":81605752210,"f":1},{"r":655361,"p":[{"n":"bufPtr","p":0},{"n":"length","p":655361}],"n":"InflateVerified","d":1373586,"h":85900719506,"f":1},{"r":65537,"p":[{"n":"bufPtr","p":0},{"n":"length","p":655361},{"n":"bytesRead","p":655361,"f":2}],"n":"ReadOutput","d":1373586,"h":90195686802,"f":2},{"r":262145,"n":"ResetStreamForLeftoverInput","d":1373586,"h":94490654098,"f":2},{"r":262145,"n":"IsGzipStream","d":1373586,"h":98785621394,"f":8},{"r":262145,"n":"NeedsInput","d":1373586,"h":103080588690,"f":1},{"r":262145,"n":"NonEmptyInput","d":1373586,"h":107375555986,"f":1},{"r":65537,"p":[{"n":"inputBuffer","p":0},{"n":"startIndex","p":655361},{"n":"count","p":655361}],"n":"SetInput","d":1373586,"h":111670523282,"f":1},{"r":65537,"p":[{"n":"inputBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h}],"n":"SetInput","o":"@$1","d":1373586,"h":115965490578,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":1373586,"h":120260457874,"f":2},{"r":65537,"n":"Dispose","o":"@$1","d":1373586,"h":124555425170,"f":1},{"r":65537,"p":[{"n":"windowBits","p":655361}],"n":"InflateInit","d":1373586,"h":133145359762,"f":2},{"r":4978066,"p":[{"n":"bufPtr","p":0},{"n":"length","p":655361},{"n":"flushCode","p":5043602},{"n":"bytesRead","p":655361,"f":2}],"n":"ReadInflateOutput","d":1373586,"h":137440327058,"f":2},{"r":4978066,"p":[{"n":"flushCode","p":5043602}],"n":"Inflate","o":"@$3","d":1373586,"h":141735294354,"f":2},{"r":65537,"n":"DeallocateInputBufferHandle","d":1373586,"h":146030261650,"f":2}],"l":[{"t":655361,"n":"MinWindowBits","d":1373586,"h":4296340882,"f":34},{"t":655361,"n":"MaxWindowBits","d":1373586,"h":8591308178,"f":34},{"t":262145,"n":"_nonEmptyInput","d":1373586,"h":12886275474,"f":2},{"t":262145,"n":"_finished","d":1373586,"h":17181242770,"f":2},{"t":262145,"n":"_isDisposed","d":1373586,"h":21476210066,"f":2},{"t":655361,"n":"_windowBits","d":1373586,"h":25771177362,"f":2},{"t":5109138,"n":"_zlibStream","d":1373586,"h":30066144658,"f":2},{"t":18481153,"n":"_inputBufferHandle","d":1373586,"h":34361111954,"f":2},{"t":917505,"n":"_uncompressedSize","d":1373586,"h":38656079250,"f":2},{"t":917505,"n":"_currentInflatedCount","d":1373586,"h":42951046546,"f":2}],"c":[{"p":[{"n":"windowBits","p":655361},{"n":"uncompressedSize","p":917505,"f":65,"v":-1}],"n":".ctor","o":"$ctor$1","d":1373586,"h":55835948434,"f":8}],"i":[57540609],"h":1373586}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.Compression.Inflater`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.Deflater", ($self) => class Deflater extends $.$spc.System.Object
        {
            /*ZLibNative.ZLibStreamHandle*/ _zlibStream = null;
            /*MemoryHandle*/ _inputBufferHandle;
            /*bool*/ _isDisposed = false;
            /*int*/ static minWindowBits = -15;
            /*int*/ static maxWindowBits = 31;
            /*object */ get SyncLock()
            {
                return this;
            }
            $ctor$1(/*ZLibNative.CompressionLevel*/ compressionLevel, /*ZLibNative.CompressionStrategy*/ strategy, /*int*/ windowBits, /*int*/ memLevel)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(windowBits >= -15/*minWindowBits*/ && windowBits <= 31/*maxWindowBits*/, "windowBits >= minWindowBits && windowBits <= maxWindowBits");
                    /*ZErrorCode*/ let errC;
                    try
                    {
                        errC = $.$sic.System.IO.Compression.ZLibNative.CreateZLibStreamForDeflate($.$ref(() => this._zlibStream, ($v) => this._zlibStream = $v, $.$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle), compressionLevel, windowBits, memLevel, strategy);
                    }
                    catch(cause)
                    {
                        throw new $.$sic.System.IO.Compression.ZLibException().$ctor$16($.$sic.System.SR.ZLibErrorDLLLoadError, cause);
                    }
                    switch(errC)
                    {
                        case 0/*ZErrorCode.Ok*/:
                        return this;
                        case -4/*ZErrorCode.MemError*/:
                        throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorNotEnoughMemory, "deflateInit2_", errC, this._zlibStream.GetErrorMessage());
                        case -6/*ZErrorCode.VersionError*/:
                        throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorVersionMismatch, "deflateInit2_", errC, this._zlibStream.GetErrorMessage());
                        case -2/*ZErrorCode.StreamError*/:
                        throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorIncorrectInitParameters, "deflateInit2_", errC, this._zlibStream.GetErrorMessage());
                        default:
                        throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorUnexpected, "deflateInit2_", errC, this._zlibStream.GetErrorMessage());
                    }
                }
                return this;
            }
            $dtor()
            {
                this.Dispose$1(false);
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this._isDisposed)
                {
                    if (disposing)
                    {
                        this._zlibStream.Dispose();
                    }
                    this.DeallocateInputBufferHandle();
                    this._isDisposed = true;
                }
            }
            /*bool */ NeedsInput()
            {
                return 0 === this._zlibStream.AvailIn;
            }
            /*void */ SetInput(/*ReadOnlyMemory<byte>*/ inputBuffer)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.NeedsInput(), "We have something left in previous input!");
                $.$spc.System.Diagnostics.Debug.Assert$1(!inputBuffer.IsEmpty, "!inputBuffer.IsEmpty");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        this._inputBufferHandle = inputBuffer.Pin();
                        this._zlibStream.NextIn = $.$spc.System.IntPtr.op_Explicit$2(this._inputBufferHandle.Pointer);
                        this._zlibStream.AvailIn = (inputBuffer.Length >>> 0);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*void */ SetInput$1(/*byte**/ inputBufferPtr, /*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.NeedsInput(), "We have something left in previous input!");
                $.$spc.System.Diagnostics.Debug.Assert$1(inputBufferPtr !== null, "inputBufferPtr != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        this._zlibStream.NextIn = $.$cast(inputBufferPtr, $.$spc.System.IntPtr);
                        this._zlibStream.AvailIn = (count >>> 0);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*int */ GetDeflateOutput(/*byte[]*/ outputBuffer)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(null !== outputBuffer, "Can't pass in a null output buffer!");
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.NeedsInput(), "GetDeflateOutput should only be called after providing input");
                try
                {
                    /*int*/ let bytesRead;
                    this.ReadDeflateOutput(outputBuffer, 0/*ZFlushCode.NoFlush*/, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32));
                    return bytesRead;
                }
                finally
                {
                    {
                        if (0 === this._zlibStream.AvailIn)
                        {
                            this.DeallocateInputBufferHandle();
                        }
                    }
                }
            }
            /*ZErrorCode */ ReadDeflateOutput(/*byte[]*/ outputBuffer, /*ZFlushCode*/ flushCode, /*out int*/ bytesRead)
            {
                const $t1 = outputBuffer;
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Int32.op_GreaterThan$1($.$ifnn($t1, ($t) => $t.length), 0), "outputBuffer?.Length > 0");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        /*fixed*/ 
                        {
                            /*byte**/ let bufPtr = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$spc.System.Byte, outputBuffer, 0, false, true);
                            this._zlibStream.NextOut = $.$cast(bufPtr, $.$spc.System.IntPtr);
                            this._zlibStream.AvailOut = (outputBuffer.length >>> 0);
                            /*ZErrorCode*/ let errC = this.Deflate(flushCode);
                            bytesRead.$v = ((outputBuffer.length - (this._zlibStream.AvailOut | 0)) | 0);
                            return errC;
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*bool */ Finish(/*byte[]*/ outputBuffer, /*out int*/ bytesRead)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(null !== outputBuffer, "Can't pass in a null output buffer!");
                $.$spc.System.Diagnostics.Debug.Assert$1(outputBuffer.length > 0, "Can't pass in an empty output buffer!");
                /*ZErrorCode*/ let errC = this.ReadDeflateOutput(outputBuffer, 4/*ZFlushCode.Finish*/, bytesRead);
                return errC === 1/*ZErrorCode.StreamEnd*/;
            }
            /*bool */ Flush(/*byte[]*/ outputBuffer, /*out int*/ bytesRead)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(null !== outputBuffer, "Can't pass in a null output buffer!");
                $.$spc.System.Diagnostics.Debug.Assert$1(outputBuffer.length > 0, "Can't pass in an empty output buffer!");
                $.$spc.System.Diagnostics.Debug.Assert$1(this.NeedsInput(), "We have something left in previous input!");
                return this.ReadDeflateOutput(outputBuffer, 2/*ZFlushCode.SyncFlush*/, bytesRead) === 0/*ZErrorCode.Ok*/;
            }
            /*void */ DeallocateInputBufferHandle()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        this._zlibStream.AvailIn = 0;
                        this._zlibStream.NextIn = $.$sic.System.IO.Compression.ZLibNative.ZNullPtr;
                        this._inputBufferHandle.Dispose();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*ZErrorCode */ Deflate(/*ZFlushCode*/ flushCode)
            {
                /*ZErrorCode*/ let errC;
                try
                {
                    errC = this._zlibStream.Deflate(flushCode);
                }
                catch(cause)
                {
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$16($.$sic.System.SR.ZLibErrorDLLLoadError, cause);
                }
                switch(errC)
                {
                    case 0/*ZErrorCode.Ok*/:
                    case 1/*ZErrorCode.StreamEnd*/:
                    return errC;
                    case -5/*ZErrorCode.BufError*/:
                    return errC;
                    case -2/*ZErrorCode.StreamError*/:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorInconsistentStream, "deflate", errC, this._zlibStream.GetErrorMessage());
                    default:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorUnexpected, "deflate", errC, this._zlibStream.GetErrorMessage());
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._inputBufferHandle = $.$default($.$spc.System.Buffers.MemoryHandle);
                $.$finalizer(this);
            }
            static $h = 1045906;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":30065816978,"f":2},"n":"SyncLock","d":1045906,"h":25770849682,"f":2}],"m":[{"r":65537,"n":"Dispose","d":1045906,"h":42950718866,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1045906,"h":47245686162,"f":2},{"r":262145,"n":"NeedsInput","d":1045906,"h":51540653458,"f":1},{"r":65537,"p":[{"n":"inputBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h}],"n":"SetInput","d":1045906,"h":55835620754,"f":8},{"r":65537,"p":[{"n":"inputBufferPtr","p":0},{"n":"count","p":655361}],"n":"SetInput","o":"@$1","d":1045906,"h":60130588050,"f":8},{"r":655361,"p":[{"n":"outputBuffer","p":0}],"n":"GetDeflateOutput","d":1045906,"h":64425555346,"f":8},{"r":4978066,"p":[{"n":"outputBuffer","p":0},{"n":"flushCode","p":5043602},{"n":"bytesRead","p":655361,"f":2}],"n":"ReadDeflateOutput","d":1045906,"h":68720522642,"f":2},{"r":262145,"p":[{"n":"outputBuffer","p":0},{"n":"bytesRead","p":655361,"f":2}],"n":"Finish","d":1045906,"h":73015489938,"f":8},{"r":262145,"p":[{"n":"outputBuffer","p":0},{"n":"bytesRead","p":655361,"f":2}],"n":"Flush","d":1045906,"h":77310457234,"f":8},{"r":65537,"n":"DeallocateInputBufferHandle","d":1045906,"h":81605424530,"f":2},{"r":4978066,"p":[{"n":"flushCode","p":5043602}],"n":"Deflate","d":1045906,"h":85900391826,"f":2}],"l":[{"t":5109138,"n":"_zlibStream","d":1045906,"h":4296013202,"f":2},{"t":18481153,"n":"_inputBufferHandle","d":1045906,"h":8590980498,"f":2},{"t":262145,"n":"_isDisposed","d":1045906,"h":12885947794,"f":2},{"t":655361,"n":"minWindowBits","d":1045906,"h":17180915090,"f":34},{"t":655361,"n":"maxWindowBits","d":1045906,"h":21475882386,"f":34}],"c":[{"p":[{"n":"compressionLevel","p":4781458},{"n":"strategy","p":4912530},{"n":"windowBits","p":655361},{"n":"memLevel","p":655361}],"n":".ctor","o":"$ctor$1","d":1045906,"h":34360784274,"f":8}],"i":[57540609],"h":1045906}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.Compression.Deflater`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipArchive", ($self) => class ZipArchive extends $.$spc.System.Object
        {
            static /*Task<ZipArchive> *//*async*/  CreateAsync(/*Stream*/ stream, /*ZipArchiveMode*/ mode, /*bool*/ leaveOpen, /*Encoding?*/ entryNameEncoding, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.ZipArchive), $.$sic.System.IO.Compression.ZipArchive, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                    /*Stream?*/ let extraTempStream = null;
                    try
                    {
                        /*Stream?*/ let backingStream = null;
                        if ($.$sic.System.IO.Compression.ZipArchive.ValidateMode(mode, stream))
                        {
                            backingStream = stream;
                            extraTempStream = stream = new $.$spc.System.IO.MemoryStream().$ctor$3();
                            await backingStream.CopyToAsync$2(stream, cancellationToken).ConfigureAwait(false);
                            stream.Seek(0n, 0/*SeekOrigin.Begin*/);
                        }
                        /*ZipArchive*/ let zipArchive = new $.$sic.System.IO.Compression.ZipArchive().$ctor$5(mode, leaveOpen, entryNameEncoding, backingStream, $.$sic.System.IO.Compression.ZipArchive.DecideArchiveStream(mode, stream));
                        switch(mode)
                        {
                            case 1/*ZipArchiveMode.Create*/:
                            zipArchive._readEntries = true;
                            break;
                            case 0/*ZipArchiveMode.Read*/:
                            await zipArchive.ReadEndOfCentralDirectoryAsync(cancellationToken).ConfigureAwait(false);
                            break;
                            case 2/*ZipArchiveMode.Update*/:
                            default:
                            $.$spc.System.Diagnostics.Debug.Assert$1(mode === 2/*ZipArchiveMode.Update*/, "mode == ZipArchiveMode.Update");
                            if (zipArchive._archiveStream.Length === 0n)
                            {
                                zipArchive._readEntries = true;
                            }
                            else 
                            {
                                await zipArchive.ReadEndOfCentralDirectoryAsync(cancellationToken).ConfigureAwait(false);
                                await zipArchive.EnsureCentralDirectoryReadAsync(cancellationToken).ConfigureAwait(false);
                                var $en6 = zipArchive._entries.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var entry = $en6.Current;
                                    {
                                        await entry.ThrowIfNotOpenableAsync(false, true, cancellationToken).ConfigureAwait(false);
                                    }
                                }
                            }
                            break;
                        }
                        return zipArchive;
                    }
                    catch($e)
                    {
                        if (extraTempStream !== null)
                        {
                            await extraTempStream.DisposeAsync().ConfigureAwait(false);
                        }
                        throw $e;
                    }
                });
            }
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    return await this.DisposeAsyncCore().ConfigureAwait(false);
                });
            }
            /*ValueTask *//*async*/  DisposeAsyncCore()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    if (!this._isDisposed)
                    {
                        try
                        {
                            switch(this._mode)
                            {
                                case 0/*ZipArchiveMode.Read*/:
                                break;
                                case 1/*ZipArchiveMode.Create*/:
                                case 2/*ZipArchiveMode.Update*/:
                                default:
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._mode === 2/*ZipArchiveMode.Update*/ || this._mode === 1/*ZipArchiveMode.Create*/, "_mode == ZipArchiveMode.Update || _mode == ZipArchiveMode.Create");
                                await this.WriteFileAsync(new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                                break;
                            }
                        }
                        finally
                        {
                            {
                                await this.CloseStreamsAsync().ConfigureAwait(false);
                                this._isDisposed = true;
                            }
                        }
                    }
                });
            }
            /*Task *//*async*/  CloseStreamsAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (!this._leaveOpen)
                    {
                        await this._archiveStream.DisposeAsync().ConfigureAwait(false);
                        if (this._backingStream !== null)
                        {
                            await this._backingStream.DisposeAsync().ConfigureAwait(false);
                        }
                    }
                    else 
                    {
                        if (this._backingStream !== null)
                        {
                            await this._archiveStream.DisposeAsync().ConfigureAwait(false);
                        }
                    }
                });
            }
            /*Task *//*async*/  EnsureCentralDirectoryReadAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (!this._readEntries)
                    {
                        await this.ReadCentralDirectoryAsync(cancellationToken).ConfigureAwait(false);
                        this._readEntries = true;
                    }
                });
            }
            /*Task *//*async*/  ReadCentralDirectoryAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    try
                    {
                        /*byte[]*/ let fileBuffer;
                        /*long*/ let numberOfEntries;
                        /*bool*/ let saveExtraFieldsAndComments;
                        /*bool*/ let continueReadingCentralDirectory;
                        /*int*/ let bytesRead;
                        /*int*/ let currPosition;
                        /*int*/ let bytesConsumed;
                        this.ReadCentralDirectoryInitialize($.$ref(() => fileBuffer, ($v) => fileBuffer = $v, $.$typeArray($.$spc.System.Byte)), $.$ref(() => numberOfEntries, ($v) => numberOfEntries = $v, $.$spc.System.Int64), $.$ref(() => saveExtraFieldsAndComments, ($v) => saveExtraFieldsAndComments = $v, $.$spc.System.Boolean), $.$ref(() => continueReadingCentralDirectory, ($v) => continueReadingCentralDirectory = $v, $.$spc.System.Boolean), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => currPosition, ($v) => currPosition = $v, $.$spc.System.Int32), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32));
                        while(continueReadingCentralDirectory)
                        {
                            /*int*/ let currBytesRead = await this._archiveStream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(fileBuffer), 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                            /*byte[]*/ let sizedFileBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetSubArray($.$spc.System.Byte, fileBuffer, new $.$spc.System.Range().$ctor$2($.$spc.System.Index.op_Implicit(0), $.$spc.System.Index.op_Implicit(currBytesRead)));
                            continueReadingCentralDirectory = currBytesRead >= 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/;
                            while(((currPosition + 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/) | 0) <= currBytesRead)
                            {
                                /*bool*/ let result;
        /*ZipCentralDirectoryFileHeader?*/ let currentHeader;
        $.$tupleUnpack(($tp) =>
                                {
                                    result = $tp.Item1;
                                    bytesConsumed = $tp.Item2;
                                    currentHeader = $tp.Item3;
                                }).$v = await $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.TryReadBlockAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$6($.$spc.System.Byte, sizedFileBuffer, currPosition)), this._archiveStream, saveExtraFieldsAndComments, cancellationToken).ConfigureAwait$2(false);
                                if (!this.ReadCentralDirectoryEndOfInnerLoopWork(result, currentHeader, bytesConsumed, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => continueReadingCentralDirectory, ($v) => continueReadingCentralDirectory = $v, null), $.$ref(() => numberOfEntries, ($v) => numberOfEntries = $v, $.$spc.System.Int64), $.$ref(() => currPosition, ($v) => currPosition = $v, $.$spc.System.Int32), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32)))
                                {
                                    break;
                                }
                            }
                            this.ReadCentralDirectoryEndOfOuterLoopWork($.$ref(() => currPosition, ($v) => currPosition = $v, $.$spc.System.Int32), $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(sizedFileBuffer));
                        }
                        this.ReadCentralDirectoryPostOuterLoopWork(numberOfEntries);
                    }
                    catch(ex)
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.Format($.$sic.System.SR.CentralDirectoryInvalid, ex));
                    }
                });
            }
            /*Task *//*async*/  ReadEndOfCentralDirectoryAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    try
                    {
                        this._archiveStream.Seek(BigInt(-18/*ZipEndOfCentralDirectoryBlock.SizeOfBlockWithoutSignature*/), 2/*SeekOrigin.End*/);
                        if (!await $.$sic.System.IO.Compression.ZipHelper.SeekBackwardsToSignatureAsync(this._archiveStream, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit($.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.SignatureConstantBytes), ((65535/*ZipEndOfCentralDirectoryBlock.ZipFileCommentMaxLength*/ + 4/*ZipEndOfCentralDirectoryBlock.FieldLengths.Signature*/) | 0), cancellationToken).ConfigureAwait$2(false))
                        {
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.EOCDNotFound);
                        }
                        /*long*/ let eocdStart = this._archiveStream.Position;
                        /*ZipEndOfCentralDirectoryBlock*/ let eocd = await $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.ReadBlockAsync(this._archiveStream, cancellationToken).ConfigureAwait$2(false);
                        this.ReadEndOfCentralDirectoryInnerWork(eocd);
                        await this.TryReadZip64EndOfCentralDirectoryAsync(eocd, eocdStart, cancellationToken).ConfigureAwait(false);
                        if (this._centralDirectoryStart > this._archiveStream.Length)
                        {
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigOffsetToCD);
                        }
                    }
                    catch($e)
                    {
                        if ($e instanceof $.$spc.System.IO.EndOfStreamException)
                        {
                            let ex = $e;
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$11($.$sic.System.SR.CDCorrupt, ex);
                        }
                        else if ($e instanceof $.$spc.System.IO.IOException)
                        {
                            let ex = $e;
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$11($.$sic.System.SR.CDCorrupt, ex);
                        }
                        else
                        {
                            throw $e;
                        }
                    }
                });
            }
            /*ValueTask *//*async*/  TryReadZip64EndOfCentralDirectoryAsync(/*ZipEndOfCentralDirectoryBlock*/ eocd, /*long*/ eocdStart, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (eocd.NumberOfThisDisk === 65535/*ZipHelper.Mask16Bit*/ || eocd.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber === 4294967295/*ZipHelper.Mask32Bit*/ || eocd.NumberOfEntriesInTheCentralDirectory === 65535/*ZipHelper.Mask16Bit*/)
                    {
                        if (eocdStart < BigInt(20/*Zip64EndOfCentralDirectoryLocator.TotalSize*/))
                        {
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.Zip64EOCDNotWhereExpected);
                        }
                        this._archiveStream.Seek(eocdStart - BigInt(16/*Zip64EndOfCentralDirectoryLocator.SizeOfBlockWithoutSignature*/), 0/*SeekOrigin.Begin*/);
                        if (await $.$sic.System.IO.Compression.ZipHelper.SeekBackwardsToSignatureAsync(this._archiveStream, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.SignatureConstantBytes), 4/*Zip64EndOfCentralDirectoryLocator.FieldLengths.Signature*/, cancellationToken).ConfigureAwait$2(false))
                        {
                            /*Zip64EndOfCentralDirectoryLocator*/ let locator = await $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.TryReadBlockAsync(this._archiveStream, cancellationToken).ConfigureAwait$2(false);
                            this.TryReadZip64EndOfCentralDirectoryInnerInitialWork(locator);
                            /*Zip64EndOfCentralDirectoryRecord*/ let record = await $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.TryReadBlockAsync(this._archiveStream, cancellationToken).ConfigureAwait$2(false);
                            this.TryReadZip64EndOfCentralDirectoryInnerFinalWork(record);
                        }
                    }
                });
            }
            /*ValueTask *//*async*/  WriteFileAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readEntries, "_readEntries");
                    /*long*/ let completeRewriteStartingOffset = 0n;
                    /*List<ZipArchiveEntry>*/ let entriesToWrite = this._entries;
                    if (this._mode === 2/*ZipArchiveMode.Update*/)
                    {
                        /*long*/ let startingOffset = this._firstDeletedEntryOffset;
                        /*long*/ let nextFileOffset = 0n;
                        completeRewriteStartingOffset = startingOffset;
                        entriesToWrite = new ($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor$2(this._entries.Count);
                        var $en4 = this._entries.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var entry = $en4.Current;
                            {
                                if (!entry.OriginallyInArchive)
                                {
                                    entriesToWrite.Add(entry);
                                }
                                else 
                                {
                                    $.$sic.System.IO.Compression.ZipArchive.WriteFileCalculateOffsets(entry, $.$ref(() => startingOffset, ($v) => startingOffset = $v, $.$spc.System.Int64), $.$ref(() => nextFileOffset, ($v) => nextFileOffset = $v, $.$spc.System.Int64));
                                    if (entry.OffsetOfLocalHeader >= startingOffset)
                                    {
                                        $.$sic.System.IO.Compression.ZipArchive.WriteFileCheckStartingOffset(entry, $.$ref(() => completeRewriteStartingOffset, ($v) => completeRewriteStartingOffset = $v, $.$spc.System.Int64));
                                        await entry.LoadLocalHeaderExtraFieldIfNeededAsync(cancellationToken).ConfigureAwait(false);
                                        if (entry.OffsetOfLocalHeader >= completeRewriteStartingOffset)
                                        {
                                            await entry.LoadCompressedBytesIfNeededAsync(cancellationToken).ConfigureAwait(false);
                                        }
                                        entriesToWrite.Add(entry);
                                    }
                                }
                            }
                        }
                        this.WriteFileUpdateModeFinalWork(startingOffset, nextFileOffset);
                    }
                    var $en3 = entriesToWrite.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            /*bool*/ let forceWriteLocalEntry = !entry.OriginallyInArchive || (entry.OriginallyInArchive && entry.OffsetOfLocalHeader >= completeRewriteStartingOffset);
                            await entry.WriteAndFinishLocalEntryAsync(forceWriteLocalEntry, cancellationToken).ConfigureAwait(false);
                        }
                    }
                    /*long*/ let plannedCentralDirectoryPosition = this._archiveStream.Position;
                    /*bool*/ let archiveEpilogueRequiresUpdate = this._entries.Count === 0;
                    var $en3 = this._entries.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            /*bool*/ let centralDirectoryEntryRequiresUpdate = plannedCentralDirectoryPosition !== this._centralDirectoryStart || !entry.OriginallyInArchive || entry.OffsetOfLocalHeader >= completeRewriteStartingOffset;
                            await entry.WriteCentralDirectoryFileHeaderAsync(centralDirectoryEntryRequiresUpdate, cancellationToken).ConfigureAwait(false);
                            archiveEpilogueRequiresUpdate = $.$spc.System.Boolean.op_BitwiseOr(archiveEpilogueRequiresUpdate, centralDirectoryEntryRequiresUpdate);
                        }
                    }
                    /*long*/ let sizeOfCentralDirectory = this._archiveStream.Position - plannedCentralDirectoryPosition;
                    await this.WriteArchiveEpilogueAsync(plannedCentralDirectoryPosition, sizeOfCentralDirectory, archiveEpilogueRequiresUpdate, cancellationToken).ConfigureAwait(false);
                    this.WriteFileFinalWork();
                });
            }
            /*ValueTask *//*async*/  WriteArchiveEpilogueAsync(/*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory, /*bool*/ centralDirectoryChanged, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (startOfCentralDirectory >= BigInt(4294967295/*uint.MaxValue*/) || sizeOfCentralDirectory >= BigInt(4294967295/*uint.MaxValue*/) || this._entries.Count >= 65535/*ZipHelper.Mask16Bit*/)
                    {
                        /*long*/ let zip64EOCDRecordStart = this._archiveStream.Position;
                        if (centralDirectoryChanged)
                        {
                            await $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.WriteBlockAsync(this._archiveStream, BigInt(this._entries.Count), startOfCentralDirectory, sizeOfCentralDirectory, cancellationToken).ConfigureAwait(false);
                            await $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.WriteBlockAsync(this._archiveStream, zip64EOCDRecordStart, cancellationToken).ConfigureAwait(false);
                        }
                        else 
                        {
                            this.WriteArchiveEpilogueNoCDChangesWork();
                        }
                    }
                    if (centralDirectoryChanged || (this.Changed !== 0/*ChangeState.Unchanged*/))
                    {
                        await $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.WriteBlockAsync(this._archiveStream, BigInt(this._entries.Count), startOfCentralDirectory, sizeOfCentralDirectory, this._archiveComment, cancellationToken).ConfigureAwait(false);
                    }
                    else 
                    {
                        this._archiveStream.Seek(BigInt(22/*ZipEndOfCentralDirectoryBlock.TotalSize*/ + this._archiveComment.length), 1/*SeekOrigin.Current*/);
                    }
                });
            }
            /*Stream*/ _archiveStream = null;
            /*ZipArchiveEntry?*/ _archiveStreamOwner = null;
            /*ZipArchiveMode*/ _mode = 0;
            /*List<ZipArchiveEntry>*/ _entries = null;
            /*ReadOnlyCollection<ZipArchiveEntry>*/ _entriesCollection = null;
            /*Dictionary<string, ZipArchiveEntry>*/ _entriesDictionary = null;
            /*bool*/ _readEntries = false;
            /*bool*/ _leaveOpen = false;
            /*long*/ _centralDirectoryStart = 0n;
            /*bool*/ _isDisposed = false;
            /*uint*/ _numberOfThisDisk = 0;
            /*long*/ _expectedNumberOfEntries = 0n;
            /*Stream?*/ _backingStream = null;
            /*byte[]*/ _archiveComment = null;
            /*Encoding?*/ _entryNameAndCommentEncoding = null;
            /*long*/ _firstDeletedEntryOffset = 0n;
            $ctor$1(/*Stream*/ stream)
            {
                this.$ctor$4(stream, 0/*ZipArchiveMode.Read*/, false, null);
                {
                }
                return this;
            }
            $ctor$2(/*Stream*/ stream, /*ZipArchiveMode*/ mode)
            {
                this.$ctor$4(stream, mode, false, null);
                {
                }
                return this;
            }
            $ctor$3(/*Stream*/ stream, /*ZipArchiveMode*/ mode, /*bool*/ leaveOpen)
            {
                this.$ctor$4(stream, mode, leaveOpen, null);
                {
                }
                return this;
            }
            $ctor$4(/*Stream*/ stream, /*ZipArchiveMode*/ mode, /*bool*/ leaveOpen, /*Encoding?*/ entryNameEncoding)
            {
                this.$ctor$5(mode, leaveOpen, entryNameEncoding, null, $.$sic.System.IO.Compression.ZipArchive.DecideArchiveStream(mode, stream));
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                    /*Stream?*/ let extraTempStream = null;
                    try
                    {
                        this._backingStream = null;
                        if ($.$sic.System.IO.Compression.ZipArchive.ValidateMode(mode, stream))
                        {
                            this._backingStream = stream;
                            extraTempStream = stream = new $.$spc.System.IO.MemoryStream().$ctor$3();
                            this._backingStream.CopyTo(stream);
                            stream.Seek(0n, 0/*SeekOrigin.Begin*/);
                        }
                        this._archiveStream = $.$sic.System.IO.Compression.ZipArchive.DecideArchiveStream(mode, stream);
                        switch(mode)
                        {
                            case 1/*ZipArchiveMode.Create*/:
                            this._readEntries = true;
                            break;
                            case 0/*ZipArchiveMode.Read*/:
                            this.ReadEndOfCentralDirectory();
                            break;
                            case 2/*ZipArchiveMode.Update*/:
                            default:
                            $.$spc.System.Diagnostics.Debug.Assert$1(mode === 2/*ZipArchiveMode.Update*/, "mode == ZipArchiveMode.Update");
                            if (this._archiveStream.Length === 0n)
                            {
                                this._readEntries = true;
                            }
                            else 
                            {
                                this.ReadEndOfCentralDirectory();
                                this.EnsureCentralDirectoryRead();
                                var $en6 = this._entries.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var entry = $en6.Current;
                                    {
                                        entry.ThrowIfNotOpenable(false, true);
                                    }
                                }
                            }
                            break;
                        }
                    }
                    catch($e)
                    {
                        extraTempStream?.Dispose();
                        throw $e;
                    }
                }
                return this;
            }
            $ctor$5(/*ZipArchiveMode*/ mode, /*bool*/ leaveOpen, /*Encoding?*/ entryNameEncoding, /*Stream?*/ backingStream, /*Stream*/ archiveStream)
            {
                super.$ctor();
                {
                    this._backingStream = backingStream;
                    this._archiveStream = archiveStream;
                    this._mode = mode;
                    this.EntryNameAndCommentEncoding = entryNameEncoding;
                    this._archiveStreamOwner = null;
                    this._entries = new ($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor$1();
                    this._entriesCollection = new ($.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor$1(this._entries);
                    this._entriesDictionary = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor$1();
                    this.Changed = 0/*ChangeState.Unchanged*/;
                    this._readEntries = false;
                    this._leaveOpen = leaveOpen;
                    this._centralDirectoryStart = 0n;
                    this._isDisposed = false;
                    this._numberOfThisDisk = 0;
                    this._archiveComment = $.$spc.System.Array.Empty($.$spc.System.Byte);
                    this._firstDeletedEntryOffset = 9223372036854775807n;
                }
                return this;
            }
            /*string */ get Comment()
            {
                return (this.EntryNameAndCommentEncoding ?? $.$spc.System.Text.Encoding.UTF8).GetString$2(this._archiveComment);
            }
            /*string */ set Comment(value)
            {
                this._archiveComment = $.$sic.System.IO.Compression.ZipHelper.GetEncodedTruncatedBytesFromString(value, this.EntryNameAndCommentEncoding, 65535/*ZipEndOfCentralDirectoryBlock.ZipFileCommentMaxLength*/, $.$discardRef());
                this.Changed |= 2/*ChangeState.DynamicLengthMetadata*/;
            }
            /*ReadOnlyCollection<ZipArchiveEntry> */ get Entries()
            {
                if (this._mode === 1/*ZipArchiveMode.Create*/)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.EntriesInCreateMode);
                }
                this.ThrowIfDisposed();
                this.EnsureCentralDirectoryRead();
                return this._entriesCollection;
            }
            /*ZipArchiveMode */ get Mode()
            {
                return this._mode;
            }
            /*ZipArchiveEntry */ CreateEntry(/*string*/ entryName)
            {
                return this.DoCreateEntry(entryName, null);
            }
            /*ZipArchiveEntry */ CreateEntry$1(/*string*/ entryName, /*CompressionLevel*/ compressionLevel)
            {
                return this.DoCreateEntry(entryName, compressionLevel);
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                if (disposing && !this._isDisposed)
                {
                    try
                    {
                        switch(this._mode)
                        {
                            case 0/*ZipArchiveMode.Read*/:
                            break;
                            case 1/*ZipArchiveMode.Create*/:
                            case 2/*ZipArchiveMode.Update*/:
                            default:
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._mode === 2/*ZipArchiveMode.Update*/ || this._mode === 1/*ZipArchiveMode.Create*/, "_mode == ZipArchiveMode.Update || _mode == ZipArchiveMode.Create");
                            this.WriteFile();
                            break;
                        }
                    }
                    finally
                    {
                        {
                            this.CloseStreams();
                            this._isDisposed = true;
                        }
                    }
                }
            }
            /*void */ Dispose$1()
            {
                return this.Dispose(true);
            }
            /*ZipArchiveEntry? */ GetEntry(/*string*/ entryName)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(entryName, "entryName");
                if (this._mode === 1/*ZipArchiveMode.Create*/)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.EntriesInCreateMode);
                }
                this.EnsureCentralDirectoryRead();
                /*ZipArchiveEntry?*/ let result;
                this._entriesDictionary.TryGetValue(entryName, $.$ref(() => result, ($v) => result = $v, $.$sic.System.IO.Compression.ZipArchiveEntry));
                return result;
            }
            /*Stream */ get ArchiveStream()
            {
                return this._archiveStream;
            }
            /*uint */ get NumberOfThisDisk()
            {
                return this._numberOfThisDisk;
            }
            /*Encoding? */ get EntryNameAndCommentEncoding()
            {
                return this._entryNameAndCommentEncoding;
            }
            /*Encoding? */ set EntryNameAndCommentEncoding(value)
            {
                if (value !== null && ($.$spc.System.Text.Encoding.Equals.call(value, $.$spc.System.Text.Encoding.BigEndianUnicode) || $.$spc.System.Text.Encoding.Equals.call(value, $.$spc.System.Text.Encoding.Unicode)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sic.System.SR.EntryNameAndCommentEncodingNotSupported, "EntryNameAndCommentEncoding");
                }
                this._entryNameAndCommentEncoding = value;
            }
            /*ChangeState*/ Changed = 0;
            /*ZipArchiveEntry */ DoCreateEntry(/*string*/ entryName, /*CompressionLevel?*/ compressionLevel)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(entryName, "entryName");
                if (this._mode === 0/*ZipArchiveMode.Read*/)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.CreateInReadMode);
                }
                this.ThrowIfDisposed();
                /*ZipArchiveEntry*/ let entry = $.$spc.System.Nullable$$($.$sic.System.IO.Compression.CompressionLevel).HasValue$get.call(compressionLevel) ? new $.$sic.System.IO.Compression.ZipArchiveEntry().$ctor$2(this, entryName, $.$spc.System.Nullable$$($.$sic.System.IO.Compression.CompressionLevel).Value$get.call(compressionLevel)) : new $.$sic.System.IO.Compression.ZipArchiveEntry().$ctor$3(this, entryName);
                this.AddEntry(entry);
                return entry;
            }
            /*void */ AcquireArchiveStream(/*ZipArchiveEntry*/ entry)
            {
                if (this._archiveStreamOwner !== null)
                {
                    if (!this._archiveStreamOwner.EverOpenedForWrite)
                    {
                        this._archiveStreamOwner.WriteAndFinishLocalEntry(true);
                    }
                    else 
                    {
                        throw new $.$spc.System.IO.IOException().$ctor$10($.$sic.System.SR.CreateModeCreateEntryWhileOpen);
                    }
                }
                this._archiveStreamOwner = entry;
            }
            /*void */ AddEntry(/*ZipArchiveEntry*/ entry)
            {
                this._entries.Add(entry);
                this._entriesDictionary.TryAdd(entry.FullName, entry);
            }
            /*void */ DebugAssertIsStillArchiveStreamOwner(/*ZipArchiveEntry*/ entry)
            {
                return $.$spc.System.Diagnostics.Debug.Assert$1(this._archiveStreamOwner === entry, "_archiveStreamOwner == entry");
            }
            /*void */ ReleaseArchiveStream(/*ZipArchiveEntry*/ entry)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._archiveStreamOwner === entry, "_archiveStreamOwner == entry");
                this._archiveStreamOwner = null;
            }
            /*void */ RemoveEntry(/*ZipArchiveEntry*/ entry)
            {
                this._entries.Remove(entry);
                this._entriesDictionary.Remove(entry.FullName);
                if (entry.OriginallyInArchive && entry.OffsetOfLocalHeader < this._firstDeletedEntryOffset)
                {
                    this._firstDeletedEntryOffset = entry.OffsetOfLocalHeader;
                }
            }
            /*void */ ThrowIfDisposed()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._isDisposed, this);
            }
            /*void */ CloseStreams()
            {
                if (!this._leaveOpen)
                {
                    this._archiveStream.Dispose();
                    this._backingStream?.Dispose();
                }
                else 
                {
                    if (this._backingStream !== null)
                    {
                        this._archiveStream.Dispose();
                    }
                }
            }
            /*void */ EnsureCentralDirectoryRead()
            {
                if (!this._readEntries)
                {
                    this.ReadCentralDirectory();
                    this._readEntries = true;
                }
            }
            /*void */ ReadCentralDirectoryInitialize(/*out byte[]*/ fileBuffer, /*out long*/ numberOfEntries, /*out bool*/ saveExtraFieldsAndComments, /*out bool*/ continueReadingCentralDirectory, /*out int*/ bytesRead, /*out int*/ currPosition, /*out int*/ bytesConsumed)
            {
                /*int*/ let ReadCentralDirectoryReadBufferSize = 4096;
                fileBuffer.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [ReadCentralDirectoryReadBufferSize], null);
                this._archiveStream.Seek(this._centralDirectoryStart, 0/*SeekOrigin.Begin*/);
                numberOfEntries.$v = 0n;
                saveExtraFieldsAndComments.$v = this.Mode === 2/*ZipArchiveMode.Update*/;
                continueReadingCentralDirectory.$v = true;
                bytesRead.$v = 0;
                currPosition.$v = 0;
                bytesConsumed.$v = 0;
                this._entries.Clear();
                this._entriesDictionary.Clear();
            }
            /*bool */ ReadCentralDirectoryEndOfInnerLoopWork(/*bool*/ result, /*ZipCentralDirectoryFileHeader?*/ currentHeader, /*int*/ bytesConsumed, /*ref bool*/ continueReadingCentralDirectory, /*ref long*/ numberOfEntries, /*ref int*/ currPosition, /*ref int*/ bytesRead)
            {
                if (!result)
                {
                    continueReadingCentralDirectory.$v = false;
                    return false;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(currentHeader !== null, "currentHeader should not be null here");
                this.AddEntry(new $.$sic.System.IO.Compression.ZipArchiveEntry().$ctor$1(this, currentHeader));
                numberOfEntries.$v++;
                if (numberOfEntries.$v > this._expectedNumberOfEntries)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.NumEntriesWrong);
                }
                currPosition.$v += bytesConsumed;
                bytesRead.$v += bytesConsumed;
                return true;
            }
            /*void */ ReadCentralDirectoryEndOfOuterLoopWork(/*ref int*/ currPosition, /*ReadOnlySpan<byte>*/ sizedFileBuffer)
            {
                if (currPosition.$v < sizedFileBuffer.Length)
                {
                    this._archiveStream.Seek(BigInt(-(((sizedFileBuffer.Length - currPosition.$v) | 0))), 1/*SeekOrigin.Current*/);
                }
                currPosition.$v = 0;
            }
            /*void */ ReadCentralDirectoryPostOuterLoopWork(/*long*/ numberOfEntries)
            {
                if (numberOfEntries !== this._expectedNumberOfEntries)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.NumEntriesWrong);
                }
                if (this.Mode === 2/*ZipArchiveMode.Update*/)
                {
                    this._entries.Sort$1($.$sic.System.IO.Compression.ZipArchiveEntry.LocalHeaderOffsetComparer.Instance);
                }
            }
            /*void */ ReadCentralDirectory()
            {
                try
                {
                    /*byte[]*/ let fileBuffer;
                    /*long*/ let numberOfEntries;
                    /*bool*/ let saveExtraFieldsAndComments;
                    /*bool*/ let continueReadingCentralDirectory;
                    /*int*/ let bytesRead;
                    /*int*/ let currPosition;
                    /*int*/ let bytesConsumed;
                    this.ReadCentralDirectoryInitialize($.$ref(() => fileBuffer, ($v) => fileBuffer = $v, $.$typeArray($.$spc.System.Byte)), $.$ref(() => numberOfEntries, ($v) => numberOfEntries = $v, $.$spc.System.Int64), $.$ref(() => saveExtraFieldsAndComments, ($v) => saveExtraFieldsAndComments = $v, $.$spc.System.Boolean), $.$ref(() => continueReadingCentralDirectory, ($v) => continueReadingCentralDirectory = $v, $.$spc.System.Boolean), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => currPosition, ($v) => currPosition = $v, $.$spc.System.Int32), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32));
                    /*Span<byte>*/ let fileBufferSpan = $.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Byte, fileBuffer);
                    while(continueReadingCentralDirectory)
                    {
                        /*int*/ let currBytesRead = this._archiveStream.ReadAtLeast(fileBufferSpan, 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/, false);
                        /*ReadOnlySpan<byte>*/ let sizedFileBuffer = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(fileBufferSpan.Slice$1(0, currBytesRead));
                        continueReadingCentralDirectory = currBytesRead >= 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/;
                        while(((currPosition + 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/) | 0) <= currBytesRead)
                        {
                            /*ZipCentralDirectoryFileHeader?*/ let currentHeader;
                            /*bool*/ let result = $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.TryReadBlock(sizedFileBuffer.Slice(currPosition), this._archiveStream, saveExtraFieldsAndComments, $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32), $.$ref(() => currentHeader, ($v) => currentHeader = $v, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader));
                            if (!this.ReadCentralDirectoryEndOfInnerLoopWork(result, currentHeader, bytesConsumed, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => continueReadingCentralDirectory, ($v) => continueReadingCentralDirectory = $v, null), $.$ref(() => numberOfEntries, ($v) => numberOfEntries = $v, $.$spc.System.Int64), $.$ref(() => currPosition, ($v) => currPosition = $v, $.$spc.System.Int32), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32)))
                            {
                                break;
                            }
                        }
                        this.ReadCentralDirectoryEndOfOuterLoopWork($.$ref(() => currPosition, ($v) => currPosition = $v, $.$spc.System.Int32), sizedFileBuffer);
                    }
                    this.ReadCentralDirectoryPostOuterLoopWork(numberOfEntries);
                }
                catch(ex)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.Format($.$sic.System.SR.CentralDirectoryInvalid, ex));
                }
            }
            /*void */ ReadEndOfCentralDirectoryInnerWork(/*ZipEndOfCentralDirectoryBlock*/ eocd)
            {
                if (eocd.NumberOfThisDisk !== eocd.NumberOfTheDiskWithTheStartOfTheCentralDirectory)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.SplitSpanned);
                }
                this._numberOfThisDisk = eocd.NumberOfThisDisk;
                this._centralDirectoryStart = BigInt(eocd.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber);
                if (eocd.NumberOfEntriesInTheCentralDirectory !== eocd.NumberOfEntriesInTheCentralDirectoryOnThisDisk)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.SplitSpanned);
                }
                this._expectedNumberOfEntries = BigInt(eocd.NumberOfEntriesInTheCentralDirectory);
                this._archiveComment = eocd.ArchiveComment;
            }
            /*void */ ReadEndOfCentralDirectory()
            {
                try
                {
                    this._archiveStream.Seek(BigInt(-18/*ZipEndOfCentralDirectoryBlock.SizeOfBlockWithoutSignature*/), 2/*SeekOrigin.End*/);
                    if (!$.$sic.System.IO.Compression.ZipHelper.SeekBackwardsToSignature(this._archiveStream, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.SignatureConstantBytes), ((65535/*ZipEndOfCentralDirectoryBlock.ZipFileCommentMaxLength*/ + 4/*ZipEndOfCentralDirectoryBlock.FieldLengths.Signature*/) | 0)))
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.EOCDNotFound);
                    }
                    /*long*/ let eocdStart = this._archiveStream.Position;
                    /*ZipEndOfCentralDirectoryBlock*/ let eocd = $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.ReadBlock(this._archiveStream);
                    this.ReadEndOfCentralDirectoryInnerWork(eocd);
                    this.TryReadZip64EndOfCentralDirectory(eocd, eocdStart);
                    if (this._centralDirectoryStart > this._archiveStream.Length)
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigOffsetToCD);
                    }
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.IO.EndOfStreamException)
                    {
                        let ex = $e;
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$11($.$sic.System.SR.CDCorrupt, ex);
                    }
                    else if ($e instanceof $.$spc.System.IO.IOException)
                    {
                        let ex = $e;
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$11($.$sic.System.SR.CDCorrupt, ex);
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*void */ TryReadZip64EndOfCentralDirectoryInnerInitialWork(/*Zip64EndOfCentralDirectoryLocator?*/ locator)
            {
                if (locator === null || locator.OffsetOfZip64EOCD > 9223372036854775807n)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigOffsetToZip64EOCD);
                }
                /*long*/ let zip64EOCDOffset = $.$cast(locator.OffsetOfZip64EOCD, $.$spc.System.Int64);
                if (zip64EOCDOffset < 0n || zip64EOCDOffset > this._archiveStream.Length)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.InvalidOffsetToZip64EOCD);
                }
                this._archiveStream.Seek(zip64EOCDOffset, 0/*SeekOrigin.Begin*/);
            }
            /*void */ TryReadZip64EndOfCentralDirectoryInnerFinalWork(/*Zip64EndOfCentralDirectoryRecord*/ record)
            {
                this._numberOfThisDisk = record.NumberOfThisDisk;
                if (record.NumberOfEntriesTotal > 9223372036854775807n)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigNumEntries);
                }
                if (record.OffsetOfCentralDirectory > 9223372036854775807n)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigOffsetToCD);
                }
                if (record.NumberOfEntriesTotal !== record.NumberOfEntriesOnThisDisk)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.SplitSpanned);
                }
                this._expectedNumberOfEntries = $.$cast(record.NumberOfEntriesTotal, $.$spc.System.Int64);
                this._centralDirectoryStart = $.$cast(record.OffsetOfCentralDirectory, $.$spc.System.Int64);
            }
            /*void */ TryReadZip64EndOfCentralDirectory(/*ZipEndOfCentralDirectoryBlock*/ eocd, /*long*/ eocdStart)
            {
                if (eocd.NumberOfThisDisk === 65535/*ZipHelper.Mask16Bit*/ || eocd.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber === 4294967295/*ZipHelper.Mask32Bit*/ || eocd.NumberOfEntriesInTheCentralDirectory === 65535/*ZipHelper.Mask16Bit*/)
                {
                    if (eocdStart < BigInt(20/*Zip64EndOfCentralDirectoryLocator.TotalSize*/))
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.Zip64EOCDNotWhereExpected);
                    }
                    this._archiveStream.Seek(eocdStart - BigInt(16/*Zip64EndOfCentralDirectoryLocator.SizeOfBlockWithoutSignature*/), 0/*SeekOrigin.Begin*/);
                    if ($.$sic.System.IO.Compression.ZipHelper.SeekBackwardsToSignature(this._archiveStream, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.SignatureConstantBytes), 4/*Zip64EndOfCentralDirectoryLocator.FieldLengths.Signature*/))
                    {
                        /*Zip64EndOfCentralDirectoryLocator*/ let locator = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.TryReadBlock(this._archiveStream);
                        this.TryReadZip64EndOfCentralDirectoryInnerInitialWork(locator);
                        /*Zip64EndOfCentralDirectoryRecord*/ let record = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.TryReadBlock(this._archiveStream);
                        this.TryReadZip64EndOfCentralDirectoryInnerFinalWork(record);
                    }
                }
            }
            static /*void */ WriteFileCalculateOffsets(/*ZipArchiveEntry*/ entry, /*ref long*/ startingOffset, /*ref long*/ nextFileOffset)
            {
                if (entry.Changes === 0/*ChangeState.Unchanged*/)
                {
                    nextFileOffset.$v = $.$spc.System.Math.Max$5(nextFileOffset.$v, entry.GetOffsetOfCompressedData() + entry.CompressedLength);
                }
                else 
                {
                    startingOffset.$v = $.$spc.System.Math.Min$5(startingOffset.$v, entry.OffsetOfLocalHeader);
                }
            }
            static /*void */ WriteFileCheckStartingOffset(/*ZipArchiveEntry*/ entry, /*ref long*/ completeRewriteStartingOffset)
            {
                if ((entry.Changes & (2/*ChangeState.DynamicLengthMetadata*/ | 4/*ChangeState.StoredData*/)) !== 0)
                {
                    completeRewriteStartingOffset.$v = $.$spc.System.Math.Min$5(completeRewriteStartingOffset.$v, entry.OffsetOfLocalHeader);
                }
            }
            /*void */ WriteFileUpdateModeFinalWork(/*long*/ startingOffset, /*long*/ nextFileOffset)
            {
                if (startingOffset === 9223372036854775807n)
                {
                    startingOffset = nextFileOffset;
                }
                this._archiveStream.Seek(startingOffset, 0/*SeekOrigin.Begin*/);
            }
            /*void */ WriteFileFinalWork()
            {
                if (this._mode === 2/*ZipArchiveMode.Update*/ && this._archiveStream.Position !== this._archiveStream.Length)
                {
                    this._archiveStream.SetLength(this._archiveStream.Position);
                }
            }
            /*void */ WriteFile()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._readEntries, "_readEntries");
                /*long*/ let completeRewriteStartingOffset = 0n;
                /*List<ZipArchiveEntry>*/ let entriesToWrite = this._entries;
                if (this._mode === 2/*ZipArchiveMode.Update*/)
                {
                    /*long*/ let startingOffset = this._firstDeletedEntryOffset;
                    /*long*/ let nextFileOffset = 0n;
                    completeRewriteStartingOffset = startingOffset;
                    entriesToWrite = new ($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor$2(this._entries.Count);
                    var $en3 = this._entries.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            if (!entry.OriginallyInArchive)
                            {
                                entriesToWrite.Add(entry);
                            }
                            else 
                            {
                                $.$sic.System.IO.Compression.ZipArchive.WriteFileCalculateOffsets(entry, $.$ref(() => startingOffset, ($v) => startingOffset = $v, $.$spc.System.Int64), $.$ref(() => nextFileOffset, ($v) => nextFileOffset = $v, $.$spc.System.Int64));
                                if (entry.OffsetOfLocalHeader >= startingOffset)
                                {
                                    $.$sic.System.IO.Compression.ZipArchive.WriteFileCheckStartingOffset(entry, $.$ref(() => completeRewriteStartingOffset, ($v) => completeRewriteStartingOffset = $v, $.$spc.System.Int64));
                                    entry.LoadLocalHeaderExtraFieldIfNeeded();
                                    if (entry.OffsetOfLocalHeader >= completeRewriteStartingOffset)
                                    {
                                        entry.LoadCompressedBytesIfNeeded();
                                    }
                                    entriesToWrite.Add(entry);
                                }
                            }
                        }
                    }
                    this.WriteFileUpdateModeFinalWork(startingOffset, nextFileOffset);
                }
                var $en2 = entriesToWrite.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var entry = $en2.Current;
                    {
                        /*bool*/ let forceWriteLocalEntry = !entry.OriginallyInArchive || (entry.OriginallyInArchive && entry.OffsetOfLocalHeader >= completeRewriteStartingOffset);
                        entry.WriteAndFinishLocalEntry(forceWriteLocalEntry);
                    }
                }
                /*long*/ let plannedCentralDirectoryPosition = this._archiveStream.Position;
                /*bool*/ let archiveEpilogueRequiresUpdate = this._entries.Count === 0;
                var $en2 = this._entries.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var entry = $en2.Current;
                    {
                        /*bool*/ let centralDirectoryEntryRequiresUpdate = plannedCentralDirectoryPosition !== this._centralDirectoryStart || !entry.OriginallyInArchive || entry.OffsetOfLocalHeader >= completeRewriteStartingOffset;
                        entry.WriteCentralDirectoryFileHeader(centralDirectoryEntryRequiresUpdate);
                        archiveEpilogueRequiresUpdate = $.$spc.System.Boolean.op_BitwiseOr(archiveEpilogueRequiresUpdate, centralDirectoryEntryRequiresUpdate);
                    }
                }
                /*long*/ let sizeOfCentralDirectory = this._archiveStream.Position - plannedCentralDirectoryPosition;
                this.WriteArchiveEpilogue(plannedCentralDirectoryPosition, sizeOfCentralDirectory, archiveEpilogueRequiresUpdate);
                this.WriteFileFinalWork();
            }
            /*void */ WriteArchiveEpilogueNoCDChangesWork()
            {
                this._archiveStream.Seek(56n, 1/*SeekOrigin.Current*/);
                this._archiveStream.Seek(BigInt(20/*Zip64EndOfCentralDirectoryLocator.TotalSize*/), 1/*SeekOrigin.Current*/);
            }
            /*void */ WriteArchiveEpilogue(/*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory, /*bool*/ centralDirectoryChanged)
            {
                if (startOfCentralDirectory >= BigInt(4294967295/*uint.MaxValue*/) || sizeOfCentralDirectory >= BigInt(4294967295/*uint.MaxValue*/) || this._entries.Count >= 65535/*ZipHelper.Mask16Bit*/)
                {
                    /*long*/ let zip64EOCDRecordStart = this._archiveStream.Position;
                    if (centralDirectoryChanged)
                    {
                        $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.WriteBlock(this._archiveStream, BigInt(this._entries.Count), startOfCentralDirectory, sizeOfCentralDirectory);
                        $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.WriteBlock(this._archiveStream, zip64EOCDRecordStart);
                    }
                    else 
                    {
                        this.WriteArchiveEpilogueNoCDChangesWork();
                    }
                }
                if (centralDirectoryChanged || (this.Changed !== 0/*ChangeState.Unchanged*/))
                {
                    $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.WriteBlock(this._archiveStream, BigInt(this._entries.Count), startOfCentralDirectory, sizeOfCentralDirectory, this._archiveComment);
                }
                else 
                {
                    this._archiveStream.Seek(BigInt(22/*ZipEndOfCentralDirectoryBlock.TotalSize*/ + this._archiveComment.length), 1/*SeekOrigin.Current*/);
                }
            }
            static /*bool */ ValidateMode(/*ZipArchiveMode*/ mode, /*Stream*/ stream)
            {
                /*bool*/ let isReadModeAndUnseekable = false;
                switch(mode)
                {
                    case 1/*ZipArchiveMode.Create*/:
                    if (!stream.CanWrite)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$sic.System.SR.CreateModeCapabilities);
                    }
                    break;
                    case 0/*ZipArchiveMode.Read*/:
                    if (!stream.CanRead)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$sic.System.SR.ReadModeCapabilities);
                    }
                    if (!stream.CanSeek)
                    {
                        isReadModeAndUnseekable = true;
                    }
                    break;
                    case 2/*ZipArchiveMode.Update*/:
                    if (!stream.CanRead || !stream.CanWrite || !stream.CanSeek)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$sic.System.SR.UpdateModeCapabilities);
                    }
                    break;
                    default:
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("mode");
                }
                return isReadModeAndUnseekable;
            }
            static /*Stream */ DecideArchiveStream(/*ZipArchiveMode*/ mode, /*Stream*/ stream)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                return mode === 1/*ZipArchiveMode.Create*/ && !stream.CanSeek ? new $.$sic.System.IO.Compression.PositionPreservingWriteOnlyStreamWrapper().$ctor$3(stream) : stream;
            }
            static $_ChangeState;
            static get ChangeState()
            {
                let $cls = $.$sic.System.IO.Compression.ZipArchive;
                return $cls.$_ChangeState ??= $asm.$nstr("$sic.System.IO.Compression.ZipArchive.ChangeState", ($self) => class ChangeState extends $.$spc.System.Enum
                {
                    static Unchanged = 0;
                    static FixedLengthMetadata = 1;
                    static DynamicLengthMetadata = 2;
                    static StoredData = 4;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Unchanged": 0n,
                            "FixedLengthMetadata": 1n,
                            "DynamicLengthMetadata": 2n,
                            "StoredData": 4n
                        };
                    }
                    static $h = 2618770;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2618770,"n":"Unchanged","d":2618770,"h":4297586066,"f":33},{"t":2618770,"n":"FixedLengthMetadata","d":2618770,"h":8592553362,"f":33},{"t":2618770,"n":"DynamicLengthMetadata","d":2618770,"h":12887520658,"f":33},{"t":2618770,"n":"StoredData","d":2618770,"h":17182487954,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2618770,"h":21477455250,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":2553234,"h":2618770,"a":[{"t":47710209,"c":4342677505}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZipArchive.ChangeState`; }
                }, $cls, ($v) => $cls.$_ChangeState = $v);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose$1(...arguments);
            }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Changed = 0;
            }
            static $h = 2553234;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":141736474002,"f":1},"s":{"r":0,"d":0,"h":146031441298,"f":1},"n":"Comment","d":2553234,"h":137441506706,"f":1},{"p":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h,"g":{"r":0,"d":0,"h":154621375890,"f":1},"n":"Entries","d":2553234,"h":150326408594,"f":1},{"p":3077522,"g":{"r":0,"d":0,"h":163211310482,"f":1},"n":"Mode","d":2553234,"h":158916343186,"f":1},{"p":62193665,"g":{"r":0,"d":0,"h":193276081554,"f":8},"n":"ArchiveStream","d":2553234,"h":188981114258,"f":8},{"p":720897,"g":{"r":0,"d":0,"h":201866016146,"f":8},"n":"NumberOfThisDisk","d":2553234,"h":197571048850,"f":8},{"p":121831425,"g":{"r":0,"d":0,"h":210455950738,"f":8},"s":{"r":0,"d":0,"h":214750918034,"f":2},"n":"EntryNameAndCommentEncoding","d":2553234,"h":206160983442,"f":8},{"p":2618770,"g":{"r":0,"d":0,"h":227635819922,"f":8},"s":{"r":0,"d":0,"h":231930787218,"f":2},"n":"Changed","d":2553234,"h":223340852626,"f":8}],"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.ZipArchive).$h,"p":[{"n":"stream","p":62193665},{"n":"mode","p":3077522},{"n":"leaveOpen","p":262145},{"n":"entryNameEncoding","p":121831425},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CreateAsync","d":2553234,"h":4297520530,"f":4129},{"r":136118273,"n":"DisposeAsync","d":2553234,"h":8592487826,"f":4097},{"r":136118273,"n":"DisposeAsyncCore","d":2553234,"h":12887455122,"f":4228},{"r":133300225,"n":"CloseStreamsAsync","d":2553234,"h":17182422418,"f":4098},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"EnsureCentralDirectoryReadAsync","d":2553234,"h":21477389714,"f":4098},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReadCentralDirectoryAsync","d":2553234,"h":25772357010,"f":4098},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReadEndOfCentralDirectoryAsync","d":2553234,"h":30067324306,"f":4098},{"r":136118273,"p":[{"n":"eocd","p":3339666},{"n":"eocdStart","p":917505},{"n":"cancellationToken","p":125960193}],"n":"TryReadZip64EndOfCentralDirectoryAsync","d":2553234,"h":34362291602,"f":4098},{"r":136118273,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteFileAsync","d":2553234,"h":38657258898,"f":4098},{"r":136118273,"p":[{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505},{"n":"centralDirectoryChanged","p":262145},{"n":"cancellationToken","p":125960193}],"n":"WriteArchiveEpilogueAsync","d":2553234,"h":42952226194,"f":4098},{"r":2684306,"p":[{"n":"entryName","p":1310721}],"n":"CreateEntry","d":2553234,"h":167506277778,"f":1},{"r":2684306,"p":[{"n":"entryName","p":1310721},{"n":"compressionLevel","p":783762}],"n":"CreateEntry","o":"@$1","d":2553234,"h":171801245074,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":2553234,"h":176096212370,"f":132},{"r":65537,"n":"Dispose","o":"@$1","d":2553234,"h":180391179666,"f":1},{"r":2684306,"p":[{"n":"entryName","p":1310721}],"n":"GetEntry","d":2553234,"h":184686146962,"f":1},{"r":2684306,"p":[{"n":"entryName","p":1310721},{"n":"compressionLevel","p":$.$typeNullable($.$sic.System.IO.Compression.CompressionLevel).$h}],"n":"DoCreateEntry","d":2553234,"h":236225754514,"f":2},{"r":65537,"p":[{"n":"entry","p":2684306}],"n":"AcquireArchiveStream","d":2553234,"h":240520721810,"f":8},{"r":65537,"p":[{"n":"entry","p":2684306}],"n":"AddEntry","d":2553234,"h":244815689106,"f":2},{"r":65537,"p":[{"n":"entry","p":2684306}],"n":"DebugAssertIsStillArchiveStreamOwner","d":2553234,"h":249110656402,"f":8,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"entry","p":2684306}],"n":"ReleaseArchiveStream","d":2553234,"h":253405623698,"f":8},{"r":65537,"p":[{"n":"entry","p":2684306}],"n":"RemoveEntry","d":2553234,"h":257700590994,"f":8},{"r":65537,"n":"ThrowIfDisposed","d":2553234,"h":261995558290,"f":8},{"r":65537,"n":"CloseStreams","d":2553234,"h":266290525586,"f":2},{"r":65537,"n":"EnsureCentralDirectoryRead","d":2553234,"h":270585492882,"f":2},{"r":65537,"p":[{"n":"fileBuffer","p":0,"f":2},{"n":"numberOfEntries","p":917505,"f":2},{"n":"saveExtraFieldsAndComments","p":262145,"f":2},{"n":"continueReadingCentralDirectory","p":262145,"f":2},{"n":"bytesRead","p":655361,"f":2},{"n":"currPosition","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"ReadCentralDirectoryInitialize","d":2553234,"h":274880460178,"f":2},{"r":262145,"p":[{"n":"result","p":262145},{"n":"currentHeader","p":3143058},{"n":"bytesConsumed","p":655361},{"n":"continueReadingCentralDirectory","p":262145,"f":4},{"n":"numberOfEntries","p":917505,"f":4},{"n":"currPosition","p":655361,"f":4},{"n":"bytesRead","p":655361,"f":4}],"n":"ReadCentralDirectoryEndOfInnerLoopWork","d":2553234,"h":279175427474,"f":2},{"r":65537,"p":[{"n":"currPosition","p":655361,"f":4},{"n":"sizedFileBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"ReadCentralDirectoryEndOfOuterLoopWork","d":2553234,"h":283470394770,"f":2},{"r":65537,"p":[{"n":"numberOfEntries","p":917505}],"n":"ReadCentralDirectoryPostOuterLoopWork","d":2553234,"h":287765362066,"f":2},{"r":65537,"n":"ReadCentralDirectory","d":2553234,"h":292060329362,"f":2},{"r":65537,"p":[{"n":"eocd","p":3339666}],"n":"ReadEndOfCentralDirectoryInnerWork","d":2553234,"h":296355296658,"f":2},{"r":65537,"n":"ReadEndOfCentralDirectory","d":2553234,"h":300650263954,"f":2},{"r":65537,"p":[{"n":"locator","p":1963410}],"n":"TryReadZip64EndOfCentralDirectoryInnerInitialWork","d":2553234,"h":304945231250,"f":2},{"r":65537,"p":[{"n":"record","p":2160018}],"n":"TryReadZip64EndOfCentralDirectoryInnerFinalWork","d":2553234,"h":309240198546,"f":2},{"r":65537,"p":[{"n":"eocd","p":3339666},{"n":"eocdStart","p":917505}],"n":"TryReadZip64EndOfCentralDirectory","d":2553234,"h":313535165842,"f":2},{"r":65537,"p":[{"n":"entry","p":2684306},{"n":"startingOffset","p":917505,"f":4},{"n":"nextFileOffset","p":917505,"f":4}],"n":"WriteFileCalculateOffsets","d":2553234,"h":317830133138,"f":34},{"r":65537,"p":[{"n":"entry","p":2684306},{"n":"completeRewriteStartingOffset","p":917505,"f":4}],"n":"WriteFileCheckStartingOffset","d":2553234,"h":322125100434,"f":34},{"r":65537,"p":[{"n":"startingOffset","p":917505},{"n":"nextFileOffset","p":917505}],"n":"WriteFileUpdateModeFinalWork","d":2553234,"h":326420067730,"f":2},{"r":65537,"n":"WriteFileFinalWork","d":2553234,"h":330715035026,"f":2},{"r":65537,"n":"WriteFile","d":2553234,"h":335010002322,"f":2},{"r":65537,"n":"WriteArchiveEpilogueNoCDChangesWork","d":2553234,"h":339304969618,"f":2},{"r":65537,"p":[{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505},{"n":"centralDirectoryChanged","p":262145}],"n":"WriteArchiveEpilogue","d":2553234,"h":343599936914,"f":2},{"r":262145,"p":[{"n":"mode","p":3077522},{"n":"stream","p":62193665}],"n":"ValidateMode","d":2553234,"h":347894904210,"f":34},{"r":62193665,"p":[{"n":"mode","p":3077522},{"n":"stream","p":62193665}],"n":"DecideArchiveStream","d":2553234,"h":352189871506,"f":34}],"l":[{"t":62193665,"n":"_archiveStream","d":2553234,"h":47247193490,"f":2},{"t":2684306,"n":"_archiveStreamOwner","d":2553234,"h":51542160786,"f":2},{"t":3077522,"n":"_mode","d":2553234,"h":55837128082,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h,"n":"_entries","d":2553234,"h":60132095378,"f":2},{"t":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h,"n":"_entriesCollection","d":2553234,"h":64427062674,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sic.System.IO.Compression.ZipArchiveEntry).$h,"n":"_entriesDictionary","d":2553234,"h":68722029970,"f":2},{"t":262145,"n":"_readEntries","d":2553234,"h":73016997266,"f":2},{"t":262145,"n":"_leaveOpen","d":2553234,"h":77311964562,"f":2},{"t":917505,"n":"_centralDirectoryStart","d":2553234,"h":81606931858,"f":2},{"t":262145,"n":"_isDisposed","d":2553234,"h":85901899154,"f":2},{"t":720897,"n":"_numberOfThisDisk","d":2553234,"h":90196866450,"f":2},{"t":917505,"n":"_expectedNumberOfEntries","d":2553234,"h":94491833746,"f":2},{"t":62193665,"n":"_backingStream","d":2553234,"h":98786801042,"f":2},{"t":0,"n":"_archiveComment","d":2553234,"h":103081768338,"f":2},{"t":121831425,"n":"_entryNameAndCommentEncoding","d":2553234,"h":107376735634,"f":2},{"t":917505,"n":"_firstDeletedEntryOffset","d":2553234,"h":111671702930,"f":2}],"c":[{"p":[{"n":"stream","p":62193665}],"n":".ctor","o":"$ctor$1","d":2553234,"h":115966670226,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"mode","p":3077522}],"n":".ctor","o":"$ctor$2","d":2553234,"h":120261637522,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"mode","p":3077522},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":2553234,"h":124556604818,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"mode","p":3077522},{"n":"leaveOpen","p":262145},{"n":"entryNameEncoding","p":121831425}],"n":".ctor","o":"$ctor$4","d":2553234,"h":128851572114,"f":1},{"p":[{"n":"mode","p":3077522},{"n":"leaveOpen","p":262145},{"n":"entryNameEncoding","p":121831425},{"n":"backingStream","p":62193665},{"n":"archiveStream","p":62193665}],"n":".ctor","o":"$ctor$5","d":2553234,"h":133146539410,"f":2}],"i":[57540609,56950785],"j":[2618770],"h":2553234}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `ZipArchive`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.ZipLocalFileHeader", ($self) => class ZipLocalFileHeader extends $.$spc.System.ValueType
        {
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static Signature = 4;
                    /*int*/ static VersionNeededToExtract = 2;
                    /*int*/ static GeneralPurposeBitFlags = 2;
                    /*int*/ static CompressionMethod = 2;
                    /*int*/ static LastModified = 4;
                    /*int*/ static Crc32 = 4;
                    /*int*/ static CompressedSize = 4;
                    /*int*/ static UncompressedSize = 4;
                    /*int*/ static FilenameLength = 2;
                    /*int*/ static ExtraFieldLength = 2;
                    static $h = 3863954;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":3863954,"h":4298831250,"f":33},{"t":655361,"n":"VersionNeededToExtract","d":3863954,"h":8593798546,"f":33},{"t":655361,"n":"GeneralPurposeBitFlags","d":3863954,"h":12888765842,"f":33},{"t":655361,"n":"CompressionMethod","d":3863954,"h":17183733138,"f":33},{"t":655361,"n":"LastModified","d":3863954,"h":21478700434,"f":33},{"t":655361,"n":"Crc32","d":3863954,"h":25773667730,"f":33},{"t":655361,"n":"CompressedSize","d":3863954,"h":30068635026,"f":33},{"t":655361,"n":"UncompressedSize","d":3863954,"h":34363602322,"f":33},{"t":655361,"n":"FilenameLength","d":3863954,"h":38658569618,"f":33},{"t":655361,"n":"ExtraFieldLength","d":3863954,"h":42953536914,"f":33}],"d":3798418,"h":3863954}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_ZipDataDescriptor;
            static get ZipDataDescriptor()
            {
                let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader;
                return $cls.$_ZipDataDescriptor ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor", ($self) => class ZipDataDescriptor extends $.$spc.System.Object
                {
                    static $_FieldLengths;
                    static get FieldLengths()
                    {
                        let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor;
                        return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor.FieldLengths", ($self) => class FieldLengths
                        {
                            /*int*/ static Signature = 4;
                            /*int*/ static Crc32 = 4;
                            /*int*/ static CompressedSize = 4;
                            /*int*/ static UncompressedSize = 4;
                            static $h = 4257170;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":4257170,"h":4299224466,"f":33},{"t":655361,"n":"Crc32","d":4257170,"h":8594191762,"f":33},{"t":655361,"n":"CompressedSize","d":4257170,"h":12889159058,"f":33},{"t":655361,"n":"UncompressedSize","d":4257170,"h":17184126354,"f":33}],"d":4191634,"h":4257170}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor.FieldLengths`; }
                        }, $cls, ($v) => $cls.$_FieldLengths = $v);
                    }
                    static $_FieldLocations;
                    static get FieldLocations()
                    {
                        let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor;
                        return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor.FieldLocations", ($self) => class FieldLocations
                        {
                            /*int*/ static Signature = 0;
                            /*int*/ static Crc32 = 4;
                            /*int*/ static CompressedSize = 8;
                            /*int*/ static UncompressedSize = 12;
                            static $h = 4322706;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":4322706,"h":4299290002,"f":33},{"t":655361,"n":"Crc32","d":4322706,"h":8594257298,"f":33},{"t":655361,"n":"CompressedSize","d":4322706,"h":12889224594,"f":33},{"t":655361,"n":"UncompressedSize","d":4322706,"h":17184191890,"f":33}],"d":4191634,"h":4322706}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor.FieldLocations`; }
                        }, $cls, ($v) => $cls.$_FieldLocations = $v);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 4191634;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":4191634,"h":12889093522,"f":1}],"j":[4257170,4322706],"d":3798418,"h":4191634}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor`; }
                }, $cls, ($v) => $cls.$_ZipDataDescriptor = $v);
            }
            static $_Zip64DataDescriptor;
            static get Zip64DataDescriptor()
            {
                let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader;
                return $cls.$_Zip64DataDescriptor ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor", ($self) => class Zip64DataDescriptor extends $.$spc.System.Object
                {
                    static $_FieldLengths;
                    static get FieldLengths()
                    {
                        let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor;
                        return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor.FieldLengths", ($self) => class FieldLengths
                        {
                            /*int*/ static Signature = 4;
                            /*int*/ static Crc32 = 4;
                            /*int*/ static CompressedSize = 8;
                            /*int*/ static UncompressedSize = 8;
                            static $h = 4060562;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":4060562,"h":4299027858,"f":33},{"t":655361,"n":"Crc32","d":4060562,"h":8593995154,"f":33},{"t":655361,"n":"CompressedSize","d":4060562,"h":12888962450,"f":33},{"t":655361,"n":"UncompressedSize","d":4060562,"h":17183929746,"f":33}],"d":3995026,"h":4060562}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor.FieldLengths`; }
                        }, $cls, ($v) => $cls.$_FieldLengths = $v);
                    }
                    static $_FieldLocations;
                    static get FieldLocations()
                    {
                        let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor;
                        return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations", ($self) => class FieldLocations
                        {
                            /*int*/ static Signature = 0;
                            /*int*/ static Crc32 = 4;
                            /*int*/ static CompressedSize = 8;
                            /*int*/ static UncompressedSize = 16;
                            static $h = 4126098;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":4126098,"h":4299093394,"f":33},{"t":655361,"n":"Crc32","d":4126098,"h":8594060690,"f":33},{"t":655361,"n":"CompressedSize","d":4126098,"h":12889027986,"f":33},{"t":655361,"n":"UncompressedSize","d":4126098,"h":17183995282,"f":33}],"d":3995026,"h":4126098}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations`; }
                        }, $cls, ($v) => $cls.$_FieldLocations = $v);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 3995026;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":3995026,"h":12888896914,"f":1}],"j":[4060562,4126098],"d":3798418,"h":3995026}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor`; }
                }, $cls, ($v) => $cls.$_Zip64DataDescriptor = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Signature = 0;
                    /*int*/ static VersionNeededToExtract = 4;
                    /*int*/ static GeneralPurposeBitFlags = 6;
                    /*int*/ static CompressionMethod = 8;
                    /*int*/ static LastModified = 10;
                    /*int*/ static Crc32 = 14;
                    /*int*/ static CompressedSize = 18;
                    /*int*/ static UncompressedSize = 22;
                    /*int*/ static FilenameLength = 26;
                    /*int*/ static ExtraFieldLength = 28;
                    /*int*/ static DynamicData = 30;
                    static $h = 3929490;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":3929490,"h":4298896786,"f":33},{"t":655361,"n":"VersionNeededToExtract","d":3929490,"h":8593864082,"f":33},{"t":655361,"n":"GeneralPurposeBitFlags","d":3929490,"h":12888831378,"f":33},{"t":655361,"n":"CompressionMethod","d":3929490,"h":17183798674,"f":33},{"t":655361,"n":"LastModified","d":3929490,"h":21478765970,"f":33},{"t":655361,"n":"Crc32","d":3929490,"h":25773733266,"f":33},{"t":655361,"n":"CompressedSize","d":3929490,"h":30068700562,"f":33},{"t":655361,"n":"UncompressedSize","d":3929490,"h":34363667858,"f":33},{"t":655361,"n":"FilenameLength","d":3929490,"h":38658635154,"f":33},{"t":655361,"n":"ExtraFieldLength","d":3929490,"h":42953602450,"f":33},{"t":655361,"n":"DynamicData","d":3929490,"h":47248569746,"f":33}],"d":3798418,"h":3929490}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            static /*Task<(List<ZipGenericExtraField>, byte[] trailingData)> *//*async*/  GetExtraFieldsAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.ValueTuple$$$($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField), $.$typeArray($.$spc.System.Byte))), $.$spc.System.ValueTuple$$$($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField), $.$typeArray($.$spc.System.Byte)), async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let fixedHeaderBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [((2/*FieldLengths.FilenameLength*/ + 2/*FieldLengths.ExtraFieldLength*/) | 0)], null);
                    /*int*/ let relativeFilenameLengthLocation;
                    /*int*/ let relativeExtraFieldLengthLocation;
                    $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldsInitialize(stream, $.$ref(() => relativeFilenameLengthLocation, ($v) => relativeFilenameLengthLocation = $v, $.$spc.System.Int32), $.$ref(() => relativeExtraFieldLengthLocation, ($v) => relativeExtraFieldLengthLocation = $v, $.$spc.System.Int32));
                    await stream.ReadExactlyAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(fixedHeaderBuffer), cancellationToken).ConfigureAwait(false);
                    /*ushort*/ let filenameLength;
                    /*ushort*/ let extraFieldLength;
                    $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldsCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(fixedHeaderBuffer), relativeFilenameLengthLocation, relativeExtraFieldLengthLocation, $.$ref(() => filenameLength, ($v) => filenameLength = $v, $.$spc.System.UInt16), $.$ref(() => extraFieldLength, ($v) => extraFieldLength = $v, $.$spc.System.UInt16));
                    /*byte[]*/ let arrayPoolBuffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(extraFieldLength);
                    /*Memory<byte>*/ let extraFieldBuffer = $.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, arrayPoolBuffer, 0, extraFieldLength);
                    try
                    {
                        stream.Seek(BigInt(filenameLength), 1/*SeekOrigin.Current*/);
                        await stream.ReadExactlyAsync(extraFieldBuffer, cancellationToken).ConfigureAwait(false);
                        /*byte[]*/ let trailingData;
                        /*List<ZipGenericExtraField>*/ let list = $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldPostReadWork(extraFieldBuffer.Span, $.$ref(() => trailingData, ($v) => trailingData = $v, $.$typeArray($.$spc.System.Byte)));
                        return new ($.$spc.System.ValueTuple$$$($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField), $.$typeArray($.$spc.System.Byte)))().$ctor$2(list, trailingData);
                    }
                    finally
                    {
                        {
                            if (arrayPoolBuffer !== null)
                            {
                                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(arrayPoolBuffer, false);
                            }
                        }
                    }
                });
            }
            static /*Task<bool> *//*async*/  TrySkipBlockAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let blockBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [4/*FieldLengths.Signature*/], null);
                    /*long*/ let currPosition = stream.Position;
                    /*int*/ let bytesRead = await stream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(blockBytes), blockBytes.length, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    if (!$.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlockCore(stream, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockBytes), bytesRead, currPosition))
                    {
                        return false;
                    }
                    bytesRead = await stream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(blockBytes), blockBytes.length, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    return $.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlockFinalize(stream, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockBytes), bytesRead);
                });
            }
            static /*ReadOnlySpan<byte> */ get DataDescriptorSignatureConstantBytes()
            {
                return this.$cacheDataDescriptorSignatureConstantBytes ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 80, 75, 7, 8 ]);
            }
            static /*ReadOnlySpan<byte> */ get SignatureConstantBytes()
            {
                return this.$cacheSignatureConstantBytes ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 80, 75, 3, 4 ]);
            }
            /*int*/ static SizeOfLocalHeader = 30;
            static /*void */ GetExtraFieldsInitialize(/*Stream*/ stream, /*out int*/ relativeFilenameLengthLocation, /*out int*/ relativeExtraFieldLengthLocation)
            {
                relativeFilenameLengthLocation.$v = ((26/*FieldLocations.FilenameLength*/ - 26/*FieldLocations.FilenameLength*/) | 0);
                relativeExtraFieldLengthLocation.$v = ((28/*FieldLocations.ExtraFieldLength*/ - 26/*FieldLocations.FilenameLength*/) | 0);
                stream.Seek(BigInt(26/*FieldLocations.FilenameLength*/), 1/*SeekOrigin.Current*/);
            }
            static /*void */ GetExtraFieldsCore(/*Span<byte>*/ fixedHeaderBuffer, /*int*/ relativeFilenameLengthLocation, /*int*/ relativeExtraFieldLengthLocation, /*out ushort*/ filenameLength, /*out ushort*/ extraFieldLength)
            {
                let $t1 = fixedHeaderBuffer;
                filenameLength.$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t1.Slice$1(relativeFilenameLengthLocation, $t1.Length - relativeFilenameLengthLocation)));
                let $t2 = fixedHeaderBuffer;
                extraFieldLength.$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t2.Slice$1(relativeExtraFieldLengthLocation, $t2.Length - relativeExtraFieldLengthLocation)));
            }
            static /*List<ZipGenericExtraField> */ GetExtraFieldPostReadWork(/*Span<byte>*/ extraFieldBuffer, /*out byte[]*/ trailingData)
            {
                /*ReadOnlySpan<byte>*/ let trailingDataSpan;
                /*List<ZipGenericExtraField>*/ let list = $.$sic.System.IO.Compression.ZipGenericExtraField.ParseExtraField($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(extraFieldBuffer), $.$ref(() => trailingDataSpan, ($v) => trailingDataSpan = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)));
                $.$sic.System.IO.Compression.Zip64ExtraField.RemoveZip64Blocks(list);
                trailingData.$v = trailingDataSpan.ToArray();
                return list;
            }
            static /*List<ZipGenericExtraField> */ GetExtraFields(/*Stream*/ stream, /*out byte[]*/ trailingData)
            {
                /*Span<byte>*/ let fixedHeaderBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, ((2/*FieldLengths.FilenameLength*/ + 2/*FieldLengths.ExtraFieldLength*/) | 0), null);
                /*int*/ let relativeFilenameLengthLocation;
                /*int*/ let relativeExtraFieldLengthLocation;
                $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldsInitialize(stream, $.$ref(() => relativeFilenameLengthLocation, ($v) => relativeFilenameLengthLocation = $v, $.$spc.System.Int32), $.$ref(() => relativeExtraFieldLengthLocation, ($v) => relativeExtraFieldLengthLocation = $v, $.$spc.System.Int32));
                stream.ReadExactly(fixedHeaderBuffer);
                /*ushort*/ let filenameLength;
                /*ushort*/ let extraFieldLength;
                $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldsCore(fixedHeaderBuffer, relativeFilenameLengthLocation, relativeExtraFieldLengthLocation, $.$ref(() => filenameLength, ($v) => filenameLength = $v, $.$spc.System.UInt16), $.$ref(() => extraFieldLength, ($v) => extraFieldLength = $v, $.$spc.System.UInt16));
                /*int*/ let StackAllocationThreshold = 512;
                /*byte[]?*/ let arrayPoolBuffer = extraFieldLength > StackAllocationThreshold ? $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(extraFieldLength) : null;
                /*Span<byte>*/ let extraFieldBuffer = extraFieldLength <= StackAllocationThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, StackAllocationThreshold, null).Slice$1(0, extraFieldLength) : $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, arrayPoolBuffer, 0, extraFieldLength);
                try
                {
                    stream.Seek(BigInt(filenameLength), 1/*SeekOrigin.Current*/);
                    stream.ReadExactly(extraFieldBuffer);
                    return $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldPostReadWork(extraFieldBuffer, trailingData);
                }
                finally
                {
                    {
                        if (arrayPoolBuffer !== null)
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(arrayPoolBuffer, false);
                        }
                    }
                }
            }
            static /*bool */ TrySkipBlockCore(/*Stream*/ stream, /*Span<byte>*/ blockBytes, /*int*/ bytesRead, /*long*/ currPosition)
            {
                if (bytesRead !== 4/*FieldLengths.Signature*/ || !$.$spc.System.MemoryExtensions.SequenceEqual$1($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockBytes), $.$sic.System.IO.Compression.ZipLocalFileHeader.SignatureConstantBytes))
                {
                    return false;
                }
                if (stream.Length < currPosition + BigInt(26/*FieldLocations.FilenameLength*/))
                {
                    return false;
                }
                stream.Seek(BigInt(26/*FieldLocations.FilenameLength*/ - 4/*FieldLengths.Signature*/), 1/*SeekOrigin.Current*/);
                $.$spc.System.Diagnostics.Debug.Assert$1(blockBytes.Length === ((2/*FieldLengths.FilenameLength*/ + 2/*FieldLengths.ExtraFieldLength*/) | 0), "blockBytes.Length == FieldLengths.FilenameLength + FieldLengths.ExtraFieldLength");
                return true;
            }
            static /*bool */ TrySkipBlockFinalize(/*Stream*/ stream, /*Span<byte>*/ blockBytes, /*int*/ bytesRead)
            {
                if (bytesRead !== ((2/*FieldLengths.FilenameLength*/ + 2/*FieldLengths.ExtraFieldLength*/) | 0))
                {
                    return false;
                }
                /*int*/ let relativeFilenameLengthLocation = ((26/*FieldLocations.FilenameLength*/ - 26/*FieldLocations.FilenameLength*/) | 0);
                /*int*/ let relativeExtraFieldLengthLocation = ((28/*FieldLocations.ExtraFieldLength*/ - 26/*FieldLocations.FilenameLength*/) | 0);
                let $t1 = blockBytes;
                /*ushort*/ let filenameLength = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t1.Slice$1(relativeFilenameLengthLocation, $t1.Length - relativeFilenameLengthLocation)));
                let $t2 = blockBytes;
                /*ushort*/ let extraFieldLength = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t2.Slice$1(relativeExtraFieldLengthLocation, $t2.Length - relativeExtraFieldLengthLocation)));
                if (stream.Length < stream.Position + BigInt(filenameLength) + BigInt(extraFieldLength))
                {
                    return false;
                }
                stream.Seek(BigInt(filenameLength + extraFieldLength), 1/*SeekOrigin.Current*/);
                return true;
            }
            static /*bool */ TrySkipBlock(/*Stream*/ stream)
            {
                /*Span<byte>*/ let blockBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 4/*FieldLengths.Signature*/, null);
                /*long*/ let currPosition = stream.Position;
                /*int*/ let bytesRead = stream.ReadAtLeast(blockBytes, blockBytes.Length, false);
                if (!$.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlockCore(stream, blockBytes, bytesRead, currPosition))
                {
                    return false;
                }
                bytesRead = stream.ReadAtLeast(blockBytes, blockBytes.Length, false);
                return $.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlockFinalize(stream, blockBytes, bytesRead);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 3798418;
            static $z = 0;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":34363536786,"f":33},"n":"DataDescriptorSignatureConstantBytes","d":3798418,"h":30068569490,"f":33},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":42953471378,"f":33},"n":"SignatureConstantBytes","d":3798418,"h":38658504082,"f":33}],"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.ValueTuple$$$($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField), $.$typeArray($.$spc.System.Byte))).$h,"p":[{"n":"stream","p":62193665},{"n":"cancellationToken","p":125960193}],"n":"GetExtraFieldsAsync","d":3798418,"h":21478634898,"f":4129},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean).$h,"p":[{"n":"stream","p":62193665},{"n":"cancellationToken","p":125960193}],"n":"TrySkipBlockAsync","d":3798418,"h":25773602194,"f":4129},{"r":65537,"p":[{"n":"stream","p":62193665},{"n":"relativeFilenameLengthLocation","p":655361,"f":2},{"n":"relativeExtraFieldLengthLocation","p":655361,"f":2}],"n":"GetExtraFieldsInitialize","d":3798418,"h":51543405970,"f":34},{"r":65537,"p":[{"n":"fixedHeaderBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"relativeFilenameLengthLocation","p":655361},{"n":"relativeExtraFieldLengthLocation","p":655361},{"n":"filenameLength","p":589825,"f":2},{"n":"extraFieldLength","p":589825,"f":2}],"n":"GetExtraFieldsCore","d":3798418,"h":55838373266,"f":34},{"r":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h,"p":[{"n":"extraFieldBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"trailingData","p":0,"f":2}],"n":"GetExtraFieldPostReadWork","d":3798418,"h":60133340562,"f":34},{"r":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h,"p":[{"n":"stream","p":62193665},{"n":"trailingData","p":0,"f":2}],"n":"GetExtraFields","d":3798418,"h":64428307858,"f":33},{"r":262145,"p":[{"n":"stream","p":62193665},{"n":"blockBytes","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesRead","p":655361},{"n":"currPosition","p":917505}],"n":"TrySkipBlockCore","d":3798418,"h":68723275154,"f":34},{"r":262145,"p":[{"n":"stream","p":62193665},{"n":"blockBytes","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesRead","p":655361}],"n":"TrySkipBlockFinalize","d":3798418,"h":73018242450,"f":34},{"r":262145,"p":[{"n":"stream","p":62193665}],"n":"TrySkipBlock","d":3798418,"h":77313209746,"f":33}],"l":[{"t":655361,"n":"SizeOfLocalHeader","d":3798418,"h":47248438674,"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":3798418,"h":81608177042,"f":1}],"j":[3863954,4191634,3995026,3929490],"h":3798418}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.DeflateManagedStream", ($self) => class DeflateManagedStream extends $.$spc.System.IO.Stream
        {
            /*int*/ static DefaultBufferSize = 8192;
            /*Stream?*/ _stream = null;
            /*InflaterManaged*/ _inflater = null;
            /*byte[]*/ _buffer = null;
            /*int*/ _asyncOperations = 0;
            $ctor$3(/*Stream*/ stream, /*ZipArchiveEntry.CompressionMethodValues*/ method, /*long*/ uncompressedSize)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                    if (!stream.CanRead)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sic.System.SR.NotSupported_UnreadableStream, "stream");
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(method === 9/*ZipArchiveEntry.CompressionMethodValues.Deflate64*/, "method == ZipArchiveEntry.CompressionMethodValues.Deflate64");
                    this._inflater = new $.$sic.System.IO.Compression.InflaterManaged().$ctor$1(method === 9/*ZipArchiveEntry.CompressionMethodValues.Deflate64*/, uncompressedSize);
                    this._stream = stream;
                    this._buffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [8192/*DefaultBufferSize*/], null);
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                if (this._stream === null)
                {
                    return false;
                }
                return this._stream.CanRead;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ Flush()
            {
                this.EnsureNotDisposed();
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                this.EnsureNotDisposed();
                return cancellationToken.IsCancellationRequested ? $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken) : $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.Read$1(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count));
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                this.EnsureNotDisposed();
                /*int*/ let initialLength = buffer.Length;
                /*int*/ let bytesRead;
                while(true)
                {
                    bytesRead = this._inflater.Inflate(buffer);
                    buffer = buffer.Slice(bytesRead);
                    if (buffer.Length === 0)
                    {
                        break;
                    }
                    if (this._inflater.Finished())
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._inflater.AvailableOutput === 0, "We should have copied all stuff out!");
                        break;
                    }
                    /*int*/ let bytes = this._stream.Read(this._buffer, 0, this._buffer.length);
                    if (bytes <= 0)
                    {
                        break;
                    }
                    else if (bytes > this._buffer.length)
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData);
                    }
                    this._inflater.SetInput$1(this._buffer, 0, bytes);
                }
                return ((initialLength - buffer.Length) | 0);
            }
            /*int */ ReadByte()
            {
                /*byte*/ let b = 0;
                return this.Read$1(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$5($.$ref(() => b, ($v) => b = $v, $.$spc.System.Byte))) === 1 ? b : -1;
            }
            /*void */ EnsureNotDisposed()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._stream === null, this);
            }
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.ReadAsync$1(buffer, offset, count, $.$spc.System.Threading.CancellationToken.None), asyncCallback, asyncState);
            }
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.End$1($.$spc.System.Int32, asyncResult);
            }
            /*ValueTask<int> */ ReadAsyncInternal(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.ValueTask.FromCanceled$1($.$spc.System.Int32, cancellationToken);
                }
                $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._asyncOperations, ($v) => this._asyncOperations = $v, $.$spc.System.Int32));
                /*bool*/ let startedAsyncWork = false;
                try
                {
                    /*int*/ let bytesRead = this._inflater.Inflate(buffer.Span);
                    if (bytesRead !== 0)
                    {
                        return $.$spc.System.Threading.Tasks.ValueTask.FromResult($.$spc.System.Int32, bytesRead);
                    }
                    if (this._inflater.Finished())
                    {
                        return $.$spc.System.Threading.Tasks.ValueTask.FromResult($.$spc.System.Int32, 0);
                    }
                    /*ValueTask<int>*/ let readTask = this._stream.ReadAsync$2($.$spc.System.MemoryExtensions.AsMemory$5($.$spc.System.Byte, this._buffer), cancellationToken);
                    startedAsyncWork = true;
                    return this.ReadAsyncCore(readTask, buffer, cancellationToken);
                }
                finally
                {
                    {
                        if (!startedAsyncWork)
                        {
                            $.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._asyncOperations, ($v) => this._asyncOperations = $v, $.$spc.System.Int32));
                        }
                    }
                }
            }
            /*ValueTask<int> *//*async*/  ReadAsyncCore(/*ValueTask<int>*/ readTask, /*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                {
                    try
                    {
                        while(true)
                        {
                            /*int*/ let bytesRead = await readTask.ConfigureAwait(false);
                            this.EnsureNotDisposed();
                            if (bytesRead <= 0)
                            {
                                return 0;
                            }
                            else if (bytesRead > this._buffer.length)
                            {
                                throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData);
                            }
                            cancellationToken.ThrowIfCancellationRequested();
                            this._inflater.SetInput$1(this._buffer, 0, bytesRead);
                            bytesRead = this._inflater.Inflate(buffer.Span);
                            if (bytesRead === 0 && !this._inflater.Finished())
                            {
                                readTask = this._stream.ReadAsync$2($.$spc.System.MemoryExtensions.AsMemory$5($.$spc.System.Byte, this._buffer), cancellationToken);
                            }
                            else 
                            {
                                return bytesRead;
                            }
                        }
                    }
                    finally
                    {
                        {
                            $.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._asyncOperations, ($v) => this._asyncOperations = $v, $.$spc.System.Int32));
                        }
                    }
                });
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                if (this._asyncOperations !== 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.InvalidBeginCall);
                }
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                this.EnsureNotDisposed();
                return this.ReadAsyncInternal($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                if (this._asyncOperations !== 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.InvalidBeginCall);
                }
                this.EnsureNotDisposed();
                return this.ReadAsyncInternal(buffer, cancellationToken);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.CannotWriteToDeflateStream);
            }
            /*void */ PurgeBuffers(/*bool*/ disposing)
            {
                if (!disposing)
                {
                    return;
                }
                if (this._stream === null)
                {
                    return;
                }
                this.Flush();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    this.PurgeBuffers(disposing);
                }
                finally
                {
                    {
                        try
                        {
                            if (disposing && this._stream !== null)
                            {
                                this._stream.Dispose();
                            }
                        }
                        finally
                        {
                            {
                                this._stream = null;
                                this._inflater = null;
                                super.Dispose$1(disposing);
                            }
                        }
                    }
                }
            }
            static $h = 980370;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360718738,"f":32769},"n":"CanRead","d":980370,"h":30065751442,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950653330,"f":32769},"n":"CanWrite","d":980370,"h":38655686034,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51540587922,"f":32769},"n":"CanSeek","d":980370,"h":47245620626,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":60130522514,"f":32769},"n":"Length","d":980370,"h":55835555218,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68720457106,"f":32769},"s":{"r":0,"d":0,"h":73015424402,"f":32769},"n":"Position","d":980370,"h":64425489810,"f":32769}],"m":[{"r":65537,"n":"Flush","d":980370,"h":77310391698,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":980370,"h":81605358994,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":980370,"h":85900326290,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":980370,"h":90195293586,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":980370,"h":94490260882,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":980370,"h":98785228178,"f":32769},{"r":655361,"n":"ReadByte","d":980370,"h":103080195474,"f":32769},{"r":65537,"n":"EnsureNotDisposed","d":980370,"h":107375162770,"f":2},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginRead","d":980370,"h":111670130066,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":980370,"h":115965097362,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadAsyncInternal","d":980370,"h":120260064658,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"readTask","p":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h},{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadAsyncCore","d":980370,"h":124555031954,"f":4098},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":980370,"h":128849999250,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":980370,"h":133144966546,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":980370,"h":137439933842,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"PurgeBuffers","d":980370,"h":141734901138,"f":2},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":980370,"h":146029868434,"f":32772}],"l":[{"t":655361,"n":"DefaultBufferSize","d":980370,"h":4295947666,"f":40},{"t":62193665,"n":"_stream","d":980370,"h":8590914962,"f":2},{"t":1439122,"n":"_inflater","d":980370,"h":12885882258,"f":2},{"t":0,"n":"_buffer","d":980370,"h":17180849554,"f":2},{"t":655361,"n":"_asyncOperations","d":980370,"h":21475816850,"f":2}],"c":[{"p":[{"n":"stream","p":62193665},{"n":"method","p":2815378},{"n":"uncompressedSize","p":917505,"f":65,"v":-1}],"n":".ctor","o":"$ctor$3","d":980370,"h":25770784146,"f":8}],"i":[57540609,56950785],"h":980370}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.DeflateManagedStream`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.GZipStream", ($self) => class GZipStream extends $.$spc.System.IO.Stream
        {
            /*DeflateStream*/ _deflateStream = null;
            $ctor$3(/*Stream*/ stream, /*CompressionMode*/ mode)
            {
                this.$ctor$4(stream, mode, false);
                {
                }
                return this;
            }
            $ctor$4(/*Stream*/ stream, /*CompressionMode*/ mode, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    this._deflateStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$10(stream, mode, leaveOpen, 31/*ZLibNative.GZip_DefaultWindowBits*/, -1n);
                }
                return this;
            }
            $ctor$5(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel)
            {
                this.$ctor$6(stream, compressionLevel, false);
                {
                }
                return this;
            }
            $ctor$6(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    this._deflateStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$11(stream, compressionLevel, leaveOpen, 31/*ZLibNative.GZip_DefaultWindowBits*/);
                }
                return this;
            }
            $ctor$7(/*Stream*/ stream, /*ZLibCompressionOptions*/ compressionOptions, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    this._deflateStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$9(stream, compressionOptions, leaveOpen, 31/*ZLibNative.GZip_DefaultWindowBits*/);
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                return (this._deflateStream?.CanRead ?? null) ?? false;
            }
            /*bool */ get CanWrite()
            {
                return (this._deflateStream?.CanWrite ?? null) ?? false;
            }
            /*bool */ get CanSeek()
            {
                return (this._deflateStream?.CanSeek ?? null) ?? false;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ Flush()
            {
                this.CheckDeflateStream();
                this._deflateStream.Flush();
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*int */ ReadByte()
            {
                this.CheckDeflateStream();
                return this._deflateStream.ReadByte();
            }
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.ReadAsync$1(buffer, offset, count, $.$spc.System.Threading.CancellationToken.None), asyncCallback, asyncState);
            }
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                return this._deflateStream.EndRead(asyncResult);
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.CheckDeflateStream();
                return this._deflateStream.Read(buffer, offset, count);
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.GZipStream.$type))
                {
                    return super.Read$1(buffer);
                }
                else 
                {
                    this.CheckDeflateStream();
                    return this._deflateStream.ReadCore(buffer);
                }
            }
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.WriteAsync$1(buffer, offset, count, $.$spc.System.Threading.CancellationToken.None), asyncCallback, asyncState);
            }
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                return this._deflateStream.EndWrite(asyncResult);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.CheckDeflateStream();
                this._deflateStream.Write(buffer, offset, count);
            }
            /*void */ WriteByte(/*byte*/ value)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.GZipStream.$type))
                {
                    super.WriteByte(value);
                }
                else 
                {
                    this.CheckDeflateStream();
                    this._deflateStream.WriteCore(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$5($.$ref(() => value, undefined, $.$spc.System.Byte)));
                }
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.GZipStream.$type))
                {
                    super.Write$1(buffer);
                }
                else 
                {
                    this.CheckDeflateStream();
                    this._deflateStream.WriteCore(buffer);
                }
            }
            /*void */ CopyTo$1(/*Stream*/ destination, /*int*/ bufferSize)
            {
                this.CheckDeflateStream();
                this._deflateStream.CopyTo$1(destination, bufferSize);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    if (disposing && this._deflateStream !== null)
                    {
                        this._deflateStream.Dispose();
                    }
                    this._deflateStream = null;
                }
                finally
                {
                    {
                        super.Dispose$1(disposing);
                    }
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.GZipStream.$type))
                {
                    return super.DisposeAsync();
                }
                /*DeflateStream?*/ let ds = this._deflateStream;
                if (ds !== null)
                {
                    this._deflateStream = null;
                    return ds.DisposeAsync();
                }
                return new $.$spc.System.Threading.Tasks.ValueTask();
            }
            /*Stream */ get BaseStream()
            {
                return (this._deflateStream?.BaseStream ?? null);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.CheckDeflateStream();
                return this._deflateStream.ReadAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.GZipStream.$type))
                {
                    return super.ReadAsync$2(buffer, cancellationToken);
                }
                else 
                {
                    this.CheckDeflateStream();
                    return this._deflateStream.ReadAsyncMemory(buffer, cancellationToken);
                }
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.CheckDeflateStream();
                return this._deflateStream.WriteAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.GZipStream.$type))
                {
                    return super.WriteAsync$2(buffer, cancellationToken);
                }
                else 
                {
                    this.CheckDeflateStream();
                    return this._deflateStream.WriteAsyncMemory(buffer, cancellationToken);
                }
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                this.CheckDeflateStream();
                return this._deflateStream.FlushAsync$1(cancellationToken);
            }
            /*Task */ CopyToAsync$3(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                this.CheckDeflateStream();
                return this._deflateStream.CopyToAsync$3(destination, bufferSize, cancellationToken);
            }
            /*void */ CheckDeflateStream()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._deflateStream === null, this);
            }
            static $h = 1242514;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360980882,"f":32769},"n":"CanRead","d":1242514,"h":30066013586,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950915474,"f":32769},"n":"CanWrite","d":1242514,"h":38655948178,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51540850066,"f":32769},"n":"CanSeek","d":1242514,"h":47245882770,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":60130784658,"f":32769},"n":"Length","d":1242514,"h":55835817362,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68720719250,"f":32769},"s":{"r":0,"d":0,"h":73015686546,"f":32769},"n":"Position","d":1242514,"h":64425751954,"f":32769},{"p":62193665,"g":{"r":0,"d":0,"h":150325097874,"f":1},"n":"BaseStream","d":1242514,"h":146030130578,"f":1}],"m":[{"r":65537,"n":"Flush","d":1242514,"h":77310653842,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1242514,"h":81605621138,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1242514,"h":85900588434,"f":32769},{"r":655361,"n":"ReadByte","d":1242514,"h":90195555730,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginRead","d":1242514,"h":94490523026,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":1242514,"h":98785490322,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1242514,"h":103080457618,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1242514,"h":107375424914,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":1242514,"h":111670392210,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":1242514,"h":115965359506,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1242514,"h":120260326802,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1242514,"h":124555294098,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1242514,"h":128850261394,"f":32769},{"r":65537,"p":[{"n":"destination","p":62193665},{"n":"bufferSize","p":655361}],"n":"CopyTo","o":"@$1","d":1242514,"h":133145228690,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1242514,"h":137440195986,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1242514,"h":141735163282,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1242514,"h":154620065170,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1242514,"h":158915032466,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1242514,"h":163209999762,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1242514,"h":167504967058,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1242514,"h":171799934354,"f":32769},{"r":133300225,"p":[{"n":"destination","p":62193665},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"CopyToAsync","o":"@$3","d":1242514,"h":176094901650,"f":32769},{"r":65537,"n":"CheckDeflateStream","d":1242514,"h":180389868946,"f":2}],"l":[{"t":1111442,"n":"_deflateStream","d":1242514,"h":4296209810,"f":2}],"c":[{"p":[{"n":"stream","p":62193665},{"n":"mode","p":849298}],"n":".ctor","o":"$ctor$3","d":1242514,"h":8591177106,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"mode","p":849298},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$4","d":1242514,"h":12886144402,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"compressionLevel","p":783762}],"n":".ctor","o":"$ctor$5","d":1242514,"h":17181111698,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"compressionLevel","p":783762},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$6","d":1242514,"h":21476078994,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"compressionOptions","p":4519314},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$7","d":1242514,"h":25771046290,"f":1}],"i":[57540609,56950785],"h":1242514}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.GZipStream`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.PositionPreservingWriteOnlyStreamWrapper", ($self) => class PositionPreservingWriteOnlyStreamWrapper extends $.$spc.System.IO.Stream
        {
            /*Stream*/ _stream = null;
            /*long*/ _position = 0n;
            $ctor$3(/*Stream*/ stream)
            {
                super.$ctor$2();
                {
                    this._stream = stream;
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                return false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return true;
            }
            /*long */ get Position()
            {
                return this._position;
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this._position += BigInt(count);
                this._stream.Write(buffer, offset, count);
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
            {
                this._position += BigInt(buffer.Length);
                this._stream.Write$1(buffer);
            }
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                this._position += BigInt(count);
                return this._stream.BeginWrite(buffer, offset, count, callback, state);
            }
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                return this._stream.EndWrite(asyncResult);
            }
            /*void */ WriteByte(/*byte*/ value)
            {
                this._position += 1n;
                this._stream.WriteByte(value);
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this._position += BigInt(count);
                return this._stream.WriteAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this._position += BigInt(buffer.Length);
                return this._stream.WriteAsync$2(buffer, cancellationToken);
            }
            /*bool */ get CanTimeout()
            {
                return this._stream.CanTimeout;
            }
            /*int */ get ReadTimeout()
            {
                return this._stream.ReadTimeout;
            }
            /*int */ set ReadTimeout(value)
            {
                this._stream.ReadTimeout = value;
            }
            /*int */ get WriteTimeout()
            {
                return this._stream.WriteTimeout;
            }
            /*int */ set WriteTimeout(value)
            {
                this._stream.WriteTimeout = value;
            }
            /*void */ Flush()
            {
                return this._stream.Flush();
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                return this._stream.FlushAsync$1(cancellationToken);
            }
            /*void */ Close()
            {
                this._stream.Close();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    this._stream.Dispose();
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                return this._stream.DisposeAsync();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            static $h = 1766802;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476603282,"f":32769},"n":"CanRead","d":1766802,"h":17181635986,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":30066537874,"f":32769},"n":"CanSeek","d":1766802,"h":25771570578,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38656472466,"f":32769},"n":"CanWrite","d":1766802,"h":34361505170,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":47246407058,"f":32769},"s":{"r":0,"d":0,"h":51541374354,"f":32769},"n":"Position","d":1766802,"h":42951439762,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":90196080018,"f":32769},"n":"CanTimeout","d":1766802,"h":85901112722,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":98786014610,"f":32769},"s":{"r":0,"d":0,"h":103080981906,"f":32769},"n":"ReadTimeout","d":1766802,"h":94491047314,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":111670916498,"f":32769},"s":{"r":0,"d":0,"h":115965883794,"f":32769},"n":"WriteTimeout","d":1766802,"h":107375949202,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":146030654866,"f":32769},"n":"Length","d":1766802,"h":141735687570,"f":32769}],"m":[{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1766802,"h":55836341650,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1766802,"h":60131308946,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginWrite","d":1766802,"h":64426276242,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":1766802,"h":68721243538,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1766802,"h":73016210834,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1766802,"h":77311178130,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1766802,"h":81606145426,"f":32769},{"r":65537,"n":"Flush","d":1766802,"h":120260851090,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1766802,"h":124555818386,"f":32769},{"r":65537,"n":"Close","d":1766802,"h":128850785682,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1766802,"h":133145752978,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1766802,"h":137440720274,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1766802,"h":150325622162,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1766802,"h":154620589458,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1766802,"h":158915556754,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1766802,"h":163210524050,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1766802,"h":167505491346,"f":32769}],"l":[{"t":62193665,"n":"_stream","d":1766802,"h":4296734098,"f":2},{"t":917505,"n":"_position","d":1766802,"h":8591701394,"f":2}],"c":[{"p":[{"n":"stream","p":62193665}],"n":".ctor","o":"$ctor$3","d":1766802,"h":12886668690,"f":1}],"i":[57540609,56950785],"h":1766802}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.PositionPreservingWriteOnlyStreamWrapper`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.WrappedStream", ($self) => class WrappedStream extends $.$spc.System.IO.Stream
        {
            /*Stream*/ _baseStream = null;
            /*bool*/ _closeBaseStream = false;
            /*Action<ZipArchiveEntry?>?*/ _onClosed = null;
            /*ZipArchiveEntry?*/ _zipArchiveEntry = null;
            /*bool*/ _isDisposed = false;
            $ctor$3(/*Stream*/ baseStream, /*bool*/ closeBaseStream)
            {
                this.$ctor$4(baseStream, closeBaseStream, null, null);
                {
                }
                return this;
            }
            $ctor$4(/*Stream*/ baseStream, /*bool*/ closeBaseStream, /*ZipArchiveEntry?*/ entry, /*Action<ZipArchiveEntry?>?*/ onClosed)
            {
                super.$ctor$2();
                {
                    this._baseStream = baseStream;
                    this._closeBaseStream = closeBaseStream;
                    this._onClosed = onClosed;
                    this._zipArchiveEntry = entry;
                    this._isDisposed = false;
                }
                return this;
            }
            $ctor$5(/*Stream*/ baseStream, /*ZipArchiveEntry*/ entry, /*Action<ZipArchiveEntry?>?*/ onClosed)
            {
                this.$ctor$4(baseStream, false, entry, onClosed);
                {
                }
                return this;
            }
            /*long */ get Length()
            {
                this.ThrowIfDisposed();
                return this._baseStream.Length;
            }
            /*long */ get Position()
            {
                this.ThrowIfDisposed();
                return this._baseStream.Position;
            }
            /*long */ set Position(value)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantSeek();
                this._baseStream.Position = value;
            }
            /*bool */ get CanRead()
            {
                return !this._isDisposed && this._baseStream.CanRead;
            }
            /*bool */ get CanSeek()
            {
                return !this._isDisposed && this._baseStream.CanSeek;
            }
            /*bool */ get CanWrite()
            {
                return !this._isDisposed && this._baseStream.CanWrite;
            }
            /*void */ ThrowIfDisposed()
            {
                if (this._isDisposed)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15($.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this)), $.$sic.System.SR.HiddenStreamName);
                }
            }
            /*void */ ThrowIfCantRead()
            {
                if (!this.CanRead)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
                }
            }
            /*void */ ThrowIfCantWrite()
            {
                if (!this.CanWrite)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.WritingNotSupported);
                }
            }
            /*void */ ThrowIfCantSeek()
            {
                if (!this.CanSeek)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
                }
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                return this._baseStream.Read(buffer, offset, count);
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                return this._baseStream.Read$1(buffer);
            }
            /*int */ ReadByte()
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                return this._baseStream.ReadByte();
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                return this._baseStream.ReadAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                return this._baseStream.ReadAsync$2(buffer, cancellationToken);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantSeek();
                return this._baseStream.Seek(offset, origin);
            }
            /*void */ SetLength(/*long*/ value)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantSeek();
                this.ThrowIfCantWrite();
                this._baseStream.SetLength(value);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                this._baseStream.Write(buffer, offset, count);
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ source)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                this._baseStream.Write$1(source);
            }
            /*void */ WriteByte(/*byte*/ value)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                this._baseStream.WriteByte(value);
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                return this._baseStream.WriteAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                return this._baseStream.WriteAsync$2(buffer, cancellationToken);
            }
            /*void */ Flush()
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                this._baseStream.Flush();
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                return this._baseStream.FlushAsync$1(cancellationToken);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing && !this._isDisposed)
                {
                    this._onClosed?.Invoke(this._zipArchiveEntry);
                    if (this._closeBaseStream)
                    {
                        this._baseStream.Dispose();
                    }
                    this._isDisposed = true;
                }
                super.Dispose$1(disposing);
            }
            static $h = 1897874;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":917505,"g":{"r":0,"d":0,"h":42951570834,"f":32769},"n":"Length","d":1897874,"h":38656603538,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":51541505426,"f":32769},"s":{"r":0,"d":0,"h":55836472722,"f":32769},"n":"Position","d":1897874,"h":47246538130,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":64426407314,"f":32769},"n":"CanRead","d":1897874,"h":60131440018,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":73016341906,"f":32769},"n":"CanSeek","d":1897874,"h":68721374610,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":81606276498,"f":32769},"n":"CanWrite","d":1897874,"h":77311309202,"f":32769}],"m":[{"r":65537,"n":"ThrowIfDisposed","d":1897874,"h":85901243794,"f":2},{"r":65537,"n":"ThrowIfCantRead","d":1897874,"h":90196211090,"f":2},{"r":65537,"n":"ThrowIfCantWrite","d":1897874,"h":94491178386,"f":2},{"r":65537,"n":"ThrowIfCantSeek","d":1897874,"h":98786145682,"f":2},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1897874,"h":103081112978,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1897874,"h":107376080274,"f":32769},{"r":655361,"n":"ReadByte","d":1897874,"h":111671047570,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1897874,"h":115966014866,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1897874,"h":120260982162,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1897874,"h":124555949458,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1897874,"h":128850916754,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1897874,"h":133145884050,"f":32769},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1897874,"h":137440851346,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1897874,"h":141735818642,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1897874,"h":146030785938,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1897874,"h":150325753234,"f":32769},{"r":65537,"n":"Flush","d":1897874,"h":154620720530,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1897874,"h":158915687826,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1897874,"h":163210655122,"f":32772}],"l":[{"t":62193665,"n":"_baseStream","d":1897874,"h":4296865170,"f":2},{"t":262145,"n":"_closeBaseStream","d":1897874,"h":8591832466,"f":2},{"t":$.$spc.System.Action$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h,"n":"_onClosed","d":1897874,"h":12886799762,"f":2},{"t":2684306,"n":"_zipArchiveEntry","d":1897874,"h":17181767058,"f":2},{"t":262145,"n":"_isDisposed","d":1897874,"h":21476734354,"f":2}],"c":[{"p":[{"n":"baseStream","p":62193665},{"n":"closeBaseStream","p":262145}],"n":".ctor","o":"$ctor$3","d":1897874,"h":25771701650,"f":8},{"p":[{"n":"baseStream","p":62193665},{"n":"closeBaseStream","p":262145},{"n":"entry","p":2684306},{"n":"onClosed","p":$.$spc.System.Action$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h}],"n":".ctor","o":"$ctor$4","d":1897874,"h":30066668946,"f":2},{"p":[{"n":"baseStream","p":62193665},{"n":"entry","p":2684306},{"n":"onClosed","p":$.$spc.System.Action$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h}],"n":".ctor","o":"$ctor$5","d":1897874,"h":34361636242,"f":8}],"i":[57540609,56950785],"h":1897874}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.WrappedStream`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.SubReadStream", ($self) => class SubReadStream extends $.$spc.System.IO.Stream
        {
            /*long*/ _startInSuperStream = 0n;
            /*long*/ _positionInSuperStream = 0n;
            /*long*/ _endInSuperStream = 0n;
            /*Stream*/ _superStream = null;
            /*bool*/ _canRead = false;
            /*bool*/ _isDisposed = false;
            $ctor$3(/*Stream*/ superStream, /*long*/ startPosition, /*long*/ maxLength)
            {
                super.$ctor$2();
                {
                    this._startInSuperStream = startPosition;
                    this._positionInSuperStream = startPosition;
                    this._endInSuperStream = startPosition + maxLength;
                    this._superStream = superStream;
                    this._canRead = true;
                    this._isDisposed = false;
                }
                return this;
            }
            /*long */ get Length()
            {
                this.ThrowIfDisposed();
                return this._endInSuperStream - this._startInSuperStream;
            }
            /*long */ get Position()
            {
                this.ThrowIfDisposed();
                return this._positionInSuperStream - this._startInSuperStream;
            }
            /*long */ set Position(value)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
            }
            /*bool */ get CanRead()
            {
                return this._superStream.CanRead && this._canRead;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*void */ ThrowIfDisposed()
            {
                if (this._isDisposed)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15($.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this)), $.$sic.System.SR.HiddenStreamName);
                }
            }
            /*void */ ThrowIfCantRead()
            {
                if (!this.CanRead)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
                }
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                /*int*/ let origCount = count;
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                if (this._superStream.Position !== this._positionInSuperStream)
                {
                    this._superStream.Seek(this._positionInSuperStream, 0/*SeekOrigin.Begin*/);
                }
                if (this._positionInSuperStream + BigInt(count) > this._endInSuperStream)
                {
                    count = $.$cast((this._endInSuperStream - this._positionInSuperStream), $.$spc.System.Int32);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(count >= 0, "count >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(count <= origCount, "count <= origCount");
                /*int*/ let ret = this._superStream.Read(buffer, offset, count);
                this._positionInSuperStream += BigInt(ret);
                return ret;
            }
            /*int */ Read$1(/*Span<byte>*/ destination)
            {
                /*int*/ let origCount = destination.Length;
                /*int*/ let count = destination.Length;
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                if (this._superStream.Position !== this._positionInSuperStream)
                {
                    this._superStream.Seek(this._positionInSuperStream, 0/*SeekOrigin.Begin*/);
                }
                if (this._positionInSuperStream + BigInt(count) > this._endInSuperStream)
                {
                    count = $.$cast((this._endInSuperStream - this._positionInSuperStream), $.$spc.System.Int32);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(count >= 0, "count >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(count <= origCount, "count <= origCount");
                /*int*/ let ret = this._superStream.Read$1(destination.Slice$1(0, count));
                this._positionInSuperStream += BigInt(ret);
                return ret;
            }
            /*int */ ReadByte()
            {
                /*byte*/ let b = 0;
                return this.Read$1(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$5($.$ref(() => b, ($v) => b = $v, $.$spc.System.Byte))) === 1 ? b : -1;
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.ReadAsync$2(new ($.$spc.System.Memory$$($.$spc.System.Byte))().$ctor$4(buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                return Core.call(this, buffer, cancellationToken);
                /*ValueTask<int>*/ /*async*/  function Core(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                    {
                        if (this._superStream.Position !== this._positionInSuperStream)
                        {
                            this._superStream.Seek(this._positionInSuperStream, 0/*SeekOrigin.Begin*/);
                        }
                        if (this._positionInSuperStream > this._endInSuperStream - BigInt(buffer.Length))
                        {
                            buffer = buffer.Slice$1(0, $.$cast((this._endInSuperStream - this._positionInSuperStream), $.$spc.System.Int32));
                        }
                        /*int*/ let ret = await this._superStream.ReadAsync$2(buffer, cancellationToken).ConfigureAwait(false);
                        this._positionInSuperStream += BigInt(ret);
                        return ret;
                    });
                }
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
            }
            /*void */ SetLength(/*long*/ value)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SetLengthRequiresSeekingAndWriting);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.WritingNotSupported);
            }
            /*void */ Flush()
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.WritingNotSupported);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing && !this._isDisposed)
                {
                    this._canRead = false;
                    this._isDisposed = true;
                }
                super.Dispose$1(disposing);
            }
            static $h = 1832338;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":917505,"g":{"r":0,"d":0,"h":38656538002,"f":32769},"n":"Length","d":1832338,"h":34361570706,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":47246472594,"f":32769},"s":{"r":0,"d":0,"h":51541439890,"f":32769},"n":"Position","d":1832338,"h":42951505298,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60131374482,"f":32769},"n":"CanRead","d":1832338,"h":55836407186,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":68721309074,"f":32769},"n":"CanSeek","d":1832338,"h":64426341778,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":77311243666,"f":32769},"n":"CanWrite","d":1832338,"h":73016276370,"f":32769}],"m":[{"r":65537,"n":"ThrowIfDisposed","d":1832338,"h":81606210962,"f":2},{"r":65537,"n":"ThrowIfCantRead","d":1832338,"h":85901178258,"f":2},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1832338,"h":90196145554,"f":32769},{"r":655361,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1832338,"h":94491112850,"f":32769},{"r":655361,"n":"ReadByte","d":1832338,"h":98786080146,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1832338,"h":103081047442,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1832338,"h":107376014738,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1832338,"h":111670982034,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1832338,"h":115965949330,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1832338,"h":120260916626,"f":32769},{"r":65537,"n":"Flush","d":1832338,"h":124555883922,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1832338,"h":128850851218,"f":32772}],"l":[{"t":917505,"n":"_startInSuperStream","d":1832338,"h":4296799634,"f":2},{"t":917505,"n":"_positionInSuperStream","d":1832338,"h":8591766930,"f":2},{"t":917505,"n":"_endInSuperStream","d":1832338,"h":12886734226,"f":2},{"t":62193665,"n":"_superStream","d":1832338,"h":17181701522,"f":2},{"t":262145,"n":"_canRead","d":1832338,"h":21476668818,"f":2},{"t":262145,"n":"_isDisposed","d":1832338,"h":25771636114,"f":2}],"c":[{"p":[{"n":"superStream","p":62193665},{"n":"startPosition","p":917505},{"n":"maxLength","p":917505}],"n":".ctor","o":"$ctor$3","d":1832338,"h":30066603410,"f":1}],"i":[57540609,56950785],"h":1832338}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.SubReadStream`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZLibStream", ($self) => class ZLibStream extends $.$spc.System.IO.Stream
        {
            /*DeflateStream*/ _deflateStream = null;
            $ctor$3(/*Stream*/ stream, /*CompressionMode*/ mode)
            {
                this.$ctor$4(stream, mode, false);
                {
                }
                return this;
            }
            $ctor$4(/*Stream*/ stream, /*CompressionMode*/ mode, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    this._deflateStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$10(stream, mode, leaveOpen, 15/*ZLibNative.ZLib_DefaultWindowBits*/, -1n);
                }
                return this;
            }
            $ctor$5(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel)
            {
                this.$ctor$6(stream, compressionLevel, false);
                {
                }
                return this;
            }
            $ctor$6(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    this._deflateStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$11(stream, compressionLevel, leaveOpen, 15/*ZLibNative.ZLib_DefaultWindowBits*/);
                }
                return this;
            }
            $ctor$7(/*Stream*/ stream, /*ZLibCompressionOptions*/ compressionOptions, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    this._deflateStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$9(stream, compressionOptions, leaveOpen, 15/*ZLibNative.ZLib_DefaultWindowBits*/);
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                return (this._deflateStream?.CanRead ?? null) ?? false;
            }
            /*bool */ get CanWrite()
            {
                return (this._deflateStream?.CanWrite ?? null) ?? false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Flush()
            {
                this.ThrowIfClosed();
                this._deflateStream.Flush();
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfClosed();
                return this._deflateStream.FlushAsync$1(cancellationToken);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*int */ ReadByte()
            {
                this.ThrowIfClosed();
                return this._deflateStream.ReadByte();
            }
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                this.ThrowIfClosed();
                return this._deflateStream.BeginRead(buffer, offset, count, asyncCallback, asyncState);
            }
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                return this._deflateStream.EndRead(asyncResult);
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ThrowIfClosed();
                return this._deflateStream.Read(buffer, offset, count);
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                this.ThrowIfClosed();
                return this._deflateStream.ReadCore(buffer);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfClosed();
                return this._deflateStream.ReadAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfClosed();
                return this._deflateStream.ReadAsyncMemory(buffer, cancellationToken);
            }
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                this.ThrowIfClosed();
                return this._deflateStream.BeginWrite(buffer, offset, count, asyncCallback, asyncState);
            }
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                return this._deflateStream.EndWrite(asyncResult);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ThrowIfClosed();
                this._deflateStream.Write(buffer, offset, count);
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
            {
                this.ThrowIfClosed();
                this._deflateStream.WriteCore(buffer);
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfClosed();
                return this._deflateStream.WriteAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfClosed();
                return this._deflateStream.WriteAsyncMemory(buffer, cancellationToken);
            }
            /*void */ WriteByte(/*byte*/ value)
            {
                this.ThrowIfClosed();
                this._deflateStream.WriteByte(value);
            }
            /*void */ CopyTo$1(/*Stream*/ destination, /*int*/ bufferSize)
            {
                this.ThrowIfClosed();
                this._deflateStream.CopyTo$1(destination, bufferSize);
            }
            /*Task */ CopyToAsync$3(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfClosed();
                return this._deflateStream.CopyToAsync$3(destination, bufferSize, cancellationToken);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    if (disposing)
                    {
                        this._deflateStream?.Dispose();
                    }
                    this._deflateStream = null;
                }
                finally
                {
                    {
                        super.Dispose$1(disposing);
                    }
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                /*DeflateStream?*/ let ds = this._deflateStream;
                if (!(ds === null))
                {
                    this._deflateStream = null;
                    return ds.DisposeAsync();
                }
                return new $.$spc.System.Threading.Tasks.ValueTask();
            }
            /*Stream */ get BaseStream()
            {
                return (this._deflateStream?.BaseStream ?? null);
            }
            /*void */ ThrowIfClosed()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._deflateStream === null, this);
            }
            static $h = 5305746;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34365044114,"f":32769},"n":"CanRead","d":5305746,"h":30070076818,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42954978706,"f":32769},"n":"CanWrite","d":5305746,"h":38660011410,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51544913298,"f":32769},"n":"CanSeek","d":5305746,"h":47249946002,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":60134847890,"f":32769},"n":"Length","d":5305746,"h":55839880594,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68724782482,"f":32769},"s":{"r":0,"d":0,"h":73019749778,"f":32769},"n":"Position","d":5305746,"h":64429815186,"f":32769},{"p":62193665,"g":{"r":0,"d":0,"h":176098964882,"f":1},"n":"BaseStream","d":5305746,"h":171803997586,"f":1}],"m":[{"r":65537,"n":"Flush","d":5305746,"h":77314717074,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":5305746,"h":81609684370,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":5305746,"h":85904651666,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":5305746,"h":90199618962,"f":32769},{"r":655361,"n":"ReadByte","d":5305746,"h":94494586258,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginRead","d":5305746,"h":98789553554,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":5305746,"h":103084520850,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":5305746,"h":107379488146,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":5305746,"h":111674455442,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":5305746,"h":115969422738,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":5305746,"h":120264390034,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":5305746,"h":124559357330,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":5305746,"h":128854324626,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":5305746,"h":133149291922,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":5305746,"h":137444259218,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":5305746,"h":141739226514,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":5305746,"h":146034193810,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":5305746,"h":150329161106,"f":32769},{"r":65537,"p":[{"n":"destination","p":62193665},{"n":"bufferSize","p":655361}],"n":"CopyTo","o":"@$1","d":5305746,"h":154624128402,"f":32769},{"r":133300225,"p":[{"n":"destination","p":62193665},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"CopyToAsync","o":"@$3","d":5305746,"h":158919095698,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":5305746,"h":163214062994,"f":32772},{"r":136118273,"n":"DisposeAsync","d":5305746,"h":167509030290,"f":32769},{"r":65537,"n":"ThrowIfClosed","d":5305746,"h":180393932178,"f":2}],"l":[{"t":1111442,"n":"_deflateStream","d":5305746,"h":4300273042,"f":2}],"c":[{"p":[{"n":"stream","p":62193665},{"n":"mode","p":849298}],"n":".ctor","o":"$ctor$3","d":5305746,"h":8595240338,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"mode","p":849298},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$4","d":5305746,"h":12890207634,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"compressionLevel","p":783762}],"n":".ctor","o":"$ctor$5","d":5305746,"h":17185174930,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"compressionLevel","p":783762},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$6","d":5305746,"h":21480142226,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"compressionOptions","p":4519314},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$7","d":5305746,"h":25775109522,"f":1}],"i":[57540609,56950785],"h":5305746}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.ZLibStream`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.CheckSumAndSizeWriteStream", ($self) => class CheckSumAndSizeWriteStream extends $.$spc.System.IO.Stream
        {
            /*Stream*/ _baseStream = null;
            /*Stream*/ _baseBaseStream = null;
            /*long*/ _position = 0n;
            /*uint*/ _checksum = 0;
            /*bool*/ _leaveOpenOnClose = false;
            /*bool*/ _canWrite = false;
            /*bool*/ _isDisposed = false;
            /*bool*/ _everWritten = false;
            /*long*/ _initialPosition = 0n;
            /*ZipArchiveEntry*/ _zipArchiveEntry = null;
            /*EventHandler?*/ _onClose = null;
            /*Action<long, long, uint, Stream, ZipArchiveEntry, EventHandler?>*/ _saveCrcAndSizes = null;
            $ctor$3(/*Stream*/ baseStream, /*Stream*/ baseBaseStream, /*bool*/ leaveOpenOnClose, /*ZipArchiveEntry*/ entry, /*EventHandler?*/ onClose, /*Action<long, long, uint, Stream, ZipArchiveEntry, EventHandler?>*/ saveCrcAndSizes)
            {
                super.$ctor$2();
                {
                    this._baseStream = baseStream;
                    this._baseBaseStream = baseBaseStream;
                    this._position = 0n;
                    this._checksum = 0;
                    this._leaveOpenOnClose = leaveOpenOnClose;
                    this._canWrite = true;
                    this._isDisposed = false;
                    this._initialPosition = 0n;
                    this._zipArchiveEntry = entry;
                    this._onClose = onClose;
                    this._saveCrcAndSizes = saveCrcAndSizes;
                }
                return this;
            }
            /*long */ get Length()
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
            }
            /*long */ get Position()
            {
                this.ThrowIfDisposed();
                return this._position;
            }
            /*long */ set Position(value)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
            }
            /*bool */ get CanRead()
            {
                return false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return this._canWrite;
            }
            /*void */ ThrowIfDisposed()
            {
                if (this._isDisposed)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15($.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this)), $.$sic.System.SR.HiddenStreamName);
                }
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
            }
            /*void */ SetLength(/*long*/ value)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SetLengthRequiresSeekingAndWriting);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                this.ThrowIfDisposed();
                $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                if (count === 0)
                {
                    return;
                }
                if (!this._everWritten)
                {
                    this._initialPosition = this._baseBaseStream.Position;
                    this._everWritten = true;
                }
                this._checksum = $.$sic.System.IO.Compression.Crc32Helper.UpdateCrc32(this._checksum, buffer, offset, count);
                this._baseStream.Write(buffer, offset, count);
                this._position += BigInt(count);
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ source)
            {
                this.ThrowIfDisposed();
                $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                if (source.Length === 0)
                {
                    return;
                }
                if (!this._everWritten)
                {
                    this._initialPosition = this._baseBaseStream.Position;
                    this._everWritten = true;
                }
                this._checksum = $.$sic.System.IO.Compression.Crc32Helper.UpdateCrc32$1(this._checksum, source);
                this._baseStream.Write$1(source);
                this._position += BigInt(source.Length);
            }
            /*void */ WriteByte(/*byte*/ value)
            {
                return this.Write$1(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$5($.$ref(() => value, undefined, $.$spc.System.Byte)));
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                return !buffer.IsEmpty ? Core.call(this, buffer, cancellationToken) : new $.$spc.System.Threading.Tasks.ValueTask();
                /*ValueTask*/ /*async*/  function Core(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                    {
                        if (!this._everWritten)
                        {
                            this._initialPosition = this._baseBaseStream.Position;
                            this._everWritten = true;
                        }
                        this._checksum = $.$sic.System.IO.Compression.Crc32Helper.UpdateCrc32$1(this._checksum, buffer.Span);
                        await this._baseStream.WriteAsync$2(buffer, cancellationToken).ConfigureAwait(false);
                        this._position += BigInt(buffer.Length);
                    });
                }
            }
            /*void */ Flush()
            {
                this.ThrowIfDisposed();
                $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                this._baseStream.Flush();
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                return this._baseStream.FlushAsync$1(cancellationToken);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing && !this._isDisposed)
                {
                    if (!this._everWritten)
                    {
                        this._initialPosition = this._baseBaseStream.Position;
                    }
                    if (!this._leaveOpenOnClose)
                    {
                        this._baseStream.Dispose();
                    }
                    this._saveCrcAndSizes?.Invoke(this._initialPosition, this.Position, this._checksum, this._baseBaseStream, this._zipArchiveEntry, this._onClose);
                    this._isDisposed = true;
                }
                super.Dispose$1(disposing);
            }
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    if (!this._isDisposed)
                    {
                        if (!this._everWritten)
                        {
                            this._initialPosition = this._baseBaseStream.Position;
                        }
                        if (!this._leaveOpenOnClose)
                        {
                            await this._baseStream.DisposeAsync().ConfigureAwait(false);
                        }
                        this._saveCrcAndSizes?.Invoke(this._initialPosition, this.Position, this._checksum, this._baseBaseStream, this._zipArchiveEntry, this._onClose);
                        this._isDisposed = true;
                    }
                    await super.DisposeAsync().ConfigureAwait(false);
                });
            }
            static $h = 718226;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":917505,"g":{"r":0,"d":0,"h":64425227666,"f":32769},"n":"Length","d":718226,"h":60130260370,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":73015162258,"f":32769},"s":{"r":0,"d":0,"h":77310129554,"f":32769},"n":"Position","d":718226,"h":68720194962,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":85900064146,"f":32769},"n":"CanRead","d":718226,"h":81605096850,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":94489998738,"f":32769},"n":"CanSeek","d":718226,"h":90195031442,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":103079933330,"f":32769},"n":"CanWrite","d":718226,"h":98784966034,"f":32769}],"m":[{"r":65537,"n":"ThrowIfDisposed","d":718226,"h":107374900626,"f":2},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":718226,"h":111669867922,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":718226,"h":115964835218,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":718226,"h":120259802514,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":718226,"h":124554769810,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":718226,"h":128849737106,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":718226,"h":133144704402,"f":32769},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":718226,"h":137439671698,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":718226,"h":141734638994,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":718226,"h":146029606290,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":718226,"h":150324573586,"f":32769},{"r":65537,"n":"Flush","d":718226,"h":154619540882,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":718226,"h":158914508178,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":718226,"h":163209475474,"f":32772},{"r":136118273,"n":"DisposeAsync","d":718226,"h":167504442770,"f":36865}],"l":[{"t":62193665,"n":"_baseStream","d":718226,"h":4295685522,"f":2},{"t":62193665,"n":"_baseBaseStream","d":718226,"h":8590652818,"f":2},{"t":917505,"n":"_position","d":718226,"h":12885620114,"f":2},{"t":720897,"n":"_checksum","d":718226,"h":17180587410,"f":2},{"t":262145,"n":"_leaveOpenOnClose","d":718226,"h":21475554706,"f":2},{"t":262145,"n":"_canWrite","d":718226,"h":25770522002,"f":2},{"t":262145,"n":"_isDisposed","d":718226,"h":30065489298,"f":2},{"t":262145,"n":"_everWritten","d":718226,"h":34360456594,"f":2},{"t":917505,"n":"_initialPosition","d":718226,"h":38655423890,"f":2},{"t":2684306,"n":"_zipArchiveEntry","d":718226,"h":42950391186,"f":2},{"t":47054849,"n":"_onClose","d":718226,"h":47245358482,"f":2},{"t":$.$spc.System.Action$$$$$$$($.$spc.System.Int64, $.$spc.System.Int64, $.$spc.System.UInt32, $.$spc.System.IO.Stream, $.$sic.System.IO.Compression.ZipArchiveEntry, $.$spc.System.EventHandler).$h,"n":"_saveCrcAndSizes","d":718226,"h":51540325778,"f":2}],"c":[{"p":[{"n":"baseStream","p":62193665},{"n":"baseBaseStream","p":62193665},{"n":"leaveOpenOnClose","p":262145},{"n":"entry","p":2684306},{"n":"onClose","p":47054849},{"n":"saveCrcAndSizes","p":$.$spc.System.Action$$$$$$$($.$spc.System.Int64, $.$spc.System.Int64, $.$spc.System.UInt32, $.$spc.System.IO.Stream, $.$sic.System.IO.Compression.ZipArchiveEntry, $.$spc.System.EventHandler).$h}],"n":".ctor","o":"$ctor$3","d":718226,"h":55835293074,"f":1}],"i":[57540609,56950785],"h":718226}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.CheckSumAndSizeWriteStream`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.DeflateStream", ($self) => class DeflateStream extends $.$spc.System.IO.Stream
        {
            /*int*/ static DefaultBufferSize = 8192;
            /*Stream*/ _stream = null;
            /*CompressionMode*/ _mode = 0;
            /*bool*/ _leaveOpen = false;
            /*Inflater?*/ _inflater = null;
            /*Deflater?*/ _deflater = null;
            /*byte[]?*/ _buffer = null;
            /*bool*/ _activeAsyncOperation = false;
            /*bool*/ _wroteBytes = false;
            $ctor$3(/*Stream*/ stream, /*CompressionMode*/ mode, /*long*/ uncompressedSize)
            {
                this.$ctor$10(stream, mode, false, -15/*ZLibNative.Deflate_DefaultWindowBits*/, -1n);
                {
                }
                return this;
            }
            $ctor$4(/*Stream*/ stream, /*CompressionMode*/ mode)
            {
                this.$ctor$5(stream, mode, false);
                {
                }
                return this;
            }
            $ctor$5(/*Stream*/ stream, /*CompressionMode*/ mode, /*bool*/ leaveOpen)
            {
                this.$ctor$10(stream, mode, leaveOpen, -15/*ZLibNative.Deflate_DefaultWindowBits*/, -1n);
                {
                }
                return this;
            }
            $ctor$6(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel)
            {
                this.$ctor$7(stream, compressionLevel, false);
                {
                }
                return this;
            }
            $ctor$7(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel, /*bool*/ leaveOpen)
            {
                this.$ctor$11(stream, compressionLevel, leaveOpen, -15/*ZLibNative.Deflate_DefaultWindowBits*/);
                {
                }
                return this;
            }
            $ctor$8(/*Stream*/ stream, /*ZLibCompressionOptions*/ compressionOptions, /*bool*/ leaveOpen)
            {
                this.$ctor$9(stream, compressionOptions, leaveOpen, -15/*ZLibNative.Deflate_DefaultWindowBits*/);
                {
                }
                return this;
            }
            $ctor$9(/*Stream*/ stream, /*ZLibCompressionOptions*/ compressionOptions, /*bool*/ leaveOpen, /*int*/ windowBits)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(compressionOptions, "compressionOptions");
                    this.InitializeDeflater(stream, $.$cast(compressionOptions.CompressionLevel, $.$sic.System.IO.Compression.ZLibNative.CompressionLevel), $.$cast(compressionOptions.CompressionStrategy, $.$sic.System.IO.Compression.ZLibNative.CompressionStrategy), leaveOpen, windowBits);
                }
                return this;
            }
            $ctor$10(/*Stream*/ stream, /*CompressionMode*/ mode, /*bool*/ leaveOpen, /*int*/ windowBits, /*long*/ uncompressedSize)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                    switch(mode)
                    {
                        case 0/*CompressionMode.Decompress*/:
                        if (!stream.CanRead)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$sic.System.SR.NotSupported_UnreadableStream, "stream");
                        }
                        this._inflater = new $.$sic.System.IO.Compression.Inflater().$ctor$1(windowBits, uncompressedSize);
                        this._stream = stream;
                        this._mode = 0/*CompressionMode.Decompress*/;
                        this._leaveOpen = leaveOpen;
                        break;
                        case 1/*CompressionMode.Compress*/:
                        this.InitializeDeflater(stream, -1/*ZLibNative.CompressionLevel.DefaultCompression*/, 0/*CompressionStrategy.DefaultStrategy*/, leaveOpen, windowBits);
                        break;
                        default:
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sic.System.SR.ArgumentOutOfRange_Enum, "mode");
                    }
                }
                return this;
            }
            $ctor$11(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel, /*bool*/ leaveOpen, /*int*/ windowBits)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                    this.InitializeDeflater(stream, $.$sic.System.IO.Compression.DeflateStream.GetZLibNativeCompressionLevel(compressionLevel), 0/*CompressionStrategy.DefaultStrategy*/, leaveOpen, windowBits);
                }
                return this;
            }
            /*void */ InitializeDeflater(/*Stream*/ stream, /*ZLibNative.CompressionLevel*/ compressionLevel, /*CompressionStrategy*/ strategy, /*bool*/ leaveOpen, /*int*/ windowBits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(stream !== null, "stream != null");
                if (!stream.CanWrite)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sic.System.SR.NotSupported_UnwritableStream, "stream");
                }
                this._deflater = new $.$sic.System.IO.Compression.Deflater().$ctor$1(compressionLevel, strategy, windowBits, $.$sic.System.IO.Compression.DeflateStream.GetMemLevel(compressionLevel));
                this._stream = stream;
                this._mode = 1/*CompressionMode.Compress*/;
                this._leaveOpen = leaveOpen;
                this.InitializeBuffer();
            }
            static /*ZLibNative.CompressionLevel */ GetZLibNativeCompressionLevel(/*CompressionLevel*/ compressionLevel)
            {
                return (() =>
                {
                    if (compressionLevel === 0/*CompressionLevel.Optimal*/)
                    {
                        return -1/*ZLibNative.CompressionLevel.DefaultCompression*/;
                    }
                    if (compressionLevel === 1/*CompressionLevel.Fastest*/)
                    {
                        return 1/*ZLibNative.CompressionLevel.BestSpeed*/;
                    }
                    if (compressionLevel === 2/*CompressionLevel.NoCompression*/)
                    {
                        return 0/*ZLibNative.CompressionLevel.NoCompression*/;
                    }
                    if (compressionLevel === 3/*CompressionLevel.SmallestSize*/)
                    {
                        return 9/*ZLibNative.CompressionLevel.BestCompression*/;
                    }
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("compressionLevel");
                })();
            }
            static /*int */ GetMemLevel(/*ZLibNative.CompressionLevel*/ level)
            {
                return level === 0/*ZLibNative.CompressionLevel.NoCompression*/ ? 7/*Deflate_NoCompressionMemLevel*/ : 8/*Deflate_DefaultMemLevel*/;
            }
            /*void */ InitializeBuffer()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._buffer === null, "_buffer == null");
                this._buffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(8192/*DefaultBufferSize*/);
            }
            /*void */ EnsureBufferInitialized()
            {
                if (this._buffer === null)
                {
                    this.InitializeBuffer();
                }
            }
            /*Stream */ get BaseStream()
            {
                return this._stream;
            }
            /*bool */ get CanRead()
            {
                if (this._stream === null)
                {
                    return false;
                }
                return (this._mode === 0/*CompressionMode.Decompress*/ && this._stream.CanRead);
            }
            /*bool */ get CanWrite()
            {
                if (this._stream === null)
                {
                    return false;
                }
                return (this._mode === 1/*CompressionMode.Compress*/ && this._stream.CanWrite);
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ Flush()
            {
                this.EnsureNotDisposed();
                if (this._mode === 1/*CompressionMode.Compress*/)
                {
                    this.FlushBuffers();
                }
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                this.EnsureNoActiveAsyncOperation();
                this.EnsureNotDisposed();
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this._mode !== 1/*CompressionMode.Compress*/ ? $.$spc.System.Threading.Tasks.Task.CompletedTask : Core.call(this, cancellationToken);
                /*Task*/ /*async*/  function Core(/*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                    {
                        this.AsyncOperationStarting();
                        try
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null && this._buffer !== null, "_deflater != null && _buffer != null");
                            await this.WriteDeflaterOutputAsync(cancellationToken).ConfigureAwait(false);
                            /*bool*/ let flushSuccessful;
                            do
                            {
                                /*int*/ let compressedBytes;
                                flushSuccessful = this._deflater.Flush(this._buffer, $.$ref(() => compressedBytes, ($v) => compressedBytes = $v, $.$spc.System.Int32));
                                if (flushSuccessful)
                                {
                                    await this._stream.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(this._buffer, 0, compressedBytes), cancellationToken).ConfigureAwait(false);
                                }
                                $.$spc.System.Diagnostics.Debug.Assert$1(flushSuccessful === (compressedBytes > 0), "flushSuccessful == (compressedBytes > 0)");
                            }
                            while(flushSuccessful);
                            await this._stream.FlushAsync$1(cancellationToken).ConfigureAwait(false);
                        }
                        finally
                        {
                            {
                                this.AsyncOperationCompleting();
                            }
                        }
                    });
                }
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*int */ ReadByte()
            {
                this.EnsureDecompressionMode();
                this.EnsureNotDisposed();
                /*byte*/ let b;
                $.$spc.System.Diagnostics.Debug.Assert$1(this._inflater !== null, "_inflater != null");
                return this._inflater.Inflate($.$ref(() => b, ($v) => b = $v, $.$spc.System.Byte)) ? b : super.ReadByte();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.ReadCore(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count));
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.DeflateStream.$type))
                {
                    return super.Read$1(buffer);
                }
                else 
                {
                    return this.ReadCore(buffer);
                }
            }
            /*int */ ReadCore(/*Span<byte>*/ buffer)
            {
                this.EnsureDecompressionMode();
                this.EnsureNotDisposed();
                this.EnsureBufferInitialized();
                $.$spc.System.Diagnostics.Debug.Assert$1(this._inflater !== null, "_inflater != null");
                /*int*/ let bytesRead;
                while(true)
                {
                    bytesRead = this._inflater.Inflate$2(buffer);
                    if (bytesRead !== 0 || this.InflatorIsFinished)
                    {
                        break;
                    }
                    if (this._inflater.NeedsInput())
                    {
                        /*int*/ let n = this._stream.Read(this._buffer, 0, this._buffer.length);
                        if (n <= 0)
                        {
                            if ($.$sic.System.IO.Compression.DeflateStream.s_useStrictValidation && !buffer.IsEmpty && !this._inflater.Finished() && this._inflater.NonEmptyInput())
                            {
                                $.$sic.System.IO.Compression.DeflateStream.ThrowTruncatedInvalidData();
                            }
                            break;
                        }
                        else if (n > this._buffer.length)
                        {
                            $.$sic.System.IO.Compression.DeflateStream.ThrowGenericInvalidData();
                        }
                        else 
                        {
                            this._inflater.SetInput(this._buffer, 0, n);
                        }
                    }
                    if (buffer.IsEmpty)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(bytesRead === 0, "bytesRead == 0");
                        break;
                    }
                }
                return bytesRead;
            }
            /*bool */ get InflatorIsFinished()
            {
                return this._inflater.Finished() && (!this._inflater.IsGzipStream() || !this._inflater.NeedsInput());
            }
            /*void */ EnsureNotDisposed()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._stream === null, this);
            }
            /*void */ EnsureDecompressionMode()
            {
                if (this._mode !== 0/*CompressionMode.Decompress*/)
                {
                    ThrowCannotReadFromDeflateStreamException();
                }
                /*static void*/  function ThrowCannotReadFromDeflateStreamException()
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.CannotReadFromDeflateStream);
                }
            }
            /*void */ EnsureCompressionMode()
            {
                if (this._mode !== 1/*CompressionMode.Compress*/)
                {
                    ThrowCannotWriteToDeflateStreamException();
                }
                /*static void*/  function ThrowCannotWriteToDeflateStreamException()
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.CannotWriteToDeflateStream);
                }
            }
            static /*void */ ThrowGenericInvalidData()
            {
                throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData);
            }
            static /*void */ ThrowTruncatedInvalidData()
            {
                throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.TruncatedData);
            }
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.ReadAsync$1(buffer, offset, count, $.$spc.System.Threading.CancellationToken.None), asyncCallback, asyncState);
            }
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                this.EnsureDecompressionMode();
                this.EnsureNotDisposed();
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.End$1($.$spc.System.Int32, asyncResult);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.ReadAsyncMemory(new ($.$spc.System.Memory$$($.$spc.System.Byte))().$ctor$4(buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.DeflateStream.$type))
                {
                    return super.ReadAsync$2(buffer, cancellationToken);
                }
                else 
                {
                    return this.ReadAsyncMemory(buffer, cancellationToken);
                }
            }
            /*ValueTask<int> */ ReadAsyncMemory(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.EnsureDecompressionMode();
                this.EnsureNoActiveAsyncOperation();
                this.EnsureNotDisposed();
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.ValueTask.FromCanceled$1($.$spc.System.Int32, cancellationToken);
                }
                this.EnsureBufferInitialized();
                $.$spc.System.Diagnostics.Debug.Assert$1(this._inflater !== null, "_inflater != null");
                return Core.call(this, buffer, cancellationToken);
                /*ValueTask<int>*/ /*async*/  function Core(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                    {
                        this.AsyncOperationStarting();
                        try
                        {
                            /*int*/ let bytesRead;
                            while(true)
                            {
                                bytesRead = this._inflater.Inflate$2(buffer.Span);
                                if (bytesRead !== 0 || this.InflatorIsFinished)
                                {
                                    break;
                                }
                                if (this._inflater.NeedsInput())
                                {
                                    /*int*/ let n = await this._stream.ReadAsync$2(new ($.$spc.System.Memory$$($.$spc.System.Byte))().$ctor$4(this._buffer, 0, this._buffer.length), cancellationToken).ConfigureAwait(false);
                                    if (n <= 0)
                                    {
                                        if ($.$sic.System.IO.Compression.DeflateStream.s_useStrictValidation && !this._inflater.Finished() && this._inflater.NonEmptyInput() && !buffer.IsEmpty)
                                        {
                                            $.$sic.System.IO.Compression.DeflateStream.ThrowTruncatedInvalidData();
                                        }
                                        break;
                                    }
                                    else if (n > this._buffer.length)
                                    {
                                        $.$sic.System.IO.Compression.DeflateStream.ThrowGenericInvalidData();
                                    }
                                    else 
                                    {
                                        this._inflater.SetInput(this._buffer, 0, n);
                                    }
                                }
                                if (buffer.IsEmpty)
                                {
                                    break;
                                }
                            }
                            return bytesRead;
                        }
                        finally
                        {
                            {
                                this.AsyncOperationCompleting();
                            }
                        }
                    });
                }
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                this.WriteCore(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count));
            }
            /*void */ WriteByte(/*byte*/ value)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.DeflateStream.$type))
                {
                    super.WriteByte(value);
                }
                else 
                {
                    this.WriteCore(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$5($.$ref(() => value, undefined, $.$spc.System.Byte)));
                }
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.DeflateStream.$type))
                {
                    super.Write$1(buffer);
                }
                else 
                {
                    this.WriteCore(buffer);
                }
            }
            /*void */ WriteCore(/*ReadOnlySpan<byte>*/ buffer)
            {
                this.EnsureCompressionMode();
                this.EnsureNotDisposed();
                if (buffer.IsEmpty)
                {
                    return;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null, "_deflater != null");
                this.WriteDeflaterOutput();
                {
                    /*fixed*/ 
                    {
                        /*byte**/ let bufferPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, buffer);
                        this._deflater.SetInput$1(bufferPtr, buffer.Length);
                        this.WriteDeflaterOutput();
                        this._wroteBytes = true;
                    }
                }
            }
            /*void */ WriteDeflaterOutput()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null && this._buffer !== null, "_deflater != null && _buffer != null");
                while(!this._deflater.NeedsInput())
                {
                    /*int*/ let compressedBytes = this._deflater.GetDeflateOutput(this._buffer);
                    if (compressedBytes > 0)
                    {
                        this._stream.Write(this._buffer, 0, compressedBytes);
                    }
                }
            }
            /*void */ FlushBuffers()
            {
                if (this._wroteBytes)
                {
                    this.WriteDeflaterOutput();
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null && this._buffer !== null, "_deflater != null && _buffer != null");
                    /*bool*/ let flushSuccessful;
                    do
                    {
                        /*int*/ let compressedBytes;
                        flushSuccessful = this._deflater.Flush(this._buffer, $.$ref(() => compressedBytes, ($v) => compressedBytes = $v, $.$spc.System.Int32));
                        if (flushSuccessful)
                        {
                            this._stream.Write(this._buffer, 0, compressedBytes);
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(flushSuccessful === (compressedBytes > 0), "flushSuccessful == (compressedBytes > 0)");
                    }
                    while(flushSuccessful);
                }
                this._stream.Flush();
            }
            /*void */ PurgeBuffers(/*bool*/ disposing)
            {
                if (!disposing)
                {
                    return;
                }
                if (this._stream === null)
                {
                    return;
                }
                if (this._mode !== 1/*CompressionMode.Compress*/)
                {
                    return;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null && this._buffer !== null, "_deflater != null && _buffer != null");
                if (this._wroteBytes)
                {
                    this.WriteDeflaterOutput();
                    /*bool*/ let finished;
                    do
                    {
                        /*int*/ let compressedBytes;
                        finished = this._deflater.Finish(this._buffer, $.$ref(() => compressedBytes, ($v) => compressedBytes = $v, $.$spc.System.Int32));
                        if (compressedBytes > 0)
                        {
                            this._stream.Write(this._buffer, 0, compressedBytes);
                        }
                    }
                    while(!finished);
                }
                else 
                {
                    /*bool*/ let finished;
                    do
                    {
                        finished = this._deflater.Finish(this._buffer, $.$discardRef());
                    }
                    while(!finished);
                }
            }
            /*ValueTask *//*async*/  PurgeBuffersAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    if (this._stream === null)
                    {
                        return;
                    }
                    if (this._mode !== 1/*CompressionMode.Compress*/)
                    {
                        return;
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null && this._buffer !== null, "_deflater != null && _buffer != null");
                    if (this._wroteBytes)
                    {
                        await this.WriteDeflaterOutputAsync(new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                        /*bool*/ let finished;
                        do
                        {
                            /*int*/ let compressedBytes;
                            finished = this._deflater.Finish(this._buffer, $.$ref(() => compressedBytes, ($v) => compressedBytes = $v, $.$spc.System.Int32));
                            if (compressedBytes > 0)
                            {
                                await this._stream.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(this._buffer, 0, compressedBytes), new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                            }
                        }
                        while(!finished);
                    }
                    else 
                    {
                        /*bool*/ let finished;
                        do
                        {
                            finished = this._deflater.Finish(this._buffer, $.$discardRef());
                        }
                        while(!finished);
                    }
                });
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    this.PurgeBuffers(disposing);
                }
                finally
                {
                    {
                        try
                        {
                            if (disposing && !this._leaveOpen)
                            {
                                this._stream?.Dispose();
                            }
                        }
                        finally
                        {
                            {
                                this._stream = null;
                                try
                                {
                                    this._deflater?.Dispose();
                                    this._inflater?.Dispose$1();
                                }
                                finally
                                {
                                    {
                                        this._deflater = null;
                                        this._inflater = null;
                                        /*byte[]?*/ let buffer = this._buffer;
                                        if (buffer !== null)
                                        {
                                            this._buffer = null;
                                            if (!this._activeAsyncOperation)
                                            {
                                                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(buffer, false);
                                            }
                                        }
                                        super.Dispose$1(disposing);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                return $.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.DeflateStream.$type) ? Core.call(this) : super.DisposeAsync();
                /*ValueTask*/ /*async*/  function Core()
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                    {
                        try
                        {
                            await this.PurgeBuffersAsync().ConfigureAwait(false);
                        }
                        finally
                        {
                            {
                                /*Stream*/ let stream = this._stream;
                                this._stream = null;
                                try
                                {
                                    if (!this._leaveOpen && stream !== null)
                                    {
                                        await stream.DisposeAsync().ConfigureAwait(false);
                                    }
                                }
                                finally
                                {
                                    {
                                        try
                                        {
                                            this._deflater?.Dispose();
                                            this._inflater?.Dispose$1();
                                        }
                                        finally
                                        {
                                            {
                                                this._deflater = null;
                                                this._inflater = null;
                                                /*byte[]?*/ let buffer = this._buffer;
                                                if (buffer !== null)
                                                {
                                                    this._buffer = null;
                                                    if (!this._activeAsyncOperation)
                                                    {
                                                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(buffer, false);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            }
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.WriteAsync$1(buffer, offset, count, $.$spc.System.Threading.CancellationToken.None), asyncCallback, asyncState);
            }
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                this.EnsureCompressionMode();
                this.EnsureNotDisposed();
                $.$spc.System.Threading.Tasks.TaskToAsyncResult.End(asyncResult);
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.WriteAsyncMemory(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.DeflateStream.$type))
                {
                    return super.WriteAsync$2(buffer, cancellationToken);
                }
                else 
                {
                    return this.WriteAsyncMemory(buffer, cancellationToken);
                }
            }
            /*ValueTask */ WriteAsyncMemory(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.EnsureCompressionMode();
                this.EnsureNoActiveAsyncOperation();
                this.EnsureNotDisposed();
                return cancellationToken.IsCancellationRequested ? $.$spc.System.Threading.Tasks.ValueTask.FromCanceled(cancellationToken) : buffer.IsEmpty ? new $.$spc.System.Threading.Tasks.ValueTask() : Core.call(this, buffer, cancellationToken);
                /*ValueTask*/ /*async*/  function Core(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                    {
                        this.AsyncOperationStarting();
                        try
                        {
                            await this.WriteDeflaterOutputAsync(cancellationToken).ConfigureAwait(false);
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null, "_deflater != null");
                            this._deflater.SetInput(buffer);
                            await this.WriteDeflaterOutputAsync(cancellationToken).ConfigureAwait(false);
                            this._wroteBytes = true;
                        }
                        finally
                        {
                            {
                                this.AsyncOperationCompleting();
                            }
                        }
                    });
                }
            }
            /*ValueTask *//*async*/  WriteDeflaterOutputAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null && this._buffer !== null, "_deflater != null && _buffer != null");
                    while(!this._deflater.NeedsInput())
                    {
                        /*int*/ let compressedBytes = this._deflater.GetDeflateOutput(this._buffer);
                        if (compressedBytes > 0)
                        {
                            await this._stream.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(this._buffer, 0, compressedBytes), cancellationToken).ConfigureAwait(false);
                        }
                    }
                });
            }
            /*void */ CopyTo$1(/*Stream*/ destination, /*int*/ bufferSize)
            {
                $.$spc.System.IO.Stream.ValidateCopyToArguments(destination, bufferSize);
                this.EnsureNotDisposed();
                if (!this.CanRead)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$9();
                }
                new $.$sic.System.IO.Compression.DeflateStream.CopyToStream().$ctor$3(this, destination, bufferSize).CopyFromSourceToDestination();
            }
            /*Task */ CopyToAsync$3(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.IO.Stream.ValidateCopyToArguments(destination, bufferSize);
                this.EnsureNotDisposed();
                if (!this.CanRead)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$9();
                }
                this.EnsureNoActiveAsyncOperation();
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spc.System.Int32, cancellationToken);
                }
                return new $.$sic.System.IO.Compression.DeflateStream.CopyToStream().$ctor$4(this, destination, bufferSize, cancellationToken).CopyFromSourceToDestinationAsync();
            }
            static $_CopyToStream;
            static get CopyToStream()
            {
                let $cls = $.$sic.System.IO.Compression.DeflateStream;
                return $cls.$_CopyToStream ??= $asm.$ncls("$sic.System.IO.Compression.DeflateStream.CopyToStream", ($self) => class CopyToStream extends $.$spc.System.IO.Stream
                {
                    /*DeflateStream*/ _deflateStream = null;
                    /*Stream*/ _destination = null;
                    /*CancellationToken*/ _cancellationToken;
                    /*byte[]*/ _arrayPoolBuffer = null;
                    $ctor$3(/*DeflateStream*/ deflateStream, /*Stream*/ destination, /*int*/ bufferSize)
                    {
                        this.$ctor$4(deflateStream, destination, bufferSize, $.$spc.System.Threading.CancellationToken.None);
                        {
                        }
                        return this;
                    }
                    $ctor$4(/*DeflateStream*/ deflateStream, /*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
                    {
                        super.$ctor$2();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(deflateStream !== null, "deflateStream != null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(destination !== null, "destination != null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(bufferSize > 0, "bufferSize > 0");
                            this._deflateStream = deflateStream;
                            this._destination = destination;
                            this._cancellationToken = cancellationToken;
                            this._arrayPoolBuffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(bufferSize);
                        }
                        return this;
                    }
                    /*Task *//*async*/  CopyFromSourceToDestinationAsync()
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                        {
                            this._deflateStream.AsyncOperationStarting();
                            try
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._deflateStream._inflater !== null, "_deflateStream._inflater != null");
                                while(!this._deflateStream._inflater.Finished())
                                {
                                    /*int*/ let bytesRead = this._deflateStream._inflater.Inflate$1(this._arrayPoolBuffer, 0, this._arrayPoolBuffer.length);
                                    if (bytesRead > 0)
                                    {
                                        await this._destination.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(this._arrayPoolBuffer, 0, bytesRead), this._cancellationToken).ConfigureAwait(false);
                                    }
                                    else if (this._deflateStream._inflater.NeedsInput())
                                    {
                                        break;
                                    }
                                }
                                await this._deflateStream._stream.CopyToAsync$3(this, this._arrayPoolBuffer.length, this._cancellationToken).ConfigureAwait(false);
                                if ($.$sic.System.IO.Compression.DeflateStream.s_useStrictValidation && !this._deflateStream._inflater.Finished())
                                {
                                    $.$sic.System.IO.Compression.DeflateStream.ThrowTruncatedInvalidData();
                                }
                            }
                            finally
                            {
                                {
                                    this._deflateStream.AsyncOperationCompleting();
                                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(this._arrayPoolBuffer, false);
                                    this._arrayPoolBuffer = null;
                                }
                            }
                        });
                    }
                    /*void */ CopyFromSourceToDestination()
                    {
                        try
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._deflateStream._inflater !== null, "_deflateStream._inflater != null");
                            while(!this._deflateStream._inflater.Finished())
                            {
                                /*int*/ let bytesRead = this._deflateStream._inflater.Inflate$1(this._arrayPoolBuffer, 0, this._arrayPoolBuffer.length);
                                if (bytesRead > 0)
                                {
                                    this._destination.Write(this._arrayPoolBuffer, 0, bytesRead);
                                }
                                else if (this._deflateStream._inflater.NeedsInput())
                                {
                                    break;
                                }
                            }
                            this._deflateStream._stream.CopyTo$1(this, this._arrayPoolBuffer.length);
                            if ($.$sic.System.IO.Compression.DeflateStream.s_useStrictValidation && !this._deflateStream._inflater.Finished())
                            {
                                $.$sic.System.IO.Compression.DeflateStream.ThrowTruncatedInvalidData();
                            }
                        }
                        finally
                        {
                            {
                                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(this._arrayPoolBuffer, false);
                                this._arrayPoolBuffer = null;
                            }
                        }
                    }
                    /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(buffer !== this._arrayPoolBuffer, "buffer != _arrayPoolBuffer");
                        this._deflateStream.EnsureNotDisposed();
                        if (count <= 0)
                        {
                            return $.$spc.System.Threading.Tasks.Task.CompletedTask;
                        }
                        else if (count > ((buffer.length - offset) | 0))
                        {
                            return $.$spc.System.Threading.Tasks.Task.FromException(new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData));
                        }
                        return this.WriteAsyncCore($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, buffer, offset, count)), cancellationToken).AsTask();
                    }
                    /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        this._deflateStream.EnsureNotDisposed();
                        return this.WriteAsyncCore(buffer, cancellationToken);
                    }
                    /*ValueTask *//*async*/  WriteAsyncCore(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(this._deflateStream._inflater === null), "_deflateStream._inflater is not null");
                            this._deflateStream._inflater.SetInput$1(buffer);
                            while(!this._deflateStream._inflater.Finished())
                            {
                                /*int*/ let bytesRead = this._deflateStream._inflater.Inflate$2(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$2(this._arrayPoolBuffer));
                                if (bytesRead > 0)
                                {
                                    await this._destination.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(this._arrayPoolBuffer, 0, bytesRead), cancellationToken).ConfigureAwait(false);
                                }
                                else if (this._deflateStream._inflater.NeedsInput())
                                {
                                    break;
                                }
                            }
                        });
                    }
                    /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(buffer !== this._arrayPoolBuffer, "buffer != _arrayPoolBuffer");
                        this._deflateStream.EnsureNotDisposed();
                        if (count <= 0)
                        {
                            return;
                        }
                        else if (count > ((buffer.length - offset) | 0))
                        {
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData);
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._deflateStream._inflater !== null, "_deflateStream._inflater != null");
                        this._deflateStream._inflater.SetInput(buffer, offset, count);
                        while(!this._deflateStream._inflater.Finished())
                        {
                            /*int*/ let bytesRead = this._deflateStream._inflater.Inflate$2(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$2(this._arrayPoolBuffer));
                            if (bytesRead > 0)
                            {
                                this._destination.Write(this._arrayPoolBuffer, 0, bytesRead);
                            }
                            else if (this._deflateStream._inflater.NeedsInput())
                            {
                                break;
                            }
                        }
                    }
                    /*bool */ get CanWrite()
                    {
                        return true;
                    }
                    /*void */ Flush()
                    {
                    }
                    /*bool */ get CanRead()
                    {
                        return false;
                    }
                    /*bool */ get CanSeek()
                    {
                        return false;
                    }
                    /*long */ get Length()
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*long */ get Position()
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*long */ set Position(value)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ SetLength(/*long*/ value)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._cancellationToken = $.$default($.$spc.System.Threading.CancellationToken);
                    }
                    static $h = 1176978;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":60130719122,"f":32769},"n":"CanWrite","d":1176978,"h":55835751826,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":73015621010,"f":32769},"n":"CanRead","d":1176978,"h":68720653714,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":81605555602,"f":32769},"n":"CanSeek","d":1176978,"h":77310588306,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":90195490194,"f":32769},"n":"Length","d":1176978,"h":85900522898,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":98785424786,"f":32769},"s":{"r":0,"d":0,"h":103080392082,"f":32769},"n":"Position","d":1176978,"h":94490457490,"f":32769}],"m":[{"r":133300225,"n":"CopyFromSourceToDestinationAsync","d":1176978,"h":30065948050,"f":4097},{"r":65537,"n":"CopyFromSourceToDestination","d":1176978,"h":34360915346,"f":1},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1176978,"h":38655882642,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1176978,"h":42950849938,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"WriteAsyncCore","d":1176978,"h":47245817234,"f":4098},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1176978,"h":51540784530,"f":32769},{"r":65537,"n":"Flush","d":1176978,"h":64425686418,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1176978,"h":107375359378,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1176978,"h":111670326674,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1176978,"h":115965293970,"f":32769}],"l":[{"t":1111442,"n":"_deflateStream","d":1176978,"h":4296144274,"f":2},{"t":62193665,"n":"_destination","d":1176978,"h":8591111570,"f":2},{"t":125960193,"n":"_cancellationToken","d":1176978,"h":12886078866,"f":2},{"t":0,"n":"_arrayPoolBuffer","d":1176978,"h":17181046162,"f":2}],"c":[{"p":[{"n":"deflateStream","p":1111442},{"n":"destination","p":62193665},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$3","d":1176978,"h":21476013458,"f":1},{"p":[{"n":"deflateStream","p":1111442},{"n":"destination","p":62193665},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":".ctor","o":"$ctor$4","d":1176978,"h":25770980754,"f":1}],"i":[57540609,56950785],"d":1111442,"h":1176978}; }
                    static get $b() { return $.$spc.System.IO.Stream; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
                    static get $fullName() { return `System.IO.Compression.DeflateStream.CopyToStream`; }
                }, $cls, ($v) => $cls.$_CopyToStream = $v);
            }
            /*void */ EnsureNoActiveAsyncOperation()
            {
                if (this._activeAsyncOperation)
                {
                    $.$sic.System.IO.Compression.DeflateStream.ThrowInvalidBeginCall();
                }
            }
            /*void */ AsyncOperationStarting()
            {
                if ($.$spc.System.Threading.Interlocked.Exchange$14($.$spc.System.Boolean, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => this._activeAsyncOperation, ($v) => this._activeAsyncOperation = $v, null), true))
                {
                    $.$sic.System.IO.Compression.DeflateStream.ThrowInvalidBeginCall();
                }
            }
            /*void */ AsyncOperationCompleting()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._activeAsyncOperation, "_activeAsyncOperation");
                this._activeAsyncOperation = false;
            }
            static /*void */ ThrowInvalidBeginCall()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.InvalidBeginCall);
            }
            /*bool*/ static s_useStrictValidation = false;
            //Static Initializer
            static $sinit()
            {
                {
                    /*bool*/ let strictValidation;
                    this.s_useStrictValidation = $.$spc.System.AppContext.TryGetSwitch("System.IO.Compression.UseStrictValidation", $.$ref(() => strictValidation, ($v) => strictValidation = $v, $.$spc.System.Boolean)) ? strictValidation : false;
                }
            }
            static $h = 1111442;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":62193665,"g":{"r":0,"d":0,"h":107375293842,"f":1},"n":"BaseStream","d":1111442,"h":103080326546,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115965228434,"f":32769},"n":"CanRead","d":1111442,"h":111670261138,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":124555163026,"f":32769},"n":"CanWrite","d":1111442,"h":120260195730,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":133145097618,"f":32769},"n":"CanSeek","d":1111442,"h":128850130322,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":141735032210,"f":32769},"n":"Length","d":1111442,"h":137440064914,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":150324966802,"f":32769},"s":{"r":0,"d":0,"h":154619934098,"f":32769},"n":"Position","d":1111442,"h":146029999506,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":197569607058,"f":2},"n":"InflatorIsFinished","d":1111442,"h":193274639762,"f":2}],"m":[{"r":65537,"p":[{"n":"stream","p":62193665},{"n":"compressionLevel","p":4781458},{"n":"strategy","p":4912530},{"n":"leaveOpen","p":262145},{"n":"windowBits","p":655361}],"n":"InitializeDeflater","d":1111442,"h":81605490066,"f":8},{"r":4781458,"p":[{"n":"compressionLevel","p":783762}],"n":"GetZLibNativeCompressionLevel","d":1111442,"h":85900457362,"f":34},{"r":655361,"p":[{"n":"level","p":4781458}],"n":"GetMemLevel","d":1111442,"h":90195424658,"f":34},{"r":65537,"n":"InitializeBuffer","d":1111442,"h":94490391954,"f":2},{"r":65537,"n":"EnsureBufferInitialized","d":1111442,"h":98785359250,"f":2},{"r":65537,"n":"Flush","d":1111442,"h":158914901394,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1111442,"h":163209868690,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1111442,"h":167504835986,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1111442,"h":171799803282,"f":32769},{"r":655361,"n":"ReadByte","d":1111442,"h":176094770578,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1111442,"h":180389737874,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1111442,"h":184684705170,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"ReadCore","d":1111442,"h":188979672466,"f":8},{"r":65537,"n":"EnsureNotDisposed","d":1111442,"h":201864574354,"f":2},{"r":65537,"n":"EnsureDecompressionMode","d":1111442,"h":206159541650,"f":2},{"r":65537,"n":"EnsureCompressionMode","d":1111442,"h":210454508946,"f":2},{"r":65537,"n":"ThrowGenericInvalidData","d":1111442,"h":214749476242,"f":34},{"r":65537,"n":"ThrowTruncatedInvalidData","d":1111442,"h":219044443538,"f":34},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginRead","d":1111442,"h":223339410834,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":1111442,"h":227634378130,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1111442,"h":231929345426,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1111442,"h":236224312722,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadAsyncMemory","d":1111442,"h":240519280018,"f":8},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1111442,"h":244814247314,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1111442,"h":249109214610,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1111442,"h":253404181906,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"WriteCore","d":1111442,"h":257699149202,"f":8},{"r":65537,"n":"WriteDeflaterOutput","d":1111442,"h":261994116498,"f":2},{"r":65537,"n":"FlushBuffers","d":1111442,"h":266289083794,"f":2},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"PurgeBuffers","d":1111442,"h":270584051090,"f":2},{"r":136118273,"n":"PurgeBuffersAsync","d":1111442,"h":274879018386,"f":4098},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1111442,"h":279173985682,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1111442,"h":283468952978,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":1111442,"h":287763920274,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":1111442,"h":292058887570,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1111442,"h":296353854866,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1111442,"h":300648822162,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"WriteAsyncMemory","d":1111442,"h":304943789458,"f":8},{"r":136118273,"p":[{"n":"cancellationToken","p":125960193}],"n":"WriteDeflaterOutputAsync","d":1111442,"h":309238756754,"f":4098},{"r":65537,"p":[{"n":"destination","p":62193665},{"n":"bufferSize","p":655361}],"n":"CopyTo","o":"@$1","d":1111442,"h":313533724050,"f":32769},{"r":133300225,"p":[{"n":"destination","p":62193665},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"CopyToAsync","o":"@$3","d":1111442,"h":317828691346,"f":32769},{"r":65537,"n":"EnsureNoActiveAsyncOperation","d":1111442,"h":326418625938,"f":2},{"r":65537,"n":"AsyncOperationStarting","d":1111442,"h":330713593234,"f":2},{"r":65537,"n":"AsyncOperationCompleting","d":1111442,"h":335008560530,"f":2},{"r":65537,"n":"ThrowInvalidBeginCall","d":1111442,"h":339303527826,"f":34}],"l":[{"t":655361,"n":"DefaultBufferSize","d":1111442,"h":4296078738,"f":34},{"t":62193665,"n":"_stream","d":1111442,"h":8591046034,"f":2},{"t":849298,"n":"_mode","d":1111442,"h":12886013330,"f":2},{"t":262145,"n":"_leaveOpen","d":1111442,"h":17180980626,"f":2},{"t":1373586,"n":"_inflater","d":1111442,"h":21475947922,"f":2},{"t":1045906,"n":"_deflater","d":1111442,"h":25770915218,"f":2},{"t":0,"n":"_buffer","d":1111442,"h":30065882514,"f":2},{"t":262145,"n":"_activeAsyncOperation","d":1111442,"h":34360849810,"f":2},{"t":262145,"n":"_wroteBytes","d":1111442,"h":38655817106,"f":2},{"t":262145,"n":"s_useStrictValidation","d":1111442,"h":343598495122,"f":34}],"c":[{"p":[{"n":"stream","p":62193665},{"n":"mode","p":849298},{"n":"uncompressedSize","p":917505}],"n":".ctor","o":"$ctor$3","d":1111442,"h":42950784402,"f":8},{"p":[{"n":"stream","p":62193665},{"n":"mode","p":849298}],"n":".ctor","o":"$ctor$4","d":1111442,"h":47245751698,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"mode","p":849298},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":1111442,"h":51540718994,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"compressionLevel","p":783762}],"n":".ctor","o":"$ctor$6","d":1111442,"h":55835686290,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"compressionLevel","p":783762},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$7","d":1111442,"h":60130653586,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"compressionOptions","p":4519314},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$8","d":1111442,"h":64425620882,"f":1},{"p":[{"n":"stream","p":62193665},{"n":"compressionOptions","p":4519314},{"n":"leaveOpen","p":262145},{"n":"windowBits","p":655361}],"n":".ctor","o":"$ctor$9","d":1111442,"h":68720588178,"f":8},{"p":[{"n":"stream","p":62193665},{"n":"mode","p":849298},{"n":"leaveOpen","p":262145},{"n":"windowBits","p":655361},{"n":"uncompressedSize","p":917505,"f":65,"v":-1}],"n":".ctor","o":"$ctor$10","d":1111442,"h":73015555474,"f":8},{"p":[{"n":"stream","p":62193665},{"n":"compressionLevel","p":783762},{"n":"leaveOpen","p":262145},{"n":"windowBits","p":655361}],"n":".ctor","o":"$ctor$11","d":1111442,"h":77310522770,"f":8}],"i":[57540609,56950785],"j":[1176978],"h":1111442}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.DeflateStream`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.ZipArchiveMode", ($self) => class ZipArchiveMode extends $.$spc.System.Enum
        {
            static Read = 0;
            static Create = 1;
            static Update = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Read": 0n,
                    "Create": 1n,
                    "Update": 2n
                };
            }
            static $h = 3077522;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3077522,"n":"Read","d":3077522,"h":4298044818,"f":33},{"t":3077522,"n":"Create","d":3077522,"h":8593012114,"f":33},{"t":3077522,"n":"Update","d":3077522,"h":12887979410,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3077522,"h":17182946706,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":3077522}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.ZipArchiveMode`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.ZipVersionNeededValues", ($self) => class ZipVersionNeededValues extends $.$spc.System.Enum
        {
            static Default = 10;
            static ExplicitDirectory = 20;
            static Deflate = 20;
            static Deflate64 = 21;
            static Zip64 = 45;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 10n,
                    "ExplicitDirectory": 20n,
                    "Deflate": 20n,
                    "Deflate64": 21n,
                    "Zip64": 45n
                };
            }
            static $h = 4453778;
            static $z = 2;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.UInt16; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":589825,"l":[{"t":4453778,"n":"Default","d":4453778,"h":4299421074,"f":33},{"t":4453778,"n":"ExplicitDirectory","d":4453778,"h":8594388370,"f":33},{"t":4453778,"n":"Deflate","d":4453778,"h":12889355666,"f":33},{"t":4453778,"n":"Deflate64","d":4453778,"h":17184322962,"f":33},{"t":4453778,"n":"Zip64","d":4453778,"h":21479290258,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4453778,"h":25774257554,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":4453778}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.ZipVersionNeededValues`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.BlockType", ($self) => class BlockType extends $.$spc.System.Enum
        {
            static Uncompressed = 0;
            static Static = 1;
            static Dynamic = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Uncompressed": 0n,
                    "Static": 1n,
                    "Dynamic": 2n
                };
            }
            static $h = 652690;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":652690,"n":"Uncompressed","d":652690,"h":4295619986,"f":33},{"t":652690,"n":"Static","d":652690,"h":8590587282,"f":33},{"t":652690,"n":"Dynamic","d":652690,"h":12885554578,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":652690,"h":17180521874,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":652690}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.BlockType`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.InflaterState", ($self) => class InflaterState extends $.$spc.System.Enum
        {
            static ReadingHeader = 0;
            static ReadingBFinal = 2;
            static ReadingBType = 3;
            static ReadingNumLitCodes = 4;
            static ReadingNumDistCodes = 5;
            static ReadingNumCodeLengthCodes = 6;
            static ReadingCodeLengthCodes = 7;
            static ReadingTreeCodesBefore = 8;
            static ReadingTreeCodesAfter = 9;
            static DecodeTop = 10;
            static HaveInitialLength = 11;
            static HaveFullLength = 12;
            static HaveDistCode = 13;
            static UncompressedAligning = 15;
            static UncompressedByte1 = 16;
            static UncompressedByte2 = 17;
            static UncompressedByte3 = 18;
            static UncompressedByte4 = 19;
            static DecodingUncompressed = 20;
            static StartReadingFooter = 21;
            static ReadingFooter = 22;
            static VerifyingFooter = 23;
            static Done = 24;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ReadingHeader": 0n,
                    "ReadingBFinal": 2n,
                    "ReadingBType": 3n,
                    "ReadingNumLitCodes": 4n,
                    "ReadingNumDistCodes": 5n,
                    "ReadingNumCodeLengthCodes": 6n,
                    "ReadingCodeLengthCodes": 7n,
                    "ReadingTreeCodesBefore": 8n,
                    "ReadingTreeCodesAfter": 9n,
                    "DecodeTop": 10n,
                    "HaveInitialLength": 11n,
                    "HaveFullLength": 12n,
                    "HaveDistCode": 13n,
                    "UncompressedAligning": 15n,
                    "UncompressedByte1": 16n,
                    "UncompressedByte2": 17n,
                    "UncompressedByte3": 18n,
                    "UncompressedByte4": 19n,
                    "DecodingUncompressed": 20n,
                    "StartReadingFooter": 21n,
                    "ReadingFooter": 22n,
                    "VerifyingFooter": 23n,
                    "Done": 24n
                };
            }
            static $h = 1504658;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1504658,"n":"ReadingHeader","d":1504658,"h":4296471954,"f":33},{"t":1504658,"n":"ReadingBFinal","d":1504658,"h":8591439250,"f":33},{"t":1504658,"n":"ReadingBType","d":1504658,"h":12886406546,"f":33},{"t":1504658,"n":"ReadingNumLitCodes","d":1504658,"h":17181373842,"f":33},{"t":1504658,"n":"ReadingNumDistCodes","d":1504658,"h":21476341138,"f":33},{"t":1504658,"n":"ReadingNumCodeLengthCodes","d":1504658,"h":25771308434,"f":33},{"t":1504658,"n":"ReadingCodeLengthCodes","d":1504658,"h":30066275730,"f":33},{"t":1504658,"n":"ReadingTreeCodesBefore","d":1504658,"h":34361243026,"f":33},{"t":1504658,"n":"ReadingTreeCodesAfter","d":1504658,"h":38656210322,"f":33},{"t":1504658,"n":"DecodeTop","d":1504658,"h":42951177618,"f":33},{"t":1504658,"n":"HaveInitialLength","d":1504658,"h":47246144914,"f":33},{"t":1504658,"n":"HaveFullLength","d":1504658,"h":51541112210,"f":33},{"t":1504658,"n":"HaveDistCode","d":1504658,"h":55836079506,"f":33},{"t":1504658,"n":"UncompressedAligning","d":1504658,"h":60131046802,"f":33},{"t":1504658,"n":"UncompressedByte1","d":1504658,"h":64426014098,"f":33},{"t":1504658,"n":"UncompressedByte2","d":1504658,"h":68720981394,"f":33},{"t":1504658,"n":"UncompressedByte3","d":1504658,"h":73015948690,"f":33},{"t":1504658,"n":"UncompressedByte4","d":1504658,"h":77310915986,"f":33},{"t":1504658,"n":"DecodingUncompressed","d":1504658,"h":81605883282,"f":33},{"t":1504658,"n":"StartReadingFooter","d":1504658,"h":85900850578,"f":33},{"t":1504658,"n":"ReadingFooter","d":1504658,"h":90195817874,"f":33},{"t":1504658,"n":"VerifyingFooter","d":1504658,"h":94490785170,"f":33},{"t":1504658,"n":"Done","d":1504658,"h":98785752466,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1504658,"h":103080719762,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1504658}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.InflaterState`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.ZipVersionMadeByPlatform", ($self) => class ZipVersionMadeByPlatform extends $.$spc.System.Enum
        {
            static Windows = 0;
            static Unix = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Windows": 0n,
                    "Unix": 3n
                };
            }
            static $h = 4388242;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":4388242,"n":"Windows","d":4388242,"h":4299355538,"f":33},{"t":4388242,"n":"Unix","d":4388242,"h":8594322834,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4388242,"h":12889290130,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":4388242}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.ZipVersionMadeByPlatform`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.MatchState", ($self) => class MatchState extends $.$spc.System.Enum
        {
            static HasSymbol = 1;
            static HasMatch = 2;
            static HasSymbolAndMatch = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "HasSymbol": 1n,
                    "HasMatch": 2n,
                    "HasSymbolAndMatch": 3n
                };
            }
            static $h = 1635730;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1635730,"n":"HasSymbol","d":1635730,"h":4296603026,"f":33},{"t":1635730,"n":"HasMatch","d":1635730,"h":8591570322,"f":33},{"t":1635730,"n":"HasSymbolAndMatch","d":1635730,"h":12886537618,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1635730,"h":17181504914,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1635730}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.MatchState`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.CompressionLevel", ($self) => class CompressionLevel extends $.$spc.System.Enum
        {
            static Optimal = 0;
            static Fastest = 1;
            static NoCompression = 2;
            static SmallestSize = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Optimal": 0n,
                    "Fastest": 1n,
                    "NoCompression": 2n,
                    "SmallestSize": 3n
                };
            }
            static $h = 783762;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":783762,"n":"Optimal","d":783762,"h":4295751058,"f":33},{"t":783762,"n":"Fastest","d":783762,"h":8590718354,"f":33},{"t":783762,"n":"NoCompression","d":783762,"h":12885685650,"f":33},{"t":783762,"n":"SmallestSize","d":783762,"h":17180652946,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":783762,"h":21475620242,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":783762}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.CompressionLevel`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.CompressionMode", ($self) => class CompressionMode extends $.$spc.System.Enum
        {
            static Decompress = 0;
            static Compress = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Decompress": 0n,
                    "Compress": 1n
                };
            }
            static $h = 849298;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":849298,"n":"Decompress","d":849298,"h":4295816594,"f":33},{"t":849298,"n":"Compress","d":849298,"h":8590783890,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":849298,"h":12885751186,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":849298}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.CompressionMode`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.ZLibCompressionStrategy", ($self) => class ZLibCompressionStrategy extends $.$spc.System.Enum
        {
            static Default = 0;
            static Filtered = 1;
            static HuffmanOnly = 2;
            static RunLengthEncoding = 3;
            static Fixed = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "Filtered": 1n,
                    "HuffmanOnly": 2n,
                    "RunLengthEncoding": 3n,
                    "Fixed": 4n
                };
            }
            static $h = 4584850;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4584850,"n":"Default","d":4584850,"h":4299552146,"f":33},{"t":4584850,"n":"Filtered","d":4584850,"h":8594519442,"f":33},{"t":4584850,"n":"HuffmanOnly","d":4584850,"h":12889486738,"f":33},{"t":4584850,"n":"RunLengthEncoding","d":4584850,"h":17184454034,"f":33},{"t":4584850,"n":"Fixed","d":4584850,"h":21479421330,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4584850,"h":25774388626,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":4584850}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.ZLibCompressionStrategy`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZLibException", ($self) => class ZLibException extends $.$spc.System.IO.IOException
        {
            /*string?*/ _zlibErrorContext = null;
            /*string?*/ _zlibErrorMessage = null;
            /*ZLibNative.ErrorCode*/ _zlibErrorCode = 0;
            $ctor$14(/*string?*/ message, /*string?*/ zlibErrorContext, /*int*/ zlibErrorCode, /*string?*/ zlibErrorMessage)
            {
                super.$ctor$10(message);
                {
                    this._zlibErrorContext = zlibErrorContext;
                    this._zlibErrorCode = $.$cast(zlibErrorCode, $.$sic.System.IO.Compression.ZLibNative.ErrorCode);
                    this._zlibErrorMessage = zlibErrorMessage;
                }
                return this;
            }
            $ctor$15()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$12(message, innerException);
                {
                }
                return this;
            }
            $ctor$17(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$13(info, context);
                {
                    this._zlibErrorContext = info.GetString("zlibErrorContext");
                    this._zlibErrorCode = $.$cast(info.GetInt32("zlibErrorCode"), $.$sic.System.IO.Compression.ZLibNative.ErrorCode);
                    this._zlibErrorMessage = info.GetString("zlibErrorMessage");
                }
                return this;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ si, /*StreamingContext*/ context)
            {
                super.GetObjectData(si, context);
                si.AddValue$1("zlibErrorContext", this._zlibErrorContext);
                si.AddValue$8("zlibErrorCode", this._zlibErrorCode);
                si.AddValue$1("zlibErrorMessage", this._zlibErrorMessage);
            }
            //default member initializer
            constructor()
            {
                super();
                this._zlibErrorContext = $.$spc.System.String.Empty;
                this._zlibErrorMessage = $.$spc.System.String.Empty;
            }
            static $h = 4650386;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":60751873,"h":4650386}; }
            static get $b() { return $.$spc.System.IO.IOException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.Compression.ZLibException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices"))