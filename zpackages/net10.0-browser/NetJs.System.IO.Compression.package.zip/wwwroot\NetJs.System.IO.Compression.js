
(function ($global, $, $spc, $sc, $sdt, $sm, $spu, $st, $sr, $scc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Compression", 
    {"h":38267,"f":"System.IO.Compression","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Compression","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Compression","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sic.Interop", ($self) => class Interop
        {
            static $_Sys;
            static get Sys()
            {
                let $cls = $.$sic.Interop;
                return $cls.$_Sys ??= $asm.$ncls("$sic.Interop.Sys", ($self) => class Sys
                {
                    static /*int */ PathConf(/*string*/ path, /*PathConfName*/ name)
                    {
                        return -1;
                    }
                    static /*int */ FStat(/*SafeHandle*/ fd, /*out FileStatus*/ output)
                    {
                        output.$v = new $.$sic.Interop.Sys.FileStatus();
                        return -1;
                    }
                    static /*int */ Stat(/*string*/ path, /*out FileStatus*/ output)
                    {
                        output.$v = new $.$sic.Interop.Sys.FileStatus();
                        return -1;
                    }
                    static /*int */ LStat(/*string*/ path, /*out FileStatus*/ output)
                    {
                        output.$v = new $.$sic.Interop.Sys.FileStatus();
                        return -1;
                    }
                    static $_PathConfName;
                    static get PathConfName()
                    {
                        let $cls = $.$sic.Interop.Sys;
                        return $cls.$_PathConfName ??= $asm.$nstr("$sic.Interop.Sys.PathConfName", ($self) => class PathConfName extends $.$spc.System.Enum
                        {
                            static PC_LINK_MAX = 1;
                            static PC_MAX_CANON = 2;
                            static PC_MAX_INPUT = 3;
                            static PC_NAME_MAX = 4;
                            static PC_PATH_MAX = 5;
                            static PC_PIPE_BUF = 6;
                            static PC_CHOWN_RESTRICTED = 7;
                            static PC_NO_TRUNC = 8;
                            static PC_VDISABLE = 9;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "PC_LINK_MAX": 1n,
                                    "PC_MAX_CANON": 2n,
                                    "PC_MAX_INPUT": 3n,
                                    "PC_NAME_MAX": 4n,
                                    "PC_PATH_MAX": 5n,
                                    "PC_PIPE_BUF": 6n,
                                    "PC_CHOWN_RESTRICTED": 7n,
                                    "PC_NO_TRUNC": 8n,
                                    "PC_VDISABLE": 9n
                                };
                            }
                            static $h = 497019;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":497019,"n":"PC_LINK_MAX","d":497019,"h":4295464315,"f":33},{"t":497019,"n":"PC_MAX_CANON","d":497019,"h":8590431611,"f":33},{"t":497019,"n":"PC_MAX_INPUT","d":497019,"h":12885398907,"f":33},{"t":497019,"n":"PC_NAME_MAX","d":497019,"h":17180366203,"f":33},{"t":497019,"n":"PC_PATH_MAX","d":497019,"h":21475333499,"f":33},{"t":497019,"n":"PC_PIPE_BUF","d":497019,"h":25770300795,"f":33},{"t":497019,"n":"PC_CHOWN_RESTRICTED","d":497019,"h":30065268091,"f":33},{"t":497019,"n":"PC_NO_TRUNC","d":497019,"h":34360235387,"f":33},{"t":497019,"n":"PC_VDISABLE","d":497019,"h":38655202683,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":497019,"h":42950169979,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":234875,"h":497019}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.PathConfName`; }
                        }, $cls, ($v) => $cls.$_PathConfName = $v);
                    }
                    static $_FileStatus;
                    static get FileStatus()
                    {
                        let $cls = $.$sic.Interop.Sys;
                        return $cls.$_FileStatus ??= $asm.$nstr("$sic.Interop.Sys.FileStatus", ($self) => class FileStatus extends $.$spc.System.ValueType
                        {
                            /*FileStatusFlags*/  get Flags() { return this.$getField(0, $.$sic.Interop.Sys.FileStatusFlags); }
                            /*FileStatusFlags*/  set Flags(value) { this.$setField(0, $.$sic.Interop.Sys.FileStatusFlags, value); }
                            /*int*/  get Mode() { return this.$getField(4, $.$spc.System.Int32); }
                            /*int*/  set Mode(value) { this.$setField(4, $.$spc.System.Int32, value); }
                            /*uint*/  get Uid() { return this.$getField(8, $.$spc.System.UInt32); }
                            /*uint*/  set Uid(value) { this.$setField(8, $.$spc.System.UInt32, value); }
                            /*uint*/  get Gid() { return this.$getField(12, $.$spc.System.UInt32); }
                            /*uint*/  set Gid(value) { this.$setField(12, $.$spc.System.UInt32, value); }
                            /*long*/  get Size() { return this.$getField(16, $.$spc.System.Int64); }
                            /*long*/  set Size(value) { this.$setField(16, $.$spc.System.Int64, value); }
                            /*long*/  get ATime() { return this.$getField(24, $.$spc.System.Int64); }
                            /*long*/  set ATime(value) { this.$setField(24, $.$spc.System.Int64, value); }
                            /*long*/  get ATimeNsec() { return this.$getField(32, $.$spc.System.Int64); }
                            /*long*/  set ATimeNsec(value) { this.$setField(32, $.$spc.System.Int64, value); }
                            /*long*/  get MTime() { return this.$getField(40, $.$spc.System.Int64); }
                            /*long*/  set MTime(value) { this.$setField(40, $.$spc.System.Int64, value); }
                            /*long*/  get MTimeNsec() { return this.$getField(48, $.$spc.System.Int64); }
                            /*long*/  set MTimeNsec(value) { this.$setField(48, $.$spc.System.Int64, value); }
                            /*long*/  get CTime() { return this.$getField(56, $.$spc.System.Int64); }
                            /*long*/  set CTime(value) { this.$setField(56, $.$spc.System.Int64, value); }
                            /*long*/  get CTimeNsec() { return this.$getField(64, $.$spc.System.Int64); }
                            /*long*/  set CTimeNsec(value) { this.$setField(64, $.$spc.System.Int64, value); }
                            /*long*/  get BirthTime() { return this.$getField(72, $.$spc.System.Int64); }
                            /*long*/  set BirthTime(value) { this.$setField(72, $.$spc.System.Int64, value); }
                            /*long*/  get BirthTimeNsec() { return this.$getField(80, $.$spc.System.Int64); }
                            /*long*/  set BirthTimeNsec(value) { this.$setField(80, $.$spc.System.Int64, value); }
                            /*long*/  get Dev() { return this.$getField(88, $.$spc.System.Int64); }
                            /*long*/  set Dev(value) { this.$setField(88, $.$spc.System.Int64, value); }
                            /*long*/  get RDev() { return this.$getField(96, $.$spc.System.Int64); }
                            /*long*/  set RDev(value) { this.$setField(96, $.$spc.System.Int64, value); }
                            /*long*/  get Ino() { return this.$getField(104, $.$spc.System.Int64); }
                            /*long*/  set Ino(value) { this.$setField(104, $.$spc.System.Int64, value); }
                            /*uint*/  get UserFlags() { return this.$getField(112, $.$spc.System.UInt32); }
                            /*uint*/  set UserFlags(value) { this.$setField(112, $.$spc.System.UInt32, value); }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy.Flags = this.Flags;
                                copy.Mode = this.Mode;
                                copy.Uid = this.Uid;
                                copy.Gid = this.Gid;
                                copy.Size = this.Size;
                                copy.ATime = this.ATime;
                                copy.ATimeNsec = this.ATimeNsec;
                                copy.MTime = this.MTime;
                                copy.MTimeNsec = this.MTimeNsec;
                                copy.CTime = this.CTime;
                                copy.CTimeNsec = this.CTimeNsec;
                                copy.BirthTime = this.BirthTime;
                                copy.BirthTimeNsec = this.BirthTimeNsec;
                                copy.Dev = this.Dev;
                                copy.RDev = this.RDev;
                                copy.Ino = this.Ino;
                                copy.UserFlags = this.UserFlags;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this.Flags = 0;
                                this.Mode = 0;
                                this.Uid = 0;
                                this.Gid = 0;
                                this.Size = 0n;
                                this.ATime = 0n;
                                this.ATimeNsec = 0n;
                                this.MTime = 0n;
                                this.MTimeNsec = 0n;
                                this.CTime = 0n;
                                this.CTimeNsec = 0n;
                                this.BirthTime = 0n;
                                this.BirthTimeNsec = 0n;
                                this.Dev = 0n;
                                this.RDev = 0n;
                                this.Ino = 0n;
                                this.UserFlags = 0;
                            }
                            static $h = 300411;
                            static $z = 116;
                            static $f = 0b10100010000001010000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":365947,"n":"Flags","d":300411,"h":4295267707,"f":8},{"t":655361,"n":"Mode","d":300411,"h":8590235003,"f":8},{"t":720897,"n":"Uid","d":300411,"h":12885202299,"f":8},{"t":720897,"n":"Gid","d":300411,"h":17180169595,"f":8},{"t":917505,"n":"Size","d":300411,"h":21475136891,"f":8},{"t":917505,"n":"ATime","d":300411,"h":25770104187,"f":8},{"t":917505,"n":"ATimeNsec","d":300411,"h":30065071483,"f":8},{"t":917505,"n":"MTime","d":300411,"h":34360038779,"f":8},{"t":917505,"n":"MTimeNsec","d":300411,"h":38655006075,"f":8},{"t":917505,"n":"CTime","d":300411,"h":42949973371,"f":8},{"t":917505,"n":"CTimeNsec","d":300411,"h":47244940667,"f":8},{"t":917505,"n":"BirthTime","d":300411,"h":51539907963,"f":8},{"t":917505,"n":"BirthTimeNsec","d":300411,"h":55834875259,"f":8},{"t":917505,"n":"Dev","d":300411,"h":60129842555,"f":8},{"t":917505,"n":"RDev","d":300411,"h":64424809851,"f":8},{"t":917505,"n":"Ino","d":300411,"h":68719777147,"f":8},{"t":720897,"n":"UserFlags","d":300411,"h":73014744443,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":300411,"h":77309711739,"f":1}],"d":234875,"h":300411,"a":[{"t":109903873,"c":4404871169,"a":[{"v":0,"t":105381889}]}]}; }
                            static get $b() { return $.$spc.System.ValueType; }
                            static get $fullName() { return `Interop.Sys.FileStatus`; }
                        }, $cls, ($v) => $cls.$_FileStatus = $v);
                    }
                    static $_FileTypes;
                    static get FileTypes()
                    {
                        let $cls = $.$sic.Interop.Sys;
                        return $cls.$_FileTypes ??= $asm.$ncls("$sic.Interop.Sys.FileTypes", ($self) => class FileTypes
                        {
                            /*int*/ static S_IFMT = 61440;
                            /*int*/ static S_IFIFO = 4096;
                            /*int*/ static S_IFCHR = 8192;
                            /*int*/ static S_IFDIR = 16384;
                            /*int*/ static S_IFBLK = 24576;
                            /*int*/ static S_IFREG = 32768;
                            /*int*/ static S_IFLNK = 40960;
                            /*int*/ static S_IFSOCK = 49152;
                            static $h = 431483;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"S_IFMT","d":431483,"h":4295398779,"f":40},{"t":655361,"n":"S_IFIFO","d":431483,"h":8590366075,"f":40},{"t":655361,"n":"S_IFCHR","d":431483,"h":12885333371,"f":40},{"t":655361,"n":"S_IFDIR","d":431483,"h":17180300667,"f":40},{"t":655361,"n":"S_IFBLK","d":431483,"h":21475267963,"f":40},{"t":655361,"n":"S_IFREG","d":431483,"h":25770235259,"f":40},{"t":655361,"n":"S_IFLNK","d":431483,"h":30065202555,"f":40},{"t":655361,"n":"S_IFSOCK","d":431483,"h":34360169851,"f":40}],"d":234875,"h":431483}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `Interop.Sys.FileTypes`; }
                        }, $cls, ($v) => $cls.$_FileTypes = $v);
                    }
                    static $_FileStatusFlags;
                    static get FileStatusFlags()
                    {
                        let $cls = $.$sic.Interop.Sys;
                        return $cls.$_FileStatusFlags ??= $asm.$nstr("$sic.Interop.Sys.FileStatusFlags", ($self) => class FileStatusFlags extends $.$spc.System.Enum
                        {
                            static None = 0;
                            static HasBirthTime = 1;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "None": 0n,
                                    "HasBirthTime": 1n
                                };
                            }
                            static $h = 365947;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":365947,"n":"None","d":365947,"h":4295333243,"f":33},{"t":365947,"n":"HasBirthTime","d":365947,"h":8590300539,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":365947,"h":12885267835,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":234875,"h":365947,"a":[{"t":47644673,"c":4342611969}]}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.FileStatusFlags`; }
                        }, $cls, ($v) => $cls.$_FileStatusFlags = $v);
                    }
                    static $h = 234875;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"path","p":1310721},{"n":"name","p":497019}],"n":"PathConf","d":234875,"h":8590169467,"f":34,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_PathConf","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109576193},{"n":"output","p":300411,"f":2}],"n":"FStat","d":234875,"h":25770038651,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FStat","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"path","p":1310721},{"n":"output","p":300411,"f":2}],"n":"Stat","d":234875,"h":30065005947,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Stat","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"path","p":1310721},{"n":"output","p":300411,"f":2}],"n":"LStat","d":234875,"h":34359973243,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_LStat","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]}],"j":[497019,300411,431483,365947],"d":103803,"h":234875}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Sys`; }
                }, $cls, ($v) => $cls.$_Sys = $v);
            }
            static $_ZLib;
            static get ZLib()
            {
                let $cls = $.$sic.Interop;
                return $cls.$_ZLib ??= $asm.$ncls("$sic.Interop.ZLib", ($self) => class ZLib
                {
                    static /*ZLibNative.ErrorCode */ DeflateInit2_(/*ZLibNative.ZStream**/ stream, /*ZLibNative.CompressionLevel*/ level, /*ZLibNative.CompressionMethod*/ method, /*int*/ windowBits, /*int*/ memLevel, /*ZLibNative.CompressionStrategy*/ strategy)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*ZLibNative.ErrorCode */ Deflate(/*ZLibNative.ZStream**/ stream, /*ZLibNative.FlushCode*/ flush)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*ZLibNative.ErrorCode */ DeflateEnd(/*ZLibNative.ZStream**/ stream)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*ZLibNative.ErrorCode */ InflateInit2_(/*ZLibNative.ZStream**/ stream, /*int*/ windowBits)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*ZLibNative.ErrorCode */ InflateReset2_(/*ZLibNative.ZStream**/ stream, /*int*/ windowBits)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*ZLibNative.ErrorCode */ Inflate(/*ZLibNative.ZStream**/ stream, /*ZLibNative.FlushCode*/ flush)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*ZLibNative.ErrorCode */ InflateEnd(/*ZLibNative.ZStream**/ stream)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*uint */ crc32(/*uint*/ crc, /*byte**/ buffer, /*int*/ len)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static $h = 562555;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":4953467,"p":[{"n":"stream","p":0},{"n":"level","p":4756859},{"n":"method","p":4822395},{"n":"windowBits","p":655361},{"n":"memLevel","p":655361},{"n":"strategy","p":4887931}],"n":"DeflateInit2_","d":562555,"h":4295529851,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_DeflateInit2_","t":1310721}]}]},{"r":4953467,"p":[{"n":"stream","p":0},{"n":"flush","p":5019003}],"n":"Deflate","d":562555,"h":8590497147,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_Deflate","t":1310721}]}]},{"r":4953467,"p":[{"n":"stream","p":0}],"n":"DeflateEnd","d":562555,"h":12885464443,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_DeflateEnd","t":1310721}]}]},{"r":4953467,"p":[{"n":"stream","p":0},{"n":"windowBits","p":655361}],"n":"InflateInit2_","d":562555,"h":17180431739,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_InflateInit2_","t":1310721}]}]},{"r":4953467,"p":[{"n":"stream","p":0},{"n":"windowBits","p":655361}],"n":"InflateReset2_","d":562555,"h":21475399035,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_InflateReset2_","t":1310721}]}]},{"r":4953467,"p":[{"n":"stream","p":0},{"n":"flush","p":5019003}],"n":"Inflate","d":562555,"h":25770366331,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_Inflate","t":1310721}]}]},{"r":4953467,"p":[{"n":"stream","p":0}],"n":"InflateEnd","d":562555,"h":30065333627,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_InflateEnd","t":1310721}]}]},{"r":720897,"p":[{"n":"crc","p":720897},{"n":"buffer","p":0},{"n":"len","p":655361}],"n":"crc32","d":562555,"h":34360300923,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.IO.Compression.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"CompressionNative_Crc32","t":1310721}]}]}],"d":103803,"h":562555}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.ZLib`; }
                }, $cls, ($v) => $cls.$_ZLib = $v);
            }
            static $_Libraries;
            static get Libraries()
            {
                let $cls = $.$sic.Interop;
                return $cls.$_Libraries ??= $asm.$ncls("$sic.Interop.Libraries", ($self) => class Libraries
                {
                    /*string*/ static libc = null;
                    /*string*/ static SystemNative = null;
                    /*string*/ static NetSecurityNative = null;
                    /*string*/ static CryptoNative = null;
                    /*string*/ static CompressionNative = null;
                    /*string*/ static GlobalizationNative = null;
                    /*string*/ static IOPortsNative = null;
                    /*string*/ static HostPolicy = null;
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.libc = "libc";
                        }
                        {
                            this.SystemNative = "libSystem.Native";
                        }
                        {
                            this.NetSecurityNative = "libSystem.Net.Security.Native";
                        }
                        {
                            this.CryptoNative = "libSystem.Security.Cryptography.Native.OpenSsl";
                        }
                        {
                            this.CompressionNative = "libSystem.IO.Compression.Native";
                        }
                        {
                            this.GlobalizationNative = "libSystem.Globalization.Native";
                        }
                        {
                            this.IOPortsNative = "libSystem.IO.Ports.Native";
                        }
                        {
                            this.HostPolicy = "libhostpolicy";
                        }
                    }
                    static $h = 169339;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"libc","d":169339,"h":4295136635,"f":40},{"t":1310721,"n":"SystemNative","d":169339,"h":8590103931,"f":40},{"t":1310721,"n":"NetSecurityNative","d":169339,"h":12885071227,"f":40},{"t":1310721,"n":"CryptoNative","d":169339,"h":17180038523,"f":40},{"t":1310721,"n":"CompressionNative","d":169339,"h":21475005819,"f":40},{"t":1310721,"n":"GlobalizationNative","d":169339,"h":25769973115,"f":40},{"t":1310721,"n":"IOPortsNative","d":169339,"h":30064940411,"f":40},{"t":1310721,"n":"HostPolicy","d":169339,"h":34359907707,"f":40}],"d":103803,"h":169339}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Libraries`; }
                }, $cls, ($v) => $cls.$_Libraries = $v);
            }
            static $h = 103803;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"j":[234875,562555,169339],"h":103803}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipArchiveEntry", ($self) => class ZipArchiveEntry extends $.$spc.System.Object
        {
            /*ZipArchive*/ _archive = null;
            /*bool*/ _originallyInArchive = false;
            /*uint*/ _diskNumberStart = 0;
            /*ZipVersionMadeByPlatform*/ _versionMadeByPlatform = 0;
            /*ZipVersionNeededValues*/ _versionMadeBySpecification = 0;
            /*ZipVersionNeededValues*/ _versionToExtract = 0;
            /*BitFlagValues*/ _generalPurposeBitFlag = 0;
            /*bool*/ _isEncrypted = false;
            /*CompressionMethodValues*/ _storedCompressionMethod = 0;
            /*DateTimeOffset*/ _lastModified;
            /*long*/ _compressedSize = 0n;
            /*long*/ _uncompressedSize = 0n;
            /*long*/ _offsetOfLocalHeader = 0n;
            /*long?*/ _storedOffsetOfCompressedData = null;
            /*uint*/ _crc32 = 0;
            /*byte[][]?*/ _compressedBytes = null;
            /*MemoryStream?*/ _storedUncompressedData = null;
            /*bool*/ _currentlyOpenForWrite = false;
            /*bool*/ _everOpenedForWrite = false;
            /*Stream?*/ _outstandingWriteStream = null;
            /*uint*/ _externalFileAttr = 0;
            /*string*/ _storedEntryName = null;
            /*byte[]*/ _storedEntryNameBytes = null;
            /*List<ZipGenericExtraField>?*/ _cdUnknownExtraFields = null;
            /*byte[]?*/ _cdTrailingExtraFieldData = null;
            /*List<ZipGenericExtraField>?*/ _lhUnknownExtraFields = null;
            /*byte[]?*/ _lhTrailingExtraFieldData = null;
            /*byte[]*/ _fileComment = null;
            /*CompressionLevel*/ _compressionLevel = 0;
            $ctor$1(/*ZipArchive*/ archive, /*ZipCentralDirectoryFileHeader*/ cd)
            {
                super.$ctor();
                {
                    this._archive = archive;
                    this._originallyInArchive = true;
                    this.Changes = 0/*ZipArchive.ChangeState.Unchanged*/;
                    this._diskNumberStart = cd.DiskNumberStart;
                    this._versionMadeByPlatform = $.$cast(cd.VersionMadeByCompatibility, $.$sic.System.IO.Compression.ZipVersionMadeByPlatform);
                    this._versionMadeBySpecification = $.$cast(cd.VersionMadeBySpecification, $.$sic.System.IO.Compression.ZipVersionNeededValues);
                    this._versionToExtract = $.$cast(cd.VersionNeededToExtract, $.$sic.System.IO.Compression.ZipVersionNeededValues);
                    this._generalPurposeBitFlag = $.$cast(cd.GeneralPurposeBitFlag, $.$sic.System.IO.Compression.ZipArchiveEntry.BitFlagValues);
                    this._isEncrypted = (this._generalPurposeBitFlag & 1/*BitFlagValues.IsEncrypted*/) !== 0;
                    this.CompressionMethod = $.$cast(cd.CompressionMethod, $.$sic.System.IO.Compression.ZipArchiveEntry.CompressionMethodValues);
                    this._lastModified = new $.$spc.System.DateTimeOffset().$ctor$4($.$sic.System.IO.Compression.ZipHelper.DosTimeToDateTime(cd.LastModified));
                    this._compressedSize = cd.CompressedSize;
                    this._uncompressedSize = cd.UncompressedSize;
                    this._externalFileAttr = cd.ExternalFileAttributes;
                    this._offsetOfLocalHeader = cd.RelativeOffsetOfLocalHeader;
                    this._storedOffsetOfCompressedData = null;
                    this._crc32 = cd.Crc32;
                    this._compressedBytes = null;
                    this._storedUncompressedData = null;
                    this._currentlyOpenForWrite = false;
                    this._everOpenedForWrite = false;
                    this._outstandingWriteStream = null;
                    this._storedEntryNameBytes = cd.Filename;
                    this._storedEntryName = this.DecodeEntryString(this._storedEntryNameBytes);
                    this.DetectEntryNameVersion();
                    this._lhUnknownExtraFields = null;
                    this._cdUnknownExtraFields = cd.ExtraFields;
                    this._cdTrailingExtraFieldData = cd.TrailingExtraFieldData;
                    this._fileComment = cd.FileComment;
                    this._compressionLevel = $.$sic.System.IO.Compression.ZipArchiveEntry.MapCompressionLevel(this._generalPurposeBitFlag, this.CompressionMethod);
                }
                return this;
            }
            $ctor$2(/*ZipArchive*/ archive, /*string*/ entryName, /*CompressionLevel*/ compressionLevel)
            {
                this.$ctor$3(archive, entryName);
                {
                    this._compressionLevel = compressionLevel;
                    if (this._compressionLevel === 2/*CompressionLevel.NoCompression*/)
                    {
                        this.CompressionMethod = 0/*CompressionMethodValues.Stored*/;
                    }
                    this._generalPurposeBitFlag = $.$sic.System.IO.Compression.ZipArchiveEntry.MapDeflateCompressionOption(this._generalPurposeBitFlag, this._compressionLevel, this.CompressionMethod);
                }
                return this;
            }
            $ctor$3(/*ZipArchive*/ archive, /*string*/ entryName)
            {
                super.$ctor();
                {
                    this._archive = archive;
                    this._originallyInArchive = false;
                    this._diskNumberStart = 0;
                    this._versionMadeByPlatform = 3/*CurrentZipPlatform*/;
                    this._versionMadeBySpecification = 10/*ZipVersionNeededValues.Default*/;
                    this._versionToExtract = 10/*ZipVersionNeededValues.Default*/;
                    this._compressionLevel = 0/*CompressionLevel.Optimal*/;
                    this.CompressionMethod = 8/*CompressionMethodValues.Deflate*/;
                    this._generalPurposeBitFlag = $.$sic.System.IO.Compression.ZipArchiveEntry.MapDeflateCompressionOption(0, this._compressionLevel, this.CompressionMethod);
                    this._lastModified = $.$spc.System.DateTimeOffset.Now;
                    this._compressedSize = 0n;
                    this._uncompressedSize = 0n;
                    this._externalFileAttr = $.$spc.System.String.EndsWith$3.call(entryName, $.$spc.System.IO.Path.DirectorySeparatorChar) || $.$spc.System.String.EndsWith$3.call(entryName, $.$spc.System.IO.Path.AltDirectorySeparatorChar) ? 1106051072/*DefaultDirectoryExternalAttributes*/ : 2175008768/*DefaultFileExternalAttributes*/;
                    this._offsetOfLocalHeader = 0n;
                    this._storedOffsetOfCompressedData = null;
                    this._crc32 = 0;
                    this._compressedBytes = null;
                    this._storedUncompressedData = null;
                    this._currentlyOpenForWrite = false;
                    this._everOpenedForWrite = false;
                    this._outstandingWriteStream = null;
                    this.FullName = entryName;
                    this._cdUnknownExtraFields = null;
                    this._lhUnknownExtraFields = null;
                    this._fileComment = $.$spc.System.Array.Empty($.$spc.System.Byte);
                    if (this._storedEntryNameBytes.length > 65535/*ushort.MaxValue*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$sic.System.SR.EntryNamesTooLong);
                    }
                    if (this._archive.Mode === 1/*ZipArchiveMode.Create*/)
                    {
                        this._archive.AcquireArchiveStream(this);
                    }
                    this.Changes = 0/*ZipArchive.ChangeState.Unchanged*/;
                }
                return this;
            }
            /*ZipArchive */ get Archive()
            {
                return this._archive;
            }
            /*uint */ get Crc32()
            {
                return this._crc32;
            }
            /*bool */ get IsEncrypted()
            {
                return this._isEncrypted;
            }
            /*long */ get CompressedLength()
            {
                if (this._everOpenedForWrite)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.LengthAfterWrite);
                }
                return this._compressedSize;
            }
            /*int */ get ExternalAttributes()
            {
                return (this._externalFileAttr | 0);
            }
            /*int */ set ExternalAttributes(value)
            {
                this.ThrowIfInvalidArchive();
                this._externalFileAttr = (value >>> 0);
                this.Changes |= 1/*ZipArchive.ChangeState.FixedLengthMetadata*/;
            }
            /*string */ get Comment()
            {
                return this.DecodeEntryString(this._fileComment);
            }
            /*string */ set Comment(value)
            {
                /*bool*/ let isUTF8;
                this._fileComment = $.$sic.System.IO.Compression.ZipHelper.GetEncodedTruncatedBytesFromString(value, this._archive.EntryNameAndCommentEncoding, 65535/*ushort.MaxValue*/, $.$ref(() => isUTF8, ($v) => isUTF8 = $v, $.$spc.System.Boolean));
                if (isUTF8)
                {
                    this._generalPurposeBitFlag |= 2048/*BitFlagValues.UnicodeFileNameAndComment*/;
                }
                this.Changes |= 2/*ZipArchive.ChangeState.DynamicLengthMetadata*/;
            }
            /*string */ get FullName()
            {
                return this._storedEntryName;
            }
            /*string */ set FullName(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "FullName");
                /*bool*/ let isUTF8;
                this._storedEntryNameBytes = $.$sic.System.IO.Compression.ZipHelper.GetEncodedTruncatedBytesFromString(value, this._archive.EntryNameAndCommentEncoding, 0, $.$ref(() => isUTF8, ($v) => isUTF8 = $v, $.$spc.System.Boolean));
                this._storedEntryName = value;
                if (isUTF8)
                {
                    this._generalPurposeBitFlag |= 2048/*BitFlagValues.UnicodeFileNameAndComment*/;
                }
                else 
                {
                    this._generalPurposeBitFlag &= ~2048/*BitFlagValues.UnicodeFileNameAndComment*/;
                }
                this.DetectEntryNameVersion();
            }
            /*DateTimeOffset */ get LastWriteTime()
            {
                return this._lastModified;
            }
            /*DateTimeOffset */ set LastWriteTime(value)
            {
                this.ThrowIfInvalidArchive();
                if (this._archive.Mode === 0/*ZipArchiveMode.Read*/)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadOnlyArchive);
                }
                if (this._archive.Mode === 1/*ZipArchiveMode.Create*/ && this._everOpenedForWrite)
                {
                    throw new $.$spc.System.IO.IOException().$ctor$10($.$sic.System.SR.FrozenAfterWrite);
                }
                if (value.DateTime.Year < 1980/*ZipHelper.ValidZipDate_YearMin*/ || value.DateTime.Year > 2107/*ZipHelper.ValidZipDate_YearMax*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("value", $.$sic.System.SR.DateTimeOutOfRange);
                }
                this._lastModified = value;
                this.Changes |= 1/*ZipArchive.ChangeState.FixedLengthMetadata*/;
            }
            /*long */ get Length()
            {
                if (this._everOpenedForWrite)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.LengthAfterWrite);
                }
                return this._uncompressedSize;
            }
            /*string */ get Name()
            {
                return $.$sic.System.IO.Compression.ZipArchiveEntry.ParseFileName(this.FullName, this._versionMadeByPlatform);
            }
            /*ZipArchive.ChangeState*/ Changes = 0;
            /*bool */ get OriginallyInArchive()
            {
                return this._originallyInArchive;
            }
            /*long */ get OffsetOfLocalHeader()
            {
                return this._offsetOfLocalHeader;
            }
            /*void */ Delete()
            {
                if (this._archive === null)
                {
                    return;
                }
                if (this._currentlyOpenForWrite)
                {
                    throw new $.$spc.System.IO.IOException().$ctor$10($.$sic.System.SR.DeleteOpenEntry);
                }
                if (this._archive.Mode !== 2/*ZipArchiveMode.Update*/)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.DeleteOnlyInUpdate);
                }
                this._archive.ThrowIfDisposed();
                this._archive.RemoveEntry(this);
                this._archive = null;
                this.UnloadStreams();
            }
            /*Stream */ Open()
            {
                this.ThrowIfInvalidArchive();
                let $switch1 = this._archive.Mode;
                switch($switch1)
                {
                    case 0/*ZipArchiveMode.Read*/:
                    return this.OpenInReadMode(true);
                    case 1/*ZipArchiveMode.Create*/:
                    return this.OpenInWriteMode();
                    case 2/*ZipArchiveMode.Update*/:
                    default:
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._archive.Mode === 2/*ZipArchiveMode.Update*/, "_archive.Mode == ZipArchiveMode.Update");
                    return this.OpenInUpdateMode();
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.FullName;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sic.System.IO.Compression.ZipArchiveEntry.ToString.apply(this, arguments); }
            /*string */ DecodeEntryString(/*byte[]*/ entryStringBytes)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(entryStringBytes !== null, "entryStringBytes != null");
                /*Encoding*/ let readEntryStringEncoding = (this._generalPurposeBitFlag & 2048/*BitFlagValues.UnicodeFileNameAndComment*/) === 2048/*BitFlagValues.UnicodeFileNameAndComment*/ ? $.$spc.System.Text.Encoding.UTF8 : (this._archive?.EntryNameAndCommentEncoding ?? null) ?? $.$spc.System.Text.Encoding.UTF8;
                return readEntryStringEncoding.GetString$2(entryStringBytes);
            }
            /*bool*/ static s_allowLargeZipArchiveEntriesInUpdateMode = false;
            /*bool */ get EverOpenedForWrite()
            {
                return this._everOpenedForWrite;
            }
            /*long */ GetOffsetOfCompressedData()
            {
                if (this._storedOffsetOfCompressedData === null)
                {
                    this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader, 0/*SeekOrigin.Begin*/);
                    if (!$.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlock(this._archive.ArchiveStream))
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.LocalFileHeaderCorrupt);
                    }
                    this._storedOffsetOfCompressedData = this._archive.ArchiveStream.Position;
                }
                return $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(this._storedOffsetOfCompressedData);
            }
            /*MemoryStream */ GetUncompressedData()
            {
                if (this._storedUncompressedData === null)
                {
                    this._storedUncompressedData = new $.$spc.System.IO.MemoryStream().$ctor$4($.$cast(this._uncompressedSize, $.$spc.System.Int32));
                    if (this._originallyInArchive)
                    {
                        let decompressor = null;
                        try
                        {
                            decompressor = this.OpenInReadMode(false);
                            try
                            {
                                decompressor.CopyTo(this._storedUncompressedData);
                            }
                            catch($e)
                            {
                                this._storedUncompressedData.Dispose();
                                this._storedUncompressedData = null;
                                this._currentlyOpenForWrite = false;
                                this._everOpenedForWrite = false;
                                throw $e;
                            }
                        }
                        finally
                        {
                            decompressor?.System$IDisposable$Dispose();
                        }
                    }
                    if (this.CompressionMethod !== 0/*CompressionMethodValues.Stored*/)
                    {
                        this.CompressionMethod = 8/*CompressionMethodValues.Deflate*/;
                    }
                }
                return this._storedUncompressedData;
            }
            /*CompressionMethodValues */ get CompressionMethod()
            {
                return this._storedCompressionMethod;
            }
            /*CompressionMethodValues */ set CompressionMethod(value)
            {
                if (value === 8/*CompressionMethodValues.Deflate*/)
                {
                    this.VersionToExtractAtLeast(20/*ZipVersionNeededValues.Deflate*/);
                }
                else if (value === 9/*CompressionMethodValues.Deflate64*/)
                {
                    this.VersionToExtractAtLeast(21/*ZipVersionNeededValues.Deflate64*/);
                }
                this._storedCompressionMethod = value;
            }
            /*void */ WriteAndFinishLocalEntry(/*bool*/ forceWrite)
            {
                this.CloseStreams();
                this.WriteLocalFileHeaderAndDataIfNeeded(forceWrite);
                this.UnloadStreams();
            }
            /*bool */ WriteCentralDirectoryFileHeaderInitialize(/*bool*/ forceWrite, /*out Zip64ExtraField?*/ zip64ExtraField, /*out uint*/ compressedSizeTruncated, /*out uint*/ uncompressedSizeTruncated, /*out ushort*/ extraFieldLength, /*out uint*/ offsetOfLocalHeaderTruncated)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._storedEntryNameBytes.length <= 65535/*ushort.MaxValue*/, "_storedEntryNameBytes.Length <= ushort.MaxValue");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._fileComment.length <= 65535/*ushort.MaxValue*/, "_fileComment.Length <= ushort.MaxValue");
                zip64ExtraField.$v = null;
                if (this.AreSizesTooLarge)
                {
                    compressedSizeTruncated.$v = 4294967295/*ZipHelper.Mask32Bit*/;
                    uncompressedSizeTruncated.$v = 4294967295/*ZipHelper.Mask32Bit*/;
                    zip64ExtraField.$v = (() =>
                    {
                        //new $.$sic.System.IO.Compression.Zip64ExtraField()
                        const $t1 = $.$sic.System.IO.Compression.Zip64ExtraField;
                        const $i1 = new $t1();
                        $i1.CompressedSize = this._compressedSize;
                        $i1.UncompressedSize = this._uncompressedSize;
                        return $i1;
                    })();
                }
                else 
                {
                    compressedSizeTruncated.$v = $.$cast(this._compressedSize, $.$spc.System.UInt32);
                    uncompressedSizeTruncated.$v = $.$cast(this._uncompressedSize, $.$spc.System.UInt32);
                }
                if (this.IsOffsetTooLarge)
                {
                    offsetOfLocalHeaderTruncated.$v = 4294967295/*ZipHelper.Mask32Bit*/;
                    zip64ExtraField.$v ??= new $.$sic.System.IO.Compression.Zip64ExtraField().$ctor$1();
                    zip64ExtraField.$v.LocalHeaderOffset = this._offsetOfLocalHeader;
                }
                else 
                {
                    offsetOfLocalHeaderTruncated.$v = $.$cast(this._offsetOfLocalHeader, $.$spc.System.UInt32);
                }
                if (zip64ExtraField.$v !== null)
                {
                    this.VersionToExtractAtLeast(45/*ZipVersionNeededValues.Zip64*/);
                }
                const $t1 = this._cdTrailingExtraFieldData;
                /*int*/ let currExtraFieldDataLength = $.$sic.System.IO.Compression.ZipGenericExtraField.TotalSize(this._cdUnknownExtraFields, $.$ifnn($t1, ($t) => $t.length) ?? 0);
                /*int*/ let bigExtraFieldLength = (((zip64ExtraField.$v !== null ? zip64ExtraField.$v.TotalSize : 0) + currExtraFieldDataLength) | 0);
                if (bigExtraFieldLength > 65535/*ushort.MaxValue*/)
                {
                    extraFieldLength.$v = $.$cast((zip64ExtraField.$v !== null ? zip64ExtraField.$v.TotalSize : 0), $.$spc.System.UInt16);
                    this._cdUnknownExtraFields = null;
                }
                else 
                {
                    extraFieldLength.$v = $.$cast(bigExtraFieldLength, $.$spc.System.UInt16);
                }
                if (this._originallyInArchive && this.Changes === 0/*ZipArchive.ChangeState.Unchanged*/ && !forceWrite)
                {
                    /*long*/ let centralDirectoryHeaderLength = BigInt(((((((46/*ZipCentralDirectoryFileHeader.FieldLocations.DynamicData*/ + this._storedEntryNameBytes.length) | 0) + (zip64ExtraField.$v !== null ? zip64ExtraField.$v.TotalSize : 0)) | 0) + currExtraFieldDataLength) | 0) + this._fileComment.length);
                    this._archive.ArchiveStream.Seek(centralDirectoryHeaderLength, 1/*SeekOrigin.Current*/);
                    return false;
                }
                return true;
            }
            /*void */ WriteCentralDirectoryFileHeaderPrepare(/*Span<byte>*/ cdStaticHeader, /*uint*/ compressedSizeTruncated, /*uint*/ uncompressedSizeTruncated, /*ushort*/ extraFieldLength, /*uint*/ offsetOfLocalHeaderTruncated)
            {
                let $t1 = cdStaticHeader;
                $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.SignatureConstantBytes.CopyTo($t1.Slice$1(0/*ZipCentralDirectoryFileHeader.FieldLocations.Signature*/, $t1.Length - 0/*ZipCentralDirectoryFileHeader.FieldLocations.Signature*/));
                cdStaticHeader.get_Item(4/*ZipCentralDirectoryFileHeader.FieldLocations.VersionMadeBySpecification*/).$v = $.$cast(this._versionMadeBySpecification, $.$spc.System.Byte);
                cdStaticHeader.get_Item(5/*ZipCentralDirectoryFileHeader.FieldLocations.VersionMadeByCompatibility*/).$v = 3/*CurrentZipPlatform*/;
                let $t2 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t2.Slice$1(6/*ZipCentralDirectoryFileHeader.FieldLocations.VersionNeededToExtract*/, $t2.Length - 6/*ZipCentralDirectoryFileHeader.FieldLocations.VersionNeededToExtract*/), this._versionToExtract);
                let $t3 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t3.Slice$1(8/*ZipCentralDirectoryFileHeader.FieldLocations.GeneralPurposeBitFlags*/, $t3.Length - 8/*ZipCentralDirectoryFileHeader.FieldLocations.GeneralPurposeBitFlags*/), this._generalPurposeBitFlag);
                let $t4 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t4.Slice$1(10/*ZipCentralDirectoryFileHeader.FieldLocations.CompressionMethod*/, $t4.Length - 10/*ZipCentralDirectoryFileHeader.FieldLocations.CompressionMethod*/), this.CompressionMethod);
                let $t5 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t5.Slice$1(12/*ZipCentralDirectoryFileHeader.FieldLocations.LastModified*/, $t5.Length - 12/*ZipCentralDirectoryFileHeader.FieldLocations.LastModified*/), $.$sic.System.IO.Compression.ZipHelper.DateTimeToDosTime(this._lastModified.DateTime));
                let $t6 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t6.Slice$1(16/*ZipCentralDirectoryFileHeader.FieldLocations.Crc32*/, $t6.Length - 16/*ZipCentralDirectoryFileHeader.FieldLocations.Crc32*/), this._crc32);
                let $t7 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t7.Slice$1(20/*ZipCentralDirectoryFileHeader.FieldLocations.CompressedSize*/, $t7.Length - 20/*ZipCentralDirectoryFileHeader.FieldLocations.CompressedSize*/), compressedSizeTruncated);
                let $t8 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t8.Slice$1(24/*ZipCentralDirectoryFileHeader.FieldLocations.UncompressedSize*/, $t8.Length - 24/*ZipCentralDirectoryFileHeader.FieldLocations.UncompressedSize*/), uncompressedSizeTruncated);
                let $t9 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t9.Slice$1(28/*ZipCentralDirectoryFileHeader.FieldLocations.FilenameLength*/, $t9.Length - 28/*ZipCentralDirectoryFileHeader.FieldLocations.FilenameLength*/), $.$cast(this._storedEntryNameBytes.length, $.$spc.System.UInt16));
                let $t10 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t10.Slice$1(30/*ZipCentralDirectoryFileHeader.FieldLocations.ExtraFieldLength*/, $t10.Length - 30/*ZipCentralDirectoryFileHeader.FieldLocations.ExtraFieldLength*/), extraFieldLength);
                let $t11 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t11.Slice$1(32/*ZipCentralDirectoryFileHeader.FieldLocations.FileCommentLength*/, $t11.Length - 32/*ZipCentralDirectoryFileHeader.FieldLocations.FileCommentLength*/), $.$cast(this._fileComment.length, $.$spc.System.UInt16));
                let $t12 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t12.Slice$1(34/*ZipCentralDirectoryFileHeader.FieldLocations.DiskNumberStart*/, $t12.Length - 34/*ZipCentralDirectoryFileHeader.FieldLocations.DiskNumberStart*/), 0);
                let $t13 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t13.Slice$1(36/*ZipCentralDirectoryFileHeader.FieldLocations.InternalFileAttributes*/, $t13.Length - 36/*ZipCentralDirectoryFileHeader.FieldLocations.InternalFileAttributes*/), 0);
                let $t14 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t14.Slice$1(38/*ZipCentralDirectoryFileHeader.FieldLocations.ExternalFileAttributes*/, $t14.Length - 38/*ZipCentralDirectoryFileHeader.FieldLocations.ExternalFileAttributes*/), this._externalFileAttr);
                let $t15 = cdStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t15.Slice$1(42/*ZipCentralDirectoryFileHeader.FieldLocations.RelativeOffsetOfLocalHeader*/, $t15.Length - 42/*ZipCentralDirectoryFileHeader.FieldLocations.RelativeOffsetOfLocalHeader*/), offsetOfLocalHeaderTruncated);
            }
            /*void */ WriteCentralDirectoryFileHeader(/*bool*/ forceWrite)
            {
                /*Zip64ExtraField?*/ let zip64ExtraField;
                /*uint*/ let compressedSizeTruncated;
                /*uint*/ let uncompressedSizeTruncated;
                /*ushort*/ let extraFieldLength;
                /*uint*/ let offsetOfLocalHeaderTruncated;
                if (this.WriteCentralDirectoryFileHeaderInitialize(forceWrite, $.$ref(() => zip64ExtraField, ($v) => zip64ExtraField = $v, $.$sic.System.IO.Compression.Zip64ExtraField), $.$ref(() => compressedSizeTruncated, ($v) => compressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeTruncated, ($v) => uncompressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => extraFieldLength, ($v) => extraFieldLength = $v, $.$spc.System.UInt16), $.$ref(() => offsetOfLocalHeaderTruncated, ($v) => offsetOfLocalHeaderTruncated = $v, $.$spc.System.UInt32)))
                {
                    /*Span<byte>*/ let cdStaticHeader = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/, null);
                    this.WriteCentralDirectoryFileHeaderPrepare(cdStaticHeader, compressedSizeTruncated, uncompressedSizeTruncated, extraFieldLength, offsetOfLocalHeaderTruncated);
                    this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(cdStaticHeader));
                    this._archive.ArchiveStream.Write$1($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this._storedEntryNameBytes));
                    zip64ExtraField?.WriteBlock(this._archive.ArchiveStream);
                    $.$sic.System.IO.Compression.ZipGenericExtraField.WriteAllBlocks(this._cdUnknownExtraFields, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this._cdTrailingExtraFieldData ?? $.$spc.System.Array.Empty($.$spc.System.Byte)), this._archive.ArchiveStream);
                    if (this._fileComment.length > 0)
                    {
                        this._archive.ArchiveStream.Write$1($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this._fileComment));
                    }
                }
            }
            /*void */ LoadLocalHeaderExtraFieldIfNeeded()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsOpenable(false, true, $.$discardRef()), "IsOpenable(false, true, out _)");
                if (this._originallyInArchive)
                {
                    this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader, 0/*SeekOrigin.Begin*/);
                    this._lhUnknownExtraFields = $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFields(this._archive.ArchiveStream, $.$ref(() => this._lhTrailingExtraFieldData, ($v) => this._lhTrailingExtraFieldData = $v, $.$typeArray($.$spc.System.Byte)));
                }
            }
            /*byte[][] */ LoadCompressedBytesIfNeededInitialize(/*out int*/ maxSingleBufferSize)
            {
                maxSingleBufferSize.$v = $.$spc.System.Array.MaxLength;
                /*byte[][]*/ let compressedBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$spc.System.Byte)), null, [(this._compressedSize / BigInt(maxSingleBufferSize.$v)) + 1n], null);
                for(/*int*/ let i = 0; i < ((compressedBytes.length - 1) | 0); i++)
                {
                    $.$spc.System.Array.$WriteT1.call(compressedBytes, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [maxSingleBufferSize.$v], null), i);
                }
                $.$spc.System.Array.$WriteT1.call(compressedBytes, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [this._compressedSize % BigInt(maxSingleBufferSize.$v)], null), ((compressedBytes.length - 1) | 0));
                return compressedBytes;
            }
            /*void */ LoadCompressedBytesIfNeeded()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsOpenable(false, true, $.$discardRef()), "IsOpenable(false, true, out _)");
                if (!this._everOpenedForWrite && this._originallyInArchive)
                {
                    /*int*/ let maxSingleBufferSize;
                    this._compressedBytes = this.LoadCompressedBytesIfNeededInitialize($.$ref(() => maxSingleBufferSize, ($v) => maxSingleBufferSize = $v, $.$spc.System.Int32));
                    this._archive.ArchiveStream.Seek(this.GetOffsetOfCompressedData(), 0/*SeekOrigin.Begin*/);
                    for(/*int*/ let i = 0; i < ((this._compressedBytes.length - 1) | 0); i++)
                    {
                        this._archive.ArchiveStream.ReadAtLeast($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit($.$spc.System.Array.$ReadT1.call(this._compressedBytes, i)), maxSingleBufferSize, true);
                    }
                    this._archive.ArchiveStream.ReadAtLeast($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit($.$spc.System.Array.$ReadT1.call(this._compressedBytes, ((this._compressedBytes.length - 1) | 0))), $.$cast((this._compressedSize % BigInt(maxSingleBufferSize)), $.$spc.System.Int32), true);
                }
            }
            /*void */ ThrowIfNotOpenable(/*bool*/ needToUncompress, /*bool*/ needToLoadIntoMemory)
            {
                /*string?*/ let message;
                if (!this.IsOpenable(needToUncompress, needToLoadIntoMemory, $.$ref(() => message, ($v) => message = $v, $.$spc.System.String)))
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10(message);
                }
            }
            /*void */ DetectEntryNameVersion()
            {
                if ($.$spc.System.String.op_Equality($.$sic.System.IO.Compression.ZipArchiveEntry.ParseFileName(this._storedEntryName, this._versionMadeByPlatform), ""))
                {
                    this.VersionToExtractAtLeast(20/*ZipVersionNeededValues.ExplicitDirectory*/);
                }
            }
            /*CheckSumAndSizeWriteStream */ GetDataCompressor(/*Stream*/ backingStream, /*bool*/ leaveBackingStreamOpen, /*EventHandler?*/ onClose)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.CompressionMethod === 8/*CompressionMethodValues.Deflate*/ || this.CompressionMethod === 0/*CompressionMethodValues.Stored*/, "CompressionMethod == CompressionMethodValues.Deflate\r\n                || CompressionMethod == CompressionMethodValues.Stored");
                /*bool*/ let isIntermediateStream = true;
                /*Stream*/ let compressorStream;
                switch(this.CompressionMethod)
                {
                    case 0/*CompressionMethodValues.Stored*/:
                    compressorStream = backingStream;
                    isIntermediateStream = false;
                    break;
                    case 8/*CompressionMethodValues.Deflate*/:
                    case 9/*CompressionMethodValues.Deflate64*/:
                    default:
                    compressorStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$7(backingStream, this._compressionLevel, leaveBackingStreamOpen);
                    break;
                }
                /*bool*/ let leaveCompressorStreamOpenOnClose = leaveBackingStreamOpen && !isIntermediateStream;
                /*var*/ let checkSumStream = new $.$sic.System.IO.Compression.CheckSumAndSizeWriteStream().$ctor$3(compressorStream, backingStream, leaveCompressorStreamOpenOnClose, this, onClose, new ($.$spc.System.Action$$$$$$$($.$spc.System.Int64, $.$spc.System.Int64, $.$spc.System.UInt32, $.$spc.System.IO.Stream, $.$sic.System.IO.Compression.ZipArchiveEntry, $.$spc.System.EventHandler))().$ctor(this,  (/*long*/ initialPosition, /*long*/ currentPosition, /*uint*/ checkSum, /*Stream*/ backing, /*ZipArchiveEntry*/ thisRef, /*EventHandler?*/ closeHandler) =>
                {
                    thisRef._crc32 = checkSum;
                    thisRef._uncompressedSize = currentPosition;
                    thisRef._compressedSize = backing.Position - initialPosition;
                    closeHandler?.Invoke(thisRef, $.$spc.System.EventArgs.Empty);
                }));
                return checkSumStream;
            }
            /*Stream */ GetDataDecompressor(/*Stream*/ compressedStreamToRead)
            {
                /*Stream?*/ let uncompressedStream;
                switch(this.CompressionMethod)
                {
                    case 8/*CompressionMethodValues.Deflate*/:
                    uncompressedStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$3(compressedStreamToRead, 0/*CompressionMode.Decompress*/, this._uncompressedSize);
                    break;
                    case 9/*CompressionMethodValues.Deflate64*/:
                    uncompressedStream = new $.$sic.System.IO.Compression.DeflateManagedStream().$ctor$3(compressedStreamToRead, 9/*CompressionMethodValues.Deflate64*/, this._uncompressedSize);
                    break;
                    case 0/*CompressionMethodValues.Stored*/:
                    default:
                    $.$spc.System.Diagnostics.Debug.Assert$1(this.CompressionMethod === 0/*CompressionMethodValues.Stored*/, "CompressionMethod == CompressionMethodValues.Stored");
                    uncompressedStream = compressedStreamToRead;
                    break;
                }
                return uncompressedStream;
            }
            /*Stream */ OpenInReadMode(/*bool*/ checkOpenable)
            {
                if (checkOpenable)
                {
                    this.ThrowIfNotOpenable(true, false);
                }
                return this.OpenInReadModeGetDataCompressor(this.GetOffsetOfCompressedData());
            }
            /*Stream */ OpenInReadModeGetDataCompressor(/*long*/ offsetOfCompressedData)
            {
                /*Stream*/ let compressedStream = new $.$sic.System.IO.Compression.SubReadStream().$ctor$3(this._archive.ArchiveStream, offsetOfCompressedData, this._compressedSize);
                return this.GetDataDecompressor(compressedStream);
            }
            /*WrappedStream */ OpenInWriteMode()
            {
                if (this._everOpenedForWrite)
                {
                    throw new $.$spc.System.IO.IOException().$ctor$10($.$sic.System.SR.CreateModeWriteOnceAndOneEntryAtATime);
                }
                this._archive.DebugAssertIsStillArchiveStreamOwner(this);
                this._everOpenedForWrite = true;
                this.Changes |= 4/*ZipArchive.ChangeState.StoredData*/;
                /*CheckSumAndSizeWriteStream*/ let crcSizeStream = this.GetDataCompressor(this._archive.ArchiveStream, true, new $.$spc.System.EventHandler().$ctor(this,  (/*object?*/ o, /*EventArgs*/ e) =>
                {
                    /*var*/ let entry = $.$cast(o, $.$sic.System.IO.Compression.ZipArchiveEntry);
                    entry._archive.ReleaseArchiveStream(entry);
                    entry._outstandingWriteStream = null;
                }));
                this._outstandingWriteStream = new $.$sic.System.IO.Compression.ZipArchiveEntry.DirectToArchiveWriterStream().$ctor$3(crcSizeStream, this);
                return new $.$sic.System.IO.Compression.WrappedStream().$ctor$3(this._outstandingWriteStream, true);
            }
            /*WrappedStream */ OpenInUpdateMode()
            {
                if (this._currentlyOpenForWrite)
                {
                    throw new $.$spc.System.IO.IOException().$ctor$10($.$sic.System.SR.UpdateModeOneStream);
                }
                this.ThrowIfNotOpenable(true, true);
                this._everOpenedForWrite = true;
                this.Changes |= 4/*ZipArchive.ChangeState.StoredData*/;
                this._currentlyOpenForWrite = true;
                /*Stream*/ let uncompressedData = this.GetUncompressedData();
                uncompressedData.Seek(0n, 0/*SeekOrigin.Begin*/);
                return new $.$sic.System.IO.Compression.WrappedStream().$ctor$5(uncompressedData, this, new ($.$spc.System.Action$$($.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor(this,  (/*thisRef*/ thisRef) =>
                {
                    thisRef._currentlyOpenForWrite = false;
                }));
            }
            /*bool */ IsOpenable(/*bool*/ needToUncompress, /*bool*/ needToLoadIntoMemory, /*out string?*/ message)
            {
                message.$v = null;
                if (this._originallyInArchive)
                {
                    if (!this.IsOpenableInitialVerifications(needToUncompress, message))
                    {
                        return false;
                    }
                    if (!$.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlock(this._archive.ArchiveStream))
                    {
                        message.$v = $.$sic.System.SR.LocalFileHeaderCorrupt;
                        return false;
                    }
                    /*long*/ let offsetOfCompressedData = this.GetOffsetOfCompressedData();
                    if (!this.IsOpenableFinalVerifications(needToLoadIntoMemory, offsetOfCompressedData, message))
                    {
                        return false;
                    }
                    return true;
                }
                return true;
            }
            /*bool */ IsOpenableInitialVerifications(/*bool*/ needToUncompress, /*out string?*/ message)
            {
                message.$v = null;
                if (needToUncompress)
                {
                    if (this.CompressionMethod !== 0/*CompressionMethodValues.Stored*/ && this.CompressionMethod !== 8/*CompressionMethodValues.Deflate*/ && this.CompressionMethod !== 9/*CompressionMethodValues.Deflate64*/)
                    {
                        message.$v = (() =>
                        {
                            if ((this.CompressionMethod === 12/*CompressionMethodValues.BZip2*/) || (this.CompressionMethod === 14/*CompressionMethodValues.LZMA*/))
                            {
                                return $.$sic.System.SR.Format($.$sic.System.SR.UnsupportedCompressionMethod, $.$spc.System.Enum.ToStringT($.$sic.System.IO.Compression.ZipArchiveEntry.CompressionMethodValues, $.$spc.System.UInt16, this.CompressionMethod));
                            }
                            return $.$sic.System.SR.UnsupportedCompression;
                        })();
                        return false;
                    }
                }
                if (this._diskNumberStart !== this._archive.NumberOfThisDisk)
                {
                    message.$v = $.$sic.System.SR.SplitSpanned;
                    return false;
                }
                if (this._offsetOfLocalHeader > this._archive.ArchiveStream.Length)
                {
                    message.$v = $.$sic.System.SR.LocalFileHeaderCorrupt;
                    return false;
                }
                this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader, 0/*SeekOrigin.Begin*/);
                return true;
            }
            /*bool */ IsOpenableFinalVerifications(/*bool*/ needToLoadIntoMemory, /*long*/ offsetOfCompressedData, /*out string?*/ message)
            {
                message.$v = null;
                if (offsetOfCompressedData + this._compressedSize > this._archive.ArchiveStream.Length)
                {
                    message.$v = $.$sic.System.SR.LocalFileHeaderCorrupt;
                    return false;
                }
                if (needToLoadIntoMemory)
                {
                    if (this._compressedSize > BigInt(2147483647/*int.MaxValue*/))
                    {
                        if (!$.$sic.System.IO.Compression.ZipArchiveEntry.s_allowLargeZipArchiveEntriesInUpdateMode)
                        {
                            message.$v = $.$sic.System.SR.EntryTooLarge;
                            return false;
                        }
                    }
                }
                return true;
            }
            /*bool */ get AreSizesTooLarge()
            {
                return this._compressedSize > BigInt(4294967295/*uint.MaxValue*/) || this._uncompressedSize > BigInt(4294967295/*uint.MaxValue*/);
            }
            static /*CompressionLevel */ MapCompressionLevel(/*BitFlagValues*/ generalPurposeBitFlag, /*CompressionMethodValues*/ compressionMethod)
            {
                if (compressionMethod === 8/*CompressionMethodValues.Deflate*/ || compressionMethod === 9/*CompressionMethodValues.Deflate64*/)
                {
                    return (() =>
                    {
                        let $switch1 = ($.$cast(generalPurposeBitFlag, $.$spc.System.Int32) & 6);
                        if ($switch1 === 0)
                        {
                            return 0/*CompressionLevel.Optimal*/;
                        }
                        if ($switch1 === 2)
                        {
                            return 3/*CompressionLevel.SmallestSize*/;
                        }
                        if ($switch1 === 4)
                        {
                            return 1/*CompressionLevel.Fastest*/;
                        }
                        if ($switch1 === 6)
                        {
                            return 1/*CompressionLevel.Fastest*/;
                        }
                        return 0/*CompressionLevel.Optimal*/;
                    })();
                }
                else 
                {
                    return 2/*CompressionLevel.NoCompression*/;
                }
            }
            static /*BitFlagValues */ MapDeflateCompressionOption(/*BitFlagValues*/ generalPurposeBitFlag, /*CompressionLevel*/ compressionLevel, /*CompressionMethodValues*/ compressionMethod)
            {
                /*ushort*/ let deflateCompressionOptions = $.$cast((compressionMethod === 8/*CompressionMethodValues.Deflate*/ || compressionMethod === 9/*CompressionMethodValues.Deflate64*/ ? (() =>
                {
                    if (compressionLevel === 0/*CompressionLevel.Optimal*/)
                    {
                        return 0;
                    }
                    if (compressionLevel === 3/*CompressionLevel.SmallestSize*/)
                    {
                        return 2;
                    }
                    if (compressionLevel === 1/*CompressionLevel.Fastest*/)
                    {
                        return 6;
                    }
                    if (compressionLevel === 2/*CompressionLevel.NoCompression*/)
                    {
                        return 6;
                    }
                    return 0;
                })() : 0), $.$spc.System.UInt16);
                return $.$cast((($.$cast(generalPurposeBitFlag, $.$spc.System.Int32) & ~6) | deflateCompressionOptions), $.$sic.System.IO.Compression.ZipArchiveEntry.BitFlagValues);
            }
            /*bool */ get IsOffsetTooLarge()
            {
                return this._offsetOfLocalHeader > BigInt(4294967295/*uint.MaxValue*/);
            }
            /*bool */ get ShouldUseZIP64()
            {
                return this.AreSizesTooLarge || this.IsOffsetTooLarge;
            }
            /*bool */ WriteLocalFileHeaderInitialize(/*bool*/ isEmptyFile, /*bool*/ forceWrite, /*out Zip64ExtraField?*/ zip64ExtraField, /*out uint*/ compressedSizeTruncated, /*out uint*/ uncompressedSizeTruncated, /*out ushort*/ extraFieldLength)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._storedEntryNameBytes.length <= 65535/*ushort.MaxValue*/, "_storedEntryNameBytes.Length <= ushort.MaxValue");
                zip64ExtraField.$v = null;
                this._offsetOfLocalHeader = this._archive.ArchiveStream.Position;
                if (isEmptyFile)
                {
                    this.CompressionMethod = 0/*CompressionMethodValues.Stored*/;
                    compressedSizeTruncated.$v = 0;
                    uncompressedSizeTruncated.$v = 0;
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._compressedSize === 0n, "_compressedSize == 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._uncompressedSize === 0n, "_uncompressedSize == 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._crc32 === 0, "_crc32 == 0");
                }
                else 
                {
                    if (this._archive.Mode === 1/*ZipArchiveMode.Create*/ && this._archive.ArchiveStream.CanSeek === false)
                    {
                        this._generalPurposeBitFlag |= 8/*BitFlagValues.DataDescriptor*/;
                        compressedSizeTruncated.$v = 0;
                        uncompressedSizeTruncated.$v = 0;
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._crc32 === 0, "_crc32 == 0");
                    }
                    else 
                    {
                        this._generalPurposeBitFlag &= ~8/*BitFlagValues.DataDescriptor*/;
                        if (this.ShouldUseZIP64)
                        {
                            compressedSizeTruncated.$v = 4294967295/*ZipHelper.Mask32Bit*/;
                            uncompressedSizeTruncated.$v = 4294967295/*ZipHelper.Mask32Bit*/;
                            zip64ExtraField.$v = (() =>
                            {
                                //new $.$sic.System.IO.Compression.Zip64ExtraField()
                                const $t1 = $.$sic.System.IO.Compression.Zip64ExtraField;
                                const $i1 = new $t1();
                                $i1.CompressedSize = this._compressedSize;
                                $i1.UncompressedSize = this._uncompressedSize;
                                return $i1;
                            })();
                            this.VersionToExtractAtLeast(45/*ZipVersionNeededValues.Zip64*/);
                        }
                        else 
                        {
                            compressedSizeTruncated.$v = $.$cast(this._compressedSize, $.$spc.System.UInt32);
                            uncompressedSizeTruncated.$v = $.$cast(this._uncompressedSize, $.$spc.System.UInt32);
                        }
                    }
                }
                this._offsetOfLocalHeader = this._archive.ArchiveStream.Position;
                const $t1 = this._lhTrailingExtraFieldData;
                /*int*/ let currExtraFieldDataLength = $.$sic.System.IO.Compression.ZipGenericExtraField.TotalSize(this._lhUnknownExtraFields, $.$ifnn($t1, ($t) => $t.length) ?? 0);
                /*int*/ let bigExtraFieldLength = (((zip64ExtraField.$v !== null ? zip64ExtraField.$v.TotalSize : 0) + currExtraFieldDataLength) | 0);
                if (bigExtraFieldLength > 65535/*ushort.MaxValue*/)
                {
                    extraFieldLength.$v = $.$cast((zip64ExtraField.$v !== null ? zip64ExtraField.$v.TotalSize : 0), $.$spc.System.UInt16);
                    this._lhUnknownExtraFields = null;
                }
                else 
                {
                    extraFieldLength.$v = $.$cast(bigExtraFieldLength, $.$spc.System.UInt16);
                }
                if (this._originallyInArchive && this.Changes === 0/*ZipArchive.ChangeState.Unchanged*/ && !forceWrite)
                {
                    this._archive.ArchiveStream.Seek(BigInt(30/*ZipLocalFileHeader.SizeOfLocalHeader*/ + this._storedEntryNameBytes.length), 1/*SeekOrigin.Current*/);
                    if (zip64ExtraField.$v !== null)
                    {
                        this._archive.ArchiveStream.Seek(BigInt(zip64ExtraField.$v.TotalSize), 1/*SeekOrigin.Current*/);
                    }
                    this._archive.ArchiveStream.Seek(BigInt(currExtraFieldDataLength), 1/*SeekOrigin.Current*/);
                    return false;
                }
                return true;
            }
            /*void */ WriteLocalFileHeaderPrepare(/*Span<byte>*/ lfStaticHeader, /*uint*/ compressedSizeTruncated, /*uint*/ uncompressedSizeTruncated, /*ushort*/ extraFieldLength)
            {
                let $t1 = lfStaticHeader;
                $.$sic.System.IO.Compression.ZipLocalFileHeader.SignatureConstantBytes.CopyTo($t1.Slice$1(0/*ZipLocalFileHeader.FieldLocations.Signature*/, $t1.Length - 0/*ZipLocalFileHeader.FieldLocations.Signature*/));
                let $t2 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t2.Slice$1(4/*ZipLocalFileHeader.FieldLocations.VersionNeededToExtract*/, $t2.Length - 4/*ZipLocalFileHeader.FieldLocations.VersionNeededToExtract*/), this._versionToExtract);
                let $t3 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t3.Slice$1(6/*ZipLocalFileHeader.FieldLocations.GeneralPurposeBitFlags*/, $t3.Length - 6/*ZipLocalFileHeader.FieldLocations.GeneralPurposeBitFlags*/), this._generalPurposeBitFlag);
                let $t4 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t4.Slice$1(8/*ZipLocalFileHeader.FieldLocations.CompressionMethod*/, $t4.Length - 8/*ZipLocalFileHeader.FieldLocations.CompressionMethod*/), this.CompressionMethod);
                let $t5 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t5.Slice$1(10/*ZipLocalFileHeader.FieldLocations.LastModified*/, $t5.Length - 10/*ZipLocalFileHeader.FieldLocations.LastModified*/), $.$sic.System.IO.Compression.ZipHelper.DateTimeToDosTime(this._lastModified.DateTime));
                let $t6 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t6.Slice$1(14/*ZipLocalFileHeader.FieldLocations.Crc32*/, $t6.Length - 14/*ZipLocalFileHeader.FieldLocations.Crc32*/), this._crc32);
                let $t7 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t7.Slice$1(18/*ZipLocalFileHeader.FieldLocations.CompressedSize*/, $t7.Length - 18/*ZipLocalFileHeader.FieldLocations.CompressedSize*/), compressedSizeTruncated);
                let $t8 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t8.Slice$1(22/*ZipLocalFileHeader.FieldLocations.UncompressedSize*/, $t8.Length - 22/*ZipLocalFileHeader.FieldLocations.UncompressedSize*/), uncompressedSizeTruncated);
                let $t9 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t9.Slice$1(26/*ZipLocalFileHeader.FieldLocations.FilenameLength*/, $t9.Length - 26/*ZipLocalFileHeader.FieldLocations.FilenameLength*/), $.$cast(this._storedEntryNameBytes.length, $.$spc.System.UInt16));
                let $t10 = lfStaticHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t10.Slice$1(28/*ZipLocalFileHeader.FieldLocations.ExtraFieldLength*/, $t10.Length - 28/*ZipLocalFileHeader.FieldLocations.ExtraFieldLength*/), extraFieldLength);
            }
            /*bool */ WriteLocalFileHeader(/*bool*/ isEmptyFile, /*bool*/ forceWrite)
            {
                /*Zip64ExtraField?*/ let zip64ExtraField;
                /*uint*/ let compressedSizeTruncated;
                /*uint*/ let uncompressedSizeTruncated;
                /*ushort*/ let extraFieldLength;
                if (this.WriteLocalFileHeaderInitialize(isEmptyFile, forceWrite, $.$ref(() => zip64ExtraField, ($v) => zip64ExtraField = $v, $.$sic.System.IO.Compression.Zip64ExtraField), $.$ref(() => compressedSizeTruncated, ($v) => compressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeTruncated, ($v) => uncompressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => extraFieldLength, ($v) => extraFieldLength = $v, $.$spc.System.UInt16)))
                {
                    /*Span<byte>*/ let lfStaticHeader = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 30/*ZipLocalFileHeader.SizeOfLocalHeader*/, null);
                    this.WriteLocalFileHeaderPrepare(lfStaticHeader, compressedSizeTruncated, uncompressedSizeTruncated, extraFieldLength);
                    this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(lfStaticHeader));
                    this._archive.ArchiveStream.Write$1($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this._storedEntryNameBytes));
                    zip64ExtraField?.WriteBlock(this._archive.ArchiveStream);
                    $.$sic.System.IO.Compression.ZipGenericExtraField.WriteAllBlocks(this._lhUnknownExtraFields, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this._lhTrailingExtraFieldData ?? $.$spc.System.Array.Empty($.$spc.System.Byte)), this._archive.ArchiveStream);
                }
                return zip64ExtraField !== null;
            }
            /*void */ WriteLocalFileHeaderAndDataIfNeeded(/*bool*/ forceWrite)
            {
                if (this._storedUncompressedData !== null || this._compressedBytes !== null)
                {
                    if (this._storedUncompressedData !== null)
                    {
                        this._uncompressedSize = this._storedUncompressedData.Length;
                        let entryWriter = null;
                        try
                        {
                            entryWriter = new $.$sic.System.IO.Compression.ZipArchiveEntry.DirectToArchiveWriterStream().$ctor$3(this.GetDataCompressor(this._archive.ArchiveStream, true, null), this);
                            this._storedUncompressedData.Seek(0n, 0/*SeekOrigin.Begin*/);
                            this._storedUncompressedData.CopyTo(entryWriter);
                            this._storedUncompressedData.Dispose();
                            this._storedUncompressedData = null;
                        }
                        finally
                        {
                            entryWriter?.System$IDisposable$Dispose();
                        }
                    }
                    else 
                    {
                        if (this._uncompressedSize === 0n)
                        {
                            this._compressedSize = 0n;
                        }
                        this.WriteLocalFileHeader(this._uncompressedSize === 0n, true);
                        if (this._uncompressedSize !== 0n)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._compressedBytes !== null, "_compressedBytes != null");
                            let $i1 = 0;
                            let $arr1 = this._compressedBytes;
                            while ($i1 < $arr1.length)
                            {
                                let compressedBytes = $arr1[$i1++];
                                this._archive.ArchiveStream.Write(compressedBytes, 0, compressedBytes.length);
                            }
                        }
                    }
                }
                else 
                {
                    if (this._archive.Mode === 2/*ZipArchiveMode.Update*/ || !this._everOpenedForWrite)
                    {
                        this._everOpenedForWrite = true;
                        this.WriteLocalFileHeader(this._uncompressedSize === 0n, forceWrite);
                        if (this._compressedSize !== 0n)
                        {
                            this._archive.ArchiveStream.Seek(this._compressedSize, 1/*SeekOrigin.Current*/);
                        }
                    }
                }
            }
            /*int*/ static MetadataBufferLength = 4;
            /*int*/ static CrcAndSizesBufferLength = 12;
            /*int*/ static Zip64SizesBufferLength = 16;
            /*int*/ static Zip64DataDescriptorCrcAndSizesBufferLength = 20;
            /*void */ WriteCrcAndSizesInLocalHeader(/*bool*/ zip64HeaderUsed)
            {
                /*Span<byte>*/ let writeBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 20/*Zip64DataDescriptorCrcAndSizesBufferLength*/, null);
                /*long*/ let finalPosition;
                /*bool*/ let pretendStreaming;
                /*uint*/ let compressedSizeTruncated;
                /*uint*/ let uncompressedSizeTruncated;
                this.WriteCrcAndSizesInLocalHeaderInitialize(zip64HeaderUsed, $.$ref(() => finalPosition, ($v) => finalPosition = $v, $.$spc.System.Int64), $.$ref(() => pretendStreaming, ($v) => pretendStreaming = $v, $.$spc.System.Boolean), $.$ref(() => compressedSizeTruncated, ($v) => compressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeTruncated, ($v) => uncompressedSizeTruncated = $v, $.$spc.System.UInt32));
                if (pretendStreaming)
                {
                    this.WriteCrcAndSizesInLocalHeaderPrepareForZip64PretendStreaming(writeBuffer);
                    let $t5 = writeBuffer;
                    this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t5.Slice$1(0, 4/*MetadataBufferLength*/)));
                }
                this.WriteCrcAndSizesInLocalHeaderPrepareFor32bitValuesWriting(pretendStreaming, writeBuffer, compressedSizeTruncated, uncompressedSizeTruncated);
                let $t5 = writeBuffer;
                this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t5.Slice$1(0, 12/*CrcAndSizesBufferLength*/)));
                if (zip64HeaderUsed)
                {
                    this.WriteCrcAndSizesInLocalHeaderPrepareForWritingWhenZip64HeaderUsed(writeBuffer);
                    let $t6 = writeBuffer;
                    this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t6.Slice$1(0, 16/*Zip64SizesBufferLength*/)));
                }
                this._archive.ArchiveStream.Seek(finalPosition, 0/*SeekOrigin.Begin*/);
                if (pretendStreaming)
                {
                    this.WriteCrcAndSizesInLocalHeaderPrepareForWritingDataDescriptor(writeBuffer);
                    let $t6 = writeBuffer;
                    this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t6.Slice$1(0, 20/*Zip64DataDescriptorCrcAndSizesBufferLength*/)));
                }
            }
            /*void */ WriteCrcAndSizesInLocalHeaderInitialize(/*bool*/ zip64HeaderUsed, /*out long*/ finalPosition, /*out bool*/ pretendStreaming, /*out uint*/ compressedSizeTruncated, /*out uint*/ uncompressedSizeTruncated)
            {
                finalPosition.$v = this._archive.ArchiveStream.Position;
                /*bool*/ let zip64Needed = this.ShouldUseZIP64;
                pretendStreaming.$v = zip64Needed && !zip64HeaderUsed;
                compressedSizeTruncated.$v = zip64Needed ? 4294967295/*ZipHelper.Mask32Bit*/ : $.$cast(this._compressedSize, $.$spc.System.UInt32);
                uncompressedSizeTruncated.$v = zip64Needed ? 4294967295/*ZipHelper.Mask32Bit*/ : $.$cast(this._uncompressedSize, $.$spc.System.UInt32);
            }
            /*void */ WriteCrcAndSizesInLocalHeaderPrepareForZip64PretendStreaming(/*Span<byte>*/ writeBuffer)
            {
                /*int*/ let relativeVersionToExtractLocation = ((4/*ZipLocalFileHeader.FieldLocations.VersionNeededToExtract*/ - 4/*ZipLocalFileHeader.FieldLocations.VersionNeededToExtract*/) | 0);
                /*int*/ let relativeGeneralPurposeBitFlagsLocation = ((6/*ZipLocalFileHeader.FieldLocations.GeneralPurposeBitFlags*/ - 4/*ZipLocalFileHeader.FieldLocations.VersionNeededToExtract*/) | 0);
                this.VersionToExtractAtLeast(45/*ZipVersionNeededValues.Zip64*/);
                this._generalPurposeBitFlag |= 8/*BitFlagValues.DataDescriptor*/;
                this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader + BigInt(4/*ZipLocalFileHeader.FieldLocations.VersionNeededToExtract*/), 0/*SeekOrigin.Begin*/);
                let $t1 = writeBuffer;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t1.Slice$1(relativeVersionToExtractLocation, $t1.Length - relativeVersionToExtractLocation), this._versionToExtract);
                let $t2 = writeBuffer;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t2.Slice$1(relativeGeneralPurposeBitFlagsLocation, $t2.Length - relativeGeneralPurposeBitFlagsLocation), this._generalPurposeBitFlag);
            }
            /*void */ WriteCrcAndSizesInLocalHeaderPrepareFor32bitValuesWriting(/*bool*/ pretendStreaming, /*Span<byte>*/ writeBuffer, /*uint*/ compressedSizeTruncated, /*uint*/ uncompressedSizeTruncated)
            {
                this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader + BigInt(14/*ZipLocalFileHeader.FieldLocations.Crc32*/), 0/*SeekOrigin.Begin*/);
                if (!pretendStreaming)
                {
                    /*int*/ let relativeCrc32Location = ((14/*ZipLocalFileHeader.FieldLocations.Crc32*/ - 14/*ZipLocalFileHeader.FieldLocations.Crc32*/) | 0);
                    /*int*/ let relativeCompressedSizeLocation = ((18/*ZipLocalFileHeader.FieldLocations.CompressedSize*/ - 14/*ZipLocalFileHeader.FieldLocations.Crc32*/) | 0);
                    /*int*/ let relativeUncompressedSizeLocation = ((22/*ZipLocalFileHeader.FieldLocations.UncompressedSize*/ - 14/*ZipLocalFileHeader.FieldLocations.Crc32*/) | 0);
                    let $t1 = writeBuffer;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t1.Slice$1(relativeCrc32Location, $t1.Length - relativeCrc32Location), this._crc32);
                    let $t2 = writeBuffer;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t2.Slice$1(relativeCompressedSizeLocation, $t2.Length - relativeCompressedSizeLocation), compressedSizeTruncated);
                    let $t3 = writeBuffer;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t3.Slice$1(relativeUncompressedSizeLocation, $t3.Length - relativeUncompressedSizeLocation), uncompressedSizeTruncated);
                }
                else 
                {
                    let $t1 = writeBuffer;
                    $t1.Slice$1(0, 12/*CrcAndSizesBufferLength*/).Clear();
                }
            }
            /*void */ WriteCrcAndSizesInLocalHeaderPrepareForWritingWhenZip64HeaderUsed(/*Span<byte>*/ writeBuffer)
            {
                /*int*/ let relativeUncompressedSizeLocation = ((4/*Zip64ExtraField.FieldLocations.UncompressedSize*/ - 4/*Zip64ExtraField.FieldLocations.UncompressedSize*/) | 0);
                /*int*/ let relativeCompressedSizeLocation = ((12/*Zip64ExtraField.FieldLocations.CompressedSize*/ - 4/*Zip64ExtraField.FieldLocations.UncompressedSize*/) | 0);
                this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader + BigInt(30/*ZipLocalFileHeader.SizeOfLocalHeader*/) + BigInt(this._storedEntryNameBytes.length) + BigInt(4/*Zip64ExtraField.OffsetToFirstField*/), 0/*SeekOrigin.Begin*/);
                let $t1 = writeBuffer;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t1.Slice$1(relativeUncompressedSizeLocation, $t1.Length - relativeUncompressedSizeLocation), this._uncompressedSize);
                let $t2 = writeBuffer;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t2.Slice$1(relativeCompressedSizeLocation, $t2.Length - relativeCompressedSizeLocation), this._compressedSize);
            }
            /*void */ WriteCrcAndSizesInLocalHeaderPrepareForWritingDataDescriptor(/*Span<byte>*/ writeBuffer)
            {
                /*int*/ let relativeCrc32Location = ((4/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.Crc32*/ - 4/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.Crc32*/) | 0);
                /*int*/ let relativeCompressedSizeLocation = ((8/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.CompressedSize*/ - 4/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.Crc32*/) | 0);
                /*int*/ let relativeUncompressedSizeLocation = ((16/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.UncompressedSize*/ - 4/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.Crc32*/) | 0);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian(writeBuffer.Slice(relativeCrc32Location), this._crc32);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian(writeBuffer.Slice(relativeCompressedSizeLocation), this._compressedSize);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian(writeBuffer.Slice(relativeUncompressedSizeLocation), this._uncompressedSize);
            }
            /*int*/ static MaxSizeOfDataDescriptor = 24;
            /*void */ WriteDataDescriptor()
            {
                /*Span<byte>*/ let dataDescriptor = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 24/*MaxSizeOfDataDescriptor*/, null);
                /*int*/ let bytesToWrite = this.PrepareToWriteDataDescriptor(dataDescriptor);
                let $t1 = dataDescriptor;
                this._archive.ArchiveStream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t1.Slice$1(0, bytesToWrite)));
            }
            /*int */ PrepareToWriteDataDescriptor(/*Span<byte>*/ dataDescriptor)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((this._generalPurposeBitFlag & 8/*BitFlagValues.DataDescriptor*/) !== 0, "(_generalPurposeBitFlag & BitFlagValues.DataDescriptor) != 0");
                /*int*/ let bytesToWrite;
                let $t1 = dataDescriptor;
                $.$sic.System.IO.Compression.ZipLocalFileHeader.DataDescriptorSignatureConstantBytes.CopyTo($t1.Slice$1(0/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.Signature*/, $t1.Length - 0/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.Signature*/));
                let $t2 = dataDescriptor;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t2.Slice$1(4/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.Crc32*/, $t2.Length - 4/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.Crc32*/), this._crc32);
                if (this.AreSizesTooLarge)
                {
                    let $t3 = dataDescriptor;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t3.Slice$1(8/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.CompressedSize*/, $t3.Length - 8/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.CompressedSize*/), this._compressedSize);
                    let $t4 = dataDescriptor;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t4.Slice$1(16/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.UncompressedSize*/, $t4.Length - 16/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.UncompressedSize*/), this._uncompressedSize);
                    bytesToWrite = ((16/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations.UncompressedSize*/ + 8/*ZipLocalFileHeader.Zip64DataDescriptor.FieldLengths.UncompressedSize*/) | 0);
                }
                else 
                {
                    let $t3 = dataDescriptor;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t3.Slice$1(8/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.CompressedSize*/, $t3.Length - 8/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.CompressedSize*/), $.$cast(this._compressedSize, $.$spc.System.UInt32));
                    let $t4 = dataDescriptor;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t4.Slice$1(12/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.UncompressedSize*/, $t4.Length - 12/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.UncompressedSize*/), $.$cast(this._uncompressedSize, $.$spc.System.UInt32));
                    bytesToWrite = ((12/*ZipLocalFileHeader.ZipDataDescriptor.FieldLocations.UncompressedSize*/ + 4/*ZipLocalFileHeader.ZipDataDescriptor.FieldLengths.UncompressedSize*/) | 0);
                }
                return bytesToWrite;
            }
            /*void */ UnloadStreams()
            {
                this._storedUncompressedData?.Dispose();
                this._compressedBytes = null;
                this._outstandingWriteStream = null;
            }
            /*void */ CloseStreams()
            {
                this._outstandingWriteStream?.Dispose();
            }
            /*void */ VersionToExtractAtLeast(/*ZipVersionNeededValues*/ value)
            {
                if (this._versionToExtract < value)
                {
                    this._versionToExtract = value;
                    this.Changes |= 1/*ZipArchive.ChangeState.FixedLengthMetadata*/;
                }
                if (this._versionMadeBySpecification < value)
                {
                    this._versionMadeBySpecification = value;
                    this.Changes |= 1/*ZipArchive.ChangeState.FixedLengthMetadata*/;
                }
            }
            /*void */ ThrowIfInvalidArchive()
            {
                if (this._archive === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.DeletedEntry);
                }
                this._archive.ThrowIfDisposed();
            }
            static /*string */ GetFileName_Windows(/*string*/ path)
            {
                /*int*/ let i = $.$spc.System.MemoryExtensions.LastIndexOfAny$6($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(path), /*\\*/ 92, /*/*/ 47, /*:*/ 58);
                return i >= 0 ? $.$spc.System.String.Substring.call(path, ((i + 1) | 0)) : path;
            }
            static /*string */ GetFileName_Unix(/*string*/ path)
            {
                /*int*/ let i = $.$spc.System.String.LastIndexOf.call(path, /*/*/ 47);
                return i >= 0 ? $.$spc.System.String.Substring.call(path, ((i + 1) | 0)) : path;
            }
            static $_DirectToArchiveWriterStream;
            static get DirectToArchiveWriterStream()
            {
                let $cls = $.$sic.System.IO.Compression.ZipArchiveEntry;
                return $cls.$_DirectToArchiveWriterStream ??= $asm.$ncls("$sic.System.IO.Compression.ZipArchiveEntry.DirectToArchiveWriterStream", ($self) => class DirectToArchiveWriterStream extends $.$spc.System.IO.Stream
                {
                    /*long*/ _position = 0n;
                    /*CheckSumAndSizeWriteStream*/ _crcSizeStream = null;
                    /*bool*/ _everWritten = false;
                    /*bool*/ _isDisposed = false;
                    /*ZipArchiveEntry*/ _entry = null;
                    /*bool*/ _usedZip64inLH = false;
                    /*bool*/ _canWrite = false;
                    $ctor$3(/*CheckSumAndSizeWriteStream*/ crcSizeStream, /*ZipArchiveEntry*/ entry)
                    {
                        super.$ctor$2();
                        {
                            this._position = 0n;
                            this._crcSizeStream = crcSizeStream;
                            this._everWritten = false;
                            this._isDisposed = false;
                            this._entry = entry;
                            this._usedZip64inLH = false;
                            this._canWrite = true;
                        }
                        return this;
                    }
                    /*long */ get Length()
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
                    }
                    /*long */ get Position()
                    {
                        this.ThrowIfDisposed();
                        return this._position;
                    }
                    /*long */ set Position(value)
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
                    }
                    /*bool */ get CanRead()
                    {
                        return false;
                    }
                    /*bool */ get CanSeek()
                    {
                        return false;
                    }
                    /*bool */ get CanWrite()
                    {
                        return this._canWrite;
                    }
                    /*void */ ThrowIfDisposed()
                    {
                        if (this._isDisposed)
                        {
                            throw new $.$spc.System.ObjectDisposedException().$ctor$15($.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this)), $.$sic.System.SR.HiddenStreamName);
                        }
                    }
                    /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
                    }
                    /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
                    }
                    /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
                    }
                    /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
                    }
                    /*void */ SetLength(/*long*/ value)
                    {
                        this.ThrowIfDisposed();
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SetLengthRequiresSeekingAndWriting);
                    }
                    /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
                    {
                        $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                        this.ThrowIfDisposed();
                        $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                        if (count === 0)
                        {
                            return;
                        }
                        if (!this._everWritten)
                        {
                            this._everWritten = true;
                            this._usedZip64inLH = this._entry.WriteLocalFileHeader(false, true);
                        }
                        this._crcSizeStream.Write(buffer, offset, count);
                        this._position += BigInt(count);
                    }
                    /*void */ Write$1(/*ReadOnlySpan<byte>*/ source)
                    {
                        this.ThrowIfDisposed();
                        $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                        if (source.Length === 0)
                        {
                            return;
                        }
                        if (!this._everWritten)
                        {
                            this._everWritten = true;
                            this._usedZip64inLH = this._entry.WriteLocalFileHeader(false, true);
                        }
                        this._crcSizeStream.Write$1(source);
                        this._position += BigInt(source.Length);
                    }
                    /*void */ WriteByte(/*byte*/ value)
                    {
                        return this.Write$1(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$5($.$ref(() => value, undefined, $.$spc.System.Byte)));
                    }
                    /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
                    {
                        $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                        return this.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count), cancellationToken).AsTask();
                    }
                    /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        this.ThrowIfDisposed();
                        $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                        return !buffer.IsEmpty ? Core.call(this, buffer, cancellationToken) : new $.$spc.System.Threading.Tasks.ValueTask();
                        /*ValueTask*/ /*async*/  function Core(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                        {
                            return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                            {
                                if (!this._everWritten)
                                {
                                    this._everWritten = true;
                                    this._usedZip64inLH = await this._entry.WriteLocalFileHeaderAsync(false, true, cancellationToken).ConfigureAwait$2(false);
                                }
                                await this._crcSizeStream.WriteAsync$2(buffer, cancellationToken).ConfigureAwait(false);
                                this._position += BigInt(buffer.Length);
                            });
                        }
                    }
                    /*void */ Flush()
                    {
                        this.ThrowIfDisposed();
                        $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                        this._crcSizeStream.Flush();
                    }
                    /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
                    {
                        this.ThrowIfDisposed();
                        $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                        return this._crcSizeStream.FlushAsync$1(cancellationToken);
                    }
                    /*void */ Dispose$1(/*bool*/ disposing)
                    {
                        if (disposing && !this._isDisposed)
                        {
                            this._crcSizeStream.Dispose();
                            if (!this._everWritten)
                            {
                                this._entry.WriteLocalFileHeader(true, true);
                            }
                            else 
                            {
                                if (this._entry._archive.ArchiveStream.CanSeek)
                                {
                                    this._entry.WriteCrcAndSizesInLocalHeader(this._usedZip64inLH);
                                }
                                else 
                                {
                                    this._entry.WriteDataDescriptor();
                                }
                            }
                            this._canWrite = false;
                            this._isDisposed = true;
                        }
                        super.Dispose$1(disposing);
                    }
                    /*ValueTask *//*async*/  DisposeAsync()
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                        {
                            if (!this._isDisposed)
                            {
                                await this._crcSizeStream.DisposeAsync().ConfigureAwait(false);
                                if (!this._everWritten)
                                {
                                    await this._entry.WriteLocalFileHeaderAsync(true, true, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait$2(false);
                                }
                                else 
                                {
                                    if (this._entry._archive.ArchiveStream.CanSeek)
                                    {
                                        await this._entry.WriteCrcAndSizesInLocalHeaderAsync(this._usedZip64inLH, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                                    }
                                    else 
                                    {
                                        await this._entry.WriteDataDescriptorAsync(new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                                    }
                                }
                                this._canWrite = false;
                                this._isDisposed = true;
                            }
                            await super.DisposeAsync().ConfigureAwait(false);
                        });
                    }
                    static $h = 2856315;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":917505,"g":{"r":0,"d":0,"h":42952529275,"f":32769},"n":"Length","d":2856315,"h":38657561979,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":51542463867,"f":32769},"s":{"r":0,"d":0,"h":55837431163,"f":32769},"n":"Position","d":2856315,"h":47247496571,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":64427365755,"f":32769},"n":"CanRead","d":2856315,"h":60132398459,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":73017300347,"f":32769},"n":"CanSeek","d":2856315,"h":68722333051,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":81607234939,"f":32769},"n":"CanWrite","d":2856315,"h":77312267643,"f":32769}],"m":[{"r":65537,"n":"ThrowIfDisposed","d":2856315,"h":85902202235,"f":2},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":2856315,"h":90197169531,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":2856315,"h":94492136827,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":2856315,"h":98787104123,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":2856315,"h":103082071419,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":2856315,"h":107377038715,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":2856315,"h":111672006011,"f":32769},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":2856315,"h":115966973307,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":2856315,"h":120261940603,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":2856315,"h":124556907899,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":2856315,"h":128851875195,"f":32769},{"r":65537,"n":"Flush","d":2856315,"h":133146842491,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":2856315,"h":137441809787,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":2856315,"h":141736777083,"f":32772},{"r":136118273,"n":"DisposeAsync","d":2856315,"h":146031744379,"f":36865}],"l":[{"t":917505,"n":"_position","d":2856315,"h":4297823611,"f":2},{"t":693627,"n":"_crcSizeStream","d":2856315,"h":8592790907,"f":2},{"t":262145,"n":"_everWritten","d":2856315,"h":12887758203,"f":2},{"t":262145,"n":"_isDisposed","d":2856315,"h":17182725499,"f":2},{"t":2659707,"n":"_entry","d":2856315,"h":21477692795,"f":2},{"t":262145,"n":"_usedZip64inLH","d":2856315,"h":25772660091,"f":2},{"t":262145,"n":"_canWrite","d":2856315,"h":30067627387,"f":2}],"c":[{"p":[{"n":"crcSizeStream","p":693627},{"n":"entry","p":2659707}],"n":".ctor","o":"$ctor$3","d":2856315,"h":34362594683,"f":1}],"i":[57475073,56885249],"d":2659707,"h":2856315}; }
                    static get $b() { return $.$spc.System.IO.Stream; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
                    static get $fullName() { return `System.IO.Compression.ZipArchiveEntry.DirectToArchiveWriterStream`; }
                }, $cls, ($v) => $cls.$_DirectToArchiveWriterStream = $v);
            }
            static $_BitFlagValues;
            static get BitFlagValues()
            {
                let $cls = $.$sic.System.IO.Compression.ZipArchiveEntry;
                return $cls.$_BitFlagValues ??= $asm.$nstr("$sic.System.IO.Compression.ZipArchiveEntry.BitFlagValues", ($self) => class BitFlagValues extends $.$spc.System.Enum
                {
                    static IsEncrypted = 1;
                    static DataDescriptor = 8;
                    static UnicodeFileNameAndComment = 2048;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "IsEncrypted": 1n,
                            "DataDescriptor": 8n,
                            "UnicodeFileNameAndComment": 2048n
                        };
                    }
                    static $h = 2725243;
                    static $z = 2;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.UInt16; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":589825,"l":[{"t":2725243,"n":"IsEncrypted","d":2725243,"h":4297692539,"f":33},{"t":2725243,"n":"DataDescriptor","d":2725243,"h":8592659835,"f":33},{"t":2725243,"n":"UnicodeFileNameAndComment","d":2725243,"h":12887627131,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2725243,"h":17182594427,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":2659707,"h":2725243,"a":[{"t":47644673,"c":4342611969}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZipArchiveEntry.BitFlagValues`; }
                }, $cls, ($v) => $cls.$_BitFlagValues = $v);
            }
            static $_CompressionMethodValues;
            static get CompressionMethodValues()
            {
                let $cls = $.$sic.System.IO.Compression.ZipArchiveEntry;
                return $cls.$_CompressionMethodValues ??= $asm.$nstr("$sic.System.IO.Compression.ZipArchiveEntry.CompressionMethodValues", ($self) => class CompressionMethodValues extends $.$spc.System.Enum
                {
                    static Stored = 0;
                    static Deflate = 8;
                    static Deflate64 = 9;
                    static BZip2 = 12;
                    static LZMA = 14;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Stored": 0n,
                            "Deflate": 8n,
                            "Deflate64": 9n,
                            "BZip2": 12n,
                            "LZMA": 14n
                        };
                    }
                    static $h = 2790779;
                    static $z = 2;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.UInt16; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":589825,"l":[{"t":2790779,"n":"Stored","d":2790779,"h":4297758075,"f":33},{"t":2790779,"n":"Deflate","d":2790779,"h":8592725371,"f":33},{"t":2790779,"n":"Deflate64","d":2790779,"h":12887692667,"f":33},{"t":2790779,"n":"BZip2","d":2790779,"h":17182659963,"f":33},{"t":2790779,"n":"LZMA","d":2790779,"h":21477627259,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2790779,"h":25772594555,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":2659707,"h":2790779}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZipArchiveEntry.CompressionMethodValues`; }
                }, $cls, ($v) => $cls.$_CompressionMethodValues = $v);
            }
            static $_LocalHeaderOffsetComparer;
            static get LocalHeaderOffsetComparer()
            {
                let $cls = $.$sic.System.IO.Compression.ZipArchiveEntry;
                return $cls.$_LocalHeaderOffsetComparer ??= $asm.$ncls("$sic.System.IO.Compression.ZipArchiveEntry.LocalHeaderOffsetComparer", ($self) => class LocalHeaderOffsetComparer extends $.$spc.System.Collections.Generic.Comparer$$($.$sic.System.IO.Compression.ZipArchiveEntry)
                {
                    /*LocalHeaderOffsetComparer*/ static s_instance = null;
                    static /*LocalHeaderOffsetComparer */ get Instance()
                    {
                        return $.$sic.System.IO.Compression.ZipArchiveEntry.LocalHeaderOffsetComparer.s_instance;
                    }
                    /*int */ Compare(/*ZipArchiveEntry?*/ x, /*ZipArchiveEntry?*/ y)
                    {
                        /*long*/ let xOffset = x !== null && !x.OriginallyInArchive ? 9223372036854775807n : (x?.OffsetOfLocalHeader ?? null) ?? -9223372036854775808n;
                        /*long*/ let yOffset = y !== null && !y.OriginallyInArchive ? 9223372036854775807n : (y?.OffsetOfLocalHeader ?? null) ?? -9223372036854775808n;
                        return $.$spc.System.Int64.CompareTo$1.call(xOffset, yOffset);
                    }
                    //default reference type constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        return this;
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.s_instance = new $.$sic.System.IO.Compression.ZipArchiveEntry.LocalHeaderOffsetComparer().$ctor$2();
                        }
                    }
                    static $h = 2921851;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":2921851,"g":{"r":0,"d":0,"h":12887823739,"f":33},"n":"Instance","d":2921851,"h":8592856443,"f":33}],"m":[{"r":655361,"p":[{"n":"x","p":2659707},{"n":"y","p":2659707}],"n":"Compare","d":2921851,"h":17182791035,"f":32769}],"l":[{"t":2921851,"n":"s_instance","d":2921851,"h":4297889147,"f":34}],"c":[{"n":".ctor","o":"$ctor$2","d":2921851,"h":21477758331,"f":1}],"i":[31391745,$.$spc.System.Collections.Generic.IComparer$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h],"d":2659707,"h":2921851}; }
                    static get $b() { return $.$spc.System.Collections.Generic.Comparer$$($.$sic.System.IO.Compression.ZipArchiveEntry); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IComparer, $.$spc.System.Collections.Generic.IComparer$$($.$sic.System.IO.Compression.ZipArchiveEntry) ]; }
                    static get $fullName() { return `System.IO.Compression.ZipArchiveEntry.LocalHeaderOffsetComparer`; }
                }, $cls, ($v) => $cls.$_LocalHeaderOffsetComparer = $v);
            }
            /*Task<Stream> *//*async*/  OpenAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.Stream), $.$spc.System.IO.Stream, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    this.ThrowIfInvalidArchive();
                    let $switch1 = this._archive.Mode;
                    switch($switch1)
                    {
                        case 0/*ZipArchiveMode.Read*/:
                        return await this.OpenInReadModeAsync(true, cancellationToken).ConfigureAwait$2(false);
                        case 1/*ZipArchiveMode.Create*/:
                        return this.OpenInWriteMode();
                        case 2/*ZipArchiveMode.Update*/:
                        default:
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._archive.Mode === 2/*ZipArchiveMode.Update*/, "_archive.Mode == ZipArchiveMode.Update");
                        return await this.OpenInUpdateModeAsync(cancellationToken).ConfigureAwait$2(false);
                    }
                });
            }
            /*Task<long> *//*async*/  GetOffsetOfCompressedDataAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int64), $.$spc.System.Int64, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (this._storedOffsetOfCompressedData === null)
                    {
                        this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader, 0/*SeekOrigin.Begin*/);
                        if (!await $.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlockAsync(this._archive.ArchiveStream, cancellationToken).ConfigureAwait$2(false))
                        {
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.LocalFileHeaderCorrupt);
                        }
                        this._storedOffsetOfCompressedData = this._archive.ArchiveStream.Position;
                    }
                    return $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(this._storedOffsetOfCompressedData);
                });
            }
            /*Task<MemoryStream> *//*async*/  GetUncompressedDataAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.MemoryStream), $.$spc.System.IO.MemoryStream, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (this._storedUncompressedData === null)
                    {
                        this._storedUncompressedData = new $.$spc.System.IO.MemoryStream().$ctor$4($.$cast(this._uncompressedSize, $.$spc.System.Int32));
                        if (this._originallyInArchive)
                        {
                            /*Stream*/ let decompressor = await this.OpenInReadModeAsync(false, cancellationToken).ConfigureAwait$2(false);
                            let $disposable1 = null;
                            try
                            {
                                $disposable1 = decompressor;
                                try
                                {
                                    await decompressor.CopyToAsync$2(this._storedUncompressedData, cancellationToken).ConfigureAwait(false);
                                }
                                catch($e)
                                {
                                    await this._storedUncompressedData.DisposeAsync().ConfigureAwait(false);
                                    this._storedUncompressedData = null;
                                    this._currentlyOpenForWrite = false;
                                    this._everOpenedForWrite = false;
                                    throw $e;
                                }
                            }
                            finally
                            {
                                $disposable1?.System$IDisposable$Dispose();
                            }
                        }
                        if (this.CompressionMethod !== 0/*CompressionMethodValues.Stored*/)
                        {
                            this.CompressionMethod = 8/*CompressionMethodValues.Deflate*/;
                        }
                    }
                    return this._storedUncompressedData;
                });
            }
            /*Task *//*async*/  WriteAndFinishLocalEntryAsync(/*bool*/ forceWrite, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await this.CloseStreamsAsync().ConfigureAwait(false);
                    await this.WriteLocalFileHeaderAndDataIfNeededAsync(forceWrite, cancellationToken).ConfigureAwait(false);
                    await this.UnloadStreamsAsync().ConfigureAwait(false);
                });
            }
            /*Task *//*async*/  WriteCentralDirectoryFileHeaderAsync(/*bool*/ forceWrite, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*Zip64ExtraField?*/ let zip64ExtraField;
                    /*uint*/ let compressedSizeTruncated;
                    /*uint*/ let uncompressedSizeTruncated;
                    /*ushort*/ let extraFieldLength;
                    /*uint*/ let offsetOfLocalHeaderTruncated;
                    if (this.WriteCentralDirectoryFileHeaderInitialize(forceWrite, $.$ref(() => zip64ExtraField, ($v) => zip64ExtraField = $v, $.$sic.System.IO.Compression.Zip64ExtraField), $.$ref(() => compressedSizeTruncated, ($v) => compressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeTruncated, ($v) => uncompressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => extraFieldLength, ($v) => extraFieldLength = $v, $.$spc.System.UInt16), $.$ref(() => offsetOfLocalHeaderTruncated, ($v) => offsetOfLocalHeaderTruncated = $v, $.$spc.System.UInt32)))
                    {
                        /*byte[]*/ let cdStaticHeader = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/], null);
                        this.WriteCentralDirectoryFileHeaderPrepare($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(cdStaticHeader), compressedSizeTruncated, uncompressedSizeTruncated, extraFieldLength, offsetOfLocalHeaderTruncated);
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(cdStaticHeader), cancellationToken).ConfigureAwait(false);
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(this._storedEntryNameBytes), cancellationToken).ConfigureAwait(false);
                        if (zip64ExtraField !== null)
                        {
                            await zip64ExtraField.WriteBlockAsync(this._archive.ArchiveStream, cancellationToken).ConfigureAwait(false);
                        }
                        await $.$sic.System.IO.Compression.ZipGenericExtraField.WriteAllBlocksAsync(this._cdUnknownExtraFields, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(this._cdTrailingExtraFieldData ?? $.$spc.System.Array.Empty($.$spc.System.Byte)), this._archive.ArchiveStream, cancellationToken).ConfigureAwait(false);
                        if (this._fileComment.length > 0)
                        {
                            await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(this._fileComment), cancellationToken).ConfigureAwait(false);
                        }
                    }
                });
            }
            /*Task *//*async*/  LoadLocalHeaderExtraFieldIfNeededAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    $.$spc.System.Diagnostics.Debug.Assert$1(await this.GetIsOpenableAsync(false, true, cancellationToken).ConfigureAwait$2(false), "await GetIsOpenableAsync(false, true, cancellationToken).ConfigureAwait(false)");
                    if (this._originallyInArchive)
                    {
                        this._archive.ArchiveStream.Seek(this._offsetOfLocalHeader, 0/*SeekOrigin.Begin*/);
                        $.$tupleUnpack(($tp) =>
                        {
                            this._lhUnknownExtraFields = $tp.Item1;
                            this._lhTrailingExtraFieldData = $tp.Item2;
                        }).$v = await $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldsAsync(this._archive.ArchiveStream, cancellationToken).ConfigureAwait$2(false);
                    }
                });
            }
            /*Task *//*async*/  LoadCompressedBytesIfNeededAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    $.$spc.System.Diagnostics.Debug.Assert$1(await this.GetIsOpenableAsync(false, true, cancellationToken).ConfigureAwait$2(false), "await GetIsOpenableAsync(false, true, cancellationToken).ConfigureAwait(false)");
                    if (!this._everOpenedForWrite && this._originallyInArchive)
                    {
                        /*int*/ let maxSingleBufferSize;
                        this._compressedBytes = this.LoadCompressedBytesIfNeededInitialize($.$ref(() => maxSingleBufferSize, ($v) => maxSingleBufferSize = $v, $.$spc.System.Int32));
                        this._archive.ArchiveStream.Seek(await this.GetOffsetOfCompressedDataAsync(cancellationToken).ConfigureAwait$2(false), 0/*SeekOrigin.Begin*/);
                        for(/*int*/ let i = 0; i < ((this._compressedBytes.length - 1) | 0); i++)
                        {
                            await this._archive.ArchiveStream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit($.$spc.System.Array.$ReadT1.call(this._compressedBytes, i)), maxSingleBufferSize, true, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                        }
                        await this._archive.ArchiveStream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit($.$spc.System.Array.$ReadT1.call(this._compressedBytes, ((this._compressedBytes.length - 1) | 0))), $.$cast((this._compressedSize % BigInt(maxSingleBufferSize)), $.$spc.System.Int32), true, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    }
                });
            }
            /*Task<bool> *//*async*/  GetIsOpenableAsync(/*bool*/ needToUncompress, /*bool*/ needToLoadIntoMemory, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*bool*/ let result;
        $.$tupleUnpack(($tp) =>
                    {
                        result = $tp.Item1;
                        _ = $tp.Item2;
                    }).$v = await this.IsOpenableAsync(needToUncompress, needToLoadIntoMemory, cancellationToken).ConfigureAwait$2(false);
                    return result;
                });
            }
            /*Task *//*async*/  ThrowIfNotOpenableAsync(/*bool*/ needToUncompress, /*bool*/ needToLoadIntoMemory, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    const { Item1: openable, Item2: message } = await this.IsOpenableAsync(needToUncompress, needToLoadIntoMemory, cancellationToken).ConfigureAwait$2(false);
                    if (!openable)
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10(message);
                    }
                });
            }
            /*Task<Stream> *//*async*/  OpenInReadModeAsync(/*bool*/ checkOpenable, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.Stream), $.$spc.System.IO.Stream, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (checkOpenable)
                    {
                        await this.ThrowIfNotOpenableAsync(true, false, cancellationToken).ConfigureAwait(false);
                    }
                    return this.OpenInReadModeGetDataCompressor(await this.GetOffsetOfCompressedDataAsync(cancellationToken).ConfigureAwait$2(false));
                });
            }
            /*Task<WrappedStream> *//*async*/  OpenInUpdateModeAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.WrappedStream), $.$sic.System.IO.Compression.WrappedStream, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (this._currentlyOpenForWrite)
                    {
                        throw new $.$spc.System.IO.IOException().$ctor$10($.$sic.System.SR.UpdateModeOneStream);
                    }
                    await this.ThrowIfNotOpenableAsync(true, true, cancellationToken).ConfigureAwait(false);
                    this._everOpenedForWrite = true;
                    this.Changes |= 4/*ZipArchive.ChangeState.StoredData*/;
                    this._currentlyOpenForWrite = true;
                    /*Stream*/ let uncompressedData = await this.GetUncompressedDataAsync(cancellationToken).ConfigureAwait$2(false);
                    uncompressedData.Seek(0n, 0/*SeekOrigin.Begin*/);
                    return new $.$sic.System.IO.Compression.WrappedStream().$ctor$5(uncompressedData, this, new ($.$spc.System.Action$$($.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor(this,  (/*thisRef*/ thisRef) =>
                    {
                        thisRef._currentlyOpenForWrite = false;
                    }));
                });
            }
            /*Task<(bool, string?)> *//*async*/  IsOpenableAsync(/*bool*/ needToUncompress, /*bool*/ needToLoadIntoMemory, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String)), $.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String), async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*string?*/ let message = null;
                    if (!this._originallyInArchive)
                    {
                        return new ($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String))().$ctor$2(true, message);
                    }
                    if (!this.IsOpenableInitialVerifications(needToUncompress, $.$ref(() => message, ($v) => message = $v, $.$spc.System.String)))
                    {
                        return new ($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String))().$ctor$2(false, message);
                    }
                    if (!await $.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlockAsync(this._archive.ArchiveStream, cancellationToken).ConfigureAwait$2(false))
                    {
                        message = $.$sic.System.SR.LocalFileHeaderCorrupt;
                        return new ($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String))().$ctor$2(false, message);
                    }
                    /*long*/ let offsetOfCompressedData = await this.GetOffsetOfCompressedDataAsync(cancellationToken).ConfigureAwait$2(false);
                    if (!this.IsOpenableFinalVerifications(needToLoadIntoMemory, offsetOfCompressedData, $.$ref(() => message, ($v) => message = $v, $.$spc.System.String)))
                    {
                        return new ($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String))().$ctor$2(false, message);
                    }
                    return new ($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String))().$ctor$2(true, message);
                });
            }
            /*Task<bool> *//*async*/  WriteLocalFileHeaderAsync(/*bool*/ isEmptyFile, /*bool*/ forceWrite, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*Zip64ExtraField?*/ let zip64ExtraField;
                    /*uint*/ let compressedSizeTruncated;
                    /*uint*/ let uncompressedSizeTruncated;
                    /*ushort*/ let extraFieldLength;
                    if (this.WriteLocalFileHeaderInitialize(isEmptyFile, forceWrite, $.$ref(() => zip64ExtraField, ($v) => zip64ExtraField = $v, $.$sic.System.IO.Compression.Zip64ExtraField), $.$ref(() => compressedSizeTruncated, ($v) => compressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeTruncated, ($v) => uncompressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => extraFieldLength, ($v) => extraFieldLength = $v, $.$spc.System.UInt16)))
                    {
                        /*byte[]*/ let lfStaticHeader = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [30/*ZipLocalFileHeader.SizeOfLocalHeader*/], null);
                        this.WriteLocalFileHeaderPrepare($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(lfStaticHeader), compressedSizeTruncated, uncompressedSizeTruncated, extraFieldLength);
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(lfStaticHeader), cancellationToken).ConfigureAwait(false);
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(this._storedEntryNameBytes), cancellationToken).ConfigureAwait(false);
                        if (zip64ExtraField !== null)
                        {
                            await zip64ExtraField.WriteBlockAsync(this._archive.ArchiveStream, cancellationToken).ConfigureAwait(false);
                        }
                        await $.$sic.System.IO.Compression.ZipGenericExtraField.WriteAllBlocksAsync(this._lhUnknownExtraFields, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(this._lhTrailingExtraFieldData ?? $.$spc.System.Array.Empty($.$spc.System.Byte)), this._archive.ArchiveStream, cancellationToken).ConfigureAwait(false);
                    }
                    return zip64ExtraField !== null;
                });
            }
            /*Task *//*async*/  WriteLocalFileHeaderAndDataIfNeededAsync(/*bool*/ forceWrite, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (this._storedUncompressedData !== null || this._compressedBytes !== null)
                    {
                        if (this._storedUncompressedData !== null)
                        {
                            this._uncompressedSize = this._storedUncompressedData.Length;
                            /*DirectToArchiveWriterStream*/ let entryWriter = new $.$sic.System.IO.Compression.ZipArchiveEntry.DirectToArchiveWriterStream().$ctor$3(this.GetDataCompressor(this._archive.ArchiveStream, true, null), this);
                            let $disposable1 = null;
                            try
                            {
                                $disposable1 = entryWriter;
                                this._storedUncompressedData.Seek(0n, 0/*SeekOrigin.Begin*/);
                                await this._storedUncompressedData.CopyToAsync$2(entryWriter, cancellationToken).ConfigureAwait(false);
                                await this._storedUncompressedData.DisposeAsync().ConfigureAwait(false);
                                this._storedUncompressedData = null;
                            }
                            finally
                            {
                                $disposable1?.System$IDisposable$Dispose();
                            }
                        }
                        else 
                        {
                            if (this._uncompressedSize === 0n)
                            {
                                this._compressedSize = 0n;
                            }
                            await this.WriteLocalFileHeaderAsync(this._uncompressedSize === 0n, true, cancellationToken).ConfigureAwait$2(false);
                            if (this._uncompressedSize !== 0n)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._compressedBytes !== null, "_compressedBytes != null");
                                let $i1 = 0;
                                let $arr1 = this._compressedBytes;
                                while ($i1 < $arr1.length)
                                {
                                    let compressedBytes = $arr1[$i1++];
                                    await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(compressedBytes), cancellationToken).ConfigureAwait(false);
                                }
                            }
                        }
                    }
                    else 
                    {
                        if (this._archive.Mode === 2/*ZipArchiveMode.Update*/ || !this._everOpenedForWrite)
                        {
                            this._everOpenedForWrite = true;
                            await this.WriteLocalFileHeaderAsync(this._uncompressedSize === 0n, forceWrite, cancellationToken).ConfigureAwait$2(false);
                            if (this._compressedSize !== 0n)
                            {
                                this._archive.ArchiveStream.Seek(this._compressedSize, 1/*SeekOrigin.Current*/);
                            }
                        }
                    }
                });
            }
            /*Task *//*async*/  WriteCrcAndSizesInLocalHeaderAsync(/*bool*/ zip64HeaderUsed, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let writeBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [20/*Zip64DataDescriptorCrcAndSizesBufferLength*/], null);
                    /*long*/ let finalPosition;
                    /*bool*/ let pretendStreaming;
                    /*uint*/ let compressedSizeTruncated;
                    /*uint*/ let uncompressedSizeTruncated;
                    this.WriteCrcAndSizesInLocalHeaderInitialize(zip64HeaderUsed, $.$ref(() => finalPosition, ($v) => finalPosition = $v, $.$spc.System.Int64), $.$ref(() => pretendStreaming, ($v) => pretendStreaming = $v, $.$spc.System.Boolean), $.$ref(() => compressedSizeTruncated, ($v) => compressedSizeTruncated = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeTruncated, ($v) => uncompressedSizeTruncated = $v, $.$spc.System.UInt32));
                    if (pretendStreaming)
                    {
                        this.WriteCrcAndSizesInLocalHeaderPrepareForZip64PretendStreaming($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(writeBuffer));
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, writeBuffer, 0, 4/*MetadataBufferLength*/)), cancellationToken).ConfigureAwait(false);
                    }
                    this.WriteCrcAndSizesInLocalHeaderPrepareFor32bitValuesWriting(pretendStreaming, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(writeBuffer), compressedSizeTruncated, uncompressedSizeTruncated);
                    await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, writeBuffer, 0, 12/*CrcAndSizesBufferLength*/)), cancellationToken).ConfigureAwait(false);
                    if (zip64HeaderUsed)
                    {
                        this.WriteCrcAndSizesInLocalHeaderPrepareForWritingWhenZip64HeaderUsed($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(writeBuffer));
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, writeBuffer, 0, 16/*Zip64SizesBufferLength*/)), cancellationToken).ConfigureAwait(false);
                    }
                    this._archive.ArchiveStream.Seek(finalPosition, 0/*SeekOrigin.Begin*/);
                    if (pretendStreaming)
                    {
                        this.WriteCrcAndSizesInLocalHeaderPrepareForWritingDataDescriptor($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(writeBuffer));
                        await this._archive.ArchiveStream.WriteAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, writeBuffer, 0, 20/*Zip64DataDescriptorCrcAndSizesBufferLength*/)), cancellationToken).ConfigureAwait(false);
                    }
                });
            }
            /*ValueTask */ WriteDataDescriptorAsync(/*CancellationToken*/ cancellationToken)
            {
                cancellationToken.ThrowIfCancellationRequested();
                /*byte[]*/ let dataDescriptor = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [24/*MaxSizeOfDataDescriptor*/], null);
                /*int*/ let bytesToWrite = this.PrepareToWriteDataDescriptor($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(dataDescriptor));
                return this._archive.ArchiveStream.WriteAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, dataDescriptor, 0, bytesToWrite)), cancellationToken);
            }
            /*Task *//*async*/  UnloadStreamsAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (this._storedUncompressedData !== null)
                    {
                        await this._storedUncompressedData.DisposeAsync().ConfigureAwait(false);
                    }
                    this._compressedBytes = null;
                    this._outstandingWriteStream = null;
                });
            }
            /*Task *//*async*/  CloseStreamsAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (this._outstandingWriteStream !== null)
                    {
                        await this._outstandingWriteStream.DisposeAsync().ConfigureAwait(false);
                    }
                });
            }
            /*ZipVersionMadeByPlatform*/ static CurrentZipPlatform = 3;
            static /*string */ ParseFileName(/*string*/ path, /*ZipVersionMadeByPlatform*/ madeByPlatform)
            {
                return madeByPlatform === 0/*ZipVersionMadeByPlatform.Windows*/ ? $.$sic.System.IO.Compression.ZipArchiveEntry.GetFileName_Windows(path) : $.$sic.System.IO.Compression.ZipArchiveEntry.GetFileName_Unix(path);
            }
            //default member initializer
            constructor()
            {
                super();
                this._lastModified = $.$default($.$spc.System.DateTimeOffset);
                this.Changes = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_allowLargeZipArchiveEntriesInUpdateMode = $.$spc.System.IntPtr.Size > 4;
                }
            }
            static $h = 2659707;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2528635,"g":{"r":0,"d":0,"h":146031547771,"f":1},"n":"Archive","d":2659707,"h":141736580475,"f":1},{"p":720897,"g":{"r":0,"d":0,"h":154621482363,"f":1},"n":"Crc32","d":2659707,"h":150326515067,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"p":262145,"g":{"r":0,"d":0,"h":163211416955,"f":1},"n":"IsEncrypted","d":2659707,"h":158916449659,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":171801351547,"f":1},"n":"CompressedLength","d":2659707,"h":167506384251,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":180391286139,"f":1},"s":{"r":0,"d":0,"h":184686253435,"f":1},"n":"ExternalAttributes","d":2659707,"h":176096318843,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":193276188027,"f":1},"s":{"r":0,"d":0,"h":197571155323,"f":1},"n":"Comment","d":2659707,"h":188981220731,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":206161089915,"f":1},"s":{"r":0,"d":0,"h":210456057211,"f":2},"n":"FullName","d":2659707,"h":201866122619,"f":1},{"p":34340865,"g":{"r":0,"d":0,"h":219045991803,"f":1},"s":{"r":0,"d":0,"h":223340959099,"f":1},"n":"LastWriteTime","d":2659707,"h":214751024507,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":231930893691,"f":1},"n":"Length","d":2659707,"h":227635926395,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":240520828283,"f":1},"n":"Name","d":2659707,"h":236225860987,"f":1},{"p":2594171,"g":{"r":0,"d":0,"h":253405730171,"f":8},"s":{"r":0,"d":0,"h":257700697467,"f":2},"n":"Changes","d":2659707,"h":249110762875,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":266290632059,"f":8},"n":"OriginallyInArchive","d":2659707,"h":261995664763,"f":8},{"p":917505,"g":{"r":0,"d":0,"h":274880566651,"f":8},"n":"OffsetOfLocalHeader","d":2659707,"h":270585599355,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":304945337723,"f":8},"n":"EverOpenedForWrite","d":2659707,"h":300650370427,"f":8},{"p":2790779,"g":{"r":0,"d":0,"h":322125206907,"f":2},"s":{"r":0,"d":0,"h":326420174203,"f":2},"n":"CompressionMethod","d":2659707,"h":317830239611,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":412319520123,"f":2},"n":"AreSizesTooLarge","d":2659707,"h":408024552827,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":429499389307,"f":2},"n":"IsOffsetTooLarge","d":2659707,"h":425204422011,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":438089323899,"f":2},"n":"ShouldUseZIP64","d":2659707,"h":433794356603,"f":2}],"m":[{"r":65537,"n":"Delete","d":2659707,"h":279175533947,"f":1},{"r":62128129,"n":"Open","d":2659707,"h":283470501243,"f":1},{"r":1310721,"n":"ToString","d":2659707,"h":287765468539,"f":32769},{"r":1310721,"p":[{"n":"entryStringBytes","p":0}],"n":"DecodeEntryString","d":2659707,"h":292060435835,"f":2},{"r":917505,"n":"GetOffsetOfCompressedData","d":2659707,"h":309240305019,"f":8},{"r":60948481,"n":"GetUncompressedData","d":2659707,"h":313535272315,"f":2},{"r":65537,"p":[{"n":"forceWrite","p":262145}],"n":"WriteAndFinishLocalEntry","d":2659707,"h":330715141499,"f":8},{"r":262145,"p":[{"n":"forceWrite","p":262145},{"n":"zip64ExtraField","p":2332027,"f":2},{"n":"compressedSizeTruncated","p":720897,"f":2},{"n":"uncompressedSizeTruncated","p":720897,"f":2},{"n":"extraFieldLength","p":589825,"f":2},{"n":"offsetOfLocalHeaderTruncated","p":720897,"f":2}],"n":"WriteCentralDirectoryFileHeaderInitialize","d":2659707,"h":335010108795,"f":2},{"r":65537,"p":[{"n":"cdStaticHeader","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"compressedSizeTruncated","p":720897},{"n":"uncompressedSizeTruncated","p":720897},{"n":"extraFieldLength","p":589825},{"n":"offsetOfLocalHeaderTruncated","p":720897}],"n":"WriteCentralDirectoryFileHeaderPrepare","d":2659707,"h":339305076091,"f":2},{"r":65537,"p":[{"n":"forceWrite","p":262145}],"n":"WriteCentralDirectoryFileHeader","d":2659707,"h":343600043387,"f":8},{"r":65537,"n":"LoadLocalHeaderExtraFieldIfNeeded","d":2659707,"h":347895010683,"f":8},{"r":0,"p":[{"n":"maxSingleBufferSize","p":655361,"f":2}],"n":"LoadCompressedBytesIfNeededInitialize","d":2659707,"h":352189977979,"f":2},{"r":65537,"n":"LoadCompressedBytesIfNeeded","d":2659707,"h":356484945275,"f":8},{"r":65537,"p":[{"n":"needToUncompress","p":262145},{"n":"needToLoadIntoMemory","p":262145}],"n":"ThrowIfNotOpenable","d":2659707,"h":360779912571,"f":8},{"r":65537,"n":"DetectEntryNameVersion","d":2659707,"h":365074879867,"f":2},{"r":693627,"p":[{"n":"backingStream","p":62128129},{"n":"leaveBackingStreamOpen","p":262145},{"n":"onClose","p":46989313}],"n":"GetDataCompressor","d":2659707,"h":369369847163,"f":2},{"r":62128129,"p":[{"n":"compressedStreamToRead","p":62128129}],"n":"GetDataDecompressor","d":2659707,"h":373664814459,"f":2},{"r":62128129,"p":[{"n":"checkOpenable","p":262145}],"n":"OpenInReadMode","d":2659707,"h":377959781755,"f":2},{"r":62128129,"p":[{"n":"offsetOfCompressedData","p":917505}],"n":"OpenInReadModeGetDataCompressor","d":2659707,"h":382254749051,"f":2},{"r":1873275,"n":"OpenInWriteMode","d":2659707,"h":386549716347,"f":2},{"r":1873275,"n":"OpenInUpdateMode","d":2659707,"h":390844683643,"f":2},{"r":262145,"p":[{"n":"needToUncompress","p":262145},{"n":"needToLoadIntoMemory","p":262145},{"n":"message","p":1310721,"f":2}],"n":"IsOpenable","d":2659707,"h":395139650939,"f":2},{"r":262145,"p":[{"n":"needToUncompress","p":262145},{"n":"message","p":1310721,"f":2}],"n":"IsOpenableInitialVerifications","d":2659707,"h":399434618235,"f":2},{"r":262145,"p":[{"n":"needToLoadIntoMemory","p":262145},{"n":"offsetOfCompressedData","p":917505},{"n":"message","p":1310721,"f":2}],"n":"IsOpenableFinalVerifications","d":2659707,"h":403729585531,"f":2},{"r":759163,"p":[{"n":"generalPurposeBitFlag","p":2725243},{"n":"compressionMethod","p":2790779}],"n":"MapCompressionLevel","d":2659707,"h":416614487419,"f":34},{"r":2725243,"p":[{"n":"generalPurposeBitFlag","p":2725243},{"n":"compressionLevel","p":759163},{"n":"compressionMethod","p":2790779}],"n":"MapDeflateCompressionOption","d":2659707,"h":420909454715,"f":34},{"r":262145,"p":[{"n":"isEmptyFile","p":262145},{"n":"forceWrite","p":262145},{"n":"zip64ExtraField","p":2332027,"f":2},{"n":"compressedSizeTruncated","p":720897,"f":2},{"n":"uncompressedSizeTruncated","p":720897,"f":2},{"n":"extraFieldLength","p":589825,"f":2}],"n":"WriteLocalFileHeaderInitialize","d":2659707,"h":442384291195,"f":2},{"r":65537,"p":[{"n":"lfStaticHeader","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"compressedSizeTruncated","p":720897},{"n":"uncompressedSizeTruncated","p":720897},{"n":"extraFieldLength","p":589825}],"n":"WriteLocalFileHeaderPrepare","d":2659707,"h":446679258491,"f":2},{"r":262145,"p":[{"n":"isEmptyFile","p":262145},{"n":"forceWrite","p":262145}],"n":"WriteLocalFileHeader","d":2659707,"h":450974225787,"f":2},{"r":65537,"p":[{"n":"forceWrite","p":262145}],"n":"WriteLocalFileHeaderAndDataIfNeeded","d":2659707,"h":455269193083,"f":2},{"r":65537,"p":[{"n":"zip64HeaderUsed","p":262145}],"n":"WriteCrcAndSizesInLocalHeader","d":2659707,"h":476744029563,"f":2},{"r":65537,"p":[{"n":"zip64HeaderUsed","p":262145},{"n":"finalPosition","p":917505,"f":2},{"n":"pretendStreaming","p":262145,"f":2},{"n":"compressedSizeTruncated","p":720897,"f":2},{"n":"uncompressedSizeTruncated","p":720897,"f":2}],"n":"WriteCrcAndSizesInLocalHeaderInitialize","d":2659707,"h":481038996859,"f":2},{"r":65537,"p":[{"n":"writeBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"WriteCrcAndSizesInLocalHeaderPrepareForZip64PretendStreaming","d":2659707,"h":485333964155,"f":2},{"r":65537,"p":[{"n":"pretendStreaming","p":262145},{"n":"writeBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"compressedSizeTruncated","p":720897},{"n":"uncompressedSizeTruncated","p":720897}],"n":"WriteCrcAndSizesInLocalHeaderPrepareFor32bitValuesWriting","d":2659707,"h":489628931451,"f":2},{"r":65537,"p":[{"n":"writeBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"WriteCrcAndSizesInLocalHeaderPrepareForWritingWhenZip64HeaderUsed","d":2659707,"h":493923898747,"f":2},{"r":65537,"p":[{"n":"writeBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"WriteCrcAndSizesInLocalHeaderPrepareForWritingDataDescriptor","d":2659707,"h":498218866043,"f":2},{"r":65537,"n":"WriteDataDescriptor","d":2659707,"h":506808800635,"f":2},{"r":655361,"p":[{"n":"dataDescriptor","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"PrepareToWriteDataDescriptor","d":2659707,"h":511103767931,"f":2},{"r":65537,"n":"UnloadStreams","d":2659707,"h":515398735227,"f":2},{"r":65537,"n":"CloseStreams","d":2659707,"h":519693702523,"f":2},{"r":65537,"p":[{"n":"value","p":4429179}],"n":"VersionToExtractAtLeast","d":2659707,"h":523988669819,"f":2},{"r":65537,"n":"ThrowIfInvalidArchive","d":2659707,"h":528283637115,"f":2},{"r":1310721,"p":[{"n":"path","p":1310721}],"n":"GetFileName_Windows","d":2659707,"h":532578604411,"f":34},{"r":1310721,"p":[{"n":"path","p":1310721}],"n":"GetFileName_Unix","d":2659707,"h":536873571707,"f":34},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.Stream).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"OpenAsync","d":2659707,"h":558348408187,"f":4097},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int64).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"GetOffsetOfCompressedDataAsync","d":2659707,"h":562643375483,"f":4104},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.MemoryStream).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"GetUncompressedDataAsync","d":2659707,"h":566938342779,"f":4098},{"r":133300225,"p":[{"n":"forceWrite","p":262145},{"n":"cancellationToken","p":125960193}],"n":"WriteAndFinishLocalEntryAsync","d":2659707,"h":571233310075,"f":4104},{"r":133300225,"p":[{"n":"forceWrite","p":262145},{"n":"cancellationToken","p":125960193}],"n":"WriteCentralDirectoryFileHeaderAsync","d":2659707,"h":575528277371,"f":4104},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"LoadLocalHeaderExtraFieldIfNeededAsync","d":2659707,"h":579823244667,"f":4104},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"LoadCompressedBytesIfNeededAsync","d":2659707,"h":584118211963,"f":4104},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean).$h,"p":[{"n":"needToUncompress","p":262145},{"n":"needToLoadIntoMemory","p":262145},{"n":"cancellationToken","p":125960193}],"n":"GetIsOpenableAsync","d":2659707,"h":588413179259,"f":4098},{"r":133300225,"p":[{"n":"needToUncompress","p":262145},{"n":"needToLoadIntoMemory","p":262145},{"n":"cancellationToken","p":125960193}],"n":"ThrowIfNotOpenableAsync","d":2659707,"h":592708146555,"f":4104},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.Stream).$h,"p":[{"n":"checkOpenable","p":262145},{"n":"cancellationToken","p":125960193}],"n":"OpenInReadModeAsync","d":2659707,"h":597003113851,"f":4098},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.WrappedStream).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"OpenInUpdateModeAsync","d":2659707,"h":601298081147,"f":4098},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.ValueTuple$$$($.$spc.System.Boolean, $.$spc.System.String)).$h,"p":[{"n":"needToUncompress","p":262145},{"n":"needToLoadIntoMemory","p":262145},{"n":"cancellationToken","p":125960193}],"n":"IsOpenableAsync","d":2659707,"h":605593048443,"f":4098},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean).$h,"p":[{"n":"isEmptyFile","p":262145},{"n":"forceWrite","p":262145},{"n":"cancellationToken","p":125960193}],"n":"WriteLocalFileHeaderAsync","d":2659707,"h":609888015739,"f":4098},{"r":133300225,"p":[{"n":"forceWrite","p":262145},{"n":"cancellationToken","p":125960193}],"n":"WriteLocalFileHeaderAndDataIfNeededAsync","d":2659707,"h":614182983035,"f":4098},{"r":133300225,"p":[{"n":"zip64HeaderUsed","p":262145},{"n":"cancellationToken","p":125960193}],"n":"WriteCrcAndSizesInLocalHeaderAsync","d":2659707,"h":618477950331,"f":4098},{"r":136118273,"p":[{"n":"cancellationToken","p":125960193}],"n":"WriteDataDescriptorAsync","d":2659707,"h":622772917627,"f":2},{"r":133300225,"n":"UnloadStreamsAsync","d":2659707,"h":627067884923,"f":4098},{"r":133300225,"n":"CloseStreamsAsync","d":2659707,"h":631362852219,"f":4098},{"r":1310721,"p":[{"n":"path","p":1310721},{"n":"madeByPlatform","p":4363643}],"n":"ParseFileName","d":2659707,"h":639952786811,"f":40}],"l":[{"t":2528635,"n":"_archive","d":2659707,"h":4297627003,"f":2},{"t":262145,"n":"_originallyInArchive","d":2659707,"h":8592594299,"f":2},{"t":720897,"n":"_diskNumberStart","d":2659707,"h":12887561595,"f":2},{"t":4363643,"n":"_versionMadeByPlatform","d":2659707,"h":17182528891,"f":2},{"t":4429179,"n":"_versionMadeBySpecification","d":2659707,"h":21477496187,"f":2},{"t":4429179,"n":"_versionToExtract","d":2659707,"h":25772463483,"f":2},{"t":2725243,"n":"_generalPurposeBitFlag","d":2659707,"h":30067430779,"f":2},{"t":262145,"n":"_isEncrypted","d":2659707,"h":34362398075,"f":2},{"t":2790779,"n":"_storedCompressionMethod","d":2659707,"h":38657365371,"f":2},{"t":34340865,"n":"_lastModified","d":2659707,"h":42952332667,"f":2},{"t":917505,"n":"_compressedSize","d":2659707,"h":47247299963,"f":2},{"t":917505,"n":"_uncompressedSize","d":2659707,"h":51542267259,"f":2},{"t":917505,"n":"_offsetOfLocalHeader","d":2659707,"h":55837234555,"f":2},{"t":$.$typeNullable($.$spc.System.Int64).$h,"n":"_storedOffsetOfCompressedData","d":2659707,"h":60132201851,"f":2},{"t":720897,"n":"_crc32","d":2659707,"h":64427169147,"f":2},{"t":0,"n":"_compressedBytes","d":2659707,"h":68722136443,"f":2},{"t":60948481,"n":"_storedUncompressedData","d":2659707,"h":73017103739,"f":2},{"t":262145,"n":"_currentlyOpenForWrite","d":2659707,"h":77312071035,"f":2},{"t":262145,"n":"_everOpenedForWrite","d":2659707,"h":81607038331,"f":2},{"t":62128129,"n":"_outstandingWriteStream","d":2659707,"h":85902005627,"f":2},{"t":720897,"n":"_externalFileAttr","d":2659707,"h":90196972923,"f":2},{"t":1310721,"n":"_storedEntryName","d":2659707,"h":94491940219,"f":2},{"t":0,"n":"_storedEntryNameBytes","d":2659707,"h":98786907515,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h,"n":"_cdUnknownExtraFields","d":2659707,"h":103081874811,"f":2},{"t":0,"n":"_cdTrailingExtraFieldData","d":2659707,"h":107376842107,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h,"n":"_lhUnknownExtraFields","d":2659707,"h":111671809403,"f":2},{"t":0,"n":"_lhTrailingExtraFieldData","d":2659707,"h":115966776699,"f":2},{"t":0,"n":"_fileComment","d":2659707,"h":120261743995,"f":2},{"t":759163,"n":"_compressionLevel","d":2659707,"h":124556711291,"f":2},{"t":262145,"n":"s_allowLargeZipArchiveEntriesInUpdateMode","d":2659707,"h":296355403131,"f":34},{"t":655361,"n":"MetadataBufferLength","d":2659707,"h":459564160379,"f":34},{"t":655361,"n":"CrcAndSizesBufferLength","d":2659707,"h":463859127675,"f":34},{"t":655361,"n":"Zip64SizesBufferLength","d":2659707,"h":468154094971,"f":34},{"t":655361,"n":"Zip64DataDescriptorCrcAndSizesBufferLength","d":2659707,"h":472449062267,"f":34},{"t":655361,"n":"MaxSizeOfDataDescriptor","d":2659707,"h":502513833339,"f":34},{"t":4363643,"n":"CurrentZipPlatform","d":2659707,"h":635657819515,"f":40}],"c":[{"p":[{"n":"archive","p":2528635},{"n":"cd","p":3118459}],"n":".ctor","o":"$ctor$1","d":2659707,"h":128851678587,"f":8},{"p":[{"n":"archive","p":2528635},{"n":"entryName","p":1310721},{"n":"compressionLevel","p":759163}],"n":".ctor","o":"$ctor$2","d":2659707,"h":133146645883,"f":8},{"p":[{"n":"archive","p":2528635},{"n":"entryName","p":1310721}],"n":".ctor","o":"$ctor$3","d":2659707,"h":137441613179,"f":8}],"j":[2856315,2725243,2790779,2921851],"h":2659707}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ZipArchiveEntry`; }
        });
        
        $asm.$cls("$sic.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sic.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.IO.Compression", $.$sic.System.SR.$type.Assembly);
                    $.$sic.System.SR.s_resourceManager = temp;
                }
                return $.$sic.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sic.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sic.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentOutOfRange_Enum()
            {
                return "Enum value was out of legal range.";
            }
            static /*string */ get CannotReadFromDeflateStream()
            {
                return "Reading from the compression stream is not supported.";
            }
            static /*string */ get CannotWriteToDeflateStream()
            {
                return "Writing to the compression stream is not supported.";
            }
            static /*string */ get GenericInvalidData()
            {
                return "Found invalid data while decoding.";
            }
            static /*string */ get InvalidBeginCall()
            {
                return "Only one asynchronous reader or writer is allowed time at one time.";
            }
            static /*string */ get InvalidBlockLength()
            {
                return "Block length does not match with its complement.";
            }
            static /*string */ get InvalidHuffmanData()
            {
                return "Failed to construct a huffman tree using the length array. The stream might be corrupted.";
            }
            static /*string */ get NotSupported()
            {
                return "This operation is not supported.";
            }
            static /*string */ get NotSupported_UnreadableStream()
            {
                return "Stream does not support reading.";
            }
            static /*string */ get NotSupported_UnwritableStream()
            {
                return "Stream does not support writing.";
            }
            static /*string */ get UnknownBlockType()
            {
                return "Unknown block type. Stream might be corrupted.";
            }
            static /*string */ get UnknownState()
            {
                return "Decoder is in some unknown state. This might be caused by corrupted data.";
            }
            static /*string */ get ZLibErrorDLLLoadError()
            {
                return "The underlying compression routine could not be loaded correctly.";
            }
            static /*string */ get ZLibErrorInconsistentStream()
            {
                return "The stream state of the underlying compression routine is inconsistent.";
            }
            static /*string */ get ZLibErrorIncorrectInitParameters()
            {
                return "The underlying compression routine received incorrect initialization parameters.";
            }
            static /*string */ get ZLibErrorNotEnoughMemory()
            {
                return "The underlying compression routine could not reserve sufficient memory.";
            }
            static /*string */ get ZLibErrorVersionMismatch()
            {
                return "The version of the underlying compression routine does not match expected version.";
            }
            static /*string */ get ZLibErrorUnexpected()
            {
                return "The underlying compression routine returned an unexpected error code.";
            }
            static /*string */ get CDCorrupt()
            {
                return "Central Directory corrupt.";
            }
            static /*string */ get CentralDirectoryInvalid()
            {
                return "Central Directory is invalid.";
            }
            static /*string */ get CreateInReadMode()
            {
                return "Cannot create entries on an archive opened in read mode.";
            }
            static /*string */ get CreateModeCapabilities()
            {
                return "Cannot use create mode on a non-writable stream.";
            }
            static /*string */ get CreateModeCreateEntryWhileOpen()
            {
                return "Entries cannot be created while previously created entries are still open.";
            }
            static /*string */ get CreateModeWriteOnceAndOneEntryAtATime()
            {
                return "Entries in create mode may only be written to once, and only one entry may be held open at a time.";
            }
            static /*string */ get DateTimeOutOfRange()
            {
                return "The DateTimeOffset specified cannot be converted into a Zip file timestamp.";
            }
            static /*string */ get DeletedEntry()
            {
                return "Cannot modify deleted entry.";
            }
            static /*string */ get DeleteOnlyInUpdate()
            {
                return "Delete can only be used when the archive is in Update mode.";
            }
            static /*string */ get DeleteOpenEntry()
            {
                return "Cannot delete an entry currently open for writing.";
            }
            static /*string */ get EntriesInCreateMode()
            {
                return "Cannot access entries in Create mode.";
            }
            static /*string */ get EntryNameAndCommentEncodingNotSupported()
            {
                return "The specified encoding is not supported for entry names and comments.";
            }
            static /*string */ get EntryNamesTooLong()
            {
                return "Entry names cannot require more than 2^16 bits.";
            }
            static /*string */ get EntryTooLarge()
            {
                return "Entries larger than 4GB are not supported in Update mode.";
            }
            static /*string */ get EOCDNotFound()
            {
                return "End of Central Directory record could not be found.";
            }
            static /*string */ get FieldTooBigCompressedSize()
            {
                return "Compressed Size cannot be held in an Int64.";
            }
            static /*string */ get FieldTooBigLocalHeaderOffset()
            {
                return "Local Header Offset cannot be held in an Int64.";
            }
            static /*string */ get FieldTooBigNumEntries()
            {
                return "Number of Entries cannot be held in an Int64.";
            }
            static /*string */ get FieldTooBigOffsetToCD()
            {
                return "Offset to Central Directory cannot be held in an Int64.";
            }
            static /*string */ get FieldTooBigOffsetToZip64EOCD()
            {
                return "Offset to Zip64 End Of Central Directory record cannot be held in an Int64.";
            }
            static /*string */ get FieldTooBigUncompressedSize()
            {
                return "Uncompressed Size cannot be held in an Int64.";
            }
            static /*string */ get FrozenAfterWrite()
            {
                return "Cannot modify entry in Create mode after entry has been opened for writing.";
            }
            static /*string */ get HiddenStreamName()
            {
                return "A stream from ZipArchiveEntry has been disposed.";
            }
            static /*string */ get LengthAfterWrite()
            {
                return "Length properties are unavailable once an entry has been opened for writing.";
            }
            static /*string */ get LocalFileHeaderCorrupt()
            {
                return "A local file header is corrupt.";
            }
            static /*string */ get NumEntriesWrong()
            {
                return "Number of entries expected in End Of Central Directory does not correspond to number of entries in Central Directory.";
            }
            static /*string */ get ReadingNotSupported()
            {
                return "This stream from ZipArchiveEntry does not support reading.";
            }
            static /*string */ get ReadModeCapabilities()
            {
                return "Cannot use read mode on a non-readable stream.";
            }
            static /*string */ get ReadOnlyArchive()
            {
                return "Cannot modify read-only archive.";
            }
            static /*string */ get SeekingNotSupported()
            {
                return "This stream from ZipArchiveEntry does not support seeking.";
            }
            static /*string */ get SetLengthRequiresSeekingAndWriting()
            {
                return "SetLength requires a stream that supports seeking and writing.";
            }
            static /*string */ get SplitSpanned()
            {
                return "Split or spanned archives are not supported.";
            }
            static /*string */ get TruncatedData()
            {
                return "Found truncated data while decoding.";
            }
            static /*string */ get UnexpectedEndOfStream()
            {
                return "Zip file corrupt: unexpected end of stream reached.";
            }
            static /*string */ get UnsupportedCompression()
            {
                return "The archive entry was compressed using an unsupported compression method.";
            }
            static /*string */ get UnsupportedCompressionMethod()
            {
                return "The archive entry was compressed using {0} and is not supported.";
            }
            static /*string */ FormatUnsupportedCompressionMethod(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The archive entry was compressed using {0} and is not supported.", arg1);
            }
            static /*string */ get UpdateModeCapabilities()
            {
                return "Update mode requires a stream with read, write, and seek capabilities.";
            }
            static /*string */ get UpdateModeOneStream()
            {
                return "Entries cannot be opened multiple times in Update mode.";
            }
            static /*string */ get WritingNotSupported()
            {
                return "This stream from ZipArchiveEntry does not support writing.";
            }
            static /*string */ get Zip64EOCDNotWhereExpected()
            {
                return "Zip 64 End of Central Directory Record not where indicated.";
            }
            static /*string */ get PlatformNotSupported_Compression()
            {
                return "System.IO.Compression is not supported on this platform.";
            }
            static /*string */ get InvalidOffsetToZip64EOCD()
            {
                return "Invalid offset to the Zip64 End of Central Directory record.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sic.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sic.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sic.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sic.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sic.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sic.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sic.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 5412219;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":5412219}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipGenericExtraField", ($self) => class ZipGenericExtraField extends $.$spc.System.Object
        {
            /*int*/ static SizeOfHeader = 4;
            /*ushort*/ _tag = 0;
            /*ushort*/ _size = 0;
            /*byte[]?*/ _data = null;
            /*ushort */ get Tag()
            {
                return this._tag;
            }
            /*ushort */ get Size()
            {
                return this._size;
            }
            /*byte[] */ get Data()
            {
                return this._data ??= $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [  ], null, null);
            }
            /*void */ WriteBlock(/*Stream*/ stream)
            {
                /*Span<byte>*/ let extraFieldHeader = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 4/*SizeOfHeader*/, null);
                this.WriteBlockCore(extraFieldHeader);
                stream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(extraFieldHeader));
                stream.Write$1($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this.Data));
            }
            /*void */ WriteBlockCore(/*Span<byte>*/ extraFieldHeader)
            {
                let $t1 = extraFieldHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t1.Slice$1(0/*FieldLocations.Tag*/, $t1.Length - 0/*FieldLocations.Tag*/), this._tag);
                let $t2 = extraFieldHeader;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t2.Slice$1(2/*FieldLocations.Size*/, $t2.Length - 2/*FieldLocations.Size*/), this._size);
            }
            static /*bool */ TryReadBlock(/*ReadOnlySpan<byte>*/ bytes, /*out int*/ bytesConsumed, /*out ZipGenericExtraField*/ field)
            {
                field.$v = new $.$sic.System.IO.Compression.ZipGenericExtraField().$ctor$1();
                bytesConsumed.$v = 0;
                if (bytes.Length < 4/*SizeOfHeader*/)
                {
                    return false;
                }
                let $t1 = bytes;
                field.$v._tag = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t1.Slice$1(0/*FieldLocations.Tag*/, $t1.Length - 0/*FieldLocations.Tag*/));
                let $t2 = bytes;
                field.$v._size = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t2.Slice$1(2/*FieldLocations.Size*/, $t2.Length - 2/*FieldLocations.Size*/));
                if ((((bytes.Length - 4/*SizeOfHeader*/) | 0)) < field.$v._size)
                {
                    return false;
                }
                field.$v._data = bytes.Slice$1(4/*FieldLocations.DynamicData*/, field.$v._size).ToArray();
                bytesConsumed.$v = ((field.$v.Size + 4/*SizeOfHeader*/) | 0);
                return true;
            }
            static /*List<ZipGenericExtraField> */ ParseExtraField(/*ReadOnlySpan<byte>*/ extraFieldData, /*out ReadOnlySpan<byte>*/ trailingExtraFieldData)
            {
                /*List<ZipGenericExtraField>*/ let extraFields = new ($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField))().$ctor$1();
                /*int*/ let totalBytesConsumed = 0;
                let $t1 = extraFieldData;
                /*int*/ let currBytesConsumed;
                /*ZipGenericExtraField*/ let field;
                while($.$sic.System.IO.Compression.ZipGenericExtraField.TryReadBlock($t1.Slice$1(totalBytesConsumed, $t1.Length - totalBytesConsumed), $.$ref(() => currBytesConsumed, ($v) => currBytesConsumed = $v, $.$spc.System.Int32), $.$ref(() => field, ($v) => field = $v, $.$sic.System.IO.Compression.ZipGenericExtraField)))
                {
                    totalBytesConsumed += currBytesConsumed;
                    extraFields.Add(field);
                }
                let $t4 = extraFieldData;
                trailingExtraFieldData.$v = $t4.Slice$1(totalBytesConsumed, $t4.Length - totalBytesConsumed);
                return extraFields;
            }
            static /*int */ TotalSize(/*List<ZipGenericExtraField>?*/ fields, /*int*/ trailingDataLength)
            {
                /*int*/ let size = trailingDataLength;
                if (fields !== null)
                {
                    var $en3 = fields.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var field = $en3.Current;
                        {
                            size += ((field.Size + 4/*SizeOfHeader*/) | 0);
                        }
                    }
                }
                return size;
            }
            static /*void */ WriteAllBlocks(/*List<ZipGenericExtraField>?*/ fields, /*ReadOnlySpan<byte>*/ trailingExtraFieldData, /*Stream*/ stream)
            {
                if (fields !== null)
                {
                    var $en3 = fields.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var field = $en3.Current;
                        {
                            field.WriteBlock(stream);
                        }
                    }
                }
                if (!trailingExtraFieldData.IsEmpty)
                {
                    stream.Write$1(trailingExtraFieldData);
                }
            }
            /*Task *//*async*/  WriteBlockAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let extraFieldHeader = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [4/*SizeOfHeader*/], null);
                    this.WriteBlockCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(extraFieldHeader));
                    await stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(extraFieldHeader), cancellationToken).ConfigureAwait(false);
                    await stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(this.Data), cancellationToken).ConfigureAwait(false);
                });
            }
            static /*Task *//*async*/  WriteAllBlocksAsync(/*List<ZipGenericExtraField>?*/ fields, /*ReadOnlyMemory<byte>*/ trailingExtraFieldData, /*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (fields !== null)
                    {
                        var $en4 = fields.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var field = $en4.Current;
                            {
                                await field.WriteBlockAsync(stream, cancellationToken).ConfigureAwait(false);
                            }
                        }
                    }
                    if (!trailingExtraFieldData.IsEmpty)
                    {
                        await stream.WriteAsync$2(trailingExtraFieldData, cancellationToken).ConfigureAwait(false);
                    }
                });
            }
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.ZipGenericExtraField;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.ZipGenericExtraField.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static Tag = 2;
                    /*int*/ static Size = 2;
                    static $h = 3577211;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Tag","d":3577211,"h":4298544507,"f":33},{"t":655361,"n":"Size","d":3577211,"h":8593511803,"f":33}],"d":3511675,"h":3577211}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipGenericExtraField.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.ZipGenericExtraField;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.ZipGenericExtraField.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Tag = 0;
                    /*int*/ static Size = 2;
                    /*int*/ static DynamicData = 4;
                    static $h = 3642747;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Tag","d":3642747,"h":4298610043,"f":33},{"t":655361,"n":"Size","d":3642747,"h":8593577339,"f":33},{"t":655361,"n":"DynamicData","d":3642747,"h":12888544635,"f":33}],"d":3511675,"h":3642747}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipGenericExtraField.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 3511675;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":589825,"g":{"r":0,"d":0,"h":25773315451,"f":1},"n":"Tag","d":3511675,"h":21478348155,"f":1},{"p":589825,"g":{"r":0,"d":0,"h":34363250043,"f":1},"n":"Size","d":3511675,"h":30068282747,"f":1},{"p":0,"g":{"r":0,"d":0,"h":42953184635,"f":1},"n":"Data","d":3511675,"h":38658217339,"f":1}],"m":[{"r":65537,"p":[{"n":"stream","p":62128129}],"n":"WriteBlock","d":3511675,"h":47248151931,"f":1},{"r":65537,"p":[{"n":"extraFieldHeader","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"WriteBlockCore","d":3511675,"h":51543119227,"f":2},{"r":262145,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"bytesConsumed","p":655361,"f":2},{"n":"field","p":3511675,"f":2}],"n":"TryReadBlock","d":3511675,"h":55838086523,"f":33},{"r":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h,"p":[{"n":"extraFieldData","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"trailingExtraFieldData","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"f":2}],"n":"ParseExtraField","d":3511675,"h":60133053819,"f":33},{"r":655361,"p":[{"n":"fields","p":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h},{"n":"trailingDataLength","p":655361}],"n":"TotalSize","d":3511675,"h":64428021115,"f":33},{"r":65537,"p":[{"n":"fields","p":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h},{"n":"trailingExtraFieldData","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"stream","p":62128129}],"n":"WriteAllBlocks","d":3511675,"h":68722988411,"f":33},{"r":133300225,"p":[{"n":"stream","p":62128129},{"n":"cancellationToken","p":125960193}],"n":"WriteBlockAsync","d":3511675,"h":73017955707,"f":4097},{"r":133300225,"p":[{"n":"fields","p":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h},{"n":"trailingExtraFieldData","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"stream","p":62128129},{"n":"cancellationToken","p":125960193}],"n":"WriteAllBlocksAsync","d":3511675,"h":77312923003,"f":4129}],"l":[{"t":655361,"n":"SizeOfHeader","d":3511675,"h":4298478971,"f":34},{"t":589825,"n":"_tag","d":3511675,"h":8593446267,"f":2},{"t":589825,"n":"_size","d":3511675,"h":12888413563,"f":2},{"t":0,"n":"_data","d":3511675,"h":17183380859,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":3511675,"h":90197824891,"f":1}],"j":[3577211,3642747],"h":3511675}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ZipGenericExtraField`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.Zip64ExtraField", ($self) => class Zip64ExtraField extends $.$spc.System.Object
        {
            /*int*/ static OffsetToFirstField = 4;
            /*ushort*/ static TagConstant = 1;
            /*ushort*/ _size = 0;
            /*long?*/ _uncompressedSize = null;
            /*long?*/ _compressedSize = null;
            /*long?*/ _localHeaderOffset = null;
            /*uint?*/ _startDiskNumber = null;
            /*ushort */ get TotalSize()
            {
                return $.$cast((((this._size + 4) | 0)), $.$spc.System.UInt16);
            }
            /*long? */ get UncompressedSize()
            {
                return this._uncompressedSize;
            }
            /*long? */ set UncompressedSize(value)
            {
                this._uncompressedSize = value;
                this.UpdateSize();
            }
            /*long? */ get CompressedSize()
            {
                return this._compressedSize;
            }
            /*long? */ set CompressedSize(value)
            {
                this._compressedSize = value;
                this.UpdateSize();
            }
            /*long? */ get LocalHeaderOffset()
            {
                return this._localHeaderOffset;
            }
            /*long? */ set LocalHeaderOffset(value)
            {
                this._localHeaderOffset = value;
                this.UpdateSize();
            }
            /*uint? */ get StartDiskNumber()
            {
                return this._startDiskNumber;
            }
            /*void */ UpdateSize()
            {
                this._size = 0;
                if (this._uncompressedSize !== null)
                {
                    this._size += 8/*FieldLengths.UncompressedSize*/;
                }
                if (this._compressedSize !== null)
                {
                    this._size += 8/*FieldLengths.CompressedSize*/;
                }
                if (this._localHeaderOffset !== null)
                {
                    this._size += 8/*FieldLengths.LocalHeaderOffset*/;
                }
                if (this._startDiskNumber !== null)
                {
                    this._size += 4/*FieldLengths.StartDiskNumber*/;
                }
            }
            static /*Zip64ExtraField */ GetJustZip64Block(/*ReadOnlySpan<byte>*/ extraFieldData, /*bool*/ readUncompressedSize, /*bool*/ readCompressedSize, /*bool*/ readLocalHeaderOffset, /*bool*/ readStartDiskNumber)
            {
                /*Zip64ExtraField*/ let zip64Field;
                /*int*/ let totalBytesConsumed = 0;
                /*int*/ let currBytesConsumed;
                /*ZipGenericExtraField*/ let currentExtraField;
                while($.$sic.System.IO.Compression.ZipGenericExtraField.TryReadBlock(extraFieldData.Slice(totalBytesConsumed), $.$ref(() => currBytesConsumed, ($v) => currBytesConsumed = $v, $.$spc.System.Int32), $.$ref(() => currentExtraField, ($v) => currentExtraField = $v, $.$sic.System.IO.Compression.ZipGenericExtraField)))
                {
                    totalBytesConsumed += currBytesConsumed;
                    if ($.$sic.System.IO.Compression.Zip64ExtraField.TryGetZip64BlockFromGenericExtraField(currentExtraField, readUncompressedSize, readCompressedSize, readLocalHeaderOffset, readStartDiskNumber, $.$ref(() => zip64Field, ($v) => zip64Field = $v, $.$sic.System.IO.Compression.Zip64ExtraField)))
                    {
                        return zip64Field;
                    }
                }
                zip64Field = (() =>
                {
                    //new $.$sic.System.IO.Compression.Zip64ExtraField()
                    const $t3 = $.$sic.System.IO.Compression.Zip64ExtraField;
                    const $i3 = new $t3();
                    $i3._compressedSize = null;
                    $i3._uncompressedSize = null;
                    $i3._localHeaderOffset = null;
                    $i3._startDiskNumber = null;
                    return $i3;
                })();
                return zip64Field;
            }
            static /*bool */ TryGetZip64BlockFromGenericExtraField(/*ZipGenericExtraField*/ extraField, /*bool*/ readUncompressedSize, /*bool*/ readCompressedSize, /*bool*/ readLocalHeaderOffset, /*bool*/ readStartDiskNumber, /*out Zip64ExtraField*/ zip64Block)
            {
                /*int*/ let MaximumExtraFieldLength = ((((((8/*FieldLengths.UncompressedSize*/ + 8/*FieldLengths.CompressedSize*/) | 0) + 8/*FieldLengths.LocalHeaderOffset*/) | 0) + 4/*FieldLengths.StartDiskNumber*/) | 0);
                zip64Block.$v = (() =>
                {
                    //new $.$sic.System.IO.Compression.Zip64ExtraField()
                    const $t1 = $.$sic.System.IO.Compression.Zip64ExtraField;
                    const $i1 = new $t1();
                    $i1._compressedSize = null;
                    $i1._uncompressedSize = null;
                    $i1._localHeaderOffset = null;
                    $i1._startDiskNumber = null;
                    return $i1;
                })();
                if (extraField.Tag !== 1/*TagConstant*/)
                {
                    return false;
                }
                zip64Block.$v._size = extraField.Size;
                /*ReadOnlySpan<byte>*/ let data = $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(extraField.Data);
                if (data.Length < 8/*FieldLengths.UncompressedSize*/)
                {
                    return true;
                }
                /*bool*/ let readAllFields = extraField.Size >= MaximumExtraFieldLength;
                if (readUncompressedSize)
                {
                    zip64Block.$v._uncompressedSize = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadInt64LittleEndian(data);
                    data = data.Slice(8/*FieldLengths.UncompressedSize*/);
                }
                else if (readAllFields)
                {
                    data = data.Slice(8/*FieldLengths.UncompressedSize*/);
                }
                if (data.Length < 8/*FieldLengths.CompressedSize*/)
                {
                    return true;
                }
                if (readCompressedSize)
                {
                    zip64Block.$v._compressedSize = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadInt64LittleEndian(data);
                    data = data.Slice(8/*FieldLengths.CompressedSize*/);
                }
                else if (readAllFields)
                {
                    data = data.Slice(8/*FieldLengths.CompressedSize*/);
                }
                if (data.Length < 8/*FieldLengths.LocalHeaderOffset*/)
                {
                    return true;
                }
                if (readLocalHeaderOffset)
                {
                    zip64Block.$v._localHeaderOffset = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadInt64LittleEndian(data);
                    data = data.Slice(8/*FieldLengths.LocalHeaderOffset*/);
                }
                else if (readAllFields)
                {
                    data = data.Slice(8/*FieldLengths.LocalHeaderOffset*/);
                }
                if (data.Length < 4/*FieldLengths.StartDiskNumber*/)
                {
                    return true;
                }
                if (readStartDiskNumber)
                {
                    zip64Block.$v._startDiskNumber = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(data);
                }
                if (zip64Block.$v._uncompressedSize < 0)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigUncompressedSize);
                }
                if (zip64Block.$v._compressedSize < 0)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigCompressedSize);
                }
                if (zip64Block.$v._localHeaderOffset < 0)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigLocalHeaderOffset);
                }
                return true;
            }
            static /*Zip64ExtraField */ GetAndRemoveZip64Block(/*List<ZipGenericExtraField>*/ extraFields, /*bool*/ readUncompressedSize, /*bool*/ readCompressedSize, /*bool*/ readLocalHeaderOffset, /*bool*/ readStartDiskNumber)
            {
                /*Zip64ExtraField*/ let zip64Field = (() =>
                {
                    //new $.$sic.System.IO.Compression.Zip64ExtraField()
                    const $t1 = $.$sic.System.IO.Compression.Zip64ExtraField;
                    const $i1 = new $t1();
                    $i1._compressedSize = null;
                    $i1._uncompressedSize = null;
                    $i1._localHeaderOffset = null;
                    $i1._startDiskNumber = null;
                    return $i1;
                })();
                /*bool*/ let zip64FieldFound = false;
                extraFields.RemoveAll(new ($.$spc.System.Predicate$$($.$sic.System.IO.Compression.ZipGenericExtraField))().$ctor(this,  (/*ef*/ ef) =>
                {
                    if (ef.Tag === 1/*TagConstant*/)
                    {
                        if (!zip64FieldFound)
                        {
                            if ($.$sic.System.IO.Compression.Zip64ExtraField.TryGetZip64BlockFromGenericExtraField(ef, readUncompressedSize, readCompressedSize, readLocalHeaderOffset, readStartDiskNumber, $.$ref(() => zip64Field, ($v) => zip64Field = $v, $.$sic.System.IO.Compression.Zip64ExtraField)))
                            {
                                zip64FieldFound = true;
                            }
                        }
                        return true;
                    }
                    return false;
                }));
                return zip64Field;
            }
            static /*void */ RemoveZip64Blocks(/*List<ZipGenericExtraField>*/ extraFields)
            {
                extraFields.RemoveAll(new ($.$spc.System.Predicate$$($.$sic.System.IO.Compression.ZipGenericExtraField))().$ctor(this,  (/**/ field) =>
                {
                    return field.Tag === 1/*TagConstant*/;
                }));
            }
            /*void */ WriteBlockCore(/*Span<byte>*/ extraFieldData)
            {
                /*int*/ let startOffset = 4/*ZipGenericExtraField.FieldLocations.DynamicData*/;
                let $t1 = extraFieldData;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t1.Slice$1(0/*FieldLocations.Tag*/, $t1.Length - 0/*FieldLocations.Tag*/), 1/*TagConstant*/);
                let $t2 = extraFieldData;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t2.Slice$1(2/*FieldLocations.Size*/, $t2.Length - 2/*FieldLocations.Size*/), this._size);
                if (this._uncompressedSize !== null)
                {
                    let $t3 = extraFieldData;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t3.Slice$1(startOffset, $t3.Length - startOffset), $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(this._uncompressedSize));
                    startOffset += 8/*FieldLengths.UncompressedSize*/;
                }
                if (this._compressedSize !== null)
                {
                    let $t3 = extraFieldData;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t3.Slice$1(startOffset, $t3.Length - startOffset), $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(this._compressedSize));
                    startOffset += 8/*FieldLengths.CompressedSize*/;
                }
                if (this._localHeaderOffset !== null)
                {
                    let $t3 = extraFieldData;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t3.Slice$1(startOffset, $t3.Length - startOffset), $.$spc.System.Nullable$$($.$spc.System.Int64).Value$get.call(this._localHeaderOffset));
                    startOffset += 8/*FieldLengths.LocalHeaderOffset*/;
                }
                if (this._startDiskNumber !== null)
                {
                    let $t3 = extraFieldData;
                    $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t3.Slice$1(startOffset, $t3.Length - startOffset), $.$spc.System.Nullable$$($.$spc.System.UInt32).Value$get.call(this._startDiskNumber));
                }
            }
            /*void */ WriteBlock(/*Stream*/ stream)
            {
                /*Span<byte>*/ let extraFieldData = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, this.TotalSize, null);
                this.WriteBlockCore(extraFieldData);
                stream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(extraFieldData));
            }
            /*ValueTask */ WriteBlockAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                cancellationToken.ThrowIfCancellationRequested();
                /*byte[]*/ let extraFieldData = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [this.TotalSize], null);
                this.WriteBlockCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(extraFieldData));
                return stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(extraFieldData), cancellationToken);
            }
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.Zip64ExtraField;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.Zip64ExtraField.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static UncompressedSize = 8;
                    /*int*/ static CompressedSize = 8;
                    /*int*/ static LocalHeaderOffset = 8;
                    /*int*/ static StartDiskNumber = 4;
                    static $h = 2397563;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"UncompressedSize","d":2397563,"h":4297364859,"f":33},{"t":655361,"n":"CompressedSize","d":2397563,"h":8592332155,"f":33},{"t":655361,"n":"LocalHeaderOffset","d":2397563,"h":12887299451,"f":33},{"t":655361,"n":"StartDiskNumber","d":2397563,"h":17182266747,"f":33}],"d":2332027,"h":2397563}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.Zip64ExtraField.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.Zip64ExtraField;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.Zip64ExtraField.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Tag = 0;
                    /*int*/ static Size = 2;
                    /*int*/ static UncompressedSize = 4;
                    /*int*/ static CompressedSize = 12;
                    /*int*/ static LocalHeaderOffset = 20;
                    /*int*/ static StartDiskNumber = 28;
                    static $h = 2463099;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Tag","d":2463099,"h":4297430395,"f":33},{"t":655361,"n":"Size","d":2463099,"h":8592397691,"f":33},{"t":655361,"n":"UncompressedSize","d":2463099,"h":12887364987,"f":33},{"t":655361,"n":"CompressedSize","d":2463099,"h":17182332283,"f":33},{"t":655361,"n":"LocalHeaderOffset","d":2463099,"h":21477299579,"f":33},{"t":655361,"n":"StartDiskNumber","d":2463099,"h":25772266875,"f":33}],"d":2332027,"h":2463099}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.Zip64ExtraField.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2332027;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":589825,"g":{"r":0,"d":0,"h":38657037691,"f":1},"n":"TotalSize","d":2332027,"h":34362070395,"f":1},{"p":$.$typeNullable($.$spc.System.Int64).$h,"g":{"r":0,"d":0,"h":47246972283,"f":1},"s":{"r":0,"d":0,"h":51541939579,"f":1},"n":"UncompressedSize","d":2332027,"h":42952004987,"f":1},{"p":$.$typeNullable($.$spc.System.Int64).$h,"g":{"r":0,"d":0,"h":60131874171,"f":1},"s":{"r":0,"d":0,"h":64426841467,"f":1},"n":"CompressedSize","d":2332027,"h":55836906875,"f":1},{"p":$.$typeNullable($.$spc.System.Int64).$h,"g":{"r":0,"d":0,"h":73016776059,"f":1},"s":{"r":0,"d":0,"h":77311743355,"f":1},"n":"LocalHeaderOffset","d":2332027,"h":68721808763,"f":1},{"p":$.$typeNullable($.$spc.System.UInt32).$h,"g":{"r":0,"d":0,"h":85901677947,"f":1},"n":"StartDiskNumber","d":2332027,"h":81606710651,"f":1}],"m":[{"r":65537,"n":"UpdateSize","d":2332027,"h":90196645243,"f":2},{"r":2332027,"p":[{"n":"extraFieldData","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"readUncompressedSize","p":262145},{"n":"readCompressedSize","p":262145},{"n":"readLocalHeaderOffset","p":262145},{"n":"readStartDiskNumber","p":262145}],"n":"GetJustZip64Block","d":2332027,"h":94491612539,"f":33},{"r":262145,"p":[{"n":"extraField","p":3511675},{"n":"readUncompressedSize","p":262145},{"n":"readCompressedSize","p":262145},{"n":"readLocalHeaderOffset","p":262145},{"n":"readStartDiskNumber","p":262145},{"n":"zip64Block","p":2332027,"f":2}],"n":"TryGetZip64BlockFromGenericExtraField","d":2332027,"h":98786579835,"f":34},{"r":2332027,"p":[{"n":"extraFields","p":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h},{"n":"readUncompressedSize","p":262145},{"n":"readCompressedSize","p":262145},{"n":"readLocalHeaderOffset","p":262145},{"n":"readStartDiskNumber","p":262145}],"n":"GetAndRemoveZip64Block","d":2332027,"h":103081547131,"f":33},{"r":65537,"p":[{"n":"extraFields","p":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h}],"n":"RemoveZip64Blocks","d":2332027,"h":107376514427,"f":33},{"r":65537,"p":[{"n":"extraFieldData","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"WriteBlockCore","d":2332027,"h":111671481723,"f":1},{"r":65537,"p":[{"n":"stream","p":62128129}],"n":"WriteBlock","d":2332027,"h":115966449019,"f":1},{"r":136118273,"p":[{"n":"stream","p":62128129},{"n":"cancellationToken","p":125960193}],"n":"WriteBlockAsync","d":2332027,"h":120261416315,"f":1}],"l":[{"t":655361,"n":"OffsetToFirstField","d":2332027,"h":4297299323,"f":33},{"t":589825,"n":"TagConstant","d":2332027,"h":8592266619,"f":34},{"t":589825,"n":"_size","d":2332027,"h":12887233915,"f":2},{"t":$.$typeNullable($.$spc.System.Int64).$h,"n":"_uncompressedSize","d":2332027,"h":17182201211,"f":2},{"t":$.$typeNullable($.$spc.System.Int64).$h,"n":"_compressedSize","d":2332027,"h":21477168507,"f":2},{"t":$.$typeNullable($.$spc.System.Int64).$h,"n":"_localHeaderOffset","d":2332027,"h":25772135803,"f":2},{"t":$.$typeNullable($.$spc.System.UInt32).$h,"n":"_startDiskNumber","d":2332027,"h":30067103099,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":2332027,"h":133146318203,"f":1}],"j":[2397563,2463099],"h":2332027}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.Zip64ExtraField`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator", ($self) => class Zip64EndOfCentralDirectoryLocator extends $.$spc.System.Object
        {
            /*byte[]*/ static SignatureConstantBytes = null;
            /*int*/ static TotalSize = 20;
            /*int*/ static SizeOfBlockWithoutSignature = 16;
            /*uint*/ NumberOfDiskWithZip64EOCD = 0;
            /*ulong*/ OffsetOfZip64EOCD = 0n;
            /*uint*/ TotalNumberOfDisks = 0;
            static /*bool */ TryReadBlockCore(/*Span<byte>*/ blockContents, /*int*/ bytesRead, /*out Zip64EndOfCentralDirectoryLocator?*/ zip64EOCDLocator)
            {
                zip64EOCDLocator.$v = null;
                if (bytesRead < 20/*TotalSize*/ || !$.$spc.System.MemoryExtensions.StartsWith$1($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockContents), $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.SignatureConstantBytes)))
                {
                    return false;
                }
                zip64EOCDLocator.$v = (() =>
                {
                    //new $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator()
                    const $t1 = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator;
                    const $i1 = new $t1();
                    let $t2 = blockContents;
                    $i1.NumberOfDiskWithZip64EOCD = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t2.Slice$1(4/*FieldLocations.NumberOfDiskWithZip64EOCD*/, $t2.Length - 4/*FieldLocations.NumberOfDiskWithZip64EOCD*/)));
                    let $t3 = blockContents;
                    $i1.OffsetOfZip64EOCD = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t3.Slice$1(8/*FieldLocations.OffsetOfZip64EOCD*/, $t3.Length - 8/*FieldLocations.OffsetOfZip64EOCD*/)));
                    let $t4 = blockContents;
                    $i1.TotalNumberOfDisks = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t4.Slice$1(16/*FieldLocations.TotalNumberOfDisks*/, $t4.Length - 16/*FieldLocations.TotalNumberOfDisks*/)));
                    return $i1;
                })();
                return true;
            }
            static /*Zip64EndOfCentralDirectoryLocator */ TryReadBlock(/*Stream*/ stream)
            {
                /*Span<byte>*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 20/*TotalSize*/, null);
                /*int*/ let bytesRead = stream.ReadAtLeast(blockContents, blockContents.Length, false);
                /*Zip64EndOfCentralDirectoryLocator?*/ let zip64EOCDLocator;
                /*bool*/ let zip64eocdLocatorProper = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.TryReadBlockCore(blockContents, bytesRead, $.$ref(() => zip64EOCDLocator, ($v) => zip64EOCDLocator = $v, $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator));
                $.$spc.System.Diagnostics.Debug.Assert$1(zip64eocdLocatorProper && zip64EOCDLocator !== null, "zip64eocdLocatorProper && zip64EOCDLocator != null");
                return zip64EOCDLocator;
            }
            static /*void */ WriteBlockCore(/*Span<byte>*/ blockContents, /*long*/ zip64EOCDRecordStart)
            {
                let $t1 = blockContents;
                $.$spc.System.MemoryExtensions.CopyTo($.$spc.System.Byte, $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.SignatureConstantBytes, $t1.Slice$1(0/*FieldLocations.Signature*/, $t1.Length - 0/*FieldLocations.Signature*/));
                let $t2 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t2.Slice$1(4/*FieldLocations.NumberOfDiskWithZip64EOCD*/, $t2.Length - 4/*FieldLocations.NumberOfDiskWithZip64EOCD*/), 0);
                let $t3 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t3.Slice$1(8/*FieldLocations.OffsetOfZip64EOCD*/, $t3.Length - 8/*FieldLocations.OffsetOfZip64EOCD*/), zip64EOCDRecordStart);
                let $t4 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t4.Slice$1(16/*FieldLocations.TotalNumberOfDisks*/, $t4.Length - 16/*FieldLocations.TotalNumberOfDisks*/), 1);
            }
            static /*void */ WriteBlock(/*Stream*/ stream, /*long*/ zip64EOCDRecordStart)
            {
                /*Span<byte>*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 20/*TotalSize*/, null);
                $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.WriteBlockCore(blockContents, zip64EOCDRecordStart);
                stream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockContents));
            }
            static /*Task<Zip64EndOfCentralDirectoryLocator> *//*async*/  TryReadBlockAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator), $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [20/*TotalSize*/], null);
                    /*int*/ let bytesRead = await stream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(blockContents), blockContents.length, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    /*Zip64EndOfCentralDirectoryLocator?*/ let zip64EOCDLocator;
                    /*bool*/ let zip64eocdLocatorProper = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.TryReadBlockCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockContents), bytesRead, $.$ref(() => zip64EOCDLocator, ($v) => zip64EOCDLocator = $v, $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator));
                    $.$spc.System.Diagnostics.Debug.Assert$1(zip64eocdLocatorProper && zip64EOCDLocator !== null, "zip64eocdLocatorProper && zip64EOCDLocator != null");
                    return zip64EOCDLocator;
                });
            }
            static /*ValueTask */ WriteBlockAsync(/*Stream*/ stream, /*long*/ zip64EOCDRecordStart, /*CancellationToken*/ cancellationToken)
            {
                cancellationToken.ThrowIfCancellationRequested();
                /*byte[]*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [20/*TotalSize*/], null);
                $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.WriteBlockCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockContents), zip64EOCDRecordStart);
                return stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(blockContents), cancellationToken);
            }
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static Signature = 4;
                    /*int*/ static NumberOfDiskWithZip64EOCD = 4;
                    /*int*/ static OffsetOfZip64EOCD = 8;
                    /*int*/ static TotalNumberOfDisks = 4;
                    static $h = 2004347;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":2004347,"h":4296971643,"f":33},{"t":655361,"n":"NumberOfDiskWithZip64EOCD","d":2004347,"h":8591938939,"f":33},{"t":655361,"n":"OffsetOfZip64EOCD","d":2004347,"h":12886906235,"f":33},{"t":655361,"n":"TotalNumberOfDisks","d":2004347,"h":17181873531,"f":33}],"d":1938811,"h":2004347}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.Zip64EndOfCentralDirectoryLocator.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Signature = 0;
                    /*int*/ static NumberOfDiskWithZip64EOCD = 4;
                    /*int*/ static OffsetOfZip64EOCD = 8;
                    /*int*/ static TotalNumberOfDisks = 16;
                    static $h = 2069883;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":2069883,"h":4297037179,"f":33},{"t":655361,"n":"NumberOfDiskWithZip64EOCD","d":2069883,"h":8592004475,"f":33},{"t":655361,"n":"OffsetOfZip64EOCD","d":2069883,"h":12886971771,"f":33},{"t":655361,"n":"TotalNumberOfDisks","d":2069883,"h":17181939067,"f":33}],"d":1938811,"h":2069883}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.Zip64EndOfCentralDirectoryLocator.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SignatureConstantBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [ 80, 75, 6, 7 ], null, null);
                }
            }
            static $h = 1938811;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"blockContents","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesRead","p":655361},{"n":"zip64EOCDLocator","p":1938811,"f":2}],"n":"TryReadBlockCore","d":1938811,"h":30066709883,"f":34},{"r":1938811,"p":[{"n":"stream","p":62128129}],"n":"TryReadBlock","d":1938811,"h":34361677179,"f":33},{"r":65537,"p":[{"n":"blockContents","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"zip64EOCDRecordStart","p":917505}],"n":"WriteBlockCore","d":1938811,"h":38656644475,"f":34},{"r":65537,"p":[{"n":"stream","p":62128129},{"n":"zip64EOCDRecordStart","p":917505}],"n":"WriteBlock","d":1938811,"h":42951611771,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator).$h,"p":[{"n":"stream","p":62128129},{"n":"cancellationToken","p":125960193}],"n":"TryReadBlockAsync","d":1938811,"h":47246579067,"f":4129},{"r":136118273,"p":[{"n":"stream","p":62128129},{"n":"zip64EOCDRecordStart","p":917505},{"n":"cancellationToken","p":125960193}],"n":"WriteBlockAsync","d":1938811,"h":51541546363,"f":33}],"l":[{"t":0,"n":"SignatureConstantBytes","d":1938811,"h":4296906107,"f":33},{"t":655361,"n":"TotalSize","d":1938811,"h":8591873403,"f":33},{"t":655361,"n":"SizeOfBlockWithoutSignature","d":1938811,"h":12886840699,"f":33},{"t":720897,"n":"NumberOfDiskWithZip64EOCD","d":1938811,"h":17181807995,"f":1},{"t":983041,"n":"OffsetOfZip64EOCD","d":1938811,"h":21476775291,"f":1},{"t":720897,"n":"TotalNumberOfDisks","d":1938811,"h":25771742587,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1938811,"h":64426448251,"f":1}],"j":[2004347,2069883],"h":1938811}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.Zip64EndOfCentralDirectoryLocator`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord", ($self) => class Zip64EndOfCentralDirectoryRecord extends $.$spc.System.Object
        {
            static /*ReadOnlySpan<byte> */ get SignatureConstantBytes()
            {
                return this.$cacheSignatureConstantBytes ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 80, 75, 6, 6 ]);
            }
            /*int*/ static BlockConstantSectionSize = 56;
            /*ulong*/ static NormalSize = 0x2Cn;
            /*long*/ static TotalSize = 56n;
            /*ulong*/ SizeOfThisRecord = 0n;
            /*ushort*/ VersionMadeBy = 0;
            /*ushort*/ VersionNeededToExtract = 0;
            /*uint*/ NumberOfThisDisk = 0;
            /*uint*/ NumberOfDiskWithStartOfCD = 0;
            /*ulong*/ NumberOfEntriesOnThisDisk = 0n;
            /*ulong*/ NumberOfEntriesTotal = 0n;
            /*ulong*/ SizeOfCentralDirectory = 0n;
            /*ulong*/ OffsetOfCentralDirectory = 0n;
            static /*bool */ TryReadBlockCore(/*Span<byte>*/ blockContents, /*int*/ bytesRead, /*out Zip64EndOfCentralDirectoryRecord?*/ zip64EOCDRecord)
            {
                zip64EOCDRecord.$v = null;
                if (bytesRead < 56/*BlockConstantSectionSize*/)
                {
                    return false;
                }
                if (!$.$spc.System.MemoryExtensions.StartsWith$1($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockContents), $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.SignatureConstantBytes))
                {
                    return false;
                }
                zip64EOCDRecord.$v = (() =>
                {
                    //new $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord()
                    const $t1 = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord;
                    const $i1 = new $t1();
                    let $t2 = blockContents;
                    $i1.SizeOfThisRecord = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t2.Slice$1(4/*FieldLocations.SizeOfThisRecord*/, $t2.Length - 4/*FieldLocations.SizeOfThisRecord*/)));
                    let $t3 = blockContents;
                    $i1.VersionMadeBy = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t3.Slice$1(12/*FieldLocations.VersionMadeBy*/, $t3.Length - 12/*FieldLocations.VersionMadeBy*/)));
                    let $t4 = blockContents;
                    $i1.VersionNeededToExtract = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t4.Slice$1(14/*FieldLocations.VersionNeededToExtract*/, $t4.Length - 14/*FieldLocations.VersionNeededToExtract*/)));
                    let $t5 = blockContents;
                    $i1.NumberOfThisDisk = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t5.Slice$1(16/*FieldLocations.NumberOfThisDisk*/, $t5.Length - 16/*FieldLocations.NumberOfThisDisk*/)));
                    let $t6 = blockContents;
                    $i1.NumberOfDiskWithStartOfCD = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t6.Slice$1(20/*FieldLocations.NumberOfDiskWithStartOfCD*/, $t6.Length - 20/*FieldLocations.NumberOfDiskWithStartOfCD*/)));
                    let $t7 = blockContents;
                    $i1.NumberOfEntriesOnThisDisk = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t7.Slice$1(24/*FieldLocations.NumberOfEntriesOnThisDisk*/, $t7.Length - 24/*FieldLocations.NumberOfEntriesOnThisDisk*/)));
                    let $t8 = blockContents;
                    $i1.NumberOfEntriesTotal = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t8.Slice$1(32/*FieldLocations.NumberOfEntriesTotal*/, $t8.Length - 32/*FieldLocations.NumberOfEntriesTotal*/)));
                    let $t9 = blockContents;
                    $i1.SizeOfCentralDirectory = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t9.Slice$1(40/*FieldLocations.SizeOfCentralDirectory*/, $t9.Length - 40/*FieldLocations.SizeOfCentralDirectory*/)));
                    let $t10 = blockContents;
                    $i1.OffsetOfCentralDirectory = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t10.Slice$1(48/*FieldLocations.OffsetOfCentralDirectory*/, $t10.Length - 48/*FieldLocations.OffsetOfCentralDirectory*/)));
                    return $i1;
                })();
                return true;
            }
            static /*Zip64EndOfCentralDirectoryRecord */ TryReadBlock(/*Stream*/ stream)
            {
                /*Span<byte>*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 56/*BlockConstantSectionSize*/, null);
                /*int*/ let bytesRead = stream.ReadAtLeast(blockContents, blockContents.Length, false);
                /*Zip64EndOfCentralDirectoryRecord?*/ let zip64EOCDRecord;
                if (!$.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.TryReadBlockCore(blockContents, bytesRead, $.$ref(() => zip64EOCDRecord, ($v) => zip64EOCDRecord = $v, $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord)))
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.Zip64EOCDNotWhereExpected);
                }
                return zip64EOCDRecord;
            }
            static /*void */ WriteBlockCore(/*Span<byte>*/ blockContents, /*long*/ numberOfEntries, /*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory)
            {
                let $t1 = blockContents;
                $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.SignatureConstantBytes.CopyTo($t1.Slice$1(0/*FieldLocations.Signature*/, $t1.Length - 0/*FieldLocations.Signature*/));
                let $t2 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt64LittleEndian($t2.Slice$1(4/*FieldLocations.SizeOfThisRecord*/, $t2.Length - 4/*FieldLocations.SizeOfThisRecord*/), 44n);
                let $t3 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t3.Slice$1(12/*FieldLocations.VersionMadeBy*/, $t3.Length - 12/*FieldLocations.VersionMadeBy*/), 45/*ZipVersionNeededValues.Zip64*/);
                let $t4 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t4.Slice$1(14/*FieldLocations.VersionNeededToExtract*/, $t4.Length - 14/*FieldLocations.VersionNeededToExtract*/), 45/*ZipVersionNeededValues.Zip64*/);
                let $t5 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t5.Slice$1(16/*FieldLocations.NumberOfThisDisk*/, $t5.Length - 16/*FieldLocations.NumberOfThisDisk*/), 0);
                let $t6 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t6.Slice$1(20/*FieldLocations.NumberOfDiskWithStartOfCD*/, $t6.Length - 20/*FieldLocations.NumberOfDiskWithStartOfCD*/), 0);
                let $t7 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t7.Slice$1(24/*FieldLocations.NumberOfEntriesOnThisDisk*/, $t7.Length - 24/*FieldLocations.NumberOfEntriesOnThisDisk*/), numberOfEntries);
                let $t8 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t8.Slice$1(32/*FieldLocations.NumberOfEntriesTotal*/, $t8.Length - 32/*FieldLocations.NumberOfEntriesTotal*/), numberOfEntries);
                let $t9 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t9.Slice$1(40/*FieldLocations.SizeOfCentralDirectory*/, $t9.Length - 40/*FieldLocations.SizeOfCentralDirectory*/), sizeOfCentralDirectory);
                let $t10 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteInt64LittleEndian($t10.Slice$1(48/*FieldLocations.OffsetOfCentralDirectory*/, $t10.Length - 48/*FieldLocations.OffsetOfCentralDirectory*/), startOfCentralDirectory);
            }
            static /*void */ WriteBlock(/*Stream*/ stream, /*long*/ numberOfEntries, /*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory)
            {
                /*Span<byte>*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 56/*BlockConstantSectionSize*/, null);
                $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.WriteBlockCore(blockContents, numberOfEntries, startOfCentralDirectory, sizeOfCentralDirectory);
                stream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockContents));
            }
            static /*Task<Zip64EndOfCentralDirectoryRecord> *//*async*/  TryReadBlockAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord), $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [56/*BlockConstantSectionSize*/], null);
                    /*int*/ let bytesRead = await stream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(blockContents), blockContents.length, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    /*Zip64EndOfCentralDirectoryRecord?*/ let zip64EOCDRecord;
                    if (!$.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.TryReadBlockCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockContents), bytesRead, $.$ref(() => zip64EOCDRecord, ($v) => zip64EOCDRecord = $v, $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord)))
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.Zip64EOCDNotWhereExpected);
                    }
                    return zip64EOCDRecord;
                });
            }
            static /*ValueTask */ WriteBlockAsync(/*Stream*/ stream, /*long*/ numberOfEntries, /*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory, /*CancellationToken*/ cancellationToken)
            {
                cancellationToken.ThrowIfCancellationRequested();
                /*byte[]*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [56/*BlockConstantSectionSize*/], null);
                $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.WriteBlockCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockContents), numberOfEntries, startOfCentralDirectory, sizeOfCentralDirectory);
                return stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(blockContents), cancellationToken);
            }
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static Signature = 4;
                    /*int*/ static SizeOfThisRecord = 8;
                    /*int*/ static VersionMadeBy = 2;
                    /*int*/ static VersionNeededToExtract = 2;
                    /*int*/ static NumberOfThisDisk = 4;
                    /*int*/ static NumberOfDiskWithStartOfCD = 4;
                    /*int*/ static NumberOfEntriesOnThisDisk = 8;
                    /*int*/ static NumberOfEntriesTotal = 8;
                    /*int*/ static SizeOfCentralDirectory = 8;
                    /*int*/ static OffsetOfCentralDirectory = 8;
                    static $h = 2200955;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":2200955,"h":4297168251,"f":33},{"t":655361,"n":"SizeOfThisRecord","d":2200955,"h":8592135547,"f":33},{"t":655361,"n":"VersionMadeBy","d":2200955,"h":12887102843,"f":33},{"t":655361,"n":"VersionNeededToExtract","d":2200955,"h":17182070139,"f":33},{"t":655361,"n":"NumberOfThisDisk","d":2200955,"h":21477037435,"f":33},{"t":655361,"n":"NumberOfDiskWithStartOfCD","d":2200955,"h":25772004731,"f":33},{"t":655361,"n":"NumberOfEntriesOnThisDisk","d":2200955,"h":30066972027,"f":33},{"t":655361,"n":"NumberOfEntriesTotal","d":2200955,"h":34361939323,"f":33},{"t":655361,"n":"SizeOfCentralDirectory","d":2200955,"h":38656906619,"f":33},{"t":655361,"n":"OffsetOfCentralDirectory","d":2200955,"h":42951873915,"f":33}],"d":2135419,"h":2200955}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.Zip64EndOfCentralDirectoryRecord.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Signature = 0;
                    /*int*/ static SizeOfThisRecord = 4;
                    /*int*/ static VersionMadeBy = 12;
                    /*int*/ static VersionNeededToExtract = 14;
                    /*int*/ static NumberOfThisDisk = 16;
                    /*int*/ static NumberOfDiskWithStartOfCD = 20;
                    /*int*/ static NumberOfEntriesOnThisDisk = 24;
                    /*int*/ static NumberOfEntriesTotal = 32;
                    /*int*/ static SizeOfCentralDirectory = 40;
                    /*int*/ static OffsetOfCentralDirectory = 48;
                    static $h = 2266491;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":2266491,"h":4297233787,"f":33},{"t":655361,"n":"SizeOfThisRecord","d":2266491,"h":8592201083,"f":33},{"t":655361,"n":"VersionMadeBy","d":2266491,"h":12887168379,"f":33},{"t":655361,"n":"VersionNeededToExtract","d":2266491,"h":17182135675,"f":33},{"t":655361,"n":"NumberOfThisDisk","d":2266491,"h":21477102971,"f":33},{"t":655361,"n":"NumberOfDiskWithStartOfCD","d":2266491,"h":25772070267,"f":33},{"t":655361,"n":"NumberOfEntriesOnThisDisk","d":2266491,"h":30067037563,"f":33},{"t":655361,"n":"NumberOfEntriesTotal","d":2266491,"h":34362004859,"f":33},{"t":655361,"n":"SizeOfCentralDirectory","d":2266491,"h":38656972155,"f":33},{"t":655361,"n":"OffsetOfCentralDirectory","d":2266491,"h":42951939451,"f":33}],"d":2135419,"h":2266491}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.Zip64EndOfCentralDirectoryRecord.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2135419;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":8592070011,"f":33},"n":"SignatureConstantBytes","d":2135419,"h":4297102715,"f":33}],"m":[{"r":262145,"p":[{"n":"blockContents","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesRead","p":655361},{"n":"zip64EOCDRecord","p":2135419,"f":2}],"n":"TryReadBlockCore","d":2135419,"h":64426644859,"f":34},{"r":2135419,"p":[{"n":"stream","p":62128129}],"n":"TryReadBlock","d":2135419,"h":68721612155,"f":33},{"r":65537,"p":[{"n":"blockContents","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"numberOfEntries","p":917505},{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505}],"n":"WriteBlockCore","d":2135419,"h":73016579451,"f":34},{"r":65537,"p":[{"n":"stream","p":62128129},{"n":"numberOfEntries","p":917505},{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505}],"n":"WriteBlock","d":2135419,"h":77311546747,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord).$h,"p":[{"n":"stream","p":62128129},{"n":"cancellationToken","p":125960193}],"n":"TryReadBlockAsync","d":2135419,"h":81606514043,"f":4129},{"r":136118273,"p":[{"n":"stream","p":62128129},{"n":"numberOfEntries","p":917505},{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505},{"n":"cancellationToken","p":125960193}],"n":"WriteBlockAsync","d":2135419,"h":85901481339,"f":33}],"l":[{"t":655361,"n":"BlockConstantSectionSize","d":2135419,"h":12887037307,"f":34},{"t":983041,"n":"NormalSize","d":2135419,"h":17182004603,"f":34},{"t":917505,"n":"TotalSize","d":2135419,"h":21476971899,"f":33},{"t":983041,"n":"SizeOfThisRecord","d":2135419,"h":25771939195,"f":1},{"t":589825,"n":"VersionMadeBy","d":2135419,"h":30066906491,"f":1},{"t":589825,"n":"VersionNeededToExtract","d":2135419,"h":34361873787,"f":1},{"t":720897,"n":"NumberOfThisDisk","d":2135419,"h":38656841083,"f":1},{"t":720897,"n":"NumberOfDiskWithStartOfCD","d":2135419,"h":42951808379,"f":1},{"t":983041,"n":"NumberOfEntriesOnThisDisk","d":2135419,"h":47246775675,"f":1},{"t":983041,"n":"NumberOfEntriesTotal","d":2135419,"h":51541742971,"f":1},{"t":983041,"n":"SizeOfCentralDirectory","d":2135419,"h":55836710267,"f":1},{"t":983041,"n":"OffsetOfCentralDirectory","d":2135419,"h":60131677563,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":2135419,"h":98786383227,"f":1}],"j":[2200955,2266491],"h":2135419}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.Zip64EndOfCentralDirectoryRecord`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipHelper", ($self) => class ZipHelper
        {
            /*uint*/ static Mask32Bit = 4294967295;
            /*ushort*/ static Mask16Bit = 65535;
            /*int*/ static BackwardsSeekingBufferSize = 4096;
            /*int*/ static ValidZipDate_YearMin = 1980;
            /*int*/ static ValidZipDate_YearMax = 2107;
            /*DateTime*/ static s_invalidDateIndicator;
            static /*Encoding */ GetEncoding(/*string*/ text)
            {
                if ($.$spc.System.MemoryExtensions.ContainsAnyExceptInRange$1($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(text), 32, 126))
                {
                    return $.$spc.System.Text.Encoding.UTF8;
                }
                return $.$spc.System.Text.Encoding.ASCII;
            }
            static /*DateTime */ DosTimeToDateTime(/*uint*/ dateTime)
            {
                if (dateTime === 0)
                {
                    return $.$sic.System.IO.Compression.ZipHelper.s_invalidDateIndicator;
                }
                /*int*/ let year = ((((1980/*ValidZipDate_YearMin*/ + (dateTime >>> 25)) | 0)) | 0);
                /*int*/ let month = (((dateTime >>> 21) & 15) | 0);
                /*int*/ let day = (((dateTime >>> 16) & 31) | 0);
                /*int*/ let hour = (((dateTime >>> 11) & 31) | 0);
                /*int*/ let minute = (((dateTime >>> 5) & 63) | 0);
                /*int*/ let second = (((((dateTime & 31) * 2) >>> 0)) | 0);
                try
                {
                    return new $.$spc.System.DateTime().$ctor$14(year, month, day, hour, minute, second, 0);
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.ArgumentOutOfRangeException)
                    {
                        return $.$sic.System.IO.Compression.ZipHelper.s_invalidDateIndicator;
                    }
                    else if ($e instanceof $.$spc.System.ArgumentException)
                    {
                        return $.$sic.System.IO.Compression.ZipHelper.s_invalidDateIndicator;
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            static /*uint */ DateTimeToDosTime(/*DateTime*/ dateTime)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(1980/*ValidZipDate_YearMin*/ <= dateTime.Year && dateTime.Year <= 2107/*ValidZipDate_YearMax*/, "ValidZipDate_YearMin <= dateTime.Year && dateTime.Year <= ValidZipDate_YearMax");
                /*int*/ let ret = ((((dateTime.Year - 1980/*ValidZipDate_YearMin*/) | 0)) & 127);
                ret = (((ret << 4) + dateTime.Month) | 0);
                ret = (((ret << 5) + dateTime.Day) | 0);
                ret = (((ret << 5) + dateTime.Hour) | 0);
                ret = (((ret << 6) + dateTime.Minute) | 0);
                ret = (((ret << 5) + ($.trunc(dateTime.Second / 2))) | 0);
                return (ret >>> 0);
            }
            static /*bool */ SeekBackwardsToSignature(/*Stream*/ stream, /*ReadOnlySpan<byte>*/ signatureToFind, /*int*/ maxBytesToRead)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(signatureToFind.Length !== 0, "signatureToFind.Length != 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(maxBytesToRead > 0, "maxBytesToRead > 0");
                /*int*/ let bufferPointer = 0;
                /*byte[]*/ let buffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(4096/*BackwardsSeekingBufferSize*/);
                /*Span<byte>*/ let bufferSpan = $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, buffer, 0, 4096/*BackwardsSeekingBufferSize*/);
                try
                {
                    /*bool*/ let outOfBytes = false;
                    /*bool*/ let signatureFound = false;
                    /*int*/ let totalBytesRead = 0;
                    while(!signatureFound && !outOfBytes && totalBytesRead < maxBytesToRead)
                    {
                        /*int*/ let overlap = totalBytesRead === 0 ? 0 : signatureToFind.Length;
                        if (((((maxBytesToRead - totalBytesRead) | 0) + overlap) | 0) < bufferSpan.Length)
                        {
                            bufferSpan = bufferSpan.Slice$1(0, ((((maxBytesToRead - totalBytesRead) | 0) + overlap) | 0));
                        }
                        /*int*/ let bytesRead = $.$sic.System.IO.Compression.ZipHelper.SeekBackwardsAndRead(stream, bufferSpan, overlap);
                        outOfBytes = bytesRead < bufferSpan.Length;
                        if (bytesRead < bufferSpan.Length)
                        {
                            bufferSpan = bufferSpan.Slice$1(0, bytesRead);
                        }
                        bufferPointer = $.$spc.System.MemoryExtensions.LastIndexOf$4($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(bufferSpan), signatureToFind);
                        $.$spc.System.Diagnostics.Debug.Assert$1(bufferPointer < bufferSpan.Length, "bufferPointer < bufferSpan.Length");
                        totalBytesRead += ((bytesRead - overlap) | 0);
                        if (bufferPointer !== -1)
                        {
                            signatureFound = true;
                            break;
                        }
                    }
                    if (!signatureFound)
                    {
                        return false;
                    }
                    else 
                    {
                        stream.Seek(BigInt(bufferPointer), 1/*SeekOrigin.Current*/);
                        return true;
                    }
                }
                finally
                {
                    {
                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(buffer, false);
                    }
                }
            }
            static /*int */ SeekBackwardsAndRead(/*Stream*/ stream, /*Span<byte>*/ buffer, /*int*/ overlap)
            {
                /*int*/ let bytesRead;
                if (stream.Position >= BigInt(buffer.Length))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(overlap <= buffer.Length, "overlap <= buffer.Length");
                    stream.Seek(BigInt(-(((buffer.Length - overlap) | 0))), 1/*SeekOrigin.Current*/);
                    bytesRead = stream.ReadAtLeast(buffer, buffer.Length, true);
                    stream.Seek(BigInt(-buffer.Length), 1/*SeekOrigin.Current*/);
                }
                else 
                {
                    /*int*/ let bytesToRead = $.$cast(stream.Position, $.$spc.System.Int32);
                    stream.Seek(0n, 0/*SeekOrigin.Begin*/);
                    bytesRead = stream.ReadAtLeast(buffer, bytesToRead, true);
                    stream.Seek(0n, 0/*SeekOrigin.Begin*/);
                }
                return bytesRead;
            }
            static /*byte[] */ GetEncodedTruncatedBytesFromString(/*string?*/ text, /*Encoding?*/ encoding, /*int*/ maxBytes, /*out bool*/ isUTF8)
            {
                if ($.$spc.System.String.IsNullOrEmpty(text))
                {
                    isUTF8.$v = false;
                    return $.$spc.System.Array.Empty($.$spc.System.Byte);
                }
                encoding ??= $.$sic.System.IO.Compression.ZipHelper.GetEncoding(text);
                isUTF8.$v = encoding.CodePage === 65001;
                if (maxBytes === 0)
                {
                    return encoding.GetBytes$3(text);
                }
                /*byte[]*/ let bytes;
                if (isUTF8.$v && encoding.GetMaxByteCount(text.length) > maxBytes)
                {
                    /*int*/ let totalCodePoints = 0;
                    var $en3 = $.$spc.System.String.EnumerateRunes.call(text).GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var rune = $en3.Current;
                        {
                            if (((totalCodePoints + rune.Utf8SequenceLength) | 0) > maxBytes)
                            {
                                break;
                            }
                            totalCodePoints += rune.Utf8SequenceLength;
                        }
                    }
                    bytes = encoding.GetBytes$3(text);
                    $.$spc.System.Diagnostics.Debug.Assert$1(totalCodePoints > 0, "totalCodePoints > 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(totalCodePoints <= bytes.length, "totalCodePoints <= bytes.Length");
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetSubArray($.$spc.System.Byte, bytes, new $.$spc.System.Range().$ctor$2($.$spc.System.Index.op_Implicit(0), $.$spc.System.Index.op_Implicit(totalCodePoints)));
                }
                bytes = encoding.GetBytes$3(text);
                return maxBytes < bytes.length ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetSubArray($.$spc.System.Byte, bytes, new $.$spc.System.Range().$ctor$2($.$spc.System.Index.op_Implicit(0), $.$spc.System.Index.op_Implicit(maxBytes))) : bytes;
            }
            static /*Task<bool> *//*async*/  SeekBackwardsToSignatureAsync(/*Stream*/ stream, /*ReadOnlyMemory<byte>*/ signatureToFind, /*int*/ maxBytesToRead, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    $.$spc.System.Diagnostics.Debug.Assert$1(signatureToFind.Length !== 0, "signatureToFind.Length != 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1(maxBytesToRead > 0, "maxBytesToRead > 0");
                    /*int*/ let bufferPointer = 0;
                    /*byte[]*/ let buffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(4096/*BackwardsSeekingBufferSize*/);
                    /*Memory<byte>*/ let bufferMemory = $.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, buffer, 0, 4096/*BackwardsSeekingBufferSize*/);
                    try
                    {
                        /*bool*/ let outOfBytes = false;
                        /*bool*/ let signatureFound = false;
                        /*int*/ let totalBytesRead = 0;
                        while(!signatureFound && !outOfBytes && totalBytesRead < maxBytesToRead)
                        {
                            /*int*/ let overlap = totalBytesRead === 0 ? 0 : signatureToFind.Length;
                            if (((((maxBytesToRead - totalBytesRead) | 0) + overlap) | 0) < bufferMemory.Length)
                            {
                                bufferMemory = bufferMemory.Slice$1(0, ((((maxBytesToRead - totalBytesRead) | 0) + overlap) | 0));
                            }
                            /*int*/ let bytesRead = await $.$sic.System.IO.Compression.ZipHelper.SeekBackwardsAndReadAsync(stream, bufferMemory, overlap, cancellationToken).ConfigureAwait$2(false);
                            outOfBytes = bytesRead < bufferMemory.Length;
                            if (bytesRead < bufferMemory.Length)
                            {
                                bufferMemory = bufferMemory.Slice$1(0, bytesRead);
                            }
                            bufferPointer = $.$spc.System.MemoryExtensions.LastIndexOf$4($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(bufferMemory.Span), signatureToFind.Span);
                            $.$spc.System.Diagnostics.Debug.Assert$1(bufferPointer < bufferMemory.Length, "bufferPointer < bufferMemory.Length");
                            totalBytesRead += ((bytesRead - overlap) | 0);
                            if (bufferPointer !== -1)
                            {
                                signatureFound = true;
                                break;
                            }
                        }
                        if (!signatureFound)
                        {
                            return false;
                        }
                        else 
                        {
                            stream.Seek(BigInt(bufferPointer), 1/*SeekOrigin.Current*/);
                            return true;
                        }
                    }
                    finally
                    {
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(buffer, false);
                        }
                    }
                });
            }
            static /*Task<int> *//*async*/  SeekBackwardsAndReadAsync(/*Stream*/ stream, /*Memory<byte>*/ buffer, /*int*/ overlap, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*int*/ let bytesRead;
                    if (stream.Position >= BigInt(buffer.Length))
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(overlap <= buffer.Length, "overlap <= buffer.Length");
                        stream.Seek(BigInt(-(((buffer.Length - overlap) | 0))), 1/*SeekOrigin.Current*/);
                        bytesRead = await stream.ReadAtLeastAsync(buffer, buffer.Length, true, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                        stream.Seek(BigInt(-buffer.Length), 1/*SeekOrigin.Current*/);
                    }
                    else 
                    {
                        /*int*/ let bytesToRead = $.$cast(stream.Position, $.$spc.System.Int32);
                        stream.Seek(0n, 0/*SeekOrigin.Begin*/);
                        bytesRead = await stream.ReadAtLeastAsync(buffer, bytesToRead, true, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                        stream.Seek(0n, 0/*SeekOrigin.Begin*/);
                    }
                    return bytesRead;
                });
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_invalidDateIndicator = new $.$spc.System.DateTime().$ctor$11(1980/*ValidZipDate_YearMin*/, 1, 1, 0, 0, 0);
                }
            }
            static $h = 3708283;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":121831425,"p":[{"n":"text","p":1310721}],"n":"GetEncoding","d":3708283,"h":30068479355,"f":40},{"r":34144257,"p":[{"n":"dateTime","p":720897}],"n":"DosTimeToDateTime","d":3708283,"h":34363446651,"f":40},{"r":720897,"p":[{"n":"dateTime","p":34144257}],"n":"DateTimeToDosTime","d":3708283,"h":38658413947,"f":40},{"r":262145,"p":[{"n":"stream","p":62128129},{"n":"signatureToFind","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"maxBytesToRead","p":655361}],"n":"SeekBackwardsToSignature","d":3708283,"h":42953381243,"f":40},{"r":655361,"p":[{"n":"stream","p":62128129},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"overlap","p":655361}],"n":"SeekBackwardsAndRead","d":3708283,"h":47248348539,"f":34},{"r":0,"p":[{"n":"text","p":1310721},{"n":"encoding","p":121831425},{"n":"maxBytes","p":655361},{"n":"isUTF8","p":262145,"f":2}],"n":"GetEncodedTruncatedBytesFromString","d":3708283,"h":51543315835,"f":40},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean).$h,"p":[{"n":"stream","p":62128129},{"n":"signatureToFind","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"maxBytesToRead","p":655361},{"n":"cancellationToken","p":125960193}],"n":"SeekBackwardsToSignatureAsync","d":3708283,"h":55838283131,"f":4136},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"stream","p":62128129},{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"overlap","p":655361},{"n":"cancellationToken","p":125960193}],"n":"SeekBackwardsAndReadAsync","d":3708283,"h":60133250427,"f":4130}],"l":[{"t":720897,"n":"Mask32Bit","d":3708283,"h":4298675579,"f":40},{"t":589825,"n":"Mask16Bit","d":3708283,"h":8593642875,"f":40},{"t":655361,"n":"BackwardsSeekingBufferSize","d":3708283,"h":12888610171,"f":34},{"t":655361,"n":"ValidZipDate_YearMin","d":3708283,"h":17183577467,"f":40},{"t":655361,"n":"ValidZipDate_YearMax","d":3708283,"h":21478544763,"f":40},{"t":34144257,"n":"s_invalidDateIndicator","d":3708283,"h":25773512059,"f":34}],"h":3708283}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ZipHelper`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.HuffmanTree", ($self) => class HuffmanTree extends $.$spc.System.Object
        {
            /*int*/ static MaxLiteralTreeElements = 288;
            /*int*/ static MaxDistTreeElements = 32;
            /*int*/ static EndOfBlockCode = 256;
            /*int*/ static NumberOfCodeLengthTreeElements = 19;
            /*int*/ _tableBits = 0;
            /*short[]*/ _table = null;
            /*short[]*/ _left = null;
            /*short[]*/ _right = null;
            /*byte[]*/ _codeLengthArray = null;
            /*uint[]?*/ _codeArrayDebug = null;
            /*int*/ _tableMask = 0;
            /*HuffmanTree*/ static StaticLiteralLengthTree = null;
            /*HuffmanTree*/ static StaticDistanceTree = null;
            $ctor$1(/*byte[]*/ codeLengths)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(codeLengths.length === 288/*MaxLiteralTreeElements*/ || codeLengths.length === 32/*MaxDistTreeElements*/ || codeLengths.length === 19/*NumberOfCodeLengthTreeElements*/, "we only expect three kinds of Length here");
                    this._codeLengthArray = codeLengths;
                    if (this._codeLengthArray.length === 288/*MaxLiteralTreeElements*/)
                    {
                        this._tableBits = 9;
                    }
                    else 
                    {
                        this._tableBits = 7;
                    }
                    this._tableMask = (((1 << this._tableBits) - 1) | 0);
                    this._table = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int16), null, [1 << this._tableBits], null);
                    this._left = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int16), null, [((2 * this._codeLengthArray.length) | 0)], null);
                    this._right = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int16), null, [((2 * this._codeLengthArray.length) | 0)], null);
                    this.CreateTable();
                }
                return this;
            }
            static /*byte[] */ GetStaticLiteralTreeLength()
            {
                /*byte[]*/ let literalTreeLength = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [288/*MaxLiteralTreeElements*/], null);
                $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, literalTreeLength, 0, 144).Fill(8);
                $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, literalTreeLength, 144, 112).Fill(9);
                $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, literalTreeLength, 256, 24).Fill(7);
                $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, literalTreeLength, 280, 8).Fill(8);
                return literalTreeLength;
            }
            static /*byte[] */ GetStaticDistanceTreeLength()
            {
                /*byte[]*/ let staticDistanceTreeLength = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [32/*MaxDistTreeElements*/], null);
                $.$spc.System.Array.Fill($.$spc.System.Byte, staticDistanceTreeLength, 5);
                return staticDistanceTreeLength;
            }
            static /*uint */ BitReverse(/*uint*/ code, /*int*/ length)
            {
                /*uint*/ let new_code = 0;
                $.$spc.System.Diagnostics.Debug.Assert$1(length > 0 && length <= 16, "Invalid len");
                do
                {
                    new_code |= (code & 1);
                    new_code <<= 1;
                    code >>= 1;
                }
                while(--length > 0);
                return new_code >>> 1;
            }
            /*uint[] */ CalculateHuffmanCode()
            {
                /*Span<uint>*/ let bitLengthCount = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, 17, null);
                bitLengthCount.Clear();
                let $i1 = 0;
                let $arr1 = this._codeLengthArray;
                while ($i1 < $arr1.length)
                {
                    let codeLength = $arr1[$i1++];
                    bitLengthCount.get_Item(codeLength).$v++;
                }
                bitLengthCount.get_Item(0).$v = 0;
                /*Span<uint>*/ let nextCode = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt32, 17, null);
                nextCode.Clear();
                /*uint*/ let tempCode = 0;
                for(/*int*/ let bits = 1; bits <= 16; bits++)
                {
                    tempCode = ((((tempCode + bitLengthCount.get_Item(((bits - 1) | 0)).$v) >>> 0)) << 1) >>> 0;
                    nextCode.get_Item(bits).$v = tempCode;
                }
                /*uint[]*/ let code = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt32), null, [288/*MaxLiteralTreeElements*/], null);
                for(/*int*/ let i = 0; i < this._codeLengthArray.length; i++)
                {
                    /*int*/ let len = $.$spc.System.Array.$ReadT1.call(this._codeLengthArray, i);
                    if (len > 0)
                    {
                        $.$spc.System.Array.$WriteT1.call(code, $.$sic.System.IO.Compression.HuffmanTree.BitReverse(nextCode.get_Item(len).$v, len), i);
                        nextCode.get_Item(len).$v++;
                    }
                }
                return code;
            }
            /*void */ CreateTable()
            {
                /*uint[]*/ let codeArray = this.CalculateHuffmanCode();
                this._codeArrayDebug = codeArray;
                /*short*/ let avail = $.$cast(this._codeLengthArray.length, $.$spc.System.Int16);
                for(/*int*/ let ch = 0; ch < this._codeLengthArray.length; ch++)
                {
                    /*int*/ let len = $.$spc.System.Array.$ReadT1.call(this._codeLengthArray, ch);
                    if (len > 0)
                    {
                        /*int*/ let start = ($.$spc.System.Array.$ReadT1.call(codeArray, ch) | 0);
                        if (len <= this._tableBits)
                        {
                            /*int*/ let increment = 1 << len;
                            if (start >= increment)
                            {
                                throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.InvalidHuffmanData);
                            }
                            /*int*/ let locs = 1 << (((this._tableBits - len) | 0));
                            for(/*int*/ let j = 0; j < locs; j++)
                            {
                                $.$spc.System.Array.$WriteT1.call(this._table, $.$cast(ch, $.$spc.System.Int16), start);
                                start += increment;
                            }
                        }
                        else 
                        {
                            /*int*/ let overflowBits = ((len - this._tableBits) | 0);
                            /*int*/ let codeBitMask = 1 << this._tableBits;
                            /*int*/ let index = start & ((((1 << this._tableBits) - 1) | 0));
                            /*short[]*/ let array = this._table;
                            do
                            {
                                /*short*/ let value = $.$spc.System.Array.$ReadT1.call(array, index);
                                if (value === 0)
                                {
                                    $.$spc.System.Array.$WriteT1.call(array, $.$cast(-avail, $.$spc.System.Int16), index);
                                    value = $.$cast(-avail, $.$spc.System.Int16);
                                    avail++;
                                }
                                if (value > 0)
                                {
                                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.InvalidHuffmanData);
                                }
                                $.$spc.System.Diagnostics.Debug.Assert$1(value < 0, "CreateTable: Only negative numbers are used for tree pointers!");
                                if ((start & codeBitMask) === 0)
                                {
                                    array = this._left;
                                }
                                else 
                                {
                                    array = this._right;
                                }
                                index = -value;
                                if (index >= array.length)
                                {
                                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.InvalidHuffmanData);
                                }
                                codeBitMask <<= 1;
                                overflowBits--;
                            }
                            while(overflowBits !== 0);
                            $.$spc.System.Array.$WriteT1.call(array, $.$cast(ch, $.$spc.System.Int16), index);
                        }
                    }
                }
            }
            /*int */ GetNextSymbol(/*InputBuffer*/ input)
            {
                /*uint*/ let bitBuffer = input.TryLoad16Bits();
                if (input.AvailableBits === 0)
                {
                    return -1;
                }
                /*int*/ let symbol = this._table[bitBuffer & this._tableMask];
                if (symbol < 0)
                {
                    /*uint*/ let mask = (1 << this._tableBits) >>> 0;
                    do
                    {
                        symbol = -symbol;
                        if ((bitBuffer & mask) === 0)
                        {
                            symbol = $.$spc.System.Array.$ReadT1.call(this._left, symbol);
                        }
                        else 
                        {
                            symbol = $.$spc.System.Array.$ReadT1.call(this._right, symbol);
                        }
                        mask <<= 1;
                    }
                    while(symbol < 0);
                }
                /*int*/ let codeLength = $.$spc.System.Array.$ReadT1.call(this._codeLengthArray, symbol);
                if (codeLength <= 0)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.InvalidHuffmanData);
                }
                if (codeLength > input.AvailableBits)
                {
                    return -1;
                }
                input.SkipBits(codeLength);
                return symbol;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.StaticLiteralLengthTree = new $.$sic.System.IO.Compression.HuffmanTree().$ctor$1($.$sic.System.IO.Compression.HuffmanTree.GetStaticLiteralTreeLength());
                }
                {
                    this.StaticDistanceTree = new $.$sic.System.IO.Compression.HuffmanTree().$ctor$1($.$sic.System.IO.Compression.HuffmanTree.GetStaticDistanceTreeLength());
                }
            }
            static $h = 1283451;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1283451,"g":{"r":0,"d":0,"h":60130825595,"f":33},"n":"StaticLiteralLengthTree","d":1283451,"h":55835858299,"f":33},{"p":1283451,"g":{"r":0,"d":0,"h":73015727483,"f":33},"n":"StaticDistanceTree","d":1283451,"h":68720760187,"f":33}],"m":[{"r":0,"n":"GetStaticLiteralTreeLength","d":1283451,"h":81605662075,"f":34},{"r":0,"n":"GetStaticDistanceTreeLength","d":1283451,"h":85900629371,"f":34},{"r":720897,"p":[{"n":"code","p":720897},{"n":"length","p":655361}],"n":"BitReverse","d":1283451,"h":90195596667,"f":34},{"r":0,"n":"CalculateHuffmanCode","d":1283451,"h":94490563963,"f":2},{"r":65537,"n":"CreateTable","d":1283451,"h":98785531259,"f":2},{"r":655361,"p":[{"n":"input","p":1545595}],"n":"GetNextSymbol","d":1283451,"h":103080498555,"f":1}],"l":[{"t":655361,"n":"MaxLiteralTreeElements","d":1283451,"h":4296250747,"f":40},{"t":655361,"n":"MaxDistTreeElements","d":1283451,"h":8591218043,"f":40},{"t":655361,"n":"EndOfBlockCode","d":1283451,"h":12886185339,"f":40},{"t":655361,"n":"NumberOfCodeLengthTreeElements","d":1283451,"h":17181152635,"f":40},{"t":655361,"n":"_tableBits","d":1283451,"h":21476119931,"f":2},{"t":0,"n":"_table","d":1283451,"h":25771087227,"f":2},{"t":0,"n":"_left","d":1283451,"h":30066054523,"f":2},{"t":0,"n":"_right","d":1283451,"h":34361021819,"f":2},{"t":0,"n":"_codeLengthArray","d":1283451,"h":38655989115,"f":2},{"t":0,"n":"_codeArrayDebug","d":1283451,"h":42950956411,"f":2},{"t":655361,"n":"_tableMask","d":1283451,"h":47245923707,"f":2}],"c":[{"p":[{"n":"codeLengths","p":0}],"n":".ctor","o":"$ctor$1","d":1283451,"h":77310694779,"f":1}],"h":1283451}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.HuffmanTree`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipCentralDirectoryFileHeader", ($self) => class ZipCentralDirectoryFileHeader extends $.$spc.System.Object
        {
            static /*ReadOnlySpan<byte> */ get SignatureConstantBytes()
            {
                return this.$cacheSignatureConstantBytes ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 80, 75, 1, 2 ]);
            }
            /*int*/ static StackAllocationThreshold = 512;
            /*int*/ static BlockConstantSectionSize = 46;
            /*byte*/ VersionMadeByCompatibility = 0;
            /*byte*/ VersionMadeBySpecification = 0;
            /*ushort*/ VersionNeededToExtract = 0;
            /*ushort*/ GeneralPurposeBitFlag = 0;
            /*ushort*/ CompressionMethod = 0;
            /*uint*/ LastModified = 0;
            /*uint*/ Crc32 = 0;
            /*long*/ CompressedSize = 0n;
            /*long*/ UncompressedSize = 0n;
            /*ushort*/ FilenameLength = 0;
            /*ushort*/ ExtraFieldLength = 0;
            /*ushort*/ FileCommentLength = 0;
            /*uint*/ DiskNumberStart = 0;
            /*ushort*/ InternalFileAttributes = 0;
            /*uint*/ ExternalFileAttributes = 0;
            /*long*/ RelativeOffsetOfLocalHeader = 0n;
            /*byte[]*/ Filename = null;
            /*byte[]*/ FileComment = null;
            /*List<ZipGenericExtraField>?*/ ExtraFields = null;
            /*byte[]?*/ TrailingExtraFieldData = null;
            static /*bool */ TryReadBlockInitialize(/*ReadOnlySpan<byte>*/ buffer, /*out ZipCentralDirectoryFileHeader?*/ header, /*out int*/ bytesRead, /*out uint*/ compressedSizeSmall, /*out uint*/ uncompressedSizeSmall, /*out ushort*/ diskNumberStartSmall, /*out uint*/ relativeOffsetOfLocalHeaderSmall)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(buffer.Length >= 46/*BlockConstantSectionSize*/, "buffer.Length >= BlockConstantSectionSize");
                header.$v = null;
                bytesRead.$v = 0;
                compressedSizeSmall.$v = 0;
                uncompressedSizeSmall.$v = 0;
                diskNumberStartSmall.$v = 0;
                relativeOffsetOfLocalHeaderSmall.$v = 0;
                if (!$.$spc.System.MemoryExtensions.StartsWith$1($.$spc.System.Byte, buffer, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.SignatureConstantBytes))
                {
                    return false;
                }
                header.$v = (() =>
                {
                    //new $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader()
                    const $t1 = $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader;
                    const $i1 = new $t1();
                    $i1.VersionMadeBySpecification = buffer.get_Item(4/*FieldLocations.VersionMadeBySpecification*/).$v;
                    $i1.VersionMadeByCompatibility = buffer.get_Item(5/*FieldLocations.VersionMadeByCompatibility*/).$v;
                    let $t2 = buffer;
                    $i1.VersionNeededToExtract = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t2.Slice$1(6/*FieldLocations.VersionNeededToExtract*/, $t2.Length - 6/*FieldLocations.VersionNeededToExtract*/));
                    let $t3 = buffer;
                    $i1.GeneralPurposeBitFlag = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t3.Slice$1(8/*FieldLocations.GeneralPurposeBitFlags*/, $t3.Length - 8/*FieldLocations.GeneralPurposeBitFlags*/));
                    let $t4 = buffer;
                    $i1.CompressionMethod = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t4.Slice$1(10/*FieldLocations.CompressionMethod*/, $t4.Length - 10/*FieldLocations.CompressionMethod*/));
                    let $t5 = buffer;
                    $i1.LastModified = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($t5.Slice$1(12/*FieldLocations.LastModified*/, $t5.Length - 12/*FieldLocations.LastModified*/));
                    let $t6 = buffer;
                    $i1.Crc32 = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($t6.Slice$1(16/*FieldLocations.Crc32*/, $t6.Length - 16/*FieldLocations.Crc32*/));
                    let $t7 = buffer;
                    $i1.FilenameLength = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t7.Slice$1(28/*FieldLocations.FilenameLength*/, $t7.Length - 28/*FieldLocations.FilenameLength*/));
                    let $t8 = buffer;
                    $i1.ExtraFieldLength = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t8.Slice$1(30/*FieldLocations.ExtraFieldLength*/, $t8.Length - 30/*FieldLocations.ExtraFieldLength*/));
                    let $t9 = buffer;
                    $i1.FileCommentLength = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t9.Slice$1(32/*FieldLocations.FileCommentLength*/, $t9.Length - 32/*FieldLocations.FileCommentLength*/));
                    let $t10 = buffer;
                    $i1.InternalFileAttributes = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t10.Slice$1(36/*FieldLocations.InternalFileAttributes*/, $t10.Length - 36/*FieldLocations.InternalFileAttributes*/));
                    let $t11 = buffer;
                    $i1.ExternalFileAttributes = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($t11.Slice$1(38/*FieldLocations.ExternalFileAttributes*/, $t11.Length - 38/*FieldLocations.ExternalFileAttributes*/));
                    return $i1;
                })();
                let $t2 = buffer;
                compressedSizeSmall.$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($t2.Slice$1(20/*FieldLocations.CompressedSize*/, $t2.Length - 20/*FieldLocations.CompressedSize*/));
                let $t3 = buffer;
                uncompressedSizeSmall.$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($t3.Slice$1(24/*FieldLocations.UncompressedSize*/, $t3.Length - 24/*FieldLocations.UncompressedSize*/));
                let $t4 = buffer;
                diskNumberStartSmall.$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($t4.Slice$1(34/*FieldLocations.DiskNumberStart*/, $t4.Length - 34/*FieldLocations.DiskNumberStart*/));
                let $t5 = buffer;
                relativeOffsetOfLocalHeaderSmall.$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($t5.Slice$1(42/*FieldLocations.RelativeOffsetOfLocalHeader*/, $t5.Length - 42/*FieldLocations.RelativeOffsetOfLocalHeader*/));
                return true;
            }
            static /*void */ TryReadBlockFinalize(/*ZipCentralDirectoryFileHeader*/ header, /*ReadOnlySpan<byte>*/ dynamicHeader, /*int*/ dynamicHeaderSize, /*uint*/ uncompressedSizeSmall, /*uint*/ compressedSizeSmall, /*ushort*/ diskNumberStartSmall, /*uint*/ relativeOffsetOfLocalHeaderSmall, /*bool*/ saveExtraFieldsAndComments, /*ref int*/ bytesRead, /*out Zip64ExtraField*/ zip64)
            {
                let $t1 = dynamicHeader;
                header.Filename = $t1.Slice$1(0, header.FilenameLength).ToArray();
                /*bool*/ let uncompressedSizeInZip64 = uncompressedSizeSmall === 4294967295/*ZipHelper.Mask32Bit*/;
                /*bool*/ let compressedSizeInZip64 = compressedSizeSmall === 4294967295/*ZipHelper.Mask32Bit*/;
                /*bool*/ let relativeOffsetInZip64 = relativeOffsetOfLocalHeaderSmall === 4294967295/*ZipHelper.Mask32Bit*/;
                /*bool*/ let diskNumberStartInZip64 = diskNumberStartSmall === 65535/*ZipHelper.Mask16Bit*/;
                /*ReadOnlySpan<byte>*/ let zipExtraFields = dynamicHeader.Slice$1(header.FilenameLength, header.ExtraFieldLength);
                if (saveExtraFieldsAndComments)
                {
                    /*ReadOnlySpan<byte>*/ let trailingDataSpan;
                    header.ExtraFields = $.$sic.System.IO.Compression.ZipGenericExtraField.ParseExtraField(zipExtraFields, $.$ref(() => trailingDataSpan, ($v) => trailingDataSpan = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)));
                    zip64.$v = $.$sic.System.IO.Compression.Zip64ExtraField.GetAndRemoveZip64Block(header.ExtraFields, uncompressedSizeInZip64, compressedSizeInZip64, relativeOffsetInZip64, diskNumberStartInZip64);
                    header.TrailingExtraFieldData = trailingDataSpan.ToArray();
                }
                else 
                {
                    header.ExtraFields = null;
                    header.TrailingExtraFieldData = null;
                    zip64.$v = $.$sic.System.IO.Compression.Zip64ExtraField.GetJustZip64Block(zipExtraFields, uncompressedSizeInZip64, compressedSizeInZip64, relativeOffsetInZip64, diskNumberStartInZip64);
                }
                header.FileComment = dynamicHeader.Slice$1(header.FilenameLength + header.ExtraFieldLength, header.FileCommentLength).ToArray();
                bytesRead.$v = ((46/*FieldLocations.DynamicData*/ + dynamicHeaderSize) | 0);
                header.UncompressedSize = zip64.$v.UncompressedSize ?? BigInt(uncompressedSizeSmall);
                header.CompressedSize = zip64.$v.CompressedSize ?? BigInt(compressedSizeSmall);
                header.RelativeOffsetOfLocalHeader = zip64.$v.LocalHeaderOffset ?? BigInt(relativeOffsetOfLocalHeaderSmall);
                header.DiskNumberStart = zip64.$v.StartDiskNumber ?? diskNumberStartSmall;
            }
            static /*bool */ TryReadBlock(/*ReadOnlySpan<byte>*/ buffer, /*Stream*/ furtherReads, /*bool*/ saveExtraFieldsAndComments, /*out int*/ bytesRead, /*out ZipCentralDirectoryFileHeader?*/ header)
            {
                /*uint*/ let compressedSizeSmall;
                /*uint*/ let uncompressedSizeSmall;
                /*ushort*/ let diskNumberStartSmall;
                /*uint*/ let relativeOffsetOfLocalHeaderSmall;
                if (!$.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.TryReadBlockInitialize(buffer, header, bytesRead, $.$ref(() => compressedSizeSmall, ($v) => compressedSizeSmall = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeSmall, ($v) => uncompressedSizeSmall = $v, $.$spc.System.UInt32), $.$ref(() => diskNumberStartSmall, ($v) => diskNumberStartSmall = $v, $.$spc.System.UInt16), $.$ref(() => relativeOffsetOfLocalHeaderSmall, ($v) => relativeOffsetOfLocalHeaderSmall = $v, $.$spc.System.UInt32)))
                {
                    return false;
                }
                /*byte[]?*/ let arrayPoolBuffer = null;
                try
                {
                    /*int*/ let dynamicHeaderSize = ((header.$v.FilenameLength + header.$v.ExtraFieldLength + header.$v.FileCommentLength) | 0);
                    /*int*/ let remainingBufferLength = ((buffer.Length - 46/*FieldLocations.DynamicData*/) | 0);
                    /*int*/ let bytesToRead = ((dynamicHeaderSize - remainingBufferLength) | 0);
                    /*scoped ReadOnlySpan<byte>*/ let dynamicHeader;
                    if (bytesToRead <= 0)
                    {
                        let $t7 = buffer;
                        dynamicHeader = $t7.Slice$1(46/*FieldLocations.DynamicData*/, $t7.Length - 46/*FieldLocations.DynamicData*/);
                    }
                    else 
                    {
                        if (dynamicHeaderSize > 512/*StackAllocationThreshold*/)
                        {
                            arrayPoolBuffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(dynamicHeaderSize);
                        }
                        /*Span<byte>*/ let collatedHeader = dynamicHeaderSize <= 512/*StackAllocationThreshold*/ ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 512/*StackAllocationThreshold*/, null).Slice$1(0, dynamicHeaderSize) : $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, arrayPoolBuffer, 0, dynamicHeaderSize);
                        let $t7 = buffer;
                        $t7.Slice$1(46/*FieldLocations.DynamicData*/, $t7.Length - 46/*FieldLocations.DynamicData*/).CopyTo(collatedHeader);
                        let $t8 = collatedHeader;
                        $.$spc.System.Diagnostics.Debug.Assert$1(bytesToRead === $t8.Slice$1(remainingBufferLength, $t8.Length - remainingBufferLength).Length, "bytesToRead == collatedHeader[remainingBufferLength..].Length");
                        let $t9 = collatedHeader;
                        /*int*/ let realBytesRead = furtherReads.ReadAtLeast($t9.Slice$1(remainingBufferLength, $t9.Length - remainingBufferLength), bytesToRead, false);
                        if (realBytesRead !== bytesToRead)
                        {
                            return false;
                        }
                        dynamicHeader = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(collatedHeader);
                    }
                    /*Zip64ExtraField*/ let zip64;
                    $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.TryReadBlockFinalize(header.$v, dynamicHeader, dynamicHeaderSize, uncompressedSizeSmall, compressedSizeSmall, diskNumberStartSmall, relativeOffsetOfLocalHeaderSmall, saveExtraFieldsAndComments, bytesRead, $.$ref(() => zip64, ($v) => zip64 = $v, $.$sic.System.IO.Compression.Zip64ExtraField));
                }
                finally
                {
                    {
                        if (arrayPoolBuffer !== null)
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(arrayPoolBuffer, false);
                        }
                    }
                }
                return true;
            }
            static /*Task<(bool, int, ZipCentralDirectoryFileHeader?)> *//*async*/  TryReadBlockAsync(/*ReadOnlyMemory<byte>*/ buffer, /*Stream*/ furtherReads, /*bool*/ saveExtraFieldsAndComments, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.ValueTuple$$$$($.$spc.System.Boolean, $.$spc.System.Int32, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader)), $.$spc.System.ValueTuple$$$$($.$spc.System.Boolean, $.$spc.System.Int32, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader), async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*ZipCentralDirectoryFileHeader?*/ let header;
                    /*int*/ let bytesRead;
                    /*uint*/ let compressedSizeSmall;
                    /*uint*/ let uncompressedSizeSmall;
                    /*ushort*/ let diskNumberStartSmall;
                    /*uint*/ let relativeOffsetOfLocalHeaderSmall;
                    if (!$.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.TryReadBlockInitialize(buffer.Span, $.$ref(() => header, ($v) => header = $v, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => compressedSizeSmall, ($v) => compressedSizeSmall = $v, $.$spc.System.UInt32), $.$ref(() => uncompressedSizeSmall, ($v) => uncompressedSizeSmall = $v, $.$spc.System.UInt32), $.$ref(() => diskNumberStartSmall, ($v) => diskNumberStartSmall = $v, $.$spc.System.UInt16), $.$ref(() => relativeOffsetOfLocalHeaderSmall, ($v) => relativeOffsetOfLocalHeaderSmall = $v, $.$spc.System.UInt32)))
                    {
                        return new ($.$spc.System.ValueTuple$$$$($.$spc.System.Boolean, $.$spc.System.Int32, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader))().$ctor$2(false, 0, null);
                    }
                    /*byte[]?*/ let arrayPoolBuffer = null;
                    try
                    {
                        /*int*/ let dynamicHeaderSize = ((header.FilenameLength + header.ExtraFieldLength + header.FileCommentLength) | 0);
                        /*int*/ let remainingBufferLength = ((buffer.Length - 46/*FieldLocations.DynamicData*/) | 0);
                        /*int*/ let bytesToRead = ((dynamicHeaderSize - remainingBufferLength) | 0);
                        /*scoped ReadOnlySpan<byte>*/ let dynamicHeader;
                        if (bytesToRead <= 0)
                        {
                            let $t7 = buffer.Span;
                            dynamicHeader = $t7.Slice$1(46/*FieldLocations.DynamicData*/, $t7.Length - 46/*FieldLocations.DynamicData*/);
                        }
                        else 
                        {
                            if (dynamicHeaderSize > 512/*StackAllocationThreshold*/)
                            {
                                arrayPoolBuffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(dynamicHeaderSize);
                            }
                            /*byte[]*/ let collatedHeader = dynamicHeaderSize <= 512/*StackAllocationThreshold*/ ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [dynamicHeaderSize], null) : $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, arrayPoolBuffer, 0, dynamicHeaderSize).ToArray();
                            let $t7 = buffer;
                            $t7.Slice$1(46/*FieldLocations.DynamicData*/, $t7.Length - 46/*FieldLocations.DynamicData*/).CopyTo($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(collatedHeader));
                            $.$spc.System.Diagnostics.Debug.Assert$1(bytesToRead === $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetSubArray($.$spc.System.Byte, collatedHeader, $.$spc.System.Range.StartAt($.$spc.System.Index.op_Implicit(remainingBufferLength))).length, "bytesToRead == collatedHeader[remainingBufferLength..].Length");
                            /*int*/ let realBytesRead = await furtherReads.ReadAtLeastAsync($.$spc.System.MemoryExtensions.AsMemory$9($.$spc.System.Byte, collatedHeader, $.$spc.System.Range.StartAt($.$spc.System.Index.op_Implicit(remainingBufferLength))), bytesToRead, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                            if (realBytesRead !== bytesToRead)
                            {
                                return new ($.$spc.System.ValueTuple$$$$($.$spc.System.Boolean, $.$spc.System.Int32, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader))().$ctor$2(false, bytesRead, null);
                            }
                            dynamicHeader = $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(collatedHeader);
                        }
                        /*Zip64ExtraField*/ let zip64;
                        $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.TryReadBlockFinalize(header, dynamicHeader, dynamicHeaderSize, uncompressedSizeSmall, compressedSizeSmall, diskNumberStartSmall, relativeOffsetOfLocalHeaderSmall, saveExtraFieldsAndComments, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => zip64, ($v) => zip64 = $v, $.$sic.System.IO.Compression.Zip64ExtraField));
                    }
                    finally
                    {
                        {
                            if (arrayPoolBuffer !== null)
                            {
                                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(arrayPoolBuffer, false);
                            }
                        }
                    }
                    return new ($.$spc.System.ValueTuple$$$$($.$spc.System.Boolean, $.$spc.System.Int32, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader))().$ctor$2(true, bytesRead, header);
                });
            }
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static Signature = 4;
                    /*int*/ static VersionMadeBySpecification = 1;
                    /*int*/ static VersionMadeByCompatibility = 1;
                    /*int*/ static VersionNeededToExtract = 2;
                    /*int*/ static GeneralPurposeBitFlags = 2;
                    /*int*/ static CompressionMethod = 2;
                    /*int*/ static LastModified = 4;
                    /*int*/ static Crc32 = 4;
                    /*int*/ static CompressedSize = 4;
                    /*int*/ static UncompressedSize = 4;
                    /*int*/ static FilenameLength = 2;
                    /*int*/ static ExtraFieldLength = 2;
                    /*int*/ static FileCommentLength = 2;
                    /*int*/ static DiskNumberStart = 2;
                    /*int*/ static InternalFileAttributes = 2;
                    /*int*/ static ExternalFileAttributes = 4;
                    /*int*/ static RelativeOffsetOfLocalHeader = 4;
                    static $h = 3183995;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":3183995,"h":4298151291,"f":33},{"t":655361,"n":"VersionMadeBySpecification","d":3183995,"h":8593118587,"f":33},{"t":655361,"n":"VersionMadeByCompatibility","d":3183995,"h":12888085883,"f":33},{"t":655361,"n":"VersionNeededToExtract","d":3183995,"h":17183053179,"f":33},{"t":655361,"n":"GeneralPurposeBitFlags","d":3183995,"h":21478020475,"f":33},{"t":655361,"n":"CompressionMethod","d":3183995,"h":25772987771,"f":33},{"t":655361,"n":"LastModified","d":3183995,"h":30067955067,"f":33},{"t":655361,"n":"Crc32","d":3183995,"h":34362922363,"f":33},{"t":655361,"n":"CompressedSize","d":3183995,"h":38657889659,"f":33},{"t":655361,"n":"UncompressedSize","d":3183995,"h":42952856955,"f":33},{"t":655361,"n":"FilenameLength","d":3183995,"h":47247824251,"f":33},{"t":655361,"n":"ExtraFieldLength","d":3183995,"h":51542791547,"f":33},{"t":655361,"n":"FileCommentLength","d":3183995,"h":55837758843,"f":33},{"t":655361,"n":"DiskNumberStart","d":3183995,"h":60132726139,"f":33},{"t":655361,"n":"InternalFileAttributes","d":3183995,"h":64427693435,"f":33},{"t":655361,"n":"ExternalFileAttributes","d":3183995,"h":68722660731,"f":33},{"t":655361,"n":"RelativeOffsetOfLocalHeader","d":3183995,"h":73017628027,"f":33}],"d":3118459,"h":3183995}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipCentralDirectoryFileHeader.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Signature = 0;
                    /*int*/ static VersionMadeBySpecification = 4;
                    /*int*/ static VersionMadeByCompatibility = 5;
                    /*int*/ static VersionNeededToExtract = 6;
                    /*int*/ static GeneralPurposeBitFlags = 8;
                    /*int*/ static CompressionMethod = 10;
                    /*int*/ static LastModified = 12;
                    /*int*/ static Crc32 = 16;
                    /*int*/ static CompressedSize = 20;
                    /*int*/ static UncompressedSize = 24;
                    /*int*/ static FilenameLength = 28;
                    /*int*/ static ExtraFieldLength = 30;
                    /*int*/ static FileCommentLength = 32;
                    /*int*/ static DiskNumberStart = 34;
                    /*int*/ static InternalFileAttributes = 36;
                    /*int*/ static ExternalFileAttributes = 38;
                    /*int*/ static RelativeOffsetOfLocalHeader = 42;
                    /*int*/ static DynamicData = 46;
                    static $h = 3249531;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":3249531,"h":4298216827,"f":33},{"t":655361,"n":"VersionMadeBySpecification","d":3249531,"h":8593184123,"f":33},{"t":655361,"n":"VersionMadeByCompatibility","d":3249531,"h":12888151419,"f":33},{"t":655361,"n":"VersionNeededToExtract","d":3249531,"h":17183118715,"f":33},{"t":655361,"n":"GeneralPurposeBitFlags","d":3249531,"h":21478086011,"f":33},{"t":655361,"n":"CompressionMethod","d":3249531,"h":25773053307,"f":33},{"t":655361,"n":"LastModified","d":3249531,"h":30068020603,"f":33},{"t":655361,"n":"Crc32","d":3249531,"h":34362987899,"f":33},{"t":655361,"n":"CompressedSize","d":3249531,"h":38657955195,"f":33},{"t":655361,"n":"UncompressedSize","d":3249531,"h":42952922491,"f":33},{"t":655361,"n":"FilenameLength","d":3249531,"h":47247889787,"f":33},{"t":655361,"n":"ExtraFieldLength","d":3249531,"h":51542857083,"f":33},{"t":655361,"n":"FileCommentLength","d":3249531,"h":55837824379,"f":33},{"t":655361,"n":"DiskNumberStart","d":3249531,"h":60132791675,"f":33},{"t":655361,"n":"InternalFileAttributes","d":3249531,"h":64427758971,"f":33},{"t":655361,"n":"ExternalFileAttributes","d":3249531,"h":68722726267,"f":33},{"t":655361,"n":"RelativeOffsetOfLocalHeader","d":3249531,"h":73017693563,"f":33},{"t":655361,"n":"DynamicData","d":3249531,"h":77312660859,"f":33}],"d":3118459,"h":3249531}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipCentralDirectoryFileHeader.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Filename = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [  ], null, null);
                this.FileComment = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [  ], null, null);
            }
            static $h = 3118459;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":8593053051,"f":33},"n":"SignatureConstantBytes","d":3118459,"h":4298085755,"f":33}],"m":[{"r":262145,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"header","p":3118459,"f":2},{"n":"bytesRead","p":655361,"f":2},{"n":"compressedSizeSmall","p":720897,"f":2},{"n":"uncompressedSizeSmall","p":720897,"f":2},{"n":"diskNumberStartSmall","p":589825,"f":2},{"n":"relativeOffsetOfLocalHeaderSmall","p":720897,"f":2}],"n":"TryReadBlockInitialize","d":3118459,"h":107377300859,"f":34},{"r":65537,"p":[{"n":"header","p":3118459},{"n":"dynamicHeader","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"dynamicHeaderSize","p":655361},{"n":"uncompressedSizeSmall","p":720897},{"n":"compressedSizeSmall","p":720897},{"n":"diskNumberStartSmall","p":589825},{"n":"relativeOffsetOfLocalHeaderSmall","p":720897},{"n":"saveExtraFieldsAndComments","p":262145},{"n":"bytesRead","p":655361,"f":4},{"n":"zip64","p":2332027,"f":2}],"n":"TryReadBlockFinalize","d":3118459,"h":111672268155,"f":34},{"r":262145,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"furtherReads","p":62128129},{"n":"saveExtraFieldsAndComments","p":262145},{"n":"bytesRead","p":655361,"f":2},{"n":"header","p":3118459,"f":2}],"n":"TryReadBlock","d":3118459,"h":115967235451,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.ValueTuple$$$$($.$spc.System.Boolean, $.$spc.System.Int32, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader)).$h,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"furtherReads","p":62128129},{"n":"saveExtraFieldsAndComments","p":262145},{"n":"cancellationToken","p":125960193}],"n":"TryReadBlockAsync","d":3118459,"h":120262202747,"f":4129}],"l":[{"t":655361,"n":"StackAllocationThreshold","d":3118459,"h":12888020347,"f":34},{"t":655361,"n":"BlockConstantSectionSize","d":3118459,"h":17182987643,"f":33},{"t":393217,"n":"VersionMadeByCompatibility","d":3118459,"h":21477954939,"f":1},{"t":393217,"n":"VersionMadeBySpecification","d":3118459,"h":25772922235,"f":1},{"t":589825,"n":"VersionNeededToExtract","d":3118459,"h":30067889531,"f":1},{"t":589825,"n":"GeneralPurposeBitFlag","d":3118459,"h":34362856827,"f":1},{"t":589825,"n":"CompressionMethod","d":3118459,"h":38657824123,"f":1},{"t":720897,"n":"LastModified","d":3118459,"h":42952791419,"f":1},{"t":720897,"n":"Crc32","d":3118459,"h":47247758715,"f":1},{"t":917505,"n":"CompressedSize","d":3118459,"h":51542726011,"f":1},{"t":917505,"n":"UncompressedSize","d":3118459,"h":55837693307,"f":1},{"t":589825,"n":"FilenameLength","d":3118459,"h":60132660603,"f":1},{"t":589825,"n":"ExtraFieldLength","d":3118459,"h":64427627899,"f":1},{"t":589825,"n":"FileCommentLength","d":3118459,"h":68722595195,"f":1},{"t":720897,"n":"DiskNumberStart","d":3118459,"h":73017562491,"f":1},{"t":589825,"n":"InternalFileAttributes","d":3118459,"h":77312529787,"f":1},{"t":720897,"n":"ExternalFileAttributes","d":3118459,"h":81607497083,"f":1},{"t":917505,"n":"RelativeOffsetOfLocalHeader","d":3118459,"h":85902464379,"f":1},{"t":0,"n":"Filename","d":3118459,"h":90197431675,"f":1},{"t":0,"n":"FileComment","d":3118459,"h":94492398971,"f":1},{"t":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h,"n":"ExtraFields","d":3118459,"h":98787366267,"f":1},{"t":0,"n":"TrailingExtraFieldData","d":3118459,"h":103082333563,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":3118459,"h":133147104635,"f":1}],"j":[3183995,3249531],"h":3118459}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.ZipCentralDirectoryFileHeader`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.InflaterManaged", ($self) => class InflaterManaged extends $.$spc.System.Object
        {
            static /*ReadOnlySpan<byte> */ get ExtraLengthBits()
            {
                return this.$cacheExtraLengthBits ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 16 ]);
            }
            static /*ReadOnlySpan<byte> */ get LengthBase()
            {
                return this.$cacheLengthBase ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 3 ]);
            }
            static /*ReadOnlySpan<ushort> */ get DistanceBasePosition()
            {
                return this.$cacheDistanceBasePosition ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16))().$ctor$2([ 1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 32769, 49153 ]);
            }
            static /*ReadOnlySpan<byte> */ get CodeOrder()
            {
                return this.$cacheCodeOrder ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15 ]);
            }
            static /*ReadOnlySpan<byte> */ get StaticDistanceTreeTable()
            {
                return this.$cacheStaticDistanceTreeTable ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 0, 16, 8, 24, 4, 20, 12, 28, 2, 18, 10, 26, 6, 22, 14, 30, 1, 17, 9, 25, 5, 21, 13, 29, 3, 19, 11, 27, 7, 23, 15, 31 ]);
            }
            /*OutputWindow*/ _output = null;
            /*InputBuffer*/ _input = null;
            /*HuffmanTree?*/ _literalLengthTree = null;
            /*HuffmanTree?*/ _distanceTree = null;
            /*InflaterState*/ _state = 0;
            /*int*/ _bfinal = 0;
            /*BlockType*/ _blockType = 0;
            /*byte[]*/ _blockLengthBuffer = null;
            /*int*/ _blockLength = 0;
            /*int*/ _length = 0;
            /*int*/ _distanceCode = 0;
            /*int*/ _extraBits = 0;
            /*int*/ _loopCounter = 0;
            /*int*/ _literalLengthCodeCount = 0;
            /*int*/ _distanceCodeCount = 0;
            /*int*/ _codeLengthCodeCount = 0;
            /*int*/ _codeArraySize = 0;
            /*int*/ _lengthCode = 0;
            /*byte[]*/ _codeList = null;
            /*byte[]*/ _codeLengthTreeCodeLength = null;
            /*bool*/ _deflate64 = false;
            /*HuffmanTree?*/ _codeLengthTree = null;
            /*long*/ _uncompressedSize = 0n;
            /*long*/ _currentInflatedCount = 0n;
            $ctor$1(/*bool*/ deflate64, /*long*/ uncompressedSize)
            {
                super.$ctor();
                {
                    this._output = new $.$sic.System.IO.Compression.OutputWindow().$ctor$1();
                    this._input = new $.$sic.System.IO.Compression.InputBuffer().$ctor$1();
                    this._codeList = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [((288/*HuffmanTree.MaxLiteralTreeElements*/ + 32/*HuffmanTree.MaxDistTreeElements*/) | 0)], null);
                    this._codeLengthTreeCodeLength = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [19/*HuffmanTree.NumberOfCodeLengthTreeElements*/], null);
                    this._deflate64 = deflate64;
                    this._uncompressedSize = uncompressedSize;
                    this._state = 2/*InflaterState.ReadingBFinal*/;
                }
                return this;
            }
            /*void */ SetInput(/*Memory<byte>*/ inputBytes)
            {
                return this._input.SetInput(inputBytes);
            }
            /*void */ SetInput$1(/*byte[]*/ inputBytes, /*int*/ offset, /*int*/ length)
            {
                return this._input.SetInput$1(inputBytes, offset, length);
            }
            /*bool */ Finished()
            {
                return this._state === 24/*InflaterState.Done*/ || this._state === 23/*InflaterState.VerifyingFooter*/;
            }
            /*int */ get AvailableOutput()
            {
                return this._output.AvailableBytes;
            }
            /*int */ Inflate(/*Span<byte>*/ bytes)
            {
                /*int*/ let count = 0;
                do
                {
                    /*int*/ let copied = 0;
                    if (this._uncompressedSize === BigInt(-1))
                    {
                        copied = this._output.CopyTo(bytes);
                    }
                    else 
                    {
                        if (this._uncompressedSize > this._currentInflatedCount)
                        {
                            bytes = bytes.Slice$1(0, $.$cast($.$spc.System.Math.Min$5(BigInt(bytes.Length), this._uncompressedSize - this._currentInflatedCount), $.$spc.System.Int32));
                            copied = this._output.CopyTo(bytes);
                            this._currentInflatedCount += BigInt(copied);
                        }
                        else 
                        {
                            this._state = 24/*InflaterState.Done*/;
                            this._output.ClearBytesUsed();
                        }
                    }
                    if (copied > 0)
                    {
                        bytes = bytes.Slice(copied);
                        count += copied;
                    }
                    if (bytes.IsEmpty)
                    {
                        break;
                    }
                }
                while(!this.Finished() && this.Decode());
                return count;
            }
            /*int */ Inflate$1(/*byte[]*/ bytes, /*int*/ offset, /*int*/ length)
            {
                return this.Inflate($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, bytes, offset, length));
            }
            /*bool */ Decode()
            {
                /*bool*/ let eob = false;
                /*bool*/ let result;
                if (this.Finished())
                {
                    return true;
                }
                if (this._state === 2/*InflaterState.ReadingBFinal*/)
                {
                    if (!this._input.EnsureBitsAvailable(1))
                    {
                        return false;
                    }
                    this._bfinal = this._input.GetBits(1);
                    this._state = 3/*InflaterState.ReadingBType*/;
                }
                if (this._state === 3/*InflaterState.ReadingBType*/)
                {
                    if (!this._input.EnsureBitsAvailable(2))
                    {
                        this._state = 3/*InflaterState.ReadingBType*/;
                        return false;
                    }
                    this._blockType = $.$cast(this._input.GetBits(2), $.$sic.System.IO.Compression.BlockType);
                    if (this._blockType === 2/*BlockType.Dynamic*/)
                    {
                        this._state = 4/*InflaterState.ReadingNumLitCodes*/;
                    }
                    else if (this._blockType === 1/*BlockType.Static*/)
                    {
                        this._literalLengthTree = $.$sic.System.IO.Compression.HuffmanTree.StaticLiteralLengthTree;
                        this._distanceTree = $.$sic.System.IO.Compression.HuffmanTree.StaticDistanceTree;
                        this._state = 10/*InflaterState.DecodeTop*/;
                    }
                    else if (this._blockType === 0/*BlockType.Uncompressed*/)
                    {
                        this._state = 15/*InflaterState.UncompressedAligning*/;
                    }
                    else 
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.UnknownBlockType);
                    }
                }
                if (this._blockType === 2/*BlockType.Dynamic*/)
                {
                    if (this._state < 10/*InflaterState.DecodeTop*/)
                    {
                        result = this.DecodeDynamicBlockHeader();
                    }
                    else 
                    {
                        result = this.DecodeBlock($.$ref(() => eob, ($v) => eob = $v, $.$spc.System.Boolean));
                    }
                }
                else if (this._blockType === 1/*BlockType.Static*/)
                {
                    result = this.DecodeBlock($.$ref(() => eob, ($v) => eob = $v, $.$spc.System.Boolean));
                }
                else if (this._blockType === 0/*BlockType.Uncompressed*/)
                {
                    result = this.DecodeUncompressedBlock($.$ref(() => eob, ($v) => eob = $v, $.$spc.System.Boolean));
                }
                else 
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.UnknownBlockType);
                }
                if (eob && (this._bfinal !== 0))
                {
                    this._state = 24/*InflaterState.Done*/;
                }
                return result;
            }
            /*bool */ DecodeUncompressedBlock(/*out bool*/ end_of_block)
            {
                end_of_block.$v = false;
                while(true)
                {
                    let $switchJumpState1;
                    $switchJumpStart1: while(true)
                    {
                        switch($switchJumpState1 ?? this._state)
                        {
                            case 15/*InflaterState.UncompressedAligning*/:
                            this._input.SkipToByteBoundary();
                            this._state = 16/*InflaterState.UncompressedByte1*/;
                            $switchJumpState1 = 16/*InflaterState.UncompressedByte1*/; /*goto case InflaterState.UncompressedByte1*/
                            continue $switchJumpStart1;
                            case 16/*InflaterState.UncompressedByte1*/:
                            case 17/*InflaterState.UncompressedByte2*/:
                            case 18/*InflaterState.UncompressedByte3*/:
                            case 19/*InflaterState.UncompressedByte4*/:
                            /*int*/ let bits = this._input.GetBits(8);
                            if (bits < 0)
                            {
                                return false;
                            }
                            $.$spc.System.Array.$WriteT1.call(this._blockLengthBuffer, $.$cast(bits, $.$spc.System.Byte), this._state - 16/*InflaterState.UncompressedByte1*/);
                            if (this._state === 19/*InflaterState.UncompressedByte4*/)
                            {
                                this._blockLength = (($.$spc.System.Array.$ReadT1.call(this._blockLengthBuffer, 0) + ((($.$cast($.$spc.System.Array.$ReadT1.call(this._blockLengthBuffer, 1), $.$spc.System.Int32)) * 256) | 0)) | 0);
                                /*int*/ let blockLengthComplement = (($.$spc.System.Array.$ReadT1.call(this._blockLengthBuffer, 2) + ((($.$cast($.$spc.System.Array.$ReadT1.call(this._blockLengthBuffer, 3), $.$spc.System.Int32)) * 256) | 0)) | 0);
                                if ($.$cast(this._blockLength, $.$spc.System.UInt16) !== $.$cast((~blockLengthComplement), $.$spc.System.UInt16))
                                {
                                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.InvalidBlockLength);
                                }
                            }
                            this._state += 1;
                            break;
                            case 20/*InflaterState.DecodingUncompressed*/:
                            /*int*/ let bytesCopied = this._output.CopyFrom(this._input, this._blockLength);
                            this._blockLength -= bytesCopied;
                            if (this._blockLength === 0)
                            {
                                this._state = 2/*InflaterState.ReadingBFinal*/;
                                end_of_block.$v = true;
                                return true;
                            }
                            if (this._output.FreeBytes === 0)
                            {
                                return true;
                            }
                            return false;
                            default:
                            $.$spc.System.Diagnostics.Debug.Fail("check why we are here!");
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.UnknownState);
                        }
                        break;
                    }
                }
            }
            /*bool */ DecodeBlock(/*out bool*/ end_of_block_code_seen)
            {
                end_of_block_code_seen.$v = false;
                /*int*/ let freeBytes = this._output.FreeBytes;
                while(freeBytes > 65536)
                {
                    /*int*/ let symbol;
                    let $switchJumpState1;
                    $switchJumpStart1: while(true)
                    {
                        switch($switchJumpState1 ?? this._state)
                        {
                            case 10/*InflaterState.DecodeTop*/:
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._literalLengthTree !== null, "_literalLengthTree != null");
                            symbol = this._literalLengthTree.GetNextSymbol(this._input);
                            if (symbol < 0)
                            {
                                return false;
                            }
                            if (symbol < 256)
                            {
                                this._output.Write($.$cast(symbol, $.$spc.System.Byte));
                                --freeBytes;
                            }
                            else if (symbol === 256)
                            {
                                end_of_block_code_seen.$v = true;
                                this._state = 2/*InflaterState.ReadingBFinal*/;
                                return true;
                            }
                            else 
                            {
                                symbol -= 257;
                                if (symbol < 8)
                                {
                                    symbol += 3;
                                    this._extraBits = 0;
                                }
                                else if (!this._deflate64 && symbol === 28)
                                {
                                    symbol = 258;
                                    this._extraBits = 0;
                                }
                                else 
                                {
                                    if (BigInt((symbol >>> 0)) >= BigInt($.$sic.System.IO.Compression.InflaterManaged.ExtraLengthBits.Length))
                                    {
                                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData);
                                    }
                                    this._extraBits = $.$sic.System.IO.Compression.InflaterManaged.ExtraLengthBits.get_Item(symbol).$v;
                                    $.$spc.System.Diagnostics.Debug.Assert$1(this._extraBits !== 0, "We handle other cases separately!");
                                }
                                this._length = symbol;
                                $switchJumpState1 = 11/*InflaterState.HaveInitialLength*/; /*goto case InflaterState.HaveInitialLength*/
                                continue $switchJumpStart1;
                            }
                            break;
                            case 11/*InflaterState.HaveInitialLength*/:
                            if (this._extraBits > 0)
                            {
                                this._state = 11/*InflaterState.HaveInitialLength*/;
                                /*int*/ let bits = this._input.GetBits(this._extraBits);
                                if (bits < 0)
                                {
                                    return false;
                                }
                                if (this._length < 0 || this._length >= $.$sic.System.IO.Compression.InflaterManaged.LengthBase.Length)
                                {
                                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData);
                                }
                                this._length = (($.$sic.System.IO.Compression.InflaterManaged.LengthBase.get_Item(this._length).$v + bits) | 0);
                            }
                            this._state = 12/*InflaterState.HaveFullLength*/;
                            $switchJumpState1 = 12/*InflaterState.HaveFullLength*/; /*goto case InflaterState.HaveFullLength*/
                            continue $switchJumpStart1;
                            case 12/*InflaterState.HaveFullLength*/:
                            if (this._blockType === 2/*BlockType.Dynamic*/)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._distanceTree !== null, "_distanceTree != null");
                                this._distanceCode = this._distanceTree.GetNextSymbol(this._input);
                            }
                            else 
                            {
                                this._distanceCode = this._input.GetBits(5);
                                if (this._distanceCode >= 0)
                                {
                                    this._distanceCode = $.$sic.System.IO.Compression.InflaterManaged.StaticDistanceTreeTable.get_Item(this._distanceCode).$v;
                                }
                            }
                            if (this._distanceCode < 0)
                            {
                                return false;
                            }
                            this._state = 13/*InflaterState.HaveDistCode*/;
                            $switchJumpState1 = 13/*InflaterState.HaveDistCode*/; /*goto case InflaterState.HaveDistCode*/
                            continue $switchJumpStart1;
                            case 13/*InflaterState.HaveDistCode*/:
                            /*int*/ let offset;
                            if (this._distanceCode > 3)
                            {
                                this._extraBits = (((this._distanceCode - 2) | 0)) >> 1;
                                /*int*/ let bits = this._input.GetBits(this._extraBits);
                                if (bits < 0)
                                {
                                    return false;
                                }
                                offset = (($.$sic.System.IO.Compression.InflaterManaged.DistanceBasePosition.get_Item(this._distanceCode).$v + bits) | 0);
                            }
                            else 
                            {
                                offset = ((this._distanceCode + 1) | 0);
                            }
                            this._output.WriteLengthDistance(this._length, offset);
                            freeBytes -= this._length;
                            this._state = 10/*InflaterState.DecodeTop*/;
                            break;
                            default:
                            $.$spc.System.Diagnostics.Debug.Fail("check why we are here!");
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.UnknownState);
                        }
                        break;
                    }
                }
                return true;
            }
            /*bool */ DecodeDynamicBlockHeader()
            {
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    switch($switchJumpState1 ?? this._state)
                    {
                        case 4/*InflaterState.ReadingNumLitCodes*/:
                        this._literalLengthCodeCount = this._input.GetBits(5);
                        if (this._literalLengthCodeCount < 0)
                        {
                            return false;
                        }
                        this._literalLengthCodeCount += 257;
                        this._state = 5/*InflaterState.ReadingNumDistCodes*/;
                        $switchJumpState1 = 5/*InflaterState.ReadingNumDistCodes*/; /*goto case InflaterState.ReadingNumDistCodes*/
                        continue $switchJumpStart1;
                        case 5/*InflaterState.ReadingNumDistCodes*/:
                        this._distanceCodeCount = this._input.GetBits(5);
                        if (this._distanceCodeCount < 0)
                        {
                            return false;
                        }
                        this._distanceCodeCount += 1;
                        this._state = 6/*InflaterState.ReadingNumCodeLengthCodes*/;
                        $switchJumpState1 = 6/*InflaterState.ReadingNumCodeLengthCodes*/; /*goto case InflaterState.ReadingNumCodeLengthCodes*/
                        continue $switchJumpStart1;
                        case 6/*InflaterState.ReadingNumCodeLengthCodes*/:
                        this._codeLengthCodeCount = this._input.GetBits(4);
                        if (this._codeLengthCodeCount < 0)
                        {
                            return false;
                        }
                        this._codeLengthCodeCount += 4;
                        this._loopCounter = 0;
                        this._state = 7/*InflaterState.ReadingCodeLengthCodes*/;
                        $switchJumpState1 = 7/*InflaterState.ReadingCodeLengthCodes*/; /*goto case InflaterState.ReadingCodeLengthCodes*/
                        continue $switchJumpStart1;
                        case 7/*InflaterState.ReadingCodeLengthCodes*/:
                        while(this._loopCounter < this._codeLengthCodeCount)
                        {
                            /*int*/ let bits = this._input.GetBits(3);
                            if (bits < 0)
                            {
                                return false;
                            }
                            $.$spc.System.Array.$WriteT1.call(this._codeLengthTreeCodeLength, $.$cast(bits, $.$spc.System.Byte), $.$sic.System.IO.Compression.InflaterManaged.CodeOrder.get_Item(this._loopCounter).$v);
                            ++this._loopCounter;
                        }
                        for(/*int*/ let i = this._codeLengthCodeCount; i < $.$sic.System.IO.Compression.InflaterManaged.CodeOrder.Length; i++)
                        {
                            $.$spc.System.Array.$WriteT1.call(this._codeLengthTreeCodeLength, 0, $.$sic.System.IO.Compression.InflaterManaged.CodeOrder.get_Item(i).$v);
                        }
                        this._codeLengthTree = new $.$sic.System.IO.Compression.HuffmanTree().$ctor$1(this._codeLengthTreeCodeLength);
                        this._codeArraySize = ((this._literalLengthCodeCount + this._distanceCodeCount) | 0);
                        this._loopCounter = 0;
                        this._state = 8/*InflaterState.ReadingTreeCodesBefore*/;
                        $switchJumpState1 = 8/*InflaterState.ReadingTreeCodesBefore*/; /*goto case InflaterState.ReadingTreeCodesBefore*/
                        continue $switchJumpStart1;
                        case 8/*InflaterState.ReadingTreeCodesBefore*/:
                        case 9/*InflaterState.ReadingTreeCodesAfter*/:
                        while(this._loopCounter < this._codeArraySize)
                        {
                            if (this._state === 8/*InflaterState.ReadingTreeCodesBefore*/)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._codeLengthTree !== null, "_codeLengthTree != null");
                                if ((this._lengthCode = this._codeLengthTree.GetNextSymbol(this._input)) < 0)
                                {
                                    return false;
                                }
                            }
                            if (this._lengthCode <= 15)
                            {
                                $.$spc.System.Array.$WriteT1.call(this._codeList, $.$cast(this._lengthCode, $.$spc.System.Byte), this._loopCounter++);
                            }
                            else 
                            {
                                /*int*/ let repeatCount;
                                if (this._lengthCode === 16)
                                {
                                    if (!this._input.EnsureBitsAvailable(2))
                                    {
                                        this._state = 9/*InflaterState.ReadingTreeCodesAfter*/;
                                        return false;
                                    }
                                    if (this._loopCounter === 0)
                                    {
                                        throw new $.$spc.System.IO.InvalidDataException().$ctor$9();
                                    }
                                    /*byte*/ let previousCode = $.$spc.System.Array.$ReadT1.call(this._codeList, ((this._loopCounter - 1) | 0));
                                    repeatCount = ((this._input.GetBits(2) + 3) | 0);
                                    if (((this._loopCounter + repeatCount) | 0) > this._codeArraySize)
                                    {
                                        throw new $.$spc.System.IO.InvalidDataException().$ctor$9();
                                    }
                                    for(/*int*/ let j = 0; j < repeatCount; j++)
                                    {
                                        $.$spc.System.Array.$WriteT1.call(this._codeList, previousCode, this._loopCounter++);
                                    }
                                }
                                else if (this._lengthCode === 17)
                                {
                                    if (!this._input.EnsureBitsAvailable(3))
                                    {
                                        this._state = 9/*InflaterState.ReadingTreeCodesAfter*/;
                                        return false;
                                    }
                                    repeatCount = ((this._input.GetBits(3) + 3) | 0);
                                    if (((this._loopCounter + repeatCount) | 0) > this._codeArraySize)
                                    {
                                        throw new $.$spc.System.IO.InvalidDataException().$ctor$9();
                                    }
                                    for(/*int*/ let j = 0; j < repeatCount; j++)
                                    {
                                        $.$spc.System.Array.$WriteT1.call(this._codeList, 0, this._loopCounter++);
                                    }
                                }
                                else 
                                {
                                    if (!this._input.EnsureBitsAvailable(7))
                                    {
                                        this._state = 9/*InflaterState.ReadingTreeCodesAfter*/;
                                        return false;
                                    }
                                    repeatCount = ((this._input.GetBits(7) + 11) | 0);
                                    if (((this._loopCounter + repeatCount) | 0) > this._codeArraySize)
                                    {
                                        throw new $.$spc.System.IO.InvalidDataException().$ctor$9();
                                    }
                                    for(/*int*/ let j = 0; j < repeatCount; j++)
                                    {
                                        $.$spc.System.Array.$WriteT1.call(this._codeList, 0, this._loopCounter++);
                                    }
                                }
                            }
                            this._state = 8/*InflaterState.ReadingTreeCodesBefore*/;
                        }
                        break;
                        default:
                        $.$spc.System.Diagnostics.Debug.Fail("check why we are here!");
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.UnknownState);
                    }
                    break;
                }
                /*byte[]*/ let literalTreeCodeLength = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [288/*HuffmanTree.MaxLiteralTreeElements*/], null);
                /*byte[]*/ let distanceTreeCodeLength = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [32/*HuffmanTree.MaxDistTreeElements*/], null);
                $.$spc.System.Array.Copy(this._codeList, literalTreeCodeLength, this._literalLengthCodeCount);
                $.$spc.System.Array.Copy$1(this._codeList, this._literalLengthCodeCount, distanceTreeCodeLength, 0, this._distanceCodeCount);
                if ($.$spc.System.Array.$ReadT1.call(literalTreeCodeLength, 256/*HuffmanTree.EndOfBlockCode*/) === 0)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$9();
                }
                this._literalLengthTree = new $.$sic.System.IO.Compression.HuffmanTree().$ctor$1(literalTreeCodeLength);
                this._distanceTree = new $.$sic.System.IO.Compression.HuffmanTree().$ctor$1(distanceTreeCodeLength);
                this._state = 10/*InflaterState.DecodeTop*/;
                return true;
            }
            //default member initializer
            constructor()
            {
                super();
                this._blockLengthBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [4], null);
            }
            static $h = 1414523;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":8591349115,"f":34},"n":"ExtraLengthBits","d":1414523,"h":4296381819,"f":34},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":17181283707,"f":34},"n":"LengthBase","d":1414523,"h":12886316411,"f":34},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16).$h,"g":{"r":0,"d":0,"h":25771218299,"f":34},"n":"DistanceBasePosition","d":1414523,"h":21476251003,"f":34},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":34361152891,"f":34},"n":"CodeOrder","d":1414523,"h":30066185595,"f":34},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":42951087483,"f":34},"n":"StaticDistanceTreeTable","d":1414523,"h":38656120187,"f":34},{"p":655361,"g":{"r":0,"d":0,"h":171800106363,"f":1},"n":"AvailableOutput","d":1414523,"h":167505139067,"f":1}],"m":[{"r":65537,"p":[{"n":"inputBytes","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h}],"n":"SetInput","d":1414523,"h":154620237179,"f":1},{"r":65537,"p":[{"n":"inputBytes","p":0},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"SetInput","o":"@$1","d":1414523,"h":158915204475,"f":1},{"r":262145,"n":"Finished","d":1414523,"h":163210171771,"f":1},{"r":655361,"p":[{"n":"bytes","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Inflate","d":1414523,"h":176095073659,"f":1},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"Inflate","o":"@$1","d":1414523,"h":180390040955,"f":1},{"r":262145,"n":"Decode","d":1414523,"h":184685008251,"f":2},{"r":262145,"p":[{"n":"end_of_block","p":262145,"f":2}],"n":"DecodeUncompressedBlock","d":1414523,"h":188979975547,"f":2},{"r":262145,"p":[{"n":"end_of_block_code_seen","p":262145,"f":2}],"n":"DecodeBlock","d":1414523,"h":193274942843,"f":2},{"r":262145,"n":"DecodeDynamicBlockHeader","d":1414523,"h":197569910139,"f":2}],"l":[{"t":1676667,"n":"_output","d":1414523,"h":47246054779,"f":2},{"t":1545595,"n":"_input","d":1414523,"h":51541022075,"f":2},{"t":1283451,"n":"_literalLengthTree","d":1414523,"h":55835989371,"f":2},{"t":1283451,"n":"_distanceTree","d":1414523,"h":60130956667,"f":2},{"t":1480059,"n":"_state","d":1414523,"h":64425923963,"f":2},{"t":655361,"n":"_bfinal","d":1414523,"h":68720891259,"f":2},{"t":628091,"n":"_blockType","d":1414523,"h":73015858555,"f":2},{"t":0,"n":"_blockLengthBuffer","d":1414523,"h":77310825851,"f":2},{"t":655361,"n":"_blockLength","d":1414523,"h":81605793147,"f":2},{"t":655361,"n":"_length","d":1414523,"h":85900760443,"f":2},{"t":655361,"n":"_distanceCode","d":1414523,"h":90195727739,"f":2},{"t":655361,"n":"_extraBits","d":1414523,"h":94490695035,"f":2},{"t":655361,"n":"_loopCounter","d":1414523,"h":98785662331,"f":2},{"t":655361,"n":"_literalLengthCodeCount","d":1414523,"h":103080629627,"f":2},{"t":655361,"n":"_distanceCodeCount","d":1414523,"h":107375596923,"f":2},{"t":655361,"n":"_codeLengthCodeCount","d":1414523,"h":111670564219,"f":2},{"t":655361,"n":"_codeArraySize","d":1414523,"h":115965531515,"f":2},{"t":655361,"n":"_lengthCode","d":1414523,"h":120260498811,"f":2},{"t":0,"n":"_codeList","d":1414523,"h":124555466107,"f":2},{"t":0,"n":"_codeLengthTreeCodeLength","d":1414523,"h":128850433403,"f":2},{"t":262145,"n":"_deflate64","d":1414523,"h":133145400699,"f":2},{"t":1283451,"n":"_codeLengthTree","d":1414523,"h":137440367995,"f":2},{"t":917505,"n":"_uncompressedSize","d":1414523,"h":141735335291,"f":2},{"t":917505,"n":"_currentInflatedCount","d":1414523,"h":146030302587,"f":2}],"c":[{"p":[{"n":"deflate64","p":262145},{"n":"uncompressedSize","p":917505}],"n":".ctor","o":"$ctor$1","d":1414523,"h":150325269883,"f":8}],"h":1414523}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.InflaterManaged`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.InputBuffer", ($self) => class InputBuffer extends $.$spc.System.Object
        {
            /*Memory<byte>*/ _buffer;
            /*uint*/ _bitBuffer = 0;
            /*int*/ _bitsInBuffer = 0;
            /*int */ get AvailableBits()
            {
                return this._bitsInBuffer;
            }
            /*int */ get AvailableBytes()
            {
                return ((this._buffer.Length + ($.trunc(this._bitsInBuffer / 8))) | 0);
            }
            /*bool */ EnsureBitsAvailable(/*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(0 < count && count <= 16, "count is invalid.");
                if (this._bitsInBuffer < count)
                {
                    if (this.NeedsInput())
                    {
                        return false;
                    }
                    this._bitBuffer |= (this._buffer.Span.get_Item(0).$v << this._bitsInBuffer) >>> 0;
                    this._buffer = this._buffer.Slice(1);
                    this._bitsInBuffer += 8;
                    if (this._bitsInBuffer < count)
                    {
                        if (this.NeedsInput())
                        {
                            return false;
                        }
                        this._bitBuffer |= (this._buffer.Span.get_Item(0).$v << this._bitsInBuffer) >>> 0;
                        this._buffer = this._buffer.Slice(1);
                        this._bitsInBuffer += 8;
                    }
                }
                return true;
            }
            /*uint */ TryLoad16Bits()
            {
                if (this._bitsInBuffer < 8)
                {
                    if (this._buffer.Length > 1)
                    {
                        /*Span<byte>*/ let span = this._buffer.Span;
                        this._bitBuffer |= (span.get_Item(0).$v << this._bitsInBuffer) >>> 0;
                        this._bitBuffer |= (span.get_Item(1).$v << (((this._bitsInBuffer + 8) | 0))) >>> 0;
                        this._buffer = this._buffer.Slice(2);
                        this._bitsInBuffer += 16;
                    }
                    else if (this._buffer.Length !== 0)
                    {
                        this._bitBuffer |= (this._buffer.Span.get_Item(0).$v << this._bitsInBuffer) >>> 0;
                        this._buffer = this._buffer.Slice(1);
                        this._bitsInBuffer += 8;
                    }
                }
                else if (this._bitsInBuffer < 16)
                {
                    if (!this._buffer.IsEmpty)
                    {
                        this._bitBuffer |= (this._buffer.Span.get_Item(0).$v << this._bitsInBuffer) >>> 0;
                        this._buffer = this._buffer.Slice(1);
                        this._bitsInBuffer += 8;
                    }
                }
                return this._bitBuffer;
            }
            static /*uint */ GetBitMask(/*int*/ count)
            {
                return ((((1 << count) >>> 0) - 1) >>> 0);
            }
            /*int */ GetBits(/*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(0 < count && count <= 16, "count is invalid.");
                if (!this.EnsureBitsAvailable(count))
                {
                    return -1;
                }
                /*int*/ let result = ((this._bitBuffer & $.$sic.System.IO.Compression.InputBuffer.GetBitMask(count)) | 0);
                this._bitBuffer >>= count;
                this._bitsInBuffer -= count;
                return result;
            }
            /*int */ CopyTo(/*Memory<byte>*/ output)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bitsInBuffer % 8 === 0, "_bitsInBuffer % 8 == 0");
                /*int*/ let bytesFromBitBuffer = 0;
                while(this._bitsInBuffer > 0 && !output.IsEmpty)
                {
                    output.Span.get_Item(0).$v = $.$cast(this._bitBuffer, $.$spc.System.Byte);
                    output = output.Slice(1);
                    this._bitBuffer >>= 8;
                    this._bitsInBuffer -= 8;
                    bytesFromBitBuffer++;
                }
                if (output.IsEmpty)
                {
                    return bytesFromBitBuffer;
                }
                /*int*/ let length = $.$spc.System.Math.Min$4(output.Length, this._buffer.Length);
                this._buffer.Slice$1(0, length).CopyTo(output);
                this._buffer = this._buffer.Slice(length);
                return ((bytesFromBitBuffer + length) | 0);
            }
            /*int */ CopyTo$1(/*byte[]*/ output, /*int*/ offset, /*int*/ length)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(output !== null, "output != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(offset >= 0, "offset >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 0, "length >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(offset <= ((output.length - length) | 0), "offset <= output.Length - length");
                $.$spc.System.Diagnostics.Debug.Assert$1((this._bitsInBuffer % 8) === 0, "(_bitsInBuffer % 8) == 0");
                return this.CopyTo($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, output, offset, length));
            }
            /*bool */ NeedsInput()
            {
                return this._buffer.IsEmpty;
            }
            /*void */ SetInput(/*Memory<byte>*/ buffer)
            {
                if (this._buffer.IsEmpty)
                {
                    this._buffer = buffer;
                }
            }
            /*void */ SetInput$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ length)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(buffer !== null, "buffer != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(offset >= 0, "offset >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 0, "length >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(offset <= ((buffer.length - length) | 0), "offset <= buffer.Length - length");
                this.SetInput($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, buffer, offset, length));
            }
            /*void */ SkipBits(/*int*/ n)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bitsInBuffer >= n, "No enough bits in the buffer, Did you call EnsureBitsAvailable?");
                this._bitBuffer >>= n;
                this._bitsInBuffer -= n;
            }
            /*void */ SkipToByteBoundary()
            {
                this._bitBuffer >>= (this._bitsInBuffer % 8);
                this._bitsInBuffer -= (this._bitsInBuffer % 8);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._buffer = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
            }
            static $h = 1545595;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21476382075,"f":1},"n":"AvailableBits","d":1545595,"h":17181414779,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30066316667,"f":1},"n":"AvailableBytes","d":1545595,"h":25771349371,"f":1}],"m":[{"r":262145,"p":[{"n":"count","p":655361}],"n":"EnsureBitsAvailable","d":1545595,"h":34361283963,"f":1},{"r":720897,"n":"TryLoad16Bits","d":1545595,"h":38656251259,"f":1},{"r":720897,"p":[{"n":"count","p":655361}],"n":"GetBitMask","d":1545595,"h":42951218555,"f":34},{"r":655361,"p":[{"n":"count","p":655361}],"n":"GetBits","d":1545595,"h":47246185851,"f":1},{"r":655361,"p":[{"n":"output","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h}],"n":"CopyTo","d":1545595,"h":51541153147,"f":1},{"r":655361,"p":[{"n":"output","p":0},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"CopyTo","o":"@$1","d":1545595,"h":55836120443,"f":1},{"r":262145,"n":"NeedsInput","d":1545595,"h":60131087739,"f":1},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h}],"n":"SetInput","d":1545595,"h":64426055035,"f":1},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"SetInput","o":"@$1","d":1545595,"h":68721022331,"f":1},{"r":65537,"p":[{"n":"n","p":655361}],"n":"SkipBits","d":1545595,"h":73015989627,"f":1},{"r":65537,"n":"SkipToByteBoundary","d":1545595,"h":77310956923,"f":1}],"l":[{"t":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"n":"_buffer","d":1545595,"h":4296512891,"f":2},{"t":720897,"n":"_bitBuffer","d":1545595,"h":8591480187,"f":2},{"t":655361,"n":"_bitsInBuffer","d":1545595,"h":12886447483,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1545595,"h":81605924219,"f":1}],"h":1545595}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.InputBuffer`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock", ($self) => class ZipEndOfCentralDirectoryBlock extends $.$spc.System.Object
        {
            /*byte[]*/ static SignatureConstantBytes = null;
            /*int*/ static TotalSize = 22;
            /*int*/ static SizeOfBlockWithoutSignature = 18;
            /*int*/ static ZipFileCommentMaxLength = 65535;
            /*uint*/ Signature = 0;
            /*ushort*/ NumberOfThisDisk = 0;
            /*ushort*/ NumberOfTheDiskWithTheStartOfTheCentralDirectory = 0;
            /*ushort*/ NumberOfEntriesInTheCentralDirectoryOnThisDisk = 0;
            /*ushort*/ NumberOfEntriesInTheCentralDirectory = 0;
            /*uint*/ SizeOfCentralDirectory = 0;
            /*uint*/ OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber = 0;
            /*byte[]?*/ _archiveComment = null;
            /*byte[] */ get ArchiveComment()
            {
                return this._archiveComment ??= $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [  ], null, null);
            }
            static /*void */ WriteBlockInitialize(/*Span<byte>*/ blockContents, /*long*/ numberOfEntries, /*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory, /*byte[]*/ archiveComment)
            {
                /*ushort*/ let numberOfEntriesTruncated = numberOfEntries > BigInt(65535/*ushort.MaxValue*/) ? 65535/*ZipHelper.Mask16Bit*/ : $.$cast(numberOfEntries, $.$spc.System.UInt16);
                /*uint*/ let startOfCentralDirectoryTruncated = startOfCentralDirectory > BigInt(4294967295/*uint.MaxValue*/) ? 4294967295/*ZipHelper.Mask32Bit*/ : $.$cast(startOfCentralDirectory, $.$spc.System.UInt32);
                /*uint*/ let sizeOfCentralDirectoryTruncated = sizeOfCentralDirectory > BigInt(4294967295/*uint.MaxValue*/) ? 4294967295/*ZipHelper.Mask32Bit*/ : $.$cast(sizeOfCentralDirectory, $.$spc.System.UInt32);
                let $t1 = blockContents;
                $.$spc.System.MemoryExtensions.CopyTo($.$spc.System.Byte, $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.SignatureConstantBytes, $t1.Slice$1(0/*FieldLocations.Signature*/, $t1.Length - 0/*FieldLocations.Signature*/));
                let $t2 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t2.Slice$1(4/*FieldLocations.NumberOfThisDisk*/, $t2.Length - 4/*FieldLocations.NumberOfThisDisk*/), 0);
                let $t3 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t3.Slice$1(6/*FieldLocations.NumberOfTheDiskWithTheStartOfTheCentralDirectory*/, $t3.Length - 6/*FieldLocations.NumberOfTheDiskWithTheStartOfTheCentralDirectory*/), 0);
                let $t4 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t4.Slice$1(8/*FieldLocations.NumberOfEntriesInTheCentralDirectoryOnThisDisk*/, $t4.Length - 8/*FieldLocations.NumberOfEntriesInTheCentralDirectoryOnThisDisk*/), numberOfEntriesTruncated);
                let $t5 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t5.Slice$1(10/*FieldLocations.NumberOfEntriesInTheCentralDirectory*/, $t5.Length - 10/*FieldLocations.NumberOfEntriesInTheCentralDirectory*/), numberOfEntriesTruncated);
                let $t6 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t6.Slice$1(12/*FieldLocations.SizeOfCentralDirectory*/, $t6.Length - 12/*FieldLocations.SizeOfCentralDirectory*/), sizeOfCentralDirectoryTruncated);
                let $t7 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($t7.Slice$1(16/*FieldLocations.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber*/, $t7.Length - 16/*FieldLocations.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber*/), startOfCentralDirectoryTruncated);
                $.$spc.System.Diagnostics.Debug.Assert$1(archiveComment.length <= 65535/*ZipFileCommentMaxLength*/, "archiveComment.Length <= ZipFileCommentMaxLength");
                let $t8 = blockContents;
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian($t8.Slice$1(20/*FieldLocations.ArchiveCommentLength*/, $t8.Length - 20/*FieldLocations.ArchiveCommentLength*/), $.$cast(archiveComment.length, $.$spc.System.UInt16));
            }
            static /*void */ WriteBlock(/*Stream*/ stream, /*long*/ numberOfEntries, /*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory, /*byte[]*/ archiveComment)
            {
                /*Span<byte>*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 22/*TotalSize*/, null);
                $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.WriteBlockInitialize(blockContents, numberOfEntries, startOfCentralDirectory, sizeOfCentralDirectory, archiveComment);
                stream.Write$1($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockContents));
                if (archiveComment.length > 0)
                {
                    stream.Write$1($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(archiveComment));
                }
            }
            static /*bool */ TryReadBlockInitialize(/*Stream*/ stream, /*Span<byte>*/ blockContents, /*int*/ bytesRead, /*out ZipEndOfCentralDirectoryBlock?*/ eocdBlock, /*out bool*/ readComment)
            {
                readComment.$v = false;
                eocdBlock.$v = null;
                if (bytesRead < 22/*TotalSize*/)
                {
                    return false;
                }
                if (!$.$spc.System.MemoryExtensions.StartsWith$1($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockContents), $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.SignatureConstantBytes)))
                {
                    return false;
                }
                eocdBlock.$v = (() =>
                {
                    //new $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock()
                    const $t1 = $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock;
                    const $i1 = new $t1();
                    let $t2 = blockContents;
                    $i1.Signature = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t2.Slice$1(0/*FieldLocations.Signature*/, $t2.Length - 0/*FieldLocations.Signature*/)));
                    let $t3 = blockContents;
                    $i1.NumberOfThisDisk = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t3.Slice$1(4/*FieldLocations.NumberOfThisDisk*/, $t3.Length - 4/*FieldLocations.NumberOfThisDisk*/)));
                    let $t4 = blockContents;
                    $i1.NumberOfTheDiskWithTheStartOfTheCentralDirectory = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t4.Slice$1(6/*FieldLocations.NumberOfTheDiskWithTheStartOfTheCentralDirectory*/, $t4.Length - 6/*FieldLocations.NumberOfTheDiskWithTheStartOfTheCentralDirectory*/)));
                    let $t5 = blockContents;
                    $i1.NumberOfEntriesInTheCentralDirectoryOnThisDisk = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t5.Slice$1(8/*FieldLocations.NumberOfEntriesInTheCentralDirectoryOnThisDisk*/, $t5.Length - 8/*FieldLocations.NumberOfEntriesInTheCentralDirectoryOnThisDisk*/)));
                    let $t6 = blockContents;
                    $i1.NumberOfEntriesInTheCentralDirectory = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t6.Slice$1(10/*FieldLocations.NumberOfEntriesInTheCentralDirectory*/, $t6.Length - 10/*FieldLocations.NumberOfEntriesInTheCentralDirectory*/)));
                    let $t7 = blockContents;
                    $i1.SizeOfCentralDirectory = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t7.Slice$1(12/*FieldLocations.SizeOfCentralDirectory*/, $t7.Length - 12/*FieldLocations.SizeOfCentralDirectory*/)));
                    let $t8 = blockContents;
                    $i1.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t8.Slice$1(16/*FieldLocations.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber*/, $t8.Length - 16/*FieldLocations.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber*/)));
                    return $i1;
                })();
                let $t2 = blockContents;
                /*ushort*/ let commentLength = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t2.Slice$1(20/*FieldLocations.ArchiveCommentLength*/, $t2.Length - 20/*FieldLocations.ArchiveCommentLength*/)));
                if (stream.Position + BigInt(commentLength) > stream.Length)
                {
                    return false;
                }
                if (commentLength === 0)
                {
                    eocdBlock.$v._archiveComment = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [  ], null, null);
                }
                else 
                {
                    eocdBlock.$v._archiveComment = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [commentLength], null);
                    readComment.$v = true;
                }
                return true;
            }
            static /*ZipEndOfCentralDirectoryBlock */ ReadBlock(/*Stream*/ stream)
            {
                /*Span<byte>*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 22/*TotalSize*/, null);
                /*int*/ let bytesRead = stream.ReadAtLeast(blockContents, blockContents.Length, false);
                /*ZipEndOfCentralDirectoryBlock?*/ let eocdBlock;
                /*bool*/ let readComment;
                if (!$.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.TryReadBlockInitialize(stream, blockContents, bytesRead, $.$ref(() => eocdBlock, ($v) => eocdBlock = $v, $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock), $.$ref(() => readComment, ($v) => readComment = $v, $.$spc.System.Boolean)))
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.EOCDNotFound);
                }
                else if (readComment)
                {
                    stream.ReadExactly($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(eocdBlock._archiveComment));
                }
                return eocdBlock;
            }
            static /*Task *//*async*/  WriteBlockAsync(/*Stream*/ stream, /*long*/ numberOfEntries, /*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory, /*byte[]*/ archiveComment, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [22/*TotalSize*/], null);
                    $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.WriteBlockInitialize($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockContents), numberOfEntries, startOfCentralDirectory, sizeOfCentralDirectory, archiveComment);
                    await stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(blockContents), cancellationToken).ConfigureAwait(false);
                    if (archiveComment.length > 0)
                    {
                        await stream.WriteAsync$2($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit(archiveComment), cancellationToken).ConfigureAwait(false);
                    }
                });
            }
            static /*Task<ZipEndOfCentralDirectoryBlock> *//*async*/  ReadBlockAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock), $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let blockContents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [22/*TotalSize*/], null);
                    /*int*/ let bytesRead = await stream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(blockContents), blockContents.length, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    /*ZipEndOfCentralDirectoryBlock?*/ let eocdBlock;
                    /*bool*/ let readComment;
                    if (!$.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.TryReadBlockInitialize(stream, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockContents), bytesRead, $.$ref(() => eocdBlock, ($v) => eocdBlock = $v, $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock), $.$ref(() => readComment, ($v) => readComment = $v, $.$spc.System.Boolean)))
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.EOCDNotFound);
                    }
                    else if (readComment)
                    {
                        stream.ReadExactly($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(eocdBlock._archiveComment));
                    }
                    return eocdBlock;
                });
            }
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static Signature = 4;
                    /*int*/ static NumberOfThisDisk = 2;
                    /*int*/ static NumberOfTheDiskWithTheStartOfTheCentralDirectory = 2;
                    /*int*/ static NumberOfEntriesInTheCentralDirectoryOnThisDisk = 2;
                    /*int*/ static NumberOfEntriesInTheCentralDirectory = 2;
                    /*int*/ static SizeOfCentralDirectory = 4;
                    /*int*/ static OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber = 4;
                    /*int*/ static ArchiveCommentLength = 2;
                    static $h = 3380603;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":3380603,"h":4298347899,"f":33},{"t":655361,"n":"NumberOfThisDisk","d":3380603,"h":8593315195,"f":33},{"t":655361,"n":"NumberOfTheDiskWithTheStartOfTheCentralDirectory","d":3380603,"h":12888282491,"f":33},{"t":655361,"n":"NumberOfEntriesInTheCentralDirectoryOnThisDisk","d":3380603,"h":17183249787,"f":33},{"t":655361,"n":"NumberOfEntriesInTheCentralDirectory","d":3380603,"h":21478217083,"f":33},{"t":655361,"n":"SizeOfCentralDirectory","d":3380603,"h":25773184379,"f":33},{"t":655361,"n":"OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber","d":3380603,"h":30068151675,"f":33},{"t":655361,"n":"ArchiveCommentLength","d":3380603,"h":34363118971,"f":33}],"d":3315067,"h":3380603}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipEndOfCentralDirectoryBlock.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Signature = 0;
                    /*int*/ static NumberOfThisDisk = 4;
                    /*int*/ static NumberOfTheDiskWithTheStartOfTheCentralDirectory = 6;
                    /*int*/ static NumberOfEntriesInTheCentralDirectoryOnThisDisk = 8;
                    /*int*/ static NumberOfEntriesInTheCentralDirectory = 10;
                    /*int*/ static SizeOfCentralDirectory = 12;
                    /*int*/ static OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber = 16;
                    /*int*/ static ArchiveCommentLength = 20;
                    /*int*/ static DynamicData = 22;
                    static $h = 3446139;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":3446139,"h":4298413435,"f":33},{"t":655361,"n":"NumberOfThisDisk","d":3446139,"h":8593380731,"f":33},{"t":655361,"n":"NumberOfTheDiskWithTheStartOfTheCentralDirectory","d":3446139,"h":12888348027,"f":33},{"t":655361,"n":"NumberOfEntriesInTheCentralDirectoryOnThisDisk","d":3446139,"h":17183315323,"f":33},{"t":655361,"n":"NumberOfEntriesInTheCentralDirectory","d":3446139,"h":21478282619,"f":33},{"t":655361,"n":"SizeOfCentralDirectory","d":3446139,"h":25773249915,"f":33},{"t":655361,"n":"OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber","d":3446139,"h":30068217211,"f":33},{"t":655361,"n":"ArchiveCommentLength","d":3446139,"h":34363184507,"f":33},{"t":655361,"n":"DynamicData","d":3446139,"h":38658151803,"f":33}],"d":3315067,"h":3446139}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipEndOfCentralDirectoryBlock.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SignatureConstantBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Byte.$type, [ 80, 75, 5, 6 ], null, null);
                }
            }
            static $h = 3315067;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":60132857211,"f":1},"n":"ArchiveComment","d":3315067,"h":55837889915,"f":1}],"m":[{"r":65537,"p":[{"n":"blockContents","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"numberOfEntries","p":917505},{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505},{"n":"archiveComment","p":0}],"n":"WriteBlockInitialize","d":3315067,"h":64427824507,"f":34},{"r":65537,"p":[{"n":"stream","p":62128129},{"n":"numberOfEntries","p":917505},{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505},{"n":"archiveComment","p":0}],"n":"WriteBlock","d":3315067,"h":68722791803,"f":33},{"r":262145,"p":[{"n":"stream","p":62128129},{"n":"blockContents","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesRead","p":655361},{"n":"eocdBlock","p":3315067,"f":2},{"n":"readComment","p":262145,"f":2}],"n":"TryReadBlockInitialize","d":3315067,"h":73017759099,"f":34},{"r":3315067,"p":[{"n":"stream","p":62128129}],"n":"ReadBlock","d":3315067,"h":77312726395,"f":33},{"r":133300225,"p":[{"n":"stream","p":62128129},{"n":"numberOfEntries","p":917505},{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505},{"n":"archiveComment","p":0},{"n":"cancellationToken","p":125960193}],"n":"WriteBlockAsync","d":3315067,"h":81607693691,"f":4129},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock).$h,"p":[{"n":"stream","p":62128129},{"n":"cancellationToken","p":125960193}],"n":"ReadBlockAsync","d":3315067,"h":85902660987,"f":4129}],"l":[{"t":0,"n":"SignatureConstantBytes","d":3315067,"h":4298282363,"f":33},{"t":655361,"n":"TotalSize","d":3315067,"h":8593249659,"f":33},{"t":655361,"n":"SizeOfBlockWithoutSignature","d":3315067,"h":12888216955,"f":33},{"t":655361,"n":"ZipFileCommentMaxLength","d":3315067,"h":17183184251,"f":33},{"t":720897,"n":"Signature","d":3315067,"h":21478151547,"f":1},{"t":589825,"n":"NumberOfThisDisk","d":3315067,"h":25773118843,"f":1},{"t":589825,"n":"NumberOfTheDiskWithTheStartOfTheCentralDirectory","d":3315067,"h":30068086139,"f":1},{"t":589825,"n":"NumberOfEntriesInTheCentralDirectoryOnThisDisk","d":3315067,"h":34363053435,"f":1},{"t":589825,"n":"NumberOfEntriesInTheCentralDirectory","d":3315067,"h":38658020731,"f":1},{"t":720897,"n":"SizeOfCentralDirectory","d":3315067,"h":42952988027,"f":1},{"t":720897,"n":"OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber","d":3315067,"h":47247955323,"f":1},{"t":0,"n":"_archiveComment","d":3315067,"h":51542922619,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":3315067,"h":98787562875,"f":1}],"j":[3380603,3446139],"h":3315067}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.ZipEndOfCentralDirectoryBlock`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.OutputWindow", ($self) => class OutputWindow extends $.$spc.System.Object
        {
            /*int*/ static WindowSize = 262144;
            /*int*/ static WindowMask = 262143;
            /*byte[]*/ _window = null;
            /*int*/ _end = 0;
            /*int*/ _bytesUsed = 0;
            /*void */ ClearBytesUsed()
            {
                this._bytesUsed = 0;
            }
            /*void */ Write(/*byte*/ b)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bytesUsed < 262144/*WindowSize*/, "Can't add byte when window is full!");
                $.$spc.System.Array.$WriteT1.call(this._window, b, this._end++);
                this._end &= 262143/*WindowMask*/;
                ++this._bytesUsed;
            }
            /*void */ WriteLengthDistance(/*int*/ length, /*int*/ distance)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((((this._bytesUsed + length) | 0)) <= 262144/*WindowSize*/, "No Enough space");
                this._bytesUsed += length;
                /*int*/ let copyStart = (((this._end - distance) | 0)) & 262143/*WindowMask*/;
                /*int*/ let border = ((262144/*WindowSize*/ - length) | 0);
                if (copyStart <= border && this._end < border)
                {
                    if (length <= distance)
                    {
                        $.$spc.System.Array.Copy$1(this._window, copyStart, this._window, this._end, length);
                        this._end += length;
                    }
                    else 
                    {
                        while(length-- > 0)
                        {
                            $.$spc.System.Array.$WriteT1.call(this._window, $.$spc.System.Array.$ReadT1.call(this._window, copyStart++), this._end++);
                        }
                    }
                }
                else 
                {
                    while(length-- > 0)
                    {
                        $.$spc.System.Array.$WriteT1.call(this._window, $.$spc.System.Array.$ReadT1.call(this._window, copyStart++), this._end++);
                        this._end &= 262143/*WindowMask*/;
                        copyStart &= 262143/*WindowMask*/;
                    }
                }
            }
            /*int */ CopyFrom(/*InputBuffer*/ input, /*int*/ length)
            {
                length = $.$spc.System.Math.Min$4($.$spc.System.Math.Min$4(length, ((262144/*WindowSize*/ - this._bytesUsed) | 0)), input.AvailableBytes);
                /*int*/ let copied;
                /*int*/ let tailLen = ((262144/*WindowSize*/ - this._end) | 0);
                if (length > tailLen)
                {
                    copied = input.CopyTo$1(this._window, this._end, tailLen);
                    if (copied === tailLen)
                    {
                        copied += input.CopyTo$1(this._window, 0, ((length - tailLen) | 0));
                    }
                }
                else 
                {
                    copied = input.CopyTo$1(this._window, this._end, length);
                }
                this._end = (((this._end + copied) | 0)) & 262143/*WindowMask*/;
                this._bytesUsed += copied;
                return copied;
            }
            /*int */ get FreeBytes()
            {
                return ((262144/*WindowSize*/ - this._bytesUsed) | 0);
            }
            /*int */ get AvailableBytes()
            {
                return this._bytesUsed;
            }
            /*int */ CopyTo(/*Span<byte>*/ output)
            {
                /*int*/ let copy_end;
                if (output.Length > this._bytesUsed)
                {
                    copy_end = this._end;
                    output = output.Slice$1(0, this._bytesUsed);
                }
                else 
                {
                    copy_end = (((((this._end - this._bytesUsed) | 0) + output.Length) | 0)) & 262143/*WindowMask*/;
                }
                /*int*/ let copied = output.Length;
                /*int*/ let tailLen = ((output.Length - copy_end) | 0);
                if (tailLen > 0)
                {
                    $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, this._window, ((262144/*WindowSize*/ - tailLen) | 0), tailLen).CopyTo(output);
                    output = output.Slice$1(tailLen, copy_end);
                }
                $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, this._window, ((copy_end - output.Length) | 0), output.Length).CopyTo(output);
                this._bytesUsed -= copied;
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bytesUsed >= 0, "check this function and find why we copied more bytes than we have");
                return copied;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._window = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [262144/*WindowSize*/], null);
            }
            static $h = 1676667;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":47246316923,"f":1},"n":"FreeBytes","d":1676667,"h":42951349627,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55836251515,"f":1},"n":"AvailableBytes","d":1676667,"h":51541284219,"f":1}],"m":[{"r":65537,"n":"ClearBytesUsed","d":1676667,"h":25771480443,"f":8},{"r":65537,"p":[{"n":"b","p":393217}],"n":"Write","d":1676667,"h":30066447739,"f":1},{"r":65537,"p":[{"n":"length","p":655361},{"n":"distance","p":655361}],"n":"WriteLengthDistance","d":1676667,"h":34361415035,"f":1},{"r":655361,"p":[{"n":"input","p":1545595},{"n":"length","p":655361}],"n":"CopyFrom","d":1676667,"h":38656382331,"f":1},{"r":655361,"p":[{"n":"output","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"CopyTo","d":1676667,"h":60131218811,"f":1}],"l":[{"t":655361,"n":"WindowSize","d":1676667,"h":4296643963,"f":34},{"t":655361,"n":"WindowMask","d":1676667,"h":8591611259,"f":34},{"t":0,"n":"_window","d":1676667,"h":12886578555,"f":2},{"t":655361,"n":"_end","d":1676667,"h":17181545851,"f":2},{"t":655361,"n":"_bytesUsed","d":1676667,"h":21476513147,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1676667,"h":64426186107,"f":1}],"h":1676667}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.OutputWindow`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZLibNative", ($self) => class ZLibNative
        {
            /*IntPtr*/ static ZNullPtr = 0;
            static $_FlushCode;
            static get FlushCode()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_FlushCode ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.FlushCode", ($self) => class FlushCode extends $.$spc.System.Enum
                {
                    static NoFlush = 0;
                    static SyncFlush = 2;
                    static Finish = 4;
                    static Block = 5;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "NoFlush": 0n,
                            "SyncFlush": 2n,
                            "Finish": 4n,
                            "Block": 5n
                        };
                    }
                    static $h = 5019003;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5019003,"n":"NoFlush","d":5019003,"h":4299986299,"f":33},{"t":5019003,"n":"SyncFlush","d":5019003,"h":8594953595,"f":33},{"t":5019003,"n":"Finish","d":5019003,"h":12889920891,"f":33},{"t":5019003,"n":"Block","d":5019003,"h":17184888187,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5019003,"h":21479855483,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":4691323,"h":5019003}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZLibNative.FlushCode`; }
                }, $cls, ($v) => $cls.$_FlushCode = $v);
            }
            static $_ErrorCode;
            static get ErrorCode()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_ErrorCode ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.ErrorCode", ($self) => class ErrorCode extends $.$spc.System.Enum
                {
                    static Ok = 0;
                    static StreamEnd = 1;
                    static StreamError = -2;
                    static DataError = -3;
                    static MemError = -4;
                    static BufError = -5;
                    static VersionError = -6;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Ok": 0n,
                            "StreamEnd": 1n,
                            "StreamError": -2n,
                            "DataError": -3n,
                            "MemError": -4n,
                            "BufError": -5n,
                            "VersionError": -6n
                        };
                    }
                    static $h = 4953467;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4953467,"n":"Ok","d":4953467,"h":4299920763,"f":33},{"t":4953467,"n":"StreamEnd","d":4953467,"h":8594888059,"f":33},{"t":4953467,"n":"StreamError","d":4953467,"h":12889855355,"f":33},{"t":4953467,"n":"DataError","d":4953467,"h":17184822651,"f":33},{"t":4953467,"n":"MemError","d":4953467,"h":21479789947,"f":33},{"t":4953467,"n":"BufError","d":4953467,"h":25774757243,"f":33},{"t":4953467,"n":"VersionError","d":4953467,"h":30069724539,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4953467,"h":34364691835,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":4691323,"h":4953467}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZLibNative.ErrorCode`; }
                }, $cls, ($v) => $cls.$_ErrorCode = $v);
            }
            static $_CompressionStrategy;
            static get CompressionStrategy()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_CompressionStrategy ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.CompressionStrategy", ($self) => class CompressionStrategy extends $.$spc.System.Enum
                {
                    static DefaultStrategy = 0;
                    static Filtered = 1;
                    static HuffmanOnly = 2;
                    static RunLengthEncoding = 3;
                    static Fixed = 4;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "DefaultStrategy": 0n,
                            "Filtered": 1n,
                            "HuffmanOnly": 2n,
                            "RunLengthEncoding": 3n,
                            "Fixed": 4n
                        };
                    }
                    static $h = 4887931;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4887931,"n":"DefaultStrategy","d":4887931,"h":4299855227,"f":33},{"t":4887931,"n":"Filtered","d":4887931,"h":8594822523,"f":33},{"t":4887931,"n":"HuffmanOnly","d":4887931,"h":12889789819,"f":33},{"t":4887931,"n":"RunLengthEncoding","d":4887931,"h":17184757115,"f":33},{"t":4887931,"n":"Fixed","d":4887931,"h":21479724411,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4887931,"h":25774691707,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":4691323,"h":4887931}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZLibNative.CompressionStrategy`; }
                }, $cls, ($v) => $cls.$_CompressionStrategy = $v);
            }
            static $_CompressionMethod;
            static get CompressionMethod()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_CompressionMethod ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.CompressionMethod", ($self) => class CompressionMethod extends $.$spc.System.Enum
                {
                    static Deflated = 8;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Deflated": 8n
                        };
                    }
                    static $h = 4822395;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4822395,"n":"Deflated","d":4822395,"h":4299789691,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4822395,"h":8594756987,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":4691323,"h":4822395}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZLibNative.CompressionMethod`; }
                }, $cls, ($v) => $cls.$_CompressionMethod = $v);
            }
            /*int*/ static Deflate_DefaultWindowBits = -15;
            /*int*/ static ZLib_DefaultWindowBits = 15;
            /*int*/ static GZip_DefaultWindowBits = 31;
            /*int*/ static Deflate_DefaultMemLevel = 8;
            /*int*/ static Deflate_NoCompressionMemLevel = 7;
            /*byte*/ static GZip_Header_ID1 = 31;
            /*byte*/ static GZip_Header_ID2 = 139;
            static $_ZLibStreamHandle;
            static get ZLibStreamHandle()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_ZLibStreamHandle ??= $asm.$ncls("$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle", ($self) => class ZLibStreamHandle extends $.$spc.System.Runtime.InteropServices.SafeHandle
                {
                    static $_State;
                    static get State()
                    {
                        let $cls = $.$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle;
                        return $cls.$_State ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle.State", ($self) => class State extends $.$spc.System.Enum
                        {
                            static NotInitialized = 0;
                            static InitializedForDeflate = 1;
                            static InitializedForInflate = 2;
                            static Disposed = 3;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "NotInitialized": 0n,
                                    "InitializedForDeflate": 1n,
                                    "InitializedForInflate": 2n,
                                    "Disposed": 3n
                                };
                            }
                            static $h = 5150075;
                            static $z = 4;
                            static $f = 0b110000011010001001;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5150075,"n":"NotInitialized","d":5150075,"h":4300117371,"f":33},{"t":5150075,"n":"InitializedForDeflate","d":5150075,"h":8595084667,"f":33},{"t":5150075,"n":"InitializedForInflate","d":5150075,"h":12890051963,"f":33},{"t":5150075,"n":"Disposed","d":5150075,"h":17185019259,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5150075,"h":21479986555,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":5084539,"h":5150075}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `System.IO.Compression.ZLibNative.ZLibStreamHandle.State`; }
                        }, $cls, ($v) => $cls.$_State = $v);
                    }
                    /*ZStream*/ _zStream;
                    /*State*/ _initializationState = 0;
                    $ctor$3()
                    {
                        super.$ctor$2(new $.$spc.System.IntPtr().$ctor$2(-1), true);
                        {
                            this._initializationState = 0/*State.NotInitialized*/;
                            this.SetHandle($.$spc.System.IntPtr.Zero);
                        }
                        return this;
                    }
                    /*bool */ get IsInvalid()
                    {
                        return this.handle === new $.$spc.System.IntPtr().$ctor$2(-1);
                    }
                    /*State */ get InitializationState()
                    {
                        return this._initializationState;
                    }
                    /*bool */ ReleaseHandle()
                    {
                        return (() =>
                        {
                            if (this.InitializationState === 0/*State.NotInitialized*/)
                            {
                                return true;
                            }
                            if (this.InitializationState === 1/*State.InitializedForDeflate*/)
                            {
                                return (this.DeflateEnd() === 0/*ErrorCode.Ok*/);
                            }
                            if (this.InitializationState === 2/*State.InitializedForInflate*/)
                            {
                                return (this.InflateEnd() === 0/*ErrorCode.Ok*/);
                            }
                            if (this.InitializationState === 3/*State.Disposed*/)
                            {
                                return true;
                            }
                            return false;
                        })();
                    }
                    /*IntPtr */ get NextIn()
                    {
                        return this._zStream.nextIn;
                    }
                    /*IntPtr */ set NextIn(value)
                    {
                        this._zStream.nextIn = value;
                    }
                    /*uint */ get AvailIn()
                    {
                        return this._zStream.availIn;
                    }
                    /*uint */ set AvailIn(value)
                    {
                        this._zStream.availIn = value;
                    }
                    /*IntPtr */ get NextOut()
                    {
                        return this._zStream.nextOut;
                    }
                    /*IntPtr */ set NextOut(value)
                    {
                        this._zStream.nextOut = value;
                    }
                    /*uint */ get AvailOut()
                    {
                        return this._zStream.availOut;
                    }
                    /*uint */ set AvailOut(value)
                    {
                        this._zStream.availOut = value;
                    }
                    /*void */ EnsureNotDisposed()
                    {
                        $.$spc.System.ObjectDisposedException.ThrowIf(this.InitializationState === 3/*State.Disposed*/, this);
                    }
                    /*void */ EnsureState(/*State*/ requiredState)
                    {
                        if (this.InitializationState !== requiredState)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10("InitializationState != " + $.$spc.System.Enum.ToStringT($.$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle.State, $.$spc.System.UInt32, requiredState));
                        }
                    }
                    /*ErrorCode */ DeflateInit2_(/*CompressionLevel*/ level, /*int*/ windowBits, /*int*/ memLevel, /*CompressionStrategy*/ strategy)
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(0/*State.NotInitialized*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            /*ErrorCode*/ let errC = $.$sic.Interop.ZLib.DeflateInit2_(stream, level, 8/*CompressionMethod.Deflated*/, windowBits, memLevel, strategy);
                            this._initializationState = 1/*State.InitializedForDeflate*/;
                            return errC;
                        }
                    }
                    /*ErrorCode */ Deflate(/*FlushCode*/ flush)
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(1/*State.InitializedForDeflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            return $.$sic.Interop.ZLib.Deflate(stream, flush);
                        }
                    }
                    /*ErrorCode */ DeflateEnd()
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(1/*State.InitializedForDeflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            /*ErrorCode*/ let errC = $.$sic.Interop.ZLib.DeflateEnd(stream);
                            this._initializationState = 3/*State.Disposed*/;
                            return errC;
                        }
                    }
                    /*ErrorCode */ InflateInit2_(/*int*/ windowBits)
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(0/*State.NotInitialized*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            /*ErrorCode*/ let errC = $.$sic.Interop.ZLib.InflateInit2_(stream, windowBits);
                            this._initializationState = 2/*State.InitializedForInflate*/;
                            return errC;
                        }
                    }
                    /*ErrorCode */ InflateReset2_(/*int*/ windowBits)
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(2/*State.InitializedForInflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            return $.$sic.Interop.ZLib.InflateReset2_(stream, windowBits);
                        }
                    }
                    /*ErrorCode */ Inflate(/*FlushCode*/ flush)
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(2/*State.InitializedForInflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            return $.$sic.Interop.ZLib.Inflate(stream, flush);
                        }
                    }
                    /*ErrorCode */ InflateEnd()
                    {
                        this.EnsureNotDisposed();
                        this.EnsureState(2/*State.InitializedForInflate*/);
                        /*fixed*/ 
                        {
                            /*ZStream**/ let stream = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sic.System.IO.Compression.ZLibNative.ZStream, () => this._zStream, ($v) => this._zStream = $v, null);
                            /*ErrorCode*/ let errC = $.$sic.Interop.ZLib.InflateEnd(stream);
                            this._initializationState = 3/*State.Disposed*/;
                            return errC;
                        }
                    }
                    /*string */ GetErrorMessage()
                    {
                        return this._zStream.msg !== $.$sic.System.IO.Compression.ZLibNative.ZNullPtr ? $.$spc.System.Runtime.InteropServices.Marshal.PtrToStringUTF8(this._zStream.msg) : $.$spc.System.String.Empty;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._zStream = $.$default($.$sic.System.IO.Compression.ZLibNative.ZStream);
                    }
                    static $h = 5084539;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":109576193,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25774888315,"f":32769},"n":"IsInvalid","d":5084539,"h":21479921019,"f":32769},{"p":5150075,"g":{"r":0,"d":0,"h":34364822907,"f":1},"n":"InitializationState","d":5084539,"h":30069855611,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":47249724795,"f":1},"s":{"r":0,"d":0,"h":51544692091,"f":1},"n":"NextIn","d":5084539,"h":42954757499,"f":1},{"p":720897,"g":{"r":0,"d":0,"h":60134626683,"f":1},"s":{"r":0,"d":0,"h":64429593979,"f":1},"n":"AvailIn","d":5084539,"h":55839659387,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":73019528571,"f":1},"s":{"r":0,"d":0,"h":77314495867,"f":1},"n":"NextOut","d":5084539,"h":68724561275,"f":1},{"p":720897,"g":{"r":0,"d":0,"h":85904430459,"f":1},"s":{"r":0,"d":0,"h":90199397755,"f":1},"n":"AvailOut","d":5084539,"h":81609463163,"f":1}],"m":[{"r":262145,"n":"ReleaseHandle","d":5084539,"h":38659790203,"f":32772},{"r":65537,"n":"EnsureNotDisposed","d":5084539,"h":94494365051,"f":2},{"r":65537,"p":[{"n":"requiredState","p":5150075}],"n":"EnsureState","d":5084539,"h":98789332347,"f":2},{"r":4953467,"p":[{"n":"level","p":4756859},{"n":"windowBits","p":655361},{"n":"memLevel","p":655361},{"n":"strategy","p":4887931}],"n":"DeflateInit2_","d":5084539,"h":103084299643,"f":1},{"r":4953467,"p":[{"n":"flush","p":5019003}],"n":"Deflate","d":5084539,"h":107379266939,"f":1},{"r":4953467,"n":"DeflateEnd","d":5084539,"h":111674234235,"f":1},{"r":4953467,"p":[{"n":"windowBits","p":655361}],"n":"InflateInit2_","d":5084539,"h":115969201531,"f":1},{"r":4953467,"p":[{"n":"windowBits","p":655361}],"n":"InflateReset2_","d":5084539,"h":120264168827,"f":1},{"r":4953467,"p":[{"n":"flush","p":5019003}],"n":"Inflate","d":5084539,"h":124559136123,"f":1},{"r":4953467,"n":"InflateEnd","d":5084539,"h":128854103419,"f":1},{"r":1310721,"n":"GetErrorMessage","d":5084539,"h":133149070715,"f":1}],"l":[{"t":5215611,"n":"_zStream","d":5084539,"h":8595019131,"f":2},{"t":5150075,"n":"_initializationState","d":5084539,"h":12889986427,"f":2}],"c":[{"n":".ctor","o":"$ctor$3","d":5084539,"h":17184953723,"f":1}],"i":[57475073],"j":[5150075],"d":4691323,"h":5084539}; }
                    static get $b() { return $.$spc.System.Runtime.InteropServices.SafeHandle; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `System.IO.Compression.ZLibNative.ZLibStreamHandle`; }
                }, $cls, ($v) => $cls.$_ZLibStreamHandle = $v);
            }
            static /*ErrorCode */ CreateZLibStreamForDeflate(/*out ZLibStreamHandle*/ zLibStreamHandle, /*CompressionLevel*/ level, /*int*/ windowBits, /*int*/ memLevel, /*CompressionStrategy*/ strategy)
            {
                zLibStreamHandle.$v = new $.$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle().$ctor$3();
                return zLibStreamHandle.$v.DeflateInit2_(level, windowBits, memLevel, strategy);
            }
            static /*ErrorCode */ CreateZLibStreamForInflate(/*out ZLibStreamHandle*/ zLibStreamHandle, /*int*/ windowBits)
            {
                zLibStreamHandle.$v = new $.$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle().$ctor$3();
                return zLibStreamHandle.$v.InflateInit2_(windowBits);
            }
            static $_CompressionLevel;
            static get CompressionLevel()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_CompressionLevel ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.CompressionLevel", ($self) => class CompressionLevel extends $.$spc.System.Enum
                {
                    static NoCompression = 0;
                    static BestSpeed = 1;
                    static DefaultCompression = -1;
                    static BestCompression = 9;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "NoCompression": 0n,
                            "BestSpeed": 1n,
                            "DefaultCompression": -1n,
                            "BestCompression": 9n
                        };
                    }
                    static $h = 4756859;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4756859,"n":"NoCompression","d":4756859,"h":4299724155,"f":33},{"t":4756859,"n":"BestSpeed","d":4756859,"h":8594691451,"f":33},{"t":4756859,"n":"DefaultCompression","d":4756859,"h":12889658747,"f":33},{"t":4756859,"n":"BestCompression","d":4756859,"h":17184626043,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4756859,"h":21479593339,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":4691323,"h":4756859}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `ZLibNative.CompressionLevel`; }
                }, $cls, ($v) => $cls.$_CompressionLevel = $v);
            }
            static $_ZStream;
            static get ZStream()
            {
                let $cls = $.$sic.System.IO.Compression.ZLibNative;
                return $cls.$_ZStream ??= $asm.$nstr("$sic.System.IO.Compression.ZLibNative.ZStream", ($self) => class ZStream extends $.$spc.System.ValueType
                {
                    /*IntPtr*/  get nextIn() { return this.$getField(0, $.$spc.System.IntPtr); }
                    /*IntPtr*/  set nextIn(value) { this.$setField(0, $.$spc.System.IntPtr, value); }
                    /*IntPtr*/  get nextOut() { return this.$getField(4, $.$spc.System.IntPtr); }
                    /*IntPtr*/  set nextOut(value) { this.$setField(4, $.$spc.System.IntPtr, value); }
                    /*IntPtr*/  get msg() { return this.$getField(8, $.$spc.System.IntPtr); }
                    /*IntPtr*/  set msg(value) { this.$setField(8, $.$spc.System.IntPtr, value); }
                    /*IntPtr*/  get internalState() { return this.$getField(12, $.$spc.System.IntPtr); }
                    /*IntPtr*/  set internalState(value) { this.$setField(12, $.$spc.System.IntPtr, value); }
                    /*uint*/  get availIn() { return this.$getField(16, $.$spc.System.UInt32); }
                    /*uint*/  set availIn(value) { this.$setField(16, $.$spc.System.UInt32, value); }
                    /*uint*/  get availOut() { return this.$getField(20, $.$spc.System.UInt32); }
                    /*uint*/  set availOut(value) { this.$setField(20, $.$spc.System.UInt32, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.nextIn = this.nextIn;
                        copy.nextOut = this.nextOut;
                        copy.msg = this.msg;
                        copy.internalState = this.internalState;
                        copy.availIn = this.availIn;
                        copy.availOut = this.availOut;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.nextIn = 0;
                        this.nextOut = 0;
                        this.msg = 0;
                        this.internalState = 0;
                        this.availIn = 0;
                        this.availOut = 0;
                    }
                    static $h = 5215611;
                    static $z = 24;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":786433,"n":"nextIn","d":5215611,"h":4300182907,"f":8},{"t":786433,"n":"nextOut","d":5215611,"h":8595150203,"f":8},{"t":786433,"n":"msg","d":5215611,"h":12890117499,"f":8},{"t":786433,"n":"internalState","d":5215611,"h":17185084795,"f":2},{"t":720897,"n":"availIn","d":5215611,"h":21480052091,"f":8},{"t":720897,"n":"availOut","d":5215611,"h":25775019387,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":5215611,"h":30069986683,"f":1}],"d":4691323,"h":5215611,"a":[{"t":109903873,"c":4404871169,"a":[{"v":0,"t":105381889}],"n":[{"n":"CharSet","v":2,"t":98500609}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.IO.Compression.ZLibNative.ZStream`; }
                }, $cls, ($v) => $cls.$_ZStream = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ZNullPtr = $.$spc.System.IntPtr.Zero;
                }
            }
            static $h = 4691323;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":4953467,"p":[{"n":"zLibStreamHandle","p":5084539,"f":2},{"n":"level","p":4756859},{"n":"windowBits","p":655361},{"n":"memLevel","p":655361},{"n":"strategy","p":4887931}],"n":"CreateZLibStreamForDeflate","d":4691323,"h":60134233467,"f":33},{"r":4953467,"p":[{"n":"zLibStreamHandle","p":5084539,"f":2},{"n":"windowBits","p":655361}],"n":"CreateZLibStreamForInflate","d":4691323,"h":64429200763,"f":33}],"l":[{"t":786433,"n":"ZNullPtr","d":4691323,"h":4299658619,"f":40},{"t":655361,"n":"Deflate_DefaultWindowBits","d":4691323,"h":25774495099,"f":33},{"t":655361,"n":"ZLib_DefaultWindowBits","d":4691323,"h":30069462395,"f":33},{"t":655361,"n":"GZip_DefaultWindowBits","d":4691323,"h":34364429691,"f":33},{"t":655361,"n":"Deflate_DefaultMemLevel","d":4691323,"h":38659396987,"f":33},{"t":655361,"n":"Deflate_NoCompressionMemLevel","d":4691323,"h":42954364283,"f":33},{"t":393217,"n":"GZip_Header_ID1","d":4691323,"h":47249331579,"f":33},{"t":393217,"n":"GZip_Header_ID2","d":4691323,"h":51544298875,"f":33}],"j":[5019003,4953467,4887931,4822395,5084539,4756859,5215611],"h":4691323}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.ZLibNative`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.Crc32Helper", ($self) => class Crc32Helper
        {
            static /*uint */ UpdateCrc32(/*uint*/ crc32, /*byte[]*/ buffer, /*int*/ offset, /*int*/ length)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((buffer !== null) && (offset >= 0) && (length >= 0) && (offset <= ((buffer.length - length) | 0)), "(buffer != null) && (offset >= 0) && (length >= 0) && (offset <= buffer.Length - length)");
                /*fixed*/ 
                {
                    /*byte**/ let bufferPtr = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$spc.System.Byte, buffer, offset, false, true);
                    return $.$sic.Interop.ZLib.crc32(crc32, bufferPtr, length);
                }
            }
            static /*uint */ UpdateCrc32$1(/*uint*/ crc32, /*ReadOnlySpan<byte>*/ buffer)
            {
                /*fixed*/ 
                {
                    /*byte**/ let bufferPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, buffer);
                    return $.$sic.Interop.ZLib.crc32(crc32, bufferPtr, buffer.Length);
                }
            }
            static $h = 890235;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":720897,"p":[{"n":"crc32","p":720897},{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"UpdateCrc32","d":890235,"h":4295857531,"f":33},{"r":720897,"p":[{"n":"crc32","p":720897},{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"UpdateCrc32","o":"@$1","d":890235,"h":8590824827,"f":33}],"h":890235}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.Crc32Helper`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipArchiveEntryConstants", ($self) => class ZipArchiveEntryConstants
        {
            /*uint*/ static DefaultFileExternalAttributes = 2175008768;
            /*uint*/ static DefaultDirectoryExternalAttributes = 1106051072;
            static $h = 2987387;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":720897,"n":"DefaultFileExternalAttributes","d":2987387,"h":4297954683,"f":40},{"t":720897,"n":"DefaultDirectoryExternalAttributes","d":2987387,"h":8592921979,"f":40}],"h":2987387}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.ZipArchiveEntryConstants`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZLibCompressionOptions", ($self) => class ZLibCompressionOptions extends $.$spc.System.Object
        {
            /*int*/ _compressionLevel = -1;
            /*ZLibCompressionStrategy*/ _strategy = 0;
            /*int */ get CompressionLevel()
            {
                return this._compressionLevel;
            }
            /*int */ set CompressionLevel(value)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, value, -1, "value");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, value, 9, "value");
                this._compressionLevel = value;
            }
            /*ZLibCompressionStrategy */ get CompressionStrategy()
            {
                return this._strategy;
            }
            /*ZLibCompressionStrategy */ set CompressionStrategy(value)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, value, 0/*ZLibCompressionStrategy.Default*/, "value");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, value, 4/*ZLibCompressionStrategy.Fixed*/, "value");
                this._strategy = value;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 4494715;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17184363899,"f":1},"s":{"r":0,"d":0,"h":21479331195,"f":1},"n":"CompressionLevel","d":4494715,"h":12889396603,"f":1},{"p":4560251,"g":{"r":0,"d":0,"h":30069265787,"f":1},"s":{"r":0,"d":0,"h":34364233083,"f":1},"n":"CompressionStrategy","d":4494715,"h":25774298491,"f":1}],"l":[{"t":655361,"n":"_compressionLevel","d":4494715,"h":4299462011,"f":2},{"t":4560251,"n":"_strategy","d":4494715,"h":8594429307,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":4494715,"h":38659200379,"f":1}],"h":4494715}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Compression.ZLibCompressionOptions`; }
        });
        
        $asm.$cls("$sic.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 5346683;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":5346683,"h":4300313979,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":5346683,"h":8595281275,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":5346683,"h":12890248571,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":5346683,"h":17185215867,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":5346683,"h":21480183163,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":5346683,"h":25775150459,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":5346683,"h":30070117755,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":5346683,"h":34365085051,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":5346683,"h":38660052347,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":5346683,"h":42955019643,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":5346683,"h":47249986939,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":5346683,"h":51544954235,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":5346683,"h":55839921531,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":5346683,"h":60134888827,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":5346683,"h":64429856123,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":5346683,"h":68724823419,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":5346683,"h":73019790715,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":5346683,"h":77314758011,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":5346683,"h":81609725307,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":5346683,"h":85904692603,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":5346683,"h":90199659899,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":5346683,"h":94494627195,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":5346683,"h":98789594491,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":5346683,"h":103084561787,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":5346683,"h":107379529083,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":5346683,"h":111674496379,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":5346683,"h":115969463675,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":5346683,"h":120264430971,"f":40},{"t":1310721,"n":"WebRequestMessage","d":5346683,"h":124559398267,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":5346683,"h":128854365563,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":5346683,"h":133149332859,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":5346683,"h":137444300155,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":5346683,"h":141739267451,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":5346683,"h":146034234747,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":5346683,"h":150329202043,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":5346683,"h":154624169339,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":5346683,"h":158919136635,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":5346683,"h":163214103931,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":5346683,"h":167509071227,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":5346683,"h":171804038523,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":5346683,"h":176099005819,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":5346683,"h":180393973115,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":5346683,"h":184688940411,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":5346683,"h":188983907707,"f":40},{"t":1310721,"n":"RijndaelMessage","d":5346683,"h":193278875003,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":5346683,"h":197573842299,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":5346683,"h":201868809595,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":5346683,"h":206163776891,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":5346683,"h":210458744187,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":5346683,"h":214753711483,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":5346683,"h":219048678779,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":5346683,"h":223343646075,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":5346683,"h":227638613371,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":5346683,"h":231933580667,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":5346683,"h":236228547963,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":5346683,"h":240523515259,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":5346683,"h":244818482555,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":5346683,"h":249113449851,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":5346683,"h":253408417147,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":5346683,"h":257703384443,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":5346683,"h":261998351739,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":5346683,"h":266293319035,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":5346683,"h":270588286331,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":5346683,"h":274883253627,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":5346683,"h":279178220923,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":5346683,"h":283473188219,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":5346683,"h":287768155515,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":5346683,"h":292063122811,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":5346683,"h":296358090107,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":5346683,"h":300653057403,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":5346683,"h":304948024699,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":5346683,"h":309242991995,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":5346683,"h":313537959291,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":5346683,"h":317832926587,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":5346683,"h":322127893883,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":5346683,"h":326422861179,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":5346683,"h":330717828475,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":5346683,"h":335012795771,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":5346683,"h":339307763067,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":5346683,"h":343602730363,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":5346683,"h":347897697659,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":5346683,"h":352192664955,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":5346683,"h":356487632251,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":5346683,"h":360782599547,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":5346683,"h":365077566843,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":5346683,"h":369372534139,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":5346683,"h":373667501435,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":5346683,"h":377962468731,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":5346683,"h":382257436027,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":5346683,"h":386552403323,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":5346683,"h":390847370619,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":5346683,"h":395142337915,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":5346683,"h":399437305211,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":5346683,"h":403732272507,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":5346683,"h":408027239803,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":5346683,"h":412322207099,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":5346683,"h":416617174395,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":5346683,"h":420912141691,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":5346683,"h":425207108987,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":5346683,"h":429502076283,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":5346683,"h":433797043579,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":5346683,"h":438092010875,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":5346683,"h":442386978171,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":5346683,"h":446681945467,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":5346683,"h":450976912763,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":5346683,"h":455271880059,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":5346683,"h":459566847355,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":5346683,"h":463861814651,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":5346683,"h":468156781947,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":5346683,"h":472451749243,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":5346683,"h":476746716539,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":5346683,"h":481041683835,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":5346683,"h":485336651131,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":5346683,"h":489631618427,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":5346683,"h":493926585723,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":5346683,"h":498221553019,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":5346683,"h":502516520315,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":5346683,"h":506811487611,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":5346683,"h":511106454907,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":5346683,"h":515401422203,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":5346683,"h":519696389499,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":5346683,"h":523991356795,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":5346683,"h":528286324091,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":5346683,"h":532581291387,"f":40}],"h":5346683}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.Deflater", ($self) => class Deflater extends $.$spc.System.Object
        {
            /*ZLibNative.ZLibStreamHandle*/ _zlibStream = null;
            /*MemoryHandle*/ _inputBufferHandle;
            /*bool*/ _isDisposed = false;
            /*int*/ static minWindowBits = -15;
            /*int*/ static maxWindowBits = 31;
            /*object */ get SyncLock()
            {
                return this;
            }
            $ctor$1(/*ZLibNative.CompressionLevel*/ compressionLevel, /*ZLibNative.CompressionStrategy*/ strategy, /*int*/ windowBits, /*int*/ memLevel)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(windowBits >= -15/*minWindowBits*/ && windowBits <= 31/*maxWindowBits*/, "windowBits >= minWindowBits && windowBits <= maxWindowBits");
                    /*ZErrorCode*/ let errC;
                    try
                    {
                        errC = $.$sic.System.IO.Compression.ZLibNative.CreateZLibStreamForDeflate($.$ref(() => this._zlibStream, ($v) => this._zlibStream = $v, $.$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle), compressionLevel, windowBits, memLevel, strategy);
                    }
                    catch(cause)
                    {
                        throw new $.$sic.System.IO.Compression.ZLibException().$ctor$16($.$sic.System.SR.ZLibErrorDLLLoadError, cause);
                    }
                    switch(errC)
                    {
                        case 0/*ZErrorCode.Ok*/:
                        return this;
                        case -4/*ZErrorCode.MemError*/:
                        throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorNotEnoughMemory, "deflateInit2_", errC, this._zlibStream.GetErrorMessage());
                        case -6/*ZErrorCode.VersionError*/:
                        throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorVersionMismatch, "deflateInit2_", errC, this._zlibStream.GetErrorMessage());
                        case -2/*ZErrorCode.StreamError*/:
                        throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorIncorrectInitParameters, "deflateInit2_", errC, this._zlibStream.GetErrorMessage());
                        default:
                        throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorUnexpected, "deflateInit2_", errC, this._zlibStream.GetErrorMessage());
                    }
                }
                return this;
            }
            $dtor()
            {
                this.Dispose$1(false);
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this._isDisposed)
                {
                    if (disposing)
                    {
                        this._zlibStream.Dispose();
                    }
                    this.DeallocateInputBufferHandle();
                    this._isDisposed = true;
                }
            }
            /*bool */ NeedsInput()
            {
                return 0 === this._zlibStream.AvailIn;
            }
            /*void */ SetInput(/*ReadOnlyMemory<byte>*/ inputBuffer)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.NeedsInput(), "We have something left in previous input!");
                $.$spc.System.Diagnostics.Debug.Assert$1(!inputBuffer.IsEmpty, "!inputBuffer.IsEmpty");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        this._inputBufferHandle = inputBuffer.Pin();
                        this._zlibStream.NextIn = $.$spc.System.IntPtr.op_Explicit$2(this._inputBufferHandle.Pointer);
                        this._zlibStream.AvailIn = (inputBuffer.Length >>> 0);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*void */ SetInput$1(/*byte**/ inputBufferPtr, /*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.NeedsInput(), "We have something left in previous input!");
                $.$spc.System.Diagnostics.Debug.Assert$1(inputBufferPtr !== null, "inputBufferPtr != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        this._zlibStream.NextIn = $.$cast(inputBufferPtr, $.$spc.System.IntPtr);
                        this._zlibStream.AvailIn = (count >>> 0);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*int */ GetDeflateOutput(/*byte[]*/ outputBuffer)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(null !== outputBuffer, "Can't pass in a null output buffer!");
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.NeedsInput(), "GetDeflateOutput should only be called after providing input");
                try
                {
                    /*int*/ let bytesRead;
                    this.ReadDeflateOutput(outputBuffer, 0/*ZFlushCode.NoFlush*/, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32));
                    return bytesRead;
                }
                finally
                {
                    {
                        if (0 === this._zlibStream.AvailIn)
                        {
                            this.DeallocateInputBufferHandle();
                        }
                    }
                }
            }
            /*ZErrorCode */ ReadDeflateOutput(/*byte[]*/ outputBuffer, /*ZFlushCode*/ flushCode, /*out int*/ bytesRead)
            {
                const $t1 = outputBuffer;
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Int32.op_GreaterThan$1($.$ifnn($t1, ($t) => $t.length), 0), "outputBuffer?.Length > 0");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        /*fixed*/ 
                        {
                            /*byte**/ let bufPtr = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$spc.System.Byte, outputBuffer, 0, false, true);
                            this._zlibStream.NextOut = $.$cast(bufPtr, $.$spc.System.IntPtr);
                            this._zlibStream.AvailOut = (outputBuffer.length >>> 0);
                            /*ZErrorCode*/ let errC = this.Deflate(flushCode);
                            bytesRead.$v = ((outputBuffer.length - (this._zlibStream.AvailOut | 0)) | 0);
                            return errC;
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*bool */ Finish(/*byte[]*/ outputBuffer, /*out int*/ bytesRead)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(null !== outputBuffer, "Can't pass in a null output buffer!");
                $.$spc.System.Diagnostics.Debug.Assert$1(outputBuffer.length > 0, "Can't pass in an empty output buffer!");
                /*ZErrorCode*/ let errC = this.ReadDeflateOutput(outputBuffer, 4/*ZFlushCode.Finish*/, bytesRead);
                return errC === 1/*ZErrorCode.StreamEnd*/;
            }
            /*bool */ Flush(/*byte[]*/ outputBuffer, /*out int*/ bytesRead)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(null !== outputBuffer, "Can't pass in a null output buffer!");
                $.$spc.System.Diagnostics.Debug.Assert$1(outputBuffer.length > 0, "Can't pass in an empty output buffer!");
                $.$spc.System.Diagnostics.Debug.Assert$1(this.NeedsInput(), "We have something left in previous input!");
                return this.ReadDeflateOutput(outputBuffer, 2/*ZFlushCode.SyncFlush*/, bytesRead) === 0/*ZErrorCode.Ok*/;
            }
            /*void */ DeallocateInputBufferHandle()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        this._zlibStream.AvailIn = 0;
                        this._zlibStream.NextIn = $.$sic.System.IO.Compression.ZLibNative.ZNullPtr;
                        this._inputBufferHandle.Dispose();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*ZErrorCode */ Deflate(/*ZFlushCode*/ flushCode)
            {
                /*ZErrorCode*/ let errC;
                try
                {
                    errC = this._zlibStream.Deflate(flushCode);
                }
                catch(cause)
                {
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$16($.$sic.System.SR.ZLibErrorDLLLoadError, cause);
                }
                switch(errC)
                {
                    case 0/*ZErrorCode.Ok*/:
                    case 1/*ZErrorCode.StreamEnd*/:
                    return errC;
                    case -5/*ZErrorCode.BufError*/:
                    return errC;
                    case -2/*ZErrorCode.StreamError*/:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorInconsistentStream, "deflate", errC, this._zlibStream.GetErrorMessage());
                    default:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorUnexpected, "deflate", errC, this._zlibStream.GetErrorMessage());
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._inputBufferHandle = $.$default($.$spc.System.Buffers.MemoryHandle);
                $.$finalizer(this);
            }
            static $h = 1021307;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":30065792379,"f":2},"n":"SyncLock","d":1021307,"h":25770825083,"f":2}],"m":[{"r":65537,"n":"Dispose","d":1021307,"h":42950694267,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1021307,"h":47245661563,"f":2},{"r":262145,"n":"NeedsInput","d":1021307,"h":51540628859,"f":1},{"r":65537,"p":[{"n":"inputBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h}],"n":"SetInput","d":1021307,"h":55835596155,"f":8},{"r":65537,"p":[{"n":"inputBufferPtr","p":0},{"n":"count","p":655361}],"n":"SetInput","o":"@$1","d":1021307,"h":60130563451,"f":8},{"r":655361,"p":[{"n":"outputBuffer","p":0}],"n":"GetDeflateOutput","d":1021307,"h":64425530747,"f":8},{"r":4953467,"p":[{"n":"outputBuffer","p":0},{"n":"flushCode","p":5019003},{"n":"bytesRead","p":655361,"f":2}],"n":"ReadDeflateOutput","d":1021307,"h":68720498043,"f":2},{"r":262145,"p":[{"n":"outputBuffer","p":0},{"n":"bytesRead","p":655361,"f":2}],"n":"Finish","d":1021307,"h":73015465339,"f":8},{"r":262145,"p":[{"n":"outputBuffer","p":0},{"n":"bytesRead","p":655361,"f":2}],"n":"Flush","d":1021307,"h":77310432635,"f":8},{"r":65537,"n":"DeallocateInputBufferHandle","d":1021307,"h":81605399931,"f":2},{"r":4953467,"p":[{"n":"flushCode","p":5019003}],"n":"Deflate","d":1021307,"h":85900367227,"f":2}],"l":[{"t":5084539,"n":"_zlibStream","d":1021307,"h":4295988603,"f":2},{"t":18415617,"n":"_inputBufferHandle","d":1021307,"h":8590955899,"f":2},{"t":262145,"n":"_isDisposed","d":1021307,"h":12885923195,"f":2},{"t":655361,"n":"minWindowBits","d":1021307,"h":17180890491,"f":34},{"t":655361,"n":"maxWindowBits","d":1021307,"h":21475857787,"f":34}],"c":[{"p":[{"n":"compressionLevel","p":4756859},{"n":"strategy","p":4887931},{"n":"windowBits","p":655361},{"n":"memLevel","p":655361}],"n":".ctor","o":"$ctor$1","d":1021307,"h":34360759675,"f":8}],"i":[57475073],"h":1021307}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.Compression.Deflater`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.Inflater", ($self) => class Inflater extends $.$spc.System.Object
        {
            /*int*/ static MinWindowBits = -15;
            /*int*/ static MaxWindowBits = 47;
            /*bool*/ _nonEmptyInput = false;
            /*bool*/ _finished = false;
            /*bool*/ _isDisposed = false;
            /*int*/ _windowBits = 0;
            /*ZLibNative.ZLibStreamHandle*/ _zlibStream = null;
            /*MemoryHandle*/ _inputBufferHandle;
            /*long*/ _uncompressedSize = 0n;
            /*long*/ _currentInflatedCount = 0n;
            /*object */ get SyncLock()
            {
                return this;
            }
            $ctor$1(/*int*/ windowBits, /*long*/ uncompressedSize)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(windowBits >= -15/*MinWindowBits*/ && windowBits <= 47/*MaxWindowBits*/, "windowBits >= MinWindowBits && windowBits <= MaxWindowBits");
                    this._finished = false;
                    this._nonEmptyInput = false;
                    this._isDisposed = false;
                    this._windowBits = windowBits;
                    this.InflateInit(windowBits);
                    this._uncompressedSize = uncompressedSize;
                }
                return this;
            }
            /*int */ get AvailableOutput()
            {
                return (this._zlibStream.AvailOut | 0);
            }
            /*bool */ Finished()
            {
                return this._finished;
            }
            /*bool */ Inflate(/*out byte*/ b)
            {
                /*fixed*/ 
                {
                    /*byte**/ let bufPtr = b;
                    /*int*/ let bytesRead = this.InflateVerified(bufPtr, 1);
                    $.$spc.System.Diagnostics.Debug.Assert$1(bytesRead === 0 || bytesRead === 1, "bytesRead == 0 || bytesRead == 1");
                    return bytesRead !== 0;
                }
            }
            /*int */ Inflate$1(/*byte[]*/ bytes, /*int*/ offset, /*int*/ length)
            {
                if (length === 0)
                {
                    return 0;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(null !== bytes, "Can't pass in a null output buffer!");
                /*fixed*/ 
                {
                    /*byte**/ let bufPtr = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$spc.System.Byte, bytes, null, false, true);
                    return this.InflateVerified(bufPtr.Add(offset), length);
                }
            }
            /*int */ Inflate$2(/*Span<byte>*/ destination)
            {
                if (destination.Length === 0)
                {
                    return 0;
                }
                /*fixed*/ 
                {
                    /*byte**/ let bufPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, destination);
                    return this.InflateVerified(bufPtr, destination.Length);
                }
            }
            /*int */ InflateVerified(/*byte**/ bufPtr, /*int*/ length)
            {
                try
                {
                    /*int*/ let bytesRead = 0;
                    if (this._uncompressedSize === BigInt(-1))
                    {
                        this.ReadOutput(bufPtr, length, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32));
                    }
                    else 
                    {
                        if (this._uncompressedSize > this._currentInflatedCount)
                        {
                            length = $.$cast($.$spc.System.Math.Min$5(BigInt(length), this._uncompressedSize - this._currentInflatedCount), $.$spc.System.Int32);
                            this.ReadOutput(bufPtr, length, $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32));
                            this._currentInflatedCount += BigInt(bytesRead);
                        }
                        else 
                        {
                            this._finished = true;
                            this._zlibStream.AvailIn = 0;
                        }
                    }
                    return bytesRead;
                }
                finally
                {
                    {
                        if (0 === this._zlibStream.AvailIn && this.IsInputBufferHandleAllocated)
                        {
                            this.DeallocateInputBufferHandle();
                        }
                    }
                }
            }
            /*void */ ReadOutput(/*byte**/ bufPtr, /*int*/ length, /*out int*/ bytesRead)
            {
                if (this.ReadInflateOutput(bufPtr, length, 0/*ZLibNative.FlushCode.NoFlush*/, bytesRead) === 1/*ZLibNative.ErrorCode.StreamEnd*/)
                {
                    if (!this.NeedsInput() && this.IsGzipStream() && this.IsInputBufferHandleAllocated)
                    {
                        this._finished = this.ResetStreamForLeftoverInput();
                    }
                    else 
                    {
                        this._finished = true;
                    }
                }
            }
            /*bool */ ResetStreamForLeftoverInput()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.NeedsInput(), "!NeedsInput()");
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsGzipStream(), "IsGzipStream()");
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsInputBufferHandleAllocated, "IsInputBufferHandleAllocated");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        /*byte**/ let nextInPointer = $.$cast(this._zlibStream.NextIn, $.$typePointer($.$spc.System.Byte));
                        /*uint*/ let nextAvailIn = this._zlibStream.AvailIn;
                        if (nextInPointer.$v !== 31/*ZLibNative.GZip_Header_ID1*/ || (nextAvailIn > 1 && (nextInPointer.Add(1)).$v !== 139/*ZLibNative.GZip_Header_ID2*/))
                        {
                            return true;
                        }
                        this._zlibStream.InflateReset2_(this._windowBits);
                        this._finished = false;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
                return false;
            }
            /*bool */ IsGzipStream()
            {
                return this._windowBits >= 24 && this._windowBits <= 31;
            }
            /*bool */ NeedsInput()
            {
                return this._zlibStream.AvailIn === 0;
            }
            /*bool */ NonEmptyInput()
            {
                return this._nonEmptyInput;
            }
            /*void */ SetInput(/*byte[]*/ inputBuffer, /*int*/ startIndex, /*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.NeedsInput(), "We have something left in previous input!");
                $.$spc.System.Diagnostics.Debug.Assert$1(inputBuffer !== null, "inputBuffer != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(startIndex >= 0 && count >= 0 && ((count + startIndex) | 0) <= inputBuffer.length, "startIndex >= 0 && count >= 0 && count + startIndex <= inputBuffer.Length");
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.IsInputBufferHandleAllocated, "!IsInputBufferHandleAllocated");
                this.SetInput$1($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, inputBuffer, startIndex, count)));
            }
            /*void */ SetInput$1(/*ReadOnlyMemory<byte>*/ inputBuffer)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.NeedsInput(), "We have something left in previous input!");
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.IsInputBufferHandleAllocated, "!IsInputBufferHandleAllocated");
                if (inputBuffer.IsEmpty)
                {
                    return;
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        this._inputBufferHandle = inputBuffer.Pin();
                        this._zlibStream.NextIn = $.$spc.System.IntPtr.op_Explicit$2(this._inputBufferHandle.Pointer);
                        this._zlibStream.AvailIn = (inputBuffer.Length >>> 0);
                        this._finished = false;
                        this._nonEmptyInput = true;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                if (!this._isDisposed)
                {
                    if (disposing)
                    {
                        this._zlibStream.Dispose();
                    }
                    if (this.IsInputBufferHandleAllocated)
                    {
                        this.DeallocateInputBufferHandle();
                    }
                    this._isDisposed = true;
                }
            }
            /*void */ Dispose$1()
            {
                this.Dispose(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            $dtor()
            {
                this.Dispose(false);
            }
            /*void */ InflateInit(/*int*/ windowBits)
            {
                /*ZLibNative.ErrorCode*/ let error;
                try
                {
                    error = $.$sic.System.IO.Compression.ZLibNative.CreateZLibStreamForInflate($.$ref(() => this._zlibStream, ($v) => this._zlibStream = $v, $.$sic.System.IO.Compression.ZLibNative.ZLibStreamHandle), windowBits);
                }
                catch(exception)
                {
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$16($.$sic.System.SR.ZLibErrorDLLLoadError, exception);
                }
                switch(error)
                {
                    case 0/*ZLibNative.ErrorCode.Ok*/:
                    return;
                    case -4/*ZLibNative.ErrorCode.MemError*/:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorNotEnoughMemory, "inflateInit2_", error, this._zlibStream.GetErrorMessage());
                    case -6/*ZLibNative.ErrorCode.VersionError*/:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorVersionMismatch, "inflateInit2_", error, this._zlibStream.GetErrorMessage());
                    case -2/*ZLibNative.ErrorCode.StreamError*/:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorIncorrectInitParameters, "inflateInit2_", error, this._zlibStream.GetErrorMessage());
                    default:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorUnexpected, "inflateInit2_", error, this._zlibStream.GetErrorMessage());
                }
            }
            /*ZLibNative.ErrorCode */ ReadInflateOutput(/*byte**/ bufPtr, /*int*/ length, /*ZLibNative.FlushCode*/ flushCode, /*out int*/ bytesRead)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        this._zlibStream.NextOut = $.$cast(bufPtr, $.$spc.System.IntPtr);
                        this._zlibStream.AvailOut = (length >>> 0);
                        /*ZLibNative.ErrorCode*/ let errC = this.Inflate$3(flushCode);
                        bytesRead.$v = ((length - (this._zlibStream.AvailOut | 0)) | 0);
                        return errC;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*ZLibNative.ErrorCode */ Inflate$3(/*ZLibNative.FlushCode*/ flushCode)
            {
                /*ZLibNative.ErrorCode*/ let errC;
                try
                {
                    errC = this._zlibStream.Inflate(flushCode);
                }
                catch(cause)
                {
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$16($.$sic.System.SR.ZLibErrorDLLLoadError, cause);
                }
                switch(errC)
                {
                    case 0/*ZLibNative.ErrorCode.Ok*/:
                    case 1/*ZLibNative.ErrorCode.StreamEnd*/:
                    return errC;
                    case -5/*ZLibNative.ErrorCode.BufError*/:
                    return errC;
                    case -4/*ZLibNative.ErrorCode.MemError*/:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorNotEnoughMemory, "inflate_", errC, this._zlibStream.GetErrorMessage());
                    case -3/*ZLibNative.ErrorCode.DataError*/:
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.UnsupportedCompression);
                    case -2/*ZLibNative.ErrorCode.StreamError*/:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorInconsistentStream, "inflate_", errC, this._zlibStream.GetErrorMessage());
                    default:
                    throw new $.$sic.System.IO.Compression.ZLibException().$ctor$14($.$sic.System.SR.ZLibErrorUnexpected, "inflate_", errC, this._zlibStream.GetErrorMessage());
                }
            }
            /*void */ DeallocateInputBufferHandle()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsInputBufferHandleAllocated, "IsInputBufferHandleAllocated");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncLock)
                    {
                        this._zlibStream.AvailIn = 0;
                        this._zlibStream.NextIn = $.$sic.System.IO.Compression.ZLibNative.ZNullPtr;
                        this._inputBufferHandle.Dispose();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncLock)
                }
            }
            /*bool */ get IsInputBufferHandleAllocated()
            {
                return $.$spc.NetJs.RefOrPointer.Compare(this._inputBufferHandle.Pointer, new $.$typePointer($.$spc.System.Void)()) != 0;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose$1(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._inputBufferHandle = $.$default($.$spc.System.Buffers.MemoryHandle);
                $.$finalizer(this);
            }
            static $h = 1348987;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":51540956539,"f":2},"n":"SyncLock","d":1348987,"h":47245989243,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":64425858427,"f":1},"n":"AvailableOutput","d":1348987,"h":60130891131,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":154620171643,"f":2},"n":"IsInputBufferHandleAllocated","d":1348987,"h":150325204347,"f":2}],"m":[{"r":262145,"n":"Finished","d":1348987,"h":68720825723,"f":1},{"r":262145,"p":[{"n":"b","p":393217,"f":2}],"n":"Inflate","d":1348987,"h":73015793019,"f":1},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"offset","p":655361},{"n":"length","p":655361}],"n":"Inflate","o":"@$1","d":1348987,"h":77310760315,"f":1},{"r":655361,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Inflate","o":"@$2","d":1348987,"h":81605727611,"f":1},{"r":655361,"p":[{"n":"bufPtr","p":0},{"n":"length","p":655361}],"n":"InflateVerified","d":1348987,"h":85900694907,"f":1},{"r":65537,"p":[{"n":"bufPtr","p":0},{"n":"length","p":655361},{"n":"bytesRead","p":655361,"f":2}],"n":"ReadOutput","d":1348987,"h":90195662203,"f":2},{"r":262145,"n":"ResetStreamForLeftoverInput","d":1348987,"h":94490629499,"f":2},{"r":262145,"n":"IsGzipStream","d":1348987,"h":98785596795,"f":8},{"r":262145,"n":"NeedsInput","d":1348987,"h":103080564091,"f":1},{"r":262145,"n":"NonEmptyInput","d":1348987,"h":107375531387,"f":1},{"r":65537,"p":[{"n":"inputBuffer","p":0},{"n":"startIndex","p":655361},{"n":"count","p":655361}],"n":"SetInput","d":1348987,"h":111670498683,"f":1},{"r":65537,"p":[{"n":"inputBuffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h}],"n":"SetInput","o":"@$1","d":1348987,"h":115965465979,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":1348987,"h":120260433275,"f":2},{"r":65537,"n":"Dispose","o":"@$1","d":1348987,"h":124555400571,"f":1},{"r":65537,"p":[{"n":"windowBits","p":655361}],"n":"InflateInit","d":1348987,"h":133145335163,"f":2},{"r":4953467,"p":[{"n":"bufPtr","p":0},{"n":"length","p":655361},{"n":"flushCode","p":5019003},{"n":"bytesRead","p":655361,"f":2}],"n":"ReadInflateOutput","d":1348987,"h":137440302459,"f":2},{"r":4953467,"p":[{"n":"flushCode","p":5019003}],"n":"Inflate","o":"@$3","d":1348987,"h":141735269755,"f":2},{"r":65537,"n":"DeallocateInputBufferHandle","d":1348987,"h":146030237051,"f":2}],"l":[{"t":655361,"n":"MinWindowBits","d":1348987,"h":4296316283,"f":34},{"t":655361,"n":"MaxWindowBits","d":1348987,"h":8591283579,"f":34},{"t":262145,"n":"_nonEmptyInput","d":1348987,"h":12886250875,"f":2},{"t":262145,"n":"_finished","d":1348987,"h":17181218171,"f":2},{"t":262145,"n":"_isDisposed","d":1348987,"h":21476185467,"f":2},{"t":655361,"n":"_windowBits","d":1348987,"h":25771152763,"f":2},{"t":5084539,"n":"_zlibStream","d":1348987,"h":30066120059,"f":2},{"t":18415617,"n":"_inputBufferHandle","d":1348987,"h":34361087355,"f":2},{"t":917505,"n":"_uncompressedSize","d":1348987,"h":38656054651,"f":2},{"t":917505,"n":"_currentInflatedCount","d":1348987,"h":42951021947,"f":2}],"c":[{"p":[{"n":"windowBits","p":655361},{"n":"uncompressedSize","p":917505,"f":65,"v":-1}],"n":".ctor","o":"$ctor$1","d":1348987,"h":55835923835,"f":8}],"i":[57475073],"h":1348987}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.Compression.Inflater`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZipArchive", ($self) => class ZipArchive extends $.$spc.System.Object
        {
            /*Stream*/ _archiveStream = null;
            /*ZipArchiveEntry?*/ _archiveStreamOwner = null;
            /*ZipArchiveMode*/ _mode = 0;
            /*List<ZipArchiveEntry>*/ _entries = null;
            /*ReadOnlyCollection<ZipArchiveEntry>*/ _entriesCollection = null;
            /*Dictionary<string, ZipArchiveEntry>*/ _entriesDictionary = null;
            /*bool*/ _readEntries = false;
            /*bool*/ _leaveOpen = false;
            /*long*/ _centralDirectoryStart = 0n;
            /*bool*/ _isDisposed = false;
            /*uint*/ _numberOfThisDisk = 0;
            /*long*/ _expectedNumberOfEntries = 0n;
            /*Stream?*/ _backingStream = null;
            /*byte[]*/ _archiveComment = null;
            /*Encoding?*/ _entryNameAndCommentEncoding = null;
            /*long*/ _firstDeletedEntryOffset = 0n;
            $ctor$1(/*Stream*/ stream)
            {
                this.$ctor$4(stream, 0/*ZipArchiveMode.Read*/, false, null);
                {
                }
                return this;
            }
            $ctor$2(/*Stream*/ stream, /*ZipArchiveMode*/ mode)
            {
                this.$ctor$4(stream, mode, false, null);
                {
                }
                return this;
            }
            $ctor$3(/*Stream*/ stream, /*ZipArchiveMode*/ mode, /*bool*/ leaveOpen)
            {
                this.$ctor$4(stream, mode, leaveOpen, null);
                {
                }
                return this;
            }
            $ctor$4(/*Stream*/ stream, /*ZipArchiveMode*/ mode, /*bool*/ leaveOpen, /*Encoding?*/ entryNameEncoding)
            {
                this.$ctor$5(mode, leaveOpen, entryNameEncoding, null, $.$sic.System.IO.Compression.ZipArchive.DecideArchiveStream(mode, stream));
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                    /*Stream?*/ let extraTempStream = null;
                    try
                    {
                        this._backingStream = null;
                        if ($.$sic.System.IO.Compression.ZipArchive.ValidateMode(mode, stream))
                        {
                            this._backingStream = stream;
                            extraTempStream = stream = new $.$spc.System.IO.MemoryStream().$ctor$3();
                            this._backingStream.CopyTo(stream);
                            stream.Seek(0n, 0/*SeekOrigin.Begin*/);
                        }
                        this._archiveStream = $.$sic.System.IO.Compression.ZipArchive.DecideArchiveStream(mode, stream);
                        switch(mode)
                        {
                            case 1/*ZipArchiveMode.Create*/:
                            this._readEntries = true;
                            break;
                            case 0/*ZipArchiveMode.Read*/:
                            this.ReadEndOfCentralDirectory();
                            break;
                            case 2/*ZipArchiveMode.Update*/:
                            default:
                            $.$spc.System.Diagnostics.Debug.Assert$1(mode === 2/*ZipArchiveMode.Update*/, "mode == ZipArchiveMode.Update");
                            if (this._archiveStream.Length === 0n)
                            {
                                this._readEntries = true;
                            }
                            else 
                            {
                                this.ReadEndOfCentralDirectory();
                                this.EnsureCentralDirectoryRead();
                                var $en6 = this._entries.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var entry = $en6.Current;
                                    {
                                        entry.ThrowIfNotOpenable(false, true);
                                    }
                                }
                            }
                            break;
                        }
                    }
                    catch($e)
                    {
                        extraTempStream?.Dispose();
                        throw $e;
                    }
                }
                return this;
            }
            $ctor$5(/*ZipArchiveMode*/ mode, /*bool*/ leaveOpen, /*Encoding?*/ entryNameEncoding, /*Stream?*/ backingStream, /*Stream*/ archiveStream)
            {
                super.$ctor();
                {
                    this._backingStream = backingStream;
                    this._archiveStream = archiveStream;
                    this._mode = mode;
                    this.EntryNameAndCommentEncoding = entryNameEncoding;
                    this._archiveStreamOwner = null;
                    this._entries = new ($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor$1();
                    this._entriesCollection = new ($.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor$1(this._entries);
                    this._entriesDictionary = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor$1();
                    this.Changed = 0/*ChangeState.Unchanged*/;
                    this._readEntries = false;
                    this._leaveOpen = leaveOpen;
                    this._centralDirectoryStart = 0n;
                    this._isDisposed = false;
                    this._numberOfThisDisk = 0;
                    this._archiveComment = $.$spc.System.Array.Empty($.$spc.System.Byte);
                    this._firstDeletedEntryOffset = 9223372036854775807n;
                }
                return this;
            }
            /*string */ get Comment()
            {
                return (this.EntryNameAndCommentEncoding ?? $.$spc.System.Text.Encoding.UTF8).GetString$2(this._archiveComment);
            }
            /*string */ set Comment(value)
            {
                this._archiveComment = $.$sic.System.IO.Compression.ZipHelper.GetEncodedTruncatedBytesFromString(value, this.EntryNameAndCommentEncoding, 65535/*ZipEndOfCentralDirectoryBlock.ZipFileCommentMaxLength*/, $.$discardRef());
                this.Changed |= 2/*ChangeState.DynamicLengthMetadata*/;
            }
            /*ReadOnlyCollection<ZipArchiveEntry> */ get Entries()
            {
                if (this._mode === 1/*ZipArchiveMode.Create*/)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.EntriesInCreateMode);
                }
                this.ThrowIfDisposed();
                this.EnsureCentralDirectoryRead();
                return this._entriesCollection;
            }
            /*ZipArchiveMode */ get Mode()
            {
                return this._mode;
            }
            /*ZipArchiveEntry */ CreateEntry(/*string*/ entryName)
            {
                return this.DoCreateEntry(entryName, null);
            }
            /*ZipArchiveEntry */ CreateEntry$1(/*string*/ entryName, /*CompressionLevel*/ compressionLevel)
            {
                return this.DoCreateEntry(entryName, compressionLevel);
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                if (disposing && !this._isDisposed)
                {
                    try
                    {
                        switch(this._mode)
                        {
                            case 0/*ZipArchiveMode.Read*/:
                            break;
                            case 1/*ZipArchiveMode.Create*/:
                            case 2/*ZipArchiveMode.Update*/:
                            default:
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._mode === 2/*ZipArchiveMode.Update*/ || this._mode === 1/*ZipArchiveMode.Create*/, "_mode == ZipArchiveMode.Update || _mode == ZipArchiveMode.Create");
                            this.WriteFile();
                            break;
                        }
                    }
                    finally
                    {
                        {
                            this.CloseStreams();
                            this._isDisposed = true;
                        }
                    }
                }
            }
            /*void */ Dispose$1()
            {
                return this.Dispose(true);
            }
            /*ZipArchiveEntry? */ GetEntry(/*string*/ entryName)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(entryName, "entryName");
                if (this._mode === 1/*ZipArchiveMode.Create*/)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.EntriesInCreateMode);
                }
                this.EnsureCentralDirectoryRead();
                /*ZipArchiveEntry?*/ let result;
                this._entriesDictionary.TryGetValue(entryName, $.$ref(() => result, ($v) => result = $v, $.$sic.System.IO.Compression.ZipArchiveEntry));
                return result;
            }
            /*Stream */ get ArchiveStream()
            {
                return this._archiveStream;
            }
            /*uint */ get NumberOfThisDisk()
            {
                return this._numberOfThisDisk;
            }
            /*Encoding? */ get EntryNameAndCommentEncoding()
            {
                return this._entryNameAndCommentEncoding;
            }
            /*Encoding? */ set EntryNameAndCommentEncoding(value)
            {
                if (value !== null && ($.$spc.System.Text.Encoding.Equals.call(value, $.$spc.System.Text.Encoding.BigEndianUnicode) || $.$spc.System.Text.Encoding.Equals.call(value, $.$spc.System.Text.Encoding.Unicode)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sic.System.SR.EntryNameAndCommentEncodingNotSupported, "EntryNameAndCommentEncoding");
                }
                this._entryNameAndCommentEncoding = value;
            }
            /*ChangeState*/ Changed = 0;
            /*ZipArchiveEntry */ DoCreateEntry(/*string*/ entryName, /*CompressionLevel?*/ compressionLevel)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(entryName, "entryName");
                if (this._mode === 0/*ZipArchiveMode.Read*/)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.CreateInReadMode);
                }
                this.ThrowIfDisposed();
                /*ZipArchiveEntry*/ let entry = $.$spc.System.Nullable$$($.$sic.System.IO.Compression.CompressionLevel).HasValue$get.call(compressionLevel) ? new $.$sic.System.IO.Compression.ZipArchiveEntry().$ctor$2(this, entryName, $.$spc.System.Nullable$$($.$sic.System.IO.Compression.CompressionLevel).Value$get.call(compressionLevel)) : new $.$sic.System.IO.Compression.ZipArchiveEntry().$ctor$3(this, entryName);
                this.AddEntry(entry);
                return entry;
            }
            /*void */ AcquireArchiveStream(/*ZipArchiveEntry*/ entry)
            {
                if (this._archiveStreamOwner !== null)
                {
                    if (!this._archiveStreamOwner.EverOpenedForWrite)
                    {
                        this._archiveStreamOwner.WriteAndFinishLocalEntry(true);
                    }
                    else 
                    {
                        throw new $.$spc.System.IO.IOException().$ctor$10($.$sic.System.SR.CreateModeCreateEntryWhileOpen);
                    }
                }
                this._archiveStreamOwner = entry;
            }
            /*void */ AddEntry(/*ZipArchiveEntry*/ entry)
            {
                this._entries.Add(entry);
                this._entriesDictionary.TryAdd(entry.FullName, entry);
            }
            /*void */ DebugAssertIsStillArchiveStreamOwner(/*ZipArchiveEntry*/ entry)
            {
                return $.$spc.System.Diagnostics.Debug.Assert$1(this._archiveStreamOwner === entry, "_archiveStreamOwner == entry");
            }
            /*void */ ReleaseArchiveStream(/*ZipArchiveEntry*/ entry)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._archiveStreamOwner === entry, "_archiveStreamOwner == entry");
                this._archiveStreamOwner = null;
            }
            /*void */ RemoveEntry(/*ZipArchiveEntry*/ entry)
            {
                this._entries.Remove(entry);
                this._entriesDictionary.Remove(entry.FullName);
                if (entry.OriginallyInArchive && entry.OffsetOfLocalHeader < this._firstDeletedEntryOffset)
                {
                    this._firstDeletedEntryOffset = entry.OffsetOfLocalHeader;
                }
            }
            /*void */ ThrowIfDisposed()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._isDisposed, this);
            }
            /*void */ CloseStreams()
            {
                if (!this._leaveOpen)
                {
                    this._archiveStream.Dispose();
                    this._backingStream?.Dispose();
                }
                else 
                {
                    if (this._backingStream !== null)
                    {
                        this._archiveStream.Dispose();
                    }
                }
            }
            /*void */ EnsureCentralDirectoryRead()
            {
                if (!this._readEntries)
                {
                    this.ReadCentralDirectory();
                    this._readEntries = true;
                }
            }
            /*void */ ReadCentralDirectoryInitialize(/*out byte[]*/ fileBuffer, /*out long*/ numberOfEntries, /*out bool*/ saveExtraFieldsAndComments, /*out bool*/ continueReadingCentralDirectory, /*out int*/ bytesRead, /*out int*/ currPosition, /*out int*/ bytesConsumed)
            {
                /*int*/ let ReadCentralDirectoryReadBufferSize = 4096;
                fileBuffer.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [ReadCentralDirectoryReadBufferSize], null);
                this._archiveStream.Seek(this._centralDirectoryStart, 0/*SeekOrigin.Begin*/);
                numberOfEntries.$v = 0n;
                saveExtraFieldsAndComments.$v = this.Mode === 2/*ZipArchiveMode.Update*/;
                continueReadingCentralDirectory.$v = true;
                bytesRead.$v = 0;
                currPosition.$v = 0;
                bytesConsumed.$v = 0;
                this._entries.Clear();
                this._entriesDictionary.Clear();
            }
            /*bool */ ReadCentralDirectoryEndOfInnerLoopWork(/*bool*/ result, /*ZipCentralDirectoryFileHeader?*/ currentHeader, /*int*/ bytesConsumed, /*ref bool*/ continueReadingCentralDirectory, /*ref long*/ numberOfEntries, /*ref int*/ currPosition, /*ref int*/ bytesRead)
            {
                if (!result)
                {
                    continueReadingCentralDirectory.$v = false;
                    return false;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(currentHeader !== null, "currentHeader should not be null here");
                this.AddEntry(new $.$sic.System.IO.Compression.ZipArchiveEntry().$ctor$1(this, currentHeader));
                numberOfEntries.$v++;
                if (numberOfEntries.$v > this._expectedNumberOfEntries)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.NumEntriesWrong);
                }
                currPosition.$v += bytesConsumed;
                bytesRead.$v += bytesConsumed;
                return true;
            }
            /*void */ ReadCentralDirectoryEndOfOuterLoopWork(/*ref int*/ currPosition, /*ReadOnlySpan<byte>*/ sizedFileBuffer)
            {
                if (currPosition.$v < sizedFileBuffer.Length)
                {
                    this._archiveStream.Seek(BigInt(-(((sizedFileBuffer.Length - currPosition.$v) | 0))), 1/*SeekOrigin.Current*/);
                }
                currPosition.$v = 0;
            }
            /*void */ ReadCentralDirectoryPostOuterLoopWork(/*long*/ numberOfEntries)
            {
                if (numberOfEntries !== this._expectedNumberOfEntries)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.NumEntriesWrong);
                }
                if (this.Mode === 2/*ZipArchiveMode.Update*/)
                {
                    this._entries.Sort$1($.$sic.System.IO.Compression.ZipArchiveEntry.LocalHeaderOffsetComparer.Instance);
                }
            }
            /*void */ ReadCentralDirectory()
            {
                try
                {
                    /*byte[]*/ let fileBuffer;
                    /*long*/ let numberOfEntries;
                    /*bool*/ let saveExtraFieldsAndComments;
                    /*bool*/ let continueReadingCentralDirectory;
                    /*int*/ let bytesRead;
                    /*int*/ let currPosition;
                    /*int*/ let bytesConsumed;
                    this.ReadCentralDirectoryInitialize($.$ref(() => fileBuffer, ($v) => fileBuffer = $v, $.$typeArray($.$spc.System.Byte)), $.$ref(() => numberOfEntries, ($v) => numberOfEntries = $v, $.$spc.System.Int64), $.$ref(() => saveExtraFieldsAndComments, ($v) => saveExtraFieldsAndComments = $v, $.$spc.System.Boolean), $.$ref(() => continueReadingCentralDirectory, ($v) => continueReadingCentralDirectory = $v, $.$spc.System.Boolean), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => currPosition, ($v) => currPosition = $v, $.$spc.System.Int32), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32));
                    /*Span<byte>*/ let fileBufferSpan = $.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Byte, fileBuffer);
                    while(continueReadingCentralDirectory)
                    {
                        /*int*/ let currBytesRead = this._archiveStream.ReadAtLeast(fileBufferSpan, 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/, false);
                        /*ReadOnlySpan<byte>*/ let sizedFileBuffer = $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(fileBufferSpan.Slice$1(0, currBytesRead));
                        continueReadingCentralDirectory = currBytesRead >= 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/;
                        while(((currPosition + 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/) | 0) <= currBytesRead)
                        {
                            /*ZipCentralDirectoryFileHeader?*/ let currentHeader;
                            /*bool*/ let result = $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.TryReadBlock(sizedFileBuffer.Slice(currPosition), this._archiveStream, saveExtraFieldsAndComments, $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32), $.$ref(() => currentHeader, ($v) => currentHeader = $v, $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader));
                            if (!this.ReadCentralDirectoryEndOfInnerLoopWork(result, currentHeader, bytesConsumed, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => continueReadingCentralDirectory, ($v) => continueReadingCentralDirectory = $v, null), $.$ref(() => numberOfEntries, ($v) => numberOfEntries = $v, $.$spc.System.Int64), $.$ref(() => currPosition, ($v) => currPosition = $v, $.$spc.System.Int32), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32)))
                            {
                                break;
                            }
                        }
                        this.ReadCentralDirectoryEndOfOuterLoopWork($.$ref(() => currPosition, ($v) => currPosition = $v, $.$spc.System.Int32), sizedFileBuffer);
                    }
                    this.ReadCentralDirectoryPostOuterLoopWork(numberOfEntries);
                }
                catch(ex)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.Format($.$sic.System.SR.CentralDirectoryInvalid, ex));
                }
            }
            /*void */ ReadEndOfCentralDirectoryInnerWork(/*ZipEndOfCentralDirectoryBlock*/ eocd)
            {
                if (eocd.NumberOfThisDisk !== eocd.NumberOfTheDiskWithTheStartOfTheCentralDirectory)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.SplitSpanned);
                }
                this._numberOfThisDisk = eocd.NumberOfThisDisk;
                this._centralDirectoryStart = BigInt(eocd.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber);
                if (eocd.NumberOfEntriesInTheCentralDirectory !== eocd.NumberOfEntriesInTheCentralDirectoryOnThisDisk)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.SplitSpanned);
                }
                this._expectedNumberOfEntries = BigInt(eocd.NumberOfEntriesInTheCentralDirectory);
                this._archiveComment = eocd.ArchiveComment;
            }
            /*void */ ReadEndOfCentralDirectory()
            {
                try
                {
                    this._archiveStream.Seek(BigInt(-18/*ZipEndOfCentralDirectoryBlock.SizeOfBlockWithoutSignature*/), 2/*SeekOrigin.End*/);
                    if (!$.$sic.System.IO.Compression.ZipHelper.SeekBackwardsToSignature(this._archiveStream, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.SignatureConstantBytes), ((65535/*ZipEndOfCentralDirectoryBlock.ZipFileCommentMaxLength*/ + 4/*ZipEndOfCentralDirectoryBlock.FieldLengths.Signature*/) | 0)))
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.EOCDNotFound);
                    }
                    /*long*/ let eocdStart = this._archiveStream.Position;
                    /*ZipEndOfCentralDirectoryBlock*/ let eocd = $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.ReadBlock(this._archiveStream);
                    this.ReadEndOfCentralDirectoryInnerWork(eocd);
                    this.TryReadZip64EndOfCentralDirectory(eocd, eocdStart);
                    if (this._centralDirectoryStart > this._archiveStream.Length)
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigOffsetToCD);
                    }
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.IO.EndOfStreamException)
                    {
                        let ex = $e;
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$11($.$sic.System.SR.CDCorrupt, ex);
                    }
                    else if ($e instanceof $.$spc.System.IO.IOException)
                    {
                        let ex = $e;
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$11($.$sic.System.SR.CDCorrupt, ex);
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*void */ TryReadZip64EndOfCentralDirectoryInnerInitialWork(/*Zip64EndOfCentralDirectoryLocator?*/ locator)
            {
                if (locator === null || locator.OffsetOfZip64EOCD > 9223372036854775807n)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigOffsetToZip64EOCD);
                }
                /*long*/ let zip64EOCDOffset = $.$cast(locator.OffsetOfZip64EOCD, $.$spc.System.Int64);
                if (zip64EOCDOffset < 0n || zip64EOCDOffset > this._archiveStream.Length)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.InvalidOffsetToZip64EOCD);
                }
                this._archiveStream.Seek(zip64EOCDOffset, 0/*SeekOrigin.Begin*/);
            }
            /*void */ TryReadZip64EndOfCentralDirectoryInnerFinalWork(/*Zip64EndOfCentralDirectoryRecord*/ record)
            {
                this._numberOfThisDisk = record.NumberOfThisDisk;
                if (record.NumberOfEntriesTotal > 9223372036854775807n)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigNumEntries);
                }
                if (record.OffsetOfCentralDirectory > 9223372036854775807n)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigOffsetToCD);
                }
                if (record.NumberOfEntriesTotal !== record.NumberOfEntriesOnThisDisk)
                {
                    throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.SplitSpanned);
                }
                this._expectedNumberOfEntries = $.$cast(record.NumberOfEntriesTotal, $.$spc.System.Int64);
                this._centralDirectoryStart = $.$cast(record.OffsetOfCentralDirectory, $.$spc.System.Int64);
            }
            /*void */ TryReadZip64EndOfCentralDirectory(/*ZipEndOfCentralDirectoryBlock*/ eocd, /*long*/ eocdStart)
            {
                if (eocd.NumberOfThisDisk === 65535/*ZipHelper.Mask16Bit*/ || eocd.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber === 4294967295/*ZipHelper.Mask32Bit*/ || eocd.NumberOfEntriesInTheCentralDirectory === 65535/*ZipHelper.Mask16Bit*/)
                {
                    if (eocdStart < BigInt(20/*Zip64EndOfCentralDirectoryLocator.TotalSize*/))
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.Zip64EOCDNotWhereExpected);
                    }
                    this._archiveStream.Seek(eocdStart - BigInt(16/*Zip64EndOfCentralDirectoryLocator.SizeOfBlockWithoutSignature*/), 0/*SeekOrigin.Begin*/);
                    if ($.$sic.System.IO.Compression.ZipHelper.SeekBackwardsToSignature(this._archiveStream, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.SignatureConstantBytes), 4/*Zip64EndOfCentralDirectoryLocator.FieldLengths.Signature*/))
                    {
                        /*Zip64EndOfCentralDirectoryLocator*/ let locator = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.TryReadBlock(this._archiveStream);
                        this.TryReadZip64EndOfCentralDirectoryInnerInitialWork(locator);
                        /*Zip64EndOfCentralDirectoryRecord*/ let record = $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.TryReadBlock(this._archiveStream);
                        this.TryReadZip64EndOfCentralDirectoryInnerFinalWork(record);
                    }
                }
            }
            static /*void */ WriteFileCalculateOffsets(/*ZipArchiveEntry*/ entry, /*ref long*/ startingOffset, /*ref long*/ nextFileOffset)
            {
                if (entry.Changes === 0/*ChangeState.Unchanged*/)
                {
                    nextFileOffset.$v = $.$spc.System.Math.Max$5(nextFileOffset.$v, entry.GetOffsetOfCompressedData() + entry.CompressedLength);
                }
                else 
                {
                    startingOffset.$v = $.$spc.System.Math.Min$5(startingOffset.$v, entry.OffsetOfLocalHeader);
                }
            }
            static /*void */ WriteFileCheckStartingOffset(/*ZipArchiveEntry*/ entry, /*ref long*/ completeRewriteStartingOffset)
            {
                if ((entry.Changes & (2/*ChangeState.DynamicLengthMetadata*/ | 4/*ChangeState.StoredData*/)) !== 0)
                {
                    completeRewriteStartingOffset.$v = $.$spc.System.Math.Min$5(completeRewriteStartingOffset.$v, entry.OffsetOfLocalHeader);
                }
            }
            /*void */ WriteFileUpdateModeFinalWork(/*long*/ startingOffset, /*long*/ nextFileOffset)
            {
                if (startingOffset === 9223372036854775807n)
                {
                    startingOffset = nextFileOffset;
                }
                this._archiveStream.Seek(startingOffset, 0/*SeekOrigin.Begin*/);
            }
            /*void */ WriteFileFinalWork()
            {
                if (this._mode === 2/*ZipArchiveMode.Update*/ && this._archiveStream.Position !== this._archiveStream.Length)
                {
                    this._archiveStream.SetLength(this._archiveStream.Position);
                }
            }
            /*void */ WriteFile()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._readEntries, "_readEntries");
                /*long*/ let completeRewriteStartingOffset = 0n;
                /*List<ZipArchiveEntry>*/ let entriesToWrite = this._entries;
                if (this._mode === 2/*ZipArchiveMode.Update*/)
                {
                    /*long*/ let startingOffset = this._firstDeletedEntryOffset;
                    /*long*/ let nextFileOffset = 0n;
                    completeRewriteStartingOffset = startingOffset;
                    entriesToWrite = new ($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor$2(this._entries.Count);
                    var $en3 = this._entries.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            if (!entry.OriginallyInArchive)
                            {
                                entriesToWrite.Add(entry);
                            }
                            else 
                            {
                                $.$sic.System.IO.Compression.ZipArchive.WriteFileCalculateOffsets(entry, $.$ref(() => startingOffset, ($v) => startingOffset = $v, $.$spc.System.Int64), $.$ref(() => nextFileOffset, ($v) => nextFileOffset = $v, $.$spc.System.Int64));
                                if (entry.OffsetOfLocalHeader >= startingOffset)
                                {
                                    $.$sic.System.IO.Compression.ZipArchive.WriteFileCheckStartingOffset(entry, $.$ref(() => completeRewriteStartingOffset, ($v) => completeRewriteStartingOffset = $v, $.$spc.System.Int64));
                                    entry.LoadLocalHeaderExtraFieldIfNeeded();
                                    if (entry.OffsetOfLocalHeader >= completeRewriteStartingOffset)
                                    {
                                        entry.LoadCompressedBytesIfNeeded();
                                    }
                                    entriesToWrite.Add(entry);
                                }
                            }
                        }
                    }
                    this.WriteFileUpdateModeFinalWork(startingOffset, nextFileOffset);
                }
                var $en2 = entriesToWrite.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var entry = $en2.Current;
                    {
                        /*bool*/ let forceWriteLocalEntry = !entry.OriginallyInArchive || (entry.OriginallyInArchive && entry.OffsetOfLocalHeader >= completeRewriteStartingOffset);
                        entry.WriteAndFinishLocalEntry(forceWriteLocalEntry);
                    }
                }
                /*long*/ let plannedCentralDirectoryPosition = this._archiveStream.Position;
                /*bool*/ let archiveEpilogueRequiresUpdate = this._entries.Count === 0;
                var $en2 = this._entries.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var entry = $en2.Current;
                    {
                        /*bool*/ let centralDirectoryEntryRequiresUpdate = plannedCentralDirectoryPosition !== this._centralDirectoryStart || !entry.OriginallyInArchive || entry.OffsetOfLocalHeader >= completeRewriteStartingOffset;
                        entry.WriteCentralDirectoryFileHeader(centralDirectoryEntryRequiresUpdate);
                        archiveEpilogueRequiresUpdate = $.$spc.System.Boolean.op_BitwiseOr(archiveEpilogueRequiresUpdate, centralDirectoryEntryRequiresUpdate);
                    }
                }
                /*long*/ let sizeOfCentralDirectory = this._archiveStream.Position - plannedCentralDirectoryPosition;
                this.WriteArchiveEpilogue(plannedCentralDirectoryPosition, sizeOfCentralDirectory, archiveEpilogueRequiresUpdate);
                this.WriteFileFinalWork();
            }
            /*void */ WriteArchiveEpilogueNoCDChangesWork()
            {
                this._archiveStream.Seek(56n, 1/*SeekOrigin.Current*/);
                this._archiveStream.Seek(BigInt(20/*Zip64EndOfCentralDirectoryLocator.TotalSize*/), 1/*SeekOrigin.Current*/);
            }
            /*void */ WriteArchiveEpilogue(/*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory, /*bool*/ centralDirectoryChanged)
            {
                if (startOfCentralDirectory >= BigInt(4294967295/*uint.MaxValue*/) || sizeOfCentralDirectory >= BigInt(4294967295/*uint.MaxValue*/) || this._entries.Count >= 65535/*ZipHelper.Mask16Bit*/)
                {
                    /*long*/ let zip64EOCDRecordStart = this._archiveStream.Position;
                    if (centralDirectoryChanged)
                    {
                        $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.WriteBlock(this._archiveStream, BigInt(this._entries.Count), startOfCentralDirectory, sizeOfCentralDirectory);
                        $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.WriteBlock(this._archiveStream, zip64EOCDRecordStart);
                    }
                    else 
                    {
                        this.WriteArchiveEpilogueNoCDChangesWork();
                    }
                }
                if (centralDirectoryChanged || (this.Changed !== 0/*ChangeState.Unchanged*/))
                {
                    $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.WriteBlock(this._archiveStream, BigInt(this._entries.Count), startOfCentralDirectory, sizeOfCentralDirectory, this._archiveComment);
                }
                else 
                {
                    this._archiveStream.Seek(BigInt(22/*ZipEndOfCentralDirectoryBlock.TotalSize*/ + this._archiveComment.length), 1/*SeekOrigin.Current*/);
                }
            }
            static /*bool */ ValidateMode(/*ZipArchiveMode*/ mode, /*Stream*/ stream)
            {
                /*bool*/ let isReadModeAndUnseekable = false;
                switch(mode)
                {
                    case 1/*ZipArchiveMode.Create*/:
                    if (!stream.CanWrite)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$sic.System.SR.CreateModeCapabilities);
                    }
                    break;
                    case 0/*ZipArchiveMode.Read*/:
                    if (!stream.CanRead)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$sic.System.SR.ReadModeCapabilities);
                    }
                    if (!stream.CanSeek)
                    {
                        isReadModeAndUnseekable = true;
                    }
                    break;
                    case 2/*ZipArchiveMode.Update*/:
                    if (!stream.CanRead || !stream.CanWrite || !stream.CanSeek)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$sic.System.SR.UpdateModeCapabilities);
                    }
                    break;
                    default:
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("mode");
                }
                return isReadModeAndUnseekable;
            }
            static /*Stream */ DecideArchiveStream(/*ZipArchiveMode*/ mode, /*Stream*/ stream)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                return mode === 1/*ZipArchiveMode.Create*/ && !stream.CanSeek ? new $.$sic.System.IO.Compression.PositionPreservingWriteOnlyStreamWrapper().$ctor$3(stream) : stream;
            }
            static $_ChangeState;
            static get ChangeState()
            {
                let $cls = $.$sic.System.IO.Compression.ZipArchive;
                return $cls.$_ChangeState ??= $asm.$nstr("$sic.System.IO.Compression.ZipArchive.ChangeState", ($self) => class ChangeState extends $.$spc.System.Enum
                {
                    static Unchanged = 0;
                    static FixedLengthMetadata = 1;
                    static DynamicLengthMetadata = 2;
                    static StoredData = 4;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Unchanged": 0n,
                            "FixedLengthMetadata": 1n,
                            "DynamicLengthMetadata": 2n,
                            "StoredData": 4n
                        };
                    }
                    static $h = 2594171;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2594171,"n":"Unchanged","d":2594171,"h":4297561467,"f":33},{"t":2594171,"n":"FixedLengthMetadata","d":2594171,"h":8592528763,"f":33},{"t":2594171,"n":"DynamicLengthMetadata","d":2594171,"h":12887496059,"f":33},{"t":2594171,"n":"StoredData","d":2594171,"h":17182463355,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2594171,"h":21477430651,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":2528635,"h":2594171,"a":[{"t":47644673,"c":4342611969}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Compression.ZipArchive.ChangeState`; }
                }, $cls, ($v) => $cls.$_ChangeState = $v);
            }
            static /*Task<ZipArchive> *//*async*/  CreateAsync(/*Stream*/ stream, /*ZipArchiveMode*/ mode, /*bool*/ leaveOpen, /*Encoding?*/ entryNameEncoding, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.ZipArchive), $.$sic.System.IO.Compression.ZipArchive, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                    /*Stream?*/ let extraTempStream = null;
                    try
                    {
                        /*Stream?*/ let backingStream = null;
                        if ($.$sic.System.IO.Compression.ZipArchive.ValidateMode(mode, stream))
                        {
                            backingStream = stream;
                            extraTempStream = stream = new $.$spc.System.IO.MemoryStream().$ctor$3();
                            await backingStream.CopyToAsync$2(stream, cancellationToken).ConfigureAwait(false);
                            stream.Seek(0n, 0/*SeekOrigin.Begin*/);
                        }
                        /*ZipArchive*/ let zipArchive = new $.$sic.System.IO.Compression.ZipArchive().$ctor$5(mode, leaveOpen, entryNameEncoding, backingStream, $.$sic.System.IO.Compression.ZipArchive.DecideArchiveStream(mode, stream));
                        switch(mode)
                        {
                            case 1/*ZipArchiveMode.Create*/:
                            zipArchive._readEntries = true;
                            break;
                            case 0/*ZipArchiveMode.Read*/:
                            await zipArchive.ReadEndOfCentralDirectoryAsync(cancellationToken).ConfigureAwait(false);
                            break;
                            case 2/*ZipArchiveMode.Update*/:
                            default:
                            $.$spc.System.Diagnostics.Debug.Assert$1(mode === 2/*ZipArchiveMode.Update*/, "mode == ZipArchiveMode.Update");
                            if (zipArchive._archiveStream.Length === 0n)
                            {
                                zipArchive._readEntries = true;
                            }
                            else 
                            {
                                await zipArchive.ReadEndOfCentralDirectoryAsync(cancellationToken).ConfigureAwait(false);
                                await zipArchive.EnsureCentralDirectoryReadAsync(cancellationToken).ConfigureAwait(false);
                                var $en6 = zipArchive._entries.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var entry = $en6.Current;
                                    {
                                        await entry.ThrowIfNotOpenableAsync(false, true, cancellationToken).ConfigureAwait(false);
                                    }
                                }
                            }
                            break;
                        }
                        return zipArchive;
                    }
                    catch($e)
                    {
                        if (extraTempStream !== null)
                        {
                            await extraTempStream.DisposeAsync().ConfigureAwait(false);
                        }
                        throw $e;
                    }
                });
            }
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    return await this.DisposeAsyncCore().ConfigureAwait(false);
                });
            }
            /*ValueTask *//*async*/  DisposeAsyncCore()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    if (!this._isDisposed)
                    {
                        try
                        {
                            switch(this._mode)
                            {
                                case 0/*ZipArchiveMode.Read*/:
                                break;
                                case 1/*ZipArchiveMode.Create*/:
                                case 2/*ZipArchiveMode.Update*/:
                                default:
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._mode === 2/*ZipArchiveMode.Update*/ || this._mode === 1/*ZipArchiveMode.Create*/, "_mode == ZipArchiveMode.Update || _mode == ZipArchiveMode.Create");
                                await this.WriteFileAsync(new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                                break;
                            }
                        }
                        finally
                        {
                            {
                                await this.CloseStreamsAsync().ConfigureAwait(false);
                                this._isDisposed = true;
                            }
                        }
                    }
                });
            }
            /*Task *//*async*/  CloseStreamsAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (!this._leaveOpen)
                    {
                        await this._archiveStream.DisposeAsync().ConfigureAwait(false);
                        if (this._backingStream !== null)
                        {
                            await this._backingStream.DisposeAsync().ConfigureAwait(false);
                        }
                    }
                    else 
                    {
                        if (this._backingStream !== null)
                        {
                            await this._archiveStream.DisposeAsync().ConfigureAwait(false);
                        }
                    }
                });
            }
            /*Task *//*async*/  EnsureCentralDirectoryReadAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (!this._readEntries)
                    {
                        await this.ReadCentralDirectoryAsync(cancellationToken).ConfigureAwait(false);
                        this._readEntries = true;
                    }
                });
            }
            /*Task *//*async*/  ReadCentralDirectoryAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    try
                    {
                        /*byte[]*/ let fileBuffer;
                        /*long*/ let numberOfEntries;
                        /*bool*/ let saveExtraFieldsAndComments;
                        /*bool*/ let continueReadingCentralDirectory;
                        /*int*/ let bytesRead;
                        /*int*/ let currPosition;
                        /*int*/ let bytesConsumed;
                        this.ReadCentralDirectoryInitialize($.$ref(() => fileBuffer, ($v) => fileBuffer = $v, $.$typeArray($.$spc.System.Byte)), $.$ref(() => numberOfEntries, ($v) => numberOfEntries = $v, $.$spc.System.Int64), $.$ref(() => saveExtraFieldsAndComments, ($v) => saveExtraFieldsAndComments = $v, $.$spc.System.Boolean), $.$ref(() => continueReadingCentralDirectory, ($v) => continueReadingCentralDirectory = $v, $.$spc.System.Boolean), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32), $.$ref(() => currPosition, ($v) => currPosition = $v, $.$spc.System.Int32), $.$ref(() => bytesConsumed, ($v) => bytesConsumed = $v, $.$spc.System.Int32));
                        while(continueReadingCentralDirectory)
                        {
                            /*int*/ let currBytesRead = await this._archiveStream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(fileBuffer), 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                            /*byte[]*/ let sizedFileBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetSubArray($.$spc.System.Byte, fileBuffer, new $.$spc.System.Range().$ctor$2($.$spc.System.Index.op_Implicit(0), $.$spc.System.Index.op_Implicit(currBytesRead)));
                            continueReadingCentralDirectory = currBytesRead >= 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/;
                            while(((currPosition + 46/*ZipCentralDirectoryFileHeader.BlockConstantSectionSize*/) | 0) <= currBytesRead)
                            {
                                /*bool*/ let result;
        /*ZipCentralDirectoryFileHeader?*/ let currentHeader;
        $.$tupleUnpack(($tp) =>
                                {
                                    result = $tp.Item1;
                                    bytesConsumed = $tp.Item2;
                                    currentHeader = $tp.Item3;
                                }).$v = await $.$sic.System.IO.Compression.ZipCentralDirectoryFileHeader.TryReadBlockAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$6($.$spc.System.Byte, sizedFileBuffer, currPosition)), this._archiveStream, saveExtraFieldsAndComments, cancellationToken).ConfigureAwait$2(false);
                                if (!this.ReadCentralDirectoryEndOfInnerLoopWork(result, currentHeader, bytesConsumed, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => continueReadingCentralDirectory, ($v) => continueReadingCentralDirectory = $v, null), $.$ref(() => numberOfEntries, ($v) => numberOfEntries = $v, $.$spc.System.Int64), $.$ref(() => currPosition, ($v) => currPosition = $v, $.$spc.System.Int32), $.$ref(() => bytesRead, ($v) => bytesRead = $v, $.$spc.System.Int32)))
                                {
                                    break;
                                }
                            }
                            this.ReadCentralDirectoryEndOfOuterLoopWork($.$ref(() => currPosition, ($v) => currPosition = $v, $.$spc.System.Int32), $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(sizedFileBuffer));
                        }
                        this.ReadCentralDirectoryPostOuterLoopWork(numberOfEntries);
                    }
                    catch(ex)
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.Format($.$sic.System.SR.CentralDirectoryInvalid, ex));
                    }
                });
            }
            /*Task *//*async*/  ReadEndOfCentralDirectoryAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    try
                    {
                        this._archiveStream.Seek(BigInt(-18/*ZipEndOfCentralDirectoryBlock.SizeOfBlockWithoutSignature*/), 2/*SeekOrigin.End*/);
                        if (!await $.$sic.System.IO.Compression.ZipHelper.SeekBackwardsToSignatureAsync(this._archiveStream, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit($.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.SignatureConstantBytes), ((65535/*ZipEndOfCentralDirectoryBlock.ZipFileCommentMaxLength*/ + 4/*ZipEndOfCentralDirectoryBlock.FieldLengths.Signature*/) | 0), cancellationToken).ConfigureAwait$2(false))
                        {
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.EOCDNotFound);
                        }
                        /*long*/ let eocdStart = this._archiveStream.Position;
                        /*ZipEndOfCentralDirectoryBlock*/ let eocd = await $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.ReadBlockAsync(this._archiveStream, cancellationToken).ConfigureAwait$2(false);
                        this.ReadEndOfCentralDirectoryInnerWork(eocd);
                        await this.TryReadZip64EndOfCentralDirectoryAsync(eocd, eocdStart, cancellationToken).ConfigureAwait(false);
                        if (this._centralDirectoryStart > this._archiveStream.Length)
                        {
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.FieldTooBigOffsetToCD);
                        }
                    }
                    catch($e)
                    {
                        if ($e instanceof $.$spc.System.IO.EndOfStreamException)
                        {
                            let ex = $e;
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$11($.$sic.System.SR.CDCorrupt, ex);
                        }
                        else if ($e instanceof $.$spc.System.IO.IOException)
                        {
                            let ex = $e;
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$11($.$sic.System.SR.CDCorrupt, ex);
                        }
                        else
                        {
                            throw $e;
                        }
                    }
                });
            }
            /*ValueTask *//*async*/  TryReadZip64EndOfCentralDirectoryAsync(/*ZipEndOfCentralDirectoryBlock*/ eocd, /*long*/ eocdStart, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (eocd.NumberOfThisDisk === 65535/*ZipHelper.Mask16Bit*/ || eocd.OffsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber === 4294967295/*ZipHelper.Mask32Bit*/ || eocd.NumberOfEntriesInTheCentralDirectory === 65535/*ZipHelper.Mask16Bit*/)
                    {
                        if (eocdStart < BigInt(20/*Zip64EndOfCentralDirectoryLocator.TotalSize*/))
                        {
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.Zip64EOCDNotWhereExpected);
                        }
                        this._archiveStream.Seek(eocdStart - BigInt(16/*Zip64EndOfCentralDirectoryLocator.SizeOfBlockWithoutSignature*/), 0/*SeekOrigin.Begin*/);
                        if (await $.$sic.System.IO.Compression.ZipHelper.SeekBackwardsToSignatureAsync(this._archiveStream, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).op_Implicit($.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.SignatureConstantBytes), 4/*Zip64EndOfCentralDirectoryLocator.FieldLengths.Signature*/, cancellationToken).ConfigureAwait$2(false))
                        {
                            /*Zip64EndOfCentralDirectoryLocator*/ let locator = await $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.TryReadBlockAsync(this._archiveStream, cancellationToken).ConfigureAwait$2(false);
                            this.TryReadZip64EndOfCentralDirectoryInnerInitialWork(locator);
                            /*Zip64EndOfCentralDirectoryRecord*/ let record = await $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.TryReadBlockAsync(this._archiveStream, cancellationToken).ConfigureAwait$2(false);
                            this.TryReadZip64EndOfCentralDirectoryInnerFinalWork(record);
                        }
                    }
                });
            }
            /*ValueTask *//*async*/  WriteFileAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readEntries, "_readEntries");
                    /*long*/ let completeRewriteStartingOffset = 0n;
                    /*List<ZipArchiveEntry>*/ let entriesToWrite = this._entries;
                    if (this._mode === 2/*ZipArchiveMode.Update*/)
                    {
                        /*long*/ let startingOffset = this._firstDeletedEntryOffset;
                        /*long*/ let nextFileOffset = 0n;
                        completeRewriteStartingOffset = startingOffset;
                        entriesToWrite = new ($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipArchiveEntry))().$ctor$2(this._entries.Count);
                        var $en4 = this._entries.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var entry = $en4.Current;
                            {
                                if (!entry.OriginallyInArchive)
                                {
                                    entriesToWrite.Add(entry);
                                }
                                else 
                                {
                                    $.$sic.System.IO.Compression.ZipArchive.WriteFileCalculateOffsets(entry, $.$ref(() => startingOffset, ($v) => startingOffset = $v, $.$spc.System.Int64), $.$ref(() => nextFileOffset, ($v) => nextFileOffset = $v, $.$spc.System.Int64));
                                    if (entry.OffsetOfLocalHeader >= startingOffset)
                                    {
                                        $.$sic.System.IO.Compression.ZipArchive.WriteFileCheckStartingOffset(entry, $.$ref(() => completeRewriteStartingOffset, ($v) => completeRewriteStartingOffset = $v, $.$spc.System.Int64));
                                        await entry.LoadLocalHeaderExtraFieldIfNeededAsync(cancellationToken).ConfigureAwait(false);
                                        if (entry.OffsetOfLocalHeader >= completeRewriteStartingOffset)
                                        {
                                            await entry.LoadCompressedBytesIfNeededAsync(cancellationToken).ConfigureAwait(false);
                                        }
                                        entriesToWrite.Add(entry);
                                    }
                                }
                            }
                        }
                        this.WriteFileUpdateModeFinalWork(startingOffset, nextFileOffset);
                    }
                    var $en3 = entriesToWrite.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            /*bool*/ let forceWriteLocalEntry = !entry.OriginallyInArchive || (entry.OriginallyInArchive && entry.OffsetOfLocalHeader >= completeRewriteStartingOffset);
                            await entry.WriteAndFinishLocalEntryAsync(forceWriteLocalEntry, cancellationToken).ConfigureAwait(false);
                        }
                    }
                    /*long*/ let plannedCentralDirectoryPosition = this._archiveStream.Position;
                    /*bool*/ let archiveEpilogueRequiresUpdate = this._entries.Count === 0;
                    var $en3 = this._entries.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            /*bool*/ let centralDirectoryEntryRequiresUpdate = plannedCentralDirectoryPosition !== this._centralDirectoryStart || !entry.OriginallyInArchive || entry.OffsetOfLocalHeader >= completeRewriteStartingOffset;
                            await entry.WriteCentralDirectoryFileHeaderAsync(centralDirectoryEntryRequiresUpdate, cancellationToken).ConfigureAwait(false);
                            archiveEpilogueRequiresUpdate = $.$spc.System.Boolean.op_BitwiseOr(archiveEpilogueRequiresUpdate, centralDirectoryEntryRequiresUpdate);
                        }
                    }
                    /*long*/ let sizeOfCentralDirectory = this._archiveStream.Position - plannedCentralDirectoryPosition;
                    await this.WriteArchiveEpilogueAsync(plannedCentralDirectoryPosition, sizeOfCentralDirectory, archiveEpilogueRequiresUpdate, cancellationToken).ConfigureAwait(false);
                    this.WriteFileFinalWork();
                });
            }
            /*ValueTask *//*async*/  WriteArchiveEpilogueAsync(/*long*/ startOfCentralDirectory, /*long*/ sizeOfCentralDirectory, /*bool*/ centralDirectoryChanged, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (startOfCentralDirectory >= BigInt(4294967295/*uint.MaxValue*/) || sizeOfCentralDirectory >= BigInt(4294967295/*uint.MaxValue*/) || this._entries.Count >= 65535/*ZipHelper.Mask16Bit*/)
                    {
                        /*long*/ let zip64EOCDRecordStart = this._archiveStream.Position;
                        if (centralDirectoryChanged)
                        {
                            await $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryRecord.WriteBlockAsync(this._archiveStream, BigInt(this._entries.Count), startOfCentralDirectory, sizeOfCentralDirectory, cancellationToken).ConfigureAwait(false);
                            await $.$sic.System.IO.Compression.Zip64EndOfCentralDirectoryLocator.WriteBlockAsync(this._archiveStream, zip64EOCDRecordStart, cancellationToken).ConfigureAwait(false);
                        }
                        else 
                        {
                            this.WriteArchiveEpilogueNoCDChangesWork();
                        }
                    }
                    if (centralDirectoryChanged || (this.Changed !== 0/*ChangeState.Unchanged*/))
                    {
                        await $.$sic.System.IO.Compression.ZipEndOfCentralDirectoryBlock.WriteBlockAsync(this._archiveStream, BigInt(this._entries.Count), startOfCentralDirectory, sizeOfCentralDirectory, this._archiveComment, cancellationToken).ConfigureAwait(false);
                    }
                    else 
                    {
                        this._archiveStream.Seek(BigInt(22/*ZipEndOfCentralDirectoryBlock.TotalSize*/ + this._archiveComment.length), 1/*SeekOrigin.Current*/);
                    }
                });
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose$1(...arguments);
            }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Changed = 0;
            }
            static $h = 2528635;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":98786776443,"f":1},"s":{"r":0,"d":0,"h":103081743739,"f":1},"n":"Comment","d":2528635,"h":94491809147,"f":1},{"p":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h,"g":{"r":0,"d":0,"h":111671678331,"f":1},"n":"Entries","d":2528635,"h":107376711035,"f":1},{"p":3052923,"g":{"r":0,"d":0,"h":120261612923,"f":1},"n":"Mode","d":2528635,"h":115966645627,"f":1},{"p":62128129,"g":{"r":0,"d":0,"h":150326383995,"f":8},"n":"ArchiveStream","d":2528635,"h":146031416699,"f":8},{"p":720897,"g":{"r":0,"d":0,"h":158916318587,"f":8},"n":"NumberOfThisDisk","d":2528635,"h":154621351291,"f":8},{"p":121831425,"g":{"r":0,"d":0,"h":167506253179,"f":8},"s":{"r":0,"d":0,"h":171801220475,"f":2},"n":"EntryNameAndCommentEncoding","d":2528635,"h":163211285883,"f":8},{"p":2594171,"g":{"r":0,"d":0,"h":184686122363,"f":8},"s":{"r":0,"d":0,"h":188981089659,"f":2},"n":"Changed","d":2528635,"h":180391155067,"f":8}],"m":[{"r":2659707,"p":[{"n":"entryName","p":1310721}],"n":"CreateEntry","d":2528635,"h":124556580219,"f":1},{"r":2659707,"p":[{"n":"entryName","p":1310721},{"n":"compressionLevel","p":759163}],"n":"CreateEntry","o":"@$1","d":2528635,"h":128851547515,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":2528635,"h":133146514811,"f":132},{"r":65537,"n":"Dispose","o":"@$1","d":2528635,"h":137441482107,"f":1},{"r":2659707,"p":[{"n":"entryName","p":1310721}],"n":"GetEntry","d":2528635,"h":141736449403,"f":1},{"r":2659707,"p":[{"n":"entryName","p":1310721},{"n":"compressionLevel","p":$.$typeNullable($.$sic.System.IO.Compression.CompressionLevel).$h}],"n":"DoCreateEntry","d":2528635,"h":193276056955,"f":2},{"r":65537,"p":[{"n":"entry","p":2659707}],"n":"AcquireArchiveStream","d":2528635,"h":197571024251,"f":8},{"r":65537,"p":[{"n":"entry","p":2659707}],"n":"AddEntry","d":2528635,"h":201865991547,"f":2},{"r":65537,"p":[{"n":"entry","p":2659707}],"n":"DebugAssertIsStillArchiveStreamOwner","d":2528635,"h":206160958843,"f":8,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"DEBUG","t":1310721}]}]},{"r":65537,"p":[{"n":"entry","p":2659707}],"n":"ReleaseArchiveStream","d":2528635,"h":210455926139,"f":8},{"r":65537,"p":[{"n":"entry","p":2659707}],"n":"RemoveEntry","d":2528635,"h":214750893435,"f":8},{"r":65537,"n":"ThrowIfDisposed","d":2528635,"h":219045860731,"f":8},{"r":65537,"n":"CloseStreams","d":2528635,"h":223340828027,"f":2},{"r":65537,"n":"EnsureCentralDirectoryRead","d":2528635,"h":227635795323,"f":2},{"r":65537,"p":[{"n":"fileBuffer","p":0,"f":2},{"n":"numberOfEntries","p":917505,"f":2},{"n":"saveExtraFieldsAndComments","p":262145,"f":2},{"n":"continueReadingCentralDirectory","p":262145,"f":2},{"n":"bytesRead","p":655361,"f":2},{"n":"currPosition","p":655361,"f":2},{"n":"bytesConsumed","p":655361,"f":2}],"n":"ReadCentralDirectoryInitialize","d":2528635,"h":231930762619,"f":2},{"r":262145,"p":[{"n":"result","p":262145},{"n":"currentHeader","p":3118459},{"n":"bytesConsumed","p":655361},{"n":"continueReadingCentralDirectory","p":262145,"f":4},{"n":"numberOfEntries","p":917505,"f":4},{"n":"currPosition","p":655361,"f":4},{"n":"bytesRead","p":655361,"f":4}],"n":"ReadCentralDirectoryEndOfInnerLoopWork","d":2528635,"h":236225729915,"f":2},{"r":65537,"p":[{"n":"currPosition","p":655361,"f":4},{"n":"sizedFileBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"ReadCentralDirectoryEndOfOuterLoopWork","d":2528635,"h":240520697211,"f":2},{"r":65537,"p":[{"n":"numberOfEntries","p":917505}],"n":"ReadCentralDirectoryPostOuterLoopWork","d":2528635,"h":244815664507,"f":2},{"r":65537,"n":"ReadCentralDirectory","d":2528635,"h":249110631803,"f":2},{"r":65537,"p":[{"n":"eocd","p":3315067}],"n":"ReadEndOfCentralDirectoryInnerWork","d":2528635,"h":253405599099,"f":2},{"r":65537,"n":"ReadEndOfCentralDirectory","d":2528635,"h":257700566395,"f":2},{"r":65537,"p":[{"n":"locator","p":1938811}],"n":"TryReadZip64EndOfCentralDirectoryInnerInitialWork","d":2528635,"h":261995533691,"f":2},{"r":65537,"p":[{"n":"record","p":2135419}],"n":"TryReadZip64EndOfCentralDirectoryInnerFinalWork","d":2528635,"h":266290500987,"f":2},{"r":65537,"p":[{"n":"eocd","p":3315067},{"n":"eocdStart","p":917505}],"n":"TryReadZip64EndOfCentralDirectory","d":2528635,"h":270585468283,"f":2},{"r":65537,"p":[{"n":"entry","p":2659707},{"n":"startingOffset","p":917505,"f":4},{"n":"nextFileOffset","p":917505,"f":4}],"n":"WriteFileCalculateOffsets","d":2528635,"h":274880435579,"f":34},{"r":65537,"p":[{"n":"entry","p":2659707},{"n":"completeRewriteStartingOffset","p":917505,"f":4}],"n":"WriteFileCheckStartingOffset","d":2528635,"h":279175402875,"f":34},{"r":65537,"p":[{"n":"startingOffset","p":917505},{"n":"nextFileOffset","p":917505}],"n":"WriteFileUpdateModeFinalWork","d":2528635,"h":283470370171,"f":2},{"r":65537,"n":"WriteFileFinalWork","d":2528635,"h":287765337467,"f":2},{"r":65537,"n":"WriteFile","d":2528635,"h":292060304763,"f":2},{"r":65537,"n":"WriteArchiveEpilogueNoCDChangesWork","d":2528635,"h":296355272059,"f":2},{"r":65537,"p":[{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505},{"n":"centralDirectoryChanged","p":262145}],"n":"WriteArchiveEpilogue","d":2528635,"h":300650239355,"f":2},{"r":262145,"p":[{"n":"mode","p":3052923},{"n":"stream","p":62128129}],"n":"ValidateMode","d":2528635,"h":304945206651,"f":34},{"r":62128129,"p":[{"n":"mode","p":3052923},{"n":"stream","p":62128129}],"n":"DecideArchiveStream","d":2528635,"h":309240173947,"f":34},{"r":$.$spc.System.Threading.Tasks.Task$$($.$sic.System.IO.Compression.ZipArchive).$h,"p":[{"n":"stream","p":62128129},{"n":"mode","p":3052923},{"n":"leaveOpen","p":262145},{"n":"entryNameEncoding","p":121831425},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CreateAsync","d":2528635,"h":317830108539,"f":4129},{"r":136118273,"n":"DisposeAsync","d":2528635,"h":322125075835,"f":4097},{"r":136118273,"n":"DisposeAsyncCore","d":2528635,"h":326420043131,"f":4228},{"r":133300225,"n":"CloseStreamsAsync","d":2528635,"h":330715010427,"f":4098},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"EnsureCentralDirectoryReadAsync","d":2528635,"h":335009977723,"f":4098},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReadCentralDirectoryAsync","d":2528635,"h":339304945019,"f":4098},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReadEndOfCentralDirectoryAsync","d":2528635,"h":343599912315,"f":4098},{"r":136118273,"p":[{"n":"eocd","p":3315067},{"n":"eocdStart","p":917505},{"n":"cancellationToken","p":125960193}],"n":"TryReadZip64EndOfCentralDirectoryAsync","d":2528635,"h":347894879611,"f":4098},{"r":136118273,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteFileAsync","d":2528635,"h":352189846907,"f":4098},{"r":136118273,"p":[{"n":"startOfCentralDirectory","p":917505},{"n":"sizeOfCentralDirectory","p":917505},{"n":"centralDirectoryChanged","p":262145},{"n":"cancellationToken","p":125960193}],"n":"WriteArchiveEpilogueAsync","d":2528635,"h":356484814203,"f":4098}],"l":[{"t":62128129,"n":"_archiveStream","d":2528635,"h":4297495931,"f":2},{"t":2659707,"n":"_archiveStreamOwner","d":2528635,"h":8592463227,"f":2},{"t":3052923,"n":"_mode","d":2528635,"h":12887430523,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h,"n":"_entries","d":2528635,"h":17182397819,"f":2},{"t":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h,"n":"_entriesCollection","d":2528635,"h":21477365115,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sic.System.IO.Compression.ZipArchiveEntry).$h,"n":"_entriesDictionary","d":2528635,"h":25772332411,"f":2},{"t":262145,"n":"_readEntries","d":2528635,"h":30067299707,"f":2},{"t":262145,"n":"_leaveOpen","d":2528635,"h":34362267003,"f":2},{"t":917505,"n":"_centralDirectoryStart","d":2528635,"h":38657234299,"f":2},{"t":262145,"n":"_isDisposed","d":2528635,"h":42952201595,"f":2},{"t":720897,"n":"_numberOfThisDisk","d":2528635,"h":47247168891,"f":2},{"t":917505,"n":"_expectedNumberOfEntries","d":2528635,"h":51542136187,"f":2},{"t":62128129,"n":"_backingStream","d":2528635,"h":55837103483,"f":2},{"t":0,"n":"_archiveComment","d":2528635,"h":60132070779,"f":2},{"t":121831425,"n":"_entryNameAndCommentEncoding","d":2528635,"h":64427038075,"f":2},{"t":917505,"n":"_firstDeletedEntryOffset","d":2528635,"h":68722005371,"f":2}],"c":[{"p":[{"n":"stream","p":62128129}],"n":".ctor","o":"$ctor$1","d":2528635,"h":73016972667,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"mode","p":3052923}],"n":".ctor","o":"$ctor$2","d":2528635,"h":77311939963,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"mode","p":3052923},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":2528635,"h":81606907259,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"mode","p":3052923},{"n":"leaveOpen","p":262145},{"n":"entryNameEncoding","p":121831425}],"n":".ctor","o":"$ctor$4","d":2528635,"h":85901874555,"f":1},{"p":[{"n":"mode","p":3052923},{"n":"leaveOpen","p":262145},{"n":"entryNameEncoding","p":121831425},{"n":"backingStream","p":62128129},{"n":"archiveStream","p":62128129}],"n":".ctor","o":"$ctor$5","d":2528635,"h":90196841851,"f":2}],"i":[57475073,56885249],"j":[2594171],"h":2528635}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `ZipArchive`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.ZipLocalFileHeader", ($self) => class ZipLocalFileHeader extends $.$spc.System.ValueType
        {
            static /*ReadOnlySpan<byte> */ get DataDescriptorSignatureConstantBytes()
            {
                return this.$cacheDataDescriptorSignatureConstantBytes ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 80, 75, 7, 8 ]);
            }
            static /*ReadOnlySpan<byte> */ get SignatureConstantBytes()
            {
                return this.$cacheSignatureConstantBytes ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 80, 75, 3, 4 ]);
            }
            /*int*/ static SizeOfLocalHeader = 30;
            static /*void */ GetExtraFieldsInitialize(/*Stream*/ stream, /*out int*/ relativeFilenameLengthLocation, /*out int*/ relativeExtraFieldLengthLocation)
            {
                relativeFilenameLengthLocation.$v = ((26/*FieldLocations.FilenameLength*/ - 26/*FieldLocations.FilenameLength*/) | 0);
                relativeExtraFieldLengthLocation.$v = ((28/*FieldLocations.ExtraFieldLength*/ - 26/*FieldLocations.FilenameLength*/) | 0);
                stream.Seek(BigInt(26/*FieldLocations.FilenameLength*/), 1/*SeekOrigin.Current*/);
            }
            static /*void */ GetExtraFieldsCore(/*Span<byte>*/ fixedHeaderBuffer, /*int*/ relativeFilenameLengthLocation, /*int*/ relativeExtraFieldLengthLocation, /*out ushort*/ filenameLength, /*out ushort*/ extraFieldLength)
            {
                let $t1 = fixedHeaderBuffer;
                filenameLength.$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t1.Slice$1(relativeFilenameLengthLocation, $t1.Length - relativeFilenameLengthLocation)));
                let $t2 = fixedHeaderBuffer;
                extraFieldLength.$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t2.Slice$1(relativeExtraFieldLengthLocation, $t2.Length - relativeExtraFieldLengthLocation)));
            }
            static /*List<ZipGenericExtraField> */ GetExtraFieldPostReadWork(/*Span<byte>*/ extraFieldBuffer, /*out byte[]*/ trailingData)
            {
                /*ReadOnlySpan<byte>*/ let trailingDataSpan;
                /*List<ZipGenericExtraField>*/ let list = $.$sic.System.IO.Compression.ZipGenericExtraField.ParseExtraField($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(extraFieldBuffer), $.$ref(() => trailingDataSpan, ($v) => trailingDataSpan = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte)));
                $.$sic.System.IO.Compression.Zip64ExtraField.RemoveZip64Blocks(list);
                trailingData.$v = trailingDataSpan.ToArray();
                return list;
            }
            static /*List<ZipGenericExtraField> */ GetExtraFields(/*Stream*/ stream, /*out byte[]*/ trailingData)
            {
                /*Span<byte>*/ let fixedHeaderBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, ((2/*FieldLengths.FilenameLength*/ + 2/*FieldLengths.ExtraFieldLength*/) | 0), null);
                /*int*/ let relativeFilenameLengthLocation;
                /*int*/ let relativeExtraFieldLengthLocation;
                $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldsInitialize(stream, $.$ref(() => relativeFilenameLengthLocation, ($v) => relativeFilenameLengthLocation = $v, $.$spc.System.Int32), $.$ref(() => relativeExtraFieldLengthLocation, ($v) => relativeExtraFieldLengthLocation = $v, $.$spc.System.Int32));
                stream.ReadExactly(fixedHeaderBuffer);
                /*ushort*/ let filenameLength;
                /*ushort*/ let extraFieldLength;
                $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldsCore(fixedHeaderBuffer, relativeFilenameLengthLocation, relativeExtraFieldLengthLocation, $.$ref(() => filenameLength, ($v) => filenameLength = $v, $.$spc.System.UInt16), $.$ref(() => extraFieldLength, ($v) => extraFieldLength = $v, $.$spc.System.UInt16));
                /*int*/ let StackAllocationThreshold = 512;
                /*byte[]?*/ let arrayPoolBuffer = extraFieldLength > StackAllocationThreshold ? $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(extraFieldLength) : null;
                /*Span<byte>*/ let extraFieldBuffer = extraFieldLength <= StackAllocationThreshold ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, StackAllocationThreshold, null).Slice$1(0, extraFieldLength) : $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, arrayPoolBuffer, 0, extraFieldLength);
                try
                {
                    stream.Seek(BigInt(filenameLength), 1/*SeekOrigin.Current*/);
                    stream.ReadExactly(extraFieldBuffer);
                    return $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldPostReadWork(extraFieldBuffer, trailingData);
                }
                finally
                {
                    {
                        if (arrayPoolBuffer !== null)
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(arrayPoolBuffer, false);
                        }
                    }
                }
            }
            static /*bool */ TrySkipBlockCore(/*Stream*/ stream, /*Span<byte>*/ blockBytes, /*int*/ bytesRead, /*long*/ currPosition)
            {
                if (bytesRead !== 4/*FieldLengths.Signature*/ || !$.$spc.System.MemoryExtensions.SequenceEqual$1($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(blockBytes), $.$sic.System.IO.Compression.ZipLocalFileHeader.SignatureConstantBytes))
                {
                    return false;
                }
                if (stream.Length < currPosition + BigInt(26/*FieldLocations.FilenameLength*/))
                {
                    return false;
                }
                stream.Seek(BigInt(26/*FieldLocations.FilenameLength*/ - 4/*FieldLengths.Signature*/), 1/*SeekOrigin.Current*/);
                $.$spc.System.Diagnostics.Debug.Assert$1(blockBytes.Length === ((2/*FieldLengths.FilenameLength*/ + 2/*FieldLengths.ExtraFieldLength*/) | 0), "blockBytes.Length == FieldLengths.FilenameLength + FieldLengths.ExtraFieldLength");
                return true;
            }
            static /*bool */ TrySkipBlockFinalize(/*Stream*/ stream, /*Span<byte>*/ blockBytes, /*int*/ bytesRead)
            {
                if (bytesRead !== ((2/*FieldLengths.FilenameLength*/ + 2/*FieldLengths.ExtraFieldLength*/) | 0))
                {
                    return false;
                }
                /*int*/ let relativeFilenameLengthLocation = ((26/*FieldLocations.FilenameLength*/ - 26/*FieldLocations.FilenameLength*/) | 0);
                /*int*/ let relativeExtraFieldLengthLocation = ((28/*FieldLocations.ExtraFieldLength*/ - 26/*FieldLocations.FilenameLength*/) | 0);
                let $t1 = blockBytes;
                /*ushort*/ let filenameLength = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t1.Slice$1(relativeFilenameLengthLocation, $t1.Length - relativeFilenameLengthLocation)));
                let $t2 = blockBytes;
                /*ushort*/ let extraFieldLength = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($t2.Slice$1(relativeExtraFieldLengthLocation, $t2.Length - relativeExtraFieldLengthLocation)));
                if (stream.Length < stream.Position + BigInt(filenameLength) + BigInt(extraFieldLength))
                {
                    return false;
                }
                stream.Seek(BigInt(filenameLength + extraFieldLength), 1/*SeekOrigin.Current*/);
                return true;
            }
            static /*bool */ TrySkipBlock(/*Stream*/ stream)
            {
                /*Span<byte>*/ let blockBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 4/*FieldLengths.Signature*/, null);
                /*long*/ let currPosition = stream.Position;
                /*int*/ let bytesRead = stream.ReadAtLeast(blockBytes, blockBytes.Length, false);
                if (!$.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlockCore(stream, blockBytes, bytesRead, currPosition))
                {
                    return false;
                }
                bytesRead = stream.ReadAtLeast(blockBytes, blockBytes.Length, false);
                return $.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlockFinalize(stream, blockBytes, bytesRead);
            }
            static /*Task<(List<ZipGenericExtraField>, byte[] trailingData)> *//*async*/  GetExtraFieldsAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.ValueTuple$$$($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField), $.$typeArray($.$spc.System.Byte))), $.$spc.System.ValueTuple$$$($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField), $.$typeArray($.$spc.System.Byte)), async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let fixedHeaderBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [((2/*FieldLengths.FilenameLength*/ + 2/*FieldLengths.ExtraFieldLength*/) | 0)], null);
                    /*int*/ let relativeFilenameLengthLocation;
                    /*int*/ let relativeExtraFieldLengthLocation;
                    $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldsInitialize(stream, $.$ref(() => relativeFilenameLengthLocation, ($v) => relativeFilenameLengthLocation = $v, $.$spc.System.Int32), $.$ref(() => relativeExtraFieldLengthLocation, ($v) => relativeExtraFieldLengthLocation = $v, $.$spc.System.Int32));
                    await stream.ReadExactlyAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(fixedHeaderBuffer), cancellationToken).ConfigureAwait(false);
                    /*ushort*/ let filenameLength;
                    /*ushort*/ let extraFieldLength;
                    $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldsCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(fixedHeaderBuffer), relativeFilenameLengthLocation, relativeExtraFieldLengthLocation, $.$ref(() => filenameLength, ($v) => filenameLength = $v, $.$spc.System.UInt16), $.$ref(() => extraFieldLength, ($v) => extraFieldLength = $v, $.$spc.System.UInt16));
                    /*byte[]*/ let arrayPoolBuffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(extraFieldLength);
                    /*Memory<byte>*/ let extraFieldBuffer = $.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, arrayPoolBuffer, 0, extraFieldLength);
                    try
                    {
                        stream.Seek(BigInt(filenameLength), 1/*SeekOrigin.Current*/);
                        await stream.ReadExactlyAsync(extraFieldBuffer, cancellationToken).ConfigureAwait(false);
                        /*byte[]*/ let trailingData;
                        /*List<ZipGenericExtraField>*/ let list = $.$sic.System.IO.Compression.ZipLocalFileHeader.GetExtraFieldPostReadWork(extraFieldBuffer.Span, $.$ref(() => trailingData, ($v) => trailingData = $v, $.$typeArray($.$spc.System.Byte)));
                        return new ($.$spc.System.ValueTuple$$$($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField), $.$typeArray($.$spc.System.Byte)))().$ctor$2(list, trailingData);
                    }
                    finally
                    {
                        {
                            if (arrayPoolBuffer !== null)
                            {
                                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(arrayPoolBuffer, false);
                            }
                        }
                    }
                });
            }
            static /*Task<bool> *//*async*/  TrySkipBlockAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*byte[]*/ let blockBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [4/*FieldLengths.Signature*/], null);
                    /*long*/ let currPosition = stream.Position;
                    /*int*/ let bytesRead = await stream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(blockBytes), blockBytes.length, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    if (!$.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlockCore(stream, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockBytes), bytesRead, currPosition))
                    {
                        return false;
                    }
                    bytesRead = await stream.ReadAtLeastAsync($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(blockBytes), blockBytes.length, false, new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    return $.$sic.System.IO.Compression.ZipLocalFileHeader.TrySkipBlockFinalize(stream, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(blockBytes), bytesRead);
                });
            }
            static $_FieldLengths;
            static get FieldLengths()
            {
                let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader;
                return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.FieldLengths", ($self) => class FieldLengths
                {
                    /*int*/ static Signature = 4;
                    /*int*/ static VersionNeededToExtract = 2;
                    /*int*/ static GeneralPurposeBitFlags = 2;
                    /*int*/ static CompressionMethod = 2;
                    /*int*/ static LastModified = 4;
                    /*int*/ static Crc32 = 4;
                    /*int*/ static CompressedSize = 4;
                    /*int*/ static UncompressedSize = 4;
                    /*int*/ static FilenameLength = 2;
                    /*int*/ static ExtraFieldLength = 2;
                    static $h = 3839355;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":3839355,"h":4298806651,"f":33},{"t":655361,"n":"VersionNeededToExtract","d":3839355,"h":8593773947,"f":33},{"t":655361,"n":"GeneralPurposeBitFlags","d":3839355,"h":12888741243,"f":33},{"t":655361,"n":"CompressionMethod","d":3839355,"h":17183708539,"f":33},{"t":655361,"n":"LastModified","d":3839355,"h":21478675835,"f":33},{"t":655361,"n":"Crc32","d":3839355,"h":25773643131,"f":33},{"t":655361,"n":"CompressedSize","d":3839355,"h":30068610427,"f":33},{"t":655361,"n":"UncompressedSize","d":3839355,"h":34363577723,"f":33},{"t":655361,"n":"FilenameLength","d":3839355,"h":38658545019,"f":33},{"t":655361,"n":"ExtraFieldLength","d":3839355,"h":42953512315,"f":33}],"d":3773819,"h":3839355}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.FieldLengths`; }
                }, $cls, ($v) => $cls.$_FieldLengths = $v);
            }
            static $_ZipDataDescriptor;
            static get ZipDataDescriptor()
            {
                let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader;
                return $cls.$_ZipDataDescriptor ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor", ($self) => class ZipDataDescriptor extends $.$spc.System.Object
                {
                    static $_FieldLengths;
                    static get FieldLengths()
                    {
                        let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor;
                        return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor.FieldLengths", ($self) => class FieldLengths
                        {
                            /*int*/ static Signature = 4;
                            /*int*/ static Crc32 = 4;
                            /*int*/ static CompressedSize = 4;
                            /*int*/ static UncompressedSize = 4;
                            static $h = 4232571;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":4232571,"h":4299199867,"f":33},{"t":655361,"n":"Crc32","d":4232571,"h":8594167163,"f":33},{"t":655361,"n":"CompressedSize","d":4232571,"h":12889134459,"f":33},{"t":655361,"n":"UncompressedSize","d":4232571,"h":17184101755,"f":33}],"d":4167035,"h":4232571}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor.FieldLengths`; }
                        }, $cls, ($v) => $cls.$_FieldLengths = $v);
                    }
                    static $_FieldLocations;
                    static get FieldLocations()
                    {
                        let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor;
                        return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor.FieldLocations", ($self) => class FieldLocations
                        {
                            /*int*/ static Signature = 0;
                            /*int*/ static Crc32 = 4;
                            /*int*/ static CompressedSize = 8;
                            /*int*/ static UncompressedSize = 12;
                            static $h = 4298107;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":4298107,"h":4299265403,"f":33},{"t":655361,"n":"Crc32","d":4298107,"h":8594232699,"f":33},{"t":655361,"n":"CompressedSize","d":4298107,"h":12889199995,"f":33},{"t":655361,"n":"UncompressedSize","d":4298107,"h":17184167291,"f":33}],"d":4167035,"h":4298107}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor.FieldLocations`; }
                        }, $cls, ($v) => $cls.$_FieldLocations = $v);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 4167035;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":4167035,"h":12889068923,"f":1}],"j":[4232571,4298107],"d":3773819,"h":4167035}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.ZipDataDescriptor`; }
                }, $cls, ($v) => $cls.$_ZipDataDescriptor = $v);
            }
            static $_Zip64DataDescriptor;
            static get Zip64DataDescriptor()
            {
                let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader;
                return $cls.$_Zip64DataDescriptor ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor", ($self) => class Zip64DataDescriptor extends $.$spc.System.Object
                {
                    static $_FieldLengths;
                    static get FieldLengths()
                    {
                        let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor;
                        return $cls.$_FieldLengths ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor.FieldLengths", ($self) => class FieldLengths
                        {
                            /*int*/ static Signature = 4;
                            /*int*/ static Crc32 = 4;
                            /*int*/ static CompressedSize = 8;
                            /*int*/ static UncompressedSize = 8;
                            static $h = 4035963;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":4035963,"h":4299003259,"f":33},{"t":655361,"n":"Crc32","d":4035963,"h":8593970555,"f":33},{"t":655361,"n":"CompressedSize","d":4035963,"h":12888937851,"f":33},{"t":655361,"n":"UncompressedSize","d":4035963,"h":17183905147,"f":33}],"d":3970427,"h":4035963}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor.FieldLengths`; }
                        }, $cls, ($v) => $cls.$_FieldLengths = $v);
                    }
                    static $_FieldLocations;
                    static get FieldLocations()
                    {
                        let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor;
                        return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations", ($self) => class FieldLocations
                        {
                            /*int*/ static Signature = 0;
                            /*int*/ static Crc32 = 4;
                            /*int*/ static CompressedSize = 8;
                            /*int*/ static UncompressedSize = 16;
                            static $h = 4101499;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":4101499,"h":4299068795,"f":33},{"t":655361,"n":"Crc32","d":4101499,"h":8594036091,"f":33},{"t":655361,"n":"CompressedSize","d":4101499,"h":12889003387,"f":33},{"t":655361,"n":"UncompressedSize","d":4101499,"h":17183970683,"f":33}],"d":3970427,"h":4101499}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor.FieldLocations`; }
                        }, $cls, ($v) => $cls.$_FieldLocations = $v);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 3970427;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":3970427,"h":12888872315,"f":1}],"j":[4035963,4101499],"d":3773819,"h":3970427}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.Zip64DataDescriptor`; }
                }, $cls, ($v) => $cls.$_Zip64DataDescriptor = $v);
            }
            static $_FieldLocations;
            static get FieldLocations()
            {
                let $cls = $.$sic.System.IO.Compression.ZipLocalFileHeader;
                return $cls.$_FieldLocations ??= $asm.$ncls("$sic.System.IO.Compression.ZipLocalFileHeader.FieldLocations", ($self) => class FieldLocations
                {
                    /*int*/ static Signature = 0;
                    /*int*/ static VersionNeededToExtract = 4;
                    /*int*/ static GeneralPurposeBitFlags = 6;
                    /*int*/ static CompressionMethod = 8;
                    /*int*/ static LastModified = 10;
                    /*int*/ static Crc32 = 14;
                    /*int*/ static CompressedSize = 18;
                    /*int*/ static UncompressedSize = 22;
                    /*int*/ static FilenameLength = 26;
                    /*int*/ static ExtraFieldLength = 28;
                    /*int*/ static DynamicData = 30;
                    static $h = 3904891;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Signature","d":3904891,"h":4298872187,"f":33},{"t":655361,"n":"VersionNeededToExtract","d":3904891,"h":8593839483,"f":33},{"t":655361,"n":"GeneralPurposeBitFlags","d":3904891,"h":12888806779,"f":33},{"t":655361,"n":"CompressionMethod","d":3904891,"h":17183774075,"f":33},{"t":655361,"n":"LastModified","d":3904891,"h":21478741371,"f":33},{"t":655361,"n":"Crc32","d":3904891,"h":25773708667,"f":33},{"t":655361,"n":"CompressedSize","d":3904891,"h":30068675963,"f":33},{"t":655361,"n":"UncompressedSize","d":3904891,"h":34363643259,"f":33},{"t":655361,"n":"FilenameLength","d":3904891,"h":38658610555,"f":33},{"t":655361,"n":"ExtraFieldLength","d":3904891,"h":42953577851,"f":33},{"t":655361,"n":"DynamicData","d":3904891,"h":47248545147,"f":33}],"d":3773819,"h":3904891}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Compression.ZipLocalFileHeader.FieldLocations`; }
                }, $cls, ($v) => $cls.$_FieldLocations = $v);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 3773819;
            static $z = 0;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":8593708411,"f":33},"n":"DataDescriptorSignatureConstantBytes","d":3773819,"h":4298741115,"f":33},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":17183643003,"f":33},"n":"SignatureConstantBytes","d":3773819,"h":12888675707,"f":33}],"m":[{"r":65537,"p":[{"n":"stream","p":62128129},{"n":"relativeFilenameLengthLocation","p":655361,"f":2},{"n":"relativeExtraFieldLengthLocation","p":655361,"f":2}],"n":"GetExtraFieldsInitialize","d":3773819,"h":25773577595,"f":34},{"r":65537,"p":[{"n":"fixedHeaderBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"relativeFilenameLengthLocation","p":655361},{"n":"relativeExtraFieldLengthLocation","p":655361},{"n":"filenameLength","p":589825,"f":2},{"n":"extraFieldLength","p":589825,"f":2}],"n":"GetExtraFieldsCore","d":3773819,"h":30068544891,"f":34},{"r":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h,"p":[{"n":"extraFieldBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"trailingData","p":0,"f":2}],"n":"GetExtraFieldPostReadWork","d":3773819,"h":34363512187,"f":34},{"r":$.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField).$h,"p":[{"n":"stream","p":62128129},{"n":"trailingData","p":0,"f":2}],"n":"GetExtraFields","d":3773819,"h":38658479483,"f":33},{"r":262145,"p":[{"n":"stream","p":62128129},{"n":"blockBytes","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesRead","p":655361},{"n":"currPosition","p":917505}],"n":"TrySkipBlockCore","d":3773819,"h":42953446779,"f":34},{"r":262145,"p":[{"n":"stream","p":62128129},{"n":"blockBytes","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesRead","p":655361}],"n":"TrySkipBlockFinalize","d":3773819,"h":47248414075,"f":34},{"r":262145,"p":[{"n":"stream","p":62128129}],"n":"TrySkipBlock","d":3773819,"h":51543381371,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.ValueTuple$$$($.$spc.System.Collections.Generic.List$$($.$sic.System.IO.Compression.ZipGenericExtraField), $.$typeArray($.$spc.System.Byte))).$h,"p":[{"n":"stream","p":62128129},{"n":"cancellationToken","p":125960193}],"n":"GetExtraFieldsAsync","d":3773819,"h":55838348667,"f":4129},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean).$h,"p":[{"n":"stream","p":62128129},{"n":"cancellationToken","p":125960193}],"n":"TrySkipBlockAsync","d":3773819,"h":60133315963,"f":4129}],"l":[{"t":655361,"n":"SizeOfLocalHeader","d":3773819,"h":21478610299,"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":3773819,"h":81608152443,"f":1}],"j":[3839355,4167035,3970427,3904891],"h":3773819}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `ZipLocalFileHeader`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.WrappedStream", ($self) => class WrappedStream extends $.$spc.System.IO.Stream
        {
            /*Stream*/ _baseStream = null;
            /*bool*/ _closeBaseStream = false;
            /*Action<ZipArchiveEntry?>?*/ _onClosed = null;
            /*ZipArchiveEntry?*/ _zipArchiveEntry = null;
            /*bool*/ _isDisposed = false;
            $ctor$3(/*Stream*/ baseStream, /*bool*/ closeBaseStream)
            {
                this.$ctor$4(baseStream, closeBaseStream, null, null);
                {
                }
                return this;
            }
            $ctor$4(/*Stream*/ baseStream, /*bool*/ closeBaseStream, /*ZipArchiveEntry?*/ entry, /*Action<ZipArchiveEntry?>?*/ onClosed)
            {
                super.$ctor$2();
                {
                    this._baseStream = baseStream;
                    this._closeBaseStream = closeBaseStream;
                    this._onClosed = onClosed;
                    this._zipArchiveEntry = entry;
                    this._isDisposed = false;
                }
                return this;
            }
            $ctor$5(/*Stream*/ baseStream, /*ZipArchiveEntry*/ entry, /*Action<ZipArchiveEntry?>?*/ onClosed)
            {
                this.$ctor$4(baseStream, false, entry, onClosed);
                {
                }
                return this;
            }
            /*long */ get Length()
            {
                this.ThrowIfDisposed();
                return this._baseStream.Length;
            }
            /*long */ get Position()
            {
                this.ThrowIfDisposed();
                return this._baseStream.Position;
            }
            /*long */ set Position(value)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantSeek();
                this._baseStream.Position = value;
            }
            /*bool */ get CanRead()
            {
                return !this._isDisposed && this._baseStream.CanRead;
            }
            /*bool */ get CanSeek()
            {
                return !this._isDisposed && this._baseStream.CanSeek;
            }
            /*bool */ get CanWrite()
            {
                return !this._isDisposed && this._baseStream.CanWrite;
            }
            /*void */ ThrowIfDisposed()
            {
                if (this._isDisposed)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15($.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this)), $.$sic.System.SR.HiddenStreamName);
                }
            }
            /*void */ ThrowIfCantRead()
            {
                if (!this.CanRead)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
                }
            }
            /*void */ ThrowIfCantWrite()
            {
                if (!this.CanWrite)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.WritingNotSupported);
                }
            }
            /*void */ ThrowIfCantSeek()
            {
                if (!this.CanSeek)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
                }
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                return this._baseStream.Read(buffer, offset, count);
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                return this._baseStream.Read$1(buffer);
            }
            /*int */ ReadByte()
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                return this._baseStream.ReadByte();
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                return this._baseStream.ReadAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                return this._baseStream.ReadAsync$2(buffer, cancellationToken);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantSeek();
                return this._baseStream.Seek(offset, origin);
            }
            /*void */ SetLength(/*long*/ value)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantSeek();
                this.ThrowIfCantWrite();
                this._baseStream.SetLength(value);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                this._baseStream.Write(buffer, offset, count);
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ source)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                this._baseStream.Write$1(source);
            }
            /*void */ WriteByte(/*byte*/ value)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                this._baseStream.WriteByte(value);
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                return this._baseStream.WriteAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                return this._baseStream.WriteAsync$2(buffer, cancellationToken);
            }
            /*void */ Flush()
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                this._baseStream.Flush();
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantWrite();
                return this._baseStream.FlushAsync$1(cancellationToken);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing && !this._isDisposed)
                {
                    this._onClosed?.Invoke(this._zipArchiveEntry);
                    if (this._closeBaseStream)
                    {
                        this._baseStream.Dispose();
                    }
                    this._isDisposed = true;
                }
                super.Dispose$1(disposing);
            }
            static $h = 1873275;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":917505,"g":{"r":0,"d":0,"h":42951546235,"f":32769},"n":"Length","d":1873275,"h":38656578939,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":51541480827,"f":32769},"s":{"r":0,"d":0,"h":55836448123,"f":32769},"n":"Position","d":1873275,"h":47246513531,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":64426382715,"f":32769},"n":"CanRead","d":1873275,"h":60131415419,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":73016317307,"f":32769},"n":"CanSeek","d":1873275,"h":68721350011,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":81606251899,"f":32769},"n":"CanWrite","d":1873275,"h":77311284603,"f":32769}],"m":[{"r":65537,"n":"ThrowIfDisposed","d":1873275,"h":85901219195,"f":2},{"r":65537,"n":"ThrowIfCantRead","d":1873275,"h":90196186491,"f":2},{"r":65537,"n":"ThrowIfCantWrite","d":1873275,"h":94491153787,"f":2},{"r":65537,"n":"ThrowIfCantSeek","d":1873275,"h":98786121083,"f":2},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1873275,"h":103081088379,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1873275,"h":107376055675,"f":32769},{"r":655361,"n":"ReadByte","d":1873275,"h":111671022971,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1873275,"h":115965990267,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1873275,"h":120260957563,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1873275,"h":124555924859,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1873275,"h":128850892155,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1873275,"h":133145859451,"f":32769},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1873275,"h":137440826747,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1873275,"h":141735794043,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1873275,"h":146030761339,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1873275,"h":150325728635,"f":32769},{"r":65537,"n":"Flush","d":1873275,"h":154620695931,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1873275,"h":158915663227,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1873275,"h":163210630523,"f":32772}],"l":[{"t":62128129,"n":"_baseStream","d":1873275,"h":4296840571,"f":2},{"t":262145,"n":"_closeBaseStream","d":1873275,"h":8591807867,"f":2},{"t":$.$spc.System.Action$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h,"n":"_onClosed","d":1873275,"h":12886775163,"f":2},{"t":2659707,"n":"_zipArchiveEntry","d":1873275,"h":17181742459,"f":2},{"t":262145,"n":"_isDisposed","d":1873275,"h":21476709755,"f":2}],"c":[{"p":[{"n":"baseStream","p":62128129},{"n":"closeBaseStream","p":262145}],"n":".ctor","o":"$ctor$3","d":1873275,"h":25771677051,"f":8},{"p":[{"n":"baseStream","p":62128129},{"n":"closeBaseStream","p":262145},{"n":"entry","p":2659707},{"n":"onClosed","p":$.$spc.System.Action$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h}],"n":".ctor","o":"$ctor$4","d":1873275,"h":30066644347,"f":2},{"p":[{"n":"baseStream","p":62128129},{"n":"entry","p":2659707},{"n":"onClosed","p":$.$spc.System.Action$$($.$sic.System.IO.Compression.ZipArchiveEntry).$h}],"n":".ctor","o":"$ctor$5","d":1873275,"h":34361611643,"f":8}],"i":[57475073,56885249],"h":1873275}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.WrappedStream`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.DeflateManagedStream", ($self) => class DeflateManagedStream extends $.$spc.System.IO.Stream
        {
            /*int*/ static DefaultBufferSize = 8192;
            /*Stream?*/ _stream = null;
            /*InflaterManaged*/ _inflater = null;
            /*byte[]*/ _buffer = null;
            /*int*/ _asyncOperations = 0;
            $ctor$3(/*Stream*/ stream, /*ZipArchiveEntry.CompressionMethodValues*/ method, /*long*/ uncompressedSize)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                    if (!stream.CanRead)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sic.System.SR.NotSupported_UnreadableStream, "stream");
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(method === 9/*ZipArchiveEntry.CompressionMethodValues.Deflate64*/, "method == ZipArchiveEntry.CompressionMethodValues.Deflate64");
                    this._inflater = new $.$sic.System.IO.Compression.InflaterManaged().$ctor$1(method === 9/*ZipArchiveEntry.CompressionMethodValues.Deflate64*/, uncompressedSize);
                    this._stream = stream;
                    this._buffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [8192/*DefaultBufferSize*/], null);
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                if (this._stream === null)
                {
                    return false;
                }
                return this._stream.CanRead;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ Flush()
            {
                this.EnsureNotDisposed();
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                this.EnsureNotDisposed();
                return cancellationToken.IsCancellationRequested ? $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken) : $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.Read$1(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count));
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                this.EnsureNotDisposed();
                /*int*/ let initialLength = buffer.Length;
                /*int*/ let bytesRead;
                while(true)
                {
                    bytesRead = this._inflater.Inflate(buffer);
                    buffer = buffer.Slice(bytesRead);
                    if (buffer.Length === 0)
                    {
                        break;
                    }
                    if (this._inflater.Finished())
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._inflater.AvailableOutput === 0, "We should have copied all stuff out!");
                        break;
                    }
                    /*int*/ let bytes = this._stream.Read(this._buffer, 0, this._buffer.length);
                    if (bytes <= 0)
                    {
                        break;
                    }
                    else if (bytes > this._buffer.length)
                    {
                        throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData);
                    }
                    this._inflater.SetInput$1(this._buffer, 0, bytes);
                }
                return ((initialLength - buffer.Length) | 0);
            }
            /*int */ ReadByte()
            {
                /*byte*/ let b = 0;
                return this.Read$1(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$5($.$ref(() => b, ($v) => b = $v, $.$spc.System.Byte))) === 1 ? b : -1;
            }
            /*void */ EnsureNotDisposed()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._stream === null, this);
            }
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.ReadAsync$1(buffer, offset, count, $.$spc.System.Threading.CancellationToken.None), asyncCallback, asyncState);
            }
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.End$1($.$spc.System.Int32, asyncResult);
            }
            /*ValueTask<int> */ ReadAsyncInternal(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.ValueTask.FromCanceled$1($.$spc.System.Int32, cancellationToken);
                }
                $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._asyncOperations, ($v) => this._asyncOperations = $v, $.$spc.System.Int32));
                /*bool*/ let startedAsyncWork = false;
                try
                {
                    /*int*/ let bytesRead = this._inflater.Inflate(buffer.Span);
                    if (bytesRead !== 0)
                    {
                        return $.$spc.System.Threading.Tasks.ValueTask.FromResult($.$spc.System.Int32, bytesRead);
                    }
                    if (this._inflater.Finished())
                    {
                        return $.$spc.System.Threading.Tasks.ValueTask.FromResult($.$spc.System.Int32, 0);
                    }
                    /*ValueTask<int>*/ let readTask = this._stream.ReadAsync$2($.$spc.System.MemoryExtensions.AsMemory$5($.$spc.System.Byte, this._buffer), cancellationToken);
                    startedAsyncWork = true;
                    return this.ReadAsyncCore(readTask, buffer, cancellationToken);
                }
                finally
                {
                    {
                        if (!startedAsyncWork)
                        {
                            $.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._asyncOperations, ($v) => this._asyncOperations = $v, $.$spc.System.Int32));
                        }
                    }
                }
            }
            /*ValueTask<int> *//*async*/  ReadAsyncCore(/*ValueTask<int>*/ readTask, /*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                {
                    try
                    {
                        while(true)
                        {
                            /*int*/ let bytesRead = await readTask.ConfigureAwait(false);
                            this.EnsureNotDisposed();
                            if (bytesRead <= 0)
                            {
                                return 0;
                            }
                            else if (bytesRead > this._buffer.length)
                            {
                                throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData);
                            }
                            cancellationToken.ThrowIfCancellationRequested();
                            this._inflater.SetInput$1(this._buffer, 0, bytesRead);
                            bytesRead = this._inflater.Inflate(buffer.Span);
                            if (bytesRead === 0 && !this._inflater.Finished())
                            {
                                readTask = this._stream.ReadAsync$2($.$spc.System.MemoryExtensions.AsMemory$5($.$spc.System.Byte, this._buffer), cancellationToken);
                            }
                            else 
                            {
                                return bytesRead;
                            }
                        }
                    }
                    finally
                    {
                        {
                            $.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._asyncOperations, ($v) => this._asyncOperations = $v, $.$spc.System.Int32));
                        }
                    }
                });
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                if (this._asyncOperations !== 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.InvalidBeginCall);
                }
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                this.EnsureNotDisposed();
                return this.ReadAsyncInternal($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                if (this._asyncOperations !== 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.InvalidBeginCall);
                }
                this.EnsureNotDisposed();
                return this.ReadAsyncInternal(buffer, cancellationToken);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.CannotWriteToDeflateStream);
            }
            /*void */ PurgeBuffers(/*bool*/ disposing)
            {
                if (!disposing)
                {
                    return;
                }
                if (this._stream === null)
                {
                    return;
                }
                this.Flush();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    this.PurgeBuffers(disposing);
                }
                finally
                {
                    {
                        try
                        {
                            if (disposing && this._stream !== null)
                            {
                                this._stream.Dispose();
                            }
                        }
                        finally
                        {
                            {
                                this._stream = null;
                                this._inflater = null;
                                super.Dispose$1(disposing);
                            }
                        }
                    }
                }
            }
            static $h = 955771;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360694139,"f":32769},"n":"CanRead","d":955771,"h":30065726843,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950628731,"f":32769},"n":"CanWrite","d":955771,"h":38655661435,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51540563323,"f":32769},"n":"CanSeek","d":955771,"h":47245596027,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":60130497915,"f":32769},"n":"Length","d":955771,"h":55835530619,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68720432507,"f":32769},"s":{"r":0,"d":0,"h":73015399803,"f":32769},"n":"Position","d":955771,"h":64425465211,"f":32769}],"m":[{"r":65537,"n":"Flush","d":955771,"h":77310367099,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":955771,"h":81605334395,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":955771,"h":85900301691,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":955771,"h":90195268987,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":955771,"h":94490236283,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":955771,"h":98785203579,"f":32769},{"r":655361,"n":"ReadByte","d":955771,"h":103080170875,"f":32769},{"r":65537,"n":"EnsureNotDisposed","d":955771,"h":107375138171,"f":2},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginRead","d":955771,"h":111670105467,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":955771,"h":115965072763,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadAsyncInternal","d":955771,"h":120260040059,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"readTask","p":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h},{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadAsyncCore","d":955771,"h":124555007355,"f":4098},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":955771,"h":128849974651,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":955771,"h":133144941947,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":955771,"h":137439909243,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"PurgeBuffers","d":955771,"h":141734876539,"f":2},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":955771,"h":146029843835,"f":32772}],"l":[{"t":655361,"n":"DefaultBufferSize","d":955771,"h":4295923067,"f":40},{"t":62128129,"n":"_stream","d":955771,"h":8590890363,"f":2},{"t":1414523,"n":"_inflater","d":955771,"h":12885857659,"f":2},{"t":0,"n":"_buffer","d":955771,"h":17180824955,"f":2},{"t":655361,"n":"_asyncOperations","d":955771,"h":21475792251,"f":2}],"c":[{"p":[{"n":"stream","p":62128129},{"n":"method","p":2790779},{"n":"uncompressedSize","p":917505,"f":65,"v":-1}],"n":".ctor","o":"$ctor$3","d":955771,"h":25770759547,"f":8}],"i":[57475073,56885249],"h":955771}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.DeflateManagedStream`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.SubReadStream", ($self) => class SubReadStream extends $.$spc.System.IO.Stream
        {
            /*long*/ _startInSuperStream = 0n;
            /*long*/ _positionInSuperStream = 0n;
            /*long*/ _endInSuperStream = 0n;
            /*Stream*/ _superStream = null;
            /*bool*/ _canRead = false;
            /*bool*/ _isDisposed = false;
            $ctor$3(/*Stream*/ superStream, /*long*/ startPosition, /*long*/ maxLength)
            {
                super.$ctor$2();
                {
                    this._startInSuperStream = startPosition;
                    this._positionInSuperStream = startPosition;
                    this._endInSuperStream = startPosition + maxLength;
                    this._superStream = superStream;
                    this._canRead = true;
                    this._isDisposed = false;
                }
                return this;
            }
            /*long */ get Length()
            {
                this.ThrowIfDisposed();
                return this._endInSuperStream - this._startInSuperStream;
            }
            /*long */ get Position()
            {
                this.ThrowIfDisposed();
                return this._positionInSuperStream - this._startInSuperStream;
            }
            /*long */ set Position(value)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
            }
            /*bool */ get CanRead()
            {
                return this._superStream.CanRead && this._canRead;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*void */ ThrowIfDisposed()
            {
                if (this._isDisposed)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15($.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this)), $.$sic.System.SR.HiddenStreamName);
                }
            }
            /*void */ ThrowIfCantRead()
            {
                if (!this.CanRead)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
                }
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                /*int*/ let origCount = count;
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                if (this._superStream.Position !== this._positionInSuperStream)
                {
                    this._superStream.Seek(this._positionInSuperStream, 0/*SeekOrigin.Begin*/);
                }
                if (this._positionInSuperStream + BigInt(count) > this._endInSuperStream)
                {
                    count = $.$cast((this._endInSuperStream - this._positionInSuperStream), $.$spc.System.Int32);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(count >= 0, "count >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(count <= origCount, "count <= origCount");
                /*int*/ let ret = this._superStream.Read(buffer, offset, count);
                this._positionInSuperStream += BigInt(ret);
                return ret;
            }
            /*int */ Read$1(/*Span<byte>*/ destination)
            {
                /*int*/ let origCount = destination.Length;
                /*int*/ let count = destination.Length;
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                if (this._superStream.Position !== this._positionInSuperStream)
                {
                    this._superStream.Seek(this._positionInSuperStream, 0/*SeekOrigin.Begin*/);
                }
                if (this._positionInSuperStream + BigInt(count) > this._endInSuperStream)
                {
                    count = $.$cast((this._endInSuperStream - this._positionInSuperStream), $.$spc.System.Int32);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(count >= 0, "count >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(count <= origCount, "count <= origCount");
                /*int*/ let ret = this._superStream.Read$1(destination.Slice$1(0, count));
                this._positionInSuperStream += BigInt(ret);
                return ret;
            }
            /*int */ ReadByte()
            {
                /*byte*/ let b = 0;
                return this.Read$1(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$5($.$ref(() => b, ($v) => b = $v, $.$spc.System.Byte))) === 1 ? b : -1;
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.ReadAsync$2(new ($.$spc.System.Memory$$($.$spc.System.Byte))().$ctor$4(buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                this.ThrowIfCantRead();
                return Core.call(this, buffer, cancellationToken);
                /*ValueTask<int>*/ /*async*/  function Core(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                    {
                        if (this._superStream.Position !== this._positionInSuperStream)
                        {
                            this._superStream.Seek(this._positionInSuperStream, 0/*SeekOrigin.Begin*/);
                        }
                        if (this._positionInSuperStream > this._endInSuperStream - BigInt(buffer.Length))
                        {
                            buffer = buffer.Slice$1(0, $.$cast((this._endInSuperStream - this._positionInSuperStream), $.$spc.System.Int32));
                        }
                        /*int*/ let ret = await this._superStream.ReadAsync$2(buffer, cancellationToken).ConfigureAwait(false);
                        this._positionInSuperStream += BigInt(ret);
                        return ret;
                    });
                }
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
            }
            /*void */ SetLength(/*long*/ value)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SetLengthRequiresSeekingAndWriting);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.WritingNotSupported);
            }
            /*void */ Flush()
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.WritingNotSupported);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing && !this._isDisposed)
                {
                    this._canRead = false;
                    this._isDisposed = true;
                }
                super.Dispose$1(disposing);
            }
            static $h = 1807739;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":917505,"g":{"r":0,"d":0,"h":38656513403,"f":32769},"n":"Length","d":1807739,"h":34361546107,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":47246447995,"f":32769},"s":{"r":0,"d":0,"h":51541415291,"f":32769},"n":"Position","d":1807739,"h":42951480699,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60131349883,"f":32769},"n":"CanRead","d":1807739,"h":55836382587,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":68721284475,"f":32769},"n":"CanSeek","d":1807739,"h":64426317179,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":77311219067,"f":32769},"n":"CanWrite","d":1807739,"h":73016251771,"f":32769}],"m":[{"r":65537,"n":"ThrowIfDisposed","d":1807739,"h":81606186363,"f":2},{"r":65537,"n":"ThrowIfCantRead","d":1807739,"h":85901153659,"f":2},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1807739,"h":90196120955,"f":32769},{"r":655361,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1807739,"h":94491088251,"f":32769},{"r":655361,"n":"ReadByte","d":1807739,"h":98786055547,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1807739,"h":103081022843,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1807739,"h":107375990139,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1807739,"h":111670957435,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1807739,"h":115965924731,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1807739,"h":120260892027,"f":32769},{"r":65537,"n":"Flush","d":1807739,"h":124555859323,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1807739,"h":128850826619,"f":32772}],"l":[{"t":917505,"n":"_startInSuperStream","d":1807739,"h":4296775035,"f":2},{"t":917505,"n":"_positionInSuperStream","d":1807739,"h":8591742331,"f":2},{"t":917505,"n":"_endInSuperStream","d":1807739,"h":12886709627,"f":2},{"t":62128129,"n":"_superStream","d":1807739,"h":17181676923,"f":2},{"t":262145,"n":"_canRead","d":1807739,"h":21476644219,"f":2},{"t":262145,"n":"_isDisposed","d":1807739,"h":25771611515,"f":2}],"c":[{"p":[{"n":"superStream","p":62128129},{"n":"startPosition","p":917505},{"n":"maxLength","p":917505}],"n":".ctor","o":"$ctor$3","d":1807739,"h":30066578811,"f":1}],"i":[57475073,56885249],"h":1807739}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.SubReadStream`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.CheckSumAndSizeWriteStream", ($self) => class CheckSumAndSizeWriteStream extends $.$spc.System.IO.Stream
        {
            /*Stream*/ _baseStream = null;
            /*Stream*/ _baseBaseStream = null;
            /*long*/ _position = 0n;
            /*uint*/ _checksum = 0;
            /*bool*/ _leaveOpenOnClose = false;
            /*bool*/ _canWrite = false;
            /*bool*/ _isDisposed = false;
            /*bool*/ _everWritten = false;
            /*long*/ _initialPosition = 0n;
            /*ZipArchiveEntry*/ _zipArchiveEntry = null;
            /*EventHandler?*/ _onClose = null;
            /*Action<long, long, uint, Stream, ZipArchiveEntry, EventHandler?>*/ _saveCrcAndSizes = null;
            $ctor$3(/*Stream*/ baseStream, /*Stream*/ baseBaseStream, /*bool*/ leaveOpenOnClose, /*ZipArchiveEntry*/ entry, /*EventHandler?*/ onClose, /*Action<long, long, uint, Stream, ZipArchiveEntry, EventHandler?>*/ saveCrcAndSizes)
            {
                super.$ctor$2();
                {
                    this._baseStream = baseStream;
                    this._baseBaseStream = baseBaseStream;
                    this._position = 0n;
                    this._checksum = 0;
                    this._leaveOpenOnClose = leaveOpenOnClose;
                    this._canWrite = true;
                    this._isDisposed = false;
                    this._initialPosition = 0n;
                    this._zipArchiveEntry = entry;
                    this._onClose = onClose;
                    this._saveCrcAndSizes = saveCrcAndSizes;
                }
                return this;
            }
            /*long */ get Length()
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
            }
            /*long */ get Position()
            {
                this.ThrowIfDisposed();
                return this._position;
            }
            /*long */ set Position(value)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
            }
            /*bool */ get CanRead()
            {
                return false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return this._canWrite;
            }
            /*void */ ThrowIfDisposed()
            {
                if (this._isDisposed)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15($.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(this)), $.$sic.System.SR.HiddenStreamName);
                }
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.ReadingNotSupported);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SeekingNotSupported);
            }
            /*void */ SetLength(/*long*/ value)
            {
                this.ThrowIfDisposed();
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.SetLengthRequiresSeekingAndWriting);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                this.ThrowIfDisposed();
                $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                if (count === 0)
                {
                    return;
                }
                if (!this._everWritten)
                {
                    this._initialPosition = this._baseBaseStream.Position;
                    this._everWritten = true;
                }
                this._checksum = $.$sic.System.IO.Compression.Crc32Helper.UpdateCrc32(this._checksum, buffer, offset, count);
                this._baseStream.Write(buffer, offset, count);
                this._position += BigInt(count);
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ source)
            {
                this.ThrowIfDisposed();
                $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                if (source.Length === 0)
                {
                    return;
                }
                if (!this._everWritten)
                {
                    this._initialPosition = this._baseBaseStream.Position;
                    this._everWritten = true;
                }
                this._checksum = $.$sic.System.IO.Compression.Crc32Helper.UpdateCrc32$1(this._checksum, source);
                this._baseStream.Write$1(source);
                this._position += BigInt(source.Length);
            }
            /*void */ WriteByte(/*byte*/ value)
            {
                return this.Write$1(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$5($.$ref(() => value, undefined, $.$spc.System.Byte)));
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                return !buffer.IsEmpty ? Core.call(this, buffer, cancellationToken) : new $.$spc.System.Threading.Tasks.ValueTask();
                /*ValueTask*/ /*async*/  function Core(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                    {
                        if (!this._everWritten)
                        {
                            this._initialPosition = this._baseBaseStream.Position;
                            this._everWritten = true;
                        }
                        this._checksum = $.$sic.System.IO.Compression.Crc32Helper.UpdateCrc32$1(this._checksum, buffer.Span);
                        await this._baseStream.WriteAsync$2(buffer, cancellationToken).ConfigureAwait(false);
                        this._position += BigInt(buffer.Length);
                    });
                }
            }
            /*void */ Flush()
            {
                this.ThrowIfDisposed();
                $.$spc.System.Diagnostics.Debug.Assert$1(this.CanWrite, "CanWrite");
                this._baseStream.Flush();
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfDisposed();
                return this._baseStream.FlushAsync$1(cancellationToken);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing && !this._isDisposed)
                {
                    if (!this._everWritten)
                    {
                        this._initialPosition = this._baseBaseStream.Position;
                    }
                    if (!this._leaveOpenOnClose)
                    {
                        this._baseStream.Dispose();
                    }
                    this._saveCrcAndSizes?.Invoke(this._initialPosition, this.Position, this._checksum, this._baseBaseStream, this._zipArchiveEntry, this._onClose);
                    this._isDisposed = true;
                }
                super.Dispose$1(disposing);
            }
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    if (!this._isDisposed)
                    {
                        if (!this._everWritten)
                        {
                            this._initialPosition = this._baseBaseStream.Position;
                        }
                        if (!this._leaveOpenOnClose)
                        {
                            await this._baseStream.DisposeAsync().ConfigureAwait(false);
                        }
                        this._saveCrcAndSizes?.Invoke(this._initialPosition, this.Position, this._checksum, this._baseBaseStream, this._zipArchiveEntry, this._onClose);
                        this._isDisposed = true;
                    }
                    await super.DisposeAsync().ConfigureAwait(false);
                });
            }
            static $h = 693627;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":917505,"g":{"r":0,"d":0,"h":64425203067,"f":32769},"n":"Length","d":693627,"h":60130235771,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":73015137659,"f":32769},"s":{"r":0,"d":0,"h":77310104955,"f":32769},"n":"Position","d":693627,"h":68720170363,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":85900039547,"f":32769},"n":"CanRead","d":693627,"h":81605072251,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":94489974139,"f":32769},"n":"CanSeek","d":693627,"h":90195006843,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":103079908731,"f":32769},"n":"CanWrite","d":693627,"h":98784941435,"f":32769}],"m":[{"r":65537,"n":"ThrowIfDisposed","d":693627,"h":107374876027,"f":2},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":693627,"h":111669843323,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":693627,"h":115964810619,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":693627,"h":120259777915,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":693627,"h":124554745211,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":693627,"h":128849712507,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":693627,"h":133144679803,"f":32769},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":693627,"h":137439647099,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":693627,"h":141734614395,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":693627,"h":146029581691,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":693627,"h":150324548987,"f":32769},{"r":65537,"n":"Flush","d":693627,"h":154619516283,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":693627,"h":158914483579,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":693627,"h":163209450875,"f":32772},{"r":136118273,"n":"DisposeAsync","d":693627,"h":167504418171,"f":36865}],"l":[{"t":62128129,"n":"_baseStream","d":693627,"h":4295660923,"f":2},{"t":62128129,"n":"_baseBaseStream","d":693627,"h":8590628219,"f":2},{"t":917505,"n":"_position","d":693627,"h":12885595515,"f":2},{"t":720897,"n":"_checksum","d":693627,"h":17180562811,"f":2},{"t":262145,"n":"_leaveOpenOnClose","d":693627,"h":21475530107,"f":2},{"t":262145,"n":"_canWrite","d":693627,"h":25770497403,"f":2},{"t":262145,"n":"_isDisposed","d":693627,"h":30065464699,"f":2},{"t":262145,"n":"_everWritten","d":693627,"h":34360431995,"f":2},{"t":917505,"n":"_initialPosition","d":693627,"h":38655399291,"f":2},{"t":2659707,"n":"_zipArchiveEntry","d":693627,"h":42950366587,"f":2},{"t":46989313,"n":"_onClose","d":693627,"h":47245333883,"f":2},{"t":$.$spc.System.Action$$$$$$$($.$spc.System.Int64, $.$spc.System.Int64, $.$spc.System.UInt32, $.$spc.System.IO.Stream, $.$sic.System.IO.Compression.ZipArchiveEntry, $.$spc.System.EventHandler).$h,"n":"_saveCrcAndSizes","d":693627,"h":51540301179,"f":2}],"c":[{"p":[{"n":"baseStream","p":62128129},{"n":"baseBaseStream","p":62128129},{"n":"leaveOpenOnClose","p":262145},{"n":"entry","p":2659707},{"n":"onClose","p":46989313},{"n":"saveCrcAndSizes","p":$.$spc.System.Action$$$$$$$($.$spc.System.Int64, $.$spc.System.Int64, $.$spc.System.UInt32, $.$spc.System.IO.Stream, $.$sic.System.IO.Compression.ZipArchiveEntry, $.$spc.System.EventHandler).$h}],"n":".ctor","o":"$ctor$3","d":693627,"h":55835268475,"f":1}],"i":[57475073,56885249],"h":693627}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.CheckSumAndSizeWriteStream`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.DeflateStream", ($self) => class DeflateStream extends $.$spc.System.IO.Stream
        {
            /*int*/ static DefaultBufferSize = 8192;
            /*Stream*/ _stream = null;
            /*CompressionMode*/ _mode = 0;
            /*bool*/ _leaveOpen = false;
            /*Inflater?*/ _inflater = null;
            /*Deflater?*/ _deflater = null;
            /*byte[]?*/ _buffer = null;
            /*bool*/ _activeAsyncOperation = false;
            /*bool*/ _wroteBytes = false;
            $ctor$3(/*Stream*/ stream, /*CompressionMode*/ mode, /*long*/ uncompressedSize)
            {
                this.$ctor$10(stream, mode, false, -15/*ZLibNative.Deflate_DefaultWindowBits*/, -1n);
                {
                }
                return this;
            }
            $ctor$4(/*Stream*/ stream, /*CompressionMode*/ mode)
            {
                this.$ctor$5(stream, mode, false);
                {
                }
                return this;
            }
            $ctor$5(/*Stream*/ stream, /*CompressionMode*/ mode, /*bool*/ leaveOpen)
            {
                this.$ctor$10(stream, mode, leaveOpen, -15/*ZLibNative.Deflate_DefaultWindowBits*/, -1n);
                {
                }
                return this;
            }
            $ctor$6(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel)
            {
                this.$ctor$7(stream, compressionLevel, false);
                {
                }
                return this;
            }
            $ctor$7(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel, /*bool*/ leaveOpen)
            {
                this.$ctor$11(stream, compressionLevel, leaveOpen, -15/*ZLibNative.Deflate_DefaultWindowBits*/);
                {
                }
                return this;
            }
            $ctor$8(/*Stream*/ stream, /*ZLibCompressionOptions*/ compressionOptions, /*bool*/ leaveOpen)
            {
                this.$ctor$9(stream, compressionOptions, leaveOpen, -15/*ZLibNative.Deflate_DefaultWindowBits*/);
                {
                }
                return this;
            }
            $ctor$9(/*Stream*/ stream, /*ZLibCompressionOptions*/ compressionOptions, /*bool*/ leaveOpen, /*int*/ windowBits)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(compressionOptions, "compressionOptions");
                    this.InitializeDeflater(stream, $.$cast(compressionOptions.CompressionLevel, $.$sic.System.IO.Compression.ZLibNative.CompressionLevel), $.$cast(compressionOptions.CompressionStrategy, $.$sic.System.IO.Compression.ZLibNative.CompressionStrategy), leaveOpen, windowBits);
                }
                return this;
            }
            $ctor$10(/*Stream*/ stream, /*CompressionMode*/ mode, /*bool*/ leaveOpen, /*int*/ windowBits, /*long*/ uncompressedSize)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                    switch(mode)
                    {
                        case 0/*CompressionMode.Decompress*/:
                        if (!stream.CanRead)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$sic.System.SR.NotSupported_UnreadableStream, "stream");
                        }
                        this._inflater = new $.$sic.System.IO.Compression.Inflater().$ctor$1(windowBits, uncompressedSize);
                        this._stream = stream;
                        this._mode = 0/*CompressionMode.Decompress*/;
                        this._leaveOpen = leaveOpen;
                        break;
                        case 1/*CompressionMode.Compress*/:
                        this.InitializeDeflater(stream, -1/*ZLibNative.CompressionLevel.DefaultCompression*/, 0/*CompressionStrategy.DefaultStrategy*/, leaveOpen, windowBits);
                        break;
                        default:
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sic.System.SR.ArgumentOutOfRange_Enum, "mode");
                    }
                }
                return this;
            }
            $ctor$11(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel, /*bool*/ leaveOpen, /*int*/ windowBits)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                    this.InitializeDeflater(stream, $.$sic.System.IO.Compression.DeflateStream.GetZLibNativeCompressionLevel(compressionLevel), 0/*CompressionStrategy.DefaultStrategy*/, leaveOpen, windowBits);
                }
                return this;
            }
            /*void */ InitializeDeflater(/*Stream*/ stream, /*ZLibNative.CompressionLevel*/ compressionLevel, /*CompressionStrategy*/ strategy, /*bool*/ leaveOpen, /*int*/ windowBits)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(stream !== null, "stream != null");
                if (!stream.CanWrite)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sic.System.SR.NotSupported_UnwritableStream, "stream");
                }
                this._deflater = new $.$sic.System.IO.Compression.Deflater().$ctor$1(compressionLevel, strategy, windowBits, $.$sic.System.IO.Compression.DeflateStream.GetMemLevel(compressionLevel));
                this._stream = stream;
                this._mode = 1/*CompressionMode.Compress*/;
                this._leaveOpen = leaveOpen;
                this.InitializeBuffer();
            }
            static /*ZLibNative.CompressionLevel */ GetZLibNativeCompressionLevel(/*CompressionLevel*/ compressionLevel)
            {
                return (() =>
                {
                    if (compressionLevel === 0/*CompressionLevel.Optimal*/)
                    {
                        return -1/*ZLibNative.CompressionLevel.DefaultCompression*/;
                    }
                    if (compressionLevel === 1/*CompressionLevel.Fastest*/)
                    {
                        return 1/*ZLibNative.CompressionLevel.BestSpeed*/;
                    }
                    if (compressionLevel === 2/*CompressionLevel.NoCompression*/)
                    {
                        return 0/*ZLibNative.CompressionLevel.NoCompression*/;
                    }
                    if (compressionLevel === 3/*CompressionLevel.SmallestSize*/)
                    {
                        return 9/*ZLibNative.CompressionLevel.BestCompression*/;
                    }
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("compressionLevel");
                })();
            }
            static /*int */ GetMemLevel(/*ZLibNative.CompressionLevel*/ level)
            {
                return level === 0/*ZLibNative.CompressionLevel.NoCompression*/ ? 7/*Deflate_NoCompressionMemLevel*/ : 8/*Deflate_DefaultMemLevel*/;
            }
            /*void */ InitializeBuffer()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._buffer === null, "_buffer == null");
                this._buffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(8192/*DefaultBufferSize*/);
            }
            /*void */ EnsureBufferInitialized()
            {
                if (this._buffer === null)
                {
                    this.InitializeBuffer();
                }
            }
            /*Stream */ get BaseStream()
            {
                return this._stream;
            }
            /*bool */ get CanRead()
            {
                if (this._stream === null)
                {
                    return false;
                }
                return (this._mode === 0/*CompressionMode.Decompress*/ && this._stream.CanRead);
            }
            /*bool */ get CanWrite()
            {
                if (this._stream === null)
                {
                    return false;
                }
                return (this._mode === 1/*CompressionMode.Compress*/ && this._stream.CanWrite);
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ Flush()
            {
                this.EnsureNotDisposed();
                if (this._mode === 1/*CompressionMode.Compress*/)
                {
                    this.FlushBuffers();
                }
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                this.EnsureNoActiveAsyncOperation();
                this.EnsureNotDisposed();
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this._mode !== 1/*CompressionMode.Compress*/ ? $.$spc.System.Threading.Tasks.Task.CompletedTask : Core.call(this, cancellationToken);
                /*Task*/ /*async*/  function Core(/*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                    {
                        this.AsyncOperationStarting();
                        try
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null && this._buffer !== null, "_deflater != null && _buffer != null");
                            await this.WriteDeflaterOutputAsync(cancellationToken).ConfigureAwait(false);
                            /*bool*/ let flushSuccessful;
                            do
                            {
                                /*int*/ let compressedBytes;
                                flushSuccessful = this._deflater.Flush(this._buffer, $.$ref(() => compressedBytes, ($v) => compressedBytes = $v, $.$spc.System.Int32));
                                if (flushSuccessful)
                                {
                                    await this._stream.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(this._buffer, 0, compressedBytes), cancellationToken).ConfigureAwait(false);
                                }
                                $.$spc.System.Diagnostics.Debug.Assert$1(flushSuccessful === (compressedBytes > 0), "flushSuccessful == (compressedBytes > 0)");
                            }
                            while(flushSuccessful);
                            await this._stream.FlushAsync$1(cancellationToken).ConfigureAwait(false);
                        }
                        finally
                        {
                            {
                                this.AsyncOperationCompleting();
                            }
                        }
                    });
                }
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*int */ ReadByte()
            {
                this.EnsureDecompressionMode();
                this.EnsureNotDisposed();
                /*byte*/ let b;
                $.$spc.System.Diagnostics.Debug.Assert$1(this._inflater !== null, "_inflater != null");
                return this._inflater.Inflate($.$ref(() => b, ($v) => b = $v, $.$spc.System.Byte)) ? b : super.ReadByte();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.ReadCore(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count));
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.DeflateStream.$type))
                {
                    return super.Read$1(buffer);
                }
                else 
                {
                    return this.ReadCore(buffer);
                }
            }
            /*int */ ReadCore(/*Span<byte>*/ buffer)
            {
                this.EnsureDecompressionMode();
                this.EnsureNotDisposed();
                this.EnsureBufferInitialized();
                $.$spc.System.Diagnostics.Debug.Assert$1(this._inflater !== null, "_inflater != null");
                /*int*/ let bytesRead;
                while(true)
                {
                    bytesRead = this._inflater.Inflate$2(buffer);
                    if (bytesRead !== 0 || this.InflatorIsFinished)
                    {
                        break;
                    }
                    if (this._inflater.NeedsInput())
                    {
                        /*int*/ let n = this._stream.Read(this._buffer, 0, this._buffer.length);
                        if (n <= 0)
                        {
                            if ($.$sic.System.IO.Compression.DeflateStream.s_useStrictValidation && !buffer.IsEmpty && !this._inflater.Finished() && this._inflater.NonEmptyInput())
                            {
                                $.$sic.System.IO.Compression.DeflateStream.ThrowTruncatedInvalidData();
                            }
                            break;
                        }
                        else if (n > this._buffer.length)
                        {
                            $.$sic.System.IO.Compression.DeflateStream.ThrowGenericInvalidData();
                        }
                        else 
                        {
                            this._inflater.SetInput(this._buffer, 0, n);
                        }
                    }
                    if (buffer.IsEmpty)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(bytesRead === 0, "bytesRead == 0");
                        break;
                    }
                }
                return bytesRead;
            }
            /*bool */ get InflatorIsFinished()
            {
                return this._inflater.Finished() && (!this._inflater.IsGzipStream() || !this._inflater.NeedsInput());
            }
            /*void */ EnsureNotDisposed()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._stream === null, this);
            }
            /*void */ EnsureDecompressionMode()
            {
                if (this._mode !== 0/*CompressionMode.Decompress*/)
                {
                    ThrowCannotReadFromDeflateStreamException();
                }
                /*static void*/  function ThrowCannotReadFromDeflateStreamException()
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.CannotReadFromDeflateStream);
                }
            }
            /*void */ EnsureCompressionMode()
            {
                if (this._mode !== 1/*CompressionMode.Compress*/)
                {
                    ThrowCannotWriteToDeflateStreamException();
                }
                /*static void*/  function ThrowCannotWriteToDeflateStreamException()
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.CannotWriteToDeflateStream);
                }
            }
            static /*void */ ThrowGenericInvalidData()
            {
                throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData);
            }
            static /*void */ ThrowTruncatedInvalidData()
            {
                throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.TruncatedData);
            }
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.ReadAsync$1(buffer, offset, count, $.$spc.System.Threading.CancellationToken.None), asyncCallback, asyncState);
            }
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                this.EnsureDecompressionMode();
                this.EnsureNotDisposed();
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.End$1($.$spc.System.Int32, asyncResult);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.ReadAsyncMemory(new ($.$spc.System.Memory$$($.$spc.System.Byte))().$ctor$4(buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.DeflateStream.$type))
                {
                    return super.ReadAsync$2(buffer, cancellationToken);
                }
                else 
                {
                    return this.ReadAsyncMemory(buffer, cancellationToken);
                }
            }
            /*ValueTask<int> */ ReadAsyncMemory(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.EnsureDecompressionMode();
                this.EnsureNoActiveAsyncOperation();
                this.EnsureNotDisposed();
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.ValueTask.FromCanceled$1($.$spc.System.Int32, cancellationToken);
                }
                this.EnsureBufferInitialized();
                $.$spc.System.Diagnostics.Debug.Assert$1(this._inflater !== null, "_inflater != null");
                return Core.call(this, buffer, cancellationToken);
                /*ValueTask<int>*/ /*async*/  function Core(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                    {
                        this.AsyncOperationStarting();
                        try
                        {
                            /*int*/ let bytesRead;
                            while(true)
                            {
                                bytesRead = this._inflater.Inflate$2(buffer.Span);
                                if (bytesRead !== 0 || this.InflatorIsFinished)
                                {
                                    break;
                                }
                                if (this._inflater.NeedsInput())
                                {
                                    /*int*/ let n = await this._stream.ReadAsync$2(new ($.$spc.System.Memory$$($.$spc.System.Byte))().$ctor$4(this._buffer, 0, this._buffer.length), cancellationToken).ConfigureAwait(false);
                                    if (n <= 0)
                                    {
                                        if ($.$sic.System.IO.Compression.DeflateStream.s_useStrictValidation && !this._inflater.Finished() && this._inflater.NonEmptyInput() && !buffer.IsEmpty)
                                        {
                                            $.$sic.System.IO.Compression.DeflateStream.ThrowTruncatedInvalidData();
                                        }
                                        break;
                                    }
                                    else if (n > this._buffer.length)
                                    {
                                        $.$sic.System.IO.Compression.DeflateStream.ThrowGenericInvalidData();
                                    }
                                    else 
                                    {
                                        this._inflater.SetInput(this._buffer, 0, n);
                                    }
                                }
                                if (buffer.IsEmpty)
                                {
                                    break;
                                }
                            }
                            return bytesRead;
                        }
                        finally
                        {
                            {
                                this.AsyncOperationCompleting();
                            }
                        }
                    });
                }
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                this.WriteCore(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count));
            }
            /*void */ WriteByte(/*byte*/ value)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.DeflateStream.$type))
                {
                    super.WriteByte(value);
                }
                else 
                {
                    this.WriteCore(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$5($.$ref(() => value, undefined, $.$spc.System.Byte)));
                }
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.DeflateStream.$type))
                {
                    super.Write$1(buffer);
                }
                else 
                {
                    this.WriteCore(buffer);
                }
            }
            /*void */ WriteCore(/*ReadOnlySpan<byte>*/ buffer)
            {
                this.EnsureCompressionMode();
                this.EnsureNotDisposed();
                if (buffer.IsEmpty)
                {
                    return;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null, "_deflater != null");
                this.WriteDeflaterOutput();
                {
                    /*fixed*/ 
                    {
                        /*byte**/ let bufferPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, buffer);
                        this._deflater.SetInput$1(bufferPtr, buffer.Length);
                        this.WriteDeflaterOutput();
                        this._wroteBytes = true;
                    }
                }
            }
            /*void */ WriteDeflaterOutput()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null && this._buffer !== null, "_deflater != null && _buffer != null");
                while(!this._deflater.NeedsInput())
                {
                    /*int*/ let compressedBytes = this._deflater.GetDeflateOutput(this._buffer);
                    if (compressedBytes > 0)
                    {
                        this._stream.Write(this._buffer, 0, compressedBytes);
                    }
                }
            }
            /*void */ FlushBuffers()
            {
                if (this._wroteBytes)
                {
                    this.WriteDeflaterOutput();
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null && this._buffer !== null, "_deflater != null && _buffer != null");
                    /*bool*/ let flushSuccessful;
                    do
                    {
                        /*int*/ let compressedBytes;
                        flushSuccessful = this._deflater.Flush(this._buffer, $.$ref(() => compressedBytes, ($v) => compressedBytes = $v, $.$spc.System.Int32));
                        if (flushSuccessful)
                        {
                            this._stream.Write(this._buffer, 0, compressedBytes);
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(flushSuccessful === (compressedBytes > 0), "flushSuccessful == (compressedBytes > 0)");
                    }
                    while(flushSuccessful);
                }
                this._stream.Flush();
            }
            /*void */ PurgeBuffers(/*bool*/ disposing)
            {
                if (!disposing)
                {
                    return;
                }
                if (this._stream === null)
                {
                    return;
                }
                if (this._mode !== 1/*CompressionMode.Compress*/)
                {
                    return;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null && this._buffer !== null, "_deflater != null && _buffer != null");
                if (this._wroteBytes)
                {
                    this.WriteDeflaterOutput();
                    /*bool*/ let finished;
                    do
                    {
                        /*int*/ let compressedBytes;
                        finished = this._deflater.Finish(this._buffer, $.$ref(() => compressedBytes, ($v) => compressedBytes = $v, $.$spc.System.Int32));
                        if (compressedBytes > 0)
                        {
                            this._stream.Write(this._buffer, 0, compressedBytes);
                        }
                    }
                    while(!finished);
                }
                else 
                {
                    /*bool*/ let finished;
                    do
                    {
                        finished = this._deflater.Finish(this._buffer, $.$discardRef());
                    }
                    while(!finished);
                }
            }
            /*ValueTask *//*async*/  PurgeBuffersAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    if (this._stream === null)
                    {
                        return;
                    }
                    if (this._mode !== 1/*CompressionMode.Compress*/)
                    {
                        return;
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null && this._buffer !== null, "_deflater != null && _buffer != null");
                    if (this._wroteBytes)
                    {
                        await this.WriteDeflaterOutputAsync(new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                        /*bool*/ let finished;
                        do
                        {
                            /*int*/ let compressedBytes;
                            finished = this._deflater.Finish(this._buffer, $.$ref(() => compressedBytes, ($v) => compressedBytes = $v, $.$spc.System.Int32));
                            if (compressedBytes > 0)
                            {
                                await this._stream.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(this._buffer, 0, compressedBytes), new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                            }
                        }
                        while(!finished);
                    }
                    else 
                    {
                        /*bool*/ let finished;
                        do
                        {
                            finished = this._deflater.Finish(this._buffer, $.$discardRef());
                        }
                        while(!finished);
                    }
                });
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    this.PurgeBuffers(disposing);
                }
                finally
                {
                    {
                        try
                        {
                            if (disposing && !this._leaveOpen)
                            {
                                this._stream?.Dispose();
                            }
                        }
                        finally
                        {
                            {
                                this._stream = null;
                                try
                                {
                                    this._deflater?.Dispose();
                                    this._inflater?.Dispose$1();
                                }
                                finally
                                {
                                    {
                                        this._deflater = null;
                                        this._inflater = null;
                                        /*byte[]?*/ let buffer = this._buffer;
                                        if (buffer !== null)
                                        {
                                            this._buffer = null;
                                            if (!this._activeAsyncOperation)
                                            {
                                                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(buffer, false);
                                            }
                                        }
                                        super.Dispose$1(disposing);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                return $.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.DeflateStream.$type) ? Core.call(this) : super.DisposeAsync();
                /*ValueTask*/ /*async*/  function Core()
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                    {
                        try
                        {
                            await this.PurgeBuffersAsync().ConfigureAwait(false);
                        }
                        finally
                        {
                            {
                                /*Stream*/ let stream = this._stream;
                                this._stream = null;
                                try
                                {
                                    if (!this._leaveOpen && stream !== null)
                                    {
                                        await stream.DisposeAsync().ConfigureAwait(false);
                                    }
                                }
                                finally
                                {
                                    {
                                        try
                                        {
                                            this._deflater?.Dispose();
                                            this._inflater?.Dispose$1();
                                        }
                                        finally
                                        {
                                            {
                                                this._deflater = null;
                                                this._inflater = null;
                                                /*byte[]?*/ let buffer = this._buffer;
                                                if (buffer !== null)
                                                {
                                                    this._buffer = null;
                                                    if (!this._activeAsyncOperation)
                                                    {
                                                        $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(buffer, false);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            }
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.WriteAsync$1(buffer, offset, count, $.$spc.System.Threading.CancellationToken.None), asyncCallback, asyncState);
            }
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                this.EnsureCompressionMode();
                this.EnsureNotDisposed();
                $.$spc.System.Threading.Tasks.TaskToAsyncResult.End(asyncResult);
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                return this.WriteAsyncMemory(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.DeflateStream.$type))
                {
                    return super.WriteAsync$2(buffer, cancellationToken);
                }
                else 
                {
                    return this.WriteAsyncMemory(buffer, cancellationToken);
                }
            }
            /*ValueTask */ WriteAsyncMemory(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.EnsureCompressionMode();
                this.EnsureNoActiveAsyncOperation();
                this.EnsureNotDisposed();
                return cancellationToken.IsCancellationRequested ? $.$spc.System.Threading.Tasks.ValueTask.FromCanceled(cancellationToken) : buffer.IsEmpty ? new $.$spc.System.Threading.Tasks.ValueTask() : Core.call(this, buffer, cancellationToken);
                /*ValueTask*/ /*async*/  function Core(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                    {
                        this.AsyncOperationStarting();
                        try
                        {
                            await this.WriteDeflaterOutputAsync(cancellationToken).ConfigureAwait(false);
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null, "_deflater != null");
                            this._deflater.SetInput(buffer);
                            await this.WriteDeflaterOutputAsync(cancellationToken).ConfigureAwait(false);
                            this._wroteBytes = true;
                        }
                        finally
                        {
                            {
                                this.AsyncOperationCompleting();
                            }
                        }
                    });
                }
            }
            /*ValueTask *//*async*/  WriteDeflaterOutputAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._deflater !== null && this._buffer !== null, "_deflater != null && _buffer != null");
                    while(!this._deflater.NeedsInput())
                    {
                        /*int*/ let compressedBytes = this._deflater.GetDeflateOutput(this._buffer);
                        if (compressedBytes > 0)
                        {
                            await this._stream.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(this._buffer, 0, compressedBytes), cancellationToken).ConfigureAwait(false);
                        }
                    }
                });
            }
            /*void */ CopyTo$1(/*Stream*/ destination, /*int*/ bufferSize)
            {
                $.$spc.System.IO.Stream.ValidateCopyToArguments(destination, bufferSize);
                this.EnsureNotDisposed();
                if (!this.CanRead)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$9();
                }
                new $.$sic.System.IO.Compression.DeflateStream.CopyToStream().$ctor$3(this, destination, bufferSize).CopyFromSourceToDestination();
            }
            /*Task */ CopyToAsync$3(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.IO.Stream.ValidateCopyToArguments(destination, bufferSize);
                this.EnsureNotDisposed();
                if (!this.CanRead)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$9();
                }
                this.EnsureNoActiveAsyncOperation();
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spc.System.Int32, cancellationToken);
                }
                return new $.$sic.System.IO.Compression.DeflateStream.CopyToStream().$ctor$4(this, destination, bufferSize, cancellationToken).CopyFromSourceToDestinationAsync();
            }
            static $_CopyToStream;
            static get CopyToStream()
            {
                let $cls = $.$sic.System.IO.Compression.DeflateStream;
                return $cls.$_CopyToStream ??= $asm.$ncls("$sic.System.IO.Compression.DeflateStream.CopyToStream", ($self) => class CopyToStream extends $.$spc.System.IO.Stream
                {
                    /*DeflateStream*/ _deflateStream = null;
                    /*Stream*/ _destination = null;
                    /*CancellationToken*/ _cancellationToken;
                    /*byte[]*/ _arrayPoolBuffer = null;
                    $ctor$3(/*DeflateStream*/ deflateStream, /*Stream*/ destination, /*int*/ bufferSize)
                    {
                        this.$ctor$4(deflateStream, destination, bufferSize, $.$spc.System.Threading.CancellationToken.None);
                        {
                        }
                        return this;
                    }
                    $ctor$4(/*DeflateStream*/ deflateStream, /*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
                    {
                        super.$ctor$2();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(deflateStream !== null, "deflateStream != null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(destination !== null, "destination != null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(bufferSize > 0, "bufferSize > 0");
                            this._deflateStream = deflateStream;
                            this._destination = destination;
                            this._cancellationToken = cancellationToken;
                            this._arrayPoolBuffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(bufferSize);
                        }
                        return this;
                    }
                    /*Task *//*async*/  CopyFromSourceToDestinationAsync()
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                        {
                            this._deflateStream.AsyncOperationStarting();
                            try
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._deflateStream._inflater !== null, "_deflateStream._inflater != null");
                                while(!this._deflateStream._inflater.Finished())
                                {
                                    /*int*/ let bytesRead = this._deflateStream._inflater.Inflate$1(this._arrayPoolBuffer, 0, this._arrayPoolBuffer.length);
                                    if (bytesRead > 0)
                                    {
                                        await this._destination.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(this._arrayPoolBuffer, 0, bytesRead), this._cancellationToken).ConfigureAwait(false);
                                    }
                                    else if (this._deflateStream._inflater.NeedsInput())
                                    {
                                        break;
                                    }
                                }
                                await this._deflateStream._stream.CopyToAsync$3(this, this._arrayPoolBuffer.length, this._cancellationToken).ConfigureAwait(false);
                                if ($.$sic.System.IO.Compression.DeflateStream.s_useStrictValidation && !this._deflateStream._inflater.Finished())
                                {
                                    $.$sic.System.IO.Compression.DeflateStream.ThrowTruncatedInvalidData();
                                }
                            }
                            finally
                            {
                                {
                                    this._deflateStream.AsyncOperationCompleting();
                                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(this._arrayPoolBuffer, false);
                                    this._arrayPoolBuffer = null;
                                }
                            }
                        });
                    }
                    /*void */ CopyFromSourceToDestination()
                    {
                        try
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._deflateStream._inflater !== null, "_deflateStream._inflater != null");
                            while(!this._deflateStream._inflater.Finished())
                            {
                                /*int*/ let bytesRead = this._deflateStream._inflater.Inflate$1(this._arrayPoolBuffer, 0, this._arrayPoolBuffer.length);
                                if (bytesRead > 0)
                                {
                                    this._destination.Write(this._arrayPoolBuffer, 0, bytesRead);
                                }
                                else if (this._deflateStream._inflater.NeedsInput())
                                {
                                    break;
                                }
                            }
                            this._deflateStream._stream.CopyTo$1(this, this._arrayPoolBuffer.length);
                            if ($.$sic.System.IO.Compression.DeflateStream.s_useStrictValidation && !this._deflateStream._inflater.Finished())
                            {
                                $.$sic.System.IO.Compression.DeflateStream.ThrowTruncatedInvalidData();
                            }
                        }
                        finally
                        {
                            {
                                $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(this._arrayPoolBuffer, false);
                                this._arrayPoolBuffer = null;
                            }
                        }
                    }
                    /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(buffer !== this._arrayPoolBuffer, "buffer != _arrayPoolBuffer");
                        this._deflateStream.EnsureNotDisposed();
                        if (count <= 0)
                        {
                            return $.$spc.System.Threading.Tasks.Task.CompletedTask;
                        }
                        else if (count > ((buffer.length - offset) | 0))
                        {
                            return $.$spc.System.Threading.Tasks.Task.FromException(new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData));
                        }
                        return this.WriteAsyncCore($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, buffer, offset, count)), cancellationToken).AsTask();
                    }
                    /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        this._deflateStream.EnsureNotDisposed();
                        return this.WriteAsyncCore(buffer, cancellationToken);
                    }
                    /*ValueTask *//*async*/  WriteAsyncCore(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(this._deflateStream._inflater === null), "_deflateStream._inflater is not null");
                            this._deflateStream._inflater.SetInput$1(buffer);
                            while(!this._deflateStream._inflater.Finished())
                            {
                                /*int*/ let bytesRead = this._deflateStream._inflater.Inflate$2(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$2(this._arrayPoolBuffer));
                                if (bytesRead > 0)
                                {
                                    await this._destination.WriteAsync$2(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(this._arrayPoolBuffer, 0, bytesRead), cancellationToken).ConfigureAwait(false);
                                }
                                else if (this._deflateStream._inflater.NeedsInput())
                                {
                                    break;
                                }
                            }
                        });
                    }
                    /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(buffer !== this._arrayPoolBuffer, "buffer != _arrayPoolBuffer");
                        this._deflateStream.EnsureNotDisposed();
                        if (count <= 0)
                        {
                            return;
                        }
                        else if (count > ((buffer.length - offset) | 0))
                        {
                            throw new $.$spc.System.IO.InvalidDataException().$ctor$10($.$sic.System.SR.GenericInvalidData);
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._deflateStream._inflater !== null, "_deflateStream._inflater != null");
                        this._deflateStream._inflater.SetInput(buffer, offset, count);
                        while(!this._deflateStream._inflater.Finished())
                        {
                            /*int*/ let bytesRead = this._deflateStream._inflater.Inflate$2(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$2(this._arrayPoolBuffer));
                            if (bytesRead > 0)
                            {
                                this._destination.Write(this._arrayPoolBuffer, 0, bytesRead);
                            }
                            else if (this._deflateStream._inflater.NeedsInput())
                            {
                                break;
                            }
                        }
                    }
                    /*bool */ get CanWrite()
                    {
                        return true;
                    }
                    /*void */ Flush()
                    {
                    }
                    /*bool */ get CanRead()
                    {
                        return false;
                    }
                    /*bool */ get CanSeek()
                    {
                        return false;
                    }
                    /*long */ get Length()
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*long */ get Position()
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*long */ set Position(value)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ SetLength(/*long*/ value)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._cancellationToken = $.$default($.$spc.System.Threading.CancellationToken);
                    }
                    static $h = 1152379;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":60130694523,"f":32769},"n":"CanWrite","d":1152379,"h":55835727227,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":73015596411,"f":32769},"n":"CanRead","d":1152379,"h":68720629115,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":81605531003,"f":32769},"n":"CanSeek","d":1152379,"h":77310563707,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":90195465595,"f":32769},"n":"Length","d":1152379,"h":85900498299,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":98785400187,"f":32769},"s":{"r":0,"d":0,"h":103080367483,"f":32769},"n":"Position","d":1152379,"h":94490432891,"f":32769}],"m":[{"r":133300225,"n":"CopyFromSourceToDestinationAsync","d":1152379,"h":30065923451,"f":4097},{"r":65537,"n":"CopyFromSourceToDestination","d":1152379,"h":34360890747,"f":1},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1152379,"h":38655858043,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1152379,"h":42950825339,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"WriteAsyncCore","d":1152379,"h":47245792635,"f":4098},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1152379,"h":51540759931,"f":32769},{"r":65537,"n":"Flush","d":1152379,"h":64425661819,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1152379,"h":107375334779,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1152379,"h":111670302075,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1152379,"h":115965269371,"f":32769}],"l":[{"t":1086843,"n":"_deflateStream","d":1152379,"h":4296119675,"f":2},{"t":62128129,"n":"_destination","d":1152379,"h":8591086971,"f":2},{"t":125960193,"n":"_cancellationToken","d":1152379,"h":12886054267,"f":2},{"t":0,"n":"_arrayPoolBuffer","d":1152379,"h":17181021563,"f":2}],"c":[{"p":[{"n":"deflateStream","p":1086843},{"n":"destination","p":62128129},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$3","d":1152379,"h":21475988859,"f":1},{"p":[{"n":"deflateStream","p":1086843},{"n":"destination","p":62128129},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":".ctor","o":"$ctor$4","d":1152379,"h":25770956155,"f":1}],"i":[57475073,56885249],"d":1086843,"h":1152379}; }
                    static get $b() { return $.$spc.System.IO.Stream; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
                    static get $fullName() { return `System.IO.Compression.DeflateStream.CopyToStream`; }
                }, $cls, ($v) => $cls.$_CopyToStream = $v);
            }
            /*void */ EnsureNoActiveAsyncOperation()
            {
                if (this._activeAsyncOperation)
                {
                    $.$sic.System.IO.Compression.DeflateStream.ThrowInvalidBeginCall();
                }
            }
            /*void */ AsyncOperationStarting()
            {
                if ($.$spc.System.Threading.Interlocked.Exchange$14($.$spc.System.Boolean, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => this._activeAsyncOperation, ($v) => this._activeAsyncOperation = $v, null), true))
                {
                    $.$sic.System.IO.Compression.DeflateStream.ThrowInvalidBeginCall();
                }
            }
            /*void */ AsyncOperationCompleting()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._activeAsyncOperation, "_activeAsyncOperation");
                this._activeAsyncOperation = false;
            }
            static /*void */ ThrowInvalidBeginCall()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sic.System.SR.InvalidBeginCall);
            }
            /*bool*/ static s_useStrictValidation = false;
            //Static Initializer
            static $sinit()
            {
                {
                    /*bool*/ let strictValidation;
                    this.s_useStrictValidation = $.$spc.System.AppContext.TryGetSwitch("System.IO.Compression.UseStrictValidation", $.$ref(() => strictValidation, ($v) => strictValidation = $v, $.$spc.System.Boolean)) ? strictValidation : false;
                }
            }
            static $h = 1086843;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":62128129,"g":{"r":0,"d":0,"h":107375269243,"f":1},"n":"BaseStream","d":1086843,"h":103080301947,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115965203835,"f":32769},"n":"CanRead","d":1086843,"h":111670236539,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":124555138427,"f":32769},"n":"CanWrite","d":1086843,"h":120260171131,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":133145073019,"f":32769},"n":"CanSeek","d":1086843,"h":128850105723,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":141735007611,"f":32769},"n":"Length","d":1086843,"h":137440040315,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":150324942203,"f":32769},"s":{"r":0,"d":0,"h":154619909499,"f":32769},"n":"Position","d":1086843,"h":146029974907,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":197569582459,"f":2},"n":"InflatorIsFinished","d":1086843,"h":193274615163,"f":2}],"m":[{"r":65537,"p":[{"n":"stream","p":62128129},{"n":"compressionLevel","p":4756859},{"n":"strategy","p":4887931},{"n":"leaveOpen","p":262145},{"n":"windowBits","p":655361}],"n":"InitializeDeflater","d":1086843,"h":81605465467,"f":8},{"r":4756859,"p":[{"n":"compressionLevel","p":759163}],"n":"GetZLibNativeCompressionLevel","d":1086843,"h":85900432763,"f":34},{"r":655361,"p":[{"n":"level","p":4756859}],"n":"GetMemLevel","d":1086843,"h":90195400059,"f":34},{"r":65537,"n":"InitializeBuffer","d":1086843,"h":94490367355,"f":2},{"r":65537,"n":"EnsureBufferInitialized","d":1086843,"h":98785334651,"f":2},{"r":65537,"n":"Flush","d":1086843,"h":158914876795,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1086843,"h":163209844091,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1086843,"h":167504811387,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1086843,"h":171799778683,"f":32769},{"r":655361,"n":"ReadByte","d":1086843,"h":176094745979,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1086843,"h":180389713275,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1086843,"h":184684680571,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"ReadCore","d":1086843,"h":188979647867,"f":8},{"r":65537,"n":"EnsureNotDisposed","d":1086843,"h":201864549755,"f":2},{"r":65537,"n":"EnsureDecompressionMode","d":1086843,"h":206159517051,"f":2},{"r":65537,"n":"EnsureCompressionMode","d":1086843,"h":210454484347,"f":2},{"r":65537,"n":"ThrowGenericInvalidData","d":1086843,"h":214749451643,"f":34},{"r":65537,"n":"ThrowTruncatedInvalidData","d":1086843,"h":219044418939,"f":34},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginRead","d":1086843,"h":223339386235,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":1086843,"h":227634353531,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1086843,"h":231929320827,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1086843,"h":236224288123,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadAsyncMemory","d":1086843,"h":240519255419,"f":8},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1086843,"h":244814222715,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1086843,"h":249109190011,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1086843,"h":253404157307,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"WriteCore","d":1086843,"h":257699124603,"f":8},{"r":65537,"n":"WriteDeflaterOutput","d":1086843,"h":261994091899,"f":2},{"r":65537,"n":"FlushBuffers","d":1086843,"h":266289059195,"f":2},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"PurgeBuffers","d":1086843,"h":270584026491,"f":2},{"r":136118273,"n":"PurgeBuffersAsync","d":1086843,"h":274878993787,"f":4098},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1086843,"h":279173961083,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1086843,"h":283468928379,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":1086843,"h":287763895675,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":1086843,"h":292058862971,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1086843,"h":296353830267,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1086843,"h":300648797563,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"WriteAsyncMemory","d":1086843,"h":304943764859,"f":8},{"r":136118273,"p":[{"n":"cancellationToken","p":125960193}],"n":"WriteDeflaterOutputAsync","d":1086843,"h":309238732155,"f":4098},{"r":65537,"p":[{"n":"destination","p":62128129},{"n":"bufferSize","p":655361}],"n":"CopyTo","o":"@$1","d":1086843,"h":313533699451,"f":32769},{"r":133300225,"p":[{"n":"destination","p":62128129},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"CopyToAsync","o":"@$3","d":1086843,"h":317828666747,"f":32769},{"r":65537,"n":"EnsureNoActiveAsyncOperation","d":1086843,"h":326418601339,"f":2},{"r":65537,"n":"AsyncOperationStarting","d":1086843,"h":330713568635,"f":2},{"r":65537,"n":"AsyncOperationCompleting","d":1086843,"h":335008535931,"f":2},{"r":65537,"n":"ThrowInvalidBeginCall","d":1086843,"h":339303503227,"f":34}],"l":[{"t":655361,"n":"DefaultBufferSize","d":1086843,"h":4296054139,"f":34},{"t":62128129,"n":"_stream","d":1086843,"h":8591021435,"f":2},{"t":824699,"n":"_mode","d":1086843,"h":12885988731,"f":2},{"t":262145,"n":"_leaveOpen","d":1086843,"h":17180956027,"f":2},{"t":1348987,"n":"_inflater","d":1086843,"h":21475923323,"f":2},{"t":1021307,"n":"_deflater","d":1086843,"h":25770890619,"f":2},{"t":0,"n":"_buffer","d":1086843,"h":30065857915,"f":2},{"t":262145,"n":"_activeAsyncOperation","d":1086843,"h":34360825211,"f":2},{"t":262145,"n":"_wroteBytes","d":1086843,"h":38655792507,"f":2},{"t":262145,"n":"s_useStrictValidation","d":1086843,"h":343598470523,"f":34}],"c":[{"p":[{"n":"stream","p":62128129},{"n":"mode","p":824699},{"n":"uncompressedSize","p":917505}],"n":".ctor","o":"$ctor$3","d":1086843,"h":42950759803,"f":8},{"p":[{"n":"stream","p":62128129},{"n":"mode","p":824699}],"n":".ctor","o":"$ctor$4","d":1086843,"h":47245727099,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"mode","p":824699},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":1086843,"h":51540694395,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"compressionLevel","p":759163}],"n":".ctor","o":"$ctor$6","d":1086843,"h":55835661691,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"compressionLevel","p":759163},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$7","d":1086843,"h":60130628987,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"compressionOptions","p":4494715},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$8","d":1086843,"h":64425596283,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"compressionOptions","p":4494715},{"n":"leaveOpen","p":262145},{"n":"windowBits","p":655361}],"n":".ctor","o":"$ctor$9","d":1086843,"h":68720563579,"f":8},{"p":[{"n":"stream","p":62128129},{"n":"mode","p":824699},{"n":"leaveOpen","p":262145},{"n":"windowBits","p":655361},{"n":"uncompressedSize","p":917505,"f":65,"v":-1}],"n":".ctor","o":"$ctor$10","d":1086843,"h":73015530875,"f":8},{"p":[{"n":"stream","p":62128129},{"n":"compressionLevel","p":759163},{"n":"leaveOpen","p":262145},{"n":"windowBits","p":655361}],"n":".ctor","o":"$ctor$11","d":1086843,"h":77310498171,"f":8}],"i":[57475073,56885249],"j":[1152379],"h":1086843}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.DeflateStream`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.GZipStream", ($self) => class GZipStream extends $.$spc.System.IO.Stream
        {
            /*DeflateStream*/ _deflateStream = null;
            $ctor$3(/*Stream*/ stream, /*CompressionMode*/ mode)
            {
                this.$ctor$4(stream, mode, false);
                {
                }
                return this;
            }
            $ctor$4(/*Stream*/ stream, /*CompressionMode*/ mode, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    this._deflateStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$10(stream, mode, leaveOpen, 31/*ZLibNative.GZip_DefaultWindowBits*/, -1n);
                }
                return this;
            }
            $ctor$5(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel)
            {
                this.$ctor$6(stream, compressionLevel, false);
                {
                }
                return this;
            }
            $ctor$6(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    this._deflateStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$11(stream, compressionLevel, leaveOpen, 31/*ZLibNative.GZip_DefaultWindowBits*/);
                }
                return this;
            }
            $ctor$7(/*Stream*/ stream, /*ZLibCompressionOptions*/ compressionOptions, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    this._deflateStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$9(stream, compressionOptions, leaveOpen, 31/*ZLibNative.GZip_DefaultWindowBits*/);
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                return (this._deflateStream?.CanRead ?? null) ?? false;
            }
            /*bool */ get CanWrite()
            {
                return (this._deflateStream?.CanWrite ?? null) ?? false;
            }
            /*bool */ get CanSeek()
            {
                return (this._deflateStream?.CanSeek ?? null) ?? false;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ Flush()
            {
                this.CheckDeflateStream();
                this._deflateStream.Flush();
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*int */ ReadByte()
            {
                this.CheckDeflateStream();
                return this._deflateStream.ReadByte();
            }
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.ReadAsync$1(buffer, offset, count, $.$spc.System.Threading.CancellationToken.None), asyncCallback, asyncState);
            }
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                return this._deflateStream.EndRead(asyncResult);
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.CheckDeflateStream();
                return this._deflateStream.Read(buffer, offset, count);
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.GZipStream.$type))
                {
                    return super.Read$1(buffer);
                }
                else 
                {
                    this.CheckDeflateStream();
                    return this._deflateStream.ReadCore(buffer);
                }
            }
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.WriteAsync$1(buffer, offset, count, $.$spc.System.Threading.CancellationToken.None), asyncCallback, asyncState);
            }
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                return this._deflateStream.EndWrite(asyncResult);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.CheckDeflateStream();
                this._deflateStream.Write(buffer, offset, count);
            }
            /*void */ WriteByte(/*byte*/ value)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.GZipStream.$type))
                {
                    super.WriteByte(value);
                }
                else 
                {
                    this.CheckDeflateStream();
                    this._deflateStream.WriteCore(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$5($.$ref(() => value, undefined, $.$spc.System.Byte)));
                }
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.GZipStream.$type))
                {
                    super.Write$1(buffer);
                }
                else 
                {
                    this.CheckDeflateStream();
                    this._deflateStream.WriteCore(buffer);
                }
            }
            /*void */ CopyTo$1(/*Stream*/ destination, /*int*/ bufferSize)
            {
                this.CheckDeflateStream();
                this._deflateStream.CopyTo$1(destination, bufferSize);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    if (disposing && this._deflateStream !== null)
                    {
                        this._deflateStream.Dispose();
                    }
                    this._deflateStream = null;
                }
                finally
                {
                    {
                        super.Dispose$1(disposing);
                    }
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.GZipStream.$type))
                {
                    return super.DisposeAsync();
                }
                /*DeflateStream?*/ let ds = this._deflateStream;
                if (ds !== null)
                {
                    this._deflateStream = null;
                    return ds.DisposeAsync();
                }
                return new $.$spc.System.Threading.Tasks.ValueTask();
            }
            /*Stream */ get BaseStream()
            {
                return (this._deflateStream?.BaseStream ?? null);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.CheckDeflateStream();
                return this._deflateStream.ReadAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.GZipStream.$type))
                {
                    return super.ReadAsync$2(buffer, cancellationToken);
                }
                else 
                {
                    this.CheckDeflateStream();
                    return this._deflateStream.ReadAsyncMemory(buffer, cancellationToken);
                }
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.CheckDeflateStream();
                return this._deflateStream.WriteAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                if ($.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(this), $.$sic.System.IO.Compression.GZipStream.$type))
                {
                    return super.WriteAsync$2(buffer, cancellationToken);
                }
                else 
                {
                    this.CheckDeflateStream();
                    return this._deflateStream.WriteAsyncMemory(buffer, cancellationToken);
                }
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                this.CheckDeflateStream();
                return this._deflateStream.FlushAsync$1(cancellationToken);
            }
            /*Task */ CopyToAsync$3(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                this.CheckDeflateStream();
                return this._deflateStream.CopyToAsync$3(destination, bufferSize, cancellationToken);
            }
            /*void */ CheckDeflateStream()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._deflateStream === null, this);
            }
            static $h = 1217915;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360956283,"f":32769},"n":"CanRead","d":1217915,"h":30065988987,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950890875,"f":32769},"n":"CanWrite","d":1217915,"h":38655923579,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51540825467,"f":32769},"n":"CanSeek","d":1217915,"h":47245858171,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":60130760059,"f":32769},"n":"Length","d":1217915,"h":55835792763,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68720694651,"f":32769},"s":{"r":0,"d":0,"h":73015661947,"f":32769},"n":"Position","d":1217915,"h":64425727355,"f":32769},{"p":62128129,"g":{"r":0,"d":0,"h":150325073275,"f":1},"n":"BaseStream","d":1217915,"h":146030105979,"f":1}],"m":[{"r":65537,"n":"Flush","d":1217915,"h":77310629243,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1217915,"h":81605596539,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1217915,"h":85900563835,"f":32769},{"r":655361,"n":"ReadByte","d":1217915,"h":90195531131,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginRead","d":1217915,"h":94490498427,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":1217915,"h":98785465723,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1217915,"h":103080433019,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1217915,"h":107375400315,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":1217915,"h":111670367611,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":1217915,"h":115965334907,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1217915,"h":120260302203,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1217915,"h":124555269499,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1217915,"h":128850236795,"f":32769},{"r":65537,"p":[{"n":"destination","p":62128129},{"n":"bufferSize","p":655361}],"n":"CopyTo","o":"@$1","d":1217915,"h":133145204091,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1217915,"h":137440171387,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1217915,"h":141735138683,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1217915,"h":154620040571,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1217915,"h":158915007867,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1217915,"h":163209975163,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1217915,"h":167504942459,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1217915,"h":171799909755,"f":32769},{"r":133300225,"p":[{"n":"destination","p":62128129},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"CopyToAsync","o":"@$3","d":1217915,"h":176094877051,"f":32769},{"r":65537,"n":"CheckDeflateStream","d":1217915,"h":180389844347,"f":2}],"l":[{"t":1086843,"n":"_deflateStream","d":1217915,"h":4296185211,"f":2}],"c":[{"p":[{"n":"stream","p":62128129},{"n":"mode","p":824699}],"n":".ctor","o":"$ctor$3","d":1217915,"h":8591152507,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"mode","p":824699},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$4","d":1217915,"h":12886119803,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"compressionLevel","p":759163}],"n":".ctor","o":"$ctor$5","d":1217915,"h":17181087099,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"compressionLevel","p":759163},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$6","d":1217915,"h":21476054395,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"compressionOptions","p":4494715},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$7","d":1217915,"h":25771021691,"f":1}],"i":[57475073,56885249],"h":1217915}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.GZipStream`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.PositionPreservingWriteOnlyStreamWrapper", ($self) => class PositionPreservingWriteOnlyStreamWrapper extends $.$spc.System.IO.Stream
        {
            /*Stream*/ _stream = null;
            /*long*/ _position = 0n;
            $ctor$3(/*Stream*/ stream)
            {
                super.$ctor$2();
                {
                    this._stream = stream;
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                return false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return true;
            }
            /*long */ get Position()
            {
                return this._position;
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this._position += BigInt(count);
                this._stream.Write(buffer, offset, count);
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
            {
                this._position += BigInt(buffer.Length);
                this._stream.Write$1(buffer);
            }
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                this._position += BigInt(count);
                return this._stream.BeginWrite(buffer, offset, count, callback, state);
            }
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                return this._stream.EndWrite(asyncResult);
            }
            /*void */ WriteByte(/*byte*/ value)
            {
                this._position += 1n;
                this._stream.WriteByte(value);
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this._position += BigInt(count);
                return this._stream.WriteAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this._position += BigInt(buffer.Length);
                return this._stream.WriteAsync$2(buffer, cancellationToken);
            }
            /*bool */ get CanTimeout()
            {
                return this._stream.CanTimeout;
            }
            /*int */ get ReadTimeout()
            {
                return this._stream.ReadTimeout;
            }
            /*int */ set ReadTimeout(value)
            {
                this._stream.ReadTimeout = value;
            }
            /*int */ get WriteTimeout()
            {
                return this._stream.WriteTimeout;
            }
            /*int */ set WriteTimeout(value)
            {
                this._stream.WriteTimeout = value;
            }
            /*void */ Flush()
            {
                return this._stream.Flush();
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                return this._stream.FlushAsync$1(cancellationToken);
            }
            /*void */ Close()
            {
                this._stream.Close();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    this._stream.Dispose();
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                return this._stream.DisposeAsync();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sic.System.SR.NotSupported);
            }
            static $h = 1742203;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476578683,"f":32769},"n":"CanRead","d":1742203,"h":17181611387,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":30066513275,"f":32769},"n":"CanSeek","d":1742203,"h":25771545979,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38656447867,"f":32769},"n":"CanWrite","d":1742203,"h":34361480571,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":47246382459,"f":32769},"s":{"r":0,"d":0,"h":51541349755,"f":32769},"n":"Position","d":1742203,"h":42951415163,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":90196055419,"f":32769},"n":"CanTimeout","d":1742203,"h":85901088123,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":98785990011,"f":32769},"s":{"r":0,"d":0,"h":103080957307,"f":32769},"n":"ReadTimeout","d":1742203,"h":94491022715,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":111670891899,"f":32769},"s":{"r":0,"d":0,"h":115965859195,"f":32769},"n":"WriteTimeout","d":1742203,"h":107375924603,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":146030630267,"f":32769},"n":"Length","d":1742203,"h":141735662971,"f":32769}],"m":[{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1742203,"h":55836317051,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1742203,"h":60131284347,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWrite","d":1742203,"h":64426251643,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":1742203,"h":68721218939,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1742203,"h":73016186235,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1742203,"h":77311153531,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1742203,"h":81606120827,"f":32769},{"r":65537,"n":"Flush","d":1742203,"h":120260826491,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1742203,"h":124555793787,"f":32769},{"r":65537,"n":"Close","d":1742203,"h":128850761083,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1742203,"h":133145728379,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1742203,"h":137440695675,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1742203,"h":150325597563,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1742203,"h":154620564859,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1742203,"h":158915532155,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1742203,"h":163210499451,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1742203,"h":167505466747,"f":32769}],"l":[{"t":62128129,"n":"_stream","d":1742203,"h":4296709499,"f":2},{"t":917505,"n":"_position","d":1742203,"h":8591676795,"f":2}],"c":[{"p":[{"n":"stream","p":62128129}],"n":".ctor","o":"$ctor$3","d":1742203,"h":12886644091,"f":1}],"i":[57475073,56885249],"h":1742203}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.PositionPreservingWriteOnlyStreamWrapper`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZLibStream", ($self) => class ZLibStream extends $.$spc.System.IO.Stream
        {
            /*DeflateStream*/ _deflateStream = null;
            $ctor$3(/*Stream*/ stream, /*CompressionMode*/ mode)
            {
                this.$ctor$4(stream, mode, false);
                {
                }
                return this;
            }
            $ctor$4(/*Stream*/ stream, /*CompressionMode*/ mode, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    this._deflateStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$10(stream, mode, leaveOpen, 15/*ZLibNative.ZLib_DefaultWindowBits*/, -1n);
                }
                return this;
            }
            $ctor$5(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel)
            {
                this.$ctor$6(stream, compressionLevel, false);
                {
                }
                return this;
            }
            $ctor$6(/*Stream*/ stream, /*CompressionLevel*/ compressionLevel, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    this._deflateStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$11(stream, compressionLevel, leaveOpen, 15/*ZLibNative.ZLib_DefaultWindowBits*/);
                }
                return this;
            }
            $ctor$7(/*Stream*/ stream, /*ZLibCompressionOptions*/ compressionOptions, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    this._deflateStream = new $.$sic.System.IO.Compression.DeflateStream().$ctor$9(stream, compressionOptions, leaveOpen, 15/*ZLibNative.ZLib_DefaultWindowBits*/);
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                return (this._deflateStream?.CanRead ?? null) ?? false;
            }
            /*bool */ get CanWrite()
            {
                return (this._deflateStream?.CanWrite ?? null) ?? false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Flush()
            {
                this.ThrowIfClosed();
                this._deflateStream.Flush();
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfClosed();
                return this._deflateStream.FlushAsync$1(cancellationToken);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*int */ ReadByte()
            {
                this.ThrowIfClosed();
                return this._deflateStream.ReadByte();
            }
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                this.ThrowIfClosed();
                return this._deflateStream.BeginRead(buffer, offset, count, asyncCallback, asyncState);
            }
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                return this._deflateStream.EndRead(asyncResult);
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ThrowIfClosed();
                return this._deflateStream.Read(buffer, offset, count);
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                this.ThrowIfClosed();
                return this._deflateStream.ReadCore(buffer);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfClosed();
                return this._deflateStream.ReadAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfClosed();
                return this._deflateStream.ReadAsyncMemory(buffer, cancellationToken);
            }
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                this.ThrowIfClosed();
                return this._deflateStream.BeginWrite(buffer, offset, count, asyncCallback, asyncState);
            }
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                return this._deflateStream.EndWrite(asyncResult);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ThrowIfClosed();
                this._deflateStream.Write(buffer, offset, count);
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
            {
                this.ThrowIfClosed();
                this._deflateStream.WriteCore(buffer);
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfClosed();
                return this._deflateStream.WriteAsync$1(buffer, offset, count, cancellationToken);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfClosed();
                return this._deflateStream.WriteAsyncMemory(buffer, cancellationToken);
            }
            /*void */ WriteByte(/*byte*/ value)
            {
                this.ThrowIfClosed();
                this._deflateStream.WriteByte(value);
            }
            /*void */ CopyTo$1(/*Stream*/ destination, /*int*/ bufferSize)
            {
                this.ThrowIfClosed();
                this._deflateStream.CopyTo$1(destination, bufferSize);
            }
            /*Task */ CopyToAsync$3(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfClosed();
                return this._deflateStream.CopyToAsync$3(destination, bufferSize, cancellationToken);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    if (disposing)
                    {
                        this._deflateStream?.Dispose();
                    }
                    this._deflateStream = null;
                }
                finally
                {
                    {
                        super.Dispose$1(disposing);
                    }
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                /*DeflateStream?*/ let ds = this._deflateStream;
                if (!(ds === null))
                {
                    this._deflateStream = null;
                    return ds.DisposeAsync();
                }
                return new $.$spc.System.Threading.Tasks.ValueTask();
            }
            /*Stream */ get BaseStream()
            {
                return (this._deflateStream?.BaseStream ?? null);
            }
            /*void */ ThrowIfClosed()
            {
                $.$spc.System.ObjectDisposedException.ThrowIf(this._deflateStream === null, this);
            }
            static $h = 5281147;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34365019515,"f":32769},"n":"CanRead","d":5281147,"h":30070052219,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42954954107,"f":32769},"n":"CanWrite","d":5281147,"h":38659986811,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51544888699,"f":32769},"n":"CanSeek","d":5281147,"h":47249921403,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":60134823291,"f":32769},"n":"Length","d":5281147,"h":55839855995,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68724757883,"f":32769},"s":{"r":0,"d":0,"h":73019725179,"f":32769},"n":"Position","d":5281147,"h":64429790587,"f":32769},{"p":62128129,"g":{"r":0,"d":0,"h":176098940283,"f":1},"n":"BaseStream","d":5281147,"h":171803972987,"f":1}],"m":[{"r":65537,"n":"Flush","d":5281147,"h":77314692475,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":5281147,"h":81609659771,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":5281147,"h":85904627067,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":5281147,"h":90199594363,"f":32769},{"r":655361,"n":"ReadByte","d":5281147,"h":94494561659,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginRead","d":5281147,"h":98789528955,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":5281147,"h":103084496251,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":5281147,"h":107379463547,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":5281147,"h":111674430843,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":5281147,"h":115969398139,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":5281147,"h":120264365435,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":5281147,"h":124559332731,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":5281147,"h":128854300027,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":5281147,"h":133149267323,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":5281147,"h":137444234619,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":5281147,"h":141739201915,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":5281147,"h":146034169211,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":5281147,"h":150329136507,"f":32769},{"r":65537,"p":[{"n":"destination","p":62128129},{"n":"bufferSize","p":655361}],"n":"CopyTo","o":"@$1","d":5281147,"h":154624103803,"f":32769},{"r":133300225,"p":[{"n":"destination","p":62128129},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"CopyToAsync","o":"@$3","d":5281147,"h":158919071099,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":5281147,"h":163214038395,"f":32772},{"r":136118273,"n":"DisposeAsync","d":5281147,"h":167509005691,"f":32769},{"r":65537,"n":"ThrowIfClosed","d":5281147,"h":180393907579,"f":2}],"l":[{"t":1086843,"n":"_deflateStream","d":5281147,"h":4300248443,"f":2}],"c":[{"p":[{"n":"stream","p":62128129},{"n":"mode","p":824699}],"n":".ctor","o":"$ctor$3","d":5281147,"h":8595215739,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"mode","p":824699},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$4","d":5281147,"h":12890183035,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"compressionLevel","p":759163}],"n":".ctor","o":"$ctor$5","d":5281147,"h":17185150331,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"compressionLevel","p":759163},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$6","d":5281147,"h":21480117627,"f":1},{"p":[{"n":"stream","p":62128129},{"n":"compressionOptions","p":4494715},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$7","d":5281147,"h":25775084923,"f":1}],"i":[57475073,56885249],"h":5281147}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Compression.ZLibStream`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.ZipArchiveMode", ($self) => class ZipArchiveMode extends $.$spc.System.Enum
        {
            static Read = 0;
            static Create = 1;
            static Update = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Read": 0n,
                    "Create": 1n,
                    "Update": 2n
                };
            }
            static $h = 3052923;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":3052923,"n":"Read","d":3052923,"h":4298020219,"f":33},{"t":3052923,"n":"Create","d":3052923,"h":8592987515,"f":33},{"t":3052923,"n":"Update","d":3052923,"h":12887954811,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":3052923,"h":17182922107,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":3052923}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.ZipArchiveMode`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.ZipVersionNeededValues", ($self) => class ZipVersionNeededValues extends $.$spc.System.Enum
        {
            static Default = 10;
            static ExplicitDirectory = 20;
            static Deflate = 20;
            static Deflate64 = 21;
            static Zip64 = 45;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 10n,
                    "ExplicitDirectory": 20n,
                    "Deflate": 20n,
                    "Deflate64": 21n,
                    "Zip64": 45n
                };
            }
            static $h = 4429179;
            static $z = 2;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.UInt16; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":589825,"l":[{"t":4429179,"n":"Default","d":4429179,"h":4299396475,"f":33},{"t":4429179,"n":"ExplicitDirectory","d":4429179,"h":8594363771,"f":33},{"t":4429179,"n":"Deflate","d":4429179,"h":12889331067,"f":33},{"t":4429179,"n":"Deflate64","d":4429179,"h":17184298363,"f":33},{"t":4429179,"n":"Zip64","d":4429179,"h":21479265659,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4429179,"h":25774232955,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4429179}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.ZipVersionNeededValues`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.ZipVersionMadeByPlatform", ($self) => class ZipVersionMadeByPlatform extends $.$spc.System.Enum
        {
            static Windows = 0;
            static Unix = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Windows": 0n,
                    "Unix": 3n
                };
            }
            static $h = 4363643;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":4363643,"n":"Windows","d":4363643,"h":4299330939,"f":33},{"t":4363643,"n":"Unix","d":4363643,"h":8594298235,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4363643,"h":12889265531,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4363643}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.ZipVersionMadeByPlatform`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.BlockType", ($self) => class BlockType extends $.$spc.System.Enum
        {
            static Uncompressed = 0;
            static Static = 1;
            static Dynamic = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Uncompressed": 0n,
                    "Static": 1n,
                    "Dynamic": 2n
                };
            }
            static $h = 628091;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":628091,"n":"Uncompressed","d":628091,"h":4295595387,"f":33},{"t":628091,"n":"Static","d":628091,"h":8590562683,"f":33},{"t":628091,"n":"Dynamic","d":628091,"h":12885529979,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":628091,"h":17180497275,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":628091}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.BlockType`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.InflaterState", ($self) => class InflaterState extends $.$spc.System.Enum
        {
            static ReadingHeader = 0;
            static ReadingBFinal = 2;
            static ReadingBType = 3;
            static ReadingNumLitCodes = 4;
            static ReadingNumDistCodes = 5;
            static ReadingNumCodeLengthCodes = 6;
            static ReadingCodeLengthCodes = 7;
            static ReadingTreeCodesBefore = 8;
            static ReadingTreeCodesAfter = 9;
            static DecodeTop = 10;
            static HaveInitialLength = 11;
            static HaveFullLength = 12;
            static HaveDistCode = 13;
            static UncompressedAligning = 15;
            static UncompressedByte1 = 16;
            static UncompressedByte2 = 17;
            static UncompressedByte3 = 18;
            static UncompressedByte4 = 19;
            static DecodingUncompressed = 20;
            static StartReadingFooter = 21;
            static ReadingFooter = 22;
            static VerifyingFooter = 23;
            static Done = 24;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ReadingHeader": 0n,
                    "ReadingBFinal": 2n,
                    "ReadingBType": 3n,
                    "ReadingNumLitCodes": 4n,
                    "ReadingNumDistCodes": 5n,
                    "ReadingNumCodeLengthCodes": 6n,
                    "ReadingCodeLengthCodes": 7n,
                    "ReadingTreeCodesBefore": 8n,
                    "ReadingTreeCodesAfter": 9n,
                    "DecodeTop": 10n,
                    "HaveInitialLength": 11n,
                    "HaveFullLength": 12n,
                    "HaveDistCode": 13n,
                    "UncompressedAligning": 15n,
                    "UncompressedByte1": 16n,
                    "UncompressedByte2": 17n,
                    "UncompressedByte3": 18n,
                    "UncompressedByte4": 19n,
                    "DecodingUncompressed": 20n,
                    "StartReadingFooter": 21n,
                    "ReadingFooter": 22n,
                    "VerifyingFooter": 23n,
                    "Done": 24n
                };
            }
            static $h = 1480059;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1480059,"n":"ReadingHeader","d":1480059,"h":4296447355,"f":33},{"t":1480059,"n":"ReadingBFinal","d":1480059,"h":8591414651,"f":33},{"t":1480059,"n":"ReadingBType","d":1480059,"h":12886381947,"f":33},{"t":1480059,"n":"ReadingNumLitCodes","d":1480059,"h":17181349243,"f":33},{"t":1480059,"n":"ReadingNumDistCodes","d":1480059,"h":21476316539,"f":33},{"t":1480059,"n":"ReadingNumCodeLengthCodes","d":1480059,"h":25771283835,"f":33},{"t":1480059,"n":"ReadingCodeLengthCodes","d":1480059,"h":30066251131,"f":33},{"t":1480059,"n":"ReadingTreeCodesBefore","d":1480059,"h":34361218427,"f":33},{"t":1480059,"n":"ReadingTreeCodesAfter","d":1480059,"h":38656185723,"f":33},{"t":1480059,"n":"DecodeTop","d":1480059,"h":42951153019,"f":33},{"t":1480059,"n":"HaveInitialLength","d":1480059,"h":47246120315,"f":33},{"t":1480059,"n":"HaveFullLength","d":1480059,"h":51541087611,"f":33},{"t":1480059,"n":"HaveDistCode","d":1480059,"h":55836054907,"f":33},{"t":1480059,"n":"UncompressedAligning","d":1480059,"h":60131022203,"f":33},{"t":1480059,"n":"UncompressedByte1","d":1480059,"h":64425989499,"f":33},{"t":1480059,"n":"UncompressedByte2","d":1480059,"h":68720956795,"f":33},{"t":1480059,"n":"UncompressedByte3","d":1480059,"h":73015924091,"f":33},{"t":1480059,"n":"UncompressedByte4","d":1480059,"h":77310891387,"f":33},{"t":1480059,"n":"DecodingUncompressed","d":1480059,"h":81605858683,"f":33},{"t":1480059,"n":"StartReadingFooter","d":1480059,"h":85900825979,"f":33},{"t":1480059,"n":"ReadingFooter","d":1480059,"h":90195793275,"f":33},{"t":1480059,"n":"VerifyingFooter","d":1480059,"h":94490760571,"f":33},{"t":1480059,"n":"Done","d":1480059,"h":98785727867,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1480059,"h":103080695163,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1480059}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.InflaterState`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.MatchState", ($self) => class MatchState extends $.$spc.System.Enum
        {
            static HasSymbol = 1;
            static HasMatch = 2;
            static HasSymbolAndMatch = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "HasSymbol": 1n,
                    "HasMatch": 2n,
                    "HasSymbolAndMatch": 3n
                };
            }
            static $h = 1611131;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1611131,"n":"HasSymbol","d":1611131,"h":4296578427,"f":33},{"t":1611131,"n":"HasMatch","d":1611131,"h":8591545723,"f":33},{"t":1611131,"n":"HasSymbolAndMatch","d":1611131,"h":12886513019,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1611131,"h":17181480315,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1611131}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.MatchState`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.CompressionLevel", ($self) => class CompressionLevel extends $.$spc.System.Enum
        {
            static Optimal = 0;
            static Fastest = 1;
            static NoCompression = 2;
            static SmallestSize = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Optimal": 0n,
                    "Fastest": 1n,
                    "NoCompression": 2n,
                    "SmallestSize": 3n
                };
            }
            static $h = 759163;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":759163,"n":"Optimal","d":759163,"h":4295726459,"f":33},{"t":759163,"n":"Fastest","d":759163,"h":8590693755,"f":33},{"t":759163,"n":"NoCompression","d":759163,"h":12885661051,"f":33},{"t":759163,"n":"SmallestSize","d":759163,"h":17180628347,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":759163,"h":21475595643,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":759163}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.CompressionLevel`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.CompressionMode", ($self) => class CompressionMode extends $.$spc.System.Enum
        {
            static Decompress = 0;
            static Compress = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Decompress": 0n,
                    "Compress": 1n
                };
            }
            static $h = 824699;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":824699,"n":"Decompress","d":824699,"h":4295791995,"f":33},{"t":824699,"n":"Compress","d":824699,"h":8590759291,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":824699,"h":12885726587,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":824699}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.CompressionMode`; }
        });
        
        $asm.$str("$sic.System.IO.Compression.ZLibCompressionStrategy", ($self) => class ZLibCompressionStrategy extends $.$spc.System.Enum
        {
            static Default = 0;
            static Filtered = 1;
            static HuffmanOnly = 2;
            static RunLengthEncoding = 3;
            static Fixed = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "Filtered": 1n,
                    "HuffmanOnly": 2n,
                    "RunLengthEncoding": 3n,
                    "Fixed": 4n
                };
            }
            static $h = 4560251;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4560251,"n":"Default","d":4560251,"h":4299527547,"f":33},{"t":4560251,"n":"Filtered","d":4560251,"h":8594494843,"f":33},{"t":4560251,"n":"HuffmanOnly","d":4560251,"h":12889462139,"f":33},{"t":4560251,"n":"RunLengthEncoding","d":4560251,"h":17184429435,"f":33},{"t":4560251,"n":"Fixed","d":4560251,"h":21479396731,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4560251,"h":25774364027,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4560251}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Compression.ZLibCompressionStrategy`; }
        });
        
        $asm.$cls("$sic.System.IO.Compression.ZLibException", ($self) => class ZLibException extends $.$spc.System.IO.IOException
        {
            /*string?*/ _zlibErrorContext = null;
            /*string?*/ _zlibErrorMessage = null;
            /*ZLibNative.ErrorCode*/ _zlibErrorCode = 0;
            $ctor$14(/*string?*/ message, /*string?*/ zlibErrorContext, /*int*/ zlibErrorCode, /*string?*/ zlibErrorMessage)
            {
                super.$ctor$10(message);
                {
                    this._zlibErrorContext = zlibErrorContext;
                    this._zlibErrorCode = $.$cast(zlibErrorCode, $.$sic.System.IO.Compression.ZLibNative.ErrorCode);
                    this._zlibErrorMessage = zlibErrorMessage;
                }
                return this;
            }
            $ctor$15()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$12(message, innerException);
                {
                }
                return this;
            }
            $ctor$17(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$13(info, context);
                {
                    this._zlibErrorContext = info.GetString("zlibErrorContext");
                    this._zlibErrorCode = $.$cast(info.GetInt32("zlibErrorCode"), $.$sic.System.IO.Compression.ZLibNative.ErrorCode);
                    this._zlibErrorMessage = info.GetString("zlibErrorMessage");
                }
                return this;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ si, /*StreamingContext*/ context)
            {
                super.GetObjectData(si, context);
                si.AddValue$1("zlibErrorContext", this._zlibErrorContext);
                si.AddValue$8("zlibErrorCode", this._zlibErrorCode);
                si.AddValue$1("zlibErrorMessage", this._zlibErrorMessage);
            }
            //default member initializer
            constructor()
            {
                super();
                this._zlibErrorContext = $.$spc.System.String.Empty;
                this._zlibErrorMessage = $.$spc.System.String.Empty;
            }
            static $h = 4625787;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":60686337,"h":4625787}; }
            static get $b() { return $.$spc.System.IO.IOException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.Compression.ZLibException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices"))