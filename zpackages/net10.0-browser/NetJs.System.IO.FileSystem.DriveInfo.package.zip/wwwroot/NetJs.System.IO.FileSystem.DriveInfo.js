
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.FileSystem.DriveInfo", 
    {"h":45152,"f":"System.IO.FileSystem.DriveInfo","v":"1.0.35.0","a":[{"t":90243073,"c":4385210369},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.FileSystem.DriveInfo","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.FileSystem.DriveInfo","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sifd.System.IO.PathInternal", ($self) => class PathInternal
        {
            static /*StringComparison */ get StringComparison()
            {
                return $.$sifd.System.IO.PathInternal.IsCaseSensitive ? 4/*StringComparison.Ordinal*/ : 5/*StringComparison.OrdinalIgnoreCase*/;
            }
            static /*bool */ get IsCaseSensitive()
            {
                return !($.$$.System.OperatingSystem.IsWindows() || $.$$.System.OperatingSystem.IsMacOS() || $.$$.System.OperatingSystem.IsIOS() || $.$$.System.OperatingSystem.IsTvOS());
            }
            static $h = 372832;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":119341057,"g":{"r":0,"d":0,"h":8590307424,"f":50331688},"n":"StringComparison","d":372832,"h":4295340128,"f":2097192},{"p":262145,"g":{"r":0,"d":0,"h":17180242016,"f":50331688},"n":"IsCaseSensitive","d":372832,"h":12885274720,"f":2097192}],"h":372832}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.PathInternal`; }
        });
        
        $asm.$cls("$sifd.System.HResults", ($self) => class HResults
        {
            /*int*/ static S_OK = 0;
            /*int*/ static S_FALSE = 1;
            /*int*/ static COR_E_ABANDONEDMUTEX = -2146233043;
            /*int*/ static COR_E_AMBIGUOUSIMPLEMENTATION = -2146234262;
            /*int*/ static COR_E_AMBIGUOUSMATCH = -2147475171;
            /*int*/ static COR_E_APPDOMAINUNLOADED = -2146234348;
            /*int*/ static COR_E_APPLICATION = -2146232832;
            /*int*/ static COR_E_ARGUMENT = -2147024809;
            /*int*/ static COR_E_ARGUMENTOUTOFRANGE = -2146233086;
            /*int*/ static COR_E_ARITHMETIC = -2147024362;
            /*int*/ static COR_E_ARRAYTYPEMISMATCH = -2146233085;
            /*int*/ static COR_E_BADEXEFORMAT = -2147024703;
            /*int*/ static COR_E_BADIMAGEFORMAT = -2147024885;
            /*int*/ static COR_E_CANNOTUNLOADAPPDOMAIN = -2146234347;
            /*int*/ static COR_E_CODECONTRACTFAILED = -2146233022;
            /*int*/ static COR_E_CONTEXTMARSHAL = -2146233084;
            /*int*/ static COR_E_CUSTOMATTRIBUTEFORMAT = -2146232827;
            /*int*/ static COR_E_DATAMISALIGNED = -2146233023;
            /*int*/ static COR_E_DIRECTORYNOTFOUND = -2147024893;
            /*int*/ static COR_E_DIVIDEBYZERO = -2147352558;
            /*int*/ static COR_E_DLLNOTFOUND = -2146233052;
            /*int*/ static COR_E_DUPLICATEWAITOBJECT = -2146233047;
            /*int*/ static COR_E_ENDOFSTREAM = -2147024858;
            /*int*/ static COR_E_ENTRYPOINTNOTFOUND = -2146233053;
            /*int*/ static COR_E_EXCEPTION = -2146233088;
            /*int*/ static COR_E_EXECUTIONENGINE = -2146233082;
            /*int*/ static COR_E_FAILFAST = -2146232797;
            /*int*/ static COR_E_FIELDACCESS = -2146233081;
            /*int*/ static COR_E_FILELOAD = -2146232799;
            /*int*/ static COR_E_FILENOTFOUND = -2147024894;
            /*int*/ static COR_E_FORMAT = -2146233033;
            /*int*/ static COR_E_INDEXOUTOFRANGE = -2146233080;
            /*int*/ static COR_E_INSUFFICIENTEXECUTIONSTACK = -2146232968;
            /*int*/ static COR_E_INSUFFICIENTMEMORY = -2146233027;
            /*int*/ static COR_E_INVALIDCAST = -2147467262;
            /*int*/ static COR_E_INVALIDCOMOBJECT = -2146233049;
            /*int*/ static COR_E_INVALIDFILTERCRITERIA = -2146232831;
            /*int*/ static COR_E_INVALIDOLEVARIANTTYPE = -2146233039;
            /*int*/ static COR_E_INVALIDOPERATION = -2146233079;
            /*int*/ static COR_E_INVALIDPROGRAM = -2146233030;
            /*int*/ static COR_E_IO = -2146232800;
            /*int*/ static COR_E_KEYNOTFOUND = -2146232969;
            /*int*/ static COR_E_MARSHALDIRECTIVE = -2146233035;
            /*int*/ static COR_E_MEMBERACCESS = -2146233062;
            /*int*/ static COR_E_METHODACCESS = -2146233072;
            /*int*/ static COR_E_MISSINGFIELD = -2146233071;
            /*int*/ static COR_E_MISSINGMANIFESTRESOURCE = -2146233038;
            /*int*/ static COR_E_MISSINGMEMBER = -2146233070;
            /*int*/ static COR_E_MISSINGMETHOD = -2146233069;
            /*int*/ static COR_E_MISSINGSATELLITEASSEMBLY = -2146233034;
            /*int*/ static COR_E_MULTICASTNOTSUPPORTED = -2146233068;
            /*int*/ static COR_E_NOTFINITENUMBER = -2146233048;
            /*int*/ static COR_E_NOTSUPPORTED = -2146233067;
            /*int*/ static COR_E_OBJECTDISPOSED = -2146232798;
            /*int*/ static COR_E_OPERATIONCANCELED = -2146233029;
            /*int*/ static COR_E_OUTOFMEMORY = -2147024882;
            /*int*/ static COR_E_OVERFLOW = -2146233066;
            /*int*/ static COR_E_PATHTOOLONG = -2147024690;
            /*int*/ static COR_E_PLATFORMNOTSUPPORTED = -2146233031;
            /*int*/ static COR_E_RANK = -2146233065;
            /*int*/ static COR_E_REFLECTIONTYPELOAD = -2146232830;
            /*int*/ static COR_E_RUNTIMEWRAPPED = -2146233026;
            /*int*/ static COR_E_SAFEARRAYRANKMISMATCH = -2146233032;
            /*int*/ static COR_E_SAFEARRAYTYPEMISMATCH = -2146233037;
            /*int*/ static COR_E_SECURITY = -2146233078;
            /*int*/ static COR_E_SERIALIZATION = -2146233076;
            /*int*/ static COR_E_STACKOVERFLOW = -2147023895;
            /*int*/ static COR_E_SYNCHRONIZATIONLOCK = -2146233064;
            /*int*/ static COR_E_SYSTEM = -2146233087;
            /*int*/ static COR_E_TARGET = -2146232829;
            /*int*/ static COR_E_TARGETINVOCATION = -2146232828;
            /*int*/ static COR_E_TARGETPARAMCOUNT = -2147352562;
            /*int*/ static COR_E_THREADABORTED = -2146233040;
            /*int*/ static COR_E_THREADINTERRUPTED = -2146233063;
            /*int*/ static COR_E_THREADSTART = -2146233051;
            /*int*/ static COR_E_THREADSTATE = -2146233056;
            /*int*/ static COR_E_TIMEOUT = -2146233083;
            /*int*/ static COR_E_TYPEACCESS = -2146233021;
            /*int*/ static COR_E_TYPEINITIALIZATION = -2146233036;
            /*int*/ static COR_E_TYPELOAD = -2146233054;
            /*int*/ static COR_E_TYPEUNLOADED = -2146234349;
            /*int*/ static COR_E_UNAUTHORIZEDACCESS = -2147024891;
            /*int*/ static COR_E_VERIFICATION = -2146233075;
            /*int*/ static COR_E_WAITHANDLECANNOTBEOPENED = -2146233044;
            /*int*/ static CO_E_NOTINITIALIZED = -2147221008;
            /*int*/ static DISP_E_PARAMNOTFOUND = -2147352572;
            /*int*/ static DISP_E_TYPEMISMATCH = -2147352571;
            /*int*/ static DISP_E_BADVARTYPE = -2147352568;
            /*int*/ static DISP_E_OVERFLOW = -2147352566;
            /*int*/ static DISP_E_DIVBYZERO = -2147352558;
            /*int*/ static E_BOUNDS = -2147483637;
            /*int*/ static E_CHANGED_STATE = -2147483636;
            /*int*/ static E_FILENOTFOUND = -2147024894;
            /*int*/ static E_FAIL = -2147467259;
            /*int*/ static E_HANDLE = -2147024890;
            /*int*/ static E_INVALIDARG = -2147024809;
            /*int*/ static E_NOTIMPL = -2147467263;
            /*int*/ static E_OUTOFMEMORY = -2147024882;
            /*int*/ static E_POINTER = -2147467261;
            /*int*/ static ERROR_MRM_MAP_NOT_FOUND = -2147009761;
            /*int*/ static ERROR_TIMEOUT = -2147023436;
            /*int*/ static RO_E_CLOSED = -2147483629;
            /*int*/ static RPC_E_CHANGED_MODE = -2147417850;
            /*int*/ static TYPE_E_TYPEMISMATCH = -2147316576;
            /*int*/ static STG_E_PATHNOTFOUND = -2147287037;
            /*int*/ static CTL_E_PATHNOTFOUND = -2146828212;
            /*int*/ static CTL_E_FILENOTFOUND = -2146828235;
            /*int*/ static FUSION_E_INVALID_NAME = -2146234297;
            /*int*/ static FUSION_E_REF_DEF_MISMATCH = -2146234304;
            /*int*/ static ERROR_TOO_MANY_OPEN_FILES = -2147024892;
            /*int*/ static ERROR_SHARING_VIOLATION = -2147024864;
            /*int*/ static ERROR_LOCK_VIOLATION = -2147024863;
            /*int*/ static ERROR_OPEN_FAILED = -2147024786;
            /*int*/ static ERROR_DISK_CORRUPT = -2147023503;
            /*int*/ static ERROR_UNRECOGNIZED_VOLUME = -2147023891;
            /*int*/ static ERROR_DLL_INIT_FAILED = -2147023782;
            /*int*/ static MSEE_E_ASSEMBLYLOADINPROGRESS = -2146234346;
            /*int*/ static ERROR_FILE_INVALID = -2147023890;
            static $h = 110688;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"S_OK","d":110688,"h":4295077984,"f":4194344},{"t":655361,"n":"S_FALSE","d":110688,"h":8590045280,"f":4194344},{"t":655361,"n":"COR_E_ABANDONEDMUTEX","d":110688,"h":12885012576,"f":4194344},{"t":655361,"n":"COR_E_AMBIGUOUSIMPLEMENTATION","d":110688,"h":17179979872,"f":4194344},{"t":655361,"n":"COR_E_AMBIGUOUSMATCH","d":110688,"h":21474947168,"f":4194344},{"t":655361,"n":"COR_E_APPDOMAINUNLOADED","d":110688,"h":25769914464,"f":4194344},{"t":655361,"n":"COR_E_APPLICATION","d":110688,"h":30064881760,"f":4194344},{"t":655361,"n":"COR_E_ARGUMENT","d":110688,"h":34359849056,"f":4194344},{"t":655361,"n":"COR_E_ARGUMENTOUTOFRANGE","d":110688,"h":38654816352,"f":4194344},{"t":655361,"n":"COR_E_ARITHMETIC","d":110688,"h":42949783648,"f":4194344},{"t":655361,"n":"COR_E_ARRAYTYPEMISMATCH","d":110688,"h":47244750944,"f":4194344},{"t":655361,"n":"COR_E_BADEXEFORMAT","d":110688,"h":51539718240,"f":4194344},{"t":655361,"n":"COR_E_BADIMAGEFORMAT","d":110688,"h":55834685536,"f":4194344},{"t":655361,"n":"COR_E_CANNOTUNLOADAPPDOMAIN","d":110688,"h":60129652832,"f":4194344},{"t":655361,"n":"COR_E_CODECONTRACTFAILED","d":110688,"h":64424620128,"f":4194344},{"t":655361,"n":"COR_E_CONTEXTMARSHAL","d":110688,"h":68719587424,"f":4194344},{"t":655361,"n":"COR_E_CUSTOMATTRIBUTEFORMAT","d":110688,"h":73014554720,"f":4194344},{"t":655361,"n":"COR_E_DATAMISALIGNED","d":110688,"h":77309522016,"f":4194344},{"t":655361,"n":"COR_E_DIRECTORYNOTFOUND","d":110688,"h":81604489312,"f":4194344},{"t":655361,"n":"COR_E_DIVIDEBYZERO","d":110688,"h":85899456608,"f":4194344},{"t":655361,"n":"COR_E_DLLNOTFOUND","d":110688,"h":90194423904,"f":4194344},{"t":655361,"n":"COR_E_DUPLICATEWAITOBJECT","d":110688,"h":94489391200,"f":4194344},{"t":655361,"n":"COR_E_ENDOFSTREAM","d":110688,"h":98784358496,"f":4194344},{"t":655361,"n":"COR_E_ENTRYPOINTNOTFOUND","d":110688,"h":103079325792,"f":4194344},{"t":655361,"n":"COR_E_EXCEPTION","d":110688,"h":107374293088,"f":4194344},{"t":655361,"n":"COR_E_EXECUTIONENGINE","d":110688,"h":111669260384,"f":4194344},{"t":655361,"n":"COR_E_FAILFAST","d":110688,"h":115964227680,"f":4194344},{"t":655361,"n":"COR_E_FIELDACCESS","d":110688,"h":120259194976,"f":4194344},{"t":655361,"n":"COR_E_FILELOAD","d":110688,"h":124554162272,"f":4194344},{"t":655361,"n":"COR_E_FILENOTFOUND","d":110688,"h":128849129568,"f":4194344},{"t":655361,"n":"COR_E_FORMAT","d":110688,"h":133144096864,"f":4194344},{"t":655361,"n":"COR_E_INDEXOUTOFRANGE","d":110688,"h":137439064160,"f":4194344},{"t":655361,"n":"COR_E_INSUFFICIENTEXECUTIONSTACK","d":110688,"h":141734031456,"f":4194344},{"t":655361,"n":"COR_E_INSUFFICIENTMEMORY","d":110688,"h":146028998752,"f":4194344},{"t":655361,"n":"COR_E_INVALIDCAST","d":110688,"h":150323966048,"f":4194344},{"t":655361,"n":"COR_E_INVALIDCOMOBJECT","d":110688,"h":154618933344,"f":4194344},{"t":655361,"n":"COR_E_INVALIDFILTERCRITERIA","d":110688,"h":158913900640,"f":4194344},{"t":655361,"n":"COR_E_INVALIDOLEVARIANTTYPE","d":110688,"h":163208867936,"f":4194344},{"t":655361,"n":"COR_E_INVALIDOPERATION","d":110688,"h":167503835232,"f":4194344},{"t":655361,"n":"COR_E_INVALIDPROGRAM","d":110688,"h":171798802528,"f":4194344},{"t":655361,"n":"COR_E_IO","d":110688,"h":176093769824,"f":4194344},{"t":655361,"n":"COR_E_KEYNOTFOUND","d":110688,"h":180388737120,"f":4194344},{"t":655361,"n":"COR_E_MARSHALDIRECTIVE","d":110688,"h":184683704416,"f":4194344},{"t":655361,"n":"COR_E_MEMBERACCESS","d":110688,"h":188978671712,"f":4194344},{"t":655361,"n":"COR_E_METHODACCESS","d":110688,"h":193273639008,"f":4194344},{"t":655361,"n":"COR_E_MISSINGFIELD","d":110688,"h":197568606304,"f":4194344},{"t":655361,"n":"COR_E_MISSINGMANIFESTRESOURCE","d":110688,"h":201863573600,"f":4194344},{"t":655361,"n":"COR_E_MISSINGMEMBER","d":110688,"h":206158540896,"f":4194344},{"t":655361,"n":"COR_E_MISSINGMETHOD","d":110688,"h":210453508192,"f":4194344},{"t":655361,"n":"COR_E_MISSINGSATELLITEASSEMBLY","d":110688,"h":214748475488,"f":4194344},{"t":655361,"n":"COR_E_MULTICASTNOTSUPPORTED","d":110688,"h":219043442784,"f":4194344},{"t":655361,"n":"COR_E_NOTFINITENUMBER","d":110688,"h":223338410080,"f":4194344},{"t":655361,"n":"COR_E_NOTSUPPORTED","d":110688,"h":227633377376,"f":4194344},{"t":655361,"n":"COR_E_OBJECTDISPOSED","d":110688,"h":231928344672,"f":4194344},{"t":655361,"n":"COR_E_OPERATIONCANCELED","d":110688,"h":236223311968,"f":4194344},{"t":655361,"n":"COR_E_OUTOFMEMORY","d":110688,"h":240518279264,"f":4194344},{"t":655361,"n":"COR_E_OVERFLOW","d":110688,"h":244813246560,"f":4194344},{"t":655361,"n":"COR_E_PATHTOOLONG","d":110688,"h":249108213856,"f":4194344},{"t":655361,"n":"COR_E_PLATFORMNOTSUPPORTED","d":110688,"h":253403181152,"f":4194344},{"t":655361,"n":"COR_E_RANK","d":110688,"h":257698148448,"f":4194344},{"t":655361,"n":"COR_E_REFLECTIONTYPELOAD","d":110688,"h":261993115744,"f":4194344},{"t":655361,"n":"COR_E_RUNTIMEWRAPPED","d":110688,"h":266288083040,"f":4194344},{"t":655361,"n":"COR_E_SAFEARRAYRANKMISMATCH","d":110688,"h":270583050336,"f":4194344},{"t":655361,"n":"COR_E_SAFEARRAYTYPEMISMATCH","d":110688,"h":274878017632,"f":4194344},{"t":655361,"n":"COR_E_SECURITY","d":110688,"h":279172984928,"f":4194344},{"t":655361,"n":"COR_E_SERIALIZATION","d":110688,"h":283467952224,"f":4194344},{"t":655361,"n":"COR_E_STACKOVERFLOW","d":110688,"h":287762919520,"f":4194344},{"t":655361,"n":"COR_E_SYNCHRONIZATIONLOCK","d":110688,"h":292057886816,"f":4194344},{"t":655361,"n":"COR_E_SYSTEM","d":110688,"h":296352854112,"f":4194344},{"t":655361,"n":"COR_E_TARGET","d":110688,"h":300647821408,"f":4194344},{"t":655361,"n":"COR_E_TARGETINVOCATION","d":110688,"h":304942788704,"f":4194344},{"t":655361,"n":"COR_E_TARGETPARAMCOUNT","d":110688,"h":309237756000,"f":4194344},{"t":655361,"n":"COR_E_THREADABORTED","d":110688,"h":313532723296,"f":4194344},{"t":655361,"n":"COR_E_THREADINTERRUPTED","d":110688,"h":317827690592,"f":4194344},{"t":655361,"n":"COR_E_THREADSTART","d":110688,"h":322122657888,"f":4194344},{"t":655361,"n":"COR_E_THREADSTATE","d":110688,"h":326417625184,"f":4194344},{"t":655361,"n":"COR_E_TIMEOUT","d":110688,"h":330712592480,"f":4194344},{"t":655361,"n":"COR_E_TYPEACCESS","d":110688,"h":335007559776,"f":4194344},{"t":655361,"n":"COR_E_TYPEINITIALIZATION","d":110688,"h":339302527072,"f":4194344},{"t":655361,"n":"COR_E_TYPELOAD","d":110688,"h":343597494368,"f":4194344},{"t":655361,"n":"COR_E_TYPEUNLOADED","d":110688,"h":347892461664,"f":4194344},{"t":655361,"n":"COR_E_UNAUTHORIZEDACCESS","d":110688,"h":352187428960,"f":4194344},{"t":655361,"n":"COR_E_VERIFICATION","d":110688,"h":356482396256,"f":4194344},{"t":655361,"n":"COR_E_WAITHANDLECANNOTBEOPENED","d":110688,"h":360777363552,"f":4194344},{"t":655361,"n":"CO_E_NOTINITIALIZED","d":110688,"h":365072330848,"f":4194344},{"t":655361,"n":"DISP_E_PARAMNOTFOUND","d":110688,"h":369367298144,"f":4194344},{"t":655361,"n":"DISP_E_TYPEMISMATCH","d":110688,"h":373662265440,"f":4194344},{"t":655361,"n":"DISP_E_BADVARTYPE","d":110688,"h":377957232736,"f":4194344},{"t":655361,"n":"DISP_E_OVERFLOW","d":110688,"h":382252200032,"f":4194344},{"t":655361,"n":"DISP_E_DIVBYZERO","d":110688,"h":386547167328,"f":4194344},{"t":655361,"n":"E_BOUNDS","d":110688,"h":390842134624,"f":4194344},{"t":655361,"n":"E_CHANGED_STATE","d":110688,"h":395137101920,"f":4194344},{"t":655361,"n":"E_FILENOTFOUND","d":110688,"h":399432069216,"f":4194344},{"t":655361,"n":"E_FAIL","d":110688,"h":403727036512,"f":4194344},{"t":655361,"n":"E_HANDLE","d":110688,"h":408022003808,"f":4194344},{"t":655361,"n":"E_INVALIDARG","d":110688,"h":412316971104,"f":4194344},{"t":655361,"n":"E_NOTIMPL","d":110688,"h":416611938400,"f":4194344},{"t":655361,"n":"E_OUTOFMEMORY","d":110688,"h":420906905696,"f":4194344},{"t":655361,"n":"E_POINTER","d":110688,"h":425201872992,"f":4194344},{"t":655361,"n":"ERROR_MRM_MAP_NOT_FOUND","d":110688,"h":429496840288,"f":4194344},{"t":655361,"n":"ERROR_TIMEOUT","d":110688,"h":433791807584,"f":4194344},{"t":655361,"n":"RO_E_CLOSED","d":110688,"h":438086774880,"f":4194344},{"t":655361,"n":"RPC_E_CHANGED_MODE","d":110688,"h":442381742176,"f":4194344},{"t":655361,"n":"TYPE_E_TYPEMISMATCH","d":110688,"h":446676709472,"f":4194344},{"t":655361,"n":"STG_E_PATHNOTFOUND","d":110688,"h":450971676768,"f":4194344},{"t":655361,"n":"CTL_E_PATHNOTFOUND","d":110688,"h":455266644064,"f":4194344},{"t":655361,"n":"CTL_E_FILENOTFOUND","d":110688,"h":459561611360,"f":4194344},{"t":655361,"n":"FUSION_E_INVALID_NAME","d":110688,"h":463856578656,"f":4194344},{"t":655361,"n":"FUSION_E_REF_DEF_MISMATCH","d":110688,"h":468151545952,"f":4194344},{"t":655361,"n":"ERROR_TOO_MANY_OPEN_FILES","d":110688,"h":472446513248,"f":4194344},{"t":655361,"n":"ERROR_SHARING_VIOLATION","d":110688,"h":476741480544,"f":4194344},{"t":655361,"n":"ERROR_LOCK_VIOLATION","d":110688,"h":481036447840,"f":4194344},{"t":655361,"n":"ERROR_OPEN_FAILED","d":110688,"h":485331415136,"f":4194344},{"t":655361,"n":"ERROR_DISK_CORRUPT","d":110688,"h":489626382432,"f":4194344},{"t":655361,"n":"ERROR_UNRECOGNIZED_VOLUME","d":110688,"h":493921349728,"f":4194344},{"t":655361,"n":"ERROR_DLL_INIT_FAILED","d":110688,"h":498216317024,"f":4194344},{"t":655361,"n":"MSEE_E_ASSEMBLYLOADINPROGRESS","d":110688,"h":502511284320,"f":4194344},{"t":655361,"n":"ERROR_FILE_INVALID","d":110688,"h":506806251616,"f":4194344}],"h":110688}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.HResults`; }
        });
        
        $asm.$cls("$sifd.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 438368;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":438368,"h":4295405664,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":438368,"h":8590372960,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":438368,"h":12885340256,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":438368,"h":17180307552,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":438368,"h":21475274848,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityMessage","d":438368,"h":25770242144,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":438368,"h":30065209440,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":438368,"h":34360176736,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":438368,"h":38655144032,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":438368,"h":42950111328,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":438368,"h":47245078624,"f":4194344},{"t":1310721,"n":"ThreadAbortMessage","d":438368,"h":51540045920,"f":4194344},{"t":1310721,"n":"ThreadResetAbortMessage","d":438368,"h":55835013216,"f":4194344},{"t":1310721,"n":"ThreadAbortDiagId","d":438368,"h":60129980512,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":438368,"h":64424947808,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":438368,"h":68719915104,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":438368,"h":73014882400,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":438368,"h":77309849696,"f":4194344},{"t":1310721,"n":"AuthenticationManagerMessage","d":438368,"h":81604816992,"f":4194344},{"t":1310721,"n":"AuthenticationManagerDiagId","d":438368,"h":85899784288,"f":4194344},{"t":1310721,"n":"RemotingApisMessage","d":438368,"h":90194751584,"f":4194344},{"t":1310721,"n":"RemotingApisDiagId","d":438368,"h":94489718880,"f":4194344},{"t":1310721,"n":"BinaryFormatterMessage","d":438368,"h":98784686176,"f":4194344},{"t":1310721,"n":"BinaryFormatterDiagId","d":438368,"h":103079653472,"f":4194344},{"t":1310721,"n":"CodeBaseMessage","d":438368,"h":107374620768,"f":4194344},{"t":1310721,"n":"CodeBaseDiagId","d":438368,"h":111669588064,"f":4194344},{"t":1310721,"n":"EscapeUriStringMessage","d":438368,"h":115964555360,"f":4194344},{"t":1310721,"n":"EscapeUriStringDiagId","d":438368,"h":120259522656,"f":4194344},{"t":1310721,"n":"WebRequestMessage","d":438368,"h":124554489952,"f":4194344},{"t":1310721,"n":"WebRequestDiagId","d":438368,"h":128849457248,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":438368,"h":133144424544,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":438368,"h":137439391840,"f":4194344},{"t":1310721,"n":"GetContextInfoMessage","d":438368,"h":141734359136,"f":4194344},{"t":1310721,"n":"GetContextInfoDiagId","d":438368,"h":146029326432,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairMessage","d":438368,"h":150324293728,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":438368,"h":154619261024,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":438368,"h":158914228320,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":438368,"h":163209195616,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":438368,"h":167504162912,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":438368,"h":171799130208,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":438368,"h":176094097504,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":438368,"h":180389064800,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":438368,"h":184684032096,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":438368,"h":188978999392,"f":4194344},{"t":1310721,"n":"RijndaelMessage","d":438368,"h":193273966688,"f":4194344},{"t":1310721,"n":"RijndaelDiagId","d":438368,"h":197568933984,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":438368,"h":201863901280,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":438368,"h":206158868576,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":438368,"h":210453835872,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":438368,"h":214748803168,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":438368,"h":219043770464,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":438368,"h":223338737760,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableMessage","d":438368,"h":227633705056,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":438368,"h":231928672352,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyMessage","d":438368,"h":236223639648,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":438368,"h":240518606944,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":438368,"h":244813574240,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":438368,"h":249108541536,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":438368,"h":253403508832,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":438368,"h":257698476128,"f":4194344},{"t":1310721,"n":"UseManagedSha1Message","d":438368,"h":261993443424,"f":4194344},{"t":1310721,"n":"UseManagedSha1DiagId","d":438368,"h":266288410720,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":438368,"h":270583378016,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":438368,"h":274878345312,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":438368,"h":279173312608,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":438368,"h":283468279904,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":438368,"h":287763247200,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":438368,"h":292058214496,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":438368,"h":296353181792,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":438368,"h":300648149088,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":438368,"h":304943116384,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":438368,"h":309238083680,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":438368,"h":313533050976,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":438368,"h":317828018272,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersMessage","d":438368,"h":322122985568,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":438368,"h":326417952864,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":438368,"h":330712920160,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":438368,"h":335007887456,"f":4194344},{"t":1310721,"n":"TlsVersion10and11Message","d":438368,"h":339302854752,"f":4194344},{"t":1310721,"n":"TlsVersion10and11DiagId","d":438368,"h":343597822048,"f":4194344},{"t":1310721,"n":"EncryptionPolicyMessage","d":438368,"h":347892789344,"f":4194344},{"t":1310721,"n":"EncryptionPolicyDiagId","d":438368,"h":352187756640,"f":4194344},{"t":1310721,"n":"EccXmlExportImportMessage","d":438368,"h":356482723936,"f":4194344},{"t":1310721,"n":"EccXmlExportImportDiagId","d":438368,"h":360777691232,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":438368,"h":365072658528,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":438368,"h":369367625824,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":438368,"h":373662593120,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":438368,"h":377957560416,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryMessage","d":438368,"h":382252527712,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":438368,"h":386547495008,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunMessage","d":438368,"h":390842462304,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":438368,"h":395137429600,"f":4194344},{"t":1310721,"n":"XmlSecureResolverMessage","d":438368,"h":399432396896,"f":4194344},{"t":1310721,"n":"XmlSecureResolverDiagId","d":438368,"h":403727364192,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":438368,"h":408022331488,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":438368,"h":412317298784,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":438368,"h":416612266080,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":438368,"h":420907233376,"f":4194344},{"t":1310721,"n":"LegacyFormatterMessage","d":438368,"h":425202200672,"f":4194344},{"t":1310721,"n":"LegacyFormatterDiagId","d":438368,"h":429497167968,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplMessage","d":438368,"h":433792135264,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":438368,"h":438087102560,"f":4194344},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":438368,"h":442382069856,"f":4194344},{"t":1310721,"n":"RegexExtensibilityDiagId","d":438368,"h":446677037152,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":438368,"h":450972004448,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":438368,"h":455266971744,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":438368,"h":459561939040,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":438368,"h":463856906336,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":438368,"h":468151873632,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":438368,"h":472446840928,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":438368,"h":476741808224,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":438368,"h":481036775520,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":438368,"h":485331742816,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":438368,"h":489626710112,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":438368,"h":493921677408,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":438368,"h":498216644704,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":438368,"h":502511612000,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":438368,"h":506806579296,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":438368,"h":511101546592,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":438368,"h":515396513888,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":438368,"h":519691481184,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":438368,"h":523986448480,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":438368,"h":528281415776,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":438368,"h":532576383072,"f":4194344}],"h":438368}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$sifd.System.SR", ($self) => class SR
        {
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sifd.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sifd.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sifd.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sifd.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sifd.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$sifd.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.IO.FileSystem.DriveInfo", $.$sifd.System.SR.$type.Assembly);
                    $.$sifd.System.SR.s_resourceManager = temp;
                }
                return $.$sifd.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sifd.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sifd.System.SR.resourceCulture = value;
            }
            static /*string */ get Arg_MustBeDriveLetterOrRootDir()
            {
                return "Drive name must be a root directory (i.e. 'C:\\') or a drive letter ('C').";
            }
            static /*string */ get Arg_MustBeNonEmptyDriveName()
            {
                return "Drive name must not be empty.";
            }
            static /*string */ get Arg_InvalidDriveChars()
            {
                return "Illegal characters in drive name '{0}'.";
            }
            static /*string */ FormatArg_InvalidDriveChars(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Illegal characters in drive name '{0}'.", arg1);
            }
            static /*string */ get Argument_InvalidPathChars()
            {
                return "Illegal characters in path '{0}'.";
            }
            static /*string */ FormatArgument_InvalidPathChars(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Illegal characters in path '{0}'.", arg1);
            }
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                return "Specified file length was too large for the file system.";
            }
            static /*string */ get InvalidOperation_SetVolumeLabelFailed()
            {
                return "Volume labels can only be set for writable local volumes.";
            }
            static /*string */ get IO_AlreadyExists_Name()
            {
                return "Cannot create '{0}' because a file or directory with the same name already exists.";
            }
            static /*string */ FormatIO_AlreadyExists_Name(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot create '{0}' because a file or directory with the same name already exists.", arg1);
            }
            static /*string */ get IO_DriveNotFound()
            {
                return "Could not find the drive. The drive might not be ready or might not be mapped.";
            }
            static /*string */ get IO_DriveNotFound_Drive()
            {
                return "Could not find the drive '{0}'. The drive might not be ready or might not be mapped.";
            }
            static /*string */ FormatIO_DriveNotFound_Drive(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Could not find the drive '{0}'. The drive might not be ready or might not be mapped.", arg1);
            }
            static /*string */ get IO_FileExists_Name()
            {
                return "The file '{0}' already exists.";
            }
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The file '{0}' already exists.", arg1);
            }
            static /*string */ get IO_FileNotFound()
            {
                return "Unable to find the specified file.";
            }
            static /*string */ get IO_FileNotFound_FileName()
            {
                return "Could not find file '{0}'.";
            }
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Could not find file '{0}'.", arg1);
            }
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                return "Could not find a part of the path.";
            }
            static /*string */ get IO_PathNotFound_Path()
            {
                return "Could not find a part of the path '{0}'.";
            }
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Could not find a part of the path '{0}'.", arg1);
            }
            static /*string */ get IO_PathTooLong()
            {
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            static /*string */ get IO_SharingViolation_File()
            {
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                return "The process cannot access the file because it is being used by another process.";
            }
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                return "Access to the path is denied.";
            }
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                return "Access to the path '{0}' is denied.";
            }
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Access to the path '{0}' is denied.", arg1);
            }
            static /*string */ get IO_PathTooLong_Path()
            {
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sifd.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 503904;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":503904}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sifd.System.IO.DriveInfo", ($self) => class DriveInfo extends $.$$.System.Object
        {
            /*DriveType */ get DriveType()
            {
                return 0/*DriveType.Unknown*/;
            }
            /*string */ get DriveFormat()
            {
                return "memfs";
            }
            /*long */ get AvailableFreeSpace()
            {
                return 0n;
            }
            /*long */ get TotalFreeSpace()
            {
                return 0n;
            }
            /*long */ get TotalSize()
            {
                return 0n;
            }
            static /*string[] */ GetMountPoints()
            {
                return $.$$.System.Environment.GetLogicalDrives();
            }
            static /*DriveInfo[] */ GetDrives()
            {
                /*string[]*/ let mountPoints = $.$sifd.System.IO.DriveInfo.GetMountPoints();
                /*DriveInfo[]*/ let info = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sifd.System.IO.DriveInfo), null, [mountPoints.length], null);
                for(/*int*/ let i = 0; i < info.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call(info, new $.$sifd.System.IO.DriveInfo().$ctor$1($.$$.System.Array.$ReadT1.call(mountPoints, i)), i);
                }
                return info;
            }
            static /*string */ NormalizeDriveName(/*string*/ driveName)
            {
                if ($.$$.System.String.Contains$1.call(driveName, /*\u0000*/ 0))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sifd.System.SR.Format$6($.$sifd.System.SR.Arg_InvalidDriveChars, driveName), "driveName");
                }
                if (driveName.length === 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sifd.System.SR.Arg_MustBeNonEmptyDriveName, "driveName");
                }
                return driveName;
            }
            /*string */ get VolumeLabel()
            {
                return this.Name;
            }
            /*string */ set VolumeLabel(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string*/ _name = null;
            $ctor$1(/*string*/ driveName)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(driveName, "driveName");
                    this._name = $.$sifd.System.IO.DriveInfo.NormalizeDriveName(driveName);
                }
                return this;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                return this._name;
            }
            /*bool */ get IsReady()
            {
                return $.$$.System.IO.Directory.Exists(this.Name);
            }
            /*DirectoryInfo */ get RootDirectory()
            {
                return new $.$$.System.IO.DirectoryInfo().$ctor$5(this.Name);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.Name;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sifd.System.IO.DriveInfo.ToString.apply(this, arguments); }
            static $h = 176224;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":307296,"g":{"r":0,"d":0,"h":8590110816,"f":50331649},"n":"DriveType","d":176224,"h":4295143520,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":17180045408,"f":50331649},"n":"DriveFormat","d":176224,"h":12885078112,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":25769980000,"f":50331649},"n":"AvailableFreeSpace","d":176224,"h":21475012704,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":34359914592,"f":50331649},"n":"TotalFreeSpace","d":176224,"h":30064947296,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":42949849184,"f":50331649},"n":"TotalSize","d":176224,"h":38654881888,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":64424685664,"f":50331649},"s":{"r":0,"d":0,"h":68719652960,"f":83886081,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},"n":"VolumeLabel","d":176224,"h":60129718368,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":90194489440,"f":50331649},"n":"Name","d":176224,"h":85899522144,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":98784424032,"f":50331649},"n":"IsReady","d":176224,"h":94489456736,"f":2097153},{"p":58720257,"g":{"r":0,"d":0,"h":107374358624,"f":50331649},"n":"RootDirectory","d":176224,"h":103079391328,"f":2097153}],"m":[{"r":$.$typeArray($.$$.System.String).$h,"n":"GetMountPoints","d":176224,"h":47244816480,"f":16777250},{"r":$.$typeArray($.$sifd.System.IO.DriveInfo).$h,"n":"GetDrives","d":176224,"h":51539783776,"f":16777249},{"r":1310721,"p":[{"n":"driveName","p":1310721}],"n":"NormalizeDriveName","d":176224,"h":55834751072,"f":16777250},{"r":1310721,"n":"ToString","d":176224,"h":111669325920,"f":16809985}],"l":[{"t":1310721,"n":"_name","d":176224,"h":73014620256,"f":4194306}],"c":[{"p":[{"n":"driveName","p":1310721}],"n":".ctor","o":"$ctor$1","d":176224,"h":77309587552,"f":16777217}],"i":[113246209],"h":176224}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.DriveInfo`; }
        });
        
        $asm.$str("$sifd.System.IO.DriveType", ($self) => class DriveType extends $.$$.System.Enum
        {
            static Unknown = 0;
            static NoRootDirectory = 1;
            static Removable = 2;
            static Fixed = 3;
            static Network = 4;
            static CDRom = 5;
            static Ram = 6;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "NoRootDirectory": 1n,
                    "Removable": 2n,
                    "Fixed": 3n,
                    "Network": 4n,
                    "CDRom": 5n,
                    "Ram": 6n
                };
            }
            static $h = 307296;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":307296,"n":"Unknown","d":307296,"h":4295274592,"f":4194337},{"t":307296,"n":"NoRootDirectory","d":307296,"h":8590241888,"f":4194337},{"t":307296,"n":"Removable","d":307296,"h":12885209184,"f":4194337},{"t":307296,"n":"Fixed","d":307296,"h":17180176480,"f":4194337},{"t":307296,"n":"Network","d":307296,"h":21475143776,"f":4194337},{"t":307296,"n":"CDRom","d":307296,"h":25770111072,"f":4194337},{"t":307296,"n":"Ram","d":307296,"h":30065078368,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":307296,"h":34360045664,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":307296}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.DriveType`; }
        });
        
        $asm.$cls("$sifd.System.IO.DriveNotFoundException", ($self) => class DriveNotFoundException extends $.$$.System.IO.IOException
        {
            $ctor$14()
            {
                super.$ctor$13($.$sifd.System.SR.IO_DriveNotFound);
                {
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            $ctor$17(/*string?*/ message)
            {
                super.$ctor$13(message ?? $.$sifd.System.SR.IO_DriveNotFound);
                {
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            $ctor$16(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$sifd.System.SR.IO_DriveNotFound, innerException);
                {
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            $ctor$15(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$10(info, context);
                {
                }
                return this;
            }
            static $h = 241760;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":60751873,"h":241760}; }
            static get $b() { return $.$$.System.IO.IOException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.DriveNotFoundException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices"))