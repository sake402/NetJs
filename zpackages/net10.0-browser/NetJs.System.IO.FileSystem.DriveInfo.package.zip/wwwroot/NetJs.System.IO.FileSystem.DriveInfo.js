
//--TRIMMABLE-BOUNDARY-START(79)
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.FileSystem.DriveInfo", 
    {
  "h": 79,
  "f": "System.IO.FileSystem.DriveInfo",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 127664129,
      "c": 4422631425
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.IO.FileSystem.DriveInfo",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.IO.FileSystem.DriveInfo",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65615)
        $asm.$cls("$sifd.System.HResults", ($self) => class HResults
        {
            //--TRIMMABLE-BOUNDARY-START(498216271951)
            /*int*/ static S_OK = 0;
            //--TRIMMABLE-BOUNDARY-END(498216271951)
            
            //--TRIMMABLE-BOUNDARY-START(493921304655)
            /*int*/ static S_FALSE = 1;
            //--TRIMMABLE-BOUNDARY-END(493921304655)
            
            //--TRIMMABLE-BOUNDARY-START(8590000207)
            /*int*/ static COR_E_ABANDONEDMUTEX = -2146233043;
            //--TRIMMABLE-BOUNDARY-END(8590000207)
            
            //--TRIMMABLE-BOUNDARY-START(12884967503)
            /*int*/ static COR_E_AMBIGUOUSIMPLEMENTATION = -2146234262;
            //--TRIMMABLE-BOUNDARY-END(12884967503)
            
            //--TRIMMABLE-BOUNDARY-START(17179934799)
            /*int*/ static COR_E_AMBIGUOUSMATCH = -2147475171;
            //--TRIMMABLE-BOUNDARY-END(17179934799)
            
            //--TRIMMABLE-BOUNDARY-START(21474902095)
            /*int*/ static COR_E_APPDOMAINUNLOADED = -2146234348;
            //--TRIMMABLE-BOUNDARY-END(21474902095)
            
            //--TRIMMABLE-BOUNDARY-START(25769869391)
            /*int*/ static COR_E_APPLICATION = -2146232832;
            //--TRIMMABLE-BOUNDARY-END(25769869391)
            
            //--TRIMMABLE-BOUNDARY-START(30064836687)
            /*int*/ static COR_E_ARGUMENT = -2147024809;
            //--TRIMMABLE-BOUNDARY-END(30064836687)
            
            //--TRIMMABLE-BOUNDARY-START(34359803983)
            /*int*/ static COR_E_ARGUMENTOUTOFRANGE = -2146233086;
            //--TRIMMABLE-BOUNDARY-END(34359803983)
            
            //--TRIMMABLE-BOUNDARY-START(38654771279)
            /*int*/ static COR_E_ARITHMETIC = -2147024362;
            //--TRIMMABLE-BOUNDARY-END(38654771279)
            
            //--TRIMMABLE-BOUNDARY-START(42949738575)
            /*int*/ static COR_E_ARRAYTYPEMISMATCH = -2146233085;
            //--TRIMMABLE-BOUNDARY-END(42949738575)
            
            //--TRIMMABLE-BOUNDARY-START(47244705871)
            /*int*/ static COR_E_BADEXEFORMAT = -2147024703;
            //--TRIMMABLE-BOUNDARY-END(47244705871)
            
            //--TRIMMABLE-BOUNDARY-START(51539673167)
            /*int*/ static COR_E_BADIMAGEFORMAT = -2147024885;
            //--TRIMMABLE-BOUNDARY-END(51539673167)
            
            //--TRIMMABLE-BOUNDARY-START(55834640463)
            /*int*/ static COR_E_CANNOTUNLOADAPPDOMAIN = -2146234347;
            //--TRIMMABLE-BOUNDARY-END(55834640463)
            
            //--TRIMMABLE-BOUNDARY-START(60129607759)
            /*int*/ static COR_E_CODECONTRACTFAILED = -2146233022;
            //--TRIMMABLE-BOUNDARY-END(60129607759)
            
            //--TRIMMABLE-BOUNDARY-START(64424575055)
            /*int*/ static COR_E_CONTEXTMARSHAL = -2146233084;
            //--TRIMMABLE-BOUNDARY-END(64424575055)
            
            //--TRIMMABLE-BOUNDARY-START(68719542351)
            /*int*/ static COR_E_CUSTOMATTRIBUTEFORMAT = -2146232827;
            //--TRIMMABLE-BOUNDARY-END(68719542351)
            
            //--TRIMMABLE-BOUNDARY-START(73014509647)
            /*int*/ static COR_E_DATAMISALIGNED = -2146233023;
            //--TRIMMABLE-BOUNDARY-END(73014509647)
            
            //--TRIMMABLE-BOUNDARY-START(77309476943)
            /*int*/ static COR_E_DIRECTORYNOTFOUND = -2147024893;
            //--TRIMMABLE-BOUNDARY-END(77309476943)
            
            //--TRIMMABLE-BOUNDARY-START(81604444239)
            /*int*/ static COR_E_DIVIDEBYZERO = -2147352558;
            //--TRIMMABLE-BOUNDARY-END(81604444239)
            
            //--TRIMMABLE-BOUNDARY-START(85899411535)
            /*int*/ static COR_E_DLLNOTFOUND = -2146233052;
            //--TRIMMABLE-BOUNDARY-END(85899411535)
            
            //--TRIMMABLE-BOUNDARY-START(90194378831)
            /*int*/ static COR_E_DUPLICATEWAITOBJECT = -2146233047;
            //--TRIMMABLE-BOUNDARY-END(90194378831)
            
            //--TRIMMABLE-BOUNDARY-START(94489346127)
            /*int*/ static COR_E_ENDOFSTREAM = -2147024858;
            //--TRIMMABLE-BOUNDARY-END(94489346127)
            
            //--TRIMMABLE-BOUNDARY-START(98784313423)
            /*int*/ static COR_E_ENTRYPOINTNOTFOUND = -2146233053;
            //--TRIMMABLE-BOUNDARY-END(98784313423)
            
            //--TRIMMABLE-BOUNDARY-START(103079280719)
            /*int*/ static COR_E_EXCEPTION = -2146233088;
            //--TRIMMABLE-BOUNDARY-END(103079280719)
            
            //--TRIMMABLE-BOUNDARY-START(107374248015)
            /*int*/ static COR_E_EXECUTIONENGINE = -2146233082;
            //--TRIMMABLE-BOUNDARY-END(107374248015)
            
            //--TRIMMABLE-BOUNDARY-START(111669215311)
            /*int*/ static COR_E_FAILFAST = -2146232797;
            //--TRIMMABLE-BOUNDARY-END(111669215311)
            
            //--TRIMMABLE-BOUNDARY-START(115964182607)
            /*int*/ static COR_E_FIELDACCESS = -2146233081;
            //--TRIMMABLE-BOUNDARY-END(115964182607)
            
            //--TRIMMABLE-BOUNDARY-START(120259149903)
            /*int*/ static COR_E_FILELOAD = -2146232799;
            //--TRIMMABLE-BOUNDARY-END(120259149903)
            
            //--TRIMMABLE-BOUNDARY-START(124554117199)
            /*int*/ static COR_E_FILENOTFOUND = -2147024894;
            //--TRIMMABLE-BOUNDARY-END(124554117199)
            
            //--TRIMMABLE-BOUNDARY-START(128849084495)
            /*int*/ static COR_E_FORMAT = -2146233033;
            //--TRIMMABLE-BOUNDARY-END(128849084495)
            
            //--TRIMMABLE-BOUNDARY-START(133144051791)
            /*int*/ static COR_E_INDEXOUTOFRANGE = -2146233080;
            //--TRIMMABLE-BOUNDARY-END(133144051791)
            
            //--TRIMMABLE-BOUNDARY-START(137439019087)
            /*int*/ static COR_E_INSUFFICIENTEXECUTIONSTACK = -2146232968;
            //--TRIMMABLE-BOUNDARY-END(137439019087)
            
            //--TRIMMABLE-BOUNDARY-START(141733986383)
            /*int*/ static COR_E_INSUFFICIENTMEMORY = -2146233027;
            //--TRIMMABLE-BOUNDARY-END(141733986383)
            
            //--TRIMMABLE-BOUNDARY-START(146028953679)
            /*int*/ static COR_E_INVALIDCAST = -2147467262;
            //--TRIMMABLE-BOUNDARY-END(146028953679)
            
            //--TRIMMABLE-BOUNDARY-START(150323920975)
            /*int*/ static COR_E_INVALIDCOMOBJECT = -2146233049;
            //--TRIMMABLE-BOUNDARY-END(150323920975)
            
            //--TRIMMABLE-BOUNDARY-START(154618888271)
            /*int*/ static COR_E_INVALIDFILTERCRITERIA = -2146232831;
            //--TRIMMABLE-BOUNDARY-END(154618888271)
            
            //--TRIMMABLE-BOUNDARY-START(158913855567)
            /*int*/ static COR_E_INVALIDOLEVARIANTTYPE = -2146233039;
            //--TRIMMABLE-BOUNDARY-END(158913855567)
            
            //--TRIMMABLE-BOUNDARY-START(163208822863)
            /*int*/ static COR_E_INVALIDOPERATION = -2146233079;
            //--TRIMMABLE-BOUNDARY-END(163208822863)
            
            //--TRIMMABLE-BOUNDARY-START(167503790159)
            /*int*/ static COR_E_INVALIDPROGRAM = -2146233030;
            //--TRIMMABLE-BOUNDARY-END(167503790159)
            
            //--TRIMMABLE-BOUNDARY-START(171798757455)
            /*int*/ static COR_E_IO = -2146232800;
            //--TRIMMABLE-BOUNDARY-END(171798757455)
            
            //--TRIMMABLE-BOUNDARY-START(176093724751)
            /*int*/ static COR_E_KEYNOTFOUND = -2146232969;
            //--TRIMMABLE-BOUNDARY-END(176093724751)
            
            //--TRIMMABLE-BOUNDARY-START(180388692047)
            /*int*/ static COR_E_MARSHALDIRECTIVE = -2146233035;
            //--TRIMMABLE-BOUNDARY-END(180388692047)
            
            //--TRIMMABLE-BOUNDARY-START(184683659343)
            /*int*/ static COR_E_MEMBERACCESS = -2146233062;
            //--TRIMMABLE-BOUNDARY-END(184683659343)
            
            //--TRIMMABLE-BOUNDARY-START(188978626639)
            /*int*/ static COR_E_METHODACCESS = -2146233072;
            //--TRIMMABLE-BOUNDARY-END(188978626639)
            
            //--TRIMMABLE-BOUNDARY-START(193273593935)
            /*int*/ static COR_E_MISSINGFIELD = -2146233071;
            //--TRIMMABLE-BOUNDARY-END(193273593935)
            
            //--TRIMMABLE-BOUNDARY-START(197568561231)
            /*int*/ static COR_E_MISSINGMANIFESTRESOURCE = -2146233038;
            //--TRIMMABLE-BOUNDARY-END(197568561231)
            
            //--TRIMMABLE-BOUNDARY-START(201863528527)
            /*int*/ static COR_E_MISSINGMEMBER = -2146233070;
            //--TRIMMABLE-BOUNDARY-END(201863528527)
            
            //--TRIMMABLE-BOUNDARY-START(206158495823)
            /*int*/ static COR_E_MISSINGMETHOD = -2146233069;
            //--TRIMMABLE-BOUNDARY-END(206158495823)
            
            //--TRIMMABLE-BOUNDARY-START(210453463119)
            /*int*/ static COR_E_MISSINGSATELLITEASSEMBLY = -2146233034;
            //--TRIMMABLE-BOUNDARY-END(210453463119)
            
            //--TRIMMABLE-BOUNDARY-START(214748430415)
            /*int*/ static COR_E_MULTICASTNOTSUPPORTED = -2146233068;
            //--TRIMMABLE-BOUNDARY-END(214748430415)
            
            //--TRIMMABLE-BOUNDARY-START(219043397711)
            /*int*/ static COR_E_NOTFINITENUMBER = -2146233048;
            //--TRIMMABLE-BOUNDARY-END(219043397711)
            
            //--TRIMMABLE-BOUNDARY-START(223338365007)
            /*int*/ static COR_E_NOTSUPPORTED = -2146233067;
            //--TRIMMABLE-BOUNDARY-END(223338365007)
            
            //--TRIMMABLE-BOUNDARY-START(227633332303)
            /*int*/ static COR_E_OBJECTDISPOSED = -2146232798;
            //--TRIMMABLE-BOUNDARY-END(227633332303)
            
            //--TRIMMABLE-BOUNDARY-START(231928299599)
            /*int*/ static COR_E_OPERATIONCANCELED = -2146233029;
            //--TRIMMABLE-BOUNDARY-END(231928299599)
            
            //--TRIMMABLE-BOUNDARY-START(236223266895)
            /*int*/ static COR_E_OUTOFMEMORY = -2147024882;
            //--TRIMMABLE-BOUNDARY-END(236223266895)
            
            //--TRIMMABLE-BOUNDARY-START(240518234191)
            /*int*/ static COR_E_OVERFLOW = -2146233066;
            //--TRIMMABLE-BOUNDARY-END(240518234191)
            
            //--TRIMMABLE-BOUNDARY-START(244813201487)
            /*int*/ static COR_E_PATHTOOLONG = -2147024690;
            //--TRIMMABLE-BOUNDARY-END(244813201487)
            
            //--TRIMMABLE-BOUNDARY-START(249108168783)
            /*int*/ static COR_E_PLATFORMNOTSUPPORTED = -2146233031;
            //--TRIMMABLE-BOUNDARY-END(249108168783)
            
            //--TRIMMABLE-BOUNDARY-START(253403136079)
            /*int*/ static COR_E_RANK = -2146233065;
            //--TRIMMABLE-BOUNDARY-END(253403136079)
            
            //--TRIMMABLE-BOUNDARY-START(257698103375)
            /*int*/ static COR_E_REFLECTIONTYPELOAD = -2146232830;
            //--TRIMMABLE-BOUNDARY-END(257698103375)
            
            //--TRIMMABLE-BOUNDARY-START(261993070671)
            /*int*/ static COR_E_RUNTIMEWRAPPED = -2146233026;
            //--TRIMMABLE-BOUNDARY-END(261993070671)
            
            //--TRIMMABLE-BOUNDARY-START(266288037967)
            /*int*/ static COR_E_SAFEARRAYRANKMISMATCH = -2146233032;
            //--TRIMMABLE-BOUNDARY-END(266288037967)
            
            //--TRIMMABLE-BOUNDARY-START(270583005263)
            /*int*/ static COR_E_SAFEARRAYTYPEMISMATCH = -2146233037;
            //--TRIMMABLE-BOUNDARY-END(270583005263)
            
            //--TRIMMABLE-BOUNDARY-START(274877972559)
            /*int*/ static COR_E_SECURITY = -2146233078;
            //--TRIMMABLE-BOUNDARY-END(274877972559)
            
            //--TRIMMABLE-BOUNDARY-START(279172939855)
            /*int*/ static COR_E_SERIALIZATION = -2146233076;
            //--TRIMMABLE-BOUNDARY-END(279172939855)
            
            //--TRIMMABLE-BOUNDARY-START(283467907151)
            /*int*/ static COR_E_STACKOVERFLOW = -2147023895;
            //--TRIMMABLE-BOUNDARY-END(283467907151)
            
            //--TRIMMABLE-BOUNDARY-START(287762874447)
            /*int*/ static COR_E_SYNCHRONIZATIONLOCK = -2146233064;
            //--TRIMMABLE-BOUNDARY-END(287762874447)
            
            //--TRIMMABLE-BOUNDARY-START(292057841743)
            /*int*/ static COR_E_SYSTEM = -2146233087;
            //--TRIMMABLE-BOUNDARY-END(292057841743)
            
            //--TRIMMABLE-BOUNDARY-START(296352809039)
            /*int*/ static COR_E_TARGET = -2146232829;
            //--TRIMMABLE-BOUNDARY-END(296352809039)
            
            //--TRIMMABLE-BOUNDARY-START(300647776335)
            /*int*/ static COR_E_TARGETINVOCATION = -2146232828;
            //--TRIMMABLE-BOUNDARY-END(300647776335)
            
            //--TRIMMABLE-BOUNDARY-START(304942743631)
            /*int*/ static COR_E_TARGETPARAMCOUNT = -2147352562;
            //--TRIMMABLE-BOUNDARY-END(304942743631)
            
            //--TRIMMABLE-BOUNDARY-START(309237710927)
            /*int*/ static COR_E_THREADABORTED = -2146233040;
            //--TRIMMABLE-BOUNDARY-END(309237710927)
            
            //--TRIMMABLE-BOUNDARY-START(313532678223)
            /*int*/ static COR_E_THREADINTERRUPTED = -2146233063;
            //--TRIMMABLE-BOUNDARY-END(313532678223)
            
            //--TRIMMABLE-BOUNDARY-START(317827645519)
            /*int*/ static COR_E_THREADSTART = -2146233051;
            //--TRIMMABLE-BOUNDARY-END(317827645519)
            
            //--TRIMMABLE-BOUNDARY-START(322122612815)
            /*int*/ static COR_E_THREADSTATE = -2146233056;
            //--TRIMMABLE-BOUNDARY-END(322122612815)
            
            //--TRIMMABLE-BOUNDARY-START(326417580111)
            /*int*/ static COR_E_TIMEOUT = -2146233083;
            //--TRIMMABLE-BOUNDARY-END(326417580111)
            
            //--TRIMMABLE-BOUNDARY-START(330712547407)
            /*int*/ static COR_E_TYPEACCESS = -2146233021;
            //--TRIMMABLE-BOUNDARY-END(330712547407)
            
            //--TRIMMABLE-BOUNDARY-START(335007514703)
            /*int*/ static COR_E_TYPEINITIALIZATION = -2146233036;
            //--TRIMMABLE-BOUNDARY-END(335007514703)
            
            //--TRIMMABLE-BOUNDARY-START(339302481999)
            /*int*/ static COR_E_TYPELOAD = -2146233054;
            //--TRIMMABLE-BOUNDARY-END(339302481999)
            
            //--TRIMMABLE-BOUNDARY-START(343597449295)
            /*int*/ static COR_E_TYPEUNLOADED = -2146234349;
            //--TRIMMABLE-BOUNDARY-END(343597449295)
            
            //--TRIMMABLE-BOUNDARY-START(347892416591)
            /*int*/ static COR_E_UNAUTHORIZEDACCESS = -2147024891;
            //--TRIMMABLE-BOUNDARY-END(347892416591)
            
            //--TRIMMABLE-BOUNDARY-START(352187383887)
            /*int*/ static COR_E_VERIFICATION = -2146233075;
            //--TRIMMABLE-BOUNDARY-END(352187383887)
            
            //--TRIMMABLE-BOUNDARY-START(356482351183)
            /*int*/ static COR_E_WAITHANDLECANNOTBEOPENED = -2146233044;
            //--TRIMMABLE-BOUNDARY-END(356482351183)
            
            //--TRIMMABLE-BOUNDARY-START(4295032911)
            /*int*/ static CO_E_NOTINITIALIZED = -2147221008;
            //--TRIMMABLE-BOUNDARY-END(4295032911)
            
            //--TRIMMABLE-BOUNDARY-START(382252154959)
            /*int*/ static DISP_E_PARAMNOTFOUND = -2147352572;
            //--TRIMMABLE-BOUNDARY-END(382252154959)
            
            //--TRIMMABLE-BOUNDARY-START(386547122255)
            /*int*/ static DISP_E_TYPEMISMATCH = -2147352571;
            //--TRIMMABLE-BOUNDARY-END(386547122255)
            
            //--TRIMMABLE-BOUNDARY-START(369367253071)
            /*int*/ static DISP_E_BADVARTYPE = -2147352568;
            //--TRIMMABLE-BOUNDARY-END(369367253071)
            
            //--TRIMMABLE-BOUNDARY-START(377957187663)
            /*int*/ static DISP_E_OVERFLOW = -2147352566;
            //--TRIMMABLE-BOUNDARY-END(377957187663)
            
            //--TRIMMABLE-BOUNDARY-START(373662220367)
            /*int*/ static DISP_E_DIVBYZERO = -2147352558;
            //--TRIMMABLE-BOUNDARY-END(373662220367)
            
            //--TRIMMABLE-BOUNDARY-START(390842089551)
            /*int*/ static E_BOUNDS = -2147483637;
            //--TRIMMABLE-BOUNDARY-END(390842089551)
            
            //--TRIMMABLE-BOUNDARY-START(395137056847)
            /*int*/ static E_CHANGED_STATE = -2147483636;
            //--TRIMMABLE-BOUNDARY-END(395137056847)
            
            //--TRIMMABLE-BOUNDARY-START(403726991439)
            /*int*/ static E_FILENOTFOUND = -2147024894;
            //--TRIMMABLE-BOUNDARY-END(403726991439)
            
            //--TRIMMABLE-BOUNDARY-START(399432024143)
            /*int*/ static E_FAIL = -2147467259;
            //--TRIMMABLE-BOUNDARY-END(399432024143)
            
            //--TRIMMABLE-BOUNDARY-START(408021958735)
            /*int*/ static E_HANDLE = -2147024890;
            //--TRIMMABLE-BOUNDARY-END(408021958735)
            
            //--TRIMMABLE-BOUNDARY-START(412316926031)
            /*int*/ static E_INVALIDARG = -2147024809;
            //--TRIMMABLE-BOUNDARY-END(412316926031)
            
            //--TRIMMABLE-BOUNDARY-START(416611893327)
            /*int*/ static E_NOTIMPL = -2147467263;
            //--TRIMMABLE-BOUNDARY-END(416611893327)
            
            //--TRIMMABLE-BOUNDARY-START(420906860623)
            /*int*/ static E_OUTOFMEMORY = -2147024882;
            //--TRIMMABLE-BOUNDARY-END(420906860623)
            
            //--TRIMMABLE-BOUNDARY-START(425201827919)
            /*int*/ static E_POINTER = -2147467261;
            //--TRIMMABLE-BOUNDARY-END(425201827919)
            
            //--TRIMMABLE-BOUNDARY-START(446676664399)
            /*int*/ static ERROR_MRM_MAP_NOT_FOUND = -2147009761;
            //--TRIMMABLE-BOUNDARY-END(446676664399)
            
            //--TRIMMABLE-BOUNDARY-START(459561566287)
            /*int*/ static ERROR_TIMEOUT = -2147023436;
            //--TRIMMABLE-BOUNDARY-END(459561566287)
            
            //--TRIMMABLE-BOUNDARY-START(485331370063)
            /*int*/ static RO_E_CLOSED = -2147483629;
            //--TRIMMABLE-BOUNDARY-END(485331370063)
            
            //--TRIMMABLE-BOUNDARY-START(489626337359)
            /*int*/ static RPC_E_CHANGED_MODE = -2147417850;
            //--TRIMMABLE-BOUNDARY-END(489626337359)
            
            //--TRIMMABLE-BOUNDARY-START(506806206543)
            /*int*/ static TYPE_E_TYPEMISMATCH = -2147316576;
            //--TRIMMABLE-BOUNDARY-END(506806206543)
            
            //--TRIMMABLE-BOUNDARY-START(502511239247)
            /*int*/ static STG_E_PATHNOTFOUND = -2147287037;
            //--TRIMMABLE-BOUNDARY-END(502511239247)
            
            //--TRIMMABLE-BOUNDARY-START(365072285775)
            /*int*/ static CTL_E_PATHNOTFOUND = -2146828212;
            //--TRIMMABLE-BOUNDARY-END(365072285775)
            
            //--TRIMMABLE-BOUNDARY-START(360777318479)
            /*int*/ static CTL_E_FILENOTFOUND = -2146828235;
            //--TRIMMABLE-BOUNDARY-END(360777318479)
            
            //--TRIMMABLE-BOUNDARY-START(472446468175)
            /*int*/ static FUSION_E_INVALID_NAME = -2146234297;
            //--TRIMMABLE-BOUNDARY-END(472446468175)
            
            //--TRIMMABLE-BOUNDARY-START(476741435471)
            /*int*/ static FUSION_E_REF_DEF_MISMATCH = -2146234304;
            //--TRIMMABLE-BOUNDARY-END(476741435471)
            
            //--TRIMMABLE-BOUNDARY-START(463856533583)
            /*int*/ static ERROR_TOO_MANY_OPEN_FILES = -2147024892;
            //--TRIMMABLE-BOUNDARY-END(463856533583)
            
            //--TRIMMABLE-BOUNDARY-START(455266598991)
            /*int*/ static ERROR_SHARING_VIOLATION = -2147024864;
            //--TRIMMABLE-BOUNDARY-END(455266598991)
            
            //--TRIMMABLE-BOUNDARY-START(442381697103)
            /*int*/ static ERROR_LOCK_VIOLATION = -2147024863;
            //--TRIMMABLE-BOUNDARY-END(442381697103)
            
            //--TRIMMABLE-BOUNDARY-START(450971631695)
            /*int*/ static ERROR_OPEN_FAILED = -2147024786;
            //--TRIMMABLE-BOUNDARY-END(450971631695)
            
            //--TRIMMABLE-BOUNDARY-START(429496795215)
            /*int*/ static ERROR_DISK_CORRUPT = -2147023503;
            //--TRIMMABLE-BOUNDARY-END(429496795215)
            
            //--TRIMMABLE-BOUNDARY-START(468151500879)
            /*int*/ static ERROR_UNRECOGNIZED_VOLUME = -2147023891;
            //--TRIMMABLE-BOUNDARY-END(468151500879)
            
            //--TRIMMABLE-BOUNDARY-START(433791762511)
            /*int*/ static ERROR_DLL_INIT_FAILED = -2147023782;
            //--TRIMMABLE-BOUNDARY-END(433791762511)
            
            //--TRIMMABLE-BOUNDARY-START(481036402767)
            /*int*/ static MSEE_E_ASSEMBLYLOADINPROGRESS = -2146234346;
            //--TRIMMABLE-BOUNDARY-END(481036402767)
            
            //--TRIMMABLE-BOUNDARY-START(438086729807)
            /*int*/ static ERROR_FILE_INVALID = -2147023890;
            //--TRIMMABLE-BOUNDARY-END(438086729807)
            
            static $h = 65615;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(498216271951),
    {
      "t": 655361,
      "n": "S_OK",
      "d": 65615,
      "h": 498216271951,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498216271951),
//--TRIMMABLE-BOUNDARY-START(493921304655),
    {
      "t": 655361,
      "n": "S_FALSE",
      "d": 65615,
      "h": 493921304655,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493921304655),
//--TRIMMABLE-BOUNDARY-START(8590000207),
    {
      "t": 655361,
      "n": "COR_E_ABANDONEDMUTEX",
      "d": 65615,
      "h": 8590000207,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590000207),
//--TRIMMABLE-BOUNDARY-START(12884967503),
    {
      "t": 655361,
      "n": "COR_E_AMBIGUOUSIMPLEMENTATION",
      "d": 65615,
      "h": 12884967503,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12884967503),
//--TRIMMABLE-BOUNDARY-START(17179934799),
    {
      "t": 655361,
      "n": "COR_E_AMBIGUOUSMATCH",
      "d": 65615,
      "h": 17179934799,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17179934799),
//--TRIMMABLE-BOUNDARY-START(21474902095),
    {
      "t": 655361,
      "n": "COR_E_APPDOMAINUNLOADED",
      "d": 65615,
      "h": 21474902095,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474902095),
//--TRIMMABLE-BOUNDARY-START(25769869391),
    {
      "t": 655361,
      "n": "COR_E_APPLICATION",
      "d": 65615,
      "h": 25769869391,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769869391),
//--TRIMMABLE-BOUNDARY-START(30064836687),
    {
      "t": 655361,
      "n": "COR_E_ARGUMENT",
      "d": 65615,
      "h": 30064836687,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30064836687),
//--TRIMMABLE-BOUNDARY-START(34359803983),
    {
      "t": 655361,
      "n": "COR_E_ARGUMENTOUTOFRANGE",
      "d": 65615,
      "h": 34359803983,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34359803983),
//--TRIMMABLE-BOUNDARY-START(38654771279),
    {
      "t": 655361,
      "n": "COR_E_ARITHMETIC",
      "d": 65615,
      "h": 38654771279,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38654771279),
//--TRIMMABLE-BOUNDARY-START(42949738575),
    {
      "t": 655361,
      "n": "COR_E_ARRAYTYPEMISMATCH",
      "d": 65615,
      "h": 42949738575,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42949738575),
//--TRIMMABLE-BOUNDARY-START(47244705871),
    {
      "t": 655361,
      "n": "COR_E_BADEXEFORMAT",
      "d": 65615,
      "h": 47244705871,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47244705871),
//--TRIMMABLE-BOUNDARY-START(51539673167),
    {
      "t": 655361,
      "n": "COR_E_BADIMAGEFORMAT",
      "d": 65615,
      "h": 51539673167,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51539673167),
//--TRIMMABLE-BOUNDARY-START(55834640463),
    {
      "t": 655361,
      "n": "COR_E_CANNOTUNLOADAPPDOMAIN",
      "d": 65615,
      "h": 55834640463,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834640463),
//--TRIMMABLE-BOUNDARY-START(60129607759),
    {
      "t": 655361,
      "n": "COR_E_CODECONTRACTFAILED",
      "d": 65615,
      "h": 60129607759,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60129607759),
//--TRIMMABLE-BOUNDARY-START(64424575055),
    {
      "t": 655361,
      "n": "COR_E_CONTEXTMARSHAL",
      "d": 65615,
      "h": 64424575055,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64424575055),
//--TRIMMABLE-BOUNDARY-START(68719542351),
    {
      "t": 655361,
      "n": "COR_E_CUSTOMATTRIBUTEFORMAT",
      "d": 65615,
      "h": 68719542351,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68719542351),
//--TRIMMABLE-BOUNDARY-START(73014509647),
    {
      "t": 655361,
      "n": "COR_E_DATAMISALIGNED",
      "d": 65615,
      "h": 73014509647,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73014509647),
//--TRIMMABLE-BOUNDARY-START(77309476943),
    {
      "t": 655361,
      "n": "COR_E_DIRECTORYNOTFOUND",
      "d": 65615,
      "h": 77309476943,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77309476943),
//--TRIMMABLE-BOUNDARY-START(81604444239),
    {
      "t": 655361,
      "n": "COR_E_DIVIDEBYZERO",
      "d": 65615,
      "h": 81604444239,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81604444239),
//--TRIMMABLE-BOUNDARY-START(85899411535),
    {
      "t": 655361,
      "n": "COR_E_DLLNOTFOUND",
      "d": 65615,
      "h": 85899411535,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85899411535),
//--TRIMMABLE-BOUNDARY-START(90194378831),
    {
      "t": 655361,
      "n": "COR_E_DUPLICATEWAITOBJECT",
      "d": 65615,
      "h": 90194378831,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90194378831),
//--TRIMMABLE-BOUNDARY-START(94489346127),
    {
      "t": 655361,
      "n": "COR_E_ENDOFSTREAM",
      "d": 65615,
      "h": 94489346127,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489346127),
//--TRIMMABLE-BOUNDARY-START(98784313423),
    {
      "t": 655361,
      "n": "COR_E_ENTRYPOINTNOTFOUND",
      "d": 65615,
      "h": 98784313423,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784313423),
//--TRIMMABLE-BOUNDARY-START(103079280719),
    {
      "t": 655361,
      "n": "COR_E_EXCEPTION",
      "d": 65615,
      "h": 103079280719,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103079280719),
//--TRIMMABLE-BOUNDARY-START(107374248015),
    {
      "t": 655361,
      "n": "COR_E_EXECUTIONENGINE",
      "d": 65615,
      "h": 107374248015,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107374248015),
//--TRIMMABLE-BOUNDARY-START(111669215311),
    {
      "t": 655361,
      "n": "COR_E_FAILFAST",
      "d": 65615,
      "h": 111669215311,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111669215311),
//--TRIMMABLE-BOUNDARY-START(115964182607),
    {
      "t": 655361,
      "n": "COR_E_FIELDACCESS",
      "d": 65615,
      "h": 115964182607,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115964182607),
//--TRIMMABLE-BOUNDARY-START(120259149903),
    {
      "t": 655361,
      "n": "COR_E_FILELOAD",
      "d": 65615,
      "h": 120259149903,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259149903),
//--TRIMMABLE-BOUNDARY-START(124554117199),
    {
      "t": 655361,
      "n": "COR_E_FILENOTFOUND",
      "d": 65615,
      "h": 124554117199,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554117199),
//--TRIMMABLE-BOUNDARY-START(128849084495),
    {
      "t": 655361,
      "n": "COR_E_FORMAT",
      "d": 65615,
      "h": 128849084495,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849084495),
//--TRIMMABLE-BOUNDARY-START(133144051791),
    {
      "t": 655361,
      "n": "COR_E_INDEXOUTOFRANGE",
      "d": 65615,
      "h": 133144051791,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133144051791),
//--TRIMMABLE-BOUNDARY-START(137439019087),
    {
      "t": 655361,
      "n": "COR_E_INSUFFICIENTEXECUTIONSTACK",
      "d": 65615,
      "h": 137439019087,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137439019087),
//--TRIMMABLE-BOUNDARY-START(141733986383),
    {
      "t": 655361,
      "n": "COR_E_INSUFFICIENTMEMORY",
      "d": 65615,
      "h": 141733986383,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141733986383),
//--TRIMMABLE-BOUNDARY-START(146028953679),
    {
      "t": 655361,
      "n": "COR_E_INVALIDCAST",
      "d": 65615,
      "h": 146028953679,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146028953679),
//--TRIMMABLE-BOUNDARY-START(150323920975),
    {
      "t": 655361,
      "n": "COR_E_INVALIDCOMOBJECT",
      "d": 65615,
      "h": 150323920975,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150323920975),
//--TRIMMABLE-BOUNDARY-START(154618888271),
    {
      "t": 655361,
      "n": "COR_E_INVALIDFILTERCRITERIA",
      "d": 65615,
      "h": 154618888271,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154618888271),
//--TRIMMABLE-BOUNDARY-START(158913855567),
    {
      "t": 655361,
      "n": "COR_E_INVALIDOLEVARIANTTYPE",
      "d": 65615,
      "h": 158913855567,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158913855567),
//--TRIMMABLE-BOUNDARY-START(163208822863),
    {
      "t": 655361,
      "n": "COR_E_INVALIDOPERATION",
      "d": 65615,
      "h": 163208822863,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163208822863),
//--TRIMMABLE-BOUNDARY-START(167503790159),
    {
      "t": 655361,
      "n": "COR_E_INVALIDPROGRAM",
      "d": 65615,
      "h": 167503790159,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167503790159),
//--TRIMMABLE-BOUNDARY-START(171798757455),
    {
      "t": 655361,
      "n": "COR_E_IO",
      "d": 65615,
      "h": 171798757455,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171798757455),
//--TRIMMABLE-BOUNDARY-START(176093724751),
    {
      "t": 655361,
      "n": "COR_E_KEYNOTFOUND",
      "d": 65615,
      "h": 176093724751,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176093724751),
//--TRIMMABLE-BOUNDARY-START(180388692047),
    {
      "t": 655361,
      "n": "COR_E_MARSHALDIRECTIVE",
      "d": 65615,
      "h": 180388692047,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180388692047),
//--TRIMMABLE-BOUNDARY-START(184683659343),
    {
      "t": 655361,
      "n": "COR_E_MEMBERACCESS",
      "d": 65615,
      "h": 184683659343,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184683659343),
//--TRIMMABLE-BOUNDARY-START(188978626639),
    {
      "t": 655361,
      "n": "COR_E_METHODACCESS",
      "d": 65615,
      "h": 188978626639,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188978626639),
//--TRIMMABLE-BOUNDARY-START(193273593935),
    {
      "t": 655361,
      "n": "COR_E_MISSINGFIELD",
      "d": 65615,
      "h": 193273593935,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193273593935),
//--TRIMMABLE-BOUNDARY-START(197568561231),
    {
      "t": 655361,
      "n": "COR_E_MISSINGMANIFESTRESOURCE",
      "d": 65615,
      "h": 197568561231,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197568561231),
//--TRIMMABLE-BOUNDARY-START(201863528527),
    {
      "t": 655361,
      "n": "COR_E_MISSINGMEMBER",
      "d": 65615,
      "h": 201863528527,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201863528527),
//--TRIMMABLE-BOUNDARY-START(206158495823),
    {
      "t": 655361,
      "n": "COR_E_MISSINGMETHOD",
      "d": 65615,
      "h": 206158495823,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206158495823),
//--TRIMMABLE-BOUNDARY-START(210453463119),
    {
      "t": 655361,
      "n": "COR_E_MISSINGSATELLITEASSEMBLY",
      "d": 65615,
      "h": 210453463119,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210453463119),
//--TRIMMABLE-BOUNDARY-START(214748430415),
    {
      "t": 655361,
      "n": "COR_E_MULTICASTNOTSUPPORTED",
      "d": 65615,
      "h": 214748430415,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214748430415),
//--TRIMMABLE-BOUNDARY-START(219043397711),
    {
      "t": 655361,
      "n": "COR_E_NOTFINITENUMBER",
      "d": 65615,
      "h": 219043397711,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219043397711),
//--TRIMMABLE-BOUNDARY-START(223338365007),
    {
      "t": 655361,
      "n": "COR_E_NOTSUPPORTED",
      "d": 65615,
      "h": 223338365007,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223338365007),
//--TRIMMABLE-BOUNDARY-START(227633332303),
    {
      "t": 655361,
      "n": "COR_E_OBJECTDISPOSED",
      "d": 65615,
      "h": 227633332303,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227633332303),
//--TRIMMABLE-BOUNDARY-START(231928299599),
    {
      "t": 655361,
      "n": "COR_E_OPERATIONCANCELED",
      "d": 65615,
      "h": 231928299599,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231928299599),
//--TRIMMABLE-BOUNDARY-START(236223266895),
    {
      "t": 655361,
      "n": "COR_E_OUTOFMEMORY",
      "d": 65615,
      "h": 236223266895,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236223266895),
//--TRIMMABLE-BOUNDARY-START(240518234191),
    {
      "t": 655361,
      "n": "COR_E_OVERFLOW",
      "d": 65615,
      "h": 240518234191,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240518234191),
//--TRIMMABLE-BOUNDARY-START(244813201487),
    {
      "t": 655361,
      "n": "COR_E_PATHTOOLONG",
      "d": 65615,
      "h": 244813201487,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244813201487),
//--TRIMMABLE-BOUNDARY-START(249108168783),
    {
      "t": 655361,
      "n": "COR_E_PLATFORMNOTSUPPORTED",
      "d": 65615,
      "h": 249108168783,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249108168783),
//--TRIMMABLE-BOUNDARY-START(253403136079),
    {
      "t": 655361,
      "n": "COR_E_RANK",
      "d": 65615,
      "h": 253403136079,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253403136079),
//--TRIMMABLE-BOUNDARY-START(257698103375),
    {
      "t": 655361,
      "n": "COR_E_REFLECTIONTYPELOAD",
      "d": 65615,
      "h": 257698103375,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257698103375),
//--TRIMMABLE-BOUNDARY-START(261993070671),
    {
      "t": 655361,
      "n": "COR_E_RUNTIMEWRAPPED",
      "d": 65615,
      "h": 261993070671,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261993070671),
//--TRIMMABLE-BOUNDARY-START(266288037967),
    {
      "t": 655361,
      "n": "COR_E_SAFEARRAYRANKMISMATCH",
      "d": 65615,
      "h": 266288037967,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266288037967),
//--TRIMMABLE-BOUNDARY-START(270583005263),
    {
      "t": 655361,
      "n": "COR_E_SAFEARRAYTYPEMISMATCH",
      "d": 65615,
      "h": 270583005263,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270583005263),
//--TRIMMABLE-BOUNDARY-START(274877972559),
    {
      "t": 655361,
      "n": "COR_E_SECURITY",
      "d": 65615,
      "h": 274877972559,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274877972559),
//--TRIMMABLE-BOUNDARY-START(279172939855),
    {
      "t": 655361,
      "n": "COR_E_SERIALIZATION",
      "d": 65615,
      "h": 279172939855,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279172939855),
//--TRIMMABLE-BOUNDARY-START(283467907151),
    {
      "t": 655361,
      "n": "COR_E_STACKOVERFLOW",
      "d": 65615,
      "h": 283467907151,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283467907151),
//--TRIMMABLE-BOUNDARY-START(287762874447),
    {
      "t": 655361,
      "n": "COR_E_SYNCHRONIZATIONLOCK",
      "d": 65615,
      "h": 287762874447,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287762874447),
//--TRIMMABLE-BOUNDARY-START(292057841743),
    {
      "t": 655361,
      "n": "COR_E_SYSTEM",
      "d": 65615,
      "h": 292057841743,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292057841743),
//--TRIMMABLE-BOUNDARY-START(296352809039),
    {
      "t": 655361,
      "n": "COR_E_TARGET",
      "d": 65615,
      "h": 296352809039,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296352809039),
//--TRIMMABLE-BOUNDARY-START(300647776335),
    {
      "t": 655361,
      "n": "COR_E_TARGETINVOCATION",
      "d": 65615,
      "h": 300647776335,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300647776335),
//--TRIMMABLE-BOUNDARY-START(304942743631),
    {
      "t": 655361,
      "n": "COR_E_TARGETPARAMCOUNT",
      "d": 65615,
      "h": 304942743631,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304942743631),
//--TRIMMABLE-BOUNDARY-START(309237710927),
    {
      "t": 655361,
      "n": "COR_E_THREADABORTED",
      "d": 65615,
      "h": 309237710927,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309237710927),
//--TRIMMABLE-BOUNDARY-START(313532678223),
    {
      "t": 655361,
      "n": "COR_E_THREADINTERRUPTED",
      "d": 65615,
      "h": 313532678223,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313532678223),
//--TRIMMABLE-BOUNDARY-START(317827645519),
    {
      "t": 655361,
      "n": "COR_E_THREADSTART",
      "d": 65615,
      "h": 317827645519,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317827645519),
//--TRIMMABLE-BOUNDARY-START(322122612815),
    {
      "t": 655361,
      "n": "COR_E_THREADSTATE",
      "d": 65615,
      "h": 322122612815,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322122612815),
//--TRIMMABLE-BOUNDARY-START(326417580111),
    {
      "t": 655361,
      "n": "COR_E_TIMEOUT",
      "d": 65615,
      "h": 326417580111,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326417580111),
//--TRIMMABLE-BOUNDARY-START(330712547407),
    {
      "t": 655361,
      "n": "COR_E_TYPEACCESS",
      "d": 65615,
      "h": 330712547407,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330712547407),
//--TRIMMABLE-BOUNDARY-START(335007514703),
    {
      "t": 655361,
      "n": "COR_E_TYPEINITIALIZATION",
      "d": 65615,
      "h": 335007514703,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335007514703),
//--TRIMMABLE-BOUNDARY-START(339302481999),
    {
      "t": 655361,
      "n": "COR_E_TYPELOAD",
      "d": 65615,
      "h": 339302481999,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339302481999),
//--TRIMMABLE-BOUNDARY-START(343597449295),
    {
      "t": 655361,
      "n": "COR_E_TYPEUNLOADED",
      "d": 65615,
      "h": 343597449295,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343597449295),
//--TRIMMABLE-BOUNDARY-START(347892416591),
    {
      "t": 655361,
      "n": "COR_E_UNAUTHORIZEDACCESS",
      "d": 65615,
      "h": 347892416591,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347892416591),
//--TRIMMABLE-BOUNDARY-START(352187383887),
    {
      "t": 655361,
      "n": "COR_E_VERIFICATION",
      "d": 65615,
      "h": 352187383887,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352187383887),
//--TRIMMABLE-BOUNDARY-START(356482351183),
    {
      "t": 655361,
      "n": "COR_E_WAITHANDLECANNOTBEOPENED",
      "d": 65615,
      "h": 356482351183,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356482351183),
//--TRIMMABLE-BOUNDARY-START(4295032911),
    {
      "t": 655361,
      "n": "CO_E_NOTINITIALIZED",
      "d": 65615,
      "h": 4295032911,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295032911),
//--TRIMMABLE-BOUNDARY-START(382252154959),
    {
      "t": 655361,
      "n": "DISP_E_PARAMNOTFOUND",
      "d": 65615,
      "h": 382252154959,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382252154959),
//--TRIMMABLE-BOUNDARY-START(386547122255),
    {
      "t": 655361,
      "n": "DISP_E_TYPEMISMATCH",
      "d": 65615,
      "h": 386547122255,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386547122255),
//--TRIMMABLE-BOUNDARY-START(369367253071),
    {
      "t": 655361,
      "n": "DISP_E_BADVARTYPE",
      "d": 65615,
      "h": 369367253071,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369367253071),
//--TRIMMABLE-BOUNDARY-START(377957187663),
    {
      "t": 655361,
      "n": "DISP_E_OVERFLOW",
      "d": 65615,
      "h": 377957187663,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377957187663),
//--TRIMMABLE-BOUNDARY-START(373662220367),
    {
      "t": 655361,
      "n": "DISP_E_DIVBYZERO",
      "d": 65615,
      "h": 373662220367,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373662220367),
//--TRIMMABLE-BOUNDARY-START(390842089551),
    {
      "t": 655361,
      "n": "E_BOUNDS",
      "d": 65615,
      "h": 390842089551,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390842089551),
//--TRIMMABLE-BOUNDARY-START(395137056847),
    {
      "t": 655361,
      "n": "E_CHANGED_STATE",
      "d": 65615,
      "h": 395137056847,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395137056847),
//--TRIMMABLE-BOUNDARY-START(403726991439),
    {
      "t": 655361,
      "n": "E_FILENOTFOUND",
      "d": 65615,
      "h": 403726991439,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403726991439),
//--TRIMMABLE-BOUNDARY-START(399432024143),
    {
      "t": 655361,
      "n": "E_FAIL",
      "d": 65615,
      "h": 399432024143,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399432024143),
//--TRIMMABLE-BOUNDARY-START(408021958735),
    {
      "t": 655361,
      "n": "E_HANDLE",
      "d": 65615,
      "h": 408021958735,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408021958735),
//--TRIMMABLE-BOUNDARY-START(412316926031),
    {
      "t": 655361,
      "n": "E_INVALIDARG",
      "d": 65615,
      "h": 412316926031,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412316926031),
//--TRIMMABLE-BOUNDARY-START(416611893327),
    {
      "t": 655361,
      "n": "E_NOTIMPL",
      "d": 65615,
      "h": 416611893327,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416611893327),
//--TRIMMABLE-BOUNDARY-START(420906860623),
    {
      "t": 655361,
      "n": "E_OUTOFMEMORY",
      "d": 65615,
      "h": 420906860623,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420906860623),
//--TRIMMABLE-BOUNDARY-START(425201827919),
    {
      "t": 655361,
      "n": "E_POINTER",
      "d": 65615,
      "h": 425201827919,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425201827919),
//--TRIMMABLE-BOUNDARY-START(446676664399),
    {
      "t": 655361,
      "n": "ERROR_MRM_MAP_NOT_FOUND",
      "d": 65615,
      "h": 446676664399,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446676664399),
//--TRIMMABLE-BOUNDARY-START(459561566287),
    {
      "t": 655361,
      "n": "ERROR_TIMEOUT",
      "d": 65615,
      "h": 459561566287,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459561566287),
//--TRIMMABLE-BOUNDARY-START(485331370063),
    {
      "t": 655361,
      "n": "RO_E_CLOSED",
      "d": 65615,
      "h": 485331370063,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485331370063),
//--TRIMMABLE-BOUNDARY-START(489626337359),
    {
      "t": 655361,
      "n": "RPC_E_CHANGED_MODE",
      "d": 65615,
      "h": 489626337359,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489626337359),
//--TRIMMABLE-BOUNDARY-START(506806206543),
    {
      "t": 655361,
      "n": "TYPE_E_TYPEMISMATCH",
      "d": 65615,
      "h": 506806206543,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506806206543),
//--TRIMMABLE-BOUNDARY-START(502511239247),
    {
      "t": 655361,
      "n": "STG_E_PATHNOTFOUND",
      "d": 65615,
      "h": 502511239247,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502511239247),
//--TRIMMABLE-BOUNDARY-START(365072285775),
    {
      "t": 655361,
      "n": "CTL_E_PATHNOTFOUND",
      "d": 65615,
      "h": 365072285775,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365072285775),
//--TRIMMABLE-BOUNDARY-START(360777318479),
    {
      "t": 655361,
      "n": "CTL_E_FILENOTFOUND",
      "d": 65615,
      "h": 360777318479,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360777318479),
//--TRIMMABLE-BOUNDARY-START(472446468175),
    {
      "t": 655361,
      "n": "FUSION_E_INVALID_NAME",
      "d": 65615,
      "h": 472446468175,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472446468175),
//--TRIMMABLE-BOUNDARY-START(476741435471),
    {
      "t": 655361,
      "n": "FUSION_E_REF_DEF_MISMATCH",
      "d": 65615,
      "h": 476741435471,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476741435471),
//--TRIMMABLE-BOUNDARY-START(463856533583),
    {
      "t": 655361,
      "n": "ERROR_TOO_MANY_OPEN_FILES",
      "d": 65615,
      "h": 463856533583,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463856533583),
//--TRIMMABLE-BOUNDARY-START(455266598991),
    {
      "t": 655361,
      "n": "ERROR_SHARING_VIOLATION",
      "d": 65615,
      "h": 455266598991,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455266598991),
//--TRIMMABLE-BOUNDARY-START(442381697103),
    {
      "t": 655361,
      "n": "ERROR_LOCK_VIOLATION",
      "d": 65615,
      "h": 442381697103,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442381697103),
//--TRIMMABLE-BOUNDARY-START(450971631695),
    {
      "t": 655361,
      "n": "ERROR_OPEN_FAILED",
      "d": 65615,
      "h": 450971631695,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450971631695),
//--TRIMMABLE-BOUNDARY-START(429496795215),
    {
      "t": 655361,
      "n": "ERROR_DISK_CORRUPT",
      "d": 65615,
      "h": 429496795215,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429496795215),
//--TRIMMABLE-BOUNDARY-START(468151500879),
    {
      "t": 655361,
      "n": "ERROR_UNRECOGNIZED_VOLUME",
      "d": 65615,
      "h": 468151500879,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468151500879),
//--TRIMMABLE-BOUNDARY-START(433791762511),
    {
      "t": 655361,
      "n": "ERROR_DLL_INIT_FAILED",
      "d": 65615,
      "h": 433791762511,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433791762511),
//--TRIMMABLE-BOUNDARY-START(481036402767),
    {
      "t": 655361,
      "n": "MSEE_E_ASSEMBLYLOADINPROGRESS",
      "d": 65615,
      "h": 481036402767,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481036402767),
//--TRIMMABLE-BOUNDARY-START(438086729807),
    {
      "t": 655361,
      "n": "ERROR_FILE_INVALID",
      "d": 65615,
      "h": 438086729807,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438086729807)
  ],
  "h": 65615
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.HResults`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65615)
        
        
        //--TRIMMABLE-BOUNDARY-START(393295)
        $asm.$cls("$sifd.System.Obsoletions", ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382252482639)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382252482639)
            
            //--TRIMMABLE-BOUNDARY-START(433792090191)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433792090191)
            
            //--TRIMMABLE-BOUNDARY-START(429497122895)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429497122895)
            
            //--TRIMMABLE-BOUNDARY-START(266288365647)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266288365647)
            
            //--TRIMMABLE-BOUNDARY-START(261993398351)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261993398351)
            
            //--TRIMMABLE-BOUNDARY-START(77309804623)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77309804623)
            
            //--TRIMMABLE-BOUNDARY-START(73014837327)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73014837327)
            
            //--TRIMMABLE-BOUNDARY-START(94489673807)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94489673807)
            
            //--TRIMMABLE-BOUNDARY-START(90194706511)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90194706511)
            
            //--TRIMMABLE-BOUNDARY-START(214748758095)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214748758095)
            
            //--TRIMMABLE-BOUNDARY-START(210453790799)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210453790799)
            
            //--TRIMMABLE-BOUNDARY-START(442382024783)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442382024783)
            
            //--TRIMMABLE-BOUNDARY-START(446676992079)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446676992079)
            
            //--TRIMMABLE-BOUNDARY-START(438087057487)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438087057487)
            
            //--TRIMMABLE-BOUNDARY-START(146029281359)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146029281359)
            
            //--TRIMMABLE-BOUNDARY-START(141734314063)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141734314063)
            
            //--TRIMMABLE-BOUNDARY-START(120259477583)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120259477583)
            
            //--TRIMMABLE-BOUNDARY-START(115964510287)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115964510287)
            
            //--TRIMMABLE-BOUNDARY-START(51540000847)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51540000847)
            
            //--TRIMMABLE-BOUNDARY-START(47245033551)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47245033551)
            
            //--TRIMMABLE-BOUNDARY-START(326417907791)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326417907791)
            
            //--TRIMMABLE-BOUNDARY-START(322122940495)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322122940495)
            
            //--TRIMMABLE-BOUNDARY-START(60129935439)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60129935439)
            
            //--TRIMMABLE-BOUNDARY-START(55834968143)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55834968143)
            
            //--TRIMMABLE-BOUNDARY-START(85899739215)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85899739215)
            
            //--TRIMMABLE-BOUNDARY-START(81604771919)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81604771919)
            
            //--TRIMMABLE-BOUNDARY-START(197568888911)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197568888911)
            
            //--TRIMMABLE-BOUNDARY-START(193273921615)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193273921615)
            
            //--TRIMMABLE-BOUNDARY-START(489626665039)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489626665039)
            
            //--TRIMMABLE-BOUNDARY-START(485331697743)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485331697743)
            
            //--TRIMMABLE-BOUNDARY-START(163209150543)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163209150543)
            
            //--TRIMMABLE-BOUNDARY-START(158914183247)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158914183247)
            
            //--TRIMMABLE-BOUNDARY-START(206158823503)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206158823503)
            
            //--TRIMMABLE-BOUNDARY-START(201863856207)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201863856207)
            
            //--TRIMMABLE-BOUNDARY-START(399432351823)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399432351823)
            
            //--TRIMMABLE-BOUNDARY-START(395137384527)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395137384527)
            
            //--TRIMMABLE-BOUNDARY-START(300648104015)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300648104015)
            
            //--TRIMMABLE-BOUNDARY-START(296353136719)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296353136719)
            
            //--TRIMMABLE-BOUNDARY-START(377957515343)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377957515343)
            
            //--TRIMMABLE-BOUNDARY-START(373662548047)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373662548047)
            
            //--TRIMMABLE-BOUNDARY-START(231928627279)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231928627279)
            
            //--TRIMMABLE-BOUNDARY-START(227633659983)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227633659983)
            
            //--TRIMMABLE-BOUNDARY-START(154619215951)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154619215951)
            
            //--TRIMMABLE-BOUNDARY-START(150324248655)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150324248655)
            
            //--TRIMMABLE-BOUNDARY-START(352187711567)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352187711567)
            
            //--TRIMMABLE-BOUNDARY-START(347892744271)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347892744271)
            
            //--TRIMMABLE-BOUNDARY-START(360777646159)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360777646159)
            
            //--TRIMMABLE-BOUNDARY-START(356482678863)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356482678863)
            
            //--TRIMMABLE-BOUNDARY-START(17180262479)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17180262479)
            
            //--TRIMMABLE-BOUNDARY-START(12885295183)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12885295183)
            
            //--TRIMMABLE-BOUNDARY-START(408022286415)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408022286415)
            
            //--TRIMMABLE-BOUNDARY-START(403727319119)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403727319119)
            
            //--TRIMMABLE-BOUNDARY-START(498216599631)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498216599631)
            
            //--TRIMMABLE-BOUNDARY-START(493921632335)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493921632335)
            
            //--TRIMMABLE-BOUNDARY-START(283468234831)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283468234831)
            
            //--TRIMMABLE-BOUNDARY-START(279173267535)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279173267535)
            
            //--TRIMMABLE-BOUNDARY-START(506806534223)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506806534223)
            
            //--TRIMMABLE-BOUNDARY-START(502511566927)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502511566927)
            
            //--TRIMMABLE-BOUNDARY-START(274878300239)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274878300239)
            
            //--TRIMMABLE-BOUNDARY-START(270583332943)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270583332943)
            
            //--TRIMMABLE-BOUNDARY-START(481036730447)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481036730447)
            
            //--TRIMMABLE-BOUNDARY-START(476741763151)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476741763151)
            
            //--TRIMMABLE-BOUNDARY-START(128849412175)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128849412175)
            
            //--TRIMMABLE-BOUNDARY-START(124554444879)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124554444879)
            
            //--TRIMMABLE-BOUNDARY-START(111669542991)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111669542991)
            
            //--TRIMMABLE-BOUNDARY-START(107374575695)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107374575695)
            
            //--TRIMMABLE-BOUNDARY-START(335007842383)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335007842383)
            
            //--TRIMMABLE-BOUNDARY-START(330712875087)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330712875087)
            
            //--TRIMMABLE-BOUNDARY-START(68719870031)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68719870031)
            
            //--TRIMMABLE-BOUNDARY-START(64424902735)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64424902735)
            
            //--TRIMMABLE-BOUNDARY-START(390842417231)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390842417231)
            
            //--TRIMMABLE-BOUNDARY-START(386547449935)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386547449935)
            
            //--TRIMMABLE-BOUNDARY-START(309238038607)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309238038607)
            
            //--TRIMMABLE-BOUNDARY-START(304943071311)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304943071311)
            
            //--TRIMMABLE-BOUNDARY-START(42950066255)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42950066255)
            
            //--TRIMMABLE-BOUNDARY-START(38655098959)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38655098959)
            
            //--TRIMMABLE-BOUNDARY-START(416612221007)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416612221007)
            
            //--TRIMMABLE-BOUNDARY-START(412317253711)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412317253711)
            
            //--TRIMMABLE-BOUNDARY-START(472446795855)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472446795855)
            
            //--TRIMMABLE-BOUNDARY-START(468151828559)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468151828559)
            
            //--TRIMMABLE-BOUNDARY-START(188978954319)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188978954319)
            
            //--TRIMMABLE-BOUNDARY-START(184683987023)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184683987023)
            
            //--TRIMMABLE-BOUNDARY-START(171799085135)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171799085135)
            
            //--TRIMMABLE-BOUNDARY-START(167504117839)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167504117839)
            
            //--TRIMMABLE-BOUNDARY-START(180389019727)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180389019727)
            
            //--TRIMMABLE-BOUNDARY-START(176094052431)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176094052431)
            
            //--TRIMMABLE-BOUNDARY-START(34360131663)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34360131663)
            
            //--TRIMMABLE-BOUNDARY-START(30065164367)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30065164367)
            
            //--TRIMMABLE-BOUNDARY-START(137439346767)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137439346767)
            
            //--TRIMMABLE-BOUNDARY-START(133144379471)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133144379471)
            
            //--TRIMMABLE-BOUNDARY-START(103079608399)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103079608399)
            
            //--TRIMMABLE-BOUNDARY-START(98784641103)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98784641103)
            
            //--TRIMMABLE-BOUNDARY-START(523986403407)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523986403407)
            
            //--TRIMMABLE-BOUNDARY-START(519691436111)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519691436111)
            
            //--TRIMMABLE-BOUNDARY-START(369367580751)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369367580751)
            
            //--TRIMMABLE-BOUNDARY-START(365072613455)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365072613455)
            
            //--TRIMMABLE-BOUNDARY-START(223338692687)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223338692687)
            
            //--TRIMMABLE-BOUNDARY-START(219043725391)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219043725391)
            
            //--TRIMMABLE-BOUNDARY-START(249108496463)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249108496463)
            
            //--TRIMMABLE-BOUNDARY-START(236223594575)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236223594575)
            
            //--TRIMMABLE-BOUNDARY-START(244813529167)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244813529167)
            
            //--TRIMMABLE-BOUNDARY-START(240518561871)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240518561871)
            
            //--TRIMMABLE-BOUNDARY-START(317827973199)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317827973199)
            
            //--TRIMMABLE-BOUNDARY-START(313533005903)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313533005903)
            
            //--TRIMMABLE-BOUNDARY-START(8590327887)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590327887)
            
            //--TRIMMABLE-BOUNDARY-START(4295360591)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295360591)
            
            //--TRIMMABLE-BOUNDARY-START(455266926671)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455266926671)
            
            //--TRIMMABLE-BOUNDARY-START(450971959375)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450971959375)
            
            //--TRIMMABLE-BOUNDARY-START(25770197071)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25770197071)
            
            //--TRIMMABLE-BOUNDARY-START(21475229775)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21475229775)
            
            //--TRIMMABLE-BOUNDARY-START(257698431055)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257698431055)
            
            //--TRIMMABLE-BOUNDARY-START(253403463759)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253403463759)
            
            //--TRIMMABLE-BOUNDARY-START(515396468815)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515396468815)
            
            //--TRIMMABLE-BOUNDARY-START(511101501519)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511101501519)
            
            //--TRIMMABLE-BOUNDARY-START(463856861263)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463856861263)
            
            //--TRIMMABLE-BOUNDARY-START(459561893967)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459561893967)
            
            //--TRIMMABLE-BOUNDARY-START(425202155599)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425202155599)
            
            //--TRIMMABLE-BOUNDARY-START(420907188303)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420907188303)
            
            //--TRIMMABLE-BOUNDARY-START(343597776975)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343597776975)
            
            //--TRIMMABLE-BOUNDARY-START(339302809679)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339302809679)
            
            //--TRIMMABLE-BOUNDARY-START(292058169423)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292058169423)
            
            //--TRIMMABLE-BOUNDARY-START(287763202127)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287763202127)
            
            //--TRIMMABLE-BOUNDARY-START(532576337999)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532576337999)
            
            //--TRIMMABLE-BOUNDARY-START(528281370703)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528281370703)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382252482639)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382252482639)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433792090191)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433792090191)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429497122895)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429497122895)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288365647)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266288365647)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993398351)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261993398351)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309804623)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77309804623)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73014837327)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73014837327)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489673807)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94489673807)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194706511)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90194706511)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214748758095)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214748758095)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210453790799)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210453790799)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442382024783)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442382024783)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446676992079)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446676992079)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438087057487)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438087057487)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029281359)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146029281359)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734314063)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141734314063)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259477583)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120259477583)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964510287)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115964510287)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540000847)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51540000847)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245033551)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47245033551)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326417907791)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326417907791)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322122940495)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322122940495)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129935439)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60129935439)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834968143)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55834968143)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899739215)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85899739215)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604771919)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81604771919)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197568888911)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197568888911)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193273921615)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193273921615)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489626665039)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489626665039)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485331697743)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485331697743)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163209150543)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163209150543)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914183247)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158914183247)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206158823503)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206158823503)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201863856207)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201863856207)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432351823)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399432351823)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137384527)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395137384527)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300648104015)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300648104015)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296353136719)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296353136719)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957515343)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377957515343)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373662548047)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373662548047)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231928627279)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231928627279)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227633659983)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227633659983)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619215951)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154619215951)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324248655)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150324248655)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352187711567)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352187711567)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347892744271)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347892744271)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360777646159)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360777646159)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356482678863)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356482678863)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180262479)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17180262479)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885295183)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12885295183)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408022286415)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408022286415)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403727319119)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403727319119)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498216599631)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498216599631)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493921632335)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493921632335)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283468234831)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283468234831)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279173267535)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279173267535)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506806534223)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506806534223)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502511566927)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502511566927)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274878300239)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274878300239)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583332943)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270583332943)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481036730447)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481036730447)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476741763151)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476741763151)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849412175)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128849412175)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554444879)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124554444879)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669542991)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111669542991)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374575695)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107374575695)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335007842383)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335007842383)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330712875087)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330712875087)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719870031)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68719870031)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424902735)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64424902735)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842417231)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390842417231)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547449935)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386547449935)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309238038607)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309238038607)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304943071311)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304943071311)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950066255)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42950066255)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655098959)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38655098959)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416612221007)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416612221007)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412317253711)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412317253711)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472446795855)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472446795855)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468151828559)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468151828559)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188978954319)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188978954319)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184683987023)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184683987023)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171799085135)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171799085135)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167504117839)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167504117839)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389019727)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180389019727)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094052431)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176094052431)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360131663)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34360131663)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065164367)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30065164367)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439346767)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137439346767)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144379471)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133144379471)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079608399)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103079608399)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784641103)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98784641103)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523986403407)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523986403407)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519691436111)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519691436111)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369367580751)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369367580751)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365072613455)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365072613455)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223338692687)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223338692687)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219043725391)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219043725391)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108496463)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249108496463)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223594575)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236223594575)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813529167)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244813529167)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518561871)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240518561871)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317827973199)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317827973199)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313533005903)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313533005903)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590327887)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8590327887)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295360591)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4295360591)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455266926671)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455266926671)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450971959375)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450971959375)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770197071)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25770197071)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475229775)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21475229775)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698431055)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257698431055)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403463759)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253403463759)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515396468815)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515396468815)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511101501519)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511101501519)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463856861263)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463856861263)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459561893967)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459561893967)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425202155599)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425202155599)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420907188303)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420907188303)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343597776975)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343597776975)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339302809679)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339302809679)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292058169423)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292058169423)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287763202127)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287763202127)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532576337999)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532576337999)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528281370703)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528281370703)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 393295;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(382252482639),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 393295,
      "h": 382252482639,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382252482639),
//--TRIMMABLE-BOUNDARY-START(433792090191),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 393295,
      "h": 433792090191,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433792090191),
//--TRIMMABLE-BOUNDARY-START(429497122895),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 393295,
      "h": 429497122895,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429497122895),
//--TRIMMABLE-BOUNDARY-START(266288365647),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 393295,
      "h": 266288365647,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266288365647),
//--TRIMMABLE-BOUNDARY-START(261993398351),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 393295,
      "h": 261993398351,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261993398351),
//--TRIMMABLE-BOUNDARY-START(77309804623),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 393295,
      "h": 77309804623,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77309804623),
//--TRIMMABLE-BOUNDARY-START(73014837327),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 393295,
      "h": 73014837327,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73014837327),
//--TRIMMABLE-BOUNDARY-START(94489673807),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 393295,
      "h": 94489673807,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489673807),
//--TRIMMABLE-BOUNDARY-START(90194706511),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 393295,
      "h": 90194706511,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90194706511),
//--TRIMMABLE-BOUNDARY-START(214748758095),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 393295,
      "h": 214748758095,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214748758095),
//--TRIMMABLE-BOUNDARY-START(210453790799),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 393295,
      "h": 210453790799,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210453790799),
//--TRIMMABLE-BOUNDARY-START(442382024783),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 393295,
      "h": 442382024783,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442382024783),
//--TRIMMABLE-BOUNDARY-START(446676992079),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 393295,
      "h": 446676992079,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446676992079),
//--TRIMMABLE-BOUNDARY-START(438087057487),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 393295,
      "h": 438087057487,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438087057487),
//--TRIMMABLE-BOUNDARY-START(146029281359),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 393295,
      "h": 146029281359,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146029281359),
//--TRIMMABLE-BOUNDARY-START(141734314063),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 393295,
      "h": 141734314063,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141734314063),
//--TRIMMABLE-BOUNDARY-START(120259477583),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 393295,
      "h": 120259477583,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259477583),
//--TRIMMABLE-BOUNDARY-START(115964510287),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 393295,
      "h": 115964510287,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115964510287),
//--TRIMMABLE-BOUNDARY-START(51540000847),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 393295,
      "h": 51540000847,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51540000847),
//--TRIMMABLE-BOUNDARY-START(47245033551),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 393295,
      "h": 47245033551,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47245033551),
//--TRIMMABLE-BOUNDARY-START(326417907791),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 393295,
      "h": 326417907791,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326417907791),
//--TRIMMABLE-BOUNDARY-START(322122940495),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 393295,
      "h": 322122940495,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322122940495),
//--TRIMMABLE-BOUNDARY-START(60129935439),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 393295,
      "h": 60129935439,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60129935439),
//--TRIMMABLE-BOUNDARY-START(55834968143),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 393295,
      "h": 55834968143,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834968143),
//--TRIMMABLE-BOUNDARY-START(85899739215),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 393295,
      "h": 85899739215,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85899739215),
//--TRIMMABLE-BOUNDARY-START(81604771919),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 393295,
      "h": 81604771919,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81604771919),
//--TRIMMABLE-BOUNDARY-START(197568888911),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 393295,
      "h": 197568888911,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197568888911),
//--TRIMMABLE-BOUNDARY-START(193273921615),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 393295,
      "h": 193273921615,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193273921615),
//--TRIMMABLE-BOUNDARY-START(489626665039),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 393295,
      "h": 489626665039,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489626665039),
//--TRIMMABLE-BOUNDARY-START(485331697743),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 393295,
      "h": 485331697743,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485331697743),
//--TRIMMABLE-BOUNDARY-START(163209150543),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 393295,
      "h": 163209150543,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163209150543),
//--TRIMMABLE-BOUNDARY-START(158914183247),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 393295,
      "h": 158914183247,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158914183247),
//--TRIMMABLE-BOUNDARY-START(206158823503),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 393295,
      "h": 206158823503,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206158823503),
//--TRIMMABLE-BOUNDARY-START(201863856207),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 393295,
      "h": 201863856207,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201863856207),
//--TRIMMABLE-BOUNDARY-START(399432351823),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 393295,
      "h": 399432351823,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399432351823),
//--TRIMMABLE-BOUNDARY-START(395137384527),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 393295,
      "h": 395137384527,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395137384527),
//--TRIMMABLE-BOUNDARY-START(300648104015),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 393295,
      "h": 300648104015,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300648104015),
//--TRIMMABLE-BOUNDARY-START(296353136719),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 393295,
      "h": 296353136719,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296353136719),
//--TRIMMABLE-BOUNDARY-START(377957515343),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 393295,
      "h": 377957515343,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377957515343),
//--TRIMMABLE-BOUNDARY-START(373662548047),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 393295,
      "h": 373662548047,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373662548047),
//--TRIMMABLE-BOUNDARY-START(231928627279),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 393295,
      "h": 231928627279,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231928627279),
//--TRIMMABLE-BOUNDARY-START(227633659983),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 393295,
      "h": 227633659983,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227633659983),
//--TRIMMABLE-BOUNDARY-START(154619215951),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 393295,
      "h": 154619215951,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154619215951),
//--TRIMMABLE-BOUNDARY-START(150324248655),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 393295,
      "h": 150324248655,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150324248655),
//--TRIMMABLE-BOUNDARY-START(352187711567),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 393295,
      "h": 352187711567,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352187711567),
//--TRIMMABLE-BOUNDARY-START(347892744271),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 393295,
      "h": 347892744271,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347892744271),
//--TRIMMABLE-BOUNDARY-START(360777646159),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 393295,
      "h": 360777646159,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360777646159),
//--TRIMMABLE-BOUNDARY-START(356482678863),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 393295,
      "h": 356482678863,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356482678863),
//--TRIMMABLE-BOUNDARY-START(17180262479),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 393295,
      "h": 17180262479,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180262479),
//--TRIMMABLE-BOUNDARY-START(12885295183),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 393295,
      "h": 12885295183,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885295183),
//--TRIMMABLE-BOUNDARY-START(408022286415),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 393295,
      "h": 408022286415,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408022286415),
//--TRIMMABLE-BOUNDARY-START(403727319119),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 393295,
      "h": 403727319119,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403727319119),
//--TRIMMABLE-BOUNDARY-START(498216599631),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 393295,
      "h": 498216599631,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498216599631),
//--TRIMMABLE-BOUNDARY-START(493921632335),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 393295,
      "h": 493921632335,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493921632335),
//--TRIMMABLE-BOUNDARY-START(283468234831),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 393295,
      "h": 283468234831,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283468234831),
//--TRIMMABLE-BOUNDARY-START(279173267535),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 393295,
      "h": 279173267535,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279173267535),
//--TRIMMABLE-BOUNDARY-START(506806534223),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 393295,
      "h": 506806534223,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506806534223),
//--TRIMMABLE-BOUNDARY-START(502511566927),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 393295,
      "h": 502511566927,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502511566927),
//--TRIMMABLE-BOUNDARY-START(274878300239),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 393295,
      "h": 274878300239,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274878300239),
//--TRIMMABLE-BOUNDARY-START(270583332943),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 393295,
      "h": 270583332943,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270583332943),
//--TRIMMABLE-BOUNDARY-START(481036730447),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 393295,
      "h": 481036730447,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481036730447),
//--TRIMMABLE-BOUNDARY-START(476741763151),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 393295,
      "h": 476741763151,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476741763151),
//--TRIMMABLE-BOUNDARY-START(128849412175),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 393295,
      "h": 128849412175,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849412175),
//--TRIMMABLE-BOUNDARY-START(124554444879),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 393295,
      "h": 124554444879,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554444879),
//--TRIMMABLE-BOUNDARY-START(111669542991),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 393295,
      "h": 111669542991,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111669542991),
//--TRIMMABLE-BOUNDARY-START(107374575695),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 393295,
      "h": 107374575695,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107374575695),
//--TRIMMABLE-BOUNDARY-START(335007842383),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 393295,
      "h": 335007842383,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335007842383),
//--TRIMMABLE-BOUNDARY-START(330712875087),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 393295,
      "h": 330712875087,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330712875087),
//--TRIMMABLE-BOUNDARY-START(68719870031),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 393295,
      "h": 68719870031,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68719870031),
//--TRIMMABLE-BOUNDARY-START(64424902735),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 393295,
      "h": 64424902735,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64424902735),
//--TRIMMABLE-BOUNDARY-START(390842417231),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 393295,
      "h": 390842417231,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390842417231),
//--TRIMMABLE-BOUNDARY-START(386547449935),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 393295,
      "h": 386547449935,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386547449935),
//--TRIMMABLE-BOUNDARY-START(309238038607),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 393295,
      "h": 309238038607,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309238038607),
//--TRIMMABLE-BOUNDARY-START(304943071311),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 393295,
      "h": 304943071311,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304943071311),
//--TRIMMABLE-BOUNDARY-START(42950066255),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 393295,
      "h": 42950066255,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42950066255),
//--TRIMMABLE-BOUNDARY-START(38655098959),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 393295,
      "h": 38655098959,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38655098959),
//--TRIMMABLE-BOUNDARY-START(416612221007),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 393295,
      "h": 416612221007,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416612221007),
//--TRIMMABLE-BOUNDARY-START(412317253711),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 393295,
      "h": 412317253711,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412317253711),
//--TRIMMABLE-BOUNDARY-START(472446795855),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 393295,
      "h": 472446795855,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472446795855),
//--TRIMMABLE-BOUNDARY-START(468151828559),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 393295,
      "h": 468151828559,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468151828559),
//--TRIMMABLE-BOUNDARY-START(188978954319),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 393295,
      "h": 188978954319,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188978954319),
//--TRIMMABLE-BOUNDARY-START(184683987023),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 393295,
      "h": 184683987023,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184683987023),
//--TRIMMABLE-BOUNDARY-START(171799085135),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 393295,
      "h": 171799085135,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171799085135),
//--TRIMMABLE-BOUNDARY-START(167504117839),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 393295,
      "h": 167504117839,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167504117839),
//--TRIMMABLE-BOUNDARY-START(180389019727),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 393295,
      "h": 180389019727,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180389019727),
//--TRIMMABLE-BOUNDARY-START(176094052431),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 393295,
      "h": 176094052431,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176094052431),
//--TRIMMABLE-BOUNDARY-START(34360131663),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 393295,
      "h": 34360131663,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360131663),
//--TRIMMABLE-BOUNDARY-START(30065164367),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 393295,
      "h": 30065164367,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065164367),
//--TRIMMABLE-BOUNDARY-START(137439346767),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 393295,
      "h": 137439346767,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137439346767),
//--TRIMMABLE-BOUNDARY-START(133144379471),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 393295,
      "h": 133144379471,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133144379471),
//--TRIMMABLE-BOUNDARY-START(103079608399),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 393295,
      "h": 103079608399,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103079608399),
//--TRIMMABLE-BOUNDARY-START(98784641103),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 393295,
      "h": 98784641103,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784641103),
//--TRIMMABLE-BOUNDARY-START(523986403407),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 393295,
      "h": 523986403407,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523986403407),
//--TRIMMABLE-BOUNDARY-START(519691436111),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 393295,
      "h": 519691436111,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519691436111),
//--TRIMMABLE-BOUNDARY-START(369367580751),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 393295,
      "h": 369367580751,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369367580751),
//--TRIMMABLE-BOUNDARY-START(365072613455),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 393295,
      "h": 365072613455,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365072613455),
//--TRIMMABLE-BOUNDARY-START(223338692687),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 393295,
      "h": 223338692687,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223338692687),
//--TRIMMABLE-BOUNDARY-START(219043725391),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 393295,
      "h": 219043725391,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219043725391),
//--TRIMMABLE-BOUNDARY-START(249108496463),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 393295,
      "h": 249108496463,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249108496463),
//--TRIMMABLE-BOUNDARY-START(236223594575),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 393295,
      "h": 236223594575,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236223594575),
//--TRIMMABLE-BOUNDARY-START(244813529167),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 393295,
      "h": 244813529167,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244813529167),
//--TRIMMABLE-BOUNDARY-START(240518561871),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 393295,
      "h": 240518561871,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240518561871),
//--TRIMMABLE-BOUNDARY-START(317827973199),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 393295,
      "h": 317827973199,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317827973199),
//--TRIMMABLE-BOUNDARY-START(313533005903),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 393295,
      "h": 313533005903,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313533005903),
//--TRIMMABLE-BOUNDARY-START(8590327887),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 393295,
      "h": 8590327887,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590327887),
//--TRIMMABLE-BOUNDARY-START(4295360591),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 393295,
      "h": 4295360591,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295360591),
//--TRIMMABLE-BOUNDARY-START(455266926671),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 393295,
      "h": 455266926671,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455266926671),
//--TRIMMABLE-BOUNDARY-START(450971959375),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 393295,
      "h": 450971959375,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450971959375),
//--TRIMMABLE-BOUNDARY-START(25770197071),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 393295,
      "h": 25770197071,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770197071),
//--TRIMMABLE-BOUNDARY-START(21475229775),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 393295,
      "h": 21475229775,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475229775),
//--TRIMMABLE-BOUNDARY-START(257698431055),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 393295,
      "h": 257698431055,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257698431055),
//--TRIMMABLE-BOUNDARY-START(253403463759),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 393295,
      "h": 253403463759,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253403463759),
//--TRIMMABLE-BOUNDARY-START(515396468815),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 393295,
      "h": 515396468815,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515396468815),
//--TRIMMABLE-BOUNDARY-START(511101501519),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 393295,
      "h": 511101501519,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511101501519),
//--TRIMMABLE-BOUNDARY-START(463856861263),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 393295,
      "h": 463856861263,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463856861263),
//--TRIMMABLE-BOUNDARY-START(459561893967),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 393295,
      "h": 459561893967,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459561893967),
//--TRIMMABLE-BOUNDARY-START(425202155599),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 393295,
      "h": 425202155599,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425202155599),
//--TRIMMABLE-BOUNDARY-START(420907188303),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 393295,
      "h": 420907188303,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420907188303),
//--TRIMMABLE-BOUNDARY-START(343597776975),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 393295,
      "h": 343597776975,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343597776975),
//--TRIMMABLE-BOUNDARY-START(339302809679),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 393295,
      "h": 339302809679,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339302809679),
//--TRIMMABLE-BOUNDARY-START(292058169423),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 393295,
      "h": 292058169423,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292058169423),
//--TRIMMABLE-BOUNDARY-START(287763202127),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 393295,
      "h": 287763202127,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287763202127),
//--TRIMMABLE-BOUNDARY-START(532576337999),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 393295,
      "h": 532576337999,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532576337999),
//--TRIMMABLE-BOUNDARY-START(528281370703),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 393295,
      "h": 528281370703,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528281370703)
  ],
  "h": 393295
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393295)
        
        
        //--TRIMMABLE-BOUNDARY-START(327759)
        $asm.$cls("$sifd.System.IO.PathInternal", ($self) => class PathInternal
        {
            //--TRIMMABLE-BOUNDARY-START(25770131535)
            static /*StringComparison */ get StringComparison()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180196943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sifd.System.IO.PathInternal.IsCaseSensitive ? 4/*StringComparison.Ordinal*/ : 5/*StringComparison.OrdinalIgnoreCase*/;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131535)
            
            //--TRIMMABLE-BOUNDARY-START(21475164239)
            static /*bool */ get IsCaseSensitive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !($.$$.System.OperatingSystem.IsWindows() || $.$$.System.OperatingSystem.IsMacOS() || $.$$.System.OperatingSystem.IsIOS() || $.$$.System.OperatingSystem.IsTvOS());
            }
            //--TRIMMABLE-BOUNDARY-END(21475164239)
            
            static $h = 327759;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770131535),
    {
      "p": 163577857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180196943,
        "f": 50331688
      },
      "n": "StringComparison",
      "d": 327759,
      "h": 25770131535,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(25770131535),
//--TRIMMABLE-BOUNDARY-START(21475164239),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590262351,
        "f": 50331688
      },
      "n": "IsCaseSensitive",
      "d": 327759,
      "h": 21475164239,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(21475164239)
  ],
  "h": 327759
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.PathInternal`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327759)
        
        
        //--TRIMMABLE-BOUNDARY-START(458831)
        $asm.$cls("$sifd.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(382252548175)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(382252548175)
            
            //--TRIMMABLE-BOUNDARY-START(309238104143)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(309238104143);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(309238104143)
            
            //--TRIMMABLE-BOUNDARY-START(403727384655)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(403727384655);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sifd.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(403727384655)
            
            //--TRIMMABLE-BOUNDARY-START(304943136847)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943136847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sifd.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(304943136847)
            
            //--TRIMMABLE-BOUNDARY-START(300648169551)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648169551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sifd.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(300648169551)
            
            //--TRIMMABLE-BOUNDARY-START(60130000975)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(60130000975)
            
            //--TRIMMABLE-BOUNDARY-START(55835033679)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835033679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(55835033679)
            
            //--TRIMMABLE-BOUNDARY-START(51540066383)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(51540066383)
            
            //--TRIMMABLE-BOUNDARY-START(64424968271)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sifd.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(64424968271)
            
            //--TRIMMABLE-BOUNDARY-START(42950131791)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42950131791)
            
            //--TRIMMABLE-BOUNDARY-START(38655164495)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(38655164495)
            
            //--TRIMMABLE-BOUNDARY-START(34360197199)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(34360197199)
            
            //--TRIMMABLE-BOUNDARY-START(47245099087)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sifd.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(47245099087)
            
            //--TRIMMABLE-BOUNDARY-START(377957580879)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(377957580879)
            
            //--TRIMMABLE-BOUNDARY-START(369367646287)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(369367646287)
            
            //--TRIMMABLE-BOUNDARY-START(373662613583)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173333071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$sifd.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.IO.FileSystem.DriveInfo", $.$sifd.System.SR.$type.Assembly);
                    $.$sifd.System.SR.s_resourceManager = temp;
                }
                return $.$sifd.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(373662613583)
            
            //--TRIMMABLE-BOUNDARY-START(30065229903)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914248783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sifd.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842482767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sifd.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30065229903)
            
            //--TRIMMABLE-BOUNDARY-START(12885360719)
            static /*string */ get Arg_MustBeDriveLetterOrRootDir()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554510415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Drive name must be a root directory (i.e. 'C:\\') or a drive letter ('C').";
            }
            //--TRIMMABLE-BOUNDARY-END(12885360719)
            
            //--TRIMMABLE-BOUNDARY-START(17180328015)
            static /*string */ get Arg_MustBeNonEmptyDriveName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144445007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Drive name must not be empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(17180328015)
            
            //--TRIMMABLE-BOUNDARY-START(8590393423)
            static /*string */ get Arg_InvalidDriveChars()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964575823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Illegal characters in drive name '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(8590393423)
            
            //--TRIMMABLE-BOUNDARY-START(68719935567)
            static /*string */ FormatArg_InvalidDriveChars(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Illegal characters in drive name '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(68719935567)
            
            //--TRIMMABLE-BOUNDARY-START(21475295311)
            static /*string */ get Argument_InvalidPathChars()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734379599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Illegal characters in path '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475295311)
            
            //--TRIMMABLE-BOUNDARY-START(73014902863)
            static /*string */ FormatArgument_InvalidPathChars(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014902863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Illegal characters in path '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(73014902863)
            
            //--TRIMMABLE-BOUNDARY-START(25770262607)
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324314191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Specified file length was too large for the file system.";
            }
            //--TRIMMABLE-BOUNDARY-END(25770262607)
            
            //--TRIMMABLE-BOUNDARY-START(313533071439)
            static /*string */ get InvalidOperation_SetVolumeLabelFailed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504183375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Volume labels can only be set for writable local volumes.";
            }
            //--TRIMMABLE-BOUNDARY-END(313533071439)
            
            //--TRIMMABLE-BOUNDARY-START(317828038735)
            static /*string */ get IO_AlreadyExists_Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094117967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create '{0}' because a file or directory with the same name already exists.";
            }
            //--TRIMMABLE-BOUNDARY-END(317828038735)
            
            //--TRIMMABLE-BOUNDARY-START(77309870159)
            static /*string */ FormatIO_AlreadyExists_Name(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot create '{0}' because a file or directory with the same name already exists.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77309870159)
            
            //--TRIMMABLE-BOUNDARY-START(322123006031)
            static /*string */ get IO_DriveNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273987151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find the drive. The drive might not be ready or might not be mapped.";
            }
            //--TRIMMABLE-BOUNDARY-END(322123006031)
            
            //--TRIMMABLE-BOUNDARY-START(326417973327)
            static /*string */ get IO_DriveNotFound_Drive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684052559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find the drive '{0}'. The drive might not be ready or might not be mapped.";
            }
            //--TRIMMABLE-BOUNDARY-END(326417973327)
            
            //--TRIMMABLE-BOUNDARY-START(81604837455)
            static /*string */ FormatIO_DriveNotFound_Drive(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604837455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Could not find the drive '{0}'. The drive might not be ready or might not be mapped.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81604837455)
            
            //--TRIMMABLE-BOUNDARY-START(330712940623)
            static /*string */ get IO_FileExists_Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863921743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The file '{0}' already exists.";
            }
            //--TRIMMABLE-BOUNDARY-END(330712940623)
            
            //--TRIMMABLE-BOUNDARY-START(85899804751)
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899804751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The file '{0}' already exists.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(85899804751)
            
            //--TRIMMABLE-BOUNDARY-START(335007907919)
            static /*string */ get IO_FileNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043790927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to find the specified file.";
            }
            //--TRIMMABLE-BOUNDARY-END(335007907919)
            
            //--TRIMMABLE-BOUNDARY-START(339302875215)
            static /*string */ get IO_FileNotFound_FileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453856335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find file '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(339302875215)
            
            //--TRIMMABLE-BOUNDARY-START(90194772047)
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194772047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Could not find file '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(90194772047)
            
            //--TRIMMABLE-BOUNDARY-START(343597842511)
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633725519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find a part of the path.";
            }
            //--TRIMMABLE-BOUNDARY-END(343597842511)
            
            //--TRIMMABLE-BOUNDARY-START(347892809807)
            static /*string */ get IO_PathNotFound_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223660111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find a part of the path '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(347892809807)
            
            //--TRIMMABLE-BOUNDARY-START(94489739343)
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Could not find a part of the path '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(94489739343)
            
            //--TRIMMABLE-BOUNDARY-START(352187777103)
            static /*string */ get IO_PathTooLong()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403529295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            //--TRIMMABLE-BOUNDARY-END(352187777103)
            
            //--TRIMMABLE-BOUNDARY-START(360777711695)
            static /*string */ get IO_SharingViolation_File()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993463887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            //--TRIMMABLE-BOUNDARY-END(360777711695)
            
            //--TRIMMABLE-BOUNDARY-START(103079673935)
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(103079673935)
            
            //--TRIMMABLE-BOUNDARY-START(365072678991)
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583398479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The process cannot access the file because it is being used by another process.";
            }
            //--TRIMMABLE-BOUNDARY-END(365072678991)
            
            //--TRIMMABLE-BOUNDARY-START(395137450063)
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763267663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Access to the path is denied.";
            }
            //--TRIMMABLE-BOUNDARY-END(395137450063)
            
            //--TRIMMABLE-BOUNDARY-START(399432417359)
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353202255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Access to the path '{0}' is denied.";
            }
            //--TRIMMABLE-BOUNDARY-END(399432417359)
            
            //--TRIMMABLE-BOUNDARY-START(107374641231)
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374641231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Access to the path '{0}' is denied.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(107374641231)
            
            //--TRIMMABLE-BOUNDARY-START(356482744399)
            static /*string */ get IO_PathTooLong_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813594703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            //--TRIMMABLE-BOUNDARY-END(356482744399)
            
            //--TRIMMABLE-BOUNDARY-START(98784706639)
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784706639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(98784706639)
            
            //--TRIMMABLE-BOUNDARY-START(4295426127)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382252548175)
                    this.s_usingResourceKeys = $.$sifd.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(382252548175)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295426127)
            
            static $h = 458831;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 458831
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458831)
        
        
        //--TRIMMABLE-BOUNDARY-START(131151)
        $asm.$cls("$sifd.System.IO.DriveInfo", ($self) => class DriveInfo extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21474967631)
            /*DriveType */ get DriveType()
            {
                return 0/*DriveType.Unknown*/;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967631)
            
            //--TRIMMABLE-BOUNDARY-START(17180000335)
            /*string */ get DriveFormat()
            {
                return "memfs";
            }
            //--TRIMMABLE-BOUNDARY-END(17180000335)
            
            //--TRIMMABLE-BOUNDARY-START(12885033039)
            /*long */ get AvailableFreeSpace()
            {
                return 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033039)
            
            //--TRIMMABLE-BOUNDARY-START(146029019215)
            /*long */ get TotalFreeSpace()
            {
                return 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(146029019215)
            
            //--TRIMMABLE-BOUNDARY-START(150323986511)
            /*long */ get TotalSize()
            {
                return 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(150323986511)
            
            //--TRIMMABLE-BOUNDARY-START(107374313551)
            static /*string[] */ GetMountPoints()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374313551);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Environment.GetLogicalDrives();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374313551)
            
            //--TRIMMABLE-BOUNDARY-START(4295098447)
            /*string*/ _name = null;
            //--TRIMMABLE-BOUNDARY-END(4295098447)
            
            //--TRIMMABLE-BOUNDARY-START(8590065743)
            $ctor$1(/*string*/ driveName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065743);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(driveName, "driveName");
                    this._name = $.$sifd.System.IO.DriveInfo.NormalizeDriveName(driveName);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065743)
            
            //--TRIMMABLE-BOUNDARY-START(137439084623)
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439084623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137439084623)
            
            //--TRIMMABLE-BOUNDARY-START(115964248143)
            /*string */ get Name()
            {
                return this._name;
            }
            //--TRIMMABLE-BOUNDARY-END(115964248143)
            
            //--TRIMMABLE-BOUNDARY-START(111669280847)
            /*bool */ get IsReady()
            {
                return $.$$.System.IO.Directory.Exists(this.Name);
            }
            //--TRIMMABLE-BOUNDARY-END(111669280847)
            
            //--TRIMMABLE-BOUNDARY-START(124554182735)
            /*DirectoryInfo */ get RootDirectory()
            {
                return new $.$$.System.IO.DirectoryInfo().$ctor$5(this.Name);
            }
            //--TRIMMABLE-BOUNDARY-END(124554182735)
            
            //--TRIMMABLE-BOUNDARY-START(141734051919)
            static/*conventional*/ /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141734051919);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Name;
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sifd.System.IO.DriveInfo.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(141734051919)
            
            //--TRIMMABLE-BOUNDARY-START(103079346255)
            static /*DriveInfo[] */ GetDrives()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079346255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string[]*/ let mountPoints = $.$sifd.System.IO.DriveInfo.GetMountPoints();
                /*DriveInfo[]*/ let info = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sifd.System.IO.DriveInfo), null, [mountPoints.length], null);
                for(/*int*/ let i = 0; i < info.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call(info, new $.$sifd.System.IO.DriveInfo().$ctor$1($.$$.System.Array.$ReadT1.call(mountPoints, i)), i);
                }
                return info;
            }
            //--TRIMMABLE-BOUNDARY-END(103079346255)
            
            //--TRIMMABLE-BOUNDARY-START(120259215439)
            static /*string */ NormalizeDriveName(/*string*/ driveName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259215439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.Contains$1.call(driveName, /*\u0000*/ 0))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sifd.System.SR.Format$6($.$sifd.System.SR.Arg_InvalidDriveChars, driveName), "driveName");
                }
                if (driveName.length === 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sifd.System.SR.Arg_MustBeNonEmptyDriveName, "driveName");
                }
                return driveName;
            }
            //--TRIMMABLE-BOUNDARY-END(120259215439)
            
            //--TRIMMABLE-BOUNDARY-START(154618953807)
            /*string */ get VolumeLabel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784378959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            /*string */ set VolumeLabel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144117327);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(154618953807)
            
            static $h = 131151;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474967631),
    {
      "p": 262223,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244771407,
        "f": 50331649
      },
      "n": "DriveType",
      "d": 131151,
      "h": 21474967631,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474967631),
//--TRIMMABLE-BOUNDARY-START(17180000335),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654836815,
        "f": 50331649
      },
      "n": "DriveFormat",
      "d": 131151,
      "h": 17180000335,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180000335),
//--TRIMMABLE-BOUNDARY-START(12885033039),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064902223,
        "f": 50331649
      },
      "n": "AvailableFreeSpace",
      "d": 131151,
      "h": 12885033039,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885033039),
//--TRIMMABLE-BOUNDARY-START(146029019215),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604509775,
        "f": 50331649
      },
      "n": "TotalFreeSpace",
      "d": 131151,
      "h": 146029019215,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146029019215),
//--TRIMMABLE-BOUNDARY-START(150323986511),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194444367,
        "f": 50331649
      },
      "n": "TotalSize",
      "d": 131151,
      "h": 150323986511,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150323986511),
//--TRIMMABLE-BOUNDARY-START(115964248143),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424640591,
        "f": 50331649
      },
      "n": "Name",
      "d": 131151,
      "h": 115964248143,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964248143),
//--TRIMMABLE-BOUNDARY-START(111669280847),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834705999,
        "f": 50331649
      },
      "n": "IsReady",
      "d": 131151,
      "h": 111669280847,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669280847),
//--TRIMMABLE-BOUNDARY-START(124554182735),
    {
      "p": 91488257,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014575183,
        "f": 50331649
      },
      "n": "RootDirectory",
      "d": 131151,
      "h": 124554182735,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124554182735),
//--TRIMMABLE-BOUNDARY-START(154618953807),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784378959,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144117327,
        "f": 83886081,
        "a": [
          {
            "t": 159055873,
            "c": 4454023169,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "VolumeLabel",
      "d": 131151,
      "h": 154618953807,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154618953807)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107374313551),
    {
      "r": $.$typeArray($.$$.System.String).$h,
      "n": "GetMountPoints",
      "d": 131151,
      "h": 107374313551,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107374313551),
//--TRIMMABLE-BOUNDARY-START(141734051919),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 131151,
      "h": 141734051919,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(141734051919),
//--TRIMMABLE-BOUNDARY-START(103079346255),
    {
      "r": $.$typeArray($.$sifd.System.IO.DriveInfo).$h,
      "n": "GetDrives",
      "d": 131151,
      "h": 103079346255,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(103079346255),
//--TRIMMABLE-BOUNDARY-START(120259215439),
    {
      "r": 1310721,
      "p": [
        {
          "n": "driveName",
          "p": 1310721
        }
      ],
      "n": "NormalizeDriveName",
      "d": 131151,
      "h": 120259215439,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120259215439)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098447),
    {
      "t": 1310721,
      "n": "_name",
      "d": 131151,
      "h": 4295098447,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098447)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065743),
    {
      "p": [
        {
          "n": "driveName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131151,
      "h": 8590065743,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065743)
  ],
  "i": [157483009
  ],
  "h": 131151
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.DriveInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131151)
        
        
        //--TRIMMABLE-BOUNDARY-START(262223)
        $asm.$str("$sifd.System.IO.DriveType", ($self) => class DriveType extends $.$$.System.Enum
        {
            static Unknown = 0;
            static NoRootDirectory = 1;
            static Removable = 2;
            static Fixed = 3;
            static Network = 4;
            static CDRom = 5;
            static Ram = 6;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(262223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "NoRootDirectory": 1n,
                    "Removable": 2n,
                    "Fixed": 3n,
                    "Network": 4n,
                    "CDRom": 5n,
                    "Ram": 6n
                };
            }
            static $h = 262223;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360000591),
    {
      "t": 262223,
      "n": "Unknown",
      "d": 262223,
      "h": 34360000591,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360000591),
//--TRIMMABLE-BOUNDARY-START(21475098703),
    {
      "t": 262223,
      "n": "NoRootDirectory",
      "d": 262223,
      "h": 21475098703,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475098703),
//--TRIMMABLE-BOUNDARY-START(30065033295),
    {
      "t": 262223,
      "n": "Removable",
      "d": 262223,
      "h": 30065033295,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065033295),
//--TRIMMABLE-BOUNDARY-START(12885164111),
    {
      "t": 262223,
      "n": "Fixed",
      "d": 262223,
      "h": 12885164111,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885164111),
//--TRIMMABLE-BOUNDARY-START(17180131407),
    {
      "t": 262223,
      "n": "Network",
      "d": 262223,
      "h": 17180131407,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180131407),
//--TRIMMABLE-BOUNDARY-START(8590196815),
    {
      "t": 262223,
      "n": "CDRom",
      "d": 262223,
      "h": 8590196815,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590196815),
//--TRIMMABLE-BOUNDARY-START(25770065999),
    {
      "t": 262223,
      "n": "Ram",
      "d": 262223,
      "h": 25770065999,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770065999)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229519),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262223,
      "h": 4295229519,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229519)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 262223
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.DriveType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262223)
        
        
        //--TRIMMABLE-BOUNDARY-START(196687)
        $asm.$cls("$sifd.System.IO.DriveNotFoundException", ($self) => class DriveNotFoundException extends $.$$.System.IO.IOException
        {
            //--TRIMMABLE-BOUNDARY-START(4295163983)
            $ctor$14()
            {
                super.$ctor$13($.$sifd.System.SR.IO_DriveNotFound);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295163983);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163983)
            
            //--TRIMMABLE-BOUNDARY-START(17180065871)
            $ctor$17(/*string?*/ message)
            {
                super.$ctor$13(message ?? $.$sifd.System.SR.IO_DriveNotFound);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065871);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065871)
            
            //--TRIMMABLE-BOUNDARY-START(12885098575)
            $ctor$16(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message ?? $.$sifd.System.SR.IO_DriveNotFound, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885098575);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098575)
            
            //--TRIMMABLE-BOUNDARY-START(8590131279)
            $ctor$15(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$10(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131279);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131279)
            
            static $h = 196687;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 93519873,
  "h": 196687
}; }
            static get $b() { return $.$$.System.IO.IOException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.DriveNotFoundException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196687)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices"))
//--TRIMMABLE-BOUNDARY-END(79)
