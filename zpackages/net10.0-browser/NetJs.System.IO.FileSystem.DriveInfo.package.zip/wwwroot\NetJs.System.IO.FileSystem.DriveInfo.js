
(function ($global, $, $spc, $sc, $sdt, $sm, $spu, $st, $sr, $scc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.FileSystem.DriveInfo", 
    {"h":57310,"f":"System.IO.FileSystem.DriveInfo","v":"1.0.35.0","a":[{"t":90374145,"c":4385341441},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.FileSystem.DriveInfo","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.FileSystem.DriveInfo","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sifd.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sifd.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.IO.FileSystem.DriveInfo", $.$sifd.System.SR.$type.Assembly);
                    $.$sifd.System.SR.s_resourceManager = temp;
                }
                return $.$sifd.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sifd.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sifd.System.SR.resourceCulture = value;
            }
            static /*string */ get Arg_MustBeDriveLetterOrRootDir()
            {
                return "Drive name must be a root directory (i.e. 'C:\\') or a drive letter ('C').";
            }
            static /*string */ get Arg_MustBeNonEmptyDriveName()
            {
                return "Drive name must not be empty.";
            }
            static /*string */ get Arg_InvalidDriveChars()
            {
                return "Illegal characters in drive name '{0}'.";
            }
            static /*string */ FormatArg_InvalidDriveChars(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Illegal characters in drive name '{0}'.", arg1);
            }
            static /*string */ get Argument_InvalidPathChars()
            {
                return "Illegal characters in path '{0}'.";
            }
            static /*string */ FormatArgument_InvalidPathChars(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Illegal characters in path '{0}'.", arg1);
            }
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                return "Specified file length was too large for the file system.";
            }
            static /*string */ get InvalidOperation_SetVolumeLabelFailed()
            {
                return "Volume labels can only be set for writable local volumes.";
            }
            static /*string */ get IO_AlreadyExists_Name()
            {
                return "Cannot create '{0}' because a file or directory with the same name already exists.";
            }
            static /*string */ FormatIO_AlreadyExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Cannot create '{0}' because a file or directory with the same name already exists.", arg1);
            }
            static /*string */ get IO_DriveNotFound()
            {
                return "Could not find the drive. The drive might not be ready or might not be mapped.";
            }
            static /*string */ get IO_DriveNotFound_Drive()
            {
                return "Could not find the drive '{0}'. The drive might not be ready or might not be mapped.";
            }
            static /*string */ FormatIO_DriveNotFound_Drive(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find the drive '{0}'. The drive might not be ready or might not be mapped.", arg1);
            }
            static /*string */ get IO_FileExists_Name()
            {
                return "The file '{0}' already exists.";
            }
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The file '{0}' already exists.", arg1);
            }
            static /*string */ get IO_FileNotFound()
            {
                return "Unable to find the specified file.";
            }
            static /*string */ get IO_FileNotFound_FileName()
            {
                return "Could not find file '{0}'.";
            }
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find file '{0}'.", arg1);
            }
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                return "Could not find a part of the path.";
            }
            static /*string */ get IO_PathNotFound_Path()
            {
                return "Could not find a part of the path '{0}'.";
            }
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find a part of the path '{0}'.", arg1);
            }
            static /*string */ get IO_PathTooLong()
            {
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            static /*string */ get IO_SharingViolation_File()
            {
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                return "The process cannot access the file because it is being used by another process.";
            }
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                return "Access to the path is denied.";
            }
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                return "Access to the path '{0}' is denied.";
            }
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Access to the path '{0}' is denied.", arg1);
            }
            static /*string */ get IO_PathTooLong_Path()
            {
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sifd.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sifd.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sifd.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sifd.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sifd.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sifd.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 516062;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":516062}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sifd.System.HResults", ($self) => class HResults
        {
            /*int*/ static S_OK = 0;
            /*int*/ static S_FALSE = 1;
            /*int*/ static COR_E_ABANDONEDMUTEX = -2146233043;
            /*int*/ static COR_E_AMBIGUOUSIMPLEMENTATION = -2146234262;
            /*int*/ static COR_E_AMBIGUOUSMATCH = -2147475171;
            /*int*/ static COR_E_APPDOMAINUNLOADED = -2146234348;
            /*int*/ static COR_E_APPLICATION = -2146232832;
            /*int*/ static COR_E_ARGUMENT = -2147024809;
            /*int*/ static COR_E_ARGUMENTOUTOFRANGE = -2146233086;
            /*int*/ static COR_E_ARITHMETIC = -2147024362;
            /*int*/ static COR_E_ARRAYTYPEMISMATCH = -2146233085;
            /*int*/ static COR_E_BADEXEFORMAT = -2147024703;
            /*int*/ static COR_E_BADIMAGEFORMAT = -2147024885;
            /*int*/ static COR_E_CANNOTUNLOADAPPDOMAIN = -2146234347;
            /*int*/ static COR_E_CODECONTRACTFAILED = -2146233022;
            /*int*/ static COR_E_CONTEXTMARSHAL = -2146233084;
            /*int*/ static COR_E_CUSTOMATTRIBUTEFORMAT = -2146232827;
            /*int*/ static COR_E_DATAMISALIGNED = -2146233023;
            /*int*/ static COR_E_DIRECTORYNOTFOUND = -2147024893;
            /*int*/ static COR_E_DIVIDEBYZERO = -2147352558;
            /*int*/ static COR_E_DLLNOTFOUND = -2146233052;
            /*int*/ static COR_E_DUPLICATEWAITOBJECT = -2146233047;
            /*int*/ static COR_E_ENDOFSTREAM = -2147024858;
            /*int*/ static COR_E_ENTRYPOINTNOTFOUND = -2146233053;
            /*int*/ static COR_E_EXCEPTION = -2146233088;
            /*int*/ static COR_E_EXECUTIONENGINE = -2146233082;
            /*int*/ static COR_E_FAILFAST = -2146232797;
            /*int*/ static COR_E_FIELDACCESS = -2146233081;
            /*int*/ static COR_E_FILELOAD = -2146232799;
            /*int*/ static COR_E_FILENOTFOUND = -2147024894;
            /*int*/ static COR_E_FORMAT = -2146233033;
            /*int*/ static COR_E_INDEXOUTOFRANGE = -2146233080;
            /*int*/ static COR_E_INSUFFICIENTEXECUTIONSTACK = -2146232968;
            /*int*/ static COR_E_INSUFFICIENTMEMORY = -2146233027;
            /*int*/ static COR_E_INVALIDCAST = -2147467262;
            /*int*/ static COR_E_INVALIDCOMOBJECT = -2146233049;
            /*int*/ static COR_E_INVALIDFILTERCRITERIA = -2146232831;
            /*int*/ static COR_E_INVALIDOLEVARIANTTYPE = -2146233039;
            /*int*/ static COR_E_INVALIDOPERATION = -2146233079;
            /*int*/ static COR_E_INVALIDPROGRAM = -2146233030;
            /*int*/ static COR_E_IO = -2146232800;
            /*int*/ static COR_E_KEYNOTFOUND = -2146232969;
            /*int*/ static COR_E_MARSHALDIRECTIVE = -2146233035;
            /*int*/ static COR_E_MEMBERACCESS = -2146233062;
            /*int*/ static COR_E_METHODACCESS = -2146233072;
            /*int*/ static COR_E_MISSINGFIELD = -2146233071;
            /*int*/ static COR_E_MISSINGMANIFESTRESOURCE = -2146233038;
            /*int*/ static COR_E_MISSINGMEMBER = -2146233070;
            /*int*/ static COR_E_MISSINGMETHOD = -2146233069;
            /*int*/ static COR_E_MISSINGSATELLITEASSEMBLY = -2146233034;
            /*int*/ static COR_E_MULTICASTNOTSUPPORTED = -2146233068;
            /*int*/ static COR_E_NOTFINITENUMBER = -2146233048;
            /*int*/ static COR_E_NOTSUPPORTED = -2146233067;
            /*int*/ static COR_E_OBJECTDISPOSED = -2146232798;
            /*int*/ static COR_E_OPERATIONCANCELED = -2146233029;
            /*int*/ static COR_E_OUTOFMEMORY = -2147024882;
            /*int*/ static COR_E_OVERFLOW = -2146233066;
            /*int*/ static COR_E_PATHTOOLONG = -2147024690;
            /*int*/ static COR_E_PLATFORMNOTSUPPORTED = -2146233031;
            /*int*/ static COR_E_RANK = -2146233065;
            /*int*/ static COR_E_REFLECTIONTYPELOAD = -2146232830;
            /*int*/ static COR_E_RUNTIMEWRAPPED = -2146233026;
            /*int*/ static COR_E_SAFEARRAYRANKMISMATCH = -2146233032;
            /*int*/ static COR_E_SAFEARRAYTYPEMISMATCH = -2146233037;
            /*int*/ static COR_E_SECURITY = -2146233078;
            /*int*/ static COR_E_SERIALIZATION = -2146233076;
            /*int*/ static COR_E_STACKOVERFLOW = -2147023895;
            /*int*/ static COR_E_SYNCHRONIZATIONLOCK = -2146233064;
            /*int*/ static COR_E_SYSTEM = -2146233087;
            /*int*/ static COR_E_TARGET = -2146232829;
            /*int*/ static COR_E_TARGETINVOCATION = -2146232828;
            /*int*/ static COR_E_TARGETPARAMCOUNT = -2147352562;
            /*int*/ static COR_E_THREADABORTED = -2146233040;
            /*int*/ static COR_E_THREADINTERRUPTED = -2146233063;
            /*int*/ static COR_E_THREADSTART = -2146233051;
            /*int*/ static COR_E_THREADSTATE = -2146233056;
            /*int*/ static COR_E_TIMEOUT = -2146233083;
            /*int*/ static COR_E_TYPEACCESS = -2146233021;
            /*int*/ static COR_E_TYPEINITIALIZATION = -2146233036;
            /*int*/ static COR_E_TYPELOAD = -2146233054;
            /*int*/ static COR_E_TYPEUNLOADED = -2146234349;
            /*int*/ static COR_E_UNAUTHORIZEDACCESS = -2147024891;
            /*int*/ static COR_E_VERIFICATION = -2146233075;
            /*int*/ static COR_E_WAITHANDLECANNOTBEOPENED = -2146233044;
            /*int*/ static CO_E_NOTINITIALIZED = -2147221008;
            /*int*/ static DISP_E_PARAMNOTFOUND = -2147352572;
            /*int*/ static DISP_E_TYPEMISMATCH = -2147352571;
            /*int*/ static DISP_E_BADVARTYPE = -2147352568;
            /*int*/ static DISP_E_OVERFLOW = -2147352566;
            /*int*/ static DISP_E_DIVBYZERO = -2147352558;
            /*int*/ static E_BOUNDS = -2147483637;
            /*int*/ static E_CHANGED_STATE = -2147483636;
            /*int*/ static E_FILENOTFOUND = -2147024894;
            /*int*/ static E_FAIL = -2147467259;
            /*int*/ static E_HANDLE = -2147024890;
            /*int*/ static E_INVALIDARG = -2147024809;
            /*int*/ static E_NOTIMPL = -2147467263;
            /*int*/ static E_OUTOFMEMORY = -2147024882;
            /*int*/ static E_POINTER = -2147467261;
            /*int*/ static ERROR_MRM_MAP_NOT_FOUND = -2147009761;
            /*int*/ static ERROR_TIMEOUT = -2147023436;
            /*int*/ static RO_E_CLOSED = -2147483629;
            /*int*/ static RPC_E_CHANGED_MODE = -2147417850;
            /*int*/ static TYPE_E_TYPEMISMATCH = -2147316576;
            /*int*/ static STG_E_PATHNOTFOUND = -2147287037;
            /*int*/ static CTL_E_PATHNOTFOUND = -2146828212;
            /*int*/ static CTL_E_FILENOTFOUND = -2146828235;
            /*int*/ static FUSION_E_INVALID_NAME = -2146234297;
            /*int*/ static FUSION_E_REF_DEF_MISMATCH = -2146234304;
            /*int*/ static ERROR_TOO_MANY_OPEN_FILES = -2147024892;
            /*int*/ static ERROR_SHARING_VIOLATION = -2147024864;
            /*int*/ static ERROR_LOCK_VIOLATION = -2147024863;
            /*int*/ static ERROR_OPEN_FAILED = -2147024786;
            /*int*/ static ERROR_DISK_CORRUPT = -2147023503;
            /*int*/ static ERROR_UNRECOGNIZED_VOLUME = -2147023891;
            /*int*/ static ERROR_DLL_INIT_FAILED = -2147023782;
            /*int*/ static MSEE_E_ASSEMBLYLOADINPROGRESS = -2146234346;
            /*int*/ static ERROR_FILE_INVALID = -2147023890;
            static $h = 122846;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"S_OK","d":122846,"h":4295090142,"f":40},{"t":655361,"n":"S_FALSE","d":122846,"h":8590057438,"f":40},{"t":655361,"n":"COR_E_ABANDONEDMUTEX","d":122846,"h":12885024734,"f":40},{"t":655361,"n":"COR_E_AMBIGUOUSIMPLEMENTATION","d":122846,"h":17179992030,"f":40},{"t":655361,"n":"COR_E_AMBIGUOUSMATCH","d":122846,"h":21474959326,"f":40},{"t":655361,"n":"COR_E_APPDOMAINUNLOADED","d":122846,"h":25769926622,"f":40},{"t":655361,"n":"COR_E_APPLICATION","d":122846,"h":30064893918,"f":40},{"t":655361,"n":"COR_E_ARGUMENT","d":122846,"h":34359861214,"f":40},{"t":655361,"n":"COR_E_ARGUMENTOUTOFRANGE","d":122846,"h":38654828510,"f":40},{"t":655361,"n":"COR_E_ARITHMETIC","d":122846,"h":42949795806,"f":40},{"t":655361,"n":"COR_E_ARRAYTYPEMISMATCH","d":122846,"h":47244763102,"f":40},{"t":655361,"n":"COR_E_BADEXEFORMAT","d":122846,"h":51539730398,"f":40},{"t":655361,"n":"COR_E_BADIMAGEFORMAT","d":122846,"h":55834697694,"f":40},{"t":655361,"n":"COR_E_CANNOTUNLOADAPPDOMAIN","d":122846,"h":60129664990,"f":40},{"t":655361,"n":"COR_E_CODECONTRACTFAILED","d":122846,"h":64424632286,"f":40},{"t":655361,"n":"COR_E_CONTEXTMARSHAL","d":122846,"h":68719599582,"f":40},{"t":655361,"n":"COR_E_CUSTOMATTRIBUTEFORMAT","d":122846,"h":73014566878,"f":40},{"t":655361,"n":"COR_E_DATAMISALIGNED","d":122846,"h":77309534174,"f":40},{"t":655361,"n":"COR_E_DIRECTORYNOTFOUND","d":122846,"h":81604501470,"f":40},{"t":655361,"n":"COR_E_DIVIDEBYZERO","d":122846,"h":85899468766,"f":40},{"t":655361,"n":"COR_E_DLLNOTFOUND","d":122846,"h":90194436062,"f":40},{"t":655361,"n":"COR_E_DUPLICATEWAITOBJECT","d":122846,"h":94489403358,"f":40},{"t":655361,"n":"COR_E_ENDOFSTREAM","d":122846,"h":98784370654,"f":40},{"t":655361,"n":"COR_E_ENTRYPOINTNOTFOUND","d":122846,"h":103079337950,"f":40},{"t":655361,"n":"COR_E_EXCEPTION","d":122846,"h":107374305246,"f":40},{"t":655361,"n":"COR_E_EXECUTIONENGINE","d":122846,"h":111669272542,"f":40},{"t":655361,"n":"COR_E_FAILFAST","d":122846,"h":115964239838,"f":40},{"t":655361,"n":"COR_E_FIELDACCESS","d":122846,"h":120259207134,"f":40},{"t":655361,"n":"COR_E_FILELOAD","d":122846,"h":124554174430,"f":40},{"t":655361,"n":"COR_E_FILENOTFOUND","d":122846,"h":128849141726,"f":40},{"t":655361,"n":"COR_E_FORMAT","d":122846,"h":133144109022,"f":40},{"t":655361,"n":"COR_E_INDEXOUTOFRANGE","d":122846,"h":137439076318,"f":40},{"t":655361,"n":"COR_E_INSUFFICIENTEXECUTIONSTACK","d":122846,"h":141734043614,"f":40},{"t":655361,"n":"COR_E_INSUFFICIENTMEMORY","d":122846,"h":146029010910,"f":40},{"t":655361,"n":"COR_E_INVALIDCAST","d":122846,"h":150323978206,"f":40},{"t":655361,"n":"COR_E_INVALIDCOMOBJECT","d":122846,"h":154618945502,"f":40},{"t":655361,"n":"COR_E_INVALIDFILTERCRITERIA","d":122846,"h":158913912798,"f":40},{"t":655361,"n":"COR_E_INVALIDOLEVARIANTTYPE","d":122846,"h":163208880094,"f":40},{"t":655361,"n":"COR_E_INVALIDOPERATION","d":122846,"h":167503847390,"f":40},{"t":655361,"n":"COR_E_INVALIDPROGRAM","d":122846,"h":171798814686,"f":40},{"t":655361,"n":"COR_E_IO","d":122846,"h":176093781982,"f":40},{"t":655361,"n":"COR_E_KEYNOTFOUND","d":122846,"h":180388749278,"f":40},{"t":655361,"n":"COR_E_MARSHALDIRECTIVE","d":122846,"h":184683716574,"f":40},{"t":655361,"n":"COR_E_MEMBERACCESS","d":122846,"h":188978683870,"f":40},{"t":655361,"n":"COR_E_METHODACCESS","d":122846,"h":193273651166,"f":40},{"t":655361,"n":"COR_E_MISSINGFIELD","d":122846,"h":197568618462,"f":40},{"t":655361,"n":"COR_E_MISSINGMANIFESTRESOURCE","d":122846,"h":201863585758,"f":40},{"t":655361,"n":"COR_E_MISSINGMEMBER","d":122846,"h":206158553054,"f":40},{"t":655361,"n":"COR_E_MISSINGMETHOD","d":122846,"h":210453520350,"f":40},{"t":655361,"n":"COR_E_MISSINGSATELLITEASSEMBLY","d":122846,"h":214748487646,"f":40},{"t":655361,"n":"COR_E_MULTICASTNOTSUPPORTED","d":122846,"h":219043454942,"f":40},{"t":655361,"n":"COR_E_NOTFINITENUMBER","d":122846,"h":223338422238,"f":40},{"t":655361,"n":"COR_E_NOTSUPPORTED","d":122846,"h":227633389534,"f":40},{"t":655361,"n":"COR_E_OBJECTDISPOSED","d":122846,"h":231928356830,"f":40},{"t":655361,"n":"COR_E_OPERATIONCANCELED","d":122846,"h":236223324126,"f":40},{"t":655361,"n":"COR_E_OUTOFMEMORY","d":122846,"h":240518291422,"f":40},{"t":655361,"n":"COR_E_OVERFLOW","d":122846,"h":244813258718,"f":40},{"t":655361,"n":"COR_E_PATHTOOLONG","d":122846,"h":249108226014,"f":40},{"t":655361,"n":"COR_E_PLATFORMNOTSUPPORTED","d":122846,"h":253403193310,"f":40},{"t":655361,"n":"COR_E_RANK","d":122846,"h":257698160606,"f":40},{"t":655361,"n":"COR_E_REFLECTIONTYPELOAD","d":122846,"h":261993127902,"f":40},{"t":655361,"n":"COR_E_RUNTIMEWRAPPED","d":122846,"h":266288095198,"f":40},{"t":655361,"n":"COR_E_SAFEARRAYRANKMISMATCH","d":122846,"h":270583062494,"f":40},{"t":655361,"n":"COR_E_SAFEARRAYTYPEMISMATCH","d":122846,"h":274878029790,"f":40},{"t":655361,"n":"COR_E_SECURITY","d":122846,"h":279172997086,"f":40},{"t":655361,"n":"COR_E_SERIALIZATION","d":122846,"h":283467964382,"f":40},{"t":655361,"n":"COR_E_STACKOVERFLOW","d":122846,"h":287762931678,"f":40},{"t":655361,"n":"COR_E_SYNCHRONIZATIONLOCK","d":122846,"h":292057898974,"f":40},{"t":655361,"n":"COR_E_SYSTEM","d":122846,"h":296352866270,"f":40},{"t":655361,"n":"COR_E_TARGET","d":122846,"h":300647833566,"f":40},{"t":655361,"n":"COR_E_TARGETINVOCATION","d":122846,"h":304942800862,"f":40},{"t":655361,"n":"COR_E_TARGETPARAMCOUNT","d":122846,"h":309237768158,"f":40},{"t":655361,"n":"COR_E_THREADABORTED","d":122846,"h":313532735454,"f":40},{"t":655361,"n":"COR_E_THREADINTERRUPTED","d":122846,"h":317827702750,"f":40},{"t":655361,"n":"COR_E_THREADSTART","d":122846,"h":322122670046,"f":40},{"t":655361,"n":"COR_E_THREADSTATE","d":122846,"h":326417637342,"f":40},{"t":655361,"n":"COR_E_TIMEOUT","d":122846,"h":330712604638,"f":40},{"t":655361,"n":"COR_E_TYPEACCESS","d":122846,"h":335007571934,"f":40},{"t":655361,"n":"COR_E_TYPEINITIALIZATION","d":122846,"h":339302539230,"f":40},{"t":655361,"n":"COR_E_TYPELOAD","d":122846,"h":343597506526,"f":40},{"t":655361,"n":"COR_E_TYPEUNLOADED","d":122846,"h":347892473822,"f":40},{"t":655361,"n":"COR_E_UNAUTHORIZEDACCESS","d":122846,"h":352187441118,"f":40},{"t":655361,"n":"COR_E_VERIFICATION","d":122846,"h":356482408414,"f":40},{"t":655361,"n":"COR_E_WAITHANDLECANNOTBEOPENED","d":122846,"h":360777375710,"f":40},{"t":655361,"n":"CO_E_NOTINITIALIZED","d":122846,"h":365072343006,"f":40},{"t":655361,"n":"DISP_E_PARAMNOTFOUND","d":122846,"h":369367310302,"f":40},{"t":655361,"n":"DISP_E_TYPEMISMATCH","d":122846,"h":373662277598,"f":40},{"t":655361,"n":"DISP_E_BADVARTYPE","d":122846,"h":377957244894,"f":40},{"t":655361,"n":"DISP_E_OVERFLOW","d":122846,"h":382252212190,"f":40},{"t":655361,"n":"DISP_E_DIVBYZERO","d":122846,"h":386547179486,"f":40},{"t":655361,"n":"E_BOUNDS","d":122846,"h":390842146782,"f":40},{"t":655361,"n":"E_CHANGED_STATE","d":122846,"h":395137114078,"f":40},{"t":655361,"n":"E_FILENOTFOUND","d":122846,"h":399432081374,"f":40},{"t":655361,"n":"E_FAIL","d":122846,"h":403727048670,"f":40},{"t":655361,"n":"E_HANDLE","d":122846,"h":408022015966,"f":40},{"t":655361,"n":"E_INVALIDARG","d":122846,"h":412316983262,"f":40},{"t":655361,"n":"E_NOTIMPL","d":122846,"h":416611950558,"f":40},{"t":655361,"n":"E_OUTOFMEMORY","d":122846,"h":420906917854,"f":40},{"t":655361,"n":"E_POINTER","d":122846,"h":425201885150,"f":40},{"t":655361,"n":"ERROR_MRM_MAP_NOT_FOUND","d":122846,"h":429496852446,"f":40},{"t":655361,"n":"ERROR_TIMEOUT","d":122846,"h":433791819742,"f":40},{"t":655361,"n":"RO_E_CLOSED","d":122846,"h":438086787038,"f":40},{"t":655361,"n":"RPC_E_CHANGED_MODE","d":122846,"h":442381754334,"f":40},{"t":655361,"n":"TYPE_E_TYPEMISMATCH","d":122846,"h":446676721630,"f":40},{"t":655361,"n":"STG_E_PATHNOTFOUND","d":122846,"h":450971688926,"f":40},{"t":655361,"n":"CTL_E_PATHNOTFOUND","d":122846,"h":455266656222,"f":40},{"t":655361,"n":"CTL_E_FILENOTFOUND","d":122846,"h":459561623518,"f":40},{"t":655361,"n":"FUSION_E_INVALID_NAME","d":122846,"h":463856590814,"f":40},{"t":655361,"n":"FUSION_E_REF_DEF_MISMATCH","d":122846,"h":468151558110,"f":40},{"t":655361,"n":"ERROR_TOO_MANY_OPEN_FILES","d":122846,"h":472446525406,"f":40},{"t":655361,"n":"ERROR_SHARING_VIOLATION","d":122846,"h":476741492702,"f":40},{"t":655361,"n":"ERROR_LOCK_VIOLATION","d":122846,"h":481036459998,"f":40},{"t":655361,"n":"ERROR_OPEN_FAILED","d":122846,"h":485331427294,"f":40},{"t":655361,"n":"ERROR_DISK_CORRUPT","d":122846,"h":489626394590,"f":40},{"t":655361,"n":"ERROR_UNRECOGNIZED_VOLUME","d":122846,"h":493921361886,"f":40},{"t":655361,"n":"ERROR_DLL_INIT_FAILED","d":122846,"h":498216329182,"f":40},{"t":655361,"n":"MSEE_E_ASSEMBLYLOADINPROGRESS","d":122846,"h":502511296478,"f":40},{"t":655361,"n":"ERROR_FILE_INVALID","d":122846,"h":506806263774,"f":40}],"h":122846}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.HResults`; }
        });
        
        $asm.$cls("$sifd.System.IO.PathInternal", ($self) => class PathInternal
        {
            static /*StringComparison */ get StringComparison()
            {
                return $.$sifd.System.IO.PathInternal.IsCaseSensitive ? 4/*StringComparison.Ordinal*/ : 5/*StringComparison.OrdinalIgnoreCase*/;
            }
            static /*bool */ get IsCaseSensitive()
            {
                return !($.$spc.System.OperatingSystem.IsWindows() || $.$spc.System.OperatingSystem.IsMacOS() || $.$spc.System.OperatingSystem.IsIOS() || $.$spc.System.OperatingSystem.IsTvOS());
            }
            static $h = 384990;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":119472129,"g":{"r":0,"d":0,"h":8590319582,"f":40},"n":"StringComparison","d":384990,"h":4295352286,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":17180254174,"f":40},"n":"IsCaseSensitive","d":384990,"h":12885286878,"f":40}],"h":384990}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.PathInternal`; }
        });
        
        $asm.$cls("$sifd.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 450526;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":450526,"h":4295417822,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":450526,"h":8590385118,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":450526,"h":12885352414,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":450526,"h":17180319710,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":450526,"h":21475287006,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":450526,"h":25770254302,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":450526,"h":30065221598,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":450526,"h":34360188894,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":450526,"h":38655156190,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":450526,"h":42950123486,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":450526,"h":47245090782,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":450526,"h":51540058078,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":450526,"h":55835025374,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":450526,"h":60129992670,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":450526,"h":64424959966,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":450526,"h":68719927262,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":450526,"h":73014894558,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":450526,"h":77309861854,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":450526,"h":81604829150,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":450526,"h":85899796446,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":450526,"h":90194763742,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":450526,"h":94489731038,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":450526,"h":98784698334,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":450526,"h":103079665630,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":450526,"h":107374632926,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":450526,"h":111669600222,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":450526,"h":115964567518,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":450526,"h":120259534814,"f":40},{"t":1310721,"n":"WebRequestMessage","d":450526,"h":124554502110,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":450526,"h":128849469406,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":450526,"h":133144436702,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":450526,"h":137439403998,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":450526,"h":141734371294,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":450526,"h":146029338590,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":450526,"h":150324305886,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":450526,"h":154619273182,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":450526,"h":158914240478,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":450526,"h":163209207774,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":450526,"h":167504175070,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":450526,"h":171799142366,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":450526,"h":176094109662,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":450526,"h":180389076958,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":450526,"h":184684044254,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":450526,"h":188979011550,"f":40},{"t":1310721,"n":"RijndaelMessage","d":450526,"h":193273978846,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":450526,"h":197568946142,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":450526,"h":201863913438,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":450526,"h":206158880734,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":450526,"h":210453848030,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":450526,"h":214748815326,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":450526,"h":219043782622,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":450526,"h":223338749918,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":450526,"h":227633717214,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":450526,"h":231928684510,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":450526,"h":236223651806,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":450526,"h":240518619102,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":450526,"h":244813586398,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":450526,"h":249108553694,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":450526,"h":253403520990,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":450526,"h":257698488286,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":450526,"h":261993455582,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":450526,"h":266288422878,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":450526,"h":270583390174,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":450526,"h":274878357470,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":450526,"h":279173324766,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":450526,"h":283468292062,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":450526,"h":287763259358,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":450526,"h":292058226654,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":450526,"h":296353193950,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":450526,"h":300648161246,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":450526,"h":304943128542,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":450526,"h":309238095838,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":450526,"h":313533063134,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":450526,"h":317828030430,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":450526,"h":322122997726,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":450526,"h":326417965022,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":450526,"h":330712932318,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":450526,"h":335007899614,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":450526,"h":339302866910,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":450526,"h":343597834206,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":450526,"h":347892801502,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":450526,"h":352187768798,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":450526,"h":356482736094,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":450526,"h":360777703390,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":450526,"h":365072670686,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":450526,"h":369367637982,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":450526,"h":373662605278,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":450526,"h":377957572574,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":450526,"h":382252539870,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":450526,"h":386547507166,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":450526,"h":390842474462,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":450526,"h":395137441758,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":450526,"h":399432409054,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":450526,"h":403727376350,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":450526,"h":408022343646,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":450526,"h":412317310942,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":450526,"h":416612278238,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":450526,"h":420907245534,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":450526,"h":425202212830,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":450526,"h":429497180126,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":450526,"h":433792147422,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":450526,"h":438087114718,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":450526,"h":442382082014,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":450526,"h":446677049310,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":450526,"h":450972016606,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":450526,"h":455266983902,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":450526,"h":459561951198,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":450526,"h":463856918494,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":450526,"h":468151885790,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":450526,"h":472446853086,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":450526,"h":476741820382,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":450526,"h":481036787678,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":450526,"h":485331754974,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":450526,"h":489626722270,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":450526,"h":493921689566,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":450526,"h":498216656862,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":450526,"h":502511624158,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":450526,"h":506806591454,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":450526,"h":511101558750,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":450526,"h":515396526046,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":450526,"h":519691493342,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":450526,"h":523986460638,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":450526,"h":528281427934,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":450526,"h":532576395230,"f":40}],"h":450526}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$sifd.System.IO.DriveInfo", ($self) => class DriveInfo extends $.$spc.System.Object
        {
            /*string*/ _name = null;
            $ctor$1(/*string*/ driveName)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(driveName, "driveName");
                    this._name = $.$sifd.System.IO.DriveInfo.NormalizeDriveName(driveName);
                }
                return this;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                return this._name;
            }
            /*bool */ get IsReady()
            {
                return $.$spc.System.IO.Directory.Exists(this.Name);
            }
            /*DirectoryInfo */ get RootDirectory()
            {
                return new $.$spc.System.IO.DirectoryInfo().$ctor$4(this.Name);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.Name;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sifd.System.IO.DriveInfo.ToString.apply(this, arguments); }
            static /*DriveInfo[] */ GetDrives()
            {
                /*string[]*/ let mountPoints = $.$sifd.System.IO.DriveInfo.GetMountPoints();
                /*DriveInfo[]*/ let info = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sifd.System.IO.DriveInfo), null, [mountPoints.length], null);
                for(/*int*/ let i = 0; i < info.length; i++)
                {
                    $.$spc.System.Array.$WriteT1.call(info, new $.$sifd.System.IO.DriveInfo().$ctor$1($.$spc.System.Array.$ReadT1.call(mountPoints, i)), i);
                }
                return info;
            }
            static /*string */ NormalizeDriveName(/*string*/ driveName)
            {
                if ($.$spc.System.String.Contains$2.call(driveName, /*\u0000*/ 0))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sifd.System.SR.Format($.$sifd.System.SR.Arg_InvalidDriveChars, driveName), "driveName");
                }
                if (driveName.length === 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sifd.System.SR.Arg_MustBeNonEmptyDriveName, "driveName");
                }
                return driveName;
            }
            /*string */ get VolumeLabel()
            {
                return this.Name;
            }
            /*string */ set VolumeLabel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*DriveType */ get DriveType()
            {
                return 0/*DriveType.Unknown*/;
            }
            /*string */ get DriveFormat()
            {
                return "memfs";
            }
            /*long */ get AvailableFreeSpace()
            {
                return 0n;
            }
            /*long */ get TotalFreeSpace()
            {
                return 0n;
            }
            /*long */ get TotalSize()
            {
                return 0n;
            }
            static /*string[] */ GetMountPoints()
            {
                return $.$spc.System.Environment.GetLogicalDrives();
            }
            static $h = 188382;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475024862,"f":1},"n":"Name","d":188382,"h":17180057566,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30064959454,"f":1},"n":"IsReady","d":188382,"h":25769992158,"f":1},{"p":58654721,"g":{"r":0,"d":0,"h":38654894046,"f":1},"n":"RootDirectory","d":188382,"h":34359926750,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60129730526,"f":1},"s":{"r":0,"d":0,"h":64424697822,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"VolumeLabel","d":188382,"h":55834763230,"f":1},{"p":319454,"g":{"r":0,"d":0,"h":73014632414,"f":1},"n":"DriveType","d":188382,"h":68719665118,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604567006,"f":1},"n":"DriveFormat","d":188382,"h":77309599710,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":90194501598,"f":1},"n":"AvailableFreeSpace","d":188382,"h":85899534302,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":98784436190,"f":1},"n":"TotalFreeSpace","d":188382,"h":94489468894,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":107374370782,"f":1},"n":"TotalSize","d":188382,"h":103079403486,"f":1}],"m":[{"r":1310721,"n":"ToString","d":188382,"h":42949861342,"f":32769},{"r":0,"n":"GetDrives","d":188382,"h":47244828638,"f":33},{"r":1310721,"p":[{"n":"driveName","p":1310721}],"n":"NormalizeDriveName","d":188382,"h":51539795934,"f":34},{"r":0,"n":"GetMountPoints","d":188382,"h":111669338078,"f":34}],"l":[{"t":1310721,"n":"_name","d":188382,"h":4295155678,"f":2}],"c":[{"p":[{"n":"driveName","p":1310721}],"n":".ctor","o":"$ctor$1","d":188382,"h":8590122974,"f":1}],"i":[113377281],"h":188382}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.DriveInfo`; }
        });
        
        $asm.$str("$sifd.System.IO.DriveType", ($self) => class DriveType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static NoRootDirectory = 1;
            static Removable = 2;
            static Fixed = 3;
            static Network = 4;
            static CDRom = 5;
            static Ram = 6;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "NoRootDirectory": 1n,
                    "Removable": 2n,
                    "Fixed": 3n,
                    "Network": 4n,
                    "CDRom": 5n,
                    "Ram": 6n
                };
            }
            static $h = 319454;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":319454,"n":"Unknown","d":319454,"h":4295286750,"f":33},{"t":319454,"n":"NoRootDirectory","d":319454,"h":8590254046,"f":33},{"t":319454,"n":"Removable","d":319454,"h":12885221342,"f":33},{"t":319454,"n":"Fixed","d":319454,"h":17180188638,"f":33},{"t":319454,"n":"Network","d":319454,"h":21475155934,"f":33},{"t":319454,"n":"CDRom","d":319454,"h":25770123230,"f":33},{"t":319454,"n":"Ram","d":319454,"h":30065090526,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":319454,"h":34360057822,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":319454}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.DriveType`; }
        });
        
        $asm.$cls("$sifd.System.IO.DriveNotFoundException", ($self) => class DriveNotFoundException extends $.$spc.System.IO.IOException
        {
            $ctor$14()
            {
                super.$ctor$10($.$sifd.System.SR.IO_DriveNotFound);
                {
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            $ctor$15(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$sifd.System.SR.IO_DriveNotFound);
                {
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            $ctor$16(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$12(message ?? $.$sifd.System.SR.IO_DriveNotFound, innerException);
                {
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            $ctor$17(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$13(info, context);
                {
                }
                return this;
            }
            static $h = 253918;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":60686337,"h":253918}; }
            static get $b() { return $.$spc.System.IO.IOException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.DriveNotFoundException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices"))