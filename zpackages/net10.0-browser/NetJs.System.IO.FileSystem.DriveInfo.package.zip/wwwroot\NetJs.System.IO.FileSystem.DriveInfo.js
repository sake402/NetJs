
(function ($global, $, $spc, $sc, $sdt, $sm, $spu, $st, $sr, $scc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.FileSystem.DriveInfo", 
    {"h":60952,"f":"System.IO.FileSystem.DriveInfo","v":"1.0.35.0","a":[{"t":90374145,"c":4385341441},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.FileSystem.DriveInfo","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.FileSystem.DriveInfo","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sifd.System.HResults", ($self) => class HResults
        {
            /*int*/ static S_OK = 0;
            /*int*/ static S_FALSE = 1;
            /*int*/ static COR_E_ABANDONEDMUTEX = -2146233043;
            /*int*/ static COR_E_AMBIGUOUSIMPLEMENTATION = -2146234262;
            /*int*/ static COR_E_AMBIGUOUSMATCH = -2147475171;
            /*int*/ static COR_E_APPDOMAINUNLOADED = -2146234348;
            /*int*/ static COR_E_APPLICATION = -2146232832;
            /*int*/ static COR_E_ARGUMENT = -2147024809;
            /*int*/ static COR_E_ARGUMENTOUTOFRANGE = -2146233086;
            /*int*/ static COR_E_ARITHMETIC = -2147024362;
            /*int*/ static COR_E_ARRAYTYPEMISMATCH = -2146233085;
            /*int*/ static COR_E_BADEXEFORMAT = -2147024703;
            /*int*/ static COR_E_BADIMAGEFORMAT = -2147024885;
            /*int*/ static COR_E_CANNOTUNLOADAPPDOMAIN = -2146234347;
            /*int*/ static COR_E_CODECONTRACTFAILED = -2146233022;
            /*int*/ static COR_E_CONTEXTMARSHAL = -2146233084;
            /*int*/ static COR_E_CUSTOMATTRIBUTEFORMAT = -2146232827;
            /*int*/ static COR_E_DATAMISALIGNED = -2146233023;
            /*int*/ static COR_E_DIRECTORYNOTFOUND = -2147024893;
            /*int*/ static COR_E_DIVIDEBYZERO = -2147352558;
            /*int*/ static COR_E_DLLNOTFOUND = -2146233052;
            /*int*/ static COR_E_DUPLICATEWAITOBJECT = -2146233047;
            /*int*/ static COR_E_ENDOFSTREAM = -2147024858;
            /*int*/ static COR_E_ENTRYPOINTNOTFOUND = -2146233053;
            /*int*/ static COR_E_EXCEPTION = -2146233088;
            /*int*/ static COR_E_EXECUTIONENGINE = -2146233082;
            /*int*/ static COR_E_FAILFAST = -2146232797;
            /*int*/ static COR_E_FIELDACCESS = -2146233081;
            /*int*/ static COR_E_FILELOAD = -2146232799;
            /*int*/ static COR_E_FILENOTFOUND = -2147024894;
            /*int*/ static COR_E_FORMAT = -2146233033;
            /*int*/ static COR_E_INDEXOUTOFRANGE = -2146233080;
            /*int*/ static COR_E_INSUFFICIENTEXECUTIONSTACK = -2146232968;
            /*int*/ static COR_E_INSUFFICIENTMEMORY = -2146233027;
            /*int*/ static COR_E_INVALIDCAST = -2147467262;
            /*int*/ static COR_E_INVALIDCOMOBJECT = -2146233049;
            /*int*/ static COR_E_INVALIDFILTERCRITERIA = -2146232831;
            /*int*/ static COR_E_INVALIDOLEVARIANTTYPE = -2146233039;
            /*int*/ static COR_E_INVALIDOPERATION = -2146233079;
            /*int*/ static COR_E_INVALIDPROGRAM = -2146233030;
            /*int*/ static COR_E_IO = -2146232800;
            /*int*/ static COR_E_KEYNOTFOUND = -2146232969;
            /*int*/ static COR_E_MARSHALDIRECTIVE = -2146233035;
            /*int*/ static COR_E_MEMBERACCESS = -2146233062;
            /*int*/ static COR_E_METHODACCESS = -2146233072;
            /*int*/ static COR_E_MISSINGFIELD = -2146233071;
            /*int*/ static COR_E_MISSINGMANIFESTRESOURCE = -2146233038;
            /*int*/ static COR_E_MISSINGMEMBER = -2146233070;
            /*int*/ static COR_E_MISSINGMETHOD = -2146233069;
            /*int*/ static COR_E_MISSINGSATELLITEASSEMBLY = -2146233034;
            /*int*/ static COR_E_MULTICASTNOTSUPPORTED = -2146233068;
            /*int*/ static COR_E_NOTFINITENUMBER = -2146233048;
            /*int*/ static COR_E_NOTSUPPORTED = -2146233067;
            /*int*/ static COR_E_OBJECTDISPOSED = -2146232798;
            /*int*/ static COR_E_OPERATIONCANCELED = -2146233029;
            /*int*/ static COR_E_OUTOFMEMORY = -2147024882;
            /*int*/ static COR_E_OVERFLOW = -2146233066;
            /*int*/ static COR_E_PATHTOOLONG = -2147024690;
            /*int*/ static COR_E_PLATFORMNOTSUPPORTED = -2146233031;
            /*int*/ static COR_E_RANK = -2146233065;
            /*int*/ static COR_E_REFLECTIONTYPELOAD = -2146232830;
            /*int*/ static COR_E_RUNTIMEWRAPPED = -2146233026;
            /*int*/ static COR_E_SAFEARRAYRANKMISMATCH = -2146233032;
            /*int*/ static COR_E_SAFEARRAYTYPEMISMATCH = -2146233037;
            /*int*/ static COR_E_SECURITY = -2146233078;
            /*int*/ static COR_E_SERIALIZATION = -2146233076;
            /*int*/ static COR_E_STACKOVERFLOW = -2147023895;
            /*int*/ static COR_E_SYNCHRONIZATIONLOCK = -2146233064;
            /*int*/ static COR_E_SYSTEM = -2146233087;
            /*int*/ static COR_E_TARGET = -2146232829;
            /*int*/ static COR_E_TARGETINVOCATION = -2146232828;
            /*int*/ static COR_E_TARGETPARAMCOUNT = -2147352562;
            /*int*/ static COR_E_THREADABORTED = -2146233040;
            /*int*/ static COR_E_THREADINTERRUPTED = -2146233063;
            /*int*/ static COR_E_THREADSTART = -2146233051;
            /*int*/ static COR_E_THREADSTATE = -2146233056;
            /*int*/ static COR_E_TIMEOUT = -2146233083;
            /*int*/ static COR_E_TYPEACCESS = -2146233021;
            /*int*/ static COR_E_TYPEINITIALIZATION = -2146233036;
            /*int*/ static COR_E_TYPELOAD = -2146233054;
            /*int*/ static COR_E_TYPEUNLOADED = -2146234349;
            /*int*/ static COR_E_UNAUTHORIZEDACCESS = -2147024891;
            /*int*/ static COR_E_VERIFICATION = -2146233075;
            /*int*/ static COR_E_WAITHANDLECANNOTBEOPENED = -2146233044;
            /*int*/ static CO_E_NOTINITIALIZED = -2147221008;
            /*int*/ static DISP_E_PARAMNOTFOUND = -2147352572;
            /*int*/ static DISP_E_TYPEMISMATCH = -2147352571;
            /*int*/ static DISP_E_BADVARTYPE = -2147352568;
            /*int*/ static DISP_E_OVERFLOW = -2147352566;
            /*int*/ static DISP_E_DIVBYZERO = -2147352558;
            /*int*/ static E_BOUNDS = -2147483637;
            /*int*/ static E_CHANGED_STATE = -2147483636;
            /*int*/ static E_FILENOTFOUND = -2147024894;
            /*int*/ static E_FAIL = -2147467259;
            /*int*/ static E_HANDLE = -2147024890;
            /*int*/ static E_INVALIDARG = -2147024809;
            /*int*/ static E_NOTIMPL = -2147467263;
            /*int*/ static E_OUTOFMEMORY = -2147024882;
            /*int*/ static E_POINTER = -2147467261;
            /*int*/ static ERROR_MRM_MAP_NOT_FOUND = -2147009761;
            /*int*/ static ERROR_TIMEOUT = -2147023436;
            /*int*/ static RO_E_CLOSED = -2147483629;
            /*int*/ static RPC_E_CHANGED_MODE = -2147417850;
            /*int*/ static TYPE_E_TYPEMISMATCH = -2147316576;
            /*int*/ static STG_E_PATHNOTFOUND = -2147287037;
            /*int*/ static CTL_E_PATHNOTFOUND = -2146828212;
            /*int*/ static CTL_E_FILENOTFOUND = -2146828235;
            /*int*/ static FUSION_E_INVALID_NAME = -2146234297;
            /*int*/ static FUSION_E_REF_DEF_MISMATCH = -2146234304;
            /*int*/ static ERROR_TOO_MANY_OPEN_FILES = -2147024892;
            /*int*/ static ERROR_SHARING_VIOLATION = -2147024864;
            /*int*/ static ERROR_LOCK_VIOLATION = -2147024863;
            /*int*/ static ERROR_OPEN_FAILED = -2147024786;
            /*int*/ static ERROR_DISK_CORRUPT = -2147023503;
            /*int*/ static ERROR_UNRECOGNIZED_VOLUME = -2147023891;
            /*int*/ static ERROR_DLL_INIT_FAILED = -2147023782;
            /*int*/ static MSEE_E_ASSEMBLYLOADINPROGRESS = -2146234346;
            /*int*/ static ERROR_FILE_INVALID = -2147023890;
            static $h = 126488;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"S_OK","d":126488,"h":4295093784,"f":40},{"t":655361,"n":"S_FALSE","d":126488,"h":8590061080,"f":40},{"t":655361,"n":"COR_E_ABANDONEDMUTEX","d":126488,"h":12885028376,"f":40},{"t":655361,"n":"COR_E_AMBIGUOUSIMPLEMENTATION","d":126488,"h":17179995672,"f":40},{"t":655361,"n":"COR_E_AMBIGUOUSMATCH","d":126488,"h":21474962968,"f":40},{"t":655361,"n":"COR_E_APPDOMAINUNLOADED","d":126488,"h":25769930264,"f":40},{"t":655361,"n":"COR_E_APPLICATION","d":126488,"h":30064897560,"f":40},{"t":655361,"n":"COR_E_ARGUMENT","d":126488,"h":34359864856,"f":40},{"t":655361,"n":"COR_E_ARGUMENTOUTOFRANGE","d":126488,"h":38654832152,"f":40},{"t":655361,"n":"COR_E_ARITHMETIC","d":126488,"h":42949799448,"f":40},{"t":655361,"n":"COR_E_ARRAYTYPEMISMATCH","d":126488,"h":47244766744,"f":40},{"t":655361,"n":"COR_E_BADEXEFORMAT","d":126488,"h":51539734040,"f":40},{"t":655361,"n":"COR_E_BADIMAGEFORMAT","d":126488,"h":55834701336,"f":40},{"t":655361,"n":"COR_E_CANNOTUNLOADAPPDOMAIN","d":126488,"h":60129668632,"f":40},{"t":655361,"n":"COR_E_CODECONTRACTFAILED","d":126488,"h":64424635928,"f":40},{"t":655361,"n":"COR_E_CONTEXTMARSHAL","d":126488,"h":68719603224,"f":40},{"t":655361,"n":"COR_E_CUSTOMATTRIBUTEFORMAT","d":126488,"h":73014570520,"f":40},{"t":655361,"n":"COR_E_DATAMISALIGNED","d":126488,"h":77309537816,"f":40},{"t":655361,"n":"COR_E_DIRECTORYNOTFOUND","d":126488,"h":81604505112,"f":40},{"t":655361,"n":"COR_E_DIVIDEBYZERO","d":126488,"h":85899472408,"f":40},{"t":655361,"n":"COR_E_DLLNOTFOUND","d":126488,"h":90194439704,"f":40},{"t":655361,"n":"COR_E_DUPLICATEWAITOBJECT","d":126488,"h":94489407000,"f":40},{"t":655361,"n":"COR_E_ENDOFSTREAM","d":126488,"h":98784374296,"f":40},{"t":655361,"n":"COR_E_ENTRYPOINTNOTFOUND","d":126488,"h":103079341592,"f":40},{"t":655361,"n":"COR_E_EXCEPTION","d":126488,"h":107374308888,"f":40},{"t":655361,"n":"COR_E_EXECUTIONENGINE","d":126488,"h":111669276184,"f":40},{"t":655361,"n":"COR_E_FAILFAST","d":126488,"h":115964243480,"f":40},{"t":655361,"n":"COR_E_FIELDACCESS","d":126488,"h":120259210776,"f":40},{"t":655361,"n":"COR_E_FILELOAD","d":126488,"h":124554178072,"f":40},{"t":655361,"n":"COR_E_FILENOTFOUND","d":126488,"h":128849145368,"f":40},{"t":655361,"n":"COR_E_FORMAT","d":126488,"h":133144112664,"f":40},{"t":655361,"n":"COR_E_INDEXOUTOFRANGE","d":126488,"h":137439079960,"f":40},{"t":655361,"n":"COR_E_INSUFFICIENTEXECUTIONSTACK","d":126488,"h":141734047256,"f":40},{"t":655361,"n":"COR_E_INSUFFICIENTMEMORY","d":126488,"h":146029014552,"f":40},{"t":655361,"n":"COR_E_INVALIDCAST","d":126488,"h":150323981848,"f":40},{"t":655361,"n":"COR_E_INVALIDCOMOBJECT","d":126488,"h":154618949144,"f":40},{"t":655361,"n":"COR_E_INVALIDFILTERCRITERIA","d":126488,"h":158913916440,"f":40},{"t":655361,"n":"COR_E_INVALIDOLEVARIANTTYPE","d":126488,"h":163208883736,"f":40},{"t":655361,"n":"COR_E_INVALIDOPERATION","d":126488,"h":167503851032,"f":40},{"t":655361,"n":"COR_E_INVALIDPROGRAM","d":126488,"h":171798818328,"f":40},{"t":655361,"n":"COR_E_IO","d":126488,"h":176093785624,"f":40},{"t":655361,"n":"COR_E_KEYNOTFOUND","d":126488,"h":180388752920,"f":40},{"t":655361,"n":"COR_E_MARSHALDIRECTIVE","d":126488,"h":184683720216,"f":40},{"t":655361,"n":"COR_E_MEMBERACCESS","d":126488,"h":188978687512,"f":40},{"t":655361,"n":"COR_E_METHODACCESS","d":126488,"h":193273654808,"f":40},{"t":655361,"n":"COR_E_MISSINGFIELD","d":126488,"h":197568622104,"f":40},{"t":655361,"n":"COR_E_MISSINGMANIFESTRESOURCE","d":126488,"h":201863589400,"f":40},{"t":655361,"n":"COR_E_MISSINGMEMBER","d":126488,"h":206158556696,"f":40},{"t":655361,"n":"COR_E_MISSINGMETHOD","d":126488,"h":210453523992,"f":40},{"t":655361,"n":"COR_E_MISSINGSATELLITEASSEMBLY","d":126488,"h":214748491288,"f":40},{"t":655361,"n":"COR_E_MULTICASTNOTSUPPORTED","d":126488,"h":219043458584,"f":40},{"t":655361,"n":"COR_E_NOTFINITENUMBER","d":126488,"h":223338425880,"f":40},{"t":655361,"n":"COR_E_NOTSUPPORTED","d":126488,"h":227633393176,"f":40},{"t":655361,"n":"COR_E_OBJECTDISPOSED","d":126488,"h":231928360472,"f":40},{"t":655361,"n":"COR_E_OPERATIONCANCELED","d":126488,"h":236223327768,"f":40},{"t":655361,"n":"COR_E_OUTOFMEMORY","d":126488,"h":240518295064,"f":40},{"t":655361,"n":"COR_E_OVERFLOW","d":126488,"h":244813262360,"f":40},{"t":655361,"n":"COR_E_PATHTOOLONG","d":126488,"h":249108229656,"f":40},{"t":655361,"n":"COR_E_PLATFORMNOTSUPPORTED","d":126488,"h":253403196952,"f":40},{"t":655361,"n":"COR_E_RANK","d":126488,"h":257698164248,"f":40},{"t":655361,"n":"COR_E_REFLECTIONTYPELOAD","d":126488,"h":261993131544,"f":40},{"t":655361,"n":"COR_E_RUNTIMEWRAPPED","d":126488,"h":266288098840,"f":40},{"t":655361,"n":"COR_E_SAFEARRAYRANKMISMATCH","d":126488,"h":270583066136,"f":40},{"t":655361,"n":"COR_E_SAFEARRAYTYPEMISMATCH","d":126488,"h":274878033432,"f":40},{"t":655361,"n":"COR_E_SECURITY","d":126488,"h":279173000728,"f":40},{"t":655361,"n":"COR_E_SERIALIZATION","d":126488,"h":283467968024,"f":40},{"t":655361,"n":"COR_E_STACKOVERFLOW","d":126488,"h":287762935320,"f":40},{"t":655361,"n":"COR_E_SYNCHRONIZATIONLOCK","d":126488,"h":292057902616,"f":40},{"t":655361,"n":"COR_E_SYSTEM","d":126488,"h":296352869912,"f":40},{"t":655361,"n":"COR_E_TARGET","d":126488,"h":300647837208,"f":40},{"t":655361,"n":"COR_E_TARGETINVOCATION","d":126488,"h":304942804504,"f":40},{"t":655361,"n":"COR_E_TARGETPARAMCOUNT","d":126488,"h":309237771800,"f":40},{"t":655361,"n":"COR_E_THREADABORTED","d":126488,"h":313532739096,"f":40},{"t":655361,"n":"COR_E_THREADINTERRUPTED","d":126488,"h":317827706392,"f":40},{"t":655361,"n":"COR_E_THREADSTART","d":126488,"h":322122673688,"f":40},{"t":655361,"n":"COR_E_THREADSTATE","d":126488,"h":326417640984,"f":40},{"t":655361,"n":"COR_E_TIMEOUT","d":126488,"h":330712608280,"f":40},{"t":655361,"n":"COR_E_TYPEACCESS","d":126488,"h":335007575576,"f":40},{"t":655361,"n":"COR_E_TYPEINITIALIZATION","d":126488,"h":339302542872,"f":40},{"t":655361,"n":"COR_E_TYPELOAD","d":126488,"h":343597510168,"f":40},{"t":655361,"n":"COR_E_TYPEUNLOADED","d":126488,"h":347892477464,"f":40},{"t":655361,"n":"COR_E_UNAUTHORIZEDACCESS","d":126488,"h":352187444760,"f":40},{"t":655361,"n":"COR_E_VERIFICATION","d":126488,"h":356482412056,"f":40},{"t":655361,"n":"COR_E_WAITHANDLECANNOTBEOPENED","d":126488,"h":360777379352,"f":40},{"t":655361,"n":"CO_E_NOTINITIALIZED","d":126488,"h":365072346648,"f":40},{"t":655361,"n":"DISP_E_PARAMNOTFOUND","d":126488,"h":369367313944,"f":40},{"t":655361,"n":"DISP_E_TYPEMISMATCH","d":126488,"h":373662281240,"f":40},{"t":655361,"n":"DISP_E_BADVARTYPE","d":126488,"h":377957248536,"f":40},{"t":655361,"n":"DISP_E_OVERFLOW","d":126488,"h":382252215832,"f":40},{"t":655361,"n":"DISP_E_DIVBYZERO","d":126488,"h":386547183128,"f":40},{"t":655361,"n":"E_BOUNDS","d":126488,"h":390842150424,"f":40},{"t":655361,"n":"E_CHANGED_STATE","d":126488,"h":395137117720,"f":40},{"t":655361,"n":"E_FILENOTFOUND","d":126488,"h":399432085016,"f":40},{"t":655361,"n":"E_FAIL","d":126488,"h":403727052312,"f":40},{"t":655361,"n":"E_HANDLE","d":126488,"h":408022019608,"f":40},{"t":655361,"n":"E_INVALIDARG","d":126488,"h":412316986904,"f":40},{"t":655361,"n":"E_NOTIMPL","d":126488,"h":416611954200,"f":40},{"t":655361,"n":"E_OUTOFMEMORY","d":126488,"h":420906921496,"f":40},{"t":655361,"n":"E_POINTER","d":126488,"h":425201888792,"f":40},{"t":655361,"n":"ERROR_MRM_MAP_NOT_FOUND","d":126488,"h":429496856088,"f":40},{"t":655361,"n":"ERROR_TIMEOUT","d":126488,"h":433791823384,"f":40},{"t":655361,"n":"RO_E_CLOSED","d":126488,"h":438086790680,"f":40},{"t":655361,"n":"RPC_E_CHANGED_MODE","d":126488,"h":442381757976,"f":40},{"t":655361,"n":"TYPE_E_TYPEMISMATCH","d":126488,"h":446676725272,"f":40},{"t":655361,"n":"STG_E_PATHNOTFOUND","d":126488,"h":450971692568,"f":40},{"t":655361,"n":"CTL_E_PATHNOTFOUND","d":126488,"h":455266659864,"f":40},{"t":655361,"n":"CTL_E_FILENOTFOUND","d":126488,"h":459561627160,"f":40},{"t":655361,"n":"FUSION_E_INVALID_NAME","d":126488,"h":463856594456,"f":40},{"t":655361,"n":"FUSION_E_REF_DEF_MISMATCH","d":126488,"h":468151561752,"f":40},{"t":655361,"n":"ERROR_TOO_MANY_OPEN_FILES","d":126488,"h":472446529048,"f":40},{"t":655361,"n":"ERROR_SHARING_VIOLATION","d":126488,"h":476741496344,"f":40},{"t":655361,"n":"ERROR_LOCK_VIOLATION","d":126488,"h":481036463640,"f":40},{"t":655361,"n":"ERROR_OPEN_FAILED","d":126488,"h":485331430936,"f":40},{"t":655361,"n":"ERROR_DISK_CORRUPT","d":126488,"h":489626398232,"f":40},{"t":655361,"n":"ERROR_UNRECOGNIZED_VOLUME","d":126488,"h":493921365528,"f":40},{"t":655361,"n":"ERROR_DLL_INIT_FAILED","d":126488,"h":498216332824,"f":40},{"t":655361,"n":"MSEE_E_ASSEMBLYLOADINPROGRESS","d":126488,"h":502511300120,"f":40},{"t":655361,"n":"ERROR_FILE_INVALID","d":126488,"h":506806267416,"f":40}],"h":126488}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.HResults`; }
        });
        
        $asm.$cls("$sifd.System.IO.PathInternal", ($self) => class PathInternal
        {
            static /*StringComparison */ get StringComparison()
            {
                return $.$sifd.System.IO.PathInternal.IsCaseSensitive ? 4/*StringComparison.Ordinal*/ : 5/*StringComparison.OrdinalIgnoreCase*/;
            }
            static /*bool */ get IsCaseSensitive()
            {
                return !($.$spc.System.OperatingSystem.IsWindows() || $.$spc.System.OperatingSystem.IsMacOS() || $.$spc.System.OperatingSystem.IsIOS() || $.$spc.System.OperatingSystem.IsTvOS());
            }
            static $h = 388632;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":119472129,"g":{"r":0,"d":0,"h":8590323224,"f":40},"n":"StringComparison","d":388632,"h":4295355928,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":17180257816,"f":40},"n":"IsCaseSensitive","d":388632,"h":12885290520,"f":40}],"h":388632}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.PathInternal`; }
        });
        
        $asm.$cls("$sifd.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 454168;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":454168,"h":4295421464,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":454168,"h":8590388760,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":454168,"h":12885356056,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":454168,"h":17180323352,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":454168,"h":21475290648,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":454168,"h":25770257944,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":454168,"h":30065225240,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":454168,"h":34360192536,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":454168,"h":38655159832,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":454168,"h":42950127128,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":454168,"h":47245094424,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":454168,"h":51540061720,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":454168,"h":55835029016,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":454168,"h":60129996312,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":454168,"h":64424963608,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":454168,"h":68719930904,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":454168,"h":73014898200,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":454168,"h":77309865496,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":454168,"h":81604832792,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":454168,"h":85899800088,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":454168,"h":90194767384,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":454168,"h":94489734680,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":454168,"h":98784701976,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":454168,"h":103079669272,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":454168,"h":107374636568,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":454168,"h":111669603864,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":454168,"h":115964571160,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":454168,"h":120259538456,"f":40},{"t":1310721,"n":"WebRequestMessage","d":454168,"h":124554505752,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":454168,"h":128849473048,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":454168,"h":133144440344,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":454168,"h":137439407640,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":454168,"h":141734374936,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":454168,"h":146029342232,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":454168,"h":150324309528,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":454168,"h":154619276824,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":454168,"h":158914244120,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":454168,"h":163209211416,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":454168,"h":167504178712,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":454168,"h":171799146008,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":454168,"h":176094113304,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":454168,"h":180389080600,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":454168,"h":184684047896,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":454168,"h":188979015192,"f":40},{"t":1310721,"n":"RijndaelMessage","d":454168,"h":193273982488,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":454168,"h":197568949784,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":454168,"h":201863917080,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":454168,"h":206158884376,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":454168,"h":210453851672,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":454168,"h":214748818968,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":454168,"h":219043786264,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":454168,"h":223338753560,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":454168,"h":227633720856,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":454168,"h":231928688152,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":454168,"h":236223655448,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":454168,"h":240518622744,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":454168,"h":244813590040,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":454168,"h":249108557336,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":454168,"h":253403524632,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":454168,"h":257698491928,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":454168,"h":261993459224,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":454168,"h":266288426520,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":454168,"h":270583393816,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":454168,"h":274878361112,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":454168,"h":279173328408,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":454168,"h":283468295704,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":454168,"h":287763263000,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":454168,"h":292058230296,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":454168,"h":296353197592,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":454168,"h":300648164888,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":454168,"h":304943132184,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":454168,"h":309238099480,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":454168,"h":313533066776,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":454168,"h":317828034072,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":454168,"h":322123001368,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":454168,"h":326417968664,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":454168,"h":330712935960,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":454168,"h":335007903256,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":454168,"h":339302870552,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":454168,"h":343597837848,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":454168,"h":347892805144,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":454168,"h":352187772440,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":454168,"h":356482739736,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":454168,"h":360777707032,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":454168,"h":365072674328,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":454168,"h":369367641624,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":454168,"h":373662608920,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":454168,"h":377957576216,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":454168,"h":382252543512,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":454168,"h":386547510808,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":454168,"h":390842478104,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":454168,"h":395137445400,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":454168,"h":399432412696,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":454168,"h":403727379992,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":454168,"h":408022347288,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":454168,"h":412317314584,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":454168,"h":416612281880,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":454168,"h":420907249176,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":454168,"h":425202216472,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":454168,"h":429497183768,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":454168,"h":433792151064,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":454168,"h":438087118360,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":454168,"h":442382085656,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":454168,"h":446677052952,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":454168,"h":450972020248,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":454168,"h":455266987544,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":454168,"h":459561954840,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":454168,"h":463856922136,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":454168,"h":468151889432,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":454168,"h":472446856728,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":454168,"h":476741824024,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":454168,"h":481036791320,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":454168,"h":485331758616,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":454168,"h":489626725912,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":454168,"h":493921693208,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":454168,"h":498216660504,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":454168,"h":502511627800,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":454168,"h":506806595096,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":454168,"h":511101562392,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":454168,"h":515396529688,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":454168,"h":519691496984,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":454168,"h":523986464280,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":454168,"h":528281431576,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":454168,"h":532576398872,"f":40}],"h":454168}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$sifd.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sifd.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.IO.FileSystem.DriveInfo", $.$sifd.System.SR.$type.Assembly);
                    $.$sifd.System.SR.s_resourceManager = temp;
                }
                return $.$sifd.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sifd.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sifd.System.SR.resourceCulture = value;
            }
            static /*string */ get Arg_MustBeDriveLetterOrRootDir()
            {
                return "Drive name must be a root directory (i.e. 'C:\\') or a drive letter ('C').";
            }
            static /*string */ get Arg_MustBeNonEmptyDriveName()
            {
                return "Drive name must not be empty.";
            }
            static /*string */ get Arg_InvalidDriveChars()
            {
                return "Illegal characters in drive name '{0}'.";
            }
            static /*string */ FormatArg_InvalidDriveChars(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Illegal characters in drive name '{0}'.", arg1);
            }
            static /*string */ get Argument_InvalidPathChars()
            {
                return "Illegal characters in path '{0}'.";
            }
            static /*string */ FormatArgument_InvalidPathChars(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Illegal characters in path '{0}'.", arg1);
            }
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                return "Specified file length was too large for the file system.";
            }
            static /*string */ get InvalidOperation_SetVolumeLabelFailed()
            {
                return "Volume labels can only be set for writable local volumes.";
            }
            static /*string */ get IO_AlreadyExists_Name()
            {
                return "Cannot create '{0}' because a file or directory with the same name already exists.";
            }
            static /*string */ FormatIO_AlreadyExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Cannot create '{0}' because a file or directory with the same name already exists.", arg1);
            }
            static /*string */ get IO_DriveNotFound()
            {
                return "Could not find the drive. The drive might not be ready or might not be mapped.";
            }
            static /*string */ get IO_DriveNotFound_Drive()
            {
                return "Could not find the drive '{0}'. The drive might not be ready or might not be mapped.";
            }
            static /*string */ FormatIO_DriveNotFound_Drive(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find the drive '{0}'. The drive might not be ready or might not be mapped.", arg1);
            }
            static /*string */ get IO_FileExists_Name()
            {
                return "The file '{0}' already exists.";
            }
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The file '{0}' already exists.", arg1);
            }
            static /*string */ get IO_FileNotFound()
            {
                return "Unable to find the specified file.";
            }
            static /*string */ get IO_FileNotFound_FileName()
            {
                return "Could not find file '{0}'.";
            }
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find file '{0}'.", arg1);
            }
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                return "Could not find a part of the path.";
            }
            static /*string */ get IO_PathNotFound_Path()
            {
                return "Could not find a part of the path '{0}'.";
            }
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find a part of the path '{0}'.", arg1);
            }
            static /*string */ get IO_PathTooLong()
            {
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            static /*string */ get IO_SharingViolation_File()
            {
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                return "The process cannot access the file because it is being used by another process.";
            }
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                return "Access to the path is denied.";
            }
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                return "Access to the path '{0}' is denied.";
            }
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Access to the path '{0}' is denied.", arg1);
            }
            static /*string */ get IO_PathTooLong_Path()
            {
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sifd.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sifd.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sifd.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sifd.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sifd.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sifd.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 519704;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":519704}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sifd.System.IO.DriveInfo", ($self) => class DriveInfo extends $.$spc.System.Object
        {
            /*string*/ _name = null;
            $ctor$1(/*string*/ driveName)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(driveName, "driveName");
                    this._name = $.$sifd.System.IO.DriveInfo.NormalizeDriveName(driveName);
                }
                return this;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                return this._name;
            }
            /*bool */ get IsReady()
            {
                return $.$spc.System.IO.Directory.Exists(this.Name);
            }
            /*DirectoryInfo */ get RootDirectory()
            {
                return new $.$spc.System.IO.DirectoryInfo().$ctor$4(this.Name);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.Name;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sifd.System.IO.DriveInfo.ToString.apply(this, arguments); }
            static /*DriveInfo[] */ GetDrives()
            {
                /*string[]*/ let mountPoints = $.$sifd.System.IO.DriveInfo.GetMountPoints();
                /*DriveInfo[]*/ let info = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sifd.System.IO.DriveInfo), null, [mountPoints.length], null);
                for(/*int*/ let i = 0; i < info.length; i++)
                {
                    $.$spc.System.Array.$WriteT1.call(info, new $.$sifd.System.IO.DriveInfo().$ctor$1($.$spc.System.Array.$ReadT1.call(mountPoints, i)), i);
                }
                return info;
            }
            static /*string */ NormalizeDriveName(/*string*/ driveName)
            {
                if ($.$spc.System.String.Contains$2.call(driveName, /*\u0000*/ 0))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sifd.System.SR.Format($.$sifd.System.SR.Arg_InvalidDriveChars, driveName), "driveName");
                }
                if (driveName.length === 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sifd.System.SR.Arg_MustBeNonEmptyDriveName, "driveName");
                }
                return driveName;
            }
            /*string */ get VolumeLabel()
            {
                return this.Name;
            }
            /*string */ set VolumeLabel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*DriveType */ get DriveType()
            {
                return 0/*DriveType.Unknown*/;
            }
            /*string */ get DriveFormat()
            {
                return "memfs";
            }
            /*long */ get AvailableFreeSpace()
            {
                return 0n;
            }
            /*long */ get TotalFreeSpace()
            {
                return 0n;
            }
            /*long */ get TotalSize()
            {
                return 0n;
            }
            static /*string[] */ GetMountPoints()
            {
                return $.$spc.System.Environment.GetLogicalDrives();
            }
            static $h = 192024;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475028504,"f":1},"n":"Name","d":192024,"h":17180061208,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30064963096,"f":1},"n":"IsReady","d":192024,"h":25769995800,"f":1},{"p":58654721,"g":{"r":0,"d":0,"h":38654897688,"f":1},"n":"RootDirectory","d":192024,"h":34359930392,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60129734168,"f":1},"s":{"r":0,"d":0,"h":64424701464,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"VolumeLabel","d":192024,"h":55834766872,"f":1},{"p":323096,"g":{"r":0,"d":0,"h":73014636056,"f":1},"n":"DriveType","d":192024,"h":68719668760,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604570648,"f":1},"n":"DriveFormat","d":192024,"h":77309603352,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":90194505240,"f":1},"n":"AvailableFreeSpace","d":192024,"h":85899537944,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":98784439832,"f":1},"n":"TotalFreeSpace","d":192024,"h":94489472536,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":107374374424,"f":1},"n":"TotalSize","d":192024,"h":103079407128,"f":1}],"m":[{"r":1310721,"n":"ToString","d":192024,"h":42949864984,"f":32769},{"r":0,"n":"GetDrives","d":192024,"h":47244832280,"f":33},{"r":1310721,"p":[{"n":"driveName","p":1310721}],"n":"NormalizeDriveName","d":192024,"h":51539799576,"f":34},{"r":0,"n":"GetMountPoints","d":192024,"h":111669341720,"f":34}],"l":[{"t":1310721,"n":"_name","d":192024,"h":4295159320,"f":2}],"c":[{"p":[{"n":"driveName","p":1310721}],"n":".ctor","o":"$ctor$1","d":192024,"h":8590126616,"f":1}],"i":[113377281],"h":192024}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.DriveInfo`; }
        });
        
        $asm.$str("$sifd.System.IO.DriveType", ($self) => class DriveType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static NoRootDirectory = 1;
            static Removable = 2;
            static Fixed = 3;
            static Network = 4;
            static CDRom = 5;
            static Ram = 6;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "NoRootDirectory": 1n,
                    "Removable": 2n,
                    "Fixed": 3n,
                    "Network": 4n,
                    "CDRom": 5n,
                    "Ram": 6n
                };
            }
            static $h = 323096;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":323096,"n":"Unknown","d":323096,"h":4295290392,"f":33},{"t":323096,"n":"NoRootDirectory","d":323096,"h":8590257688,"f":33},{"t":323096,"n":"Removable","d":323096,"h":12885224984,"f":33},{"t":323096,"n":"Fixed","d":323096,"h":17180192280,"f":33},{"t":323096,"n":"Network","d":323096,"h":21475159576,"f":33},{"t":323096,"n":"CDRom","d":323096,"h":25770126872,"f":33},{"t":323096,"n":"Ram","d":323096,"h":30065094168,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":323096,"h":34360061464,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":323096}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.DriveType`; }
        });
        
        $asm.$cls("$sifd.System.IO.DriveNotFoundException", ($self) => class DriveNotFoundException extends $.$spc.System.IO.IOException
        {
            $ctor$14()
            {
                super.$ctor$10($.$sifd.System.SR.IO_DriveNotFound);
                {
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            $ctor$15(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$sifd.System.SR.IO_DriveNotFound);
                {
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            $ctor$16(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$12(message ?? $.$sifd.System.SR.IO_DriveNotFound, innerException);
                {
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            $ctor$17(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$13(info, context);
                {
                }
                return this;
            }
            static $h = 257560;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":60686337,"h":257560}; }
            static get $b() { return $.$spc.System.IO.IOException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.DriveNotFoundException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices"))