
(function ($global, $, $spc, $sc, $sdt, $sm, $spu, $st, $sr, $scc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.FileSystem.DriveInfo", 
    {"h":56367,"f":"System.IO.FileSystem.DriveInfo","v":"1.0.35.0","a":[{"t":90374145,"c":4385341441},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.FileSystem.DriveInfo","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.FileSystem.DriveInfo","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sifd.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sifd.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.IO.FileSystem.DriveInfo", $.$sifd.System.SR.$type.Assembly);
                    $.$sifd.System.SR.s_resourceManager = temp;
                }
                return $.$sifd.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sifd.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sifd.System.SR.resourceCulture = value;
            }
            static /*string */ get Arg_MustBeDriveLetterOrRootDir()
            {
                return "Drive name must be a root directory (i.e. 'C:\\') or a drive letter ('C').";
            }
            static /*string */ get Arg_MustBeNonEmptyDriveName()
            {
                return "Drive name must not be empty.";
            }
            static /*string */ get Arg_InvalidDriveChars()
            {
                return "Illegal characters in drive name '{0}'.";
            }
            static /*string */ FormatArg_InvalidDriveChars(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Illegal characters in drive name '{0}'.", arg1);
            }
            static /*string */ get Argument_InvalidPathChars()
            {
                return "Illegal characters in path '{0}'.";
            }
            static /*string */ FormatArgument_InvalidPathChars(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Illegal characters in path '{0}'.", arg1);
            }
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                return "Specified file length was too large for the file system.";
            }
            static /*string */ get InvalidOperation_SetVolumeLabelFailed()
            {
                return "Volume labels can only be set for writable local volumes.";
            }
            static /*string */ get IO_AlreadyExists_Name()
            {
                return "Cannot create '{0}' because a file or directory with the same name already exists.";
            }
            static /*string */ FormatIO_AlreadyExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Cannot create '{0}' because a file or directory with the same name already exists.", arg1);
            }
            static /*string */ get IO_DriveNotFound()
            {
                return "Could not find the drive. The drive might not be ready or might not be mapped.";
            }
            static /*string */ get IO_DriveNotFound_Drive()
            {
                return "Could not find the drive '{0}'. The drive might not be ready or might not be mapped.";
            }
            static /*string */ FormatIO_DriveNotFound_Drive(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find the drive '{0}'. The drive might not be ready or might not be mapped.", arg1);
            }
            static /*string */ get IO_FileExists_Name()
            {
                return "The file '{0}' already exists.";
            }
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The file '{0}' already exists.", arg1);
            }
            static /*string */ get IO_FileNotFound()
            {
                return "Unable to find the specified file.";
            }
            static /*string */ get IO_FileNotFound_FileName()
            {
                return "Could not find file '{0}'.";
            }
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find file '{0}'.", arg1);
            }
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                return "Could not find a part of the path.";
            }
            static /*string */ get IO_PathNotFound_Path()
            {
                return "Could not find a part of the path '{0}'.";
            }
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find a part of the path '{0}'.", arg1);
            }
            static /*string */ get IO_PathTooLong()
            {
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            static /*string */ get IO_SharingViolation_File()
            {
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                return "The process cannot access the file because it is being used by another process.";
            }
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                return "Access to the path is denied.";
            }
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                return "Access to the path '{0}' is denied.";
            }
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Access to the path '{0}' is denied.", arg1);
            }
            static /*string */ get IO_PathTooLong_Path()
            {
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sifd.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sifd.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sifd.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sifd.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sifd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sifd.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sifd.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 515119;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":515119}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sifd.System.HResults", ($self) => class HResults
        {
            /*int*/ static S_OK = 0;
            /*int*/ static S_FALSE = 1;
            /*int*/ static COR_E_ABANDONEDMUTEX = -2146233043;
            /*int*/ static COR_E_AMBIGUOUSIMPLEMENTATION = -2146234262;
            /*int*/ static COR_E_AMBIGUOUSMATCH = -2147475171;
            /*int*/ static COR_E_APPDOMAINUNLOADED = -2146234348;
            /*int*/ static COR_E_APPLICATION = -2146232832;
            /*int*/ static COR_E_ARGUMENT = -2147024809;
            /*int*/ static COR_E_ARGUMENTOUTOFRANGE = -2146233086;
            /*int*/ static COR_E_ARITHMETIC = -2147024362;
            /*int*/ static COR_E_ARRAYTYPEMISMATCH = -2146233085;
            /*int*/ static COR_E_BADEXEFORMAT = -2147024703;
            /*int*/ static COR_E_BADIMAGEFORMAT = -2147024885;
            /*int*/ static COR_E_CANNOTUNLOADAPPDOMAIN = -2146234347;
            /*int*/ static COR_E_CODECONTRACTFAILED = -2146233022;
            /*int*/ static COR_E_CONTEXTMARSHAL = -2146233084;
            /*int*/ static COR_E_CUSTOMATTRIBUTEFORMAT = -2146232827;
            /*int*/ static COR_E_DATAMISALIGNED = -2146233023;
            /*int*/ static COR_E_DIRECTORYNOTFOUND = -2147024893;
            /*int*/ static COR_E_DIVIDEBYZERO = -2147352558;
            /*int*/ static COR_E_DLLNOTFOUND = -2146233052;
            /*int*/ static COR_E_DUPLICATEWAITOBJECT = -2146233047;
            /*int*/ static COR_E_ENDOFSTREAM = -2147024858;
            /*int*/ static COR_E_ENTRYPOINTNOTFOUND = -2146233053;
            /*int*/ static COR_E_EXCEPTION = -2146233088;
            /*int*/ static COR_E_EXECUTIONENGINE = -2146233082;
            /*int*/ static COR_E_FAILFAST = -2146232797;
            /*int*/ static COR_E_FIELDACCESS = -2146233081;
            /*int*/ static COR_E_FILELOAD = -2146232799;
            /*int*/ static COR_E_FILENOTFOUND = -2147024894;
            /*int*/ static COR_E_FORMAT = -2146233033;
            /*int*/ static COR_E_INDEXOUTOFRANGE = -2146233080;
            /*int*/ static COR_E_INSUFFICIENTEXECUTIONSTACK = -2146232968;
            /*int*/ static COR_E_INSUFFICIENTMEMORY = -2146233027;
            /*int*/ static COR_E_INVALIDCAST = -2147467262;
            /*int*/ static COR_E_INVALIDCOMOBJECT = -2146233049;
            /*int*/ static COR_E_INVALIDFILTERCRITERIA = -2146232831;
            /*int*/ static COR_E_INVALIDOLEVARIANTTYPE = -2146233039;
            /*int*/ static COR_E_INVALIDOPERATION = -2146233079;
            /*int*/ static COR_E_INVALIDPROGRAM = -2146233030;
            /*int*/ static COR_E_IO = -2146232800;
            /*int*/ static COR_E_KEYNOTFOUND = -2146232969;
            /*int*/ static COR_E_MARSHALDIRECTIVE = -2146233035;
            /*int*/ static COR_E_MEMBERACCESS = -2146233062;
            /*int*/ static COR_E_METHODACCESS = -2146233072;
            /*int*/ static COR_E_MISSINGFIELD = -2146233071;
            /*int*/ static COR_E_MISSINGMANIFESTRESOURCE = -2146233038;
            /*int*/ static COR_E_MISSINGMEMBER = -2146233070;
            /*int*/ static COR_E_MISSINGMETHOD = -2146233069;
            /*int*/ static COR_E_MISSINGSATELLITEASSEMBLY = -2146233034;
            /*int*/ static COR_E_MULTICASTNOTSUPPORTED = -2146233068;
            /*int*/ static COR_E_NOTFINITENUMBER = -2146233048;
            /*int*/ static COR_E_NOTSUPPORTED = -2146233067;
            /*int*/ static COR_E_OBJECTDISPOSED = -2146232798;
            /*int*/ static COR_E_OPERATIONCANCELED = -2146233029;
            /*int*/ static COR_E_OUTOFMEMORY = -2147024882;
            /*int*/ static COR_E_OVERFLOW = -2146233066;
            /*int*/ static COR_E_PATHTOOLONG = -2147024690;
            /*int*/ static COR_E_PLATFORMNOTSUPPORTED = -2146233031;
            /*int*/ static COR_E_RANK = -2146233065;
            /*int*/ static COR_E_REFLECTIONTYPELOAD = -2146232830;
            /*int*/ static COR_E_RUNTIMEWRAPPED = -2146233026;
            /*int*/ static COR_E_SAFEARRAYRANKMISMATCH = -2146233032;
            /*int*/ static COR_E_SAFEARRAYTYPEMISMATCH = -2146233037;
            /*int*/ static COR_E_SECURITY = -2146233078;
            /*int*/ static COR_E_SERIALIZATION = -2146233076;
            /*int*/ static COR_E_STACKOVERFLOW = -2147023895;
            /*int*/ static COR_E_SYNCHRONIZATIONLOCK = -2146233064;
            /*int*/ static COR_E_SYSTEM = -2146233087;
            /*int*/ static COR_E_TARGET = -2146232829;
            /*int*/ static COR_E_TARGETINVOCATION = -2146232828;
            /*int*/ static COR_E_TARGETPARAMCOUNT = -2147352562;
            /*int*/ static COR_E_THREADABORTED = -2146233040;
            /*int*/ static COR_E_THREADINTERRUPTED = -2146233063;
            /*int*/ static COR_E_THREADSTART = -2146233051;
            /*int*/ static COR_E_THREADSTATE = -2146233056;
            /*int*/ static COR_E_TIMEOUT = -2146233083;
            /*int*/ static COR_E_TYPEACCESS = -2146233021;
            /*int*/ static COR_E_TYPEINITIALIZATION = -2146233036;
            /*int*/ static COR_E_TYPELOAD = -2146233054;
            /*int*/ static COR_E_TYPEUNLOADED = -2146234349;
            /*int*/ static COR_E_UNAUTHORIZEDACCESS = -2147024891;
            /*int*/ static COR_E_VERIFICATION = -2146233075;
            /*int*/ static COR_E_WAITHANDLECANNOTBEOPENED = -2146233044;
            /*int*/ static CO_E_NOTINITIALIZED = -2147221008;
            /*int*/ static DISP_E_PARAMNOTFOUND = -2147352572;
            /*int*/ static DISP_E_TYPEMISMATCH = -2147352571;
            /*int*/ static DISP_E_BADVARTYPE = -2147352568;
            /*int*/ static DISP_E_OVERFLOW = -2147352566;
            /*int*/ static DISP_E_DIVBYZERO = -2147352558;
            /*int*/ static E_BOUNDS = -2147483637;
            /*int*/ static E_CHANGED_STATE = -2147483636;
            /*int*/ static E_FILENOTFOUND = -2147024894;
            /*int*/ static E_FAIL = -2147467259;
            /*int*/ static E_HANDLE = -2147024890;
            /*int*/ static E_INVALIDARG = -2147024809;
            /*int*/ static E_NOTIMPL = -2147467263;
            /*int*/ static E_OUTOFMEMORY = -2147024882;
            /*int*/ static E_POINTER = -2147467261;
            /*int*/ static ERROR_MRM_MAP_NOT_FOUND = -2147009761;
            /*int*/ static ERROR_TIMEOUT = -2147023436;
            /*int*/ static RO_E_CLOSED = -2147483629;
            /*int*/ static RPC_E_CHANGED_MODE = -2147417850;
            /*int*/ static TYPE_E_TYPEMISMATCH = -2147316576;
            /*int*/ static STG_E_PATHNOTFOUND = -2147287037;
            /*int*/ static CTL_E_PATHNOTFOUND = -2146828212;
            /*int*/ static CTL_E_FILENOTFOUND = -2146828235;
            /*int*/ static FUSION_E_INVALID_NAME = -2146234297;
            /*int*/ static FUSION_E_REF_DEF_MISMATCH = -2146234304;
            /*int*/ static ERROR_TOO_MANY_OPEN_FILES = -2147024892;
            /*int*/ static ERROR_SHARING_VIOLATION = -2147024864;
            /*int*/ static ERROR_LOCK_VIOLATION = -2147024863;
            /*int*/ static ERROR_OPEN_FAILED = -2147024786;
            /*int*/ static ERROR_DISK_CORRUPT = -2147023503;
            /*int*/ static ERROR_UNRECOGNIZED_VOLUME = -2147023891;
            /*int*/ static ERROR_DLL_INIT_FAILED = -2147023782;
            /*int*/ static MSEE_E_ASSEMBLYLOADINPROGRESS = -2146234346;
            /*int*/ static ERROR_FILE_INVALID = -2147023890;
            static $h = 121903;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"S_OK","d":121903,"h":4295089199,"f":40},{"t":655361,"n":"S_FALSE","d":121903,"h":8590056495,"f":40},{"t":655361,"n":"COR_E_ABANDONEDMUTEX","d":121903,"h":12885023791,"f":40},{"t":655361,"n":"COR_E_AMBIGUOUSIMPLEMENTATION","d":121903,"h":17179991087,"f":40},{"t":655361,"n":"COR_E_AMBIGUOUSMATCH","d":121903,"h":21474958383,"f":40},{"t":655361,"n":"COR_E_APPDOMAINUNLOADED","d":121903,"h":25769925679,"f":40},{"t":655361,"n":"COR_E_APPLICATION","d":121903,"h":30064892975,"f":40},{"t":655361,"n":"COR_E_ARGUMENT","d":121903,"h":34359860271,"f":40},{"t":655361,"n":"COR_E_ARGUMENTOUTOFRANGE","d":121903,"h":38654827567,"f":40},{"t":655361,"n":"COR_E_ARITHMETIC","d":121903,"h":42949794863,"f":40},{"t":655361,"n":"COR_E_ARRAYTYPEMISMATCH","d":121903,"h":47244762159,"f":40},{"t":655361,"n":"COR_E_BADEXEFORMAT","d":121903,"h":51539729455,"f":40},{"t":655361,"n":"COR_E_BADIMAGEFORMAT","d":121903,"h":55834696751,"f":40},{"t":655361,"n":"COR_E_CANNOTUNLOADAPPDOMAIN","d":121903,"h":60129664047,"f":40},{"t":655361,"n":"COR_E_CODECONTRACTFAILED","d":121903,"h":64424631343,"f":40},{"t":655361,"n":"COR_E_CONTEXTMARSHAL","d":121903,"h":68719598639,"f":40},{"t":655361,"n":"COR_E_CUSTOMATTRIBUTEFORMAT","d":121903,"h":73014565935,"f":40},{"t":655361,"n":"COR_E_DATAMISALIGNED","d":121903,"h":77309533231,"f":40},{"t":655361,"n":"COR_E_DIRECTORYNOTFOUND","d":121903,"h":81604500527,"f":40},{"t":655361,"n":"COR_E_DIVIDEBYZERO","d":121903,"h":85899467823,"f":40},{"t":655361,"n":"COR_E_DLLNOTFOUND","d":121903,"h":90194435119,"f":40},{"t":655361,"n":"COR_E_DUPLICATEWAITOBJECT","d":121903,"h":94489402415,"f":40},{"t":655361,"n":"COR_E_ENDOFSTREAM","d":121903,"h":98784369711,"f":40},{"t":655361,"n":"COR_E_ENTRYPOINTNOTFOUND","d":121903,"h":103079337007,"f":40},{"t":655361,"n":"COR_E_EXCEPTION","d":121903,"h":107374304303,"f":40},{"t":655361,"n":"COR_E_EXECUTIONENGINE","d":121903,"h":111669271599,"f":40},{"t":655361,"n":"COR_E_FAILFAST","d":121903,"h":115964238895,"f":40},{"t":655361,"n":"COR_E_FIELDACCESS","d":121903,"h":120259206191,"f":40},{"t":655361,"n":"COR_E_FILELOAD","d":121903,"h":124554173487,"f":40},{"t":655361,"n":"COR_E_FILENOTFOUND","d":121903,"h":128849140783,"f":40},{"t":655361,"n":"COR_E_FORMAT","d":121903,"h":133144108079,"f":40},{"t":655361,"n":"COR_E_INDEXOUTOFRANGE","d":121903,"h":137439075375,"f":40},{"t":655361,"n":"COR_E_INSUFFICIENTEXECUTIONSTACK","d":121903,"h":141734042671,"f":40},{"t":655361,"n":"COR_E_INSUFFICIENTMEMORY","d":121903,"h":146029009967,"f":40},{"t":655361,"n":"COR_E_INVALIDCAST","d":121903,"h":150323977263,"f":40},{"t":655361,"n":"COR_E_INVALIDCOMOBJECT","d":121903,"h":154618944559,"f":40},{"t":655361,"n":"COR_E_INVALIDFILTERCRITERIA","d":121903,"h":158913911855,"f":40},{"t":655361,"n":"COR_E_INVALIDOLEVARIANTTYPE","d":121903,"h":163208879151,"f":40},{"t":655361,"n":"COR_E_INVALIDOPERATION","d":121903,"h":167503846447,"f":40},{"t":655361,"n":"COR_E_INVALIDPROGRAM","d":121903,"h":171798813743,"f":40},{"t":655361,"n":"COR_E_IO","d":121903,"h":176093781039,"f":40},{"t":655361,"n":"COR_E_KEYNOTFOUND","d":121903,"h":180388748335,"f":40},{"t":655361,"n":"COR_E_MARSHALDIRECTIVE","d":121903,"h":184683715631,"f":40},{"t":655361,"n":"COR_E_MEMBERACCESS","d":121903,"h":188978682927,"f":40},{"t":655361,"n":"COR_E_METHODACCESS","d":121903,"h":193273650223,"f":40},{"t":655361,"n":"COR_E_MISSINGFIELD","d":121903,"h":197568617519,"f":40},{"t":655361,"n":"COR_E_MISSINGMANIFESTRESOURCE","d":121903,"h":201863584815,"f":40},{"t":655361,"n":"COR_E_MISSINGMEMBER","d":121903,"h":206158552111,"f":40},{"t":655361,"n":"COR_E_MISSINGMETHOD","d":121903,"h":210453519407,"f":40},{"t":655361,"n":"COR_E_MISSINGSATELLITEASSEMBLY","d":121903,"h":214748486703,"f":40},{"t":655361,"n":"COR_E_MULTICASTNOTSUPPORTED","d":121903,"h":219043453999,"f":40},{"t":655361,"n":"COR_E_NOTFINITENUMBER","d":121903,"h":223338421295,"f":40},{"t":655361,"n":"COR_E_NOTSUPPORTED","d":121903,"h":227633388591,"f":40},{"t":655361,"n":"COR_E_OBJECTDISPOSED","d":121903,"h":231928355887,"f":40},{"t":655361,"n":"COR_E_OPERATIONCANCELED","d":121903,"h":236223323183,"f":40},{"t":655361,"n":"COR_E_OUTOFMEMORY","d":121903,"h":240518290479,"f":40},{"t":655361,"n":"COR_E_OVERFLOW","d":121903,"h":244813257775,"f":40},{"t":655361,"n":"COR_E_PATHTOOLONG","d":121903,"h":249108225071,"f":40},{"t":655361,"n":"COR_E_PLATFORMNOTSUPPORTED","d":121903,"h":253403192367,"f":40},{"t":655361,"n":"COR_E_RANK","d":121903,"h":257698159663,"f":40},{"t":655361,"n":"COR_E_REFLECTIONTYPELOAD","d":121903,"h":261993126959,"f":40},{"t":655361,"n":"COR_E_RUNTIMEWRAPPED","d":121903,"h":266288094255,"f":40},{"t":655361,"n":"COR_E_SAFEARRAYRANKMISMATCH","d":121903,"h":270583061551,"f":40},{"t":655361,"n":"COR_E_SAFEARRAYTYPEMISMATCH","d":121903,"h":274878028847,"f":40},{"t":655361,"n":"COR_E_SECURITY","d":121903,"h":279172996143,"f":40},{"t":655361,"n":"COR_E_SERIALIZATION","d":121903,"h":283467963439,"f":40},{"t":655361,"n":"COR_E_STACKOVERFLOW","d":121903,"h":287762930735,"f":40},{"t":655361,"n":"COR_E_SYNCHRONIZATIONLOCK","d":121903,"h":292057898031,"f":40},{"t":655361,"n":"COR_E_SYSTEM","d":121903,"h":296352865327,"f":40},{"t":655361,"n":"COR_E_TARGET","d":121903,"h":300647832623,"f":40},{"t":655361,"n":"COR_E_TARGETINVOCATION","d":121903,"h":304942799919,"f":40},{"t":655361,"n":"COR_E_TARGETPARAMCOUNT","d":121903,"h":309237767215,"f":40},{"t":655361,"n":"COR_E_THREADABORTED","d":121903,"h":313532734511,"f":40},{"t":655361,"n":"COR_E_THREADINTERRUPTED","d":121903,"h":317827701807,"f":40},{"t":655361,"n":"COR_E_THREADSTART","d":121903,"h":322122669103,"f":40},{"t":655361,"n":"COR_E_THREADSTATE","d":121903,"h":326417636399,"f":40},{"t":655361,"n":"COR_E_TIMEOUT","d":121903,"h":330712603695,"f":40},{"t":655361,"n":"COR_E_TYPEACCESS","d":121903,"h":335007570991,"f":40},{"t":655361,"n":"COR_E_TYPEINITIALIZATION","d":121903,"h":339302538287,"f":40},{"t":655361,"n":"COR_E_TYPELOAD","d":121903,"h":343597505583,"f":40},{"t":655361,"n":"COR_E_TYPEUNLOADED","d":121903,"h":347892472879,"f":40},{"t":655361,"n":"COR_E_UNAUTHORIZEDACCESS","d":121903,"h":352187440175,"f":40},{"t":655361,"n":"COR_E_VERIFICATION","d":121903,"h":356482407471,"f":40},{"t":655361,"n":"COR_E_WAITHANDLECANNOTBEOPENED","d":121903,"h":360777374767,"f":40},{"t":655361,"n":"CO_E_NOTINITIALIZED","d":121903,"h":365072342063,"f":40},{"t":655361,"n":"DISP_E_PARAMNOTFOUND","d":121903,"h":369367309359,"f":40},{"t":655361,"n":"DISP_E_TYPEMISMATCH","d":121903,"h":373662276655,"f":40},{"t":655361,"n":"DISP_E_BADVARTYPE","d":121903,"h":377957243951,"f":40},{"t":655361,"n":"DISP_E_OVERFLOW","d":121903,"h":382252211247,"f":40},{"t":655361,"n":"DISP_E_DIVBYZERO","d":121903,"h":386547178543,"f":40},{"t":655361,"n":"E_BOUNDS","d":121903,"h":390842145839,"f":40},{"t":655361,"n":"E_CHANGED_STATE","d":121903,"h":395137113135,"f":40},{"t":655361,"n":"E_FILENOTFOUND","d":121903,"h":399432080431,"f":40},{"t":655361,"n":"E_FAIL","d":121903,"h":403727047727,"f":40},{"t":655361,"n":"E_HANDLE","d":121903,"h":408022015023,"f":40},{"t":655361,"n":"E_INVALIDARG","d":121903,"h":412316982319,"f":40},{"t":655361,"n":"E_NOTIMPL","d":121903,"h":416611949615,"f":40},{"t":655361,"n":"E_OUTOFMEMORY","d":121903,"h":420906916911,"f":40},{"t":655361,"n":"E_POINTER","d":121903,"h":425201884207,"f":40},{"t":655361,"n":"ERROR_MRM_MAP_NOT_FOUND","d":121903,"h":429496851503,"f":40},{"t":655361,"n":"ERROR_TIMEOUT","d":121903,"h":433791818799,"f":40},{"t":655361,"n":"RO_E_CLOSED","d":121903,"h":438086786095,"f":40},{"t":655361,"n":"RPC_E_CHANGED_MODE","d":121903,"h":442381753391,"f":40},{"t":655361,"n":"TYPE_E_TYPEMISMATCH","d":121903,"h":446676720687,"f":40},{"t":655361,"n":"STG_E_PATHNOTFOUND","d":121903,"h":450971687983,"f":40},{"t":655361,"n":"CTL_E_PATHNOTFOUND","d":121903,"h":455266655279,"f":40},{"t":655361,"n":"CTL_E_FILENOTFOUND","d":121903,"h":459561622575,"f":40},{"t":655361,"n":"FUSION_E_INVALID_NAME","d":121903,"h":463856589871,"f":40},{"t":655361,"n":"FUSION_E_REF_DEF_MISMATCH","d":121903,"h":468151557167,"f":40},{"t":655361,"n":"ERROR_TOO_MANY_OPEN_FILES","d":121903,"h":472446524463,"f":40},{"t":655361,"n":"ERROR_SHARING_VIOLATION","d":121903,"h":476741491759,"f":40},{"t":655361,"n":"ERROR_LOCK_VIOLATION","d":121903,"h":481036459055,"f":40},{"t":655361,"n":"ERROR_OPEN_FAILED","d":121903,"h":485331426351,"f":40},{"t":655361,"n":"ERROR_DISK_CORRUPT","d":121903,"h":489626393647,"f":40},{"t":655361,"n":"ERROR_UNRECOGNIZED_VOLUME","d":121903,"h":493921360943,"f":40},{"t":655361,"n":"ERROR_DLL_INIT_FAILED","d":121903,"h":498216328239,"f":40},{"t":655361,"n":"MSEE_E_ASSEMBLYLOADINPROGRESS","d":121903,"h":502511295535,"f":40},{"t":655361,"n":"ERROR_FILE_INVALID","d":121903,"h":506806262831,"f":40}],"h":121903}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.HResults`; }
        });
        
        $asm.$cls("$sifd.System.IO.PathInternal", ($self) => class PathInternal
        {
            static /*StringComparison */ get StringComparison()
            {
                return $.$sifd.System.IO.PathInternal.IsCaseSensitive ? 4/*StringComparison.Ordinal*/ : 5/*StringComparison.OrdinalIgnoreCase*/;
            }
            static /*bool */ get IsCaseSensitive()
            {
                return !($.$spc.System.OperatingSystem.IsWindows() || $.$spc.System.OperatingSystem.IsMacOS() || $.$spc.System.OperatingSystem.IsIOS() || $.$spc.System.OperatingSystem.IsTvOS());
            }
            static $h = 384047;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":119472129,"g":{"r":0,"d":0,"h":8590318639,"f":40},"n":"StringComparison","d":384047,"h":4295351343,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":17180253231,"f":40},"n":"IsCaseSensitive","d":384047,"h":12885285935,"f":40}],"h":384047}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.PathInternal`; }
        });
        
        $asm.$cls("$sifd.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 449583;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":449583,"h":4295416879,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":449583,"h":8590384175,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":449583,"h":12885351471,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":449583,"h":17180318767,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":449583,"h":21475286063,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":449583,"h":25770253359,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":449583,"h":30065220655,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":449583,"h":34360187951,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":449583,"h":38655155247,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":449583,"h":42950122543,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":449583,"h":47245089839,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":449583,"h":51540057135,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":449583,"h":55835024431,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":449583,"h":60129991727,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":449583,"h":64424959023,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":449583,"h":68719926319,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":449583,"h":73014893615,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":449583,"h":77309860911,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":449583,"h":81604828207,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":449583,"h":85899795503,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":449583,"h":90194762799,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":449583,"h":94489730095,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":449583,"h":98784697391,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":449583,"h":103079664687,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":449583,"h":107374631983,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":449583,"h":111669599279,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":449583,"h":115964566575,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":449583,"h":120259533871,"f":40},{"t":1310721,"n":"WebRequestMessage","d":449583,"h":124554501167,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":449583,"h":128849468463,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":449583,"h":133144435759,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":449583,"h":137439403055,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":449583,"h":141734370351,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":449583,"h":146029337647,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":449583,"h":150324304943,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":449583,"h":154619272239,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":449583,"h":158914239535,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":449583,"h":163209206831,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":449583,"h":167504174127,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":449583,"h":171799141423,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":449583,"h":176094108719,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":449583,"h":180389076015,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":449583,"h":184684043311,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":449583,"h":188979010607,"f":40},{"t":1310721,"n":"RijndaelMessage","d":449583,"h":193273977903,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":449583,"h":197568945199,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":449583,"h":201863912495,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":449583,"h":206158879791,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":449583,"h":210453847087,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":449583,"h":214748814383,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":449583,"h":219043781679,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":449583,"h":223338748975,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":449583,"h":227633716271,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":449583,"h":231928683567,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":449583,"h":236223650863,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":449583,"h":240518618159,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":449583,"h":244813585455,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":449583,"h":249108552751,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":449583,"h":253403520047,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":449583,"h":257698487343,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":449583,"h":261993454639,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":449583,"h":266288421935,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":449583,"h":270583389231,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":449583,"h":274878356527,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":449583,"h":279173323823,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":449583,"h":283468291119,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":449583,"h":287763258415,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":449583,"h":292058225711,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":449583,"h":296353193007,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":449583,"h":300648160303,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":449583,"h":304943127599,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":449583,"h":309238094895,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":449583,"h":313533062191,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":449583,"h":317828029487,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":449583,"h":322122996783,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":449583,"h":326417964079,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":449583,"h":330712931375,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":449583,"h":335007898671,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":449583,"h":339302865967,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":449583,"h":343597833263,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":449583,"h":347892800559,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":449583,"h":352187767855,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":449583,"h":356482735151,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":449583,"h":360777702447,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":449583,"h":365072669743,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":449583,"h":369367637039,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":449583,"h":373662604335,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":449583,"h":377957571631,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":449583,"h":382252538927,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":449583,"h":386547506223,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":449583,"h":390842473519,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":449583,"h":395137440815,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":449583,"h":399432408111,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":449583,"h":403727375407,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":449583,"h":408022342703,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":449583,"h":412317309999,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":449583,"h":416612277295,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":449583,"h":420907244591,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":449583,"h":425202211887,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":449583,"h":429497179183,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":449583,"h":433792146479,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":449583,"h":438087113775,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":449583,"h":442382081071,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":449583,"h":446677048367,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":449583,"h":450972015663,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":449583,"h":455266982959,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":449583,"h":459561950255,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":449583,"h":463856917551,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":449583,"h":468151884847,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":449583,"h":472446852143,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":449583,"h":476741819439,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":449583,"h":481036786735,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":449583,"h":485331754031,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":449583,"h":489626721327,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":449583,"h":493921688623,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":449583,"h":498216655919,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":449583,"h":502511623215,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":449583,"h":506806590511,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":449583,"h":511101557807,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":449583,"h":515396525103,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":449583,"h":519691492399,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":449583,"h":523986459695,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":449583,"h":528281426991,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":449583,"h":532576394287,"f":40}],"h":449583}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$sifd.System.IO.DriveInfo", ($self) => class DriveInfo extends $.$spc.System.Object
        {
            /*string*/ _name = null;
            $ctor$1(/*string*/ driveName)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(driveName, "driveName");
                    this._name = $.$sifd.System.IO.DriveInfo.NormalizeDriveName(driveName);
                }
                return this;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                return this._name;
            }
            /*bool */ get IsReady()
            {
                return $.$spc.System.IO.Directory.Exists(this.Name);
            }
            /*DirectoryInfo */ get RootDirectory()
            {
                return new $.$spc.System.IO.DirectoryInfo().$ctor$4(this.Name);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.Name;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sifd.System.IO.DriveInfo.ToString.apply(this, arguments); }
            static /*DriveInfo[] */ GetDrives()
            {
                /*string[]*/ let mountPoints = $.$sifd.System.IO.DriveInfo.GetMountPoints();
                /*DriveInfo[]*/ let info = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sifd.System.IO.DriveInfo), null, [mountPoints.length], null);
                for(/*int*/ let i = 0; i < info.length; i++)
                {
                    $.$spc.System.Array.$WriteT1.call(info, new $.$sifd.System.IO.DriveInfo().$ctor$1($.$spc.System.Array.$ReadT1.call(mountPoints, i)), i);
                }
                return info;
            }
            static /*string */ NormalizeDriveName(/*string*/ driveName)
            {
                if ($.$spc.System.String.Contains$2.call(driveName, /*\u0000*/ 0))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sifd.System.SR.Format($.$sifd.System.SR.Arg_InvalidDriveChars, driveName), "driveName");
                }
                if (driveName.length === 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sifd.System.SR.Arg_MustBeNonEmptyDriveName, "driveName");
                }
                return driveName;
            }
            /*string */ get VolumeLabel()
            {
                return this.Name;
            }
            /*string */ set VolumeLabel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*DriveType */ get DriveType()
            {
                return 0/*DriveType.Unknown*/;
            }
            /*string */ get DriveFormat()
            {
                return "memfs";
            }
            /*long */ get AvailableFreeSpace()
            {
                return 0n;
            }
            /*long */ get TotalFreeSpace()
            {
                return 0n;
            }
            /*long */ get TotalSize()
            {
                return 0n;
            }
            static /*string[] */ GetMountPoints()
            {
                return $.$spc.System.Environment.GetLogicalDrives();
            }
            static $h = 187439;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475023919,"f":1},"n":"Name","d":187439,"h":17180056623,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30064958511,"f":1},"n":"IsReady","d":187439,"h":25769991215,"f":1},{"p":58654721,"g":{"r":0,"d":0,"h":38654893103,"f":1},"n":"RootDirectory","d":187439,"h":34359925807,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60129729583,"f":1},"s":{"r":0,"d":0,"h":64424696879,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"VolumeLabel","d":187439,"h":55834762287,"f":1},{"p":318511,"g":{"r":0,"d":0,"h":73014631471,"f":1},"n":"DriveType","d":187439,"h":68719664175,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604566063,"f":1},"n":"DriveFormat","d":187439,"h":77309598767,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":90194500655,"f":1},"n":"AvailableFreeSpace","d":187439,"h":85899533359,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":98784435247,"f":1},"n":"TotalFreeSpace","d":187439,"h":94489467951,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":107374369839,"f":1},"n":"TotalSize","d":187439,"h":103079402543,"f":1}],"m":[{"r":1310721,"n":"ToString","d":187439,"h":42949860399,"f":32769},{"r":0,"n":"GetDrives","d":187439,"h":47244827695,"f":33},{"r":1310721,"p":[{"n":"driveName","p":1310721}],"n":"NormalizeDriveName","d":187439,"h":51539794991,"f":34},{"r":0,"n":"GetMountPoints","d":187439,"h":111669337135,"f":34}],"l":[{"t":1310721,"n":"_name","d":187439,"h":4295154735,"f":2}],"c":[{"p":[{"n":"driveName","p":1310721}],"n":".ctor","o":"$ctor$1","d":187439,"h":8590122031,"f":1}],"i":[113377281],"h":187439}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.DriveInfo`; }
        });
        
        $asm.$str("$sifd.System.IO.DriveType", ($self) => class DriveType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static NoRootDirectory = 1;
            static Removable = 2;
            static Fixed = 3;
            static Network = 4;
            static CDRom = 5;
            static Ram = 6;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "NoRootDirectory": 1n,
                    "Removable": 2n,
                    "Fixed": 3n,
                    "Network": 4n,
                    "CDRom": 5n,
                    "Ram": 6n
                };
            }
            static $h = 318511;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":318511,"n":"Unknown","d":318511,"h":4295285807,"f":33},{"t":318511,"n":"NoRootDirectory","d":318511,"h":8590253103,"f":33},{"t":318511,"n":"Removable","d":318511,"h":12885220399,"f":33},{"t":318511,"n":"Fixed","d":318511,"h":17180187695,"f":33},{"t":318511,"n":"Network","d":318511,"h":21475154991,"f":33},{"t":318511,"n":"CDRom","d":318511,"h":25770122287,"f":33},{"t":318511,"n":"Ram","d":318511,"h":30065089583,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":318511,"h":34360056879,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":318511}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.DriveType`; }
        });
        
        $asm.$cls("$sifd.System.IO.DriveNotFoundException", ($self) => class DriveNotFoundException extends $.$spc.System.IO.IOException
        {
            $ctor$14()
            {
                super.$ctor$10($.$sifd.System.SR.IO_DriveNotFound);
                {
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            $ctor$15(/*string?*/ message)
            {
                super.$ctor$10(message ?? $.$sifd.System.SR.IO_DriveNotFound);
                {
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            $ctor$16(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$12(message ?? $.$sifd.System.SR.IO_DriveNotFound, innerException);
                {
                    this.HResult = -2147024893/*HResults.COR_E_DIRECTORYNOTFOUND*/;
                }
                return this;
            }
            $ctor$17(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$13(info, context);
                {
                }
                return this;
            }
            static $h = 252975;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":60686337,"h":252975}; }
            static get $b() { return $.$spc.System.IO.IOException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.DriveNotFoundException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices"))