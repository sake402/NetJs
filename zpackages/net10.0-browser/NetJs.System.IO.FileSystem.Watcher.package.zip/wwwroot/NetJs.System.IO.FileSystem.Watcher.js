
//--TRIMMABLE-BOUNDARY-START(82)
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $scm, $so, $scp, $sris, $sto, $stt) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.FileSystem.Watcher", 
    {
  "h": 82,
  "f": "System.IO.FileSystem.Watcher",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.IO.FileSystem.Watcher",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.IO.FileSystem.Watcher",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(655442)
        $asm.$str("$sifw.System.IO.WaitForChangedResult", ($self) => class WaitForChangedResult extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295622738)
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4295622738)
            
            //--TRIMMABLE-BOUNDARY-START(8590590034)
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590590034)
            
            //--TRIMMABLE-BOUNDARY-START(17180524626)
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770459218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WatcherChangeTypes */ set ChangeType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720132178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180524626)
            
            //--TRIMMABLE-BOUNDARY-START(55835230290)
            /*string? */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360393810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310066770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835230290)
            
            //--TRIMMABLE-BOUNDARY-START(60130197586)
            /*string? */ get OldName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950328402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set OldName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900001362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60130197586)
            
            //--TRIMMABLE-BOUNDARY-START(98784903250)
            /*bool */ get TimedOut()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540262994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set TimedOut(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489935954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98784903250)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295622738)
                this._dummy = null;
                //--TRIMMABLE-BOUNDARY-END(4295622738)
                
                //--TRIMMABLE-BOUNDARY-START(8590590034)
                this._dummyPrimitive = 0;
                //--TRIMMABLE-BOUNDARY-END(8590590034)
                
            }
            static $h = 655442;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180524626),
    {
      "p": 720978,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770459218,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720132178,
        "f": 83886081
      },
      "n": "ChangeType",
      "d": 655442,
      "h": 17180524626,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180524626),
//--TRIMMABLE-BOUNDARY-START(55835230290),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360393810,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310066770,
        "f": 83886081
      },
      "n": "Name",
      "d": 655442,
      "h": 55835230290,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835230290),
//--TRIMMABLE-BOUNDARY-START(60130197586),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950328402,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900001362,
        "f": 83886081
      },
      "n": "OldName",
      "d": 655442,
      "h": 60130197586,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130197586),
//--TRIMMABLE-BOUNDARY-START(98784903250),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540262994,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489935954,
        "f": 83886081
      },
      "n": "TimedOut",
      "d": 655442,
      "h": 98784903250,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784903250)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622738),
    {
      "t": 131073,
      "n": "_dummy",
      "d": 655442,
      "h": 4295622738,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622738),
//--TRIMMABLE-BOUNDARY-START(8590590034),
    {
      "t": 655361,
      "n": "_dummyPrimitive",
      "d": 655442,
      "h": 8590590034,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590590034)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885557330),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655442,
      "h": 12885557330,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557330)
  ],
  "h": 655442
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IO.WaitForChangedResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655442)
        
        
        //--TRIMMABLE-BOUNDARY-START(131154)
        $asm.$cls("$sifw.System.IO.ErrorEventHandler", ($self) => class ErrorEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Object*/ sender, /*$.$sifw.System.IO.ErrorEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 131154;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 98828289,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180000338),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 65618
        }
      ],
      "n": "Invoke",
      "d": 131154,
      "h": 17180000338,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180000338),
//--TRIMMABLE-BOUNDARY-START(8590065746),
    {
      "r": 89653249,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 65618
        },
        {
          "n": "callback",
          "p": 45154305
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 131154,
      "h": 8590065746,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590065746),
//--TRIMMABLE-BOUNDARY-START(12885033042),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 89653249
        }
      ],
      "n": "EndInvoke",
      "d": 131154,
      "h": 12885033042,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885033042)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098450),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 131154,
      "h": 4295098450,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098450)
  ],
  "i": [89849857,157351937
  ],
  "h": 131154
}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.ErrorEventHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131154)
        
        
        //--TRIMMABLE-BOUNDARY-START(262226)
        $asm.$cls("$sifw.System.IO.FileSystemEventHandler", ($self) => class FileSystemEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Object*/ sender, /*$.$sifw.System.IO.FileSystemEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 262226;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 98828289,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180131410),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 196690
        }
      ],
      "n": "Invoke",
      "d": 262226,
      "h": 17180131410,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180131410),
//--TRIMMABLE-BOUNDARY-START(8590196818),
    {
      "r": 89653249,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 196690
        },
        {
          "n": "callback",
          "p": 45154305
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 262226,
      "h": 8590196818,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590196818),
//--TRIMMABLE-BOUNDARY-START(12885164114),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 89653249
        }
      ],
      "n": "EndInvoke",
      "d": 262226,
      "h": 12885164114,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885164114)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229522),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 262226,
      "h": 4295229522,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229522)
  ],
  "i": [89849857,157351937
  ],
  "h": 262226
}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.FileSystemEventHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262226)
        
        
        //--TRIMMABLE-BOUNDARY-START(589906)
        $asm.$cls("$sifw.System.IO.RenamedEventHandler", ($self) => class RenamedEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Object*/ sender, /*$.$sifw.System.IO.RenamedEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 589906;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 98828289,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180459090),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 524370
        }
      ],
      "n": "Invoke",
      "d": 589906,
      "h": 17180459090,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180459090),
//--TRIMMABLE-BOUNDARY-START(8590524498),
    {
      "r": 89653249,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 524370
        },
        {
          "n": "callback",
          "p": 45154305
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 589906,
      "h": 8590524498,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590524498),
//--TRIMMABLE-BOUNDARY-START(12885491794),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 89653249
        }
      ],
      "n": "EndInvoke",
      "d": 589906,
      "h": 12885491794,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885491794)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557202),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 589906,
      "h": 4295557202,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557202)
  ],
  "i": [89849857,157351937
  ],
  "h": 589906
}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.RenamedEventHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589906)
        
        
        //--TRIMMABLE-BOUNDARY-START(458834)
        $asm.$str("$sifw.System.IO.NotifyFilters", ($self) => class NotifyFilters extends $.$$.System.Enum
        {
            static FileName = 1;
            static DirectoryName = 2;
            static Attributes = 4;
            static Size = 8;
            static LastWrite = 16;
            static LastAccess = 32;
            static CreationTime = 64;
            static Security = 256;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(458834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "FileName": 1n,
                    "DirectoryName": 2n,
                    "Attributes": 4n,
                    "Size": 8n,
                    "LastWrite": 16n,
                    "LastAccess": 32n,
                    "CreationTime": 64n,
                    "Security": 256n
                };
            }
            static $h = 458834;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475295314),
    {
      "t": 458834,
      "n": "FileName",
      "d": 458834,
      "h": 21475295314,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475295314),
//--TRIMMABLE-BOUNDARY-START(17180328018),
    {
      "t": 458834,
      "n": "DirectoryName",
      "d": 458834,
      "h": 17180328018,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180328018),
//--TRIMMABLE-BOUNDARY-START(8590393426),
    {
      "t": 458834,
      "n": "Attributes",
      "d": 458834,
      "h": 8590393426,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393426),
//--TRIMMABLE-BOUNDARY-START(38655164498),
    {
      "t": 458834,
      "n": "Size",
      "d": 458834,
      "h": 38655164498,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655164498),
//--TRIMMABLE-BOUNDARY-START(30065229906),
    {
      "t": 458834,
      "n": "LastWrite",
      "d": 458834,
      "h": 30065229906,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065229906),
//--TRIMMABLE-BOUNDARY-START(25770262610),
    {
      "t": 458834,
      "n": "LastAccess",
      "d": 458834,
      "h": 25770262610,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770262610),
//--TRIMMABLE-BOUNDARY-START(12885360722),
    {
      "t": 458834,
      "n": "CreationTime",
      "d": 458834,
      "h": 12885360722,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360722),
//--TRIMMABLE-BOUNDARY-START(34360197202),
    {
      "t": 458834,
      "n": "Security",
      "d": 458834,
      "h": 34360197202,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360197202)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426130),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458834,
      "h": 4295426130,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426130)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 458834,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.NotifyFilters`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458834)
        
        
        //--TRIMMABLE-BOUNDARY-START(720978)
        $asm.$str("$sifw.System.IO.WatcherChangeTypes", ($self) => class WatcherChangeTypes extends $.$$.System.Enum
        {
            static Created = 1;
            static Deleted = 2;
            static Changed = 4;
            static Renamed = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Created": 1n,
                    "Deleted": 2n,
                    "Changed": 4n,
                    "Renamed": 8n,
                    "All": 15n
                };
            }
            static $h = 720978;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180590162),
    {
      "t": 720978,
      "n": "Created",
      "d": 720978,
      "h": 17180590162,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590162),
//--TRIMMABLE-BOUNDARY-START(21475557458),
    {
      "t": 720978,
      "n": "Deleted",
      "d": 720978,
      "h": 21475557458,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475557458),
//--TRIMMABLE-BOUNDARY-START(12885622866),
    {
      "t": 720978,
      "n": "Changed",
      "d": 720978,
      "h": 12885622866,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622866),
//--TRIMMABLE-BOUNDARY-START(25770524754),
    {
      "t": 720978,
      "n": "Renamed",
      "d": 720978,
      "h": 25770524754,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770524754),
//--TRIMMABLE-BOUNDARY-START(8590655570),
    {
      "t": 720978,
      "n": "All",
      "d": 720978,
      "h": 8590655570,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655570)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688274),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720978,
      "h": 4295688274,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688274)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 720978,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.WatcherChangeTypes`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720978)
        
        
        //--TRIMMABLE-BOUNDARY-START(65618)
        $asm.$cls("$sifw.System.IO.ErrorEventArgs", ($self) => class ErrorEventArgs extends $.$$.System.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(4295032914)
            $ctor$2(/*System.Exception*/ exception)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032914);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032914)
            
            //--TRIMMABLE-BOUNDARY-START(8590000210)
            /*System.Exception */ GetException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590000210)
            
            static $h = 65618;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79626241,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000210),
    {
      "r": 79888385,
      "n": "GetException",
      "d": 65618,
      "h": 8590000210,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590000210)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032914),
    {
      "p": [
        {
          "n": "exception",
          "p": 79888385
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65618,
      "h": 4295032914,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032914)
  ],
  "h": 65618
}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.IO.ErrorEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65618)
        
        
        //--TRIMMABLE-BOUNDARY-START(196690)
        $asm.$cls("$sifw.System.IO.FileSystemEventArgs", ($self) => class FileSystemEventArgs extends $.$$.System.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(4295163986)
            $ctor$2(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295163986);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163986)
            
            //--TRIMMABLE-BOUNDARY-START(8590131282)
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590131282)
            
            //--TRIMMABLE-BOUNDARY-START(12885098578)
            /*string */ get FullPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885098578)
            
            //--TRIMMABLE-BOUNDARY-START(42949869650)
            /*string? */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42949869650)
            
            static $h = 196690;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79626241,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590131282),
    {
      "p": 720978,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475033170,
        "f": 50331649
      },
      "n": "ChangeType",
      "d": 196690,
      "h": 8590131282,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590131282),
//--TRIMMABLE-BOUNDARY-START(12885098578),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064967762,
        "f": 50331649
      },
      "n": "FullPath",
      "d": 196690,
      "h": 12885098578,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885098578),
//--TRIMMABLE-BOUNDARY-START(42949869650),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654902354,
        "f": 50331649
      },
      "n": "Name",
      "d": 196690,
      "h": 42949869650,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949869650)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163986),
    {
      "p": [
        {
          "n": "changeType",
          "p": 720978
        },
        {
          "n": "directory",
          "p": 1310721
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196690,
      "h": 4295163986,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163986)
  ],
  "h": 196690
}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.IO.FileSystemEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196690)
        
        
        //--TRIMMABLE-BOUNDARY-START(327762)
        $asm.$cls("$sifw.System.IO.FileSystemWatcher", ($self) => class FileSystemWatcher extends $.$scp.System.ComponentModel.Component
        {
            //--TRIMMABLE-BOUNDARY-START(4295295058)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295058);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295058)
            
            //--TRIMMABLE-BOUNDARY-START(8590262354)
            $ctor$5(/*string*/ path)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262354);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262354)
            
            //--TRIMMABLE-BOUNDARY-START(12885229650)
            $ctor$4(/*string*/ path, /*string*/ filter)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885229650);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885229650)
            
            //--TRIMMABLE-BOUNDARY-START(81604706386)
            /*bool */ get EnableRaisingEvents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583267410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81604706386)
            
            //--TRIMMABLE-BOUNDARY-START(94489608274)
            /*string */ get Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964444754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Filter(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173202002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(94489608274)
            
            //--TRIMMABLE-BOUNDARY-START(98784575570)
            /*System.Collections.ObjectModel.Collection<string> */ get Filters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98784575570)
            
            //--TRIMMABLE-BOUNDARY-START(180388954194)
            /*bool */ get IncludeSubdirectories()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144313938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IncludeSubdirectories(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763136594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(180388954194)
            
            //--TRIMMABLE-BOUNDARY-START(184683921490)
            /*int */ get InternalBufferSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734248530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InternalBufferSize(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353071186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(184683921490)
            
            //--TRIMMABLE-BOUNDARY-START(188978888786)
            /*System.IO.NotifyFilters */ get NotifyFilter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324183122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ set NotifyFilter(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943005778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(188978888786)
            
            //--TRIMMABLE-BOUNDARY-START(214748692562)
            /*string */ get Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914117714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Path(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532940370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(214748692562)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 335007776850, 146029084712)
            /*System.ComponentModel.ISite? */ get Site()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504052306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ set Site(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322122874962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 335007776850, 146029084712)
            
            //--TRIMMABLE-BOUNDARY-START(339302744146)
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093986898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712809554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(339302744146)
            
            //--TRIMMABLE-BOUNDARY-START(64424837202)
            /*System.IO.FileSystemEventHandler?*/ add_Changed(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Changed(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338627154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64424837202)
            
            //--TRIMMABLE-BOUNDARY-START(68719804498)
            /*System.IO.FileSystemEventHandler?*/ add_Created(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065098834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Created(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928561746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68719804498)
            
            //--TRIMMABLE-BOUNDARY-START(73014771794)
            /*System.IO.FileSystemEventHandler?*/ add_Deleted(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Deleted(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518496338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(73014771794)
            
            //--TRIMMABLE-BOUNDARY-START(90194640978)
            /*System.IO.ErrorEventHandler?*/ add_Error(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244968018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            /*System.IO.ErrorEventHandler?*/ remove_Error(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108430930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(90194640978)
            
            //--TRIMMABLE-BOUNDARY-START(261993332818)
            /*System.IO.RenamedEventHandler?*/ add_Renamed(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834902610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            /*System.IO.RenamedEventHandler?*/ remove_Renamed(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698365522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(261993332818)
            
            //--TRIMMABLE-BOUNDARY-START(60129869906)
            /*void */ BeginInit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129869906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60129869906)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 77309739090, 51539804200)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309739090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 77309739090, 51539804200)
            
            //--TRIMMABLE-BOUNDARY-START(85899673682)
            /*void */ EndInit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(85899673682)
            
            //--TRIMMABLE-BOUNDARY-START(193273856082)
            /*void */ OnChanged(/*System.IO.FileSystemEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273856082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(193273856082)
            
            //--TRIMMABLE-BOUNDARY-START(197568823378)
            /*void */ OnCreated(/*System.IO.FileSystemEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568823378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(197568823378)
            
            //--TRIMMABLE-BOUNDARY-START(201863790674)
            /*void */ OnDeleted(/*System.IO.FileSystemEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863790674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(201863790674)
            
            //--TRIMMABLE-BOUNDARY-START(206158757970)
            /*void */ OnError(/*System.IO.ErrorEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158757970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(206158757970)
            
            //--TRIMMABLE-BOUNDARY-START(210453725266)
            /*void */ OnRenamed(/*System.IO.RenamedEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453725266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(210453725266)
            
            //--TRIMMABLE-BOUNDARY-START(343597711442)
            /*System.IO.WaitForChangedResult */ WaitForChanged$2(/*System.IO.WatcherChangeTypes*/ changeType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597711442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(343597711442)
            
            //--TRIMMABLE-BOUNDARY-START(347892678738)
            /*System.IO.WaitForChangedResult */ WaitForChanged(/*System.IO.WatcherChangeTypes*/ changeType, /*int*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892678738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(347892678738)
            
            //--TRIMMABLE-BOUNDARY-START(352187646034)
            /*System.IO.WaitForChangedResult */ WaitForChanged$1(/*System.IO.WatcherChangeTypes*/ changeType, /*System.TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187646034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(352187646034)
            
            //--TRIMMABLE-BOUNDARY-START(4296474664)
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.BeginInit()
            System$ComponentModel$ISupportInitialize$BeginInit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296474664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BeginInit(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296474664)
            
            //--TRIMMABLE-BOUNDARY-START(8591441960)
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.EndInit()
            System$ComponentModel$ISupportInitialize$EndInit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591441960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EndInit(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591441960)
            
            static $h = 327762;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196648,
  "p": [
//--TRIMMABLE-BOUNDARY-START(81604706386),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374510162,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270583267410,
        "f": 83886081
      },
      "n": "EnableRaisingEvents",
      "d": 327762,
      "h": 81604706386,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604706386),
//--TRIMMABLE-BOUNDARY-START(94489608274),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964444754,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279173202002,
        "f": 83886081
      },
      "n": "Filter",
      "d": 327762,
      "h": 94489608274,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489608274),
//--TRIMMABLE-BOUNDARY-START(98784575570),
    {
      "p": $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554379346,
        "f": 50331649
      },
      "n": "Filters",
      "d": 327762,
      "h": 98784575570,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784575570),
//--TRIMMABLE-BOUNDARY-START(180388954194),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144313938,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763136594,
        "f": 83886081
      },
      "n": "IncludeSubdirectories",
      "d": 327762,
      "h": 180388954194,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180388954194),
//--TRIMMABLE-BOUNDARY-START(184683921490),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734248530,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353071186,
        "f": 83886081
      },
      "n": "InternalBufferSize",
      "d": 327762,
      "h": 184683921490,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184683921490),
//--TRIMMABLE-BOUNDARY-START(188978888786),
    {
      "p": 458834,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324183122,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943005778,
        "f": 83886081
      },
      "n": "NotifyFilter",
      "d": 327762,
      "h": 188978888786,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188978888786),
//--TRIMMABLE-BOUNDARY-START(214748692562),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914117714,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313532940370,
        "f": 83886081
      },
      "n": "Path",
      "d": 327762,
      "h": 214748692562,
      "f": 2097153,
      "a": [
        {
          "t": 852008,
          "c": 12885753896,
          "a": [
            {
              "v": "System.Diagnostics.Design.FSWPathEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
              "t": 1310721
            },
            {
              "v": "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214748692562),
//--TRIMMABLE-BOUNDARY-START(ALL, 335007776850, 146029084712),
    {
      "p": 1441832,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504052306,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322122874962,
        "f": 83918849
      },
      "n": "Site",
      "d": 327762,
      "h": 335007776850,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 335007776850, 146029084712),
//--TRIMMABLE-BOUNDARY-START(339302744146),
    {
      "p": 1572904,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176093986898,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330712809554,
        "f": 83886081
      },
      "n": "SynchronizingObject",
      "d": 327762,
      "h": 339302744146,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(339302744146)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60129869906),
    {
      "r": 65537,
      "n": "BeginInit",
      "d": 327762,
      "h": 60129869906,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129869906),
//--TRIMMABLE-BOUNDARY-START(ALL, 77309739090, 51539804200),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 327762,
      "h": 77309739090,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 77309739090, 51539804200),
//--TRIMMABLE-BOUNDARY-START(85899673682),
    {
      "r": 65537,
      "n": "EndInit",
      "d": 327762,
      "h": 85899673682,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899673682),
//--TRIMMABLE-BOUNDARY-START(193273856082),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 196690
        }
      ],
      "n": "OnChanged",
      "d": 327762,
      "h": 193273856082,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(193273856082),
//--TRIMMABLE-BOUNDARY-START(197568823378),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 196690
        }
      ],
      "n": "OnCreated",
      "d": 327762,
      "h": 197568823378,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(197568823378),
//--TRIMMABLE-BOUNDARY-START(201863790674),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 196690
        }
      ],
      "n": "OnDeleted",
      "d": 327762,
      "h": 201863790674,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(201863790674),
//--TRIMMABLE-BOUNDARY-START(206158757970),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 65618
        }
      ],
      "n": "OnError",
      "d": 327762,
      "h": 206158757970,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(206158757970),
//--TRIMMABLE-BOUNDARY-START(210453725266),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 524370
        }
      ],
      "n": "OnRenamed",
      "d": 327762,
      "h": 210453725266,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(210453725266),
//--TRIMMABLE-BOUNDARY-START(343597711442),
    {
      "r": 655442,
      "p": [
        {
          "n": "changeType",
          "p": 720978
        }
      ],
      "n": "WaitForChanged",
      "o": "@$2",
      "d": 327762,
      "h": 343597711442,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(343597711442),
//--TRIMMABLE-BOUNDARY-START(347892678738),
    {
      "r": 655442,
      "p": [
        {
          "n": "changeType",
          "p": 720978
        },
        {
          "n": "timeout",
          "p": 655361
        }
      ],
      "n": "WaitForChanged",
      "d": 327762,
      "h": 347892678738,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(347892678738),
//--TRIMMABLE-BOUNDARY-START(352187646034),
    {
      "r": 655442,
      "p": [
        {
          "n": "changeType",
          "p": 720978
        },
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "WaitForChanged",
      "o": "@$1",
      "d": 327762,
      "h": 352187646034,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(352187646034)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295058),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327762,
      "h": 4295295058,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295058),
//--TRIMMABLE-BOUNDARY-START(8590262354),
    {
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 327762,
      "h": 8590262354,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262354),
//--TRIMMABLE-BOUNDARY-START(12885229650),
    {
      "p": [
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "filter",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 327762,
      "h": 12885229650,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885229650)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(64424837202),
    {
      "e": 262226,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 262226
          }
        ],
        "n": "add_Changed",
        "d": 327762,
        "h": 21475164242,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 262226
          }
        ],
        "n": "remove_Changed",
        "d": 327762,
        "h": 223338627154,
        "f": 285212673
      },
      "n": "Changed",
      "d": 327762,
      "h": 64424837202,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(64424837202),
//--TRIMMABLE-BOUNDARY-START(68719804498),
    {
      "e": 262226,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 262226
          }
        ],
        "n": "add_Created",
        "d": 327762,
        "h": 30065098834,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 262226
          }
        ],
        "n": "remove_Created",
        "d": 327762,
        "h": 231928561746,
        "f": 285212673
      },
      "n": "Created",
      "d": 327762,
      "h": 68719804498,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(68719804498),
//--TRIMMABLE-BOUNDARY-START(73014771794),
    {
      "e": 262226,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 262226
          }
        ],
        "n": "add_Deleted",
        "d": 327762,
        "h": 38655033426,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 262226
          }
        ],
        "n": "remove_Deleted",
        "d": 327762,
        "h": 240518496338,
        "f": 285212673
      },
      "n": "Deleted",
      "d": 327762,
      "h": 73014771794,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(73014771794),
//--TRIMMABLE-BOUNDARY-START(90194640978),
    {
      "e": 131154,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 131154
          }
        ],
        "n": "add_Error",
        "d": 327762,
        "h": 47244968018,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 131154
          }
        ],
        "n": "remove_Error",
        "d": 327762,
        "h": 249108430930,
        "f": 285212673
      },
      "n": "Error",
      "d": 327762,
      "h": 90194640978,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(90194640978),
//--TRIMMABLE-BOUNDARY-START(261993332818),
    {
      "e": 589906,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 589906
          }
        ],
        "n": "add_Renamed",
        "d": 327762,
        "h": 55834902610,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 589906
          }
        ],
        "n": "remove_Renamed",
        "d": 327762,
        "h": 257698365522,
        "f": 285212673
      },
      "n": "Renamed",
      "d": 327762,
      "h": 261993332818,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(261993332818)
  ],
  "i": [1048616,90177537,1507368
  ],
  "h": 327762
}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$$.System.IDisposable, $.$scp.System.ComponentModel.ISupportInitialize ]; }
            static get $fullName() { return `System.IO.FileSystemWatcher`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327762)
        
        
        //--TRIMMABLE-BOUNDARY-START(524370)
        $asm.$cls("$sifw.System.IO.RenamedEventArgs", ($self) => class RenamedEventArgs extends $.$sifw.System.IO.FileSystemEventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(4295491666)
            $ctor$3(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name, /*string?*/ oldName)
            {
                super.$ctor$2(0, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295491666);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491666)
            
            //--TRIMMABLE-BOUNDARY-START(25770328146)
            /*string */ get OldFullPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885426258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770328146)
            
            //--TRIMMABLE-BOUNDARY-START(30065295442)
            /*string? */ get OldName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065295442)
            
            static $h = 524370;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196690,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770328146),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885426258,
        "f": 50331649
      },
      "n": "OldFullPath",
      "d": 524370,
      "h": 25770328146,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770328146),
//--TRIMMABLE-BOUNDARY-START(30065295442),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475360850,
        "f": 50331649
      },
      "n": "OldName",
      "d": 524370,
      "h": 30065295442,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065295442)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491666),
    {
      "p": [
        {
          "n": "changeType",
          "p": 720978
        },
        {
          "n": "directory",
          "p": 1310721
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "oldName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524370,
      "h": 4295491666,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491666)
  ],
  "h": 524370
}; }
            static get $b() { return $.$sifw.System.IO.FileSystemEventArgs; }
            static get $fullName() { return `System.IO.RenamedEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524370)
        
        
        //--TRIMMABLE-BOUNDARY-START(393298)
        $asm.$cls("$sifw.System.IO.InternalBufferOverflowException", ($self) => class InternalBufferOverflowException extends $.$$.System.SystemException
        {
            //--TRIMMABLE-BOUNDARY-START(4295360594)
            $ctor$9()
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360594);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360594)
            
            //--TRIMMABLE-BOUNDARY-START(8590327890)
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327890);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327890)
            
            //--TRIMMABLE-BOUNDARY-START(12885295186)
            $ctor$12(/*string?*/ message)
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295186);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885295186)
            
            //--TRIMMABLE-BOUNDARY-START(17180262482)
            $ctor$11(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180262482);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180262482)
            
            static $h = 393298;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 163643393,
  "h": 393298
}; }
            static get $b() { return $.$$.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.InternalBufferOverflowException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393298)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread"))
//--TRIMMABLE-BOUNDARY-END(82)
