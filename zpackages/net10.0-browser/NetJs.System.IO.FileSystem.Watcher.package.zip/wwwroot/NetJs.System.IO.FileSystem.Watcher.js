
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $scm, $so, $scp, $sris, $sto, $stt) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.FileSystem.Watcher", 
    {"h":41323,"f":"System.IO.FileSystem.Watcher","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$str("$sifw.System.IO.WaitForChangedResult", ($self) => class WaitForChangedResult extends $.$$.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WatcherChangeTypes */ set ChangeType(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set Name(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set OldName(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get TimedOut()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set TimedOut(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 696683;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":762219,"g":{"r":0,"d":0,"h":17180565867,"f":50331649},"s":{"r":0,"d":0,"h":21475533163,"f":83886081},"n":"ChangeType","d":696683,"h":12885598571,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30065467755,"f":50331649},"s":{"r":0,"d":0,"h":34360435051,"f":83886081},"n":"Name","d":696683,"h":25770500459,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":42950369643,"f":50331649},"s":{"r":0,"d":0,"h":47245336939,"f":83886081},"n":"OldName","d":696683,"h":38655402347,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":55835271531,"f":50331649},"s":{"r":0,"d":0,"h":60130238827,"f":83886081},"n":"TimedOut","d":696683,"h":51540304235,"f":2097153}],"l":[{"t":131073,"n":"_dummy","d":696683,"h":4295663979,"f":4194306},{"t":655361,"n":"_dummyPrimitive","d":696683,"h":8590631275,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":696683,"h":64425206123,"f":16777217}],"h":696683}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IO.WaitForChangedResult`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventHandler", ($self) => class ErrorEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Object*/ sender, /*$.$sifw.System.IO.ErrorEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 172395;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":106859}],"n":"Invoke","d":172395,"h":8590106987,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":106859},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":172395,"h":12885074283,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":172395,"h":17180041579,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":172395,"h":4295139691,"f":16777217}],"i":[57212929,113246209],"h":172395}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.ErrorEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventHandler", ($self) => class FileSystemEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Object*/ sender, /*$.$sifw.System.IO.FileSystemEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 303467;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":237931}],"n":"Invoke","d":303467,"h":8590238059,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":237931},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":303467,"h":12885205355,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":303467,"h":17180172651,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":303467,"h":4295270763,"f":16777217}],"i":[57212929,113246209],"h":303467}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.FileSystemEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventHandler", ($self) => class RenamedEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Object*/ sender, /*$.$sifw.System.IO.RenamedEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 631147;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":565611}],"n":"Invoke","d":631147,"h":8590565739,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":565611},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":631147,"h":12885533035,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":631147,"h":17180500331,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":631147,"h":4295598443,"f":16777217}],"i":[57212929,113246209],"h":631147}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.RenamedEventHandler`; }
        });
        
        $asm.$str("$sifw.System.IO.NotifyFilters", ($self) => class NotifyFilters extends $.$$.System.Enum
        {
            static FileName = 1;
            static DirectoryName = 2;
            static Attributes = 4;
            static Size = 8;
            static LastWrite = 16;
            static LastAccess = 32;
            static CreationTime = 64;
            static Security = 256;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FileName": 1n,
                    "DirectoryName": 2n,
                    "Attributes": 4n,
                    "Size": 8n,
                    "LastWrite": 16n,
                    "LastAccess": 32n,
                    "CreationTime": 64n,
                    "Security": 256n
                };
            }
            static $h = 500075;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":500075,"n":"FileName","d":500075,"h":4295467371,"f":4194337},{"t":500075,"n":"DirectoryName","d":500075,"h":8590434667,"f":4194337},{"t":500075,"n":"Attributes","d":500075,"h":12885401963,"f":4194337},{"t":500075,"n":"Size","d":500075,"h":17180369259,"f":4194337},{"t":500075,"n":"LastWrite","d":500075,"h":21475336555,"f":4194337},{"t":500075,"n":"LastAccess","d":500075,"h":25770303851,"f":4194337},{"t":500075,"n":"CreationTime","d":500075,"h":30065271147,"f":4194337},{"t":500075,"n":"Security","d":500075,"h":34360238443,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":500075,"h":38655205739,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":500075,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.NotifyFilters`; }
        });
        
        $asm.$str("$sifw.System.IO.WatcherChangeTypes", ($self) => class WatcherChangeTypes extends $.$$.System.Enum
        {
            static Created = 1;
            static Deleted = 2;
            static Changed = 4;
            static Renamed = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Created": 1n,
                    "Deleted": 2n,
                    "Changed": 4n,
                    "Renamed": 8n,
                    "All": 15n
                };
            }
            static $h = 762219;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":762219,"n":"Created","d":762219,"h":4295729515,"f":4194337},{"t":762219,"n":"Deleted","d":762219,"h":8590696811,"f":4194337},{"t":762219,"n":"Changed","d":762219,"h":12885664107,"f":4194337},{"t":762219,"n":"Renamed","d":762219,"h":17180631403,"f":4194337},{"t":762219,"n":"All","d":762219,"h":21475598699,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":762219,"h":25770565995,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":762219,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.WatcherChangeTypes`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventArgs", ($self) => class ErrorEventArgs extends $.$$.System.EventArgs
        {
            $ctor$2(/*System.Exception*/ exception)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Exception */ GetException()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 106859;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"m":[{"r":47251457,"n":"GetException","d":106859,"h":8590041451,"f":16777345}],"c":[{"p":[{"n":"exception","p":47251457}],"n":".ctor","o":"$ctor$2","d":106859,"h":4295074155,"f":16777217}],"h":106859}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.IO.ErrorEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventArgs", ($self) => class FileSystemEventArgs extends $.$$.System.EventArgs
        {
            $ctor$2(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FullPath()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 237931;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":762219,"g":{"r":0,"d":0,"h":12885139819,"f":50331649},"n":"ChangeType","d":237931,"h":8590172523,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":21475074411,"f":50331649},"n":"FullPath","d":237931,"h":17180107115,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30065009003,"f":50331649},"n":"Name","d":237931,"h":25770041707,"f":2097153}],"c":[{"p":[{"n":"changeType","p":762219},{"n":"directory","p":1310721},{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":237931,"h":4295205227,"f":16777217}],"h":237931}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.IO.FileSystemEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemWatcher", ($self) => class FileSystemWatcher extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*string*/ path)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ path, /*string*/ filter)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get EnableRaisingEvents()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Filter()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Filter(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.ObjectModel.Collection<string> */ get Filters()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IncludeSubdirectories()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IncludeSubdirectories(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InternalBufferSize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InternalBufferSize(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ get NotifyFilter()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ set NotifyFilter(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Path()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Path(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ get Site()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ set Site(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.FileSystemEventHandler?*/ add_Changed(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Changed(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ add_Created(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Created(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ add_Deleted(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Deleted(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ add_Error(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ remove_Error(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ add_Renamed(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ remove_Renamed(value)
            {
            }
            /*void */ BeginInit()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ EndInit()
            {
            }
            /*void */ OnChanged(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnCreated(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnDeleted(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnError(/*System.IO.ErrorEventArgs*/ e)
            {
            }
            /*void */ OnRenamed(/*System.IO.RenamedEventArgs*/ e)
            {
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$2(/*System.IO.WatcherChangeTypes*/ changeType)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged(/*System.IO.WatcherChangeTypes*/ changeType, /*int*/ timeout)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$1(/*System.IO.WatcherChangeTypes*/ changeType, /*System.TimeSpan*/ timeout)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.BeginInit()
            System$ComponentModel$ISupportInitialize$BeginInit()
            {
                return this.BeginInit(...arguments);
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.EndInit()
            System$ComponentModel$ISupportInitialize$EndInit()
            {
                return this.EndInit(...arguments);
            }
            static $h = 369003;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475205483,"f":50331649},"s":{"r":0,"d":0,"h":25770172779,"f":83886081},"n":"EnableRaisingEvents","d":369003,"h":17180238187,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":34360107371,"f":50331649},"s":{"r":0,"d":0,"h":38655074667,"f":83886081},"n":"Filter","d":369003,"h":30065140075,"f":2097153},{"p":$.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":47245009259,"f":50331649},"n":"Filters","d":369003,"h":42950041963,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":55834943851,"f":50331649},"s":{"r":0,"d":0,"h":60129911147,"f":83886081},"n":"IncludeSubdirectories","d":369003,"h":51539976555,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":68719845739,"f":50331649},"s":{"r":0,"d":0,"h":73014813035,"f":83886081},"n":"InternalBufferSize","d":369003,"h":64424878443,"f":2097153},{"p":500075,"g":{"r":0,"d":0,"h":81604747627,"f":50331649},"s":{"r":0,"d":0,"h":85899714923,"f":83886081},"n":"NotifyFilter","d":369003,"h":77309780331,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":94489649515,"f":50331649},"s":{"r":0,"d":0,"h":98784616811,"f":83886081},"n":"Path","d":369003,"h":90194682219,"f":2097153,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.FSWPathEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":1441831,"g":{"r":0,"d":0,"h":107374551403,"f":50364417},"s":{"r":0,"d":0,"h":111669518699,"f":83918849},"n":"Site","d":369003,"h":103079584107,"f":2129921},{"p":1572903,"g":{"r":0,"d":0,"h":120259453291,"f":50331649},"s":{"r":0,"d":0,"h":124554420587,"f":83886081},"n":"SynchronizingObject","d":369003,"h":115964485995,"f":2097153}],"m":[{"r":65537,"n":"BeginInit","d":369003,"h":193273897323,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":369003,"h":197568864619,"f":16809988},{"r":65537,"n":"EndInit","d":369003,"h":201863831915,"f":16777217},{"r":65537,"p":[{"n":"e","p":237931}],"n":"OnChanged","d":369003,"h":206158799211,"f":16777220},{"r":65537,"p":[{"n":"e","p":237931}],"n":"OnCreated","d":369003,"h":210453766507,"f":16777220},{"r":65537,"p":[{"n":"e","p":237931}],"n":"OnDeleted","d":369003,"h":214748733803,"f":16777220},{"r":65537,"p":[{"n":"e","p":106859}],"n":"OnError","d":369003,"h":219043701099,"f":16777220},{"r":65537,"p":[{"n":"e","p":565611}],"n":"OnRenamed","d":369003,"h":223338668395,"f":16777220},{"r":696683,"p":[{"n":"changeType","p":762219}],"n":"WaitForChanged","o":"@$2","d":369003,"h":227633635691,"f":16777217},{"r":696683,"p":[{"n":"changeType","p":762219},{"n":"timeout","p":655361}],"n":"WaitForChanged","d":369003,"h":231928602987,"f":16777217},{"r":696683,"p":[{"n":"changeType","p":762219},{"n":"timeout","p":140574721}],"n":"WaitForChanged","o":"@$1","d":369003,"h":236223570283,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$3","d":369003,"h":4295336299,"f":16777217},{"p":[{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$5","d":369003,"h":8590303595,"f":16777217},{"p":[{"n":"path","p":1310721},{"n":"filter","p":1310721}],"n":".ctor","o":"$ctor$4","d":369003,"h":12885270891,"f":16777217}],"e":[{"e":303467,"m":{"r":65537,"p":[{"n":"value","p":303467}],"n":"add_Changed","d":369003,"h":133144355179,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":303467}],"n":"remove_Changed","d":369003,"h":137439322475,"f":285212673},"n":"Changed","d":369003,"h":128849387883,"f":8388609},{"e":303467,"m":{"r":65537,"p":[{"n":"value","p":303467}],"n":"add_Created","d":369003,"h":146029257067,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":303467}],"n":"remove_Created","d":369003,"h":150324224363,"f":285212673},"n":"Created","d":369003,"h":141734289771,"f":8388609},{"e":303467,"m":{"r":65537,"p":[{"n":"value","p":303467}],"n":"add_Deleted","d":369003,"h":158914158955,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":303467}],"n":"remove_Deleted","d":369003,"h":163209126251,"f":285212673},"n":"Deleted","d":369003,"h":154619191659,"f":8388609},{"e":172395,"m":{"r":65537,"p":[{"n":"value","p":172395}],"n":"add_Error","d":369003,"h":171799060843,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":172395}],"n":"remove_Error","d":369003,"h":176094028139,"f":285212673},"n":"Error","d":369003,"h":167504093547,"f":8388609},{"e":631147,"m":{"r":65537,"p":[{"n":"value","p":631147}],"n":"add_Renamed","d":369003,"h":184683962731,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":631147}],"n":"remove_Renamed","d":369003,"h":188978930027,"f":285212673},"n":"Renamed","d":369003,"h":180388995435,"f":8388609}],"i":[1048615,57540609,1507367],"h":369003}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$$.System.IDisposable, $.$scp.System.ComponentModel.ISupportInitialize ]; }
            static get $fullName() { return `System.IO.FileSystemWatcher`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventArgs", ($self) => class RenamedEventArgs extends $.$sifw.System.IO.FileSystemEventArgs
        {
            $ctor$3(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name, /*string?*/ oldName)
            {
                super.$ctor$2(0, null, null);
                {
                }
                return this;
            }
            /*string */ get OldFullPath()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 565611;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":237931,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885467499,"f":50331649},"n":"OldFullPath","d":565611,"h":8590500203,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":21475402091,"f":50331649},"n":"OldName","d":565611,"h":17180434795,"f":2097153}],"c":[{"p":[{"n":"changeType","p":762219},{"n":"directory","p":1310721},{"n":"name","p":1310721},{"n":"oldName","p":1310721}],"n":".ctor","o":"$ctor$3","d":565611,"h":4295532907,"f":16777217}],"h":565611}; }
            static get $b() { return $.$sifw.System.IO.FileSystemEventArgs; }
            static get $fullName() { return `System.IO.RenamedEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.InternalBufferOverflowException", ($self) => class InternalBufferOverflowException extends $.$$.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 434539;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119537665,"h":434539}; }
            static get $b() { return $.$$.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.InternalBufferOverflowException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread"))