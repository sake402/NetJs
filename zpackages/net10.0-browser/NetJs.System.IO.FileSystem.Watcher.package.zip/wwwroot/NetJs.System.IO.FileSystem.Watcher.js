
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $scm, $so, $scp, $sris, $sto, $stt) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.FileSystem.Watcher", 
    {"h":43115,"f":"System.IO.FileSystem.Watcher","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$str("$sifw.System.IO.WaitForChangedResult", ($self) => class WaitForChangedResult extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WatcherChangeTypes */ set ChangeType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set Name(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set OldName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get TimedOut()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set TimedOut(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 698475;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":764011,"g":{"r":0,"d":0,"h":17180567659,"f":1},"s":{"r":0,"d":0,"h":21475534955,"f":1},"n":"ChangeType","d":698475,"h":12885600363,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065469547,"f":1},"s":{"r":0,"d":0,"h":34360436843,"f":1},"n":"Name","d":698475,"h":25770502251,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42950371435,"f":1},"s":{"r":0,"d":0,"h":47245338731,"f":1},"n":"OldName","d":698475,"h":38655404139,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835273323,"f":1},"s":{"r":0,"d":0,"h":60130240619,"f":1},"n":"TimedOut","d":698475,"h":51540306027,"f":1}],"l":[{"t":131073,"n":"_dummy","d":698475,"h":4295665771,"f":2},{"t":655361,"n":"_dummyPrimitive","d":698475,"h":8590633067,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":698475,"h":64425207915,"f":1}],"h":698475}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.WaitForChangedResult`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventHandler", ($self) => class ErrorEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$sifw.System.IO.ErrorEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 174187;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":108651}],"n":"Invoke","d":174187,"h":8590108779,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":108651},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":174187,"h":12885076075,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":174187,"h":17180043371,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":174187,"h":4295141483,"f":1}],"i":[57212929,113377281],"h":174187}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.ErrorEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventHandler", ($self) => class FileSystemEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$sifw.System.IO.FileSystemEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 305259;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":239723}],"n":"Invoke","d":305259,"h":8590239851,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":239723},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":305259,"h":12885207147,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":305259,"h":17180174443,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":305259,"h":4295272555,"f":1}],"i":[57212929,113377281],"h":305259}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.FileSystemEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventHandler", ($self) => class RenamedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$sifw.System.IO.RenamedEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 632939;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":567403}],"n":"Invoke","d":632939,"h":8590567531,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":567403},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":632939,"h":12885534827,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":632939,"h":17180502123,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":632939,"h":4295600235,"f":1}],"i":[57212929,113377281],"h":632939}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.RenamedEventHandler`; }
        });
        
        $asm.$str("$sifw.System.IO.NotifyFilters", ($self) => class NotifyFilters extends $.$spc.System.Enum
        {
            static FileName = 1;
            static DirectoryName = 2;
            static Attributes = 4;
            static Size = 8;
            static LastWrite = 16;
            static LastAccess = 32;
            static CreationTime = 64;
            static Security = 256;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FileName": 1n,
                    "DirectoryName": 2n,
                    "Attributes": 4n,
                    "Size": 8n,
                    "LastWrite": 16n,
                    "LastAccess": 32n,
                    "CreationTime": 64n,
                    "Security": 256n
                };
            }
            static $h = 501867;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":501867,"n":"FileName","d":501867,"h":4295469163,"f":33},{"t":501867,"n":"DirectoryName","d":501867,"h":8590436459,"f":33},{"t":501867,"n":"Attributes","d":501867,"h":12885403755,"f":33},{"t":501867,"n":"Size","d":501867,"h":17180371051,"f":33},{"t":501867,"n":"LastWrite","d":501867,"h":21475338347,"f":33},{"t":501867,"n":"LastAccess","d":501867,"h":25770305643,"f":33},{"t":501867,"n":"CreationTime","d":501867,"h":30065272939,"f":33},{"t":501867,"n":"Security","d":501867,"h":34360240235,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":501867,"h":38655207531,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":501867,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.NotifyFilters`; }
        });
        
        $asm.$str("$sifw.System.IO.WatcherChangeTypes", ($self) => class WatcherChangeTypes extends $.$spc.System.Enum
        {
            static Created = 1;
            static Deleted = 2;
            static Changed = 4;
            static Renamed = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Created": 1n,
                    "Deleted": 2n,
                    "Changed": 4n,
                    "Renamed": 8n,
                    "All": 15n
                };
            }
            static $h = 764011;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":764011,"n":"Created","d":764011,"h":4295731307,"f":33},{"t":764011,"n":"Deleted","d":764011,"h":8590698603,"f":33},{"t":764011,"n":"Changed","d":764011,"h":12885665899,"f":33},{"t":764011,"n":"Renamed","d":764011,"h":17180633195,"f":33},{"t":764011,"n":"All","d":764011,"h":21475600491,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":764011,"h":25770567787,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":764011,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.WatcherChangeTypes`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventArgs", ($self) => class ErrorEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*System.Exception*/ exception)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Exception */ GetException()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 108651;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"m":[{"r":47251457,"n":"GetException","d":108651,"h":8590043243,"f":129}],"c":[{"p":[{"n":"exception","p":47251457}],"n":".ctor","o":"$ctor$2","d":108651,"h":4295075947,"f":1}],"h":108651}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.IO.ErrorEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventArgs", ($self) => class FileSystemEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FullPath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 239723;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":764011,"g":{"r":0,"d":0,"h":12885141611,"f":1},"n":"ChangeType","d":239723,"h":8590174315,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21475076203,"f":1},"n":"FullPath","d":239723,"h":17180108907,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065010795,"f":1},"n":"Name","d":239723,"h":25770043499,"f":1}],"c":[{"p":[{"n":"changeType","p":764011},{"n":"directory","p":1310721},{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":239723,"h":4295207019,"f":1}],"h":239723}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.IO.FileSystemEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemWatcher", ($self) => class FileSystemWatcher extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ path)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*string*/ path, /*string*/ filter)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get EnableRaisingEvents()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Filter()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Filter(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.ObjectModel.Collection<string> */ get Filters()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IncludeSubdirectories()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IncludeSubdirectories(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InternalBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InternalBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ get NotifyFilter()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ set NotifyFilter(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Path()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Path(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ get Site()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ set Site(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.FileSystemEventHandler?*/ add_Changed(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Changed(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ add_Created(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Created(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ add_Deleted(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Deleted(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ add_Error(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ remove_Error(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ add_Renamed(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ remove_Renamed(value)
            {
            }
            /*void */ BeginInit()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ EndInit()
            {
            }
            /*void */ OnChanged(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnCreated(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnDeleted(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnError(/*System.IO.ErrorEventArgs*/ e)
            {
            }
            /*void */ OnRenamed(/*System.IO.RenamedEventArgs*/ e)
            {
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged(/*System.IO.WatcherChangeTypes*/ changeType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$1(/*System.IO.WatcherChangeTypes*/ changeType, /*int*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$2(/*System.IO.WatcherChangeTypes*/ changeType, /*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.BeginInit()
            System$ComponentModel$ISupportInitialize$BeginInit()
            {
                return this.BeginInit(...arguments);
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.EndInit()
            System$ComponentModel$ISupportInitialize$EndInit()
            {
                return this.EndInit(...arguments);
            }
            static $h = 370795;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475207275,"f":1},"s":{"r":0,"d":0,"h":25770174571,"f":1},"n":"EnableRaisingEvents","d":370795,"h":17180239979,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360109163,"f":1},"s":{"r":0,"d":0,"h":38655076459,"f":1},"n":"Filter","d":370795,"h":30065141867,"f":1},{"p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":47245011051,"f":1},"n":"Filters","d":370795,"h":42950043755,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55834945643,"f":1},"s":{"r":0,"d":0,"h":60129912939,"f":1},"n":"IncludeSubdirectories","d":370795,"h":51539978347,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":68719847531,"f":1},"s":{"r":0,"d":0,"h":73014814827,"f":1},"n":"InternalBufferSize","d":370795,"h":64424880235,"f":1},{"p":501867,"g":{"r":0,"d":0,"h":81604749419,"f":1},"s":{"r":0,"d":0,"h":85899716715,"f":1},"n":"NotifyFilter","d":370795,"h":77309782123,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94489651307,"f":1},"s":{"r":0,"d":0,"h":98784618603,"f":1},"n":"Path","d":370795,"h":90194684011,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.FSWPathEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":1441831,"g":{"r":0,"d":0,"h":107374553195,"f":32769},"s":{"r":0,"d":0,"h":111669520491,"f":32769},"n":"Site","d":370795,"h":103079585899,"f":32769},{"p":1572903,"g":{"r":0,"d":0,"h":120259455083,"f":1},"s":{"r":0,"d":0,"h":124554422379,"f":1},"n":"SynchronizingObject","d":370795,"h":115964487787,"f":1}],"m":[{"r":65537,"n":"BeginInit","d":370795,"h":193273899115,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":370795,"h":197568866411,"f":32772},{"r":65537,"n":"EndInit","d":370795,"h":201863833707,"f":1},{"r":65537,"p":[{"n":"e","p":239723}],"n":"OnChanged","d":370795,"h":206158801003,"f":4},{"r":65537,"p":[{"n":"e","p":239723}],"n":"OnCreated","d":370795,"h":210453768299,"f":4},{"r":65537,"p":[{"n":"e","p":239723}],"n":"OnDeleted","d":370795,"h":214748735595,"f":4},{"r":65537,"p":[{"n":"e","p":108651}],"n":"OnError","d":370795,"h":219043702891,"f":4},{"r":65537,"p":[{"n":"e","p":567403}],"n":"OnRenamed","d":370795,"h":223338670187,"f":4},{"r":698475,"p":[{"n":"changeType","p":764011}],"n":"WaitForChanged","d":370795,"h":227633637483,"f":1},{"r":698475,"p":[{"n":"changeType","p":764011},{"n":"timeout","p":655361}],"n":"WaitForChanged","o":"@$1","d":370795,"h":231928604779,"f":1},{"r":698475,"p":[{"n":"changeType","p":764011},{"n":"timeout","p":140705793}],"n":"WaitForChanged","o":"@$2","d":370795,"h":236223572075,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":370795,"h":4295338091,"f":1},{"p":[{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$4","d":370795,"h":8590305387,"f":1},{"p":[{"n":"path","p":1310721},{"n":"filter","p":1310721}],"n":".ctor","o":"$ctor$5","d":370795,"h":12885272683,"f":1}],"e":[{"e":305259,"m":{"r":65537,"p":[{"n":"value","p":305259}],"n":"add_Changed","d":370795,"h":133144356971,"f":1},"r":{"r":65537,"p":[{"n":"value","p":305259}],"n":"remove_Changed","d":370795,"h":137439324267,"f":1},"n":"Changed","d":370795,"h":128849389675,"f":1},{"e":305259,"m":{"r":65537,"p":[{"n":"value","p":305259}],"n":"add_Created","d":370795,"h":146029258859,"f":1},"r":{"r":65537,"p":[{"n":"value","p":305259}],"n":"remove_Created","d":370795,"h":150324226155,"f":1},"n":"Created","d":370795,"h":141734291563,"f":1},{"e":305259,"m":{"r":65537,"p":[{"n":"value","p":305259}],"n":"add_Deleted","d":370795,"h":158914160747,"f":1},"r":{"r":65537,"p":[{"n":"value","p":305259}],"n":"remove_Deleted","d":370795,"h":163209128043,"f":1},"n":"Deleted","d":370795,"h":154619193451,"f":1},{"e":174187,"m":{"r":65537,"p":[{"n":"value","p":174187}],"n":"add_Error","d":370795,"h":171799062635,"f":1},"r":{"r":65537,"p":[{"n":"value","p":174187}],"n":"remove_Error","d":370795,"h":176094029931,"f":1},"n":"Error","d":370795,"h":167504095339,"f":1},{"e":632939,"m":{"r":65537,"p":[{"n":"value","p":632939}],"n":"add_Renamed","d":370795,"h":184683964523,"f":1},"r":{"r":65537,"p":[{"n":"value","p":632939}],"n":"remove_Renamed","d":370795,"h":188978931819,"f":1},"n":"Renamed","d":370795,"h":180388997227,"f":1}],"i":[1048615,57540609,1507367],"h":370795}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable, $.$scp.System.ComponentModel.ISupportInitialize ]; }
            static get $fullName() { return `System.IO.FileSystemWatcher`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventArgs", ($self) => class RenamedEventArgs extends $.$sifw.System.IO.FileSystemEventArgs
        {
            $ctor$3(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name, /*string?*/ oldName)
            {
                super.$ctor$2(0, null, null);
                {
                }
                return this;
            }
            /*string */ get OldFullPath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 567403;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":239723,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885469291,"f":1},"n":"OldFullPath","d":567403,"h":8590501995,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21475403883,"f":1},"n":"OldName","d":567403,"h":17180436587,"f":1}],"c":[{"p":[{"n":"changeType","p":764011},{"n":"directory","p":1310721},{"n":"name","p":1310721},{"n":"oldName","p":1310721}],"n":".ctor","o":"$ctor$3","d":567403,"h":4295534699,"f":1}],"h":567403}; }
            static get $b() { return $.$sifw.System.IO.FileSystemEventArgs; }
            static get $fullName() { return `System.IO.RenamedEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.InternalBufferOverflowException", ($self) => class InternalBufferOverflowException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 436331;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":436331}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.InternalBufferOverflowException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread"))