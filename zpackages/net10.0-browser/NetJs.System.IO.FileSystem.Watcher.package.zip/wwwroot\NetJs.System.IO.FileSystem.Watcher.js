
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $sto, $stt, $sr, $scc, $scn, $scm, $so, $sris, $scp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.FileSystem.Watcher", 
    {"h":36389,"f":"System.IO.FileSystem.Watcher","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$str("$sifw.System.IO.WaitForChangedResult", ($self) => class WaitForChangedResult extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WatcherChangeTypes */ set ChangeType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set Name(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set OldName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get TimedOut()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set TimedOut(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 691749;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":757285,"g":{"r":0,"d":0,"h":17180560933,"f":1},"s":{"r":0,"d":0,"h":21475528229,"f":1},"n":"ChangeType","d":691749,"h":12885593637,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065462821,"f":1},"s":{"r":0,"d":0,"h":34360430117,"f":1},"n":"Name","d":691749,"h":25770495525,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42950364709,"f":1},"s":{"r":0,"d":0,"h":47245332005,"f":1},"n":"OldName","d":691749,"h":38655397413,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835266597,"f":1},"s":{"r":0,"d":0,"h":60130233893,"f":1},"n":"TimedOut","d":691749,"h":51540299301,"f":1}],"l":[{"t":131073,"n":"_dummy","d":691749,"h":4295659045,"f":2},{"t":655361,"n":"_dummyPrimitive","d":691749,"h":8590626341,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":691749,"h":64425201189,"f":1}],"h":691749}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.WaitForChangedResult`; }
        });
        
        $asm.$str("$sifw.System.IO.NotifyFilters", ($self) => class NotifyFilters extends $.$spc.System.Enum
        {
            static FileName = 1;
            static DirectoryName = 2;
            static Attributes = 4;
            static Size = 8;
            static LastWrite = 16;
            static LastAccess = 32;
            static CreationTime = 64;
            static Security = 256;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FileName": 1n,
                    "DirectoryName": 2n,
                    "Attributes": 4n,
                    "Size": 8n,
                    "LastWrite": 16n,
                    "LastAccess": 32n,
                    "CreationTime": 64n,
                    "Security": 256n
                };
            }
            static $h = 495141;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":495141,"n":"FileName","d":495141,"h":4295462437,"f":33},{"t":495141,"n":"DirectoryName","d":495141,"h":8590429733,"f":33},{"t":495141,"n":"Attributes","d":495141,"h":12885397029,"f":33},{"t":495141,"n":"Size","d":495141,"h":17180364325,"f":33},{"t":495141,"n":"LastWrite","d":495141,"h":21475331621,"f":33},{"t":495141,"n":"LastAccess","d":495141,"h":25770298917,"f":33},{"t":495141,"n":"CreationTime","d":495141,"h":30065266213,"f":33},{"t":495141,"n":"Security","d":495141,"h":34360233509,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":495141,"h":38655200805,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":495141,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.NotifyFilters`; }
        });
        
        $asm.$str("$sifw.System.IO.WatcherChangeTypes", ($self) => class WatcherChangeTypes extends $.$spc.System.Enum
        {
            static Created = 1;
            static Deleted = 2;
            static Changed = 4;
            static Renamed = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Created": 1n,
                    "Deleted": 2n,
                    "Changed": 4n,
                    "Renamed": 8n,
                    "All": 15n
                };
            }
            static $h = 757285;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":757285,"n":"Created","d":757285,"h":4295724581,"f":33},{"t":757285,"n":"Deleted","d":757285,"h":8590691877,"f":33},{"t":757285,"n":"Changed","d":757285,"h":12885659173,"f":33},{"t":757285,"n":"Renamed","d":757285,"h":17180626469,"f":33},{"t":757285,"n":"All","d":757285,"h":21475593765,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":757285,"h":25770561061,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":757285,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.WatcherChangeTypes`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventArgs", ($self) => class ErrorEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*System.Exception*/ exception)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Exception */ GetException()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 101925;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"m":[{"r":47185921,"n":"GetException","d":101925,"h":8590036517,"f":129}],"c":[{"p":[{"n":"exception","p":47185921}],"n":".ctor","o":"$ctor$2","d":101925,"h":4295069221,"f":1}],"h":101925}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.IO.ErrorEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventArgs", ($self) => class FileSystemEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FullPath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 232997;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":757285,"g":{"r":0,"d":0,"h":12885134885,"f":1},"n":"ChangeType","d":232997,"h":8590167589,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21475069477,"f":1},"n":"FullPath","d":232997,"h":17180102181,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065004069,"f":1},"n":"Name","d":232997,"h":25770036773,"f":1}],"c":[{"p":[{"n":"changeType","p":757285},{"n":"directory","p":1310721},{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":232997,"h":4295200293,"f":1}],"h":232997}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.IO.FileSystemEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventHandler", ($self) => class ErrorEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sifw.System.IO.ErrorEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 167461;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":101925}],"n":"Invoke","d":167461,"h":8590102053,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":101925},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":167461,"h":12885069349,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":167461,"h":17180036645,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":167461,"h":4295134757,"f":1}],"i":[57147393,113377281],"h":167461}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.ErrorEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventHandler", ($self) => class FileSystemEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sifw.System.IO.FileSystemEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 298533;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":232997}],"n":"Invoke","d":298533,"h":8590233125,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":232997},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":298533,"h":12885200421,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":298533,"h":17180167717,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":298533,"h":4295265829,"f":1}],"i":[57147393,113377281],"h":298533}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.FileSystemEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventHandler", ($self) => class RenamedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sifw.System.IO.RenamedEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 626213;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":560677}],"n":"Invoke","d":626213,"h":8590560805,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":560677},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":626213,"h":12885528101,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":626213,"h":17180495397,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":626213,"h":4295593509,"f":1}],"i":[57147393,113377281],"h":626213}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.RenamedEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemWatcher", ($self) => class FileSystemWatcher extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ path)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*string*/ path, /*string*/ filter)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get EnableRaisingEvents()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Filter()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Filter(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.ObjectModel.Collection<string> */ get Filters()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IncludeSubdirectories()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IncludeSubdirectories(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InternalBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InternalBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ get NotifyFilter()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ set NotifyFilter(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Path()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Path(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ get Site()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ set Site(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.FileSystemEventHandler?*/ Changed$add(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Changed$remove(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Created$add(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Created$remove(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Deleted$add(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Deleted$remove(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ Error$add(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ Error$remove(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ Renamed$add(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ Renamed$remove(value)
            {
            }
            /*void */ BeginInit()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ EndInit()
            {
            }
            /*void */ OnChanged(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnCreated(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnDeleted(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnError(/*System.IO.ErrorEventArgs*/ e)
            {
            }
            /*void */ OnRenamed(/*System.IO.RenamedEventArgs*/ e)
            {
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged(/*System.IO.WatcherChangeTypes*/ changeType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$1(/*System.IO.WatcherChangeTypes*/ changeType, /*int*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$2(/*System.IO.WatcherChangeTypes*/ changeType, /*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.BeginInit()
            System$ComponentModel$ISupportInitialize$BeginInit()
            {
                return this.BeginInit(...arguments);
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.EndInit()
            System$ComponentModel$ISupportInitialize$EndInit()
            {
                return this.EndInit(...arguments);
            }
            static $h = 364069;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475200549,"f":1},"s":{"r":0,"d":0,"h":25770167845,"f":1},"n":"EnableRaisingEvents","d":364069,"h":17180233253,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360102437,"f":1},"s":{"r":0,"d":0,"h":38655069733,"f":1},"n":"Filter","d":364069,"h":30065135141,"f":1},{"p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":47245004325,"f":1},"n":"Filters","d":364069,"h":42950037029,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55834938917,"f":1},"s":{"r":0,"d":0,"h":60129906213,"f":1},"n":"IncludeSubdirectories","d":364069,"h":51539971621,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":68719840805,"f":1},"s":{"r":0,"d":0,"h":73014808101,"f":1},"n":"InternalBufferSize","d":364069,"h":64424873509,"f":1},{"p":495141,"g":{"r":0,"d":0,"h":81604742693,"f":1},"s":{"r":0,"d":0,"h":85899709989,"f":1},"n":"NotifyFilter","d":364069,"h":77309775397,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94489644581,"f":1},"s":{"r":0,"d":0,"h":98784611877,"f":1},"n":"Path","d":364069,"h":90194677285,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.FSWPathEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":1441831,"g":{"r":0,"d":0,"h":107374546469,"f":32769},"s":{"r":0,"d":0,"h":111669513765,"f":32769},"n":"Site","d":364069,"h":103079579173,"f":32769},{"p":1572903,"g":{"r":0,"d":0,"h":120259448357,"f":1},"s":{"r":0,"d":0,"h":124554415653,"f":1},"n":"SynchronizingObject","d":364069,"h":115964481061,"f":1}],"m":[{"r":65537,"n":"BeginInit","d":364069,"h":193273892389,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":364069,"h":197568859685,"f":32772},{"r":65537,"n":"EndInit","d":364069,"h":201863826981,"f":1},{"r":65537,"p":[{"n":"e","p":232997}],"n":"OnChanged","d":364069,"h":206158794277,"f":4},{"r":65537,"p":[{"n":"e","p":232997}],"n":"OnCreated","d":364069,"h":210453761573,"f":4},{"r":65537,"p":[{"n":"e","p":232997}],"n":"OnDeleted","d":364069,"h":214748728869,"f":4},{"r":65537,"p":[{"n":"e","p":101925}],"n":"OnError","d":364069,"h":219043696165,"f":4},{"r":65537,"p":[{"n":"e","p":560677}],"n":"OnRenamed","d":364069,"h":223338663461,"f":4},{"r":691749,"p":[{"n":"changeType","p":757285}],"n":"WaitForChanged","d":364069,"h":227633630757,"f":1},{"r":691749,"p":[{"n":"changeType","p":757285},{"n":"timeout","p":655361}],"n":"WaitForChanged","o":"@$1","d":364069,"h":231928598053,"f":1},{"r":691749,"p":[{"n":"changeType","p":757285},{"n":"timeout","p":140705793}],"n":"WaitForChanged","o":"@$2","d":364069,"h":236223565349,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":364069,"h":4295331365,"f":1},{"p":[{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$4","d":364069,"h":8590298661,"f":1},{"p":[{"n":"path","p":1310721},{"n":"filter","p":1310721}],"n":".ctor","o":"$ctor$5","d":364069,"h":12885265957,"f":1}],"e":[{"e":298533,"m":{"r":65537,"p":[{"n":"value","p":298533}],"n":"add_Changed","d":364069,"h":133144350245,"f":1},"r":{"r":65537,"p":[{"n":"value","p":298533}],"n":"remove_Changed","d":364069,"h":137439317541,"f":1},"n":"Changed","d":364069,"h":128849382949,"f":1},{"e":298533,"m":{"r":65537,"p":[{"n":"value","p":298533}],"n":"add_Created","d":364069,"h":146029252133,"f":1},"r":{"r":65537,"p":[{"n":"value","p":298533}],"n":"remove_Created","d":364069,"h":150324219429,"f":1},"n":"Created","d":364069,"h":141734284837,"f":1},{"e":298533,"m":{"r":65537,"p":[{"n":"value","p":298533}],"n":"add_Deleted","d":364069,"h":158914154021,"f":1},"r":{"r":65537,"p":[{"n":"value","p":298533}],"n":"remove_Deleted","d":364069,"h":163209121317,"f":1},"n":"Deleted","d":364069,"h":154619186725,"f":1},{"e":167461,"m":{"r":65537,"p":[{"n":"value","p":167461}],"n":"add_Error","d":364069,"h":171799055909,"f":1},"r":{"r":65537,"p":[{"n":"value","p":167461}],"n":"remove_Error","d":364069,"h":176094023205,"f":1},"n":"Error","d":364069,"h":167504088613,"f":1},{"e":626213,"m":{"r":65537,"p":[{"n":"value","p":626213}],"n":"add_Renamed","d":364069,"h":184683957797,"f":1},"r":{"r":65537,"p":[{"n":"value","p":626213}],"n":"remove_Renamed","d":364069,"h":188978925093,"f":1},"n":"Renamed","d":364069,"h":180388990501,"f":1}],"i":[1048615,57475073,1507367],"h":364069}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable, $.$scp.System.ComponentModel.ISupportInitialize ]; }
            static get $fullName() { return `System.IO.FileSystemWatcher`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventArgs", ($self) => class RenamedEventArgs extends $.$sifw.System.IO.FileSystemEventArgs
        {
            $ctor$3(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name, /*string?*/ oldName)
            {
                super.$ctor$2(0, null, null);
                {
                }
                return this;
            }
            /*string */ get OldFullPath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 560677;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":232997,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885462565,"f":1},"n":"OldFullPath","d":560677,"h":8590495269,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21475397157,"f":1},"n":"OldName","d":560677,"h":17180429861,"f":1}],"c":[{"p":[{"n":"changeType","p":757285},{"n":"directory","p":1310721},{"n":"name","p":1310721},{"n":"oldName","p":1310721}],"n":".ctor","o":"$ctor$3","d":560677,"h":4295527973,"f":1}],"h":560677}; }
            static get $b() { return $.$sifw.System.IO.FileSystemEventArgs; }
            static get $fullName() { return `System.IO.RenamedEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.InternalBufferOverflowException", ($self) => class InternalBufferOverflowException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 429605;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":429605}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.InternalBufferOverflowException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.InteropServices", "NetJs.System.ComponentModel.Primitives"))