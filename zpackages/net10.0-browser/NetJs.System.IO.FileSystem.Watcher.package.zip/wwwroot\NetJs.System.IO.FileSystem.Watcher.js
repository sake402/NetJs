
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $sto, $stt, $sr, $scc, $scn, $scm, $so, $sris, $scp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.FileSystem.Watcher", 
    {"h":40323,"f":"System.IO.FileSystem.Watcher","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$str("$sifw.System.IO.WaitForChangedResult", ($self) => class WaitForChangedResult extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WatcherChangeTypes */ set ChangeType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set Name(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set OldName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get TimedOut()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set TimedOut(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 695683;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":761219,"g":{"r":0,"d":0,"h":17180564867,"f":1},"s":{"r":0,"d":0,"h":21475532163,"f":1},"n":"ChangeType","d":695683,"h":12885597571,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065466755,"f":1},"s":{"r":0,"d":0,"h":34360434051,"f":1},"n":"Name","d":695683,"h":25770499459,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42950368643,"f":1},"s":{"r":0,"d":0,"h":47245335939,"f":1},"n":"OldName","d":695683,"h":38655401347,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835270531,"f":1},"s":{"r":0,"d":0,"h":60130237827,"f":1},"n":"TimedOut","d":695683,"h":51540303235,"f":1}],"l":[{"t":131073,"n":"_dummy","d":695683,"h":4295662979,"f":2},{"t":655361,"n":"_dummyPrimitive","d":695683,"h":8590630275,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":695683,"h":64425205123,"f":1}],"h":695683}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.WaitForChangedResult`; }
        });
        
        $asm.$str("$sifw.System.IO.NotifyFilters", ($self) => class NotifyFilters extends $.$spc.System.Enum
        {
            static FileName = 1;
            static DirectoryName = 2;
            static Attributes = 4;
            static Size = 8;
            static LastWrite = 16;
            static LastAccess = 32;
            static CreationTime = 64;
            static Security = 256;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FileName": 1n,
                    "DirectoryName": 2n,
                    "Attributes": 4n,
                    "Size": 8n,
                    "LastWrite": 16n,
                    "LastAccess": 32n,
                    "CreationTime": 64n,
                    "Security": 256n
                };
            }
            static $h = 499075;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":499075,"n":"FileName","d":499075,"h":4295466371,"f":33},{"t":499075,"n":"DirectoryName","d":499075,"h":8590433667,"f":33},{"t":499075,"n":"Attributes","d":499075,"h":12885400963,"f":33},{"t":499075,"n":"Size","d":499075,"h":17180368259,"f":33},{"t":499075,"n":"LastWrite","d":499075,"h":21475335555,"f":33},{"t":499075,"n":"LastAccess","d":499075,"h":25770302851,"f":33},{"t":499075,"n":"CreationTime","d":499075,"h":30065270147,"f":33},{"t":499075,"n":"Security","d":499075,"h":34360237443,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":499075,"h":38655204739,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":499075,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.NotifyFilters`; }
        });
        
        $asm.$str("$sifw.System.IO.WatcherChangeTypes", ($self) => class WatcherChangeTypes extends $.$spc.System.Enum
        {
            static Created = 1;
            static Deleted = 2;
            static Changed = 4;
            static Renamed = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Created": 1n,
                    "Deleted": 2n,
                    "Changed": 4n,
                    "Renamed": 8n,
                    "All": 15n
                };
            }
            static $h = 761219;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":761219,"n":"Created","d":761219,"h":4295728515,"f":33},{"t":761219,"n":"Deleted","d":761219,"h":8590695811,"f":33},{"t":761219,"n":"Changed","d":761219,"h":12885663107,"f":33},{"t":761219,"n":"Renamed","d":761219,"h":17180630403,"f":33},{"t":761219,"n":"All","d":761219,"h":21475597699,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":761219,"h":25770564995,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":761219,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.WatcherChangeTypes`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventArgs", ($self) => class ErrorEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*System.Exception*/ exception)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Exception */ GetException()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 105859;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"m":[{"r":47185921,"n":"GetException","d":105859,"h":8590040451,"f":129}],"c":[{"p":[{"n":"exception","p":47185921}],"n":".ctor","o":"$ctor$2","d":105859,"h":4295073155,"f":1}],"h":105859}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.IO.ErrorEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventArgs", ($self) => class FileSystemEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FullPath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 236931;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":761219,"g":{"r":0,"d":0,"h":12885138819,"f":1},"n":"ChangeType","d":236931,"h":8590171523,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21475073411,"f":1},"n":"FullPath","d":236931,"h":17180106115,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065008003,"f":1},"n":"Name","d":236931,"h":25770040707,"f":1}],"c":[{"p":[{"n":"changeType","p":761219},{"n":"directory","p":1310721},{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":236931,"h":4295204227,"f":1}],"h":236931}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.IO.FileSystemEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventHandler", ($self) => class ErrorEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sifw.System.IO.ErrorEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 171395;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":105859}],"n":"Invoke","d":171395,"h":8590105987,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":105859},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":171395,"h":12885073283,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":171395,"h":17180040579,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":171395,"h":4295138691,"f":1}],"i":[57147393,113377281],"h":171395}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.ErrorEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventHandler", ($self) => class FileSystemEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sifw.System.IO.FileSystemEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 302467;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":236931}],"n":"Invoke","d":302467,"h":8590237059,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":236931},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":302467,"h":12885204355,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":302467,"h":17180171651,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":302467,"h":4295269763,"f":1}],"i":[57147393,113377281],"h":302467}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.FileSystemEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventHandler", ($self) => class RenamedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sifw.System.IO.RenamedEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 630147;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":564611}],"n":"Invoke","d":630147,"h":8590564739,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":564611},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":630147,"h":12885532035,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":630147,"h":17180499331,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":630147,"h":4295597443,"f":1}],"i":[57147393,113377281],"h":630147}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.RenamedEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemWatcher", ($self) => class FileSystemWatcher extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ path)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*string*/ path, /*string*/ filter)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get EnableRaisingEvents()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Filter()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Filter(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.ObjectModel.Collection<string> */ get Filters()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IncludeSubdirectories()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IncludeSubdirectories(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InternalBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InternalBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ get NotifyFilter()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ set NotifyFilter(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Path()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Path(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ get Site()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ set Site(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.FileSystemEventHandler?*/ add_Changed(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Changed(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ add_Created(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Created(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ add_Deleted(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Deleted(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ add_Error(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ remove_Error(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ add_Renamed(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ remove_Renamed(value)
            {
            }
            /*void */ BeginInit()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ EndInit()
            {
            }
            /*void */ OnChanged(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnCreated(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnDeleted(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnError(/*System.IO.ErrorEventArgs*/ e)
            {
            }
            /*void */ OnRenamed(/*System.IO.RenamedEventArgs*/ e)
            {
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged(/*System.IO.WatcherChangeTypes*/ changeType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$1(/*System.IO.WatcherChangeTypes*/ changeType, /*int*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$2(/*System.IO.WatcherChangeTypes*/ changeType, /*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.BeginInit()
            System$ComponentModel$ISupportInitialize$BeginInit()
            {
                return this.BeginInit(...arguments);
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.EndInit()
            System$ComponentModel$ISupportInitialize$EndInit()
            {
                return this.EndInit(...arguments);
            }
            static $h = 368003;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475204483,"f":1},"s":{"r":0,"d":0,"h":25770171779,"f":1},"n":"EnableRaisingEvents","d":368003,"h":17180237187,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360106371,"f":1},"s":{"r":0,"d":0,"h":38655073667,"f":1},"n":"Filter","d":368003,"h":30065139075,"f":1},{"p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":47245008259,"f":1},"n":"Filters","d":368003,"h":42950040963,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55834942851,"f":1},"s":{"r":0,"d":0,"h":60129910147,"f":1},"n":"IncludeSubdirectories","d":368003,"h":51539975555,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":68719844739,"f":1},"s":{"r":0,"d":0,"h":73014812035,"f":1},"n":"InternalBufferSize","d":368003,"h":64424877443,"f":1},{"p":499075,"g":{"r":0,"d":0,"h":81604746627,"f":1},"s":{"r":0,"d":0,"h":85899713923,"f":1},"n":"NotifyFilter","d":368003,"h":77309779331,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94489648515,"f":1},"s":{"r":0,"d":0,"h":98784615811,"f":1},"n":"Path","d":368003,"h":90194681219,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.FSWPathEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":1441831,"g":{"r":0,"d":0,"h":107374550403,"f":32769},"s":{"r":0,"d":0,"h":111669517699,"f":32769},"n":"Site","d":368003,"h":103079583107,"f":32769},{"p":1572903,"g":{"r":0,"d":0,"h":120259452291,"f":1},"s":{"r":0,"d":0,"h":124554419587,"f":1},"n":"SynchronizingObject","d":368003,"h":115964484995,"f":1}],"m":[{"r":65537,"n":"BeginInit","d":368003,"h":193273896323,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":368003,"h":197568863619,"f":32772},{"r":65537,"n":"EndInit","d":368003,"h":201863830915,"f":1},{"r":65537,"p":[{"n":"e","p":236931}],"n":"OnChanged","d":368003,"h":206158798211,"f":4},{"r":65537,"p":[{"n":"e","p":236931}],"n":"OnCreated","d":368003,"h":210453765507,"f":4},{"r":65537,"p":[{"n":"e","p":236931}],"n":"OnDeleted","d":368003,"h":214748732803,"f":4},{"r":65537,"p":[{"n":"e","p":105859}],"n":"OnError","d":368003,"h":219043700099,"f":4},{"r":65537,"p":[{"n":"e","p":564611}],"n":"OnRenamed","d":368003,"h":223338667395,"f":4},{"r":695683,"p":[{"n":"changeType","p":761219}],"n":"WaitForChanged","d":368003,"h":227633634691,"f":1},{"r":695683,"p":[{"n":"changeType","p":761219},{"n":"timeout","p":655361}],"n":"WaitForChanged","o":"@$1","d":368003,"h":231928601987,"f":1},{"r":695683,"p":[{"n":"changeType","p":761219},{"n":"timeout","p":140705793}],"n":"WaitForChanged","o":"@$2","d":368003,"h":236223569283,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":368003,"h":4295335299,"f":1},{"p":[{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$4","d":368003,"h":8590302595,"f":1},{"p":[{"n":"path","p":1310721},{"n":"filter","p":1310721}],"n":".ctor","o":"$ctor$5","d":368003,"h":12885269891,"f":1}],"e":[{"e":302467,"m":{"r":65537,"p":[{"n":"value","p":302467}],"n":"add_Changed","d":368003,"h":133144354179,"f":1},"r":{"r":65537,"p":[{"n":"value","p":302467}],"n":"remove_Changed","d":368003,"h":137439321475,"f":1},"n":"Changed","d":368003,"h":128849386883,"f":1},{"e":302467,"m":{"r":65537,"p":[{"n":"value","p":302467}],"n":"add_Created","d":368003,"h":146029256067,"f":1},"r":{"r":65537,"p":[{"n":"value","p":302467}],"n":"remove_Created","d":368003,"h":150324223363,"f":1},"n":"Created","d":368003,"h":141734288771,"f":1},{"e":302467,"m":{"r":65537,"p":[{"n":"value","p":302467}],"n":"add_Deleted","d":368003,"h":158914157955,"f":1},"r":{"r":65537,"p":[{"n":"value","p":302467}],"n":"remove_Deleted","d":368003,"h":163209125251,"f":1},"n":"Deleted","d":368003,"h":154619190659,"f":1},{"e":171395,"m":{"r":65537,"p":[{"n":"value","p":171395}],"n":"add_Error","d":368003,"h":171799059843,"f":1},"r":{"r":65537,"p":[{"n":"value","p":171395}],"n":"remove_Error","d":368003,"h":176094027139,"f":1},"n":"Error","d":368003,"h":167504092547,"f":1},{"e":630147,"m":{"r":65537,"p":[{"n":"value","p":630147}],"n":"add_Renamed","d":368003,"h":184683961731,"f":1},"r":{"r":65537,"p":[{"n":"value","p":630147}],"n":"remove_Renamed","d":368003,"h":188978929027,"f":1},"n":"Renamed","d":368003,"h":180388994435,"f":1}],"i":[1048615,57475073,1507367],"h":368003}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable, $.$scp.System.ComponentModel.ISupportInitialize ]; }
            static get $fullName() { return `System.IO.FileSystemWatcher`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventArgs", ($self) => class RenamedEventArgs extends $.$sifw.System.IO.FileSystemEventArgs
        {
            $ctor$3(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name, /*string?*/ oldName)
            {
                super.$ctor$2(0, null, null);
                {
                }
                return this;
            }
            /*string */ get OldFullPath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 564611;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":236931,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885466499,"f":1},"n":"OldFullPath","d":564611,"h":8590499203,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21475401091,"f":1},"n":"OldName","d":564611,"h":17180433795,"f":1}],"c":[{"p":[{"n":"changeType","p":761219},{"n":"directory","p":1310721},{"n":"name","p":1310721},{"n":"oldName","p":1310721}],"n":".ctor","o":"$ctor$3","d":564611,"h":4295531907,"f":1}],"h":564611}; }
            static get $b() { return $.$sifw.System.IO.FileSystemEventArgs; }
            static get $fullName() { return `System.IO.RenamedEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.InternalBufferOverflowException", ($self) => class InternalBufferOverflowException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 433539;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":433539}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.InternalBufferOverflowException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.InteropServices", "NetJs.System.ComponentModel.Primitives"))