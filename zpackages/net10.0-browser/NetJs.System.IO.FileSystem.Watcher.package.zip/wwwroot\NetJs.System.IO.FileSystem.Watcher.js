
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $sto, $stt, $sr, $scc, $scn, $scm, $so, $sris, $scp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.FileSystem.Watcher", 
    {"h":52560,"f":"System.IO.FileSystem.Watcher","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$str("$sifw.System.IO.WaitForChangedResult", ($self) => class WaitForChangedResult extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WatcherChangeTypes */ set ChangeType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set Name(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set OldName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get TimedOut()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set TimedOut(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 707920;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":773456,"g":{"r":0,"d":0,"h":17180577104,"f":1},"s":{"r":0,"d":0,"h":21475544400,"f":1},"n":"ChangeType","d":707920,"h":12885609808,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065478992,"f":1},"s":{"r":0,"d":0,"h":34360446288,"f":1},"n":"Name","d":707920,"h":25770511696,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42950380880,"f":1},"s":{"r":0,"d":0,"h":47245348176,"f":1},"n":"OldName","d":707920,"h":38655413584,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835282768,"f":1},"s":{"r":0,"d":0,"h":60130250064,"f":1},"n":"TimedOut","d":707920,"h":51540315472,"f":1}],"l":[{"t":131073,"n":"_dummy","d":707920,"h":4295675216,"f":2},{"t":655361,"n":"_dummyPrimitive","d":707920,"h":8590642512,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":707920,"h":64425217360,"f":1}],"h":707920}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.WaitForChangedResult`; }
        });
        
        $asm.$str("$sifw.System.IO.NotifyFilters", ($self) => class NotifyFilters extends $.$spc.System.Enum
        {
            static FileName = 1;
            static DirectoryName = 2;
            static Attributes = 4;
            static Size = 8;
            static LastWrite = 16;
            static LastAccess = 32;
            static CreationTime = 64;
            static Security = 256;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FileName": 1n,
                    "DirectoryName": 2n,
                    "Attributes": 4n,
                    "Size": 8n,
                    "LastWrite": 16n,
                    "LastAccess": 32n,
                    "CreationTime": 64n,
                    "Security": 256n
                };
            }
            static $h = 511312;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":511312,"n":"FileName","d":511312,"h":4295478608,"f":33},{"t":511312,"n":"DirectoryName","d":511312,"h":8590445904,"f":33},{"t":511312,"n":"Attributes","d":511312,"h":12885413200,"f":33},{"t":511312,"n":"Size","d":511312,"h":17180380496,"f":33},{"t":511312,"n":"LastWrite","d":511312,"h":21475347792,"f":33},{"t":511312,"n":"LastAccess","d":511312,"h":25770315088,"f":33},{"t":511312,"n":"CreationTime","d":511312,"h":30065282384,"f":33},{"t":511312,"n":"Security","d":511312,"h":34360249680,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":511312,"h":38655216976,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":511312,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.NotifyFilters`; }
        });
        
        $asm.$str("$sifw.System.IO.WatcherChangeTypes", ($self) => class WatcherChangeTypes extends $.$spc.System.Enum
        {
            static Created = 1;
            static Deleted = 2;
            static Changed = 4;
            static Renamed = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Created": 1n,
                    "Deleted": 2n,
                    "Changed": 4n,
                    "Renamed": 8n,
                    "All": 15n
                };
            }
            static $h = 773456;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":773456,"n":"Created","d":773456,"h":4295740752,"f":33},{"t":773456,"n":"Deleted","d":773456,"h":8590708048,"f":33},{"t":773456,"n":"Changed","d":773456,"h":12885675344,"f":33},{"t":773456,"n":"Renamed","d":773456,"h":17180642640,"f":33},{"t":773456,"n":"All","d":773456,"h":21475609936,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":773456,"h":25770577232,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":773456,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.WatcherChangeTypes`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventArgs", ($self) => class ErrorEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*System.Exception*/ exception)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Exception */ GetException()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 118096;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"m":[{"r":47185921,"n":"GetException","d":118096,"h":8590052688,"f":129}],"c":[{"p":[{"n":"exception","p":47185921}],"n":".ctor","o":"$ctor$2","d":118096,"h":4295085392,"f":1}],"h":118096}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.IO.ErrorEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventArgs", ($self) => class FileSystemEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FullPath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 249168;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":773456,"g":{"r":0,"d":0,"h":12885151056,"f":1},"n":"ChangeType","d":249168,"h":8590183760,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21475085648,"f":1},"n":"FullPath","d":249168,"h":17180118352,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065020240,"f":1},"n":"Name","d":249168,"h":25770052944,"f":1}],"c":[{"p":[{"n":"changeType","p":773456},{"n":"directory","p":1310721},{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":249168,"h":4295216464,"f":1}],"h":249168}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.IO.FileSystemEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventHandler", ($self) => class ErrorEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sifw.System.IO.ErrorEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 183632;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":118096}],"n":"Invoke","d":183632,"h":8590118224,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":118096},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":183632,"h":12885085520,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":183632,"h":17180052816,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":183632,"h":4295150928,"f":1}],"i":[57147393,113377281],"h":183632}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.ErrorEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventHandler", ($self) => class FileSystemEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sifw.System.IO.FileSystemEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 314704;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":249168}],"n":"Invoke","d":314704,"h":8590249296,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":249168},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":314704,"h":12885216592,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":314704,"h":17180183888,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":314704,"h":4295282000,"f":1}],"i":[57147393,113377281],"h":314704}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.FileSystemEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventHandler", ($self) => class RenamedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sifw.System.IO.RenamedEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 642384;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":576848}],"n":"Invoke","d":642384,"h":8590576976,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":576848},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":642384,"h":12885544272,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":642384,"h":17180511568,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":642384,"h":4295609680,"f":1}],"i":[57147393,113377281],"h":642384}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.RenamedEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemWatcher", ($self) => class FileSystemWatcher extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ path)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*string*/ path, /*string*/ filter)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get EnableRaisingEvents()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Filter()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Filter(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.ObjectModel.Collection<string> */ get Filters()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IncludeSubdirectories()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IncludeSubdirectories(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InternalBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InternalBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ get NotifyFilter()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ set NotifyFilter(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Path()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Path(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ get Site()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ set Site(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.FileSystemEventHandler?*/ Changed$add(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Changed$remove(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Created$add(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Created$remove(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Deleted$add(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Deleted$remove(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ Error$add(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ Error$remove(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ Renamed$add(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ Renamed$remove(value)
            {
            }
            /*void */ BeginInit()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ EndInit()
            {
            }
            /*void */ OnChanged(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnCreated(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnDeleted(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnError(/*System.IO.ErrorEventArgs*/ e)
            {
            }
            /*void */ OnRenamed(/*System.IO.RenamedEventArgs*/ e)
            {
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged(/*System.IO.WatcherChangeTypes*/ changeType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$1(/*System.IO.WatcherChangeTypes*/ changeType, /*int*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$2(/*System.IO.WatcherChangeTypes*/ changeType, /*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.BeginInit()
            System$ComponentModel$ISupportInitialize$BeginInit()
            {
                return this.BeginInit(...arguments);
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.EndInit()
            System$ComponentModel$ISupportInitialize$EndInit()
            {
                return this.EndInit(...arguments);
            }
            static $h = 380240;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475216720,"f":1},"s":{"r":0,"d":0,"h":25770184016,"f":1},"n":"EnableRaisingEvents","d":380240,"h":17180249424,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360118608,"f":1},"s":{"r":0,"d":0,"h":38655085904,"f":1},"n":"Filter","d":380240,"h":30065151312,"f":1},{"p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":47245020496,"f":1},"n":"Filters","d":380240,"h":42950053200,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55834955088,"f":1},"s":{"r":0,"d":0,"h":60129922384,"f":1},"n":"IncludeSubdirectories","d":380240,"h":51539987792,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":68719856976,"f":1},"s":{"r":0,"d":0,"h":73014824272,"f":1},"n":"InternalBufferSize","d":380240,"h":64424889680,"f":1},{"p":511312,"g":{"r":0,"d":0,"h":81604758864,"f":1},"s":{"r":0,"d":0,"h":85899726160,"f":1},"n":"NotifyFilter","d":380240,"h":77309791568,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94489660752,"f":1},"s":{"r":0,"d":0,"h":98784628048,"f":1},"n":"Path","d":380240,"h":90194693456,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.FSWPathEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":1441831,"g":{"r":0,"d":0,"h":107374562640,"f":32769},"s":{"r":0,"d":0,"h":111669529936,"f":32769},"n":"Site","d":380240,"h":103079595344,"f":32769},{"p":1572903,"g":{"r":0,"d":0,"h":120259464528,"f":1},"s":{"r":0,"d":0,"h":124554431824,"f":1},"n":"SynchronizingObject","d":380240,"h":115964497232,"f":1}],"m":[{"r":65537,"n":"BeginInit","d":380240,"h":193273908560,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":380240,"h":197568875856,"f":32772},{"r":65537,"n":"EndInit","d":380240,"h":201863843152,"f":1},{"r":65537,"p":[{"n":"e","p":249168}],"n":"OnChanged","d":380240,"h":206158810448,"f":4},{"r":65537,"p":[{"n":"e","p":249168}],"n":"OnCreated","d":380240,"h":210453777744,"f":4},{"r":65537,"p":[{"n":"e","p":249168}],"n":"OnDeleted","d":380240,"h":214748745040,"f":4},{"r":65537,"p":[{"n":"e","p":118096}],"n":"OnError","d":380240,"h":219043712336,"f":4},{"r":65537,"p":[{"n":"e","p":576848}],"n":"OnRenamed","d":380240,"h":223338679632,"f":4},{"r":707920,"p":[{"n":"changeType","p":773456}],"n":"WaitForChanged","d":380240,"h":227633646928,"f":1},{"r":707920,"p":[{"n":"changeType","p":773456},{"n":"timeout","p":655361}],"n":"WaitForChanged","o":"@$1","d":380240,"h":231928614224,"f":1},{"r":707920,"p":[{"n":"changeType","p":773456},{"n":"timeout","p":140705793}],"n":"WaitForChanged","o":"@$2","d":380240,"h":236223581520,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":380240,"h":4295347536,"f":1},{"p":[{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$4","d":380240,"h":8590314832,"f":1},{"p":[{"n":"path","p":1310721},{"n":"filter","p":1310721}],"n":".ctor","o":"$ctor$5","d":380240,"h":12885282128,"f":1}],"e":[{"e":314704,"m":{"r":65537,"p":[{"n":"value","p":314704}],"n":"add_Changed","d":380240,"h":133144366416,"f":1},"r":{"r":65537,"p":[{"n":"value","p":314704}],"n":"remove_Changed","d":380240,"h":137439333712,"f":1},"n":"Changed","d":380240,"h":128849399120,"f":1},{"e":314704,"m":{"r":65537,"p":[{"n":"value","p":314704}],"n":"add_Created","d":380240,"h":146029268304,"f":1},"r":{"r":65537,"p":[{"n":"value","p":314704}],"n":"remove_Created","d":380240,"h":150324235600,"f":1},"n":"Created","d":380240,"h":141734301008,"f":1},{"e":314704,"m":{"r":65537,"p":[{"n":"value","p":314704}],"n":"add_Deleted","d":380240,"h":158914170192,"f":1},"r":{"r":65537,"p":[{"n":"value","p":314704}],"n":"remove_Deleted","d":380240,"h":163209137488,"f":1},"n":"Deleted","d":380240,"h":154619202896,"f":1},{"e":183632,"m":{"r":65537,"p":[{"n":"value","p":183632}],"n":"add_Error","d":380240,"h":171799072080,"f":1},"r":{"r":65537,"p":[{"n":"value","p":183632}],"n":"remove_Error","d":380240,"h":176094039376,"f":1},"n":"Error","d":380240,"h":167504104784,"f":1},{"e":642384,"m":{"r":65537,"p":[{"n":"value","p":642384}],"n":"add_Renamed","d":380240,"h":184683973968,"f":1},"r":{"r":65537,"p":[{"n":"value","p":642384}],"n":"remove_Renamed","d":380240,"h":188978941264,"f":1},"n":"Renamed","d":380240,"h":180389006672,"f":1}],"i":[1048615,57475073,1507367],"h":380240}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable, $.$scp.System.ComponentModel.ISupportInitialize ]; }
            static get $fullName() { return `System.IO.FileSystemWatcher`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventArgs", ($self) => class RenamedEventArgs extends $.$sifw.System.IO.FileSystemEventArgs
        {
            $ctor$3(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name, /*string?*/ oldName)
            {
                super.$ctor$2(0, null, null);
                {
                }
                return this;
            }
            /*string */ get OldFullPath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 576848;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":249168,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885478736,"f":1},"n":"OldFullPath","d":576848,"h":8590511440,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21475413328,"f":1},"n":"OldName","d":576848,"h":17180446032,"f":1}],"c":[{"p":[{"n":"changeType","p":773456},{"n":"directory","p":1310721},{"n":"name","p":1310721},{"n":"oldName","p":1310721}],"n":".ctor","o":"$ctor$3","d":576848,"h":4295544144,"f":1}],"h":576848}; }
            static get $b() { return $.$sifw.System.IO.FileSystemEventArgs; }
            static get $fullName() { return `System.IO.RenamedEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.InternalBufferOverflowException", ($self) => class InternalBufferOverflowException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 445776;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":445776}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.InternalBufferOverflowException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.InteropServices", "NetJs.System.ComponentModel.Primitives"))