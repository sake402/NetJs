
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $scm, $so, $scp, $sris, $sto, $stt) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.FileSystem.Watcher", 
    {"h":39083,"f":"System.IO.FileSystem.Watcher","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$str("$sifw.System.IO.WaitForChangedResult", ($self) => class WaitForChangedResult extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WatcherChangeTypes */ set ChangeType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set Name(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set OldName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get TimedOut()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set TimedOut(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 694443;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":759979,"g":{"r":0,"d":0,"h":17180563627,"f":1},"s":{"r":0,"d":0,"h":21475530923,"f":1},"n":"ChangeType","d":694443,"h":12885596331,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065465515,"f":1},"s":{"r":0,"d":0,"h":34360432811,"f":1},"n":"Name","d":694443,"h":25770498219,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42950367403,"f":1},"s":{"r":0,"d":0,"h":47245334699,"f":1},"n":"OldName","d":694443,"h":38655400107,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835269291,"f":1},"s":{"r":0,"d":0,"h":60130236587,"f":1},"n":"TimedOut","d":694443,"h":51540301995,"f":1}],"l":[{"t":131073,"n":"_dummy","d":694443,"h":4295661739,"f":2},{"t":655361,"n":"_dummyPrimitive","d":694443,"h":8590629035,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":694443,"h":64425203883,"f":1}],"h":694443}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.WaitForChangedResult`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventHandler", ($self) => class ErrorEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$sifw.System.IO.ErrorEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 170155;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":104619}],"n":"Invoke","d":170155,"h":8590104747,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":104619},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":170155,"h":12885072043,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":170155,"h":17180039339,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":170155,"h":4295137451,"f":1}],"i":[57212929,113377281],"h":170155}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.ErrorEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventHandler", ($self) => class FileSystemEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$sifw.System.IO.FileSystemEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 301227;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":235691}],"n":"Invoke","d":301227,"h":8590235819,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":235691},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":301227,"h":12885203115,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":301227,"h":17180170411,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":301227,"h":4295268523,"f":1}],"i":[57212929,113377281],"h":301227}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.FileSystemEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventHandler", ($self) => class RenamedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$sifw.System.IO.RenamedEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 628907;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":563371}],"n":"Invoke","d":628907,"h":8590563499,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":563371},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":628907,"h":12885530795,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":628907,"h":17180498091,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":628907,"h":4295596203,"f":1}],"i":[57212929,113377281],"h":628907}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.RenamedEventHandler`; }
        });
        
        $asm.$str("$sifw.System.IO.NotifyFilters", ($self) => class NotifyFilters extends $.$spc.System.Enum
        {
            static FileName = 1;
            static DirectoryName = 2;
            static Attributes = 4;
            static Size = 8;
            static LastWrite = 16;
            static LastAccess = 32;
            static CreationTime = 64;
            static Security = 256;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FileName": 1n,
                    "DirectoryName": 2n,
                    "Attributes": 4n,
                    "Size": 8n,
                    "LastWrite": 16n,
                    "LastAccess": 32n,
                    "CreationTime": 64n,
                    "Security": 256n
                };
            }
            static $h = 497835;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":497835,"n":"FileName","d":497835,"h":4295465131,"f":33},{"t":497835,"n":"DirectoryName","d":497835,"h":8590432427,"f":33},{"t":497835,"n":"Attributes","d":497835,"h":12885399723,"f":33},{"t":497835,"n":"Size","d":497835,"h":17180367019,"f":33},{"t":497835,"n":"LastWrite","d":497835,"h":21475334315,"f":33},{"t":497835,"n":"LastAccess","d":497835,"h":25770301611,"f":33},{"t":497835,"n":"CreationTime","d":497835,"h":30065268907,"f":33},{"t":497835,"n":"Security","d":497835,"h":34360236203,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":497835,"h":38655203499,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":497835,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.NotifyFilters`; }
        });
        
        $asm.$str("$sifw.System.IO.WatcherChangeTypes", ($self) => class WatcherChangeTypes extends $.$spc.System.Enum
        {
            static Created = 1;
            static Deleted = 2;
            static Changed = 4;
            static Renamed = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Created": 1n,
                    "Deleted": 2n,
                    "Changed": 4n,
                    "Renamed": 8n,
                    "All": 15n
                };
            }
            static $h = 759979;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":759979,"n":"Created","d":759979,"h":4295727275,"f":33},{"t":759979,"n":"Deleted","d":759979,"h":8590694571,"f":33},{"t":759979,"n":"Changed","d":759979,"h":12885661867,"f":33},{"t":759979,"n":"Renamed","d":759979,"h":17180629163,"f":33},{"t":759979,"n":"All","d":759979,"h":21475596459,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":759979,"h":25770563755,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":759979,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.WatcherChangeTypes`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventArgs", ($self) => class ErrorEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*System.Exception*/ exception)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Exception */ GetException()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 104619;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"m":[{"r":47251457,"n":"GetException","d":104619,"h":8590039211,"f":129}],"c":[{"p":[{"n":"exception","p":47251457}],"n":".ctor","o":"$ctor$2","d":104619,"h":4295071915,"f":1}],"h":104619}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.IO.ErrorEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventArgs", ($self) => class FileSystemEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FullPath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 235691;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":759979,"g":{"r":0,"d":0,"h":12885137579,"f":1},"n":"ChangeType","d":235691,"h":8590170283,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21475072171,"f":1},"n":"FullPath","d":235691,"h":17180104875,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065006763,"f":1},"n":"Name","d":235691,"h":25770039467,"f":1}],"c":[{"p":[{"n":"changeType","p":759979},{"n":"directory","p":1310721},{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":235691,"h":4295202987,"f":1}],"h":235691}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.IO.FileSystemEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemWatcher", ($self) => class FileSystemWatcher extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ path)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*string*/ path, /*string*/ filter)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get EnableRaisingEvents()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Filter()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Filter(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.ObjectModel.Collection<string> */ get Filters()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IncludeSubdirectories()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IncludeSubdirectories(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InternalBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InternalBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ get NotifyFilter()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ set NotifyFilter(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Path()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Path(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ get Site()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ set Site(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.FileSystemEventHandler?*/ add_Changed(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Changed(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ add_Created(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Created(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ add_Deleted(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ remove_Deleted(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ add_Error(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ remove_Error(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ add_Renamed(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ remove_Renamed(value)
            {
            }
            /*void */ BeginInit()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ EndInit()
            {
            }
            /*void */ OnChanged(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnCreated(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnDeleted(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnError(/*System.IO.ErrorEventArgs*/ e)
            {
            }
            /*void */ OnRenamed(/*System.IO.RenamedEventArgs*/ e)
            {
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged(/*System.IO.WatcherChangeTypes*/ changeType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$1(/*System.IO.WatcherChangeTypes*/ changeType, /*int*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$2(/*System.IO.WatcherChangeTypes*/ changeType, /*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.BeginInit()
            System$ComponentModel$ISupportInitialize$BeginInit()
            {
                return this.BeginInit(...arguments);
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.EndInit()
            System$ComponentModel$ISupportInitialize$EndInit()
            {
                return this.EndInit(...arguments);
            }
            static $h = 366763;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475203243,"f":1},"s":{"r":0,"d":0,"h":25770170539,"f":1},"n":"EnableRaisingEvents","d":366763,"h":17180235947,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360105131,"f":1},"s":{"r":0,"d":0,"h":38655072427,"f":1},"n":"Filter","d":366763,"h":30065137835,"f":1},{"p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":47245007019,"f":1},"n":"Filters","d":366763,"h":42950039723,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55834941611,"f":1},"s":{"r":0,"d":0,"h":60129908907,"f":1},"n":"IncludeSubdirectories","d":366763,"h":51539974315,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":68719843499,"f":1},"s":{"r":0,"d":0,"h":73014810795,"f":1},"n":"InternalBufferSize","d":366763,"h":64424876203,"f":1},{"p":497835,"g":{"r":0,"d":0,"h":81604745387,"f":1},"s":{"r":0,"d":0,"h":85899712683,"f":1},"n":"NotifyFilter","d":366763,"h":77309778091,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94489647275,"f":1},"s":{"r":0,"d":0,"h":98784614571,"f":1},"n":"Path","d":366763,"h":90194679979,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.FSWPathEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":1441831,"g":{"r":0,"d":0,"h":107374549163,"f":32769},"s":{"r":0,"d":0,"h":111669516459,"f":32769},"n":"Site","d":366763,"h":103079581867,"f":32769},{"p":1572903,"g":{"r":0,"d":0,"h":120259451051,"f":1},"s":{"r":0,"d":0,"h":124554418347,"f":1},"n":"SynchronizingObject","d":366763,"h":115964483755,"f":1}],"m":[{"r":65537,"n":"BeginInit","d":366763,"h":193273895083,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":366763,"h":197568862379,"f":32772},{"r":65537,"n":"EndInit","d":366763,"h":201863829675,"f":1},{"r":65537,"p":[{"n":"e","p":235691}],"n":"OnChanged","d":366763,"h":206158796971,"f":4},{"r":65537,"p":[{"n":"e","p":235691}],"n":"OnCreated","d":366763,"h":210453764267,"f":4},{"r":65537,"p":[{"n":"e","p":235691}],"n":"OnDeleted","d":366763,"h":214748731563,"f":4},{"r":65537,"p":[{"n":"e","p":104619}],"n":"OnError","d":366763,"h":219043698859,"f":4},{"r":65537,"p":[{"n":"e","p":563371}],"n":"OnRenamed","d":366763,"h":223338666155,"f":4},{"r":694443,"p":[{"n":"changeType","p":759979}],"n":"WaitForChanged","d":366763,"h":227633633451,"f":1},{"r":694443,"p":[{"n":"changeType","p":759979},{"n":"timeout","p":655361}],"n":"WaitForChanged","o":"@$1","d":366763,"h":231928600747,"f":1},{"r":694443,"p":[{"n":"changeType","p":759979},{"n":"timeout","p":140705793}],"n":"WaitForChanged","o":"@$2","d":366763,"h":236223568043,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":366763,"h":4295334059,"f":1},{"p":[{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$4","d":366763,"h":8590301355,"f":1},{"p":[{"n":"path","p":1310721},{"n":"filter","p":1310721}],"n":".ctor","o":"$ctor$5","d":366763,"h":12885268651,"f":1}],"e":[{"e":301227,"m":{"r":65537,"p":[{"n":"value","p":301227}],"n":"add_Changed","d":366763,"h":133144352939,"f":1},"r":{"r":65537,"p":[{"n":"value","p":301227}],"n":"remove_Changed","d":366763,"h":137439320235,"f":1},"n":"Changed","d":366763,"h":128849385643,"f":1},{"e":301227,"m":{"r":65537,"p":[{"n":"value","p":301227}],"n":"add_Created","d":366763,"h":146029254827,"f":1},"r":{"r":65537,"p":[{"n":"value","p":301227}],"n":"remove_Created","d":366763,"h":150324222123,"f":1},"n":"Created","d":366763,"h":141734287531,"f":1},{"e":301227,"m":{"r":65537,"p":[{"n":"value","p":301227}],"n":"add_Deleted","d":366763,"h":158914156715,"f":1},"r":{"r":65537,"p":[{"n":"value","p":301227}],"n":"remove_Deleted","d":366763,"h":163209124011,"f":1},"n":"Deleted","d":366763,"h":154619189419,"f":1},{"e":170155,"m":{"r":65537,"p":[{"n":"value","p":170155}],"n":"add_Error","d":366763,"h":171799058603,"f":1},"r":{"r":65537,"p":[{"n":"value","p":170155}],"n":"remove_Error","d":366763,"h":176094025899,"f":1},"n":"Error","d":366763,"h":167504091307,"f":1},{"e":628907,"m":{"r":65537,"p":[{"n":"value","p":628907}],"n":"add_Renamed","d":366763,"h":184683960491,"f":1},"r":{"r":65537,"p":[{"n":"value","p":628907}],"n":"remove_Renamed","d":366763,"h":188978927787,"f":1},"n":"Renamed","d":366763,"h":180388993195,"f":1}],"i":[1048615,57540609,1507367],"h":366763}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable, $.$scp.System.ComponentModel.ISupportInitialize ]; }
            static get $fullName() { return `System.IO.FileSystemWatcher`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventArgs", ($self) => class RenamedEventArgs extends $.$sifw.System.IO.FileSystemEventArgs
        {
            $ctor$3(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name, /*string?*/ oldName)
            {
                super.$ctor$2(0, null, null);
                {
                }
                return this;
            }
            /*string */ get OldFullPath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 563371;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":235691,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885465259,"f":1},"n":"OldFullPath","d":563371,"h":8590497963,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21475399851,"f":1},"n":"OldName","d":563371,"h":17180432555,"f":1}],"c":[{"p":[{"n":"changeType","p":759979},{"n":"directory","p":1310721},{"n":"name","p":1310721},{"n":"oldName","p":1310721}],"n":".ctor","o":"$ctor$3","d":563371,"h":4295530667,"f":1}],"h":563371}; }
            static get $b() { return $.$sifw.System.IO.FileSystemEventArgs; }
            static get $fullName() { return `System.IO.RenamedEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.InternalBufferOverflowException", ($self) => class InternalBufferOverflowException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 432299;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":432299}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.InternalBufferOverflowException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread"))