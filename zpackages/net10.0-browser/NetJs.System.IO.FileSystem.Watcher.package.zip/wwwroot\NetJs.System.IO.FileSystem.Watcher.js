
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $sto, $stt, $sr, $scc, $scn, $scm, $so, $sris, $scp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.FileSystem.Watcher", 
    {"h":52771,"f":"System.IO.FileSystem.Watcher","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.FileSystem.Watcher","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$str("$sifw.System.IO.WaitForChangedResult", ($self) => class WaitForChangedResult extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WatcherChangeTypes */ set ChangeType(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set Name(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set OldName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get TimedOut()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set TimedOut(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 708131;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":773667,"g":{"r":0,"d":0,"h":17180577315,"f":1},"s":{"r":0,"d":0,"h":21475544611,"f":1},"n":"ChangeType","d":708131,"h":12885610019,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065479203,"f":1},"s":{"r":0,"d":0,"h":34360446499,"f":1},"n":"Name","d":708131,"h":25770511907,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42950381091,"f":1},"s":{"r":0,"d":0,"h":47245348387,"f":1},"n":"OldName","d":708131,"h":38655413795,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55835282979,"f":1},"s":{"r":0,"d":0,"h":60130250275,"f":1},"n":"TimedOut","d":708131,"h":51540315683,"f":1}],"l":[{"t":131073,"n":"_dummy","d":708131,"h":4295675427,"f":2},{"t":655361,"n":"_dummyPrimitive","d":708131,"h":8590642723,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":708131,"h":64425217571,"f":1}],"h":708131}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.WaitForChangedResult`; }
        });
        
        $asm.$str("$sifw.System.IO.NotifyFilters", ($self) => class NotifyFilters extends $.$spc.System.Enum
        {
            static FileName = 1;
            static DirectoryName = 2;
            static Attributes = 4;
            static Size = 8;
            static LastWrite = 16;
            static LastAccess = 32;
            static CreationTime = 64;
            static Security = 256;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "FileName": 1n,
                    "DirectoryName": 2n,
                    "Attributes": 4n,
                    "Size": 8n,
                    "LastWrite": 16n,
                    "LastAccess": 32n,
                    "CreationTime": 64n,
                    "Security": 256n
                };
            }
            static $h = 511523;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":511523,"n":"FileName","d":511523,"h":4295478819,"f":33},{"t":511523,"n":"DirectoryName","d":511523,"h":8590446115,"f":33},{"t":511523,"n":"Attributes","d":511523,"h":12885413411,"f":33},{"t":511523,"n":"Size","d":511523,"h":17180380707,"f":33},{"t":511523,"n":"LastWrite","d":511523,"h":21475348003,"f":33},{"t":511523,"n":"LastAccess","d":511523,"h":25770315299,"f":33},{"t":511523,"n":"CreationTime","d":511523,"h":30065282595,"f":33},{"t":511523,"n":"Security","d":511523,"h":34360249891,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":511523,"h":38655217187,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":511523,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.NotifyFilters`; }
        });
        
        $asm.$str("$sifw.System.IO.WatcherChangeTypes", ($self) => class WatcherChangeTypes extends $.$spc.System.Enum
        {
            static Created = 1;
            static Deleted = 2;
            static Changed = 4;
            static Renamed = 8;
            static All = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Created": 1n,
                    "Deleted": 2n,
                    "Changed": 4n,
                    "Renamed": 8n,
                    "All": 15n
                };
            }
            static $h = 773667;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":773667,"n":"Created","d":773667,"h":4295740963,"f":33},{"t":773667,"n":"Deleted","d":773667,"h":8590708259,"f":33},{"t":773667,"n":"Changed","d":773667,"h":12885675555,"f":33},{"t":773667,"n":"Renamed","d":773667,"h":17180642851,"f":33},{"t":773667,"n":"All","d":773667,"h":21475610147,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":773667,"h":25770577443,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":773667,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.WatcherChangeTypes`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventArgs", ($self) => class ErrorEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*System.Exception*/ exception)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Exception */ GetException()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 118307;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"m":[{"r":47185921,"n":"GetException","d":118307,"h":8590052899,"f":129}],"c":[{"p":[{"n":"exception","p":47185921}],"n":".ctor","o":"$ctor$2","d":118307,"h":4295085603,"f":1}],"h":118307}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.IO.ErrorEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventArgs", ($self) => class FileSystemEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.IO.WatcherChangeTypes */ get ChangeType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FullPath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 249379;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":773667,"g":{"r":0,"d":0,"h":12885151267,"f":1},"n":"ChangeType","d":249379,"h":8590183971,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21475085859,"f":1},"n":"FullPath","d":249379,"h":17180118563,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065020451,"f":1},"n":"Name","d":249379,"h":25770053155,"f":1}],"c":[{"p":[{"n":"changeType","p":773667},{"n":"directory","p":1310721},{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":249379,"h":4295216675,"f":1}],"h":249379}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.IO.FileSystemEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.ErrorEventHandler", ($self) => class ErrorEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sifw.System.IO.ErrorEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 183843;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":118307}],"n":"Invoke","d":183843,"h":8590118435,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":118307},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":183843,"h":12885085731,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":183843,"h":17180053027,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":183843,"h":4295151139,"f":1}],"i":[57147393,113377281],"h":183843}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.ErrorEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemEventHandler", ($self) => class FileSystemEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sifw.System.IO.FileSystemEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 314915;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":249379}],"n":"Invoke","d":314915,"h":8590249507,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":249379},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":314915,"h":12885216803,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":314915,"h":17180184099,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":314915,"h":4295282211,"f":1}],"i":[57147393,113377281],"h":314915}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.FileSystemEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventHandler", ($self) => class RenamedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sifw.System.IO.RenamedEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 642595;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":577059}],"n":"Invoke","d":642595,"h":8590577187,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":577059},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":642595,"h":12885544483,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":642595,"h":17180511779,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":642595,"h":4295609891,"f":1}],"i":[57147393,113377281],"h":642595}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.RenamedEventHandler`; }
        });
        
        $asm.$cls("$sifw.System.IO.FileSystemWatcher", ($self) => class FileSystemWatcher extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ path)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*string*/ path, /*string*/ filter)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get EnableRaisingEvents()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Filter()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Filter(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.ObjectModel.Collection<string> */ get Filters()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IncludeSubdirectories()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IncludeSubdirectories(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InternalBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InternalBufferSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ get NotifyFilter()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.NotifyFilters */ set NotifyFilter(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Path()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Path(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ get Site()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISite? */ set Site(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.FileSystemEventHandler?*/ Changed$add(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Changed$remove(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Created$add(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Created$remove(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Deleted$add(value)
            {
            }
            /*System.IO.FileSystemEventHandler?*/ Deleted$remove(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ Error$add(value)
            {
            }
            /*System.IO.ErrorEventHandler?*/ Error$remove(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ Renamed$add(value)
            {
            }
            /*System.IO.RenamedEventHandler?*/ Renamed$remove(value)
            {
            }
            /*void */ BeginInit()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ EndInit()
            {
            }
            /*void */ OnChanged(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnCreated(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnDeleted(/*System.IO.FileSystemEventArgs*/ e)
            {
            }
            /*void */ OnError(/*System.IO.ErrorEventArgs*/ e)
            {
            }
            /*void */ OnRenamed(/*System.IO.RenamedEventArgs*/ e)
            {
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged(/*System.IO.WatcherChangeTypes*/ changeType)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$1(/*System.IO.WatcherChangeTypes*/ changeType, /*int*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.WaitForChangedResult */ WaitForChanged$2(/*System.IO.WatcherChangeTypes*/ changeType, /*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.BeginInit()
            System$ComponentModel$ISupportInitialize$BeginInit()
            {
                return this.BeginInit(...arguments);
            }
            //Generated interface implemetation for System.ComponentModel.ISupportInitialize.EndInit()
            System$ComponentModel$ISupportInitialize$EndInit()
            {
                return this.EndInit(...arguments);
            }
            static $h = 380451;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475216931,"f":1},"s":{"r":0,"d":0,"h":25770184227,"f":1},"n":"EnableRaisingEvents","d":380451,"h":17180249635,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360118819,"f":1},"s":{"r":0,"d":0,"h":38655086115,"f":1},"n":"Filter","d":380451,"h":30065151523,"f":1},{"p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":47245020707,"f":1},"n":"Filters","d":380451,"h":42950053411,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55834955299,"f":1},"s":{"r":0,"d":0,"h":60129922595,"f":1},"n":"IncludeSubdirectories","d":380451,"h":51539988003,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":68719857187,"f":1},"s":{"r":0,"d":0,"h":73014824483,"f":1},"n":"InternalBufferSize","d":380451,"h":64424889891,"f":1},{"p":511523,"g":{"r":0,"d":0,"h":81604759075,"f":1},"s":{"r":0,"d":0,"h":85899726371,"f":1},"n":"NotifyFilter","d":380451,"h":77309791779,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94489660963,"f":1},"s":{"r":0,"d":0,"h":98784628259,"f":1},"n":"Path","d":380451,"h":90194693667,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.FSWPathEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":1441831,"g":{"r":0,"d":0,"h":107374562851,"f":32769},"s":{"r":0,"d":0,"h":111669530147,"f":32769},"n":"Site","d":380451,"h":103079595555,"f":32769},{"p":1572903,"g":{"r":0,"d":0,"h":120259464739,"f":1},"s":{"r":0,"d":0,"h":124554432035,"f":1},"n":"SynchronizingObject","d":380451,"h":115964497443,"f":1}],"m":[{"r":65537,"n":"BeginInit","d":380451,"h":193273908771,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":380451,"h":197568876067,"f":32772},{"r":65537,"n":"EndInit","d":380451,"h":201863843363,"f":1},{"r":65537,"p":[{"n":"e","p":249379}],"n":"OnChanged","d":380451,"h":206158810659,"f":4},{"r":65537,"p":[{"n":"e","p":249379}],"n":"OnCreated","d":380451,"h":210453777955,"f":4},{"r":65537,"p":[{"n":"e","p":249379}],"n":"OnDeleted","d":380451,"h":214748745251,"f":4},{"r":65537,"p":[{"n":"e","p":118307}],"n":"OnError","d":380451,"h":219043712547,"f":4},{"r":65537,"p":[{"n":"e","p":577059}],"n":"OnRenamed","d":380451,"h":223338679843,"f":4},{"r":708131,"p":[{"n":"changeType","p":773667}],"n":"WaitForChanged","d":380451,"h":227633647139,"f":1},{"r":708131,"p":[{"n":"changeType","p":773667},{"n":"timeout","p":655361}],"n":"WaitForChanged","o":"@$1","d":380451,"h":231928614435,"f":1},{"r":708131,"p":[{"n":"changeType","p":773667},{"n":"timeout","p":140705793}],"n":"WaitForChanged","o":"@$2","d":380451,"h":236223581731,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":380451,"h":4295347747,"f":1},{"p":[{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$4","d":380451,"h":8590315043,"f":1},{"p":[{"n":"path","p":1310721},{"n":"filter","p":1310721}],"n":".ctor","o":"$ctor$5","d":380451,"h":12885282339,"f":1}],"e":[{"e":314915,"m":{"r":65537,"p":[{"n":"value","p":314915}],"n":"add_Changed","d":380451,"h":133144366627,"f":1},"r":{"r":65537,"p":[{"n":"value","p":314915}],"n":"remove_Changed","d":380451,"h":137439333923,"f":1},"n":"Changed","d":380451,"h":128849399331,"f":1},{"e":314915,"m":{"r":65537,"p":[{"n":"value","p":314915}],"n":"add_Created","d":380451,"h":146029268515,"f":1},"r":{"r":65537,"p":[{"n":"value","p":314915}],"n":"remove_Created","d":380451,"h":150324235811,"f":1},"n":"Created","d":380451,"h":141734301219,"f":1},{"e":314915,"m":{"r":65537,"p":[{"n":"value","p":314915}],"n":"add_Deleted","d":380451,"h":158914170403,"f":1},"r":{"r":65537,"p":[{"n":"value","p":314915}],"n":"remove_Deleted","d":380451,"h":163209137699,"f":1},"n":"Deleted","d":380451,"h":154619203107,"f":1},{"e":183843,"m":{"r":65537,"p":[{"n":"value","p":183843}],"n":"add_Error","d":380451,"h":171799072291,"f":1},"r":{"r":65537,"p":[{"n":"value","p":183843}],"n":"remove_Error","d":380451,"h":176094039587,"f":1},"n":"Error","d":380451,"h":167504104995,"f":1},{"e":642595,"m":{"r":65537,"p":[{"n":"value","p":642595}],"n":"add_Renamed","d":380451,"h":184683974179,"f":1},"r":{"r":65537,"p":[{"n":"value","p":642595}],"n":"remove_Renamed","d":380451,"h":188978941475,"f":1},"n":"Renamed","d":380451,"h":180389006883,"f":1}],"i":[1048615,57475073,1507367],"h":380451}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable, $.$scp.System.ComponentModel.ISupportInitialize ]; }
            static get $fullName() { return `System.IO.FileSystemWatcher`; }
        });
        
        $asm.$cls("$sifw.System.IO.RenamedEventArgs", ($self) => class RenamedEventArgs extends $.$sifw.System.IO.FileSystemEventArgs
        {
            $ctor$3(/*System.IO.WatcherChangeTypes*/ changeType, /*string*/ directory, /*string?*/ name, /*string?*/ oldName)
            {
                super.$ctor$2(0, null, null);
                {
                }
                return this;
            }
            /*string */ get OldFullPath()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OldName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 577059;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":249379,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885478947,"f":1},"n":"OldFullPath","d":577059,"h":8590511651,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21475413539,"f":1},"n":"OldName","d":577059,"h":17180446243,"f":1}],"c":[{"p":[{"n":"changeType","p":773667},{"n":"directory","p":1310721},{"n":"name","p":1310721},{"n":"oldName","p":1310721}],"n":".ctor","o":"$ctor$3","d":577059,"h":4295544355,"f":1}],"h":577059}; }
            static get $b() { return $.$sifw.System.IO.FileSystemEventArgs; }
            static get $fullName() { return `System.IO.RenamedEventArgs`; }
        });
        
        $asm.$cls("$sifw.System.IO.InternalBufferOverflowException", ($self) => class InternalBufferOverflowException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message, /*System.Exception?*/ inner)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 445987;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":445987}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.InternalBufferOverflowException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.InteropServices", "NetJs.System.ComponentModel.Primitives"))