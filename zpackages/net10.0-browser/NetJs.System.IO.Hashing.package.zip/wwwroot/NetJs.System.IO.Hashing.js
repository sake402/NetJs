
//--TRIMMABLE-BOUNDARY-START(32)
(async function () {
(function ($global, $, $$, $sm) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.IO.Hashing", 
    {
  "h": 32,
  "f": "System.IO.Hashing",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.IO.Hashing",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.IO.Hashing",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(196640)
        $asm.$cls(`$sih.SIH.NonCryptographicHashAlgorithm`, ($self) => class NonCryptographicHashAlgorithm extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(68719673376)
            /*int*/ HashLengthInBytes = 0;
            //--TRIMMABLE-BOUNDARY-END(68719673376)
            
            //--TRIMMABLE-BOUNDARY-START(8590131232)
            $ctor$1(/*int*/ hashLengthInBytes)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131232);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (hashLengthInBytes < 1)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("hashLengthInBytes");
                    }
                    this.HashLengthInBytes = hashLengthInBytes;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131232)
            
            //--TRIMMABLE-BOUNDARY-START(12885098528)
            /*void */ Append(/*byte[]*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                this.Append$2(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7(source));
            }
            //--TRIMMABLE-BOUNDARY-END(12885098528)
            
            //--TRIMMABLE-BOUNDARY-START(17180065824)
            /*void */ Append$1(/*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                stream.CopyTo$1(new $.$sih.SIH.NonCryptographicHashAlgorithm.CopyToDestinationStream().$ctor$3(this));
            }
            //--TRIMMABLE-BOUNDARY-END(17180065824)
            
            //--TRIMMABLE-BOUNDARY-START(25770000416)
            /*Task */ AppendAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                return stream.CopyToAsync$2(new $.$sih.SIH.NonCryptographicHashAlgorithm.CopyToDestinationStream().$ctor$3(this), cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(25770000416)
            
            //--TRIMMABLE-BOUNDARY-START(38654902304)
            /*byte[] */ GetCurrentHash()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let ret = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [this.HashLengthInBytes], null);
                this.GetCurrentHashCore($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(ret));
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(38654902304)
            
            //--TRIMMABLE-BOUNDARY-START(81604575264)
            /*bool */ TryGetCurrentHash(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < this.HashLengthInBytes)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                this.GetCurrentHashCore(destination.Slice(0, this.HashLengthInBytes));
                bytesWritten.$v = this.HashLengthInBytes;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(81604575264)
            
            //--TRIMMABLE-BOUNDARY-START(42949869600)
            /*int */ GetCurrentHash$1(/*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < this.HashLengthInBytes)
                {
                    $.$sih.SIH.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                this.GetCurrentHashCore(destination.Slice(0, this.HashLengthInBytes));
                return this.HashLengthInBytes;
            }
            //--TRIMMABLE-BOUNDARY-END(42949869600)
            
            //--TRIMMABLE-BOUNDARY-START(51539804192)
            /*byte[] */ GetHashAndReset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539804192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let ret = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [this.HashLengthInBytes], null);
                this.GetHashAndResetCore($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(ret));
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804192)
            
            //--TRIMMABLE-BOUNDARY-START(85899542560)
            /*bool */ TryGetHashAndReset(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899542560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < this.HashLengthInBytes)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                this.GetHashAndResetCore(destination.Slice(0, this.HashLengthInBytes));
                bytesWritten.$v = this.HashLengthInBytes;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(85899542560)
            
            //--TRIMMABLE-BOUNDARY-START(55834771488)
            /*int */ GetHashAndReset$1(/*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < this.HashLengthInBytes)
                {
                    $.$sih.SIH.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                this.GetHashAndResetCore(destination.Slice(0, this.HashLengthInBytes));
                return this.HashLengthInBytes;
            }
            //--TRIMMABLE-BOUNDARY-END(55834771488)
            
            //--TRIMMABLE-BOUNDARY-START(60129738784)
            /*void */ GetHashAndResetCore(/*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129738784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(destination.Length === this.HashLengthInBytes, "destination.Length == HashLengthInBytes");
                this.GetCurrentHashCore(destination);
                this.Reset();
            }
            //--TRIMMABLE-BOUNDARY-END(60129738784)
            
            //--TRIMMABLE-BOUNDARY-START(64424706080)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$12($.$sih.S.SR.NotSupported_GetHashCode);
            }
            //--TRIMMABLE-BOUNDARY-END(64424706080)
            
            //--TRIMMABLE-BOUNDARY-START(77309607968)
            static /*void */ ThrowDestinationTooShort()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309607968);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sih.S.SR.Argument_DestinationTooShort, "destination");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309607968)
            
            //--TRIMMABLE-BOUNDARY-START(262176)
            static $_CopyToDestinationStream;
            static get CopyToDestinationStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(262176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sih.SIH.NonCryptographicHashAlgorithm;
                return $cls.$_CopyToDestinationStream ??= $asm.$ncls(`$sih.SIH.NonCryptographicHashAlgorithm.CopyToDestinationStream`, ($self) => class CopyToDestinationStream extends $.$$.SI.Stream
                {
                    //--TRIMMABLE-BOUNDARY-START(25770065952)
                    /*bool */ get CanWrite()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770065952)
                    
                    //--TRIMMABLE-BOUNDARY-START(115964379168)
                    /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(115964379168);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.hash.Append$2($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, buffer, offset, count)));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(115964379168)
                    
                    //--TRIMMABLE-BOUNDARY-START(133144248352)
                    /*void */ WriteByte(/*byte*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(133144248352);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.hash.Append$2(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$5($.$ref(() => value, undefined, $.$$.S.Byte)));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(133144248352)
                    
                    //--TRIMMABLE-BOUNDARY-START(124554313760)
                    /*Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(124554313760);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.hash.Append$2($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, buffer, offset, count)));
                        return $.$$.STT.Task.CompletedTask;
                    }
                    //--TRIMMABLE-BOUNDARY-END(124554313760)
                    
                    //--TRIMMABLE-BOUNDARY-START(120259346464)
                    /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(120259346464);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.hash.Append$2(buffer);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(120259346464)
                    
                    //--TRIMMABLE-BOUNDARY-START(128849281056)
                    /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(128849281056);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.hash.Append$2(buffer.Span);
                        return new $.$$.STT.ValueTask();
                    }
                    //--TRIMMABLE-BOUNDARY-END(128849281056)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885164064)
                    /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885164064);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.STT.TaskToAsyncResult.Begin(this.WriteAsync$1(buffer, offset, count), callback, state);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885164064)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065033248)
                    /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065033248);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.STT.TaskToAsyncResult.End(asyncResult);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065033248)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360000544)
                    /*void */ Flush()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360000544);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360000544)
                    
                    //--TRIMMABLE-BOUNDARY-START(38654967840)
                    /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38654967840);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.STT.Task.CompletedTask;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38654967840)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180131360)
                    /*bool */ get CanRead()
                    {
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180131360)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475098656)
                    /*bool */ get CanSeek()
                    {
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475098656)
                    
                    //--TRIMMABLE-BOUNDARY-START(85899608096)
                    /*long */ get Length()
                    {
                        throw new $.$$.S.NotSupportedException().$ctor$9();
                    }
                    //--TRIMMABLE-BOUNDARY-END(85899608096)
                    
                    //--TRIMMABLE-BOUNDARY-START(90194575392)
                    /*long */ get Position()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81604640800);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.S.NotSupportedException().$ctor$9();
                    }
                    /*long */ set Position(value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(107374444576);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.S.NotSupportedException().$ctor$9();
                    }
                    //--TRIMMABLE-BOUNDARY-END(90194575392)
                    
                    //--TRIMMABLE-BOUNDARY-START(94489542688)
                    /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(94489542688);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.S.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(94489542688)
                    
                    //--TRIMMABLE-BOUNDARY-START(98784509984)
                    /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(98784509984);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.S.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(98784509984)
                    
                    //--TRIMMABLE-BOUNDARY-START(111669411872)
                    /*void */ SetLength(/*long*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(111669411872);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.S.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(111669411872)
                    
                    //Begin primary constructor
                    /*NonCryptographicHashAlgorithm*/ hash = null;
                    $ctor$3(/*NonCryptographicHashAlgorithm*/hash)
                    {
                        this.hash = hash;
                        super.$ctor$2();
                        return this
                    }
                    //End primary constructor
                    static $h = 262176;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.SI.Stream; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770065952),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424771616,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 262176,
      "h": 25770065952,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770065952),
//--TRIMMABLE-BOUNDARY-START(17180131360),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244902432,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 262176,
      "h": 17180131360,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180131360),
//--TRIMMABLE-BOUNDARY-START(21475098656),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834837024,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 262176,
      "h": 21475098656,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475098656),
//--TRIMMABLE-BOUNDARY-START(85899608096),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014706208,
        "f": 50364417
      },
      "n": "Length",
      "d": 262176,
      "h": 85899608096,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(85899608096),
//--TRIMMABLE-BOUNDARY-START(90194575392),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604640800,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374444576,
        "f": 83918849
      },
      "n": "Position",
      "d": 262176,
      "h": 90194575392,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90194575392)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(115964379168),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 262176,
      "h": 115964379168,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115964379168),
//--TRIMMABLE-BOUNDARY-START(133144248352),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        }
      ],
      "n": "WriteByte",
      "d": 262176,
      "h": 133144248352,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133144248352),
//--TRIMMABLE-BOUNDARY-START(124554313760),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "d": 262176,
      "h": 124554313760,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124554313760),
//--TRIMMABLE-BOUNDARY-START(120259346464),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 262176,
      "h": 120259346464,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120259346464),
//--TRIMMABLE-BOUNDARY-START(128849281056),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 262176,
      "h": 128849281056,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128849281056),
//--TRIMMABLE-BOUNDARY-START(12885164064),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginWrite",
      "d": 262176,
      "h": 12885164064,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885164064),
//--TRIMMABLE-BOUNDARY-START(30065033248),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndWrite",
      "d": 262176,
      "h": 30065033248,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065033248),
//--TRIMMABLE-BOUNDARY-START(34360000544),
    {
      "r": 65537,
      "n": "Flush",
      "d": 262176,
      "h": 34360000544,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360000544),
//--TRIMMABLE-BOUNDARY-START(38654967840),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 262176,
      "h": 38654967840,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38654967840),
//--TRIMMABLE-BOUNDARY-START(94489542688),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 262176,
      "h": 94489542688,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489542688),
//--TRIMMABLE-BOUNDARY-START(98784509984),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 262176,
      "h": 98784509984,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98784509984),
//--TRIMMABLE-BOUNDARY-START(111669411872),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 262176,
      "h": 111669411872,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669411872)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295229472),
    {
      "t": 196640,
      "n": "\u003Chash\u003EP",
      "d": 262176,
      "h": 4295229472,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229472)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590196768),
    {
      "p": [
        {
          "n": "hash",
          "p": 196640
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262176,
      "h": 8590196768,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590196768)
  ],
  "d": 196640,
  "h": 262176
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.NonCryptographicHashAlgorithm+CopyToDestinationStream`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}NonCryptographicHashAlgorithm${separator}CopyToDestinationStream`; }
                }, $cls, ($v) => $cls.$_CopyToDestinationStream = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(262176)
            
            static $h = 196640;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719673376),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359935008,
        "f": 50331649
      },
      "n": "HashLengthInBytes",
      "d": 196640,
      "h": 68719673376,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719673376)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475033120),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": 196640,
      "h": 21475033120,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475033120),
//--TRIMMABLE-BOUNDARY-START(73014640672),
    {
      "r": 65537,
      "n": "Reset",
      "d": 196640,
      "h": 73014640672,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(73014640672),
//--TRIMMABLE-BOUNDARY-START(47244836896),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetCurrentHashCore",
      "d": 196640,
      "h": 47244836896,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(47244836896),
//--TRIMMABLE-BOUNDARY-START(12885098528),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Append",
      "d": 196640,
      "h": 12885098528,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098528),
//--TRIMMABLE-BOUNDARY-START(17180065824),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        }
      ],
      "n": "Append",
      "o": "@$1",
      "d": 196640,
      "h": 17180065824,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065824),
//--TRIMMABLE-BOUNDARY-START(25770000416),
    {
      "r": 178454529,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "AppendAsync",
      "d": 196640,
      "h": 25770000416,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770000416),
//--TRIMMABLE-BOUNDARY-START(38654902304),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "n": "GetCurrentHash",
      "d": 196640,
      "h": 38654902304,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654902304),
//--TRIMMABLE-BOUNDARY-START(81604575264),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryGetCurrentHash",
      "d": 196640,
      "h": 81604575264,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604575264),
//--TRIMMABLE-BOUNDARY-START(42949869600),
    {
      "r": 655361,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetCurrentHash",
      "o": "@$1",
      "d": 196640,
      "h": 42949869600,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949869600),
//--TRIMMABLE-BOUNDARY-START(51539804192),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "n": "GetHashAndReset",
      "d": 196640,
      "h": 51539804192,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539804192),
//--TRIMMABLE-BOUNDARY-START(85899542560),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryGetHashAndReset",
      "d": 196640,
      "h": 85899542560,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899542560),
//--TRIMMABLE-BOUNDARY-START(55834771488),
    {
      "r": 655361,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetHashAndReset",
      "o": "@$1",
      "d": 196640,
      "h": 55834771488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834771488),
//--TRIMMABLE-BOUNDARY-START(60129738784),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetHashAndResetCore",
      "d": 196640,
      "h": 60129738784,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(60129738784),
//--TRIMMABLE-BOUNDARY-START(64424706080),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 196640,
      "h": 64424706080,
      "f": 16809985,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        },
        {
          "t": 104464385,
          "c": 25874268161,
          "a": [
            {
              "v": "Use GetCurrentHash() to retrieve the computed hash code.",
              "t": 1310721
            },
            {
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64424706080),
//--TRIMMABLE-BOUNDARY-START(77309607968),
    {
      "r": 65537,
      "n": "ThrowDestinationTooShort",
      "d": 196640,
      "h": 77309607968,
      "f": 16777248
    },
//--TRIMMABLE-BOUNDARY-END(77309607968)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131232),
    {
      "p": [
        {
          "n": "hashLengthInBytes",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196640,
      "h": 8590131232,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590131232)
  ],
  "h": 196640
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sih.SIH.NonCryptographicHashAlgorithm.CopyToDestinationStream ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.NonCryptographicHashAlgorithm`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}NonCryptographicHashAlgorithm`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196640)
        
        

        //--TRIMMABLE-BOUNDARY-START(327712)
        $asm.$cls(`$sih.SIH.VectorHelper`, ($self) => class VectorHelper
        {
            //--TRIMMABLE-BOUNDARY-START(34360066080)
            static /*bool */ get IsSupported()
            {
                return /*$.$$.SRIX.Pclmulqdq*/$.$$.DeletedObject.IsSupported || (/*$.$$.SRIA.Aes*/$.$$.DeletedObject.IsSupported && /*$.$$.SRIA.AdvSimd*/$.$$.DeletedObject.IsSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(34360066080)
            
            //--TRIMMABLE-BOUNDARY-START(21475164192)
            static /*Vector128<ulong> */ FoldPolynomialPair(/*Vector128<ulong>*/ target, /*Vector128<ulong>*/ source, /*Vector128<ulong>*/ constants)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                target = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr(target, $.$sih.SIH.VectorHelper.CarrylessMultiplyUpper(source, constants));
                target = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr(target, $.$sih.SIH.VectorHelper.CarrylessMultiplyLower(source, constants));
                return target;
            }
            //--TRIMMABLE-BOUNDARY-END(21475164192)
            
            //--TRIMMABLE-BOUNDARY-START(12885229600)
            static /*Vector128<ulong> */ CarrylessMultiplyLower(/*Vector128<ulong>*/ left, /*Vector128<ulong>*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (Pclmulqdq.IsSupported) { ... }
                //if (Aes.IsSupported) { ... }
                $.$sih.S.ThrowHelper.ThrowUnreachableException();
                return new ($.$$.SRI$1.Vector128$$($.$$.S.UInt64))();
            }
            //--TRIMMABLE-BOUNDARY-END(12885229600)
            
            //--TRIMMABLE-BOUNDARY-START(17180196896)
            static /*Vector128<ulong> */ CarrylessMultiplyUpper(/*Vector128<ulong>*/ left, /*Vector128<ulong>*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180196896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (Pclmulqdq.IsSupported) { ... }
                //if (Aes.IsSupported) { ... }
                $.$sih.S.ThrowHelper.ThrowUnreachableException();
                return new ($.$$.SRI$1.Vector128$$($.$$.S.UInt64))();
            }
            //--TRIMMABLE-BOUNDARY-END(17180196896)
            
            //--TRIMMABLE-BOUNDARY-START(8590262304)
            static /*Vector128<ulong> */ CarrylessMultiplyLeftUpperRightLower(/*Vector128<ulong>*/ left, /*Vector128<ulong>*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (Pclmulqdq.IsSupported) { ... }
                //if (Aes.IsSupported) { ... }
                $.$sih.S.ThrowHelper.ThrowUnreachableException();
                return new ($.$$.SRI$1.Vector128$$($.$$.S.UInt64))();
            }
            //--TRIMMABLE-BOUNDARY-END(8590262304)
            
            //--TRIMMABLE-BOUNDARY-START(4295295008)
            static /*Vector128<ulong> */ CarrylessMultiplyLeftLowerRightUpper(/*Vector128<ulong>*/ left, /*Vector128<ulong>*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (Pclmulqdq.IsSupported) { ... }
                //if (Aes.IsSupported) { ... }
                $.$sih.S.ThrowHelper.ThrowUnreachableException();
                return new ($.$$.SRI$1.Vector128$$($.$$.S.UInt64))();
            }
            //--TRIMMABLE-BOUNDARY-END(4295295008)
            
            //--TRIMMABLE-BOUNDARY-START(42950000672)
            static /*Vector128<ulong> */ ShiftRightBytesInVector(/*Vector128<ulong>*/ operand, /*byte*/ numBytesToShift)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950000672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (Sse2.IsSupported) { ... }
                //if (AdvSimd.IsSupported) { ... }
                $.$sih.S.ThrowHelper.ThrowUnreachableException();
                return new ($.$$.SRI$1.Vector128$$($.$$.S.UInt64))();
            }
            //--TRIMMABLE-BOUNDARY-END(42950000672)
            
            //--TRIMMABLE-BOUNDARY-START(38655033376)
            static /*Vector128<ulong> */ ShiftLowerToUpper(/*Vector128<ulong>*/ operand)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (Sse2.IsSupported) { ... }
                //if (AdvSimd.IsSupported) { ... }
                $.$sih.S.ThrowHelper.ThrowUnreachableException();
                return new ($.$$.SRI$1.Vector128$$($.$$.S.UInt64))();
            }
            //--TRIMMABLE-BOUNDARY-END(38655033376)
            
            static $h = 327712;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360066080),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065098784,
        "f": 50331681
      },
      "n": "IsSupported",
      "d": 327712,
      "h": 34360066080,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34360066080)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475164192),
    {
      "r": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "target",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        },
        {
          "n": "source",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        },
        {
          "n": "constants",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        }
      ],
      "n": "FoldPolynomialPair",
      "d": 327712,
      "h": 21475164192,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475164192),
//--TRIMMABLE-BOUNDARY-START(12885229600),
    {
      "r": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "left",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        },
        {
          "n": "right",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        }
      ],
      "n": "CarrylessMultiplyLower",
      "d": 327712,
      "h": 12885229600,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885229600),
//--TRIMMABLE-BOUNDARY-START(17180196896),
    {
      "r": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "left",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        },
        {
          "n": "right",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        }
      ],
      "n": "CarrylessMultiplyUpper",
      "d": 327712,
      "h": 17180196896,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180196896),
//--TRIMMABLE-BOUNDARY-START(8590262304),
    {
      "r": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "left",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        },
        {
          "n": "right",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        }
      ],
      "n": "CarrylessMultiplyLeftUpperRightLower",
      "d": 327712,
      "h": 8590262304,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590262304),
//--TRIMMABLE-BOUNDARY-START(4295295008),
    {
      "r": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "left",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        },
        {
          "n": "right",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        }
      ],
      "n": "CarrylessMultiplyLeftLowerRightUpper",
      "d": 327712,
      "h": 4295295008,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295295008),
//--TRIMMABLE-BOUNDARY-START(42950000672),
    {
      "r": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "operand",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        },
        {
          "n": "numBytesToShift",
          "p": 393217
        }
      ],
      "n": "ShiftRightBytesInVector",
      "d": 327712,
      "h": 42950000672,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950000672),
//--TRIMMABLE-BOUNDARY-START(38655033376),
    {
      "r": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "operand",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        }
      ],
      "n": "ShiftLowerToUpper",
      "d": 327712,
      "h": 38655033376,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655033376)
  ],
  "h": 327712
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.VectorHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}VectorHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327712)
        
        

        //--TRIMMABLE-BOUNDARY-START(983072)
        $asm.$cls(`$sih.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(111670132768)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(111670132768)
            
            //--TRIMMABLE-BOUNDARY-START(103080198176)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(103080198176)
            
            //--TRIMMABLE-BOUNDARY-START(107375165472)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605361696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$sih.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.IO.Hashing", $.$sih.S.SR.$type.Assembly);
                    $.$sih.S.SR.s_resourceManager = temp;
                }
                return $.$sih.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(107375165472)
            
            //--TRIMMABLE-BOUNDARY-START(12885884960)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425492512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sih.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555034656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sih.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12885884960)
            
            //--TRIMMABLE-BOUNDARY-START(8590917664)
            static /*string */ get Argument_DestinationTooShort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835557920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Destination is too short.";
            }
            //--TRIMMABLE-BOUNDARY-END(8590917664)
            
            //--TRIMMABLE-BOUNDARY-START(98785230880)
            static /*string */ get NotSupported_GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015427104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The GetHashCode method is not supported on this object. Use GetCurrentHash or GetHashAndReset to retrieve the hash code computed by this object.";
            }
            //--TRIMMABLE-BOUNDARY-END(98785230880)
            
            //--TRIMMABLE-BOUNDARY-START(115965100064)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(115965100064)
            
            //--TRIMMABLE-BOUNDARY-START(94490263584)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490263584);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490263584)
            
            //--TRIMMABLE-BOUNDARY-START(128850001952)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128850001952);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sih.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128850001952)
            
            //--TRIMMABLE-BOUNDARY-START(90195296288)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195296288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sih.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sih.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(90195296288)
            
            //--TRIMMABLE-BOUNDARY-START(85900328992)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900328992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sih.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(85900328992)
            
            //--TRIMMABLE-BOUNDARY-START(42950656032)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sih.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42950656032)
            
            //--TRIMMABLE-BOUNDARY-START(38655688736)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655688736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sih.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(38655688736)
            
            //--TRIMMABLE-BOUNDARY-START(34360721440)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360721440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sih.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(34360721440)
            
            //--TRIMMABLE-BOUNDARY-START(47245623328)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245623328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sih.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(47245623328)
            
            //--TRIMMABLE-BOUNDARY-START(25770786848)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770786848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sih.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(25770786848)
            
            //--TRIMMABLE-BOUNDARY-START(21475819552)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sih.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(21475819552)
            
            //--TRIMMABLE-BOUNDARY-START(17180852256)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sih.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(17180852256)
            
            //--TRIMMABLE-BOUNDARY-START(30065754144)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065754144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sih.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(30065754144)
            
            //--TRIMMABLE-BOUNDARY-START(4295950368)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(115965100064)
                    this.s_usingResourceKeys = $.$sih.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(115965100064)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295950368)
            
            static $h = 983072;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 983072
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983072)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048608)
        $asm.$cls(`$sih.S.ThrowHelper`, ($self) => class ThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4296015904)
            static /*void */ ThrowUnreachableException()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296015904);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.SD.UnreachableException().$ctor$5();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296015904)
            
            static $h = 1048608;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296015904),
    {
      "r": 65537,
      "n": "ThrowUnreachableException",
      "d": 1048608,
      "h": 4296015904,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296015904)
  ],
  "h": 1048608
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ThrowHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048608)
        
        

        //--TRIMMABLE-BOUNDARY-START(852000)
        $asm.$cls(`$sih.SIH.XxHashShared`, ($self) => class XxHashShared
        {
            //--TRIMMABLE-BOUNDARY-START(352188170272)
            /*int*/ static StripeLengthBytes = 64;
            //--TRIMMABLE-BOUNDARY-END(352188170272)
            
            //--TRIMMABLE-BOUNDARY-START(339303268384)
            /*int*/ static SecretLengthBytes = 192;
            //--TRIMMABLE-BOUNDARY-END(339303268384)
            
            //--TRIMMABLE-BOUNDARY-START(347893202976)
            /*int*/ static SecretSizeMin = 136;
            //--TRIMMABLE-BOUNDARY-END(347893202976)
            
            //--TRIMMABLE-BOUNDARY-START(335008301088)
            /*int*/ static SecretLastAccStartBytes = 7;
            //--TRIMMABLE-BOUNDARY-END(335008301088)
            
            //--TRIMMABLE-BOUNDARY-START(330713333792)
            /*int*/ static SecretConsumeRateBytes = 8;
            //--TRIMMABLE-BOUNDARY-END(330713333792)
            
            //--TRIMMABLE-BOUNDARY-START(343598235680)
            /*int*/ static SecretMergeAccsStartBytes = 11;
            //--TRIMMABLE-BOUNDARY-END(343598235680)
            
            //--TRIMMABLE-BOUNDARY-START(253403922464)
            /*int*/ static NumStripesPerBlock = 16;
            //--TRIMMABLE-BOUNDARY-END(253403922464)
            
            //--TRIMMABLE-BOUNDARY-START(30065623072)
            /*int*/ static AccumulatorCount = 8;
            //--TRIMMABLE-BOUNDARY-END(30065623072)
            
            //--TRIMMABLE-BOUNDARY-START(227634118688)
            /*int*/ static MidSizeMaxBytes = 240;
            //--TRIMMABLE-BOUNDARY-END(227634118688)
            
            //--TRIMMABLE-BOUNDARY-START(219044184096)
            /*int*/ static InternalBufferStripes = 4;
            //--TRIMMABLE-BOUNDARY-END(219044184096)
            
            //--TRIMMABLE-BOUNDARY-START(214749216800)
            /*int*/ static InternalBufferLengthBytes = 256;
            //--TRIMMABLE-BOUNDARY-END(214749216800)
            
            //--TRIMMABLE-BOUNDARY-START(51540459552)
            static /*ReadOnlySpan<byte> */ get DefaultSecret()
            {
                return this.$cacheDefaultSecret ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([ 184, 254, 108, 57, 35, 164, 75, 190, 124, 1, 129, 44, 247, 33, 173, 28, 222, 212, 109, 233, 131, 144, 151, 219, 114, 64, 164, 164, 183, 179, 103, 31, 203, 121, 230, 78, 204, 192, 229, 120, 130, 90, 208, 125, 204, 255, 114, 33, 184, 8, 70, 116, 247, 67, 36, 142, 224, 53, 144, 230, 129, 58, 38, 76, 60, 40, 82, 187, 145, 195, 0, 203, 136, 208, 101, 139, 27, 83, 46, 163, 113, 100, 72, 151, 162, 13, 249, 78, 56, 25, 239, 70, 169, 222, 172, 216, 168, 250, 118, 63, 227, 156, 52, 63, 249, 220, 187, 199, 199, 11, 79, 29, 138, 81, 224, 75, 205, 180, 89, 49, 200, 159, 126, 201, 217, 120, 115, 100, 234, 197, 172, 131, 52, 211, 235, 195, 197, 129, 160, 255, 250, 19, 99, 235, 23, 13, 221, 81, 183, 240, 218, 73, 211, 22, 85, 38, 41, 212, 104, 158, 43, 22, 190, 88, 125, 71, 161, 252, 143, 248, 184, 209, 122, 208, 49, 206, 69, 203, 58, 143, 149, 22, 4, 40, 175, 215, 251, 202, 187, 75, 64, 126 ]);
            }
            //--TRIMMABLE-BOUNDARY-END(51540459552)
            
            //--TRIMMABLE-BOUNDARY-START(115964968992)
            /*ulong*/ static DefaultSecretUInt64_0 = 0xBE4BA423396CFEB8n;
            //--TRIMMABLE-BOUNDARY-END(115964968992)
            
            //--TRIMMABLE-BOUNDARY-START(120259936288)
            /*ulong*/ static DefaultSecretUInt64_1 = 0x1CAD21F72C81017Cn;
            //--TRIMMABLE-BOUNDARY-END(120259936288)
            
            //--TRIMMABLE-BOUNDARY-START(150324707360)
            /*ulong*/ static DefaultSecretUInt64_2 = 0xDB979083E96DD4DEn;
            //--TRIMMABLE-BOUNDARY-END(150324707360)
            
            //--TRIMMABLE-BOUNDARY-START(154619674656)
            /*ulong*/ static DefaultSecretUInt64_3 = 0x1F67B3B7A4A44072n;
            //--TRIMMABLE-BOUNDARY-END(154619674656)
            
            //--TRIMMABLE-BOUNDARY-START(158914641952)
            /*ulong*/ static DefaultSecretUInt64_4 = 0x78E5C0CC4EE679CBn;
            //--TRIMMABLE-BOUNDARY-END(158914641952)
            
            //--TRIMMABLE-BOUNDARY-START(163209609248)
            /*ulong*/ static DefaultSecretUInt64_5 = 0x2172FFCC7DD05A82n;
            //--TRIMMABLE-BOUNDARY-END(163209609248)
            
            //--TRIMMABLE-BOUNDARY-START(167504576544)
            /*ulong*/ static DefaultSecretUInt64_6 = 0x8E2443F7744608B8n;
            //--TRIMMABLE-BOUNDARY-END(167504576544)
            
            //--TRIMMABLE-BOUNDARY-START(171799543840)
            /*ulong*/ static DefaultSecretUInt64_7 = 0x4C263A81E69035E0n;
            //--TRIMMABLE-BOUNDARY-END(171799543840)
            
            //--TRIMMABLE-BOUNDARY-START(176094511136)
            /*ulong*/ static DefaultSecretUInt64_8 = 0xCB00C391BB52283Cn;
            //--TRIMMABLE-BOUNDARY-END(176094511136)
            
            //--TRIMMABLE-BOUNDARY-START(180389478432)
            /*ulong*/ static DefaultSecretUInt64_9 = 0xA32E531B8B65D088n;
            //--TRIMMABLE-BOUNDARY-END(180389478432)
            
            //--TRIMMABLE-BOUNDARY-START(124554903584)
            /*ulong*/ static DefaultSecretUInt64_10 = 0x4EF90DA297486471n;
            //--TRIMMABLE-BOUNDARY-END(124554903584)
            
            //--TRIMMABLE-BOUNDARY-START(128849870880)
            /*ulong*/ static DefaultSecretUInt64_11 = 0xD8ACDEA946EF1938n;
            //--TRIMMABLE-BOUNDARY-END(128849870880)
            
            //--TRIMMABLE-BOUNDARY-START(133144838176)
            /*ulong*/ static DefaultSecretUInt64_12 = 0x3F349CE33F76FAA8n;
            //--TRIMMABLE-BOUNDARY-END(133144838176)
            
            //--TRIMMABLE-BOUNDARY-START(137439805472)
            /*ulong*/ static DefaultSecretUInt64_13 = 0x1D4F0BC7C7BBDCF9n;
            //--TRIMMABLE-BOUNDARY-END(137439805472)
            
            //--TRIMMABLE-BOUNDARY-START(141734772768)
            /*ulong*/ static DefaultSecretUInt64_14 = 0x3159B4CD4BE0518An;
            //--TRIMMABLE-BOUNDARY-END(141734772768)
            
            //--TRIMMABLE-BOUNDARY-START(146029740064)
            /*ulong*/ static DefaultSecretUInt64_15 = 0x647378D9C97E9FC8n;
            //--TRIMMABLE-BOUNDARY-END(146029740064)
            
            //--TRIMMABLE-BOUNDARY-START(55835426848)
            /*ulong*/ static DefaultSecret3UInt64_0 = 0x81017CBE4BA42339n;
            //--TRIMMABLE-BOUNDARY-END(55835426848)
            
            //--TRIMMABLE-BOUNDARY-START(60130394144)
            /*ulong*/ static DefaultSecret3UInt64_1 = 0x6DD4DE1CAD21F72Cn;
            //--TRIMMABLE-BOUNDARY-END(60130394144)
            
            //--TRIMMABLE-BOUNDARY-START(81605230624)
            /*ulong*/ static DefaultSecret3UInt64_2 = 0xA44072DB979083E9n;
            //--TRIMMABLE-BOUNDARY-END(81605230624)
            
            //--TRIMMABLE-BOUNDARY-START(85900197920)
            /*ulong*/ static DefaultSecret3UInt64_3 = 0xE679CB1F67B3B7A4n;
            //--TRIMMABLE-BOUNDARY-END(85900197920)
            
            //--TRIMMABLE-BOUNDARY-START(90195165216)
            /*ulong*/ static DefaultSecret3UInt64_4 = 0xD05A8278E5C0CC4En;
            //--TRIMMABLE-BOUNDARY-END(90195165216)
            
            //--TRIMMABLE-BOUNDARY-START(94490132512)
            /*ulong*/ static DefaultSecret3UInt64_5 = 0x4608B82172FFCC7Dn;
            //--TRIMMABLE-BOUNDARY-END(94490132512)
            
            //--TRIMMABLE-BOUNDARY-START(98785099808)
            /*ulong*/ static DefaultSecret3UInt64_6 = 0x9035E08E2443F774n;
            //--TRIMMABLE-BOUNDARY-END(98785099808)
            
            //--TRIMMABLE-BOUNDARY-START(103080067104)
            /*ulong*/ static DefaultSecret3UInt64_7 = 0x52283C4C263A81E6n;
            //--TRIMMABLE-BOUNDARY-END(103080067104)
            
            //--TRIMMABLE-BOUNDARY-START(107375034400)
            /*ulong*/ static DefaultSecret3UInt64_8 = 0x65D088CB00C391BBn;
            //--TRIMMABLE-BOUNDARY-END(107375034400)
            
            //--TRIMMABLE-BOUNDARY-START(111670001696)
            /*ulong*/ static DefaultSecret3UInt64_9 = 0x486471A32E531B8Bn;
            //--TRIMMABLE-BOUNDARY-END(111670001696)
            
            //--TRIMMABLE-BOUNDARY-START(64425361440)
            /*ulong*/ static DefaultSecret3UInt64_10 = 0xEF19384EF90DA297n;
            //--TRIMMABLE-BOUNDARY-END(64425361440)
            
            //--TRIMMABLE-BOUNDARY-START(68720328736)
            /*ulong*/ static DefaultSecret3UInt64_11 = 0x76FAA8D8ACDEA946n;
            //--TRIMMABLE-BOUNDARY-END(68720328736)
            
            //--TRIMMABLE-BOUNDARY-START(73015296032)
            /*ulong*/ static DefaultSecret3UInt64_12 = 0xBBDCF93F349CE33Fn;
            //--TRIMMABLE-BOUNDARY-END(73015296032)
            
            //--TRIMMABLE-BOUNDARY-START(77310263328)
            /*ulong*/ static DefaultSecret3UInt64_13 = 0xE0518A1D4F0BC7C7n;
            //--TRIMMABLE-BOUNDARY-END(77310263328)
            
            //--TRIMMABLE-BOUNDARY-START(279173726240)
            /*ulong*/ static Prime64_1 = 0x9E3779B185EBCA87n;
            //--TRIMMABLE-BOUNDARY-END(279173726240)
            
            //--TRIMMABLE-BOUNDARY-START(283468693536)
            /*ulong*/ static Prime64_2 = 0xC2B2AE3D27D4EB4Fn;
            //--TRIMMABLE-BOUNDARY-END(283468693536)
            
            //--TRIMMABLE-BOUNDARY-START(287763660832)
            /*ulong*/ static Prime64_3 = 0x165667B19E3779F9n;
            //--TRIMMABLE-BOUNDARY-END(287763660832)
            
            //--TRIMMABLE-BOUNDARY-START(292058628128)
            /*ulong*/ static Prime64_4 = 0x85EBCA77C2B2AE63n;
            //--TRIMMABLE-BOUNDARY-END(292058628128)
            
            //--TRIMMABLE-BOUNDARY-START(296353595424)
            /*ulong*/ static Prime64_5 = 0x27D4EB2F165667C5n;
            //--TRIMMABLE-BOUNDARY-END(296353595424)
            
            //--TRIMMABLE-BOUNDARY-START(257698889760)
            /*uint*/ static Prime32_1 = 2654435761;
            //--TRIMMABLE-BOUNDARY-END(257698889760)
            
            //--TRIMMABLE-BOUNDARY-START(261993857056)
            /*uint*/ static Prime32_2 = 2246822519;
            //--TRIMMABLE-BOUNDARY-END(261993857056)
            
            //--TRIMMABLE-BOUNDARY-START(266288824352)
            /*uint*/ static Prime32_3 = 3266489917;
            //--TRIMMABLE-BOUNDARY-END(266288824352)
            
            //--TRIMMABLE-BOUNDARY-START(270583791648)
            /*uint*/ static Prime32_4 = 668265263;
            //--TRIMMABLE-BOUNDARY-END(270583791648)
            
            //--TRIMMABLE-BOUNDARY-START(274878758944)
            /*uint*/ static Prime32_5 = 374761393;
            //--TRIMMABLE-BOUNDARY-END(274878758944)
            
            //--TRIMMABLE-BOUNDARY-START(4295819296)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte**/ let secret = $.$$.SRC.RuntimeHelpers.StackAllocPointer($.$$.S.Byte, 192/*SecretLengthBytes*/, null);
                $.$sih.SIH.XxHashShared.DeriveSecretFromSeed(secret, 0n);
                $.$$.SD.Debug.Assert$4($.$$.S.MemoryExtensions.SequenceEqual$1($.$$.S.Byte, $.$$.S.Span$$($.$$.S.Byte).op_Implicit(new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$5(secret, 192/*SecretLengthBytes*/)), $.$sih.SIH.XxHashShared.DefaultSecret), "new Span<byte>(secret, SecretLengthBytes).SequenceEqual(DefaultSecret)");
                $.$$.SD.Debug.Assert$4(256/*InternalBufferLengthBytes*/ % 64/*StripeLengthBytes*/ === 0, "InternalBufferLengthBytes % StripeLengthBytes == 0");
                /*ReadOnlySpan<ulong>*/ let defaultSecretUInt64 = $.$$.SRI.MemoryMarshal.Cast($.$$.S.Byte, $.$$.S.UInt64, $.$sih.SIH.XxHashShared.DefaultSecret);
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(0)) === 13712233961653862072n, "ReadLE64(defaultSecretUInt64[0]) == DefaultSecretUInt64_0");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(1)) === 2066345149520216444n, "ReadLE64(defaultSecretUInt64[1]) == DefaultSecretUInt64_1");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(2)) === 15823274712020931806n, "ReadLE64(defaultSecretUInt64[2]) == DefaultSecretUInt64_2");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(3)) === 2262974939099578482n, "ReadLE64(defaultSecretUInt64[3]) == DefaultSecretUInt64_3");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(4)) === 8711581037947681227n, "ReadLE64(defaultSecretUInt64[4]) == DefaultSecretUInt64_4");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(5)) === 2410270004345854594n, "ReadLE64(defaultSecretUInt64[5]) == DefaultSecretUInt64_5");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(6)) === 10242386182634080440n, "ReadLE64(defaultSecretUInt64[6]) == DefaultSecretUInt64_6");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(7)) === 5487137525590930912n, "ReadLE64(defaultSecretUInt64[7]) == DefaultSecretUInt64_7");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(8)) === 14627906620379768892n, "ReadLE64(defaultSecretUInt64[8]) == DefaultSecretUInt64_8");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(9)) === 11758427054878871688n, "ReadLE64(defaultSecretUInt64[9]) == DefaultSecretUInt64_9");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(10)) === 5690594596133299313n, "ReadLE64(defaultSecretUInt64[10]) == DefaultSecretUInt64_10");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(11)) === 15613098826807580984n, "ReadLE64(defaultSecretUInt64[11]) == DefaultSecretUInt64_11");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(12)) === 4554437623014685352n, "ReadLE64(defaultSecretUInt64[12]) == DefaultSecretUInt64_12");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(13)) === 2111919702937427193n, "ReadLE64(defaultSecretUInt64[13]) == DefaultSecretUInt64_13");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(14)) === 3556072174620004746n, "ReadLE64(defaultSecretUInt64[14]) == DefaultSecretUInt64_14");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecretUInt64._reference.GetAt(15)) === 7238261902898274248n, "ReadLE64(defaultSecretUInt64[15]) == DefaultSecretUInt64_15");
                /*ReadOnlySpan<ulong>*/ let defaultSecret3UInt64 = $.$$.SRI.MemoryMarshal.Cast($.$$.S.Byte, $.$$.S.UInt64, $.$sih.SIH.XxHashShared.DefaultSecret.Slice$1(3));
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(0)) === 9295848262624092985n, "ReadLE64(defaultSecret3UInt64[0]) == DefaultSecret3UInt64_0");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(1)) === 7914194659941938988n, "ReadLE64(defaultSecret3UInt64[1]) == DefaultSecret3UInt64_1");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(2)) === 11835586108195898345n, "ReadLE64(defaultSecret3UInt64[2]) == DefaultSecret3UInt64_2");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(3)) === 16607528436649670564n, "ReadLE64(defaultSecret3UInt64[3]) == DefaultSecret3UInt64_3");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(4)) === 15013455763555273806n, "ReadLE64(defaultSecret3UInt64[4]) == DefaultSecret3UInt64_4");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(5)) === 5046485836271438973n, "ReadLE64(defaultSecret3UInt64[5]) == DefaultSecret3UInt64_5");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(6)) === 10391458616325699444n, "ReadLE64(defaultSecret3UInt64[6]) == DefaultSecret3UInt64_6");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(7)) === 5920048007935066598n, "ReadLE64(defaultSecret3UInt64[7]) == DefaultSecret3UInt64_7");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(8)) === 7336514198459093435n, "ReadLE64(defaultSecret3UInt64[8]) == DefaultSecret3UInt64_8");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(9)) === 5216419214072683403n, "ReadLE64(defaultSecret3UInt64[9]) == DefaultSecret3UInt64_9");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(10)) === 17228863761319568023n, "ReadLE64(defaultSecret3UInt64[10]) == DefaultSecret3UInt64_10");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(11)) === 8573350489219836230n, "ReadLE64(defaultSecret3UInt64[11]) == DefaultSecret3UInt64_11");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(12)) === 13536968629829821247n, "ReadLE64(defaultSecret3UInt64[12]) == DefaultSecret3UInt64_12");
                $.$$.SD.Debug.Assert$4(ReadLE64(defaultSecret3UInt64._reference.GetAt(13)) === 16163852396094277575n, "ReadLE64(defaultSecret3UInt64[13]) == DefaultSecret3UInt64_13");
                /*static ulong*/  function ReadLE64(/*ulong*/ data)
                {
                    {
                        return $.$$.S.BitConverter.IsLittleEndian ? data : $.$$.SBB.BinaryPrimitives.ReverseEndianness$21(data);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295819296)
            
            //--TRIMMABLE-BOUNDARY-START(206159282208)
            static /*void */ Initialize(/*ref State*/ state, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159282208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                state.$v.Seed = seed;
                /*fixed*/ 
                {
                    /*byte**/ let secret = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$$.S.Byte, state.$v.Secret, null, false, true);
                    if (seed === 0n)
                    {
                        $.$sih.SIH.XxHashShared.DefaultSecret.CopyTo(new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$5(secret, 192/*SecretLengthBytes*/));
                    }
                    else 
                    {
                        $.$sih.SIH.XxHashShared.DeriveSecretFromSeed(secret, seed);
                    }
                }
                $.$sih.SIH.XxHashShared.Reset(state);
            }
            //--TRIMMABLE-BOUNDARY-END(206159282208)
            
            //--TRIMMABLE-BOUNDARY-START(309238497312)
            static /*void */ Reset(/*ref State*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238497312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                state.$v.BufferedCount = 0;
                state.$v.StripesProcessedInCurrentBlock = 0n;
                state.$v.TotalLength = 0n;
                /*fixed*/ 
                {
                    /*ulong**/ let accumulators = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$$.S.UInt64, state.$v.Accumulators, null, false, true);
                    $.$sih.SIH.XxHashShared.InitializeAccumulators(accumulators);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(309238497312)
            
            //--TRIMMABLE-BOUNDARY-START(313533464608)
            static /*ulong */ Rrmxmx(/*ulong*/ hash, /*uint*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533464608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                hash ^= $.$$.SN$1.BitOperations.RotateLeft$1(hash, 49) ^ $.$$.SN$1.BitOperations.RotateLeft$1(hash, 24);
                hash *= 11507291218515648293n;
                hash ^= BigInt.asUintN(64, (hash >> 35n) + BigInt(length));
                hash *= 11507291218515648293n;
                return $.$sih.SIH.XxHashShared.XorShift(hash, 28);
            }
            //--TRIMMABLE-BOUNDARY-END(313533464608)
            
            //--TRIMMABLE-BOUNDARY-START(201864314912)
            static /*void */ HashInternalLoop(/*ulong**/ accumulators, /*byte**/ source, /*uint*/ length, /*byte**/ secret)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864314912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(length > 240, "length > 240");
                /*int*/ let StripesPerBlock = $.trunc((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0)) / 8/*SecretConsumeRateBytes*/);
                /*int*/ let BlockLen = ((64/*StripeLengthBytes*/ * StripesPerBlock) | 0);
                /*int*/ let blocksNum = (($.trunc((((length - 1) >>> 0)) / BlockLen)) | 0);
                $.$sih.SIH.XxHashShared.Accumulate(accumulators, source, secret, StripesPerBlock, true, blocksNum);
                /*int*/ let offset = ((BlockLen * blocksNum) | 0);
                /*int*/ let stripesNumber = $.$cast(((BigInt(length - 1) - BigInt(offset)) / BigInt(64/*StripeLengthBytes*/)), $.$$.S.Int32);
                $.$sih.SIH.XxHashShared.Accumulate(accumulators, source.Add(offset), secret, stripesNumber, false, 1);
                $.$sih.SIH.XxHashShared.Accumulate512(accumulators, source.Add(length).Add(-64/*StripeLengthBytes*/), secret.Add((((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0) - 7/*SecretLastAccStartBytes*/) | 0))));
            }
            //--TRIMMABLE-BOUNDARY-END(201864314912)
            
            //--TRIMMABLE-BOUNDARY-START(42950524960)
            static /*void */ ConsumeStripes(/*ulong**/ accumulators, /*ref ulong*/ stripesSoFar, /*ulong*/ stripesPerBlock, /*byte**/ source, /*ulong*/ stripes, /*byte**/ secret)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950524960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(stripes <= stripesPerBlock, "stripes <= stripesPerBlock");
                $.$$.SD.Debug.Assert$4(stripesSoFar.$v < stripesPerBlock, "stripesSoFar < stripesPerBlock");
                /*ulong*/ let stripesToEndOfBlock = BigInt.asUintN(64, stripesPerBlock - stripesSoFar.$v);
                if (stripesToEndOfBlock <= stripes)
                {
                    /*ulong*/ let stripesAfterBlock = BigInt.asUintN(64, stripes - stripesToEndOfBlock);
                    $.$sih.SIH.XxHashShared.Accumulate(accumulators, source, secret.Add(((($.$cast(stripesSoFar.$v, $.$$.S.Int32) * 8/*SecretConsumeRateBytes*/) | 0))), $.$cast(stripesToEndOfBlock, $.$$.S.Int32), false, 1);
                    $.$sih.SIH.XxHashShared.ScrambleAccumulators(accumulators, secret.Add((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0))));
                    $.$sih.SIH.XxHashShared.Accumulate(accumulators, source.Add(((($.$cast(stripesToEndOfBlock, $.$$.S.Int32) * 64/*StripeLengthBytes*/) | 0))), secret, $.$cast(stripesAfterBlock, $.$$.S.Int32), false, 1);
                    stripesSoFar.$v = stripesAfterBlock;
                }
                else 
                {
                    $.$sih.SIH.XxHashShared.Accumulate(accumulators, source, secret.Add(((($.$cast(stripesSoFar.$v, $.$$.S.Int32) * 8/*SecretConsumeRateBytes*/) | 0))), $.$cast(stripes, $.$$.S.Int32), false, 1);
                    stripesSoFar.$v += stripes;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950524960)
            
            //--TRIMMABLE-BOUNDARY-START(34360590368)
            static /*void */ Append(/*ref State*/ state, /*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360590368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(state.$v.BufferedCount <= 256/*InternalBufferLengthBytes*/, "state.BufferedCount <= InternalBufferLengthBytes");
                state.$v.TotalLength += BigInt((source.Length >>> 0));
                /*fixed*/ 
                {
                    /*byte**/ let buffer = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$$.S.Byte, state.$v.Buffer, null, false, true);
                    if (BigInt(source.Length) <= BigInt(256/*InternalBufferLengthBytes*/ - state.$v.BufferedCount))
                    {
                        source.CopyTo(new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$5(buffer.Add(state.$v.BufferedCount), source.Length));
                        state.$v.BufferedCount += (source.Length >>> 0);
                        return;
                    }
                    /*fixed*/ 
                    {
                        /*byte**/ let secret = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$$.S.Byte, state.$v.Secret, null, false, true);
                        /*fixed*/ 
                        {
                            /*ulong**/ let accumulators = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$$.S.UInt64, state.$v.Accumulators, null, false, true);
                            /*fixed*/ 
                            {
                                /*byte**/ let sourcePtr = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Byte, source);
                                /*int*/ let sourceIndex = 0;
                                if (state.$v.BufferedCount !== 0)
                                {
                                    /*int*/ let loadSize = ((256/*InternalBufferLengthBytes*/ - (state.$v.BufferedCount | 0)) | 0);
                                    source.Slice(0, loadSize).CopyTo(new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$5(buffer.Add(state.$v.BufferedCount), loadSize));
                                    sourceIndex = loadSize;
                                    $.$sih.SIH.XxHashShared.ConsumeStripes(accumulators, $.$ref(() => state.$v.StripesProcessedInCurrentBlock, ($v) => state.$v.StripesProcessedInCurrentBlock = $v, $.$$.S.UInt64), BigInt(16/*NumStripesPerBlock*/), buffer, BigInt(4/*InternalBufferStripes*/), secret);
                                    state.$v.BufferedCount = 0;
                                }
                                $.$$.SD.Debug.Assert$4(sourceIndex < source.Length, "sourceIndex < source.Length");
                                if (((source.Length - sourceIndex) | 0) > ((16/*NumStripesPerBlock*/ * 64/*StripeLengthBytes*/) | 0))
                                {
                                    /*ulong*/ let stripes = $.$cast((((((source.Length - sourceIndex) | 0) - 1) | 0)), $.$$.S.UInt64) / BigInt(64/*StripeLengthBytes*/);
                                    $.$$.SD.Debug.Assert$4(BigInt(16/*NumStripesPerBlock*/) >= state.$v.StripesProcessedInCurrentBlock, "NumStripesPerBlock >= state.StripesProcessedInCurrentBlock");
                                    /*ulong*/ let stripesToEnd = BigInt.asIntN(64, BigInt(16/*NumStripesPerBlock*/) - state.$v.StripesProcessedInCurrentBlock);
                                    $.$$.SD.Debug.Assert$4(stripesToEnd <= stripes, "stripesToEnd <= stripes");
                                    $.$sih.SIH.XxHashShared.Accumulate(accumulators, sourcePtr.Add(sourceIndex), secret.Add(((($.$cast(state.$v.StripesProcessedInCurrentBlock, $.$$.S.Int32) * 8/*SecretConsumeRateBytes*/) | 0))), $.$cast(stripesToEnd, $.$$.S.Int32), false, 1);
                                    $.$sih.SIH.XxHashShared.ScrambleAccumulators(accumulators, secret.Add((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0))));
                                    state.$v.StripesProcessedInCurrentBlock = 0n;
                                    sourceIndex += (($.$cast(stripesToEnd, $.$$.S.Int32) * 64/*StripeLengthBytes*/) | 0);
                                    stripes -= stripesToEnd;
                                    while(stripes >= BigInt(16/*NumStripesPerBlock*/))
                                    {
                                        $.$sih.SIH.XxHashShared.Accumulate(accumulators, sourcePtr.Add(sourceIndex), secret, 16/*NumStripesPerBlock*/, false, 1);
                                        $.$sih.SIH.XxHashShared.ScrambleAccumulators(accumulators, secret.Add((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0))));
                                        sourceIndex += ((16/*NumStripesPerBlock*/ * 64/*StripeLengthBytes*/) | 0);
                                        stripes -= BigInt(16/*NumStripesPerBlock*/);
                                    }
                                    $.$sih.SIH.XxHashShared.Accumulate(accumulators, sourcePtr.Add(sourceIndex), secret, $.$cast(stripes, $.$$.S.Int32), false, 1);
                                    sourceIndex += (($.$cast(stripes, $.$$.S.Int32) * 64/*StripeLengthBytes*/) | 0);
                                    $.$$.SD.Debug.Assert$4(sourceIndex < source.Length, "sourceIndex < source.Length");
                                    state.$v.StripesProcessedInCurrentBlock = stripes;
                                    source.Slice(((sourceIndex - 64/*StripeLengthBytes*/) | 0), 64/*StripeLengthBytes*/).CopyTo(new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$5(buffer.Add(256/*InternalBufferLengthBytes*/).Add(-64/*StripeLengthBytes*/), 64/*StripeLengthBytes*/));
                                }
                                else if (((source.Length - sourceIndex) | 0) > 256/*InternalBufferLengthBytes*/)
                                {
                                    do
                                    {
                                        $.$sih.SIH.XxHashShared.ConsumeStripes(accumulators, $.$ref(() => state.$v.StripesProcessedInCurrentBlock, ($v) => state.$v.StripesProcessedInCurrentBlock = $v, $.$$.S.UInt64), BigInt(16/*NumStripesPerBlock*/), sourcePtr.Add(sourceIndex), BigInt(4/*InternalBufferStripes*/), secret);
                                        sourceIndex += 256/*InternalBufferLengthBytes*/;
                                    }
                                    while(((source.Length - sourceIndex) | 0) > 256/*InternalBufferLengthBytes*/);
                                    source.Slice(((sourceIndex - 64/*StripeLengthBytes*/) | 0), 64/*StripeLengthBytes*/).CopyTo(new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$5(buffer.Add(256/*InternalBufferLengthBytes*/).Add(-64/*StripeLengthBytes*/), 64/*StripeLengthBytes*/));
                                }
                                /*Span<byte>*/ let remaining = new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$5(buffer, ((source.Length - sourceIndex) | 0));
                                $.$$.SD.Debug.Assert$4(sourceIndex < source.Length, "sourceIndex < source.Length");
                                $.$$.SD.Debug.Assert$4(remaining.Length <= 256/*InternalBufferLengthBytes*/, "remaining.Length <= InternalBufferLengthBytes");
                                $.$$.SD.Debug.Assert$4(state.$v.BufferedCount === 0, "state.BufferedCount == 0");
                                source.Slice$1(sourceIndex).CopyTo(remaining);
                                state.$v.BufferedCount = (remaining.Length >>> 0);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360590368)
            
            //--TRIMMABLE-BOUNDARY-START(47245492256)
            static /*void */ CopyAccumulators(/*ref State*/ state, /*ulong**/ accumulators)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245492256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*ulong**/ let stateAccumulators = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$$.S.UInt64, state.$v.Accumulators, null, false, true);
                    //if (Vector256.IsHardwareAccelerated) { ... }
                    /*else*/ //if (Vector128.IsHardwareAccelerated) { ... }
                    //else 
                    {
                        for(/*int*/ let i = 0; i < 8; i++)
                        {
                            accumulators.SetAt(stateAccumulators.GetAt(i), i);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245492256)
            
            //--TRIMMABLE-BOUNDARY-START(188979413024)
            static /*void */ DigestLong(/*ref State*/ state, /*ulong**/ accumulators, /*byte**/ secret)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979413024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(state.$v.BufferedCount > 0, "state.BufferedCount > 0");
                /*fixed*/ 
                {
                    /*byte**/ let buffer = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$$.S.Byte, state.$v.Buffer, null, false, true);
                    /*byte**/ let accumulateData;
                    if (state.$v.BufferedCount >= 64/*StripeLengthBytes*/)
                    {
                        /*uint*/ let stripes = $.trunc((((state.$v.BufferedCount - 1) >>> 0)) / 64/*StripeLengthBytes*/);
                        /*ulong*/ let stripesSoFar = state.$v.StripesProcessedInCurrentBlock;
                        $.$sih.SIH.XxHashShared.ConsumeStripes(accumulators, $.$ref(() => stripesSoFar, ($v) => stripesSoFar = $v, $.$$.S.UInt64), BigInt(16/*NumStripesPerBlock*/), buffer, BigInt(stripes), secret);
                        accumulateData = buffer.Add(state.$v.BufferedCount).Add(-64/*StripeLengthBytes*/);
                    }
                    else 
                    {
                        /*byte**/ let lastStripe = $.$$.SRC.RuntimeHelpers.StackAllocPointer($.$$.S.Byte, 64/*StripeLengthBytes*/, null);
                        /*int*/ let catchupSize = ((64/*StripeLengthBytes*/ - (state.$v.BufferedCount | 0)) | 0);
                        new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$4(buffer.Add(256/*InternalBufferLengthBytes*/).Add(-catchupSize), catchupSize).CopyTo(new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$5(lastStripe, 64/*StripeLengthBytes*/));
                        new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$4(buffer, (state.$v.BufferedCount | 0)).CopyTo(new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$5(lastStripe.Add(catchupSize), (state.$v.BufferedCount | 0)));
                        accumulateData = lastStripe;
                    }
                    $.$sih.SIH.XxHashShared.Accumulate512(accumulators, accumulateData, secret.Add((((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0) - 7/*SecretLastAccStartBytes*/) | 0))));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979413024)
            
            //--TRIMMABLE-BOUNDARY-START(210454249504)
            static /*void */ InitializeAccumulators(/*ulong**/ accumulators)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454249504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (Vector256.IsHardwareAccelerated) { ... }
                /*else*/ //if (Vector128.IsHardwareAccelerated) { ... }
                //else 
                {
                    accumulators.SetAt(BigInt(3266489917/*Prime32_3*/), 0);
                    accumulators.SetAt(11400714785074694791n, 1);
                    accumulators.SetAt(14029467366897019727n, 2);
                    accumulators.SetAt(1609587929392839161n, 3);
                    accumulators.SetAt(9650029242287828579n, 4);
                    accumulators.SetAt(BigInt(2246822519/*Prime32_2*/), 5);
                    accumulators.SetAt(2870177450012600261n, 6);
                    accumulators.SetAt(BigInt(2654435761/*Prime32_1*/), 7);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(210454249504)
            
            //--TRIMMABLE-BOUNDARY-START(223339151392)
            static /*ulong */ MergeAccumulators(/*ulong**/ accumulators, /*byte**/ secret, /*ulong*/ start)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339151392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ulong*/ let result64 = start;
                result64 += $.$sih.SIH.XxHashShared.Multiply64To128ThenFold(accumulators.GetAt(0) ^ $.$sih.SIH.XxHashShared.ReadUInt64LE(secret), accumulators.GetAt(1) ^ $.$sih.SIH.XxHashShared.ReadUInt64LE(secret.Add(8)));
                result64 += $.$sih.SIH.XxHashShared.Multiply64To128ThenFold(accumulators.GetAt(2) ^ $.$sih.SIH.XxHashShared.ReadUInt64LE(secret.Add(16)), accumulators.GetAt(3) ^ $.$sih.SIH.XxHashShared.ReadUInt64LE(secret.Add(24)));
                result64 += $.$sih.SIH.XxHashShared.Multiply64To128ThenFold(accumulators.GetAt(4) ^ $.$sih.SIH.XxHashShared.ReadUInt64LE(secret.Add(32)), accumulators.GetAt(5) ^ $.$sih.SIH.XxHashShared.ReadUInt64LE(secret.Add(40)));
                result64 += $.$sih.SIH.XxHashShared.Multiply64To128ThenFold(accumulators.GetAt(6) ^ $.$sih.SIH.XxHashShared.ReadUInt64LE(secret.Add(48)), accumulators.GetAt(7) ^ $.$sih.SIH.XxHashShared.ReadUInt64LE(secret.Add(56)));
                return $.$sih.SIH.XxHashShared.Avalanche(result64);
            }
            //--TRIMMABLE-BOUNDARY-END(223339151392)
            
            //--TRIMMABLE-BOUNDARY-START(231929085984)
            static /*ulong */ Mix16Bytes(/*byte**/ source, /*ulong*/ secretLow, /*ulong*/ secretHigh, /*ulong*/ seed)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(231929085984);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sih.SIH.XxHashShared.Multiply64To128ThenFold($.$sih.SIH.XxHashShared.ReadUInt64LE(source) ^ (BigInt.asUintN(64, secretLow + seed)), $.$sih.SIH.XxHashShared.ReadUInt64LE(source.Add(8)) ^ (BigInt.asUintN(64, secretHigh - seed)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231929085984)
            
            //--TRIMMABLE-BOUNDARY-START(236224053280)
            static /*ulong */ Multiply32To64(/*uint*/ v1, /*uint*/ v2)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(236224053280);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return BigInt.asUintN(64, $.$cast(v1, $.$$.S.UInt64) * BigInt(v2));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236224053280)
            
            //--TRIMMABLE-BOUNDARY-START(38655557664)
            static /*ulong */ Avalanche(/*ulong*/ hash)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655557664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                hash = $.$sih.SIH.XxHashShared.XorShift(hash, 37);
                hash *= 1609587791953885689n;
                hash = $.$sih.SIH.XxHashShared.XorShift(hash, 32);
                return hash;
            }
            //--TRIMMABLE-BOUNDARY-END(38655557664)
            
            //--TRIMMABLE-BOUNDARY-START(240519020576)
            static /*ulong */ Multiply64To128(/*ulong*/ left, /*ulong*/ right, /*out ulong*/ lower)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519020576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.Math.BigMul$6(left, right, lower);
            }
            //--TRIMMABLE-BOUNDARY-END(240519020576)
            
            //--TRIMMABLE-BOUNDARY-START(244813987872)
            static /*ulong */ Multiply64To128ThenFold(/*ulong*/ left, /*ulong*/ right)
            {
                /*ulong*/ let lower;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813987872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ulong*/ let upper = $.$sih.SIH.XxHashShared.Multiply64To128(left, right, $.$ref(() => lower, ($v) => lower = $v, $.$$.S.UInt64));
                return lower ^ upper;
            }
            //--TRIMMABLE-BOUNDARY-END(244813987872)
            
            //--TRIMMABLE-BOUNDARY-START(184684445728)
            static /*void */ DeriveSecretFromSeed(/*byte**/ destinationSecret, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684445728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*byte**/ let defaultSecret = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Byte, $.$sih.SIH.XxHashShared.DefaultSecret);
                    //if (Vector256.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                    /*else*/ //if (Vector128.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                    //else 
                    {
                        for(/*int*/ let i = 0; i < 192/*SecretLengthBytes*/; i += ((8 * 2) | 0))
                        {
                            $.$sih.SIH.XxHashShared.WriteUInt64LE(destinationSecret.Add(i), BigInt.asUintN(64, $.$sih.SIH.XxHashShared.ReadUInt64LE(defaultSecret.Add(i)) + seed));
                            $.$sih.SIH.XxHashShared.WriteUInt64LE(destinationSecret.Add(i).Add(8), BigInt.asUintN(64, $.$sih.SIH.XxHashShared.ReadUInt64LE(defaultSecret.Add(i).Add(8)) - seed));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684445728)
            
            //--TRIMMABLE-BOUNDARY-START(8590786592)
            static /*void */ Accumulate(/*ulong**/ accumulators, /*byte**/ source, /*byte**/ secret, /*int*/ stripesToProcess, /*bool*/ scramble, /*int*/ blockCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte**/ let secretForAccumulate = secret;
                /*byte**/ let secretForScramble = secret.Add((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0)));
                //if (Vector256.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                /*else*/ //if (Vector128.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                //else 
                {
                    for(/*int*/ let j = 0; j < blockCount; j++)
                    {
                        for(/*int*/ let i = 0; i < stripesToProcess; i++)
                        {
                            $.$sih.SIH.XxHashShared.Accumulate512Inlined(accumulators, source, secret.Add((((i * 8/*SecretConsumeRateBytes*/) | 0))));
                            source = source.Add(64/*StripeLengthBytes*/);
                        }
                        if (scramble)
                        {
                            $.$sih.SIH.XxHashShared.ScrambleAccumulators(accumulators, secretForScramble);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590786592)
            
            //--TRIMMABLE-BOUNDARY-START(21475688480)
            static /*void */ Accumulate512(/*ulong**/ accumulators, /*byte**/ source, /*byte**/ secret)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475688480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sih.SIH.XxHashShared.Accumulate512Inlined(accumulators, source, secret);
            }
            //--TRIMMABLE-BOUNDARY-END(21475688480)
            
            //--TRIMMABLE-BOUNDARY-START(25770655776)
            static /*void */ Accumulate512Inlined(/*ulong**/ accumulators, /*byte**/ source, /*byte**/ secret)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770655776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (Vector256.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                /*else*/ //if (Vector128.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                //else 
                {
                    for(/*int*/ let i = 0; i < 8/*AccumulatorCount*/; i++)
                    {
                        /*ulong*/ let sourceVal = $.$sih.SIH.XxHashShared.ReadUInt64LE(source.Add((((8 * i) | 0))));
                        /*ulong*/ let sourceKey = sourceVal ^ $.$sih.SIH.XxHashShared.ReadUInt64LE(secret.Add((((i * 8) | 0))));
                        accumulators.SetAt(sourceVal, i ^ 1);
                        accumulators.SetAt($.$sih.SIH.XxHashShared.Multiply32To64($.$cast(sourceKey, $.$$.S.UInt32), $.$cast((sourceKey >> 32n), $.$$.S.UInt32)), i);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770655776)
            
            //--TRIMMABLE-BOUNDARY-START(17180721184)
            static /*Vector256<ulong> */ Accumulate256(/*Vector256<ulong>*/ accVec, /*byte**/ source, /*Vector256<uint>*/ secret)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Vector256<uint>*/ let sourceVec = $.$$.SRI$1.Vector256.Load($.$$.S.UInt32, $.$cast(source, $.$typePointer($.$$.S.UInt32)));
                /*Vector256<uint>*/ let sourceKey = $.$$.SRI$1.Vector256$$($.$$.S.UInt32).op_ExclusiveOr(sourceVec, secret);
                /*Vector256<uint>*/ let sourceKeyLow = $.$$.SRI$1.Vector256.Shuffle$8(sourceKey, $.$$.SRI$1.Vector256.Create$29(1, 0, 3, 0, 5, 0, 7, 0));
                /*Vector256<uint>*/ let sourceSwap = $.$$.SRI$1.Vector256.Shuffle$8(sourceVec, $.$$.SRI$1.Vector256.Create$29(2, 3, 0, 1, 6, 7, 4, 5));
                /*Vector256<ulong>*/ let sum = $.$$.SRI$1.Vector256$$($.$$.S.UInt64).op_Addition(accVec, $.$$.SRI$1.Vector256.AsUInt64($.$$.S.UInt32, sourceSwap));
                /*Vector256<ulong>*/ let product = /*Avx2.IsSupported ? Avx2.Multiply(sourceKey, sourceKeyLow) : */ $.$$.SRI$1.Vector256$$($.$$.S.UInt64).op_Multiply$2($.$$.SRI$1.Vector256.AsUInt64($.$$.S.UInt32, ($.$$.SRI$1.Vector256$$($.$$.S.UInt32).op_BitwiseAnd(sourceKey, $.$$.SRI$1.Vector256.Create$29(~0, 0, ~0, 0, ~0, 0, ~0, 0)))), $.$$.SRI$1.Vector256.AsUInt64($.$$.S.UInt32, ($.$$.SRI$1.Vector256$$($.$$.S.UInt32).op_BitwiseAnd(sourceKeyLow, $.$$.SRI$1.Vector256.Create$29(~0, 0, ~0, 0, ~0, 0, ~0, 0)))));
                accVec = $.$$.SRI$1.Vector256$$($.$$.S.UInt64).op_Addition(product, sum);
                return accVec;
            }
            //--TRIMMABLE-BOUNDARY-END(17180721184)
            
            //--TRIMMABLE-BOUNDARY-START(12885753888)
            static /*Vector128<ulong> */ Accumulate128(/*Vector128<ulong>*/ accVec, /*byte**/ source, /*Vector128<uint>*/ secret)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Vector128<uint>*/ let sourceVec = $.$$.SRI$1.Vector128.Load($.$$.S.UInt32, $.$cast(source, $.$typePointer($.$$.S.UInt32)));
                /*Vector128<uint>*/ let sourceKey = $.$$.SRI$1.Vector128$$($.$$.S.UInt32).op_ExclusiveOr(sourceVec, secret);
                /*Vector128<uint>*/ let sourceSwap = $.$$.SRI$1.Vector128.Shuffle$8(sourceVec, $.$$.SRI$1.Vector128.Create$29(2, 3, 0, 1));
                /*Vector128<ulong>*/ let sum = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_Addition(accVec, $.$$.SRI$1.Vector128.AsUInt64($.$$.S.UInt32, sourceSwap));
                /*Vector128<ulong>*/ let product = $.$sih.SIH.XxHashShared.MultiplyWideningLower(sourceKey);
                accVec = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_Addition(product, sum);
                return accVec;
            }
            //--TRIMMABLE-BOUNDARY-END(12885753888)
            
            //--TRIMMABLE-BOUNDARY-START(249108955168)
            static /*Vector128<ulong> */ MultiplyWideningLower(/*Vector128<uint>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108955168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (AdvSimd.IsSupported) { ... }
                //else 
                {
                    /*Vector128<uint>*/ let sourceLow = $.$$.SRI$1.Vector128.Shuffle$8(source, $.$$.SRI$1.Vector128.Create$29(1, 0, 3, 0));
                    return /*Sse2.IsSupported ? Sse2.Multiply(source, sourceLow) : */ $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_Multiply$2($.$$.SRI$1.Vector128.AsUInt64($.$$.S.UInt32, ($.$$.SRI$1.Vector128$$($.$$.S.UInt32).op_BitwiseAnd(source, $.$$.SRI$1.Vector128.Create$29(~0, 0, ~0, 0)))), $.$$.SRI$1.Vector128.AsUInt64($.$$.S.UInt32, ($.$$.SRI$1.Vector128$$($.$$.S.UInt32).op_BitwiseAnd(sourceLow, $.$$.SRI$1.Vector128.Create$29(~0, 0, ~0, 0)))));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249108955168)
            
            //--TRIMMABLE-BOUNDARY-START(326418366496)
            static /*void */ ScrambleAccumulators(/*ulong**/ accumulators, /*byte**/ secret)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418366496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (Vector256.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                /*else*/ //if (Vector128.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                //else 
                {
                    for(/*int*/ let i = 0; i < 8/*AccumulatorCount*/; i++)
                    {
                        /*ulong*/ let xorShift = $.$sih.SIH.XxHashShared.XorShift(accumulators.$v, 47);
                        /*ulong*/ let xorWithKey = xorShift ^ $.$sih.SIH.XxHashShared.ReadUInt64LE(secret);
                        accumulators.$v = BigInt.asUintN(64, xorWithKey * BigInt(2654435761/*Prime32_1*/));
                        accumulators = accumulators.Add(1);
                        secret = secret.Add(8);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(326418366496)
            
            //--TRIMMABLE-BOUNDARY-START(322123399200)
            static /*Vector256<ulong> */ ScrambleAccumulator256(/*Vector256<ulong>*/ accVec, /*Vector256<ulong>*/ secret)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123399200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Vector256<ulong>*/ let xorShift = $.$$.SRI$1.Vector256$$($.$$.S.UInt64).op_ExclusiveOr(accVec, $.$$.SRI$1.Vector256.ShiftRightLogical$8(accVec, 47));
                /*Vector256<ulong>*/ let xorWithKey = $.$$.SRI$1.Vector256$$($.$$.S.UInt64).op_ExclusiveOr(xorShift, secret);
                accVec = $.$$.SRI$1.Vector256$$($.$$.S.UInt64).op_Multiply$2(xorWithKey, $.$$.SRI$1.Vector256.Create$32($.$cast(2654435761/*Prime32_1*/, $.$$.S.UInt64)));
                return accVec;
            }
            //--TRIMMABLE-BOUNDARY-END(322123399200)
            
            //--TRIMMABLE-BOUNDARY-START(317828431904)
            static /*Vector128<ulong> */ ScrambleAccumulator128(/*Vector128<ulong>*/ accVec, /*Vector128<ulong>*/ secret)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828431904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Vector128<ulong>*/ let xorShift = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr(accVec, $.$$.SRI$1.Vector128.ShiftRightLogical$8(accVec, 47));
                /*Vector128<ulong>*/ let xorWithKey = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr(xorShift, secret);
                accVec = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_Multiply$2(xorWithKey, $.$$.SRI$1.Vector128.Create$32($.$cast(2654435761/*Prime32_1*/, $.$$.S.UInt64)));
                return accVec;
            }
            //--TRIMMABLE-BOUNDARY-END(317828431904)
            
            //--TRIMMABLE-BOUNDARY-START(360778104864)
            static /*ulong */ XorShift(/*ulong*/ value, /*int*/ shift)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778104864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(shift >= 0 && shift < 64, "shift >= 0 && shift < 64");
                return value ^ (value >> BigInt(shift));
            }
            //--TRIMMABLE-BOUNDARY-END(360778104864)
            
            //--TRIMMABLE-BOUNDARY-START(300648562720)
            static /*uint */ ReadUInt32LE(/*byte**/ data)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(300648562720);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.BitConverter.IsLittleEndian ? $.$$.SRC.Unsafe.ReadUnaligned$1($.$$.S.UInt32, data) : $.$$.SBB.BinaryPrimitives.ReverseEndianness$20($.$$.SRC.Unsafe.ReadUnaligned$1($.$$.S.UInt32, data));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(300648562720)
            
            //--TRIMMABLE-BOUNDARY-START(304943530016)
            static /*ulong */ ReadUInt64LE(/*byte**/ data)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(304943530016);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.BitConverter.IsLittleEndian ? $.$$.SRC.Unsafe.ReadUnaligned$1($.$$.S.UInt64, data) : $.$$.SBB.BinaryPrimitives.ReverseEndianness$21($.$$.SRC.Unsafe.ReadUnaligned$1($.$$.S.UInt64, data));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(304943530016)
            
            //--TRIMMABLE-BOUNDARY-START(356483137568)
            static /*void */ WriteUInt64LE(/*byte**/ data, /*ulong*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483137568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.BitConverter.IsLittleEndian)
                {
                    value = $.$$.SBB.BinaryPrimitives.ReverseEndianness$21(value);
                }
                $.$$.SRC.Unsafe.WriteUnaligned$1($.$$.S.UInt64, data, value);
            }
            //--TRIMMABLE-BOUNDARY-END(356483137568)
            
            //--TRIMMABLE-BOUNDARY-START(917536)
            static $_State;
            static get State()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(917536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sih.SIH.XxHashShared;
                return $cls.$_State ??= $asm.$nstr(`$sih.SIH.XxHashShared.State`, ($self) => class State extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(8590852128)
                    /*ulong[8]*/ Accumulators = [];
                    //--TRIMMABLE-BOUNDARY-END(8590852128)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475754016)
                    /*byte[192]*/ Secret = [];
                    //--TRIMMABLE-BOUNDARY-END(21475754016)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885819424)
                    /*byte[256]*/ Buffer = [];
                    //--TRIMMABLE-BOUNDARY-END(12885819424)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180786720)
                    /*uint*/ BufferedCount = 0;
                    //--TRIMMABLE-BOUNDARY-END(17180786720)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065688608)
                    /*ulong*/ StripesProcessedInCurrentBlock = 0n;
                    //--TRIMMABLE-BOUNDARY-END(30065688608)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360655904)
                    /*ulong*/ TotalLength = 0n;
                    //--TRIMMABLE-BOUNDARY-END(34360655904)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770721312)
                    /*ulong*/ Seed = 0n;
                    //--TRIMMABLE-BOUNDARY-END(25770721312)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295884832)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295884832);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295884832)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295884832)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295884832)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        //FixedSizeArray(ulong, 8)
                        copy.Accumulators = [...this.Accumulators];
                        $.$$.S.Array.CopyMetadata(copy.Accumulators, this.Accumulators)
                        //FixedSizeArray(byte, 192)
                        copy.Secret = [...this.Secret];
                        $.$$.S.Array.CopyMetadata(copy.Secret, this.Secret)
                        //FixedSizeArray(byte, 256)
                        copy.Buffer = [...this.Buffer];
                        $.$$.S.Array.CopyMetadata(copy.Buffer, this.Buffer)
                        copy.BufferedCount = this.BufferedCount;
                        copy.StripesProcessedInCurrentBlock = this.StripesProcessedInCurrentBlock;
                        copy.TotalLength = this.TotalLength;
                        copy.Seed = this.Seed;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590852128)
                        //FixedSizeArray(ulong*, 8)
                        let $t7 = this.Accumulators;
                        $.$$.S.Array.AddMetadata($t7, $.$$.S.UInt64.$type, null, null);
                        for (let $i = 0; $i < 8; $i++)
                        {
                            $t7[$i] = [];
                        }
                        //--TRIMMABLE-BOUNDARY-END(8590852128)
                        
                        //--TRIMMABLE-BOUNDARY-START(21475754016)
                        //FixedSizeArray(byte*, 192)
                        let $t8 = this.Secret;
                        $.$$.S.Array.AddMetadata($t8, $.$$.S.Byte.$type, null, null);
                        for (let $i = 0; $i < 192; $i++)
                        {
                            $t8[$i] = [];
                        }
                        //--TRIMMABLE-BOUNDARY-END(21475754016)
                        
                        //--TRIMMABLE-BOUNDARY-START(12885819424)
                        //FixedSizeArray(byte*, 256)
                        let $t9 = this.Buffer;
                        $.$$.S.Array.AddMetadata($t9, $.$$.S.Byte.$type, null, null);
                        for (let $i = 0; $i < 256; $i++)
                        {
                            $t9[$i] = [];
                        }
                        //--TRIMMABLE-BOUNDARY-END(12885819424)
                        
                    }
                    static $h = 917536;
                    static $z = 540;
                    static $f = 0b10100010000001010000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852128),
    {
      "t": $.$typePointer($.$$.S.UInt64).$h,
      "n": "Accumulators",
      "d": 917536,
      "h": 8590852128,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590852128),
//--TRIMMABLE-BOUNDARY-START(21475754016),
    {
      "t": $.$typePointer($.$$.S.Byte).$h,
      "n": "Secret",
      "d": 917536,
      "h": 21475754016,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21475754016),
//--TRIMMABLE-BOUNDARY-START(12885819424),
    {
      "t": $.$typePointer($.$$.S.Byte).$h,
      "n": "Buffer",
      "d": 917536,
      "h": 12885819424,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885819424),
//--TRIMMABLE-BOUNDARY-START(17180786720),
    {
      "t": 720897,
      "n": "BufferedCount",
      "d": 917536,
      "h": 17180786720,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180786720),
//--TRIMMABLE-BOUNDARY-START(30065688608),
    {
      "t": 983041,
      "n": "StripesProcessedInCurrentBlock",
      "d": 917536,
      "h": 30065688608,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(30065688608),
//--TRIMMABLE-BOUNDARY-START(34360655904),
    {
      "t": 983041,
      "n": "TotalLength",
      "d": 917536,
      "h": 34360655904,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(34360655904),
//--TRIMMABLE-BOUNDARY-START(25770721312),
    {
      "t": 983041,
      "n": "Seed",
      "d": 917536,
      "h": 25770721312,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(25770721312)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884832),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917536,
      "h": 4295884832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884832)
  ],
  "d": 852000,
  "h": 917536,
  "a": [
    {
      "t": 148176897,
      "c": 13033078785,
      "a": [
        {
          "v": 3,
          "t": 143654913
        }
      ]
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.XxHashShared+State`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}XxHashShared${separator}State`; }
                }, $cls, ($v) => $cls.$_State = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917536)
            
            static $h = 852000;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540459552),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569347616,
        "f": 50331681
      },
      "n": "DefaultSecret",
      "d": 852000,
      "h": 51540459552,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(51540459552)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(206159282208),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": 917536,
          "f": 4
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "Initialize",
      "d": 852000,
      "h": 206159282208,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(206159282208),
//--TRIMMABLE-BOUNDARY-START(309238497312),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": 917536,
          "f": 4
        }
      ],
      "n": "Reset",
      "d": 852000,
      "h": 309238497312,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(309238497312),
//--TRIMMABLE-BOUNDARY-START(313533464608),
    {
      "r": 983041,
      "p": [
        {
          "n": "hash",
          "p": 983041
        },
        {
          "n": "length",
          "p": 720897
        }
      ],
      "n": "Rrmxmx",
      "d": 852000,
      "h": 313533464608,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(313533464608),
//--TRIMMABLE-BOUNDARY-START(201864314912),
    {
      "r": 65537,
      "p": [
        {
          "n": "accumulators",
          "p": $.$typePointer($.$$.S.UInt64).$h
        },
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "secret",
          "p": $.$typePointer($.$$.S.Byte).$h
        }
      ],
      "n": "HashInternalLoop",
      "d": 852000,
      "h": 201864314912,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(201864314912),
//--TRIMMABLE-BOUNDARY-START(42950524960),
    {
      "r": 65537,
      "p": [
        {
          "n": "accumulators",
          "p": $.$typePointer($.$$.S.UInt64).$h
        },
        {
          "n": "stripesSoFar",
          "p": 983041,
          "f": 4
        },
        {
          "n": "stripesPerBlock",
          "p": 983041
        },
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "stripes",
          "p": 983041
        },
        {
          "n": "secret",
          "p": $.$typePointer($.$$.S.Byte).$h
        }
      ],
      "n": "ConsumeStripes",
      "d": 852000,
      "h": 42950524960,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950524960),
//--TRIMMABLE-BOUNDARY-START(34360590368),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": 917536,
          "f": 4
        },
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Append",
      "d": 852000,
      "h": 34360590368,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360590368),
//--TRIMMABLE-BOUNDARY-START(47245492256),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": 917536,
          "f": 4
        },
        {
          "n": "accumulators",
          "p": $.$typePointer($.$$.S.UInt64).$h
        }
      ],
      "n": "CopyAccumulators",
      "d": 852000,
      "h": 47245492256,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245492256),
//--TRIMMABLE-BOUNDARY-START(188979413024),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": 917536,
          "f": 4
        },
        {
          "n": "accumulators",
          "p": $.$typePointer($.$$.S.UInt64).$h
        },
        {
          "n": "secret",
          "p": $.$typePointer($.$$.S.Byte).$h
        }
      ],
      "n": "DigestLong",
      "d": 852000,
      "h": 188979413024,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(188979413024),
//--TRIMMABLE-BOUNDARY-START(210454249504),
    {
      "r": 65537,
      "p": [
        {
          "n": "accumulators",
          "p": $.$typePointer($.$$.S.UInt64).$h
        }
      ],
      "n": "InitializeAccumulators",
      "d": 852000,
      "h": 210454249504,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(210454249504),
//--TRIMMABLE-BOUNDARY-START(223339151392),
    {
      "r": 983041,
      "p": [
        {
          "n": "accumulators",
          "p": $.$typePointer($.$$.S.UInt64).$h
        },
        {
          "n": "secret",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "start",
          "p": 983041
        }
      ],
      "n": "MergeAccumulators",
      "d": 852000,
      "h": 223339151392,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(223339151392),
//--TRIMMABLE-BOUNDARY-START(231929085984),
    {
      "r": 983041,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "secretLow",
          "p": 983041
        },
        {
          "n": "secretHigh",
          "p": 983041
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "Mix16Bytes",
      "d": 852000,
      "h": 231929085984,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(231929085984),
//--TRIMMABLE-BOUNDARY-START(236224053280),
    {
      "r": 983041,
      "p": [
        {
          "n": "v1",
          "p": 720897
        },
        {
          "n": "v2",
          "p": 720897
        }
      ],
      "n": "Multiply32To64",
      "d": 852000,
      "h": 236224053280,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(236224053280),
//--TRIMMABLE-BOUNDARY-START(38655557664),
    {
      "r": 983041,
      "p": [
        {
          "n": "hash",
          "p": 983041
        }
      ],
      "n": "Avalanche",
      "d": 852000,
      "h": 38655557664,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655557664),
//--TRIMMABLE-BOUNDARY-START(240519020576),
    {
      "r": 983041,
      "p": [
        {
          "n": "left",
          "p": 983041
        },
        {
          "n": "right",
          "p": 983041
        },
        {
          "n": "lower",
          "p": 983041,
          "f": 2
        }
      ],
      "n": "Multiply64To128",
      "d": 852000,
      "h": 240519020576,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(240519020576),
//--TRIMMABLE-BOUNDARY-START(244813987872),
    {
      "r": 983041,
      "p": [
        {
          "n": "left",
          "p": 983041
        },
        {
          "n": "right",
          "p": 983041
        }
      ],
      "n": "Multiply64To128ThenFold",
      "d": 852000,
      "h": 244813987872,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(244813987872),
//--TRIMMABLE-BOUNDARY-START(184684445728),
    {
      "r": 65537,
      "p": [
        {
          "n": "destinationSecret",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "DeriveSecretFromSeed",
      "d": 852000,
      "h": 184684445728,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(184684445728),
//--TRIMMABLE-BOUNDARY-START(8590786592),
    {
      "r": 65537,
      "p": [
        {
          "n": "accumulators",
          "p": $.$typePointer($.$$.S.UInt64).$h
        },
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "secret",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "stripesToProcess",
          "p": 655361
        },
        {
          "n": "scramble",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "blockCount",
          "p": 655361,
          "f": 65,
          "v": 1
        }
      ],
      "n": "Accumulate",
      "d": 852000,
      "h": 8590786592,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8590786592),
//--TRIMMABLE-BOUNDARY-START(21475688480),
    {
      "r": 65537,
      "p": [
        {
          "n": "accumulators",
          "p": $.$typePointer($.$$.S.UInt64).$h
        },
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "secret",
          "p": $.$typePointer($.$$.S.Byte).$h
        }
      ],
      "n": "Accumulate512",
      "d": 852000,
      "h": 21475688480,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475688480),
//--TRIMMABLE-BOUNDARY-START(25770655776),
    {
      "r": 65537,
      "p": [
        {
          "n": "accumulators",
          "p": $.$typePointer($.$$.S.UInt64).$h
        },
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "secret",
          "p": $.$typePointer($.$$.S.Byte).$h
        }
      ],
      "n": "Accumulate512Inlined",
      "d": 852000,
      "h": 25770655776,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770655776),
//--TRIMMABLE-BOUNDARY-START(17180721184),
    {
      "r": $.$$.SRI$1.Vector256$$($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "accVec",
          "p": $.$$.SRI$1.Vector256$$($.$$.S.UInt64).$h
        },
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "secret",
          "p": $.$$.SRI$1.Vector256$$($.$$.S.UInt32).$h
        }
      ],
      "n": "Accumulate256",
      "d": 852000,
      "h": 17180721184,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180721184),
//--TRIMMABLE-BOUNDARY-START(12885753888),
    {
      "r": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "accVec",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        },
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "secret",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt32).$h
        }
      ],
      "n": "Accumulate128",
      "d": 852000,
      "h": 12885753888,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885753888),
//--TRIMMABLE-BOUNDARY-START(249108955168),
    {
      "r": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt32).$h
        }
      ],
      "n": "MultiplyWideningLower",
      "d": 852000,
      "h": 249108955168,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(249108955168),
//--TRIMMABLE-BOUNDARY-START(326418366496),
    {
      "r": 65537,
      "p": [
        {
          "n": "accumulators",
          "p": $.$typePointer($.$$.S.UInt64).$h
        },
        {
          "n": "secret",
          "p": $.$typePointer($.$$.S.Byte).$h
        }
      ],
      "n": "ScrambleAccumulators",
      "d": 852000,
      "h": 326418366496,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(326418366496),
//--TRIMMABLE-BOUNDARY-START(322123399200),
    {
      "r": $.$$.SRI$1.Vector256$$($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "accVec",
          "p": $.$$.SRI$1.Vector256$$($.$$.S.UInt64).$h
        },
        {
          "n": "secret",
          "p": $.$$.SRI$1.Vector256$$($.$$.S.UInt64).$h
        }
      ],
      "n": "ScrambleAccumulator256",
      "d": 852000,
      "h": 322123399200,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(322123399200),
//--TRIMMABLE-BOUNDARY-START(317828431904),
    {
      "r": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "accVec",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        },
        {
          "n": "secret",
          "p": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h
        }
      ],
      "n": "ScrambleAccumulator128",
      "d": 852000,
      "h": 317828431904,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(317828431904),
//--TRIMMABLE-BOUNDARY-START(360778104864),
    {
      "r": 983041,
      "p": [
        {
          "n": "value",
          "p": 983041
        },
        {
          "n": "shift",
          "p": 655361
        }
      ],
      "n": "XorShift",
      "d": 852000,
      "h": 360778104864,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(360778104864),
//--TRIMMABLE-BOUNDARY-START(300648562720),
    {
      "r": 720897,
      "p": [
        {
          "n": "data",
          "p": $.$typePointer($.$$.S.Byte).$h
        }
      ],
      "n": "ReadUInt32LE",
      "d": 852000,
      "h": 300648562720,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(300648562720),
//--TRIMMABLE-BOUNDARY-START(304943530016),
    {
      "r": 983041,
      "p": [
        {
          "n": "data",
          "p": $.$typePointer($.$$.S.Byte).$h
        }
      ],
      "n": "ReadUInt64LE",
      "d": 852000,
      "h": 304943530016,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(304943530016),
//--TRIMMABLE-BOUNDARY-START(356483137568),
    {
      "r": 65537,
      "p": [
        {
          "n": "data",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "value",
          "p": 983041
        }
      ],
      "n": "WriteUInt64LE",
      "d": 852000,
      "h": 356483137568,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(356483137568)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(352188170272),
    {
      "t": 655361,
      "n": "StripeLengthBytes",
      "d": 852000,
      "h": 352188170272,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(352188170272),
//--TRIMMABLE-BOUNDARY-START(339303268384),
    {
      "t": 655361,
      "n": "SecretLengthBytes",
      "d": 852000,
      "h": 339303268384,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(339303268384),
//--TRIMMABLE-BOUNDARY-START(347893202976),
    {
      "t": 655361,
      "n": "SecretSizeMin",
      "d": 852000,
      "h": 347893202976,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(347893202976),
//--TRIMMABLE-BOUNDARY-START(335008301088),
    {
      "t": 655361,
      "n": "SecretLastAccStartBytes",
      "d": 852000,
      "h": 335008301088,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(335008301088),
//--TRIMMABLE-BOUNDARY-START(330713333792),
    {
      "t": 655361,
      "n": "SecretConsumeRateBytes",
      "d": 852000,
      "h": 330713333792,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(330713333792),
//--TRIMMABLE-BOUNDARY-START(343598235680),
    {
      "t": 655361,
      "n": "SecretMergeAccsStartBytes",
      "d": 852000,
      "h": 343598235680,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(343598235680),
//--TRIMMABLE-BOUNDARY-START(253403922464),
    {
      "t": 655361,
      "n": "NumStripesPerBlock",
      "d": 852000,
      "h": 253403922464,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(253403922464),
//--TRIMMABLE-BOUNDARY-START(30065623072),
    {
      "t": 655361,
      "n": "AccumulatorCount",
      "d": 852000,
      "h": 30065623072,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065623072),
//--TRIMMABLE-BOUNDARY-START(227634118688),
    {
      "t": 655361,
      "n": "MidSizeMaxBytes",
      "d": 852000,
      "h": 227634118688,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(227634118688),
//--TRIMMABLE-BOUNDARY-START(219044184096),
    {
      "t": 655361,
      "n": "InternalBufferStripes",
      "d": 852000,
      "h": 219044184096,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219044184096),
//--TRIMMABLE-BOUNDARY-START(214749216800),
    {
      "t": 655361,
      "n": "InternalBufferLengthBytes",
      "d": 852000,
      "h": 214749216800,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(214749216800),
//--TRIMMABLE-BOUNDARY-START(115964968992),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_0",
      "d": 852000,
      "h": 115964968992,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964968992),
//--TRIMMABLE-BOUNDARY-START(120259936288),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_1",
      "d": 852000,
      "h": 120259936288,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259936288),
//--TRIMMABLE-BOUNDARY-START(150324707360),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_2",
      "d": 852000,
      "h": 150324707360,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324707360),
//--TRIMMABLE-BOUNDARY-START(154619674656),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_3",
      "d": 852000,
      "h": 154619674656,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619674656),
//--TRIMMABLE-BOUNDARY-START(158914641952),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_4",
      "d": 852000,
      "h": 158914641952,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914641952),
//--TRIMMABLE-BOUNDARY-START(163209609248),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_5",
      "d": 852000,
      "h": 163209609248,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209609248),
//--TRIMMABLE-BOUNDARY-START(167504576544),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_6",
      "d": 852000,
      "h": 167504576544,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167504576544),
//--TRIMMABLE-BOUNDARY-START(171799543840),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_7",
      "d": 852000,
      "h": 171799543840,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171799543840),
//--TRIMMABLE-BOUNDARY-START(176094511136),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_8",
      "d": 852000,
      "h": 176094511136,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176094511136),
//--TRIMMABLE-BOUNDARY-START(180389478432),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_9",
      "d": 852000,
      "h": 180389478432,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180389478432),
//--TRIMMABLE-BOUNDARY-START(124554903584),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_10",
      "d": 852000,
      "h": 124554903584,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554903584),
//--TRIMMABLE-BOUNDARY-START(128849870880),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_11",
      "d": 852000,
      "h": 128849870880,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849870880),
//--TRIMMABLE-BOUNDARY-START(133144838176),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_12",
      "d": 852000,
      "h": 133144838176,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144838176),
//--TRIMMABLE-BOUNDARY-START(137439805472),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_13",
      "d": 852000,
      "h": 137439805472,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439805472),
//--TRIMMABLE-BOUNDARY-START(141734772768),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_14",
      "d": 852000,
      "h": 141734772768,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734772768),
//--TRIMMABLE-BOUNDARY-START(146029740064),
    {
      "t": 983041,
      "n": "DefaultSecretUInt64_15",
      "d": 852000,
      "h": 146029740064,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029740064),
//--TRIMMABLE-BOUNDARY-START(55835426848),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_0",
      "d": 852000,
      "h": 55835426848,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835426848),
//--TRIMMABLE-BOUNDARY-START(60130394144),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_1",
      "d": 852000,
      "h": 60130394144,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130394144),
//--TRIMMABLE-BOUNDARY-START(81605230624),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_2",
      "d": 852000,
      "h": 81605230624,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605230624),
//--TRIMMABLE-BOUNDARY-START(85900197920),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_3",
      "d": 852000,
      "h": 85900197920,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900197920),
//--TRIMMABLE-BOUNDARY-START(90195165216),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_4",
      "d": 852000,
      "h": 90195165216,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195165216),
//--TRIMMABLE-BOUNDARY-START(94490132512),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_5",
      "d": 852000,
      "h": 94490132512,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490132512),
//--TRIMMABLE-BOUNDARY-START(98785099808),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_6",
      "d": 852000,
      "h": 98785099808,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98785099808),
//--TRIMMABLE-BOUNDARY-START(103080067104),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_7",
      "d": 852000,
      "h": 103080067104,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103080067104),
//--TRIMMABLE-BOUNDARY-START(107375034400),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_8",
      "d": 852000,
      "h": 107375034400,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107375034400),
//--TRIMMABLE-BOUNDARY-START(111670001696),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_9",
      "d": 852000,
      "h": 111670001696,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670001696),
//--TRIMMABLE-BOUNDARY-START(64425361440),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_10",
      "d": 852000,
      "h": 64425361440,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425361440),
//--TRIMMABLE-BOUNDARY-START(68720328736),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_11",
      "d": 852000,
      "h": 68720328736,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720328736),
//--TRIMMABLE-BOUNDARY-START(73015296032),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_12",
      "d": 852000,
      "h": 73015296032,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015296032),
//--TRIMMABLE-BOUNDARY-START(77310263328),
    {
      "t": 983041,
      "n": "DefaultSecret3UInt64_13",
      "d": 852000,
      "h": 77310263328,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310263328),
//--TRIMMABLE-BOUNDARY-START(279173726240),
    {
      "t": 983041,
      "n": "Prime64_1",
      "d": 852000,
      "h": 279173726240,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(279173726240),
//--TRIMMABLE-BOUNDARY-START(283468693536),
    {
      "t": 983041,
      "n": "Prime64_2",
      "d": 852000,
      "h": 283468693536,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(283468693536),
//--TRIMMABLE-BOUNDARY-START(287763660832),
    {
      "t": 983041,
      "n": "Prime64_3",
      "d": 852000,
      "h": 287763660832,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(287763660832),
//--TRIMMABLE-BOUNDARY-START(292058628128),
    {
      "t": 983041,
      "n": "Prime64_4",
      "d": 852000,
      "h": 292058628128,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(292058628128),
//--TRIMMABLE-BOUNDARY-START(296353595424),
    {
      "t": 983041,
      "n": "Prime64_5",
      "d": 852000,
      "h": 296353595424,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(296353595424),
//--TRIMMABLE-BOUNDARY-START(257698889760),
    {
      "t": 720897,
      "n": "Prime32_1",
      "d": 852000,
      "h": 257698889760,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(257698889760),
//--TRIMMABLE-BOUNDARY-START(261993857056),
    {
      "t": 720897,
      "n": "Prime32_2",
      "d": 852000,
      "h": 261993857056,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(261993857056),
//--TRIMMABLE-BOUNDARY-START(266288824352),
    {
      "t": 720897,
      "n": "Prime32_3",
      "d": 852000,
      "h": 266288824352,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(266288824352),
//--TRIMMABLE-BOUNDARY-START(270583791648),
    {
      "t": 720897,
      "n": "Prime32_4",
      "d": 852000,
      "h": 270583791648,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(270583791648),
//--TRIMMABLE-BOUNDARY-START(274878758944),
    {
      "t": 720897,
      "n": "Prime32_5",
      "d": 852000,
      "h": 274878758944,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(274878758944)
  ],
  "h": 852000,
  "a": [
    {
      "t": 133693441,
      "c": 4428660737
    }
  ]
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sih.SIH.XxHashShared.State ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.XxHashShared`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}XxHashShared`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852000)
        
        

        //--TRIMMABLE-BOUNDARY-START(589856)
        $asm.$cls(`$sih.SIH.XxHash32`, ($self) => class XxHash32 extends $.$sih.SIH.NonCryptographicHashAlgorithm
        {
            //--TRIMMABLE-BOUNDARY-START(655392)
            static $_State;
            static get State()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sih.SIH.XxHash32;
                return $cls.$_State ??= $asm.$nstr(`$sih.SIH.XxHash32.State`, ($self) => class State extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295622688)
                    /*uint*/ _acc1 = 0;
                    //--TRIMMABLE-BOUNDARY-END(4295622688)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590589984)
                    /*uint*/ _acc2 = 0;
                    //--TRIMMABLE-BOUNDARY-END(8590589984)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557280)
                    /*uint*/ _acc3 = 0;
                    //--TRIMMABLE-BOUNDARY-END(12885557280)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180524576)
                    /*uint*/ _acc4 = 0;
                    //--TRIMMABLE-BOUNDARY-END(17180524576)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770459168)
                    /*uint*/ _smallAcc = 0;
                    //--TRIMMABLE-BOUNDARY-END(25770459168)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475491872)
                    /*bool*/ _hadFullStripe = false;
                    //--TRIMMABLE-BOUNDARY-END(21475491872)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360393760)
                    $ctor$3(/*uint*/ seed)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34360393760);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._acc1 = ((seed + ((2654435761/*Prime32_1*/ + 2246822519/*Prime32_2*/) >>> 0)) >>> 0);
                            this._acc2 = ((seed + 2246822519/*Prime32_2*/) >>> 0);
                            this._acc3 = seed;
                            this._acc4 = ((seed - 2654435761/*Prime32_1*/) >>> 0);
                            this._smallAcc = ((seed + 374761393/*Prime32_5*/) >>> 0);
                            this._hadFullStripe = false;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360393760)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540262944)
                    /*void */ ProcessStripe(/*ReadOnlySpan<byte>*/ source)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540262944);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4(source.Length >= 16/*StripeSize*/, "source.Length >= StripeSize");
                        source = source.Slice(0, 16/*StripeSize*/);
                        this._acc1 = $.$sih.SIH.XxHash32.State.ApplyRound(this._acc1, source);
                        this._acc2 = $.$sih.SIH.XxHash32.State.ApplyRound(this._acc2, source.Slice$1(4));
                        this._acc3 = $.$sih.SIH.XxHash32.State.ApplyRound(this._acc3, source.Slice$1(((2 * 4) | 0)));
                        this._acc4 = $.$sih.SIH.XxHash32.State.ApplyRound(this._acc4, source.Slice$1(((3 * 4) | 0)));
                        this._hadFullStripe = true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540262944)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245295648)
                    /*uint */ Converge()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245295648);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (((((($.$$.SN$1.BitOperations.RotateLeft(this._acc1, 1) + $.$$.SN$1.BitOperations.RotateLeft(this._acc2, 7)) >>> 0) + $.$$.SN$1.BitOperations.RotateLeft(this._acc3, 12)) >>> 0) + $.$$.SN$1.BitOperations.RotateLeft(this._acc4, 18)) >>> 0);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245295648)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655361056)
                    static /*uint */ ApplyRound(/*uint*/ acc, /*ReadOnlySpan<byte>*/ lane)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655361056);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        acc += (($.$$.SBB.BinaryPrimitives.ReadUInt32LittleEndian(lane) * 2246822519/*Prime32_2*/) >>> 0);
                        acc = $.$$.SN$1.BitOperations.RotateLeft(acc, 13);
                        acc *= 2654435761/*Prime32_1*/;
                        return acc;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655361056)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950328352)
                    /*uint */ Complete(/*int*/ length, /*ReadOnlySpan<byte>*/ remaining)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950328352);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*uint*/ let acc = this._hadFullStripe ? this.Converge() : this._smallAcc;
                        acc += (length >>> 0);
                        while(remaining.Length >= 4)
                        {
                            /*uint*/ let lane = $.$$.SBB.BinaryPrimitives.ReadUInt32LittleEndian(remaining);
                            acc += ((lane * 3266489917/*Prime32_3*/) >>> 0);
                            acc = $.$$.SN$1.BitOperations.RotateLeft(acc, 17);
                            acc *= 668265263/*Prime32_4*/;
                            remaining = remaining.Slice$1(4);
                        }
                        for(/*int*/ let i = 0; i < remaining.Length; i++)
                        {
                            /*uint*/ let lane = remaining._reference.GetAt(i);
                            acc += ((lane * 374761393/*Prime32_5*/) >>> 0);
                            acc = $.$$.SN$1.BitOperations.RotateLeft(acc, 11);
                            acc *= 2654435761/*Prime32_1*/;
                        }
                        acc ^= (acc >>> 15);
                        acc *= 2246822519/*Prime32_2*/;
                        acc ^= (acc >>> 13);
                        acc *= 3266489917/*Prime32_3*/;
                        acc ^= (acc >>> 16);
                        return acc;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950328352)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065426464)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065426464);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065426464)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065426464)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065426464)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._acc1 = this._acc1;
                        copy._acc2 = this._acc2;
                        copy._acc3 = this._acc3;
                        copy._acc4 = this._acc4;
                        copy._smallAcc = this._smallAcc;
                        copy._hadFullStripe = this._hadFullStripe;
                        return copy;
                    }
                    static $h = 655392;
                    static $z = 21;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540262944),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "ProcessStripe",
      "d": 655392,
      "h": 51540262944,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51540262944),
//--TRIMMABLE-BOUNDARY-START(47245295648),
    {
      "r": 720897,
      "n": "Converge",
      "d": 655392,
      "h": 47245295648,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245295648),
//--TRIMMABLE-BOUNDARY-START(38655361056),
    {
      "r": 720897,
      "p": [
        {
          "n": "acc",
          "p": 720897
        },
        {
          "n": "lane",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "ApplyRound",
      "d": 655392,
      "h": 38655361056,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38655361056),
//--TRIMMABLE-BOUNDARY-START(42950328352),
    {
      "r": 720897,
      "p": [
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "remaining",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Complete",
      "d": 655392,
      "h": 42950328352,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42950328352)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622688),
    {
      "t": 720897,
      "n": "_acc1",
      "d": 655392,
      "h": 4295622688,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622688),
//--TRIMMABLE-BOUNDARY-START(8590589984),
    {
      "t": 720897,
      "n": "_acc2",
      "d": 655392,
      "h": 8590589984,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590589984),
//--TRIMMABLE-BOUNDARY-START(12885557280),
    {
      "t": 720897,
      "n": "_acc3",
      "d": 655392,
      "h": 12885557280,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885557280),
//--TRIMMABLE-BOUNDARY-START(17180524576),
    {
      "t": 720897,
      "n": "_acc4",
      "d": 655392,
      "h": 17180524576,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180524576),
//--TRIMMABLE-BOUNDARY-START(25770459168),
    {
      "t": 720897,
      "n": "_smallAcc",
      "d": 655392,
      "h": 25770459168,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770459168),
//--TRIMMABLE-BOUNDARY-START(21475491872),
    {
      "t": 262145,
      "n": "_hadFullStripe",
      "d": 655392,
      "h": 21475491872,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475491872)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360393760),
    {
      "p": [
        {
          "n": "seed",
          "p": 720897
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655392,
      "h": 34360393760,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34360393760),
//--TRIMMABLE-BOUNDARY-START(30065426464),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655392,
      "h": 30065426464,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065426464)
  ],
  "d": 589856,
  "h": 655392
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.XxHash32+State`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}XxHash32${separator}State`; }
                }, $cls, ($v) => $cls.$_State = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655392)
            
            //--TRIMMABLE-BOUNDARY-START(68720066592)
            /*int*/ static HashSize = 4;
            //--TRIMMABLE-BOUNDARY-END(68720066592)
            
            //--TRIMMABLE-BOUNDARY-START(81604968480)
            /*int*/ static StripeSize = 16;
            //--TRIMMABLE-BOUNDARY-END(81604968480)
            
            //--TRIMMABLE-BOUNDARY-START(12885491744)
            /*uint*/ _seed = 0;
            //--TRIMMABLE-BOUNDARY-END(12885491744)
            
            //--TRIMMABLE-BOUNDARY-START(17180459040)
            /*State*/ _state;
            //--TRIMMABLE-BOUNDARY-END(17180459040)
            
            //--TRIMMABLE-BOUNDARY-START(4295557152)
            /*byte[]?*/ _holdback = null;
            //--TRIMMABLE-BOUNDARY-END(4295557152)
            
            //--TRIMMABLE-BOUNDARY-START(8590524448)
            /*int*/ _length = 0;
            //--TRIMMABLE-BOUNDARY-END(8590524448)
            
            //--TRIMMABLE-BOUNDARY-START(21475426336)
            $ctor$2()
            {
                this.$ctor$3(0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426336);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426336)
            
            //--TRIMMABLE-BOUNDARY-START(25770393632)
            $ctor$3(/*int*/ seed)
            {
                super.$ctor$1(4/*HashSize*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770393632);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._seed = (seed >>> 0);
                    this.Reset();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770393632)
            
            //--TRIMMABLE-BOUNDARY-START(30065360928)
            $ctor$4(/*uint*/ seed, /*State*/ state, /*byte[]?*/ holdback, /*int*/ length)
            {
                super.$ctor$1(4/*HashSize*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065360928);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._seed = seed;
                    this._state = $.$clone(state);
                    if ((length & 15) > 0)
                    {
                        this._holdback = $.$cast((holdback?.Clone() ?? null), $.$typeArray($.$$.S.Byte));
                    }
                    this._length = length;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065360928)
            
            //--TRIMMABLE-BOUNDARY-START(38655295520)
            /*XxHash32 */ Clone()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655295520);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sih.SIH.XxHash32().$ctor$4(this._seed, $.$clone(this._state), this._holdback, this._length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655295520)
            
            //--TRIMMABLE-BOUNDARY-START(77310001184)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._state = new $.$sih.SIH.XxHash32.State().$ctor$3(this._seed);
                this._length = 0;
            }
            //--TRIMMABLE-BOUNDARY-END(77310001184)
            
            //--TRIMMABLE-BOUNDARY-START(34360328224)
            /*void */ Append$2(/*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let held = this._length & 15;
                if (held !== 0)
                {
                    /*int*/ let remain = ((16/*StripeSize*/ - held) | 0);
                    if (source.Length >= remain)
                    {
                        source.Slice(0, remain).CopyTo($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._holdback, held));
                        this._state.ProcessStripe($.$$.S.ReadOnlySpan$$($.$$.S.Byte).op_Implicit$1(this._holdback));
                        source = source.Slice$1(remain);
                        this._length += remain;
                    }
                    else 
                    {
                        source.CopyTo($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._holdback, held));
                        this._length += source.Length;
                        return;
                    }
                }
                while(source.Length >= 16/*StripeSize*/)
                {
                    this._state.ProcessStripe(source);
                    source = source.Slice$1(16/*StripeSize*/);
                    this._length += 16/*StripeSize*/;
                }
                if (source.Length > 0)
                {
                    this._holdback ??= $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [16/*StripeSize*/], null);
                    source.CopyTo($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(this._holdback));
                    this._length += source.Length;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360328224)
            
            //--TRIMMABLE-BOUNDARY-START(47245230112)
            /*void */ GetCurrentHashCore(/*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245230112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let hash = this.GetCurrentHashAsUInt32();
                $.$$.SBB.BinaryPrimitives.WriteUInt32BigEndian(destination, hash);
            }
            //--TRIMMABLE-BOUNDARY-END(47245230112)
            
            //--TRIMMABLE-BOUNDARY-START(42950262816)
            /*uint */ GetCurrentHashAsUInt32()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let remainingLength = this._length & 15;
                /*ReadOnlySpan<byte>*/ let remaining = $.$$.S.ReadOnlySpan$$($.$$.S.Byte).Empty;
                if (remainingLength > 0)
                {
                    remaining = new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$6(this._holdback, 0, remainingLength);
                }
                return this._state.Complete(this._length, remaining);
            }
            //--TRIMMABLE-BOUNDARY-END(42950262816)
            
            //--TRIMMABLE-BOUNDARY-START(55835164704)
            static /*byte[] */ Hash$1(/*byte[]*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835164704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$sih.SIH.XxHash32.Hash$2(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7(source), 0);
            }
            //--TRIMMABLE-BOUNDARY-END(55835164704)
            
            //--TRIMMABLE-BOUNDARY-START(51540197408)
            static /*byte[] */ Hash(/*byte[]*/ source, /*int*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540197408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$sih.SIH.XxHash32.Hash$2(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7(source), seed);
            }
            //--TRIMMABLE-BOUNDARY-END(51540197408)
            
            //--TRIMMABLE-BOUNDARY-START(60130132000)
            static /*byte[] */ Hash$2(/*ReadOnlySpan<byte>*/ source, /*int*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130132000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let ret = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [4/*HashSize*/], null);
                /*uint*/ let hash = $.$sih.SIH.XxHash32.HashToUInt32(source, seed);
                $.$$.SBB.BinaryPrimitives.WriteUInt32BigEndian($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(ret), hash);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(60130132000)
            
            //--TRIMMABLE-BOUNDARY-START(85899935776)
            static /*bool */ TryHash(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesWritten, /*int*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < 4/*HashSize*/)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                /*uint*/ let hash = $.$sih.SIH.XxHash32.HashToUInt32(source, seed);
                $.$$.SBB.BinaryPrimitives.WriteUInt32BigEndian(destination, hash);
                bytesWritten.$v = 4/*HashSize*/;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(85899935776)
            
            //--TRIMMABLE-BOUNDARY-START(64425099296)
            static /*int */ Hash$3(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*int*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425099296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < 4/*HashSize*/)
                {
                    $.$sih.SIH.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                /*uint*/ let hash = $.$sih.SIH.XxHash32.HashToUInt32(source, seed);
                $.$$.SBB.BinaryPrimitives.WriteUInt32BigEndian(destination, hash);
                return 4/*HashSize*/;
            }
            //--TRIMMABLE-BOUNDARY-END(64425099296)
            
            //--TRIMMABLE-BOUNDARY-START(73015033888)
            static /*uint */ HashToUInt32(/*ReadOnlySpan<byte>*/ source, /*int*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let totalLength = source.Length;
                /*State*/ let state = new $.$sih.SIH.XxHash32.State().$ctor$3((seed >>> 0));
                while(source.Length >= 16/*StripeSize*/)
                {
                    state.ProcessStripe(source);
                    source = source.Slice$1(16/*StripeSize*/);
                }
                return state.Complete(totalLength, source);
            }
            //--TRIMMABLE-BOUNDARY-END(73015033888)
            
            //--TRIMMABLE-BOUNDARY-START(21475426336)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21475426336)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180459040)
                this._state = $.$default($.$sih.SIH.XxHash32.State);
                //--TRIMMABLE-BOUNDARY-END(17180459040)
                
            }
            static $h = 589856;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sih.SIH.NonCryptographicHashAlgorithm; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655295520),
    {
      "r": 589856,
      "n": "Clone",
      "d": 589856,
      "h": 38655295520,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655295520),
//--TRIMMABLE-BOUNDARY-START(77310001184),
    {
      "r": 65537,
      "n": "Reset",
      "d": 589856,
      "h": 77310001184,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310001184),
//--TRIMMABLE-BOUNDARY-START(34360328224),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": 589856,
      "h": 34360328224,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360328224),
//--TRIMMABLE-BOUNDARY-START(47245230112),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetCurrentHashCore",
      "d": 589856,
      "h": 47245230112,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47245230112),
//--TRIMMABLE-BOUNDARY-START(42950262816),
    {
      "r": 720897,
      "n": "GetCurrentHashAsUInt32",
      "d": 589856,
      "h": 42950262816,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950262816),
//--TRIMMABLE-BOUNDARY-START(55835164704),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Hash",
      "o": "@$1",
      "d": 589856,
      "h": 55835164704,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835164704),
//--TRIMMABLE-BOUNDARY-START(51540197408),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 655361
        }
      ],
      "n": "Hash",
      "d": 589856,
      "h": 51540197408,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540197408),
//--TRIMMABLE-BOUNDARY-START(60130132000),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "Hash",
      "o": "@$2",
      "d": 589856,
      "h": 60130132000,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130132000),
//--TRIMMABLE-BOUNDARY-START(85899935776),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "seed",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "TryHash",
      "d": 589856,
      "h": 85899935776,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85899935776),
//--TRIMMABLE-BOUNDARY-START(64425099296),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "Hash",
      "o": "@$3",
      "d": 589856,
      "h": 64425099296,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64425099296),
//--TRIMMABLE-BOUNDARY-START(73015033888),
    {
      "r": 720897,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "HashToUInt32",
      "d": 589856,
      "h": 73015033888,
      "f": 16777249,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015033888)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(68720066592),
    {
      "t": 655361,
      "n": "HashSize",
      "d": 589856,
      "h": 68720066592,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68720066592),
//--TRIMMABLE-BOUNDARY-START(81604968480),
    {
      "t": 655361,
      "n": "StripeSize",
      "d": 589856,
      "h": 81604968480,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81604968480),
//--TRIMMABLE-BOUNDARY-START(12885491744),
    {
      "t": 720897,
      "n": "_seed",
      "d": 589856,
      "h": 12885491744,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885491744),
//--TRIMMABLE-BOUNDARY-START(17180459040),
    {
      "t": 655392,
      "n": "_state",
      "d": 589856,
      "h": 17180459040,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180459040),
//--TRIMMABLE-BOUNDARY-START(4295557152),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_holdback",
      "d": 589856,
      "h": 4295557152,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557152),
//--TRIMMABLE-BOUNDARY-START(8590524448),
    {
      "t": 655361,
      "n": "_length",
      "d": 589856,
      "h": 8590524448,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524448)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475426336),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589856,
      "h": 21475426336,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426336),
//--TRIMMABLE-BOUNDARY-START(25770393632),
    {
      "p": [
        {
          "n": "seed",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589856,
      "h": 25770393632,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770393632),
//--TRIMMABLE-BOUNDARY-START(30065360928),
    {
      "p": [
        {
          "n": "seed",
          "p": 720897
        },
        {
          "n": "state",
          "p": 655392
        },
        {
          "n": "holdback",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 589856,
      "h": 30065360928,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065360928)
  ],
  "h": 589856
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sih.SIH.XxHash32.State ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.XxHash32`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}XxHash32`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589856)
        
        

        //--TRIMMABLE-BOUNDARY-START(131104)
        $asm.$cls(`$sih.SIH.Crc64`, ($self) => class Crc64 extends $.$sih.SIH.NonCryptographicHashAlgorithm
        {
            //--TRIMMABLE-BOUNDARY-START(73014575136)
            /*ulong*/ static InitialState = 0n;
            //--TRIMMABLE-BOUNDARY-END(73014575136)
            
            //--TRIMMABLE-BOUNDARY-START(85899477024)
            /*int*/ static Size = 8;
            //--TRIMMABLE-BOUNDARY-END(85899477024)
            
            //--TRIMMABLE-BOUNDARY-START(4295098400)
            /*ulong*/ _crc = 0n;
            //--TRIMMABLE-BOUNDARY-END(4295098400)
            
            //--TRIMMABLE-BOUNDARY-START(8590065696)
            $ctor$2()
            {
                super.$ctor$1(8/*Size*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065696);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065696)
            
            //--TRIMMABLE-BOUNDARY-START(12885032992)
            $ctor$3(/*ulong*/ crc)
            {
                super.$ctor$1(8/*Size*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885032992);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._crc = crc;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885032992)
            
            //--TRIMMABLE-BOUNDARY-START(25769934880)
            /*Crc64 */ Clone()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769934880);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sih.SIH.Crc64().$ctor$3(this._crc);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25769934880)
            
            //--TRIMMABLE-BOUNDARY-START(17180000288)
            /*void */ Append$2(/*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._crc = $.$sih.SIH.Crc64.Update(this._crc, source);
            }
            //--TRIMMABLE-BOUNDARY-END(17180000288)
            
            //--TRIMMABLE-BOUNDARY-START(81604509728)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604509728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._crc = 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(81604509728)
            
            //--TRIMMABLE-BOUNDARY-START(47244771360)
            /*void */ GetCurrentHashCore(/*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244771360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SBB.BinaryPrimitives.WriteUInt64BigEndian(destination, this._crc);
            }
            //--TRIMMABLE-BOUNDARY-END(47244771360)
            
            //--TRIMMABLE-BOUNDARY-START(51539738656)
            /*void */ GetHashAndResetCore(/*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539738656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SBB.BinaryPrimitives.WriteUInt64BigEndian(destination, this._crc);
                this._crc = 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(51539738656)
            
            //--TRIMMABLE-BOUNDARY-START(42949804064)
            /*ulong */ GetCurrentHashAsUInt64()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949804064);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._crc;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949804064)
            
            //--TRIMMABLE-BOUNDARY-START(55834705952)
            static /*byte[] */ Hash(/*byte[]*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834705952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$sih.SIH.Crc64.Hash$2(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7(source));
            }
            //--TRIMMABLE-BOUNDARY-END(55834705952)
            
            //--TRIMMABLE-BOUNDARY-START(64424640544)
            static /*byte[] */ Hash$2(/*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424640544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let ret = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [8/*Size*/], null);
                /*ulong*/ let hash = $.$sih.SIH.Crc64.HashToUInt64(source);
                $.$$.SBB.BinaryPrimitives.WriteUInt64BigEndian($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(ret), hash);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(64424640544)
            
            //--TRIMMABLE-BOUNDARY-START(90194444320)
            static /*bool */ TryHash(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194444320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < 8/*Size*/)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                /*ulong*/ let hash = $.$sih.SIH.Crc64.HashToUInt64(source);
                $.$$.SBB.BinaryPrimitives.WriteUInt64BigEndian(destination, hash);
                bytesWritten.$v = 8/*Size*/;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(90194444320)
            
            //--TRIMMABLE-BOUNDARY-START(60129673248)
            static /*int */ Hash$1(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < 8/*Size*/)
                {
                    $.$sih.SIH.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                /*ulong*/ let hash = $.$sih.SIH.Crc64.HashToUInt64(source);
                $.$$.SBB.BinaryPrimitives.WriteUInt64BigEndian(destination, hash);
                return 8/*Size*/;
            }
            //--TRIMMABLE-BOUNDARY-END(60129673248)
            
            //--TRIMMABLE-BOUNDARY-START(68719607840)
            static /*ulong */ HashToUInt64(/*ReadOnlySpan<byte>*/ source)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719607840);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sih.SIH.Crc64.Update(0n, source);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719607840)
            
            //--TRIMMABLE-BOUNDARY-START(94489411616)
            static /*ulong */ Update(/*ulong*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489411616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sih.SIH.Crc64.CanBeVectorized(source))
                {
                    return $.$sih.SIH.Crc64.UpdateVectorized(crc, source);
                }
                return $.$sih.SIH.Crc64.UpdateScalar(crc, source);
            }
            //--TRIMMABLE-BOUNDARY-END(94489411616)
            
            //--TRIMMABLE-BOUNDARY-START(98784378912)
            static /*ulong */ UpdateScalar(/*ulong*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784378912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<ulong>*/ let crcLookup = $.$sih.SIH.Crc64.CrcLookup;
                for(/*int*/ let i = 0; i < source.Length; i++)
                {
                    /*ulong*/ let idx = (crc >> 56n);
                    idx ^= BigInt(source._reference.GetAt(i));
                    crc = crcLookup._reference.GetAt($.$cast(idx, $.$$.S.Int32)) ^ (BigInt.asUintN(64, crc << 8n));
                }
                return crc;
            }
            //--TRIMMABLE-BOUNDARY-END(98784378912)
            
            //--TRIMMABLE-BOUNDARY-START(77309542432)
            static /*Vector128<ulong> */ LoadFromSource(/*ref byte*/ source, /*nuint*/ elementOffset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309542432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Vector128<byte>*/ let vector = $.$$.SRI$1.Vector128.LoadUnsafe$2($.$$.S.Byte, source, elementOffset);
                if ($.$$.S.BitConverter.IsLittleEndian)
                {
                    vector = $.$$.SRI$1.Vector128.Shuffle(vector, $.$$.SRI$1.Vector128.Create(15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0));
                }
                return $.$$.SRI$1.Vector128.AsUInt64($.$$.S.Byte, vector);
            }
            //--TRIMMABLE-BOUNDARY-END(77309542432)
            
            //--TRIMMABLE-BOUNDARY-START(21474967584)
            static /*bool */ CanBeVectorized(/*ReadOnlySpan<byte>*/ source)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21474967584);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sih.SIH.VectorHelper.IsSupported && source.Length >= $.$$.SRI$1.Vector128$$($.$$.S.Byte).Count;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21474967584)
            
            //--TRIMMABLE-BOUNDARY-START(103079346208)
            static /*ulong */ UpdateVectorized(/*ulong*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079346208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$sih.SIH.Crc64.CanBeVectorized(source), "source cannot be vectorized.");
                /*ref byte*/ let srcRef = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Byte, source);
                /*int*/ let length = source.Length;
                /*Vector128<ulong>*/ let x7;
                /*Vector128<ulong>*/ let kConstants;
                if (length >= (($.$$.SRI$1.Vector128$$($.$$.S.Byte).Count * 16) | 0))
                {
                    /*Vector128<ulong>*/ let x0 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 0);
                    /*Vector128<ulong>*/ let x1 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 16);
                    /*Vector128<ulong>*/ let x2 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 32);
                    /*Vector128<ulong>*/ let x3 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 48);
                    /*Vector128<ulong>*/ let x4 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 64);
                    /*Vector128<ulong>*/ let x5 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 80);
                    /*Vector128<ulong>*/ let x6 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 96);
                    x7 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 112);
                    srcRef = $.$$.SRC.Unsafe.Add($.$$.S.Byte, srcRef, (($.$$.SRI$1.Vector128$$($.$$.S.Byte).Count * 8) | 0));
                    length -= (($.$$.SRI$1.Vector128$$($.$$.S.Byte).Count * 8) | 0);
                    x0 = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr(x0, $.$sih.SIH.VectorHelper.ShiftLowerToUpper($.$$.SRI$1.Vector128.CreateScalar$10(crc)));
                    kConstants = $.$$.SRI$1.Vector128.Create$31(0x5CF79DEA9AC37D6n, 0x1067E571D7D5C2n);
                    do
                    {
                        /*Vector128<ulong>*/ let y1 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 0);
                        /*Vector128<ulong>*/ let y2 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 16);
                        x0 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(y1, x0, kConstants);
                        x1 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(y2, x1, kConstants);
                        y1 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 32);
                        y2 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 48);
                        x2 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(y1, x2, kConstants);
                        x3 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(y2, x3, kConstants);
                        y1 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 64);
                        y2 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 80);
                        x4 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(y1, x4, kConstants);
                        x5 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(y2, x5, kConstants);
                        y1 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 96);
                        y2 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 112);
                        x6 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(y1, x6, kConstants);
                        x7 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(y2, x7, kConstants);
                        srcRef = $.$$.SRC.Unsafe.Add($.$$.S.Byte, srcRef, (($.$$.SRI$1.Vector128$$($.$$.S.Byte).Count * 8) | 0));
                        length -= (($.$$.SRI$1.Vector128$$($.$$.S.Byte).Count * 8) | 0);
                    }
                    while(length >= (($.$$.SRI$1.Vector128$$($.$$.S.Byte).Count * 8) | 0));
                    x7 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(x7, x0, $.$$.SRI$1.Vector128.Create$31(0xE464F4DF5FB60AC1n, 0xB649C5B35A759CF2n));
                    x7 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(x7, x1, $.$$.SRI$1.Vector128.Create$31(0x9AF04E1EFF82D0DDn, 0x6E82E609297F8FE8n));
                    x7 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(x7, x2, $.$$.SRI$1.Vector128.Create$31(0x97C516E98BD2E73n, 0xB76477B31E22E7Bn));
                    x7 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(x7, x3, $.$$.SRI$1.Vector128.Create$31(0x5F6843CA540DF020n, 0xDDF4B6981205B83Fn));
                    x7 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(x7, x4, $.$$.SRI$1.Vector128.Create$31(0x54819D8713758B2Cn, 0x4A6B90073EB0AF5An));
                    x7 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(x7, x5, $.$$.SRI$1.Vector128.Create$31(0x571BEE0A227EF92Bn, 0x44BEF2A201B5200Cn));
                    x7 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(x7, x6, $.$$.SRI$1.Vector128.Create$31(0x5F5C3C7EB52FAB6n, 0x4EB938A7D257740En));
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4(length >= 16, "length >= 16");
                    x7 = $.$sih.SIH.Crc64.LoadFromSource(srcRef, 0);
                    x7 = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr(x7, $.$sih.SIH.VectorHelper.ShiftLowerToUpper($.$$.SRI$1.Vector128.CreateScalar$10(crc)));
                    srcRef = $.$$.SRC.Unsafe.Add($.$$.S.Byte, srcRef, $.$$.SRI$1.Vector128$$($.$$.S.Byte).Count);
                    length -= $.$$.SRI$1.Vector128$$($.$$.S.Byte).Count;
                }
                while(length >= $.$$.SRI$1.Vector128$$($.$$.S.Byte).Count)
                {
                    x7 = $.$sih.SIH.VectorHelper.FoldPolynomialPair($.$sih.SIH.Crc64.LoadFromSource(srcRef, 0), x7, $.$$.SRI$1.Vector128.Create$31(0x5F5C3C7EB52FAB6n, 0x4EB938A7D257740En));
                    srcRef = $.$$.SRC.Unsafe.Add($.$$.S.Byte, srcRef, $.$$.SRI$1.Vector128$$($.$$.S.Byte).Count);
                    length -= $.$$.SRI$1.Vector128$$($.$$.S.Byte).Count;
                }
                x7 = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr($.$sih.SIH.VectorHelper.CarrylessMultiplyLeftUpperRightLower(x7, $.$$.SRI$1.Vector128.CreateScalar$10(0x5F5C3C7EB52FAB6n)), $.$sih.SIH.VectorHelper.ShiftLowerToUpper(x7));
                kConstants = $.$$.SRI$1.Vector128.Create$31(0x578D29D06CC4F872n, 0x42F0E1EBA9EA3693n);
                /*Vector128<ulong>*/ let temp = x7;
                x7 = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr($.$sih.SIH.VectorHelper.CarrylessMultiplyLeftUpperRightLower(x7, kConstants), ($.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_BitwiseAnd(x7, $.$$.SRI$1.Vector128.Create$31(0n, (~0n & 0xFFFFFFFFFFFFFFFFn)))));
                x7 = $.$sih.SIH.VectorHelper.CarrylessMultiplyUpper(x7, kConstants);
                x7 = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr(x7, temp);
                /*ulong*/ let result = $.$$.SRI$1.Vector128.GetElement($.$$.S.UInt64, x7, 0);
                return length > 0 ? $.$sih.SIH.Crc64.UpdateScalar(result, $.$$.SRI.MemoryMarshal.CreateReadOnlySpan($.$$.S.Byte, srcRef, length)) : result;
            }
            //--TRIMMABLE-BOUNDARY-END(103079346208)
            
            //--TRIMMABLE-BOUNDARY-START(30064902176)
            static /*ReadOnlySpan<ulong> */ get CrcLookup()
            {
                return this.$cacheCrcLookup ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.UInt64))().$ctor$7([ 0n, 4823603603198064275n, 9647207206396128550n, 14344283933443513269n, 5274672035359026399n, 847670339082705484n, 14759040976900489721n, 10241823793177474922n, 10549344070718052798n, 15030250704074698541n, 1695340678165410968n, 6158653484774949387n, 15804726273676621153n, 11071337880091427826n, 6824194888265062471n, 2036903512645398228n, 7367177604490692079n, 2651944067726553980n, 16419204125234161865n, 11613757334439845466n, 3390681356330821936n, 7926053118503640995n, 12317306969549898774n, 16726154088988619397n, 17607865585094646865n, 13162708473643690690n, 8194994013375312247n, 3695931686473304036n, 13648389776530124942n, 18417527692557321757n, 4073807025290796456n, 8825348881154370363n, 14734355208981384158n, 10271039580541631821n, 5303888135453107960n, 822984195088142443n, 9604374506261047041n, 14391664176758772114n, 47380625301539367n, 4780770595170139316n, 6781362712661643872n, 2084283301222999283n, 15852106237007281990n, 11028505464239851989n, 1670654249350217407n, 6187869865390245932n, 10578560694269006745n, 15005564104267687178n, 12269926345859042865n, 16768987096479742114n, 3433514057002836759n, 7878672873577829764n, 16389988026750624494n, 11638443477897467005n, 7391863372946608072n, 2622728278751721819n, 4044590402276644751n, 8850035479350698268n, 13673076206955870889n, 18388311311405091898n, 8147614050581592912n, 3738764100714335683n, 17650697762308740726n, 13115328684529279205n, 15709965168302367023n, 11021966344253216700n, 6909860770376862729n, 2095335087373712026n, 10607776270906215920n, 15115916238825782115n, 1645968390176284886n, 6063892853452478021n, 5216239979862816913n, 762004938812542466n, 14808413130408695223n, 10336584279807992612n, 94761250603078734n, 4872975272980325085n, 9561541190340278632n, 14285852213486374907n, 13562725425323287744n, 18359094313119879763n, 4168566602445998566n, 8874722219015798645n, 17657238303940757535n, 13257468400305012364n, 8136561383943382329n, 3610266854770152362n, 3341308498700434814n, 7831293060043656173n, 12375739730780491864n, 16811819059476047563n, 7452841817450123681n, 2710377314828461874n, 16324444680414493831n, 11564384134825822740n, 1621282580641819377n, 6093108618008534114n, 10636992411005044695n, 15091230119249932612n, 6867028114005673518n, 2142715359940571325n, 15757345747155659528n, 10979133309658045851n, 9518708972583580495n, 14333231979791697372n, 142141253402664553n, 4830142882085382394n, 14783726745893216144n, 10365800689136969987n, 5245456557503443638n, 737318311902463013n, 8089180804553289502n, 3653099890976004493n, 17700070958701396536n, 13210088128275084459n, 4139350461810230209n, 8899408340202190162n, 13587411233247080167n, 18329878549100632180n, 16295228101163185824n, 11589070762272702515n, 7477528201428671366n, 2681160907110034709n, 12328359726370364031n, 16854651450907929836n, 3384140715920324441n, 7783913295349006794n, 17796789492404876493n, 12973186262895182430n, 8294265019745835499n, 3597188614796881784n, 13819721540753725458n, 18246723593521770113n, 4190670174747424052n, 8707887697765516199n, 7249714899603402099n, 2768808468102880224n, 16248400991498780757n, 11785088403942012614n, 3291936780352569772n, 8025325358597240639n, 12127785706904956042n, 16915077318774037017n, 10432479959725633826n, 15147713122803500977n, 1524009877625084932n, 6329456346323069591n, 15705454305770282493n, 11170082187107838830n, 6635271944638132443n, 2226424485906433608n, 189522501206157468n, 4634679410803088911n, 9745950545960650170n, 14245012653811987241n, 5445476407655580739n, 676338306971005648n, 14876502445374089573n, 10124960353263198198n, 4215391513593610003n, 8678706776937023872n, 13790540925671641653n, 18271444552530207910n, 8337133204891997132n, 3549843186494580063n, 17749444438031597290n, 13016054137459951737n, 12170653315997410989n, 16867732534171963454n, 3244592164593781643n, 8068192726900473112n, 16273122767886764658n, 11755906975779290337n, 7220533709540304724n, 2793530071884239303n, 6682616997400869628n, 2183556611878603887n, 15662586120087312346n, 11217427617020813641n, 1553190491096487459n, 6304735387851432112n, 10407758620342516485n, 15176894045242543510n, 14905683634900247362n, 10100238751092381137n, 5420754629656923748n, 705519735670536439n, 9793295161182637981n, 14202145287119436046n, 146654890503152315n, 4682024195942093864n, 3242565161283638754n, 7930564333232481137n, 12186217236017068228n, 17000743249723264599n, 7335380351123765565n, 2827240748300537774n, 16153640314560107547n, 11735716164790313608n, 13734056228011347036n, 18188291445129067215n, 4285430719881142650n, 8757259798139230185n, 17846161249714921603n, 13067947420601767440n, 8235833358291897765n, 3511522545606540086n, 5387043107155988493n, 590673871457609374n, 14925875833148783915n, 10219719885873843128n, 284282506805329106n, 4684052045342640705n, 9660285764170764788n, 14186579979835500391n, 15610694155489642931n, 11120709418076880672n, 6720936860919424149n, 2284857304564388358n, 10490913115006887276n, 15233377424362361855n, 1474636623804926026n, 6234696958930763481n, 16178361609106579004n, 11706535215248140463n, 7306199781952008986n, 2851961734412043657n, 12229085463316509411n, 16953397843693241456n, 3195220067441434565n, 7973432182840617302n, 8278700923620460418n, 3464177731752866065n, 17798816680404380324n, 13110814815472245815n, 4310152537884486493n, 8728078392784608718n, 13704874997943502459n, 18213013024491712744n, 9707630858549910483n, 14143712128616820032n, 241414281116563189n, 4731397450835853414n, 14955056402857342732n, 10194998898151653791n, 5362321814220069418n, 619854820462849209n, 1503817855483314797n, 6209975379031176446n, 10466191297540353867n, 15262558828106308056n, 6768281431840648882n, 2241989909157107745n, 15567826590698013588n, 11168054230320002311n ]);
            }
            //--TRIMMABLE-BOUNDARY-END(30064902176)
            
            //--TRIMMABLE-BOUNDARY-START(8590065696)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590065696)
            
            static $h = 131104;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sih.SIH.NonCryptographicHashAlgorithm; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064902176),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.UInt64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654836768,
        "f": 50331682
      },
      "n": "CrcLookup",
      "d": 131104,
      "h": 30064902176,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(30064902176)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769934880),
    {
      "r": 131104,
      "n": "Clone",
      "d": 131104,
      "h": 25769934880,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769934880),
//--TRIMMABLE-BOUNDARY-START(17180000288),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": 131104,
      "h": 17180000288,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180000288),
//--TRIMMABLE-BOUNDARY-START(81604509728),
    {
      "r": 65537,
      "n": "Reset",
      "d": 131104,
      "h": 81604509728,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604509728),
//--TRIMMABLE-BOUNDARY-START(47244771360),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetCurrentHashCore",
      "d": 131104,
      "h": 47244771360,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47244771360),
//--TRIMMABLE-BOUNDARY-START(51539738656),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetHashAndResetCore",
      "d": 131104,
      "h": 51539738656,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51539738656),
//--TRIMMABLE-BOUNDARY-START(42949804064),
    {
      "r": 983041,
      "n": "GetCurrentHashAsUInt64",
      "d": 131104,
      "h": 42949804064,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42949804064),
//--TRIMMABLE-BOUNDARY-START(55834705952),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Hash",
      "d": 131104,
      "h": 55834705952,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55834705952),
//--TRIMMABLE-BOUNDARY-START(64424640544),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Hash",
      "o": "@$2",
      "d": 131104,
      "h": 64424640544,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64424640544),
//--TRIMMABLE-BOUNDARY-START(90194444320),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryHash",
      "d": 131104,
      "h": 90194444320,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90194444320),
//--TRIMMABLE-BOUNDARY-START(60129673248),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "Hash",
      "o": "@$1",
      "d": 131104,
      "h": 60129673248,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60129673248),
//--TRIMMABLE-BOUNDARY-START(68719607840),
    {
      "r": 983041,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "HashToUInt64",
      "d": 131104,
      "h": 68719607840,
      "f": 16777249,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719607840),
//--TRIMMABLE-BOUNDARY-START(94489411616),
    {
      "r": 983041,
      "p": [
        {
          "n": "crc",
          "p": 983041
        },
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Update",
      "d": 131104,
      "h": 94489411616,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94489411616),
//--TRIMMABLE-BOUNDARY-START(98784378912),
    {
      "r": 983041,
      "p": [
        {
          "n": "crc",
          "p": 983041
        },
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "UpdateScalar",
      "d": 131104,
      "h": 98784378912,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(98784378912),
//--TRIMMABLE-BOUNDARY-START(77309542432),
    {
      "r": $.$$.SRI$1.Vector128$$($.$$.S.UInt64).$h,
      "p": [
        {
          "n": "source",
          "p": 393217,
          "f": 4
        },
        {
          "n": "elementOffset",
          "p": 851969
        }
      ],
      "n": "LoadFromSource",
      "d": 131104,
      "h": 77309542432,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77309542432),
//--TRIMMABLE-BOUNDARY-START(21474967584),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "CanBeVectorized",
      "d": 131104,
      "h": 21474967584,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21474967584),
//--TRIMMABLE-BOUNDARY-START(103079346208),
    {
      "r": 983041,
      "p": [
        {
          "n": "crc",
          "p": 983041
        },
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "UpdateVectorized",
      "d": 131104,
      "h": 103079346208,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103079346208)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73014575136),
    {
      "t": 983041,
      "n": "InitialState",
      "d": 131104,
      "h": 73014575136,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73014575136),
//--TRIMMABLE-BOUNDARY-START(85899477024),
    {
      "t": 655361,
      "n": "Size",
      "d": 131104,
      "h": 85899477024,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(85899477024),
//--TRIMMABLE-BOUNDARY-START(4295098400),
    {
      "t": 983041,
      "n": "_crc",
      "d": 131104,
      "h": 4295098400,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098400)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065696),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131104,
      "h": 8590065696,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065696),
//--TRIMMABLE-BOUNDARY-START(12885032992),
    {
      "p": [
        {
          "n": "crc",
          "p": 983041
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131104,
      "h": 12885032992,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885032992)
  ],
  "h": 131104
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.Crc64`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}Crc64`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131104)
        
        

        //--TRIMMABLE-BOUNDARY-START(65568)
        $asm.$cls(`$sih.SIH.Crc32`, ($self) => class Crc32 extends $.$sih.SIH.NonCryptographicHashAlgorithm
        {
            //--TRIMMABLE-BOUNDARY-START(103079280672)
            static /*uint */ UpdateScalarArm64(/*uint*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079280672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(/*$.$$.SRIA.Crc32*/$.$$.DeletedObject.Arm64.IsSupported, "ARM CRC support is required.");
                if (source.Length >= 8)
                {
                    /*ref byte*/ let ptr = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Byte, source);
                    /*int*/ let longLength = source.Length & ~7;
                    for(/*int*/ let i = 0; i < longLength; i += 8)
                    {
                        crc = /*$.$$.SRIA.Crc32*/$.$$.DeletedObject.Arm64.ComputeCrc32(crc, $.$$.SRC.Unsafe.ReadUnaligned($.$$.S.UInt64, $.$$.SRC.Unsafe.Add($.$$.S.Byte, ptr, i)));
                    }
                    source = source.Slice$1(longLength);
                }
                for(/*int*/ let i = 0; i < source.Length; i++)
                {
                    crc = /*$.$$.SRIA.Crc32*/$.$$.DeletedObject.ComputeCrc32(crc, source._reference.GetAt(i));
                }
                return crc;
            }
            //--TRIMMABLE-BOUNDARY-END(103079280672)
            
            //--TRIMMABLE-BOUNDARY-START(98784313376)
            static /*uint */ UpdateScalarArm32(/*uint*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784313376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(/*$.$$.SRIA.Crc32*/$.$$.DeletedObject.IsSupported, "ARM CRC support is required.");
                if (source.Length >= 4)
                {
                    /*ref byte*/ let ptr = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Byte, source);
                    /*int*/ let intLength = source.Length & ~3;
                    for(/*int*/ let i = 0; i < intLength; i += 4)
                    {
                        crc = /*$.$$.SRIA.Crc32*/$.$$.DeletedObject.ComputeCrc32(crc, $.$$.SRC.Unsafe.ReadUnaligned($.$$.S.UInt32, $.$$.SRC.Unsafe.Add($.$$.S.Byte, ptr, i)));
                    }
                    source = source.Slice$1(intLength);
                }
                for(/*int*/ let i = 0; i < source.Length; i++)
                {
                    crc = /*$.$$.SRIA.Crc32*/$.$$.DeletedObject.ComputeCrc32(crc, source._reference.GetAt(i));
                }
                return crc;
            }
            //--TRIMMABLE-BOUNDARY-END(98784313376)
            
            //--TRIMMABLE-BOUNDARY-START(73014509600)
            /*uint*/ static InitialState = 4294967295;
            //--TRIMMABLE-BOUNDARY-END(73014509600)
            
            //--TRIMMABLE-BOUNDARY-START(81604444192)
            /*int*/ static Size = 4;
            //--TRIMMABLE-BOUNDARY-END(81604444192)
            
            //--TRIMMABLE-BOUNDARY-START(4295032864)
            /*uint*/ _crc = 4294967295;
            //--TRIMMABLE-BOUNDARY-END(4295032864)
            
            //--TRIMMABLE-BOUNDARY-START(8590000160)
            $ctor$2()
            {
                super.$ctor$1(4/*Size*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000160);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000160)
            
            //--TRIMMABLE-BOUNDARY-START(12884967456)
            $ctor$3(/*uint*/ crc)
            {
                super.$ctor$1(4/*Size*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967456);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._crc = crc;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967456)
            
            //--TRIMMABLE-BOUNDARY-START(25769869344)
            /*Crc32 */ Clone()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769869344);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sih.SIH.Crc32().$ctor$3(this._crc);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25769869344)
            
            //--TRIMMABLE-BOUNDARY-START(17179934752)
            /*void */ Append$2(/*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._crc = $.$sih.SIH.Crc32.Update(this._crc, source);
            }
            //--TRIMMABLE-BOUNDARY-END(17179934752)
            
            //--TRIMMABLE-BOUNDARY-START(77309476896)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309476896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._crc = 4294967295/*InitialState*/;
            }
            //--TRIMMABLE-BOUNDARY-END(77309476896)
            
            //--TRIMMABLE-BOUNDARY-START(47244705824)
            /*void */ GetCurrentHashCore(/*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SBB.BinaryPrimitives.WriteUInt32LittleEndian(destination, ~this._crc);
            }
            //--TRIMMABLE-BOUNDARY-END(47244705824)
            
            //--TRIMMABLE-BOUNDARY-START(51539673120)
            /*void */ GetHashAndResetCore(/*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SBB.BinaryPrimitives.WriteUInt32LittleEndian(destination, ~this._crc);
                this._crc = 4294967295/*InitialState*/;
            }
            //--TRIMMABLE-BOUNDARY-END(51539673120)
            
            //--TRIMMABLE-BOUNDARY-START(42949738528)
            /*uint */ GetCurrentHashAsUInt32()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949738528);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ~this._crc;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949738528)
            
            //--TRIMMABLE-BOUNDARY-START(55834640416)
            static /*byte[] */ Hash(/*byte[]*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834640416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$sih.SIH.Crc32.Hash$2(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7(source));
            }
            //--TRIMMABLE-BOUNDARY-END(55834640416)
            
            //--TRIMMABLE-BOUNDARY-START(64424575008)
            static /*byte[] */ Hash$2(/*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424575008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let ret = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [4/*Size*/], null);
                /*uint*/ let hash = $.$sih.SIH.Crc32.HashToUInt32(source);
                $.$$.SBB.BinaryPrimitives.WriteUInt32LittleEndian($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(ret), hash);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(64424575008)
            
            //--TRIMMABLE-BOUNDARY-START(85899411488)
            static /*bool */ TryHash(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899411488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < 4/*Size*/)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                /*uint*/ let hash = $.$sih.SIH.Crc32.HashToUInt32(source);
                $.$$.SBB.BinaryPrimitives.WriteUInt32LittleEndian(destination, hash);
                bytesWritten.$v = 4/*Size*/;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(85899411488)
            
            //--TRIMMABLE-BOUNDARY-START(60129607712)
            static /*int */ Hash$1(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129607712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < 4/*Size*/)
                {
                    $.$sih.SIH.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                /*uint*/ let hash = $.$sih.SIH.Crc32.HashToUInt32(source);
                $.$$.SBB.BinaryPrimitives.WriteUInt32LittleEndian(destination, hash);
                return 4/*Size*/;
            }
            //--TRIMMABLE-BOUNDARY-END(60129607712)
            
            //--TRIMMABLE-BOUNDARY-START(68719542304)
            static /*uint */ HashToUInt32(/*ReadOnlySpan<byte>*/ source)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719542304);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ~$.$sih.SIH.Crc32.Update(4294967295/*InitialState*/, source);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719542304)
            
            //--TRIMMABLE-BOUNDARY-START(90194378784)
            static /*uint */ Update(/*uint*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194378784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sih.SIH.Crc32.CanBeVectorized(source))
                {
                    return $.$sih.SIH.Crc32.UpdateVectorized(crc, source);
                }
                return $.$sih.SIH.Crc32.UpdateScalar(crc, source);
            }
            //--TRIMMABLE-BOUNDARY-END(90194378784)
            
            //--TRIMMABLE-BOUNDARY-START(94489346080)
            static /*uint */ UpdateScalar(/*uint*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489346080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (System.Runtime.Intrinsics.Arm.Crc32.Arm64.IsSupported) { ... }
                //if (System.Runtime.Intrinsics.Arm.Crc32.IsSupported) { ... }
                /*ReadOnlySpan<uint>*/ let crcLookup = $.$sih.SIH.Crc32.CrcLookup;
                for(/*int*/ let i = 0; i < source.Length; i++)
                {
                    /*byte*/ let idx = ((crc & 0xFF) >>> 0);
                    idx ^= source._reference.GetAt(i);
                    crc = crcLookup._reference.GetAt(idx) ^ (crc >>> 8);
                }
                return crc;
            }
            //--TRIMMABLE-BOUNDARY-END(94489346080)
            
            //--TRIMMABLE-BOUNDARY-START(30064836640)
            static /*ReadOnlySpan<uint> */ get CrcLookup()
            {
                return this.$cacheCrcLookup ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.UInt32))().$ctor$7([ 0, 1996959894, 3993919788, 2567524794, 124634137, 1886057615, 3915621685, 2657392035, 249268274, 2044508324, 3772115230, 2547177864, 162941995, 2125561021, 3887607047, 2428444049, 498536548, 1789927666, 4089016648, 2227061214, 450548861, 1843258603, 4107580753, 2211677639, 325883990, 1684777152, 4251122042, 2321926636, 335633487, 1661365465, 4195302755, 2366115317, 997073096, 1281953886, 3579855332, 2724688242, 1006888145, 1258607687, 3524101629, 2768942443, 901097722, 1119000684, 3686517206, 2898065728, 853044451, 1172266101, 3705015759, 2882616665, 651767980, 1373503546, 3369554304, 3218104598, 565507253, 1454621731, 3485111705, 3099436303, 671266974, 1594198024, 3322730930, 2970347812, 795835527, 1483230225, 3244367275, 3060149565, 1994146192, 31158534, 2563907772, 4023717930, 1907459465, 112637215, 2680153253, 3904427059, 2013776290, 251722036, 2517215374, 3775830040, 2137656763, 141376813, 2439277719, 3865271297, 1802195444, 476864866, 2238001368, 4066508878, 1812370925, 453092731, 2181625025, 4111451223, 1706088902, 314042704, 2344532202, 4240017532, 1658658271, 366619977, 2362670323, 4224994405, 1303535960, 984961486, 2747007092, 3569037538, 1256170817, 1037604311, 2765210733, 3554079995, 1131014506, 879679996, 2909243462, 3663771856, 1141124467, 855842277, 2852801631, 3708648649, 1342533948, 654459306, 3188396048, 3373015174, 1466479909, 544179635, 3110523913, 3462522015, 1591671054, 702138776, 2966460450, 3352799412, 1504918807, 783551873, 3082640443, 3233442989, 3988292384, 2596254646, 62317068, 1957810842, 3939845945, 2647816111, 81470997, 1943803523, 3814918930, 2489596804, 225274430, 2053790376, 3826175755, 2466906013, 167816743, 2097651377, 4027552580, 2265490386, 503444072, 1762050814, 4150417245, 2154129355, 426522225, 1852507879, 4275313526, 2312317920, 282753626, 1742555852, 4189708143, 2394877945, 397917763, 1622183637, 3604390888, 2714866558, 953729732, 1340076626, 3518719985, 2797360999, 1068828381, 1219638859, 3624741850, 2936675148, 906185462, 1090812512, 3747672003, 2825379669, 829329135, 1181335161, 3412177804, 3160834842, 628085408, 1382605366, 3423369109, 3138078467, 570562233, 1426400815, 3317316542, 2998733608, 733239954, 1555261956, 3268935591, 3050360625, 752459403, 1541320221, 2607071920, 3965973030, 1969922972, 40735498, 2617837225, 3943577151, 1913087877, 83908371, 2512341634, 3803740692, 2075208622, 213261112, 2463272603, 3855990285, 2094854071, 198958881, 2262029012, 4057260610, 1759359992, 534414190, 2176718541, 4139329115, 1873836001, 414664567, 2282248934, 4279200368, 1711684554, 285281116, 2405801727, 4167216745, 1634467795, 376229701, 2685067896, 3608007406, 1308918612, 956543938, 2808555105, 3495958263, 1231636301, 1047427035, 2932959818, 3654703836, 1088359270, 936918000, 2847714899, 3736837829, 1202900863, 817233897, 3183342108, 3401237130, 1404277552, 615818150, 3134207493, 3453421203, 1423857449, 601450431, 3009837614, 3294710456, 1567103746, 711928724, 3020668471, 3272380065, 1510334235, 755167117 ]);
            }
            //--TRIMMABLE-BOUNDARY-END(30064836640)
            
            //--TRIMMABLE-BOUNDARY-START(21474902048)
            static /*bool */ CanBeVectorized(/*ReadOnlySpan<byte>*/ source)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21474902048);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.BitConverter.IsLittleEndian && $.$sih.SIH.VectorHelper.IsSupported && source.Length >= (($.$$.SRI$1.Vector128$$($.$$.S.Byte).Count * (/*System.Runtime.Intrinsics.Arm.Crc32.IsSupported ? 8 : */ 1)) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21474902048)
            
            //--TRIMMABLE-BOUNDARY-START(107374247968)
            static /*uint */ UpdateVectorized(/*uint*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374247968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$sih.SIH.Crc32.CanBeVectorized(source), "source cannot be vectorized.");
                /*ref byte*/ let srcRef = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Byte, source);
                /*int*/ let length = source.Length;
                /*Vector128<ulong>*/ let kConstants;
                /*Vector128<ulong>*/ let x1;
                /*Vector128<ulong>*/ let x2;
                if (length >= (($.$$.SRI$1.Vector128$$($.$$.S.Byte).Count * 8) | 0))
                {
                    x1 = $.$$.SRI$1.Vector128.AsUInt64($.$$.S.Byte, $.$$.SRI$1.Vector128.LoadUnsafe$3($.$$.S.Byte, srcRef));
                    x2 = $.$$.SRI$1.Vector128.AsUInt64($.$$.S.Byte, $.$$.SRI$1.Vector128.LoadUnsafe$2($.$$.S.Byte, srcRef, 16));
                    /*Vector128<ulong>*/ let x3 = $.$$.SRI$1.Vector128.AsUInt64($.$$.S.Byte, $.$$.SRI$1.Vector128.LoadUnsafe$2($.$$.S.Byte, srcRef, 32));
                    /*Vector128<ulong>*/ let x4 = $.$$.SRI$1.Vector128.AsUInt64($.$$.S.Byte, $.$$.SRI$1.Vector128.LoadUnsafe$2($.$$.S.Byte, srcRef, 48));
                    srcRef = $.$$.SRC.Unsafe.Add($.$$.S.Byte, srcRef, (($.$$.SRI$1.Vector128$$($.$$.S.Byte).Count * 4) | 0));
                    length -= (($.$$.SRI$1.Vector128$$($.$$.S.Byte).Count * 4) | 0);
                    x1 = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr(x1, $.$$.SRI$1.Vector128.AsUInt64($.$$.S.UInt32, $.$$.SRI$1.Vector128.CreateScalar$9(crc)));
                    kConstants = $.$$.SRI$1.Vector128.Create$31(0x154442BD4n, 0x1C6E41596n);
                    do
                    {
                        /*Vector128<ulong>*/ let y5 = $.$$.SRI$1.Vector128.AsUInt64($.$$.S.Byte, $.$$.SRI$1.Vector128.LoadUnsafe$3($.$$.S.Byte, srcRef));
                        /*Vector128<ulong>*/ let y6 = $.$$.SRI$1.Vector128.AsUInt64($.$$.S.Byte, $.$$.SRI$1.Vector128.LoadUnsafe$2($.$$.S.Byte, srcRef, 16));
                        /*Vector128<ulong>*/ let y7 = $.$$.SRI$1.Vector128.AsUInt64($.$$.S.Byte, $.$$.SRI$1.Vector128.LoadUnsafe$2($.$$.S.Byte, srcRef, 32));
                        /*Vector128<ulong>*/ let y8 = $.$$.SRI$1.Vector128.AsUInt64($.$$.S.Byte, $.$$.SRI$1.Vector128.LoadUnsafe$2($.$$.S.Byte, srcRef, 48));
                        x1 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(y5, x1, kConstants);
                        x2 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(y6, x2, kConstants);
                        x3 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(y7, x3, kConstants);
                        x4 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(y8, x4, kConstants);
                        srcRef = $.$$.SRC.Unsafe.Add($.$$.S.Byte, srcRef, (($.$$.SRI$1.Vector128$$($.$$.S.Byte).Count * 4) | 0));
                        length -= (($.$$.SRI$1.Vector128$$($.$$.S.Byte).Count * 4) | 0);
                    }
                    while(length >= (($.$$.SRI$1.Vector128$$($.$$.S.Byte).Count * 4) | 0));
                    kConstants = $.$$.SRI$1.Vector128.Create$31(0x1751997D0n, 0xCCAA009En);
                    x1 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(x2, x1, kConstants);
                    x1 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(x3, x1, kConstants);
                    x1 = $.$sih.SIH.VectorHelper.FoldPolynomialPair(x4, x1, kConstants);
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4(length >= 16, "length >= 16");
                    x1 = $.$$.SRI$1.Vector128.AsUInt64($.$$.S.Byte, $.$$.SRI$1.Vector128.LoadUnsafe$3($.$$.S.Byte, srcRef));
                    x1 = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr(x1, $.$$.SRI$1.Vector128.AsUInt64($.$$.S.UInt32, $.$$.SRI$1.Vector128.CreateScalar$9(crc)));
                    srcRef = $.$$.SRC.Unsafe.Add($.$$.S.Byte, srcRef, $.$$.SRI$1.Vector128$$($.$$.S.Byte).Count);
                    length -= $.$$.SRI$1.Vector128$$($.$$.S.Byte).Count;
                }
                while(length >= $.$$.SRI$1.Vector128$$($.$$.S.Byte).Count)
                {
                    x1 = $.$sih.SIH.VectorHelper.FoldPolynomialPair($.$$.SRI$1.Vector128.AsUInt64($.$$.S.Byte, $.$$.SRI$1.Vector128.LoadUnsafe$3($.$$.S.Byte, srcRef)), x1, $.$$.SRI$1.Vector128.Create$31(0x1751997D0n, 0xCCAA009En));
                    srcRef = $.$$.SRC.Unsafe.Add($.$$.S.Byte, srcRef, $.$$.SRI$1.Vector128$$($.$$.S.Byte).Count);
                    length -= $.$$.SRI$1.Vector128$$($.$$.S.Byte).Count;
                }
                /*Vector128<ulong>*/ let bitmask = $.$$.SRI$1.Vector128.AsUInt64($.$$.S.Int32, $.$$.SRI$1.Vector128.Create$6(~0, 0, ~0, 0));
                x1 = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr($.$sih.SIH.VectorHelper.ShiftRightBytesInVector(x1, 8), $.$sih.SIH.VectorHelper.CarrylessMultiplyLower(x1, $.$$.SRI$1.Vector128.CreateScalar$10(0xCCAA009En)));
                x1 = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr($.$sih.SIH.VectorHelper.CarrylessMultiplyLower($.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_BitwiseAnd(x1, bitmask), $.$$.SRI$1.Vector128.CreateScalar$10(0x163CD6124n)), $.$sih.SIH.VectorHelper.ShiftRightBytesInVector(x1, 4));
                kConstants = $.$$.SRI$1.Vector128.Create$31(0x1DB710641n, 0x1F7011641n);
                x2 = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_BitwiseAnd($.$sih.SIH.VectorHelper.CarrylessMultiplyLeftLowerRightUpper($.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_BitwiseAnd(x1, bitmask), kConstants), bitmask);
                x2 = $.$sih.SIH.VectorHelper.CarrylessMultiplyLower(x2, kConstants);
                x1 = $.$$.SRI$1.Vector128$$($.$$.S.UInt64).op_ExclusiveOr(x1, x2);
                /*uint*/ let result = $.$$.SRI$1.Vector128.GetElement($.$$.S.UInt32, $.$$.SRI$1.Vector128.AsUInt32($.$$.S.UInt64, x1), 1);
                return length > 0 ? $.$sih.SIH.Crc32.UpdateScalar(result, $.$$.SRI.MemoryMarshal.CreateReadOnlySpan($.$$.S.Byte, srcRef, length)) : result;
            }
            //--TRIMMABLE-BOUNDARY-END(107374247968)
            
            //--TRIMMABLE-BOUNDARY-START(8590000160)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590000160)
            
            static $h = 65568;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sih.SIH.NonCryptographicHashAlgorithm; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064836640),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.UInt32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654771232,
        "f": 50331682
      },
      "n": "CrcLookup",
      "d": 65568,
      "h": 30064836640,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(30064836640)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103079280672),
    {
      "r": 720897,
      "p": [
        {
          "n": "crc",
          "p": 720897
        },
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "UpdateScalarArm64",
      "d": 65568,
      "h": 103079280672,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103079280672),
//--TRIMMABLE-BOUNDARY-START(98784313376),
    {
      "r": 720897,
      "p": [
        {
          "n": "crc",
          "p": 720897
        },
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "UpdateScalarArm32",
      "d": 65568,
      "h": 98784313376,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(98784313376),
//--TRIMMABLE-BOUNDARY-START(25769869344),
    {
      "r": 65568,
      "n": "Clone",
      "d": 65568,
      "h": 25769869344,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769869344),
//--TRIMMABLE-BOUNDARY-START(17179934752),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": 65568,
      "h": 17179934752,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17179934752),
//--TRIMMABLE-BOUNDARY-START(77309476896),
    {
      "r": 65537,
      "n": "Reset",
      "d": 65568,
      "h": 77309476896,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77309476896),
//--TRIMMABLE-BOUNDARY-START(47244705824),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetCurrentHashCore",
      "d": 65568,
      "h": 47244705824,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47244705824),
//--TRIMMABLE-BOUNDARY-START(51539673120),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetHashAndResetCore",
      "d": 65568,
      "h": 51539673120,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51539673120),
//--TRIMMABLE-BOUNDARY-START(42949738528),
    {
      "r": 720897,
      "n": "GetCurrentHashAsUInt32",
      "d": 65568,
      "h": 42949738528,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42949738528),
//--TRIMMABLE-BOUNDARY-START(55834640416),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Hash",
      "d": 65568,
      "h": 55834640416,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55834640416),
//--TRIMMABLE-BOUNDARY-START(64424575008),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Hash",
      "o": "@$2",
      "d": 65568,
      "h": 64424575008,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64424575008),
//--TRIMMABLE-BOUNDARY-START(85899411488),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryHash",
      "d": 65568,
      "h": 85899411488,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85899411488),
//--TRIMMABLE-BOUNDARY-START(60129607712),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "Hash",
      "o": "@$1",
      "d": 65568,
      "h": 60129607712,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60129607712),
//--TRIMMABLE-BOUNDARY-START(68719542304),
    {
      "r": 720897,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "HashToUInt32",
      "d": 65568,
      "h": 68719542304,
      "f": 16777249,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719542304),
//--TRIMMABLE-BOUNDARY-START(90194378784),
    {
      "r": 720897,
      "p": [
        {
          "n": "crc",
          "p": 720897
        },
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Update",
      "d": 65568,
      "h": 90194378784,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90194378784),
//--TRIMMABLE-BOUNDARY-START(94489346080),
    {
      "r": 720897,
      "p": [
        {
          "n": "crc",
          "p": 720897
        },
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "UpdateScalar",
      "d": 65568,
      "h": 94489346080,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94489346080),
//--TRIMMABLE-BOUNDARY-START(21474902048),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "CanBeVectorized",
      "d": 65568,
      "h": 21474902048,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21474902048),
//--TRIMMABLE-BOUNDARY-START(107374247968),
    {
      "r": 720897,
      "p": [
        {
          "n": "crc",
          "p": 720897
        },
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "UpdateVectorized",
      "d": 65568,
      "h": 107374247968,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107374247968)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73014509600),
    {
      "t": 720897,
      "n": "InitialState",
      "d": 65568,
      "h": 73014509600,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73014509600),
//--TRIMMABLE-BOUNDARY-START(81604444192),
    {
      "t": 655361,
      "n": "Size",
      "d": 65568,
      "h": 81604444192,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81604444192),
//--TRIMMABLE-BOUNDARY-START(4295032864),
    {
      "t": 720897,
      "n": "_crc",
      "d": 65568,
      "h": 4295032864,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032864)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590000160),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65568,
      "h": 8590000160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000160),
//--TRIMMABLE-BOUNDARY-START(12884967456),
    {
      "p": [
        {
          "n": "crc",
          "p": 720897
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65568,
      "h": 12884967456,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12884967456)
  ],
  "h": 65568
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.Crc32`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}Crc32`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65568)
        
        

        //--TRIMMABLE-BOUNDARY-START(720928)
        $asm.$cls(`$sih.SIH.XxHash64`, ($self) => class XxHash64 extends $.$sih.SIH.NonCryptographicHashAlgorithm
        {
            //--TRIMMABLE-BOUNDARY-START(38655426592)
            static /*ulong */ Avalanche(/*ulong*/ hash)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655426592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                hash ^= hash >> 33n;
                hash *= 14029467366897019727n;
                hash ^= hash >> 29n;
                hash *= 1609587929392839161n;
                hash ^= hash >> 32n;
                return hash;
            }
            //--TRIMMABLE-BOUNDARY-END(38655426592)
            
            //--TRIMMABLE-BOUNDARY-START(786464)
            static $_State;
            static get State()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sih.SIH.XxHash64;
                return $cls.$_State ??= $asm.$nstr(`$sih.SIH.XxHash64.State`, ($self) => class State extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295753760)
                    /*ulong*/ _acc1 = 0n;
                    //--TRIMMABLE-BOUNDARY-END(4295753760)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590721056)
                    /*ulong*/ _acc2 = 0n;
                    //--TRIMMABLE-BOUNDARY-END(8590721056)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885688352)
                    /*ulong*/ _acc3 = 0n;
                    //--TRIMMABLE-BOUNDARY-END(12885688352)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180655648)
                    /*ulong*/ _acc4 = 0n;
                    //--TRIMMABLE-BOUNDARY-END(17180655648)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770590240)
                    /*ulong*/ _smallAcc = 0n;
                    //--TRIMMABLE-BOUNDARY-END(25770590240)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475622944)
                    /*bool*/ _hadFullStripe = false;
                    //--TRIMMABLE-BOUNDARY-END(21475622944)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360524832)
                    $ctor$3(/*ulong*/ seed)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34360524832);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._acc1 = BigInt.asUintN(64, seed + BigInt.asUintN(64, 11400714785074694791n + 14029467366897019727n));
                            this._acc2 = BigInt.asUintN(64, seed + 14029467366897019727n);
                            this._acc3 = seed;
                            this._acc4 = BigInt.asUintN(64, seed - 11400714785074694791n);
                            this._smallAcc = BigInt.asUintN(64, seed + 2870177450012600261n);
                            this._hadFullStripe = false;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360524832)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130328608)
                    /*void */ ProcessStripe(/*ReadOnlySpan<byte>*/ source)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60130328608);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4(source.Length >= 32/*StripeSize*/, "source.Length >= StripeSize");
                        source = source.Slice(0, 32/*StripeSize*/);
                        this._acc1 = $.$sih.SIH.XxHash64.State.ApplyRound(this._acc1, source);
                        this._acc2 = $.$sih.SIH.XxHash64.State.ApplyRound(this._acc2, source.Slice$1(8));
                        this._acc3 = $.$sih.SIH.XxHash64.State.ApplyRound(this._acc3, source.Slice$1(((2 * 8) | 0)));
                        this._acc4 = $.$sih.SIH.XxHash64.State.ApplyRound(this._acc4, source.Slice$1(((3 * 8) | 0)));
                        this._hadFullStripe = true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130328608)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835361312)
                    static /*ulong */ MergeAccumulator(/*ulong*/ acc, /*ulong*/ accN)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55835361312);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        acc ^= $.$sih.SIH.XxHash64.State.ApplyRound$1(0n, accN);
                        acc *= 11400714785074694791n;
                        acc += 9650029242287828579n;
                        return acc;
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835361312)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540394016)
                    /*ulong */ Converge()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540394016);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*ulong*/ let acc = BigInt.asUintN(64, BigInt.asUintN(64, BigInt.asUintN(64, $.$$.SN$1.BitOperations.RotateLeft$1(this._acc1, 1) + $.$$.SN$1.BitOperations.RotateLeft$1(this._acc2, 7)) + $.$$.SN$1.BitOperations.RotateLeft$1(this._acc3, 12)) + $.$$.SN$1.BitOperations.RotateLeft$1(this._acc4, 18));
                        acc = $.$sih.SIH.XxHash64.State.MergeAccumulator(acc, this._acc1);
                        acc = $.$sih.SIH.XxHash64.State.MergeAccumulator(acc, this._acc2);
                        acc = $.$sih.SIH.XxHash64.State.MergeAccumulator(acc, this._acc3);
                        acc = $.$sih.SIH.XxHash64.State.MergeAccumulator(acc, this._acc4);
                        return acc;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540394016)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655492128)
                    static /*ulong */ ApplyRound(/*ulong*/ acc, /*ReadOnlySpan<byte>*/ lane)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655492128);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$sih.SIH.XxHash64.State.ApplyRound$1(acc, $.$$.SBB.BinaryPrimitives.ReadUInt64LittleEndian(lane));
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655492128)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950459424)
                    static /*ulong */ ApplyRound$1(/*ulong*/ acc, /*ulong*/ lane)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950459424);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        acc += BigInt.asUintN(64, lane * 14029467366897019727n);
                        acc = $.$$.SN$1.BitOperations.RotateLeft$1(acc, 31);
                        acc *= 11400714785074694791n;
                        return acc;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950459424)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245426720)
                    /*ulong */ Complete(/*long*/ length, /*ReadOnlySpan<byte>*/ remaining)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245426720);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*ulong*/ let acc = this._hadFullStripe ? this.Converge() : this._smallAcc;
                        acc += $.$cast(length, $.$$.S.UInt64);
                        while(remaining.Length >= 8)
                        {
                            /*ulong*/ let lane = $.$$.SBB.BinaryPrimitives.ReadUInt64LittleEndian(remaining);
                            acc ^= $.$sih.SIH.XxHash64.State.ApplyRound$1(0n, lane);
                            acc = $.$$.SN$1.BitOperations.RotateLeft$1(acc, 27);
                            acc *= 11400714785074694791n;
                            acc += 9650029242287828579n;
                            remaining = remaining.Slice$1(8);
                        }
                        if (remaining.Length >= 4)
                        {
                            /*ulong*/ let lane = BigInt($.$$.SBB.BinaryPrimitives.ReadUInt32LittleEndian(remaining));
                            acc ^= BigInt.asUintN(64, lane * 11400714785074694791n);
                            acc = $.$$.SN$1.BitOperations.RotateLeft$1(acc, 23);
                            acc *= 14029467366897019727n;
                            acc += 1609587929392839161n;
                            remaining = remaining.Slice$1(4);
                        }
                        for(/*int*/ let i = 0; i < remaining.Length; i++)
                        {
                            /*ulong*/ let lane = BigInt(remaining._reference.GetAt(i));
                            acc ^= BigInt.asUintN(64, lane * 2870177450012600261n);
                            acc = $.$$.SN$1.BitOperations.RotateLeft$1(acc, 11);
                            acc *= 11400714785074694791n;
                        }
                        return $.$sih.SIH.XxHash64.Avalanche(acc);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245426720)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065557536)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065557536);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065557536)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065557536)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065557536)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._acc1 = this._acc1;
                        copy._acc2 = this._acc2;
                        copy._acc3 = this._acc3;
                        copy._acc4 = this._acc4;
                        copy._smallAcc = this._smallAcc;
                        copy._hadFullStripe = this._hadFullStripe;
                        return copy;
                    }
                    static $h = 786464;
                    static $z = 41;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130328608),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "ProcessStripe",
      "d": 786464,
      "h": 60130328608,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(60130328608),
//--TRIMMABLE-BOUNDARY-START(55835361312),
    {
      "r": 983041,
      "p": [
        {
          "n": "acc",
          "p": 983041
        },
        {
          "n": "accN",
          "p": 983041
        }
      ],
      "n": "MergeAccumulator",
      "d": 786464,
      "h": 55835361312,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55835361312),
//--TRIMMABLE-BOUNDARY-START(51540394016),
    {
      "r": 983041,
      "n": "Converge",
      "d": 786464,
      "h": 51540394016,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540394016),
//--TRIMMABLE-BOUNDARY-START(38655492128),
    {
      "r": 983041,
      "p": [
        {
          "n": "acc",
          "p": 983041
        },
        {
          "n": "lane",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "ApplyRound",
      "d": 786464,
      "h": 38655492128,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38655492128),
//--TRIMMABLE-BOUNDARY-START(42950459424),
    {
      "r": 983041,
      "p": [
        {
          "n": "acc",
          "p": 983041
        },
        {
          "n": "lane",
          "p": 983041
        }
      ],
      "n": "ApplyRound",
      "o": "@$1",
      "d": 786464,
      "h": 42950459424,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42950459424),
//--TRIMMABLE-BOUNDARY-START(47245426720),
    {
      "r": 983041,
      "p": [
        {
          "n": "length",
          "p": 917505
        },
        {
          "n": "remaining",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Complete",
      "d": 786464,
      "h": 47245426720,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47245426720)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295753760),
    {
      "t": 983041,
      "n": "_acc1",
      "d": 786464,
      "h": 4295753760,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753760),
//--TRIMMABLE-BOUNDARY-START(8590721056),
    {
      "t": 983041,
      "n": "_acc2",
      "d": 786464,
      "h": 8590721056,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721056),
//--TRIMMABLE-BOUNDARY-START(12885688352),
    {
      "t": 983041,
      "n": "_acc3",
      "d": 786464,
      "h": 12885688352,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688352),
//--TRIMMABLE-BOUNDARY-START(17180655648),
    {
      "t": 983041,
      "n": "_acc4",
      "d": 786464,
      "h": 17180655648,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180655648),
//--TRIMMABLE-BOUNDARY-START(25770590240),
    {
      "t": 983041,
      "n": "_smallAcc",
      "d": 786464,
      "h": 25770590240,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770590240),
//--TRIMMABLE-BOUNDARY-START(21475622944),
    {
      "t": 262145,
      "n": "_hadFullStripe",
      "d": 786464,
      "h": 21475622944,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475622944)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360524832),
    {
      "p": [
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786464,
      "h": 34360524832,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34360524832),
//--TRIMMABLE-BOUNDARY-START(30065557536),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786464,
      "h": 30065557536,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065557536)
  ],
  "d": 720928,
  "h": 786464
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.XxHash64+State`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}XxHash64${separator}State`; }
                }, $cls, ($v) => $cls.$_State = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786464)
            
            //--TRIMMABLE-BOUNDARY-START(73015164960)
            /*int*/ static HashSize = 8;
            //--TRIMMABLE-BOUNDARY-END(73015164960)
            
            //--TRIMMABLE-BOUNDARY-START(85900066848)
            /*int*/ static StripeSize = 32;
            //--TRIMMABLE-BOUNDARY-END(85900066848)
            
            //--TRIMMABLE-BOUNDARY-START(12885622816)
            /*ulong*/ _seed = 0n;
            //--TRIMMABLE-BOUNDARY-END(12885622816)
            
            //--TRIMMABLE-BOUNDARY-START(17180590112)
            /*State*/ _state;
            //--TRIMMABLE-BOUNDARY-END(17180590112)
            
            //--TRIMMABLE-BOUNDARY-START(4295688224)
            /*byte[]?*/ _holdback = null;
            //--TRIMMABLE-BOUNDARY-END(4295688224)
            
            //--TRIMMABLE-BOUNDARY-START(8590655520)
            /*long*/ _length = 0n;
            //--TRIMMABLE-BOUNDARY-END(8590655520)
            
            //--TRIMMABLE-BOUNDARY-START(21475557408)
            $ctor$2()
            {
                this.$ctor$3(0n);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557408);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557408)
            
            //--TRIMMABLE-BOUNDARY-START(25770524704)
            $ctor$3(/*long*/ seed)
            {
                super.$ctor$1(8/*HashSize*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770524704);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._seed = $.$cast(seed, $.$$.S.UInt64);
                    this.Reset();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770524704)
            
            //--TRIMMABLE-BOUNDARY-START(30065492000)
            $ctor$4(/*ulong*/ seed, /*State*/ state, /*byte[]?*/ holdback, /*long*/ length)
            {
                super.$ctor$1(8/*HashSize*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065492000);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._seed = seed;
                    this._state = $.$clone(state);
                    if (($.$cast(length, $.$$.S.Int32) & 31) > 0)
                    {
                        this._holdback = $.$cast((holdback?.Clone() ?? null), $.$typeArray($.$$.S.Byte));
                    }
                    this._length = length;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065492000)
            
            //--TRIMMABLE-BOUNDARY-START(42950393888)
            /*XxHash64 */ Clone()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950393888);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sih.SIH.XxHash64().$ctor$4(this._seed, $.$clone(this._state), this._holdback, this._length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950393888)
            
            //--TRIMMABLE-BOUNDARY-START(81605099552)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._state = new $.$sih.SIH.XxHash64.State().$ctor$3(this._seed);
                this._length = 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(81605099552)
            
            //--TRIMMABLE-BOUNDARY-START(34360459296)
            /*void */ Append$2(/*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360459296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let held = $.$cast(this._length, $.$$.S.Int32) & 31;
                if (held !== 0)
                {
                    /*int*/ let remain = ((32/*StripeSize*/ - held) | 0);
                    if (source.Length >= remain)
                    {
                        source.Slice(0, remain).CopyTo($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._holdback, held));
                        this._state.ProcessStripe($.$$.S.ReadOnlySpan$$($.$$.S.Byte).op_Implicit$1(this._holdback));
                        source = source.Slice$1(remain);
                        this._length += BigInt(remain);
                    }
                    else 
                    {
                        source.CopyTo($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._holdback, held));
                        this._length += BigInt(source.Length);
                        return;
                    }
                }
                while(source.Length >= 32/*StripeSize*/)
                {
                    this._state.ProcessStripe(source);
                    source = source.Slice$1(32/*StripeSize*/);
                    this._length += BigInt(32/*StripeSize*/);
                }
                if (source.Length > 0)
                {
                    this._holdback ??= $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [32/*StripeSize*/], null);
                    source.CopyTo($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(this._holdback));
                    this._length += BigInt(source.Length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360459296)
            
            //--TRIMMABLE-BOUNDARY-START(51540328480)
            /*void */ GetCurrentHashCore(/*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ulong*/ let hash = this.GetCurrentHashAsUInt64();
                $.$$.SBB.BinaryPrimitives.WriteUInt64BigEndian(destination, hash);
            }
            //--TRIMMABLE-BOUNDARY-END(51540328480)
            
            //--TRIMMABLE-BOUNDARY-START(47245361184)
            /*ulong */ GetCurrentHashAsUInt64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let remainingLength = $.$cast(this._length, $.$$.S.Int32) & 31;
                /*ReadOnlySpan<byte>*/ let remaining = $.$$.S.ReadOnlySpan$$($.$$.S.Byte).Empty;
                if (remainingLength > 0)
                {
                    remaining = new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$6(this._holdback, 0, remainingLength);
                }
                return this._state.Complete(this._length, remaining);
            }
            //--TRIMMABLE-BOUNDARY-END(47245361184)
            
            //--TRIMMABLE-BOUNDARY-START(60130263072)
            static /*byte[] */ Hash$1(/*byte[]*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$sih.SIH.XxHash64.Hash$2(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7(source), 0n);
            }
            //--TRIMMABLE-BOUNDARY-END(60130263072)
            
            //--TRIMMABLE-BOUNDARY-START(55835295776)
            static /*byte[] */ Hash(/*byte[]*/ source, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$sih.SIH.XxHash64.Hash$2(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7(source), seed);
            }
            //--TRIMMABLE-BOUNDARY-END(55835295776)
            
            //--TRIMMABLE-BOUNDARY-START(64425230368)
            static /*byte[] */ Hash$2(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let ret = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [8/*HashSize*/], null);
                /*ulong*/ let hash = $.$sih.SIH.XxHash64.HashToUInt64(source, seed);
                $.$$.SBB.BinaryPrimitives.WriteUInt64BigEndian($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(ret), hash);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(64425230368)
            
            //--TRIMMABLE-BOUNDARY-START(90195034144)
            static /*bool */ TryHash(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesWritten, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < 8/*HashSize*/)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                /*ulong*/ let hash = $.$sih.SIH.XxHash64.HashToUInt64(source, seed);
                $.$$.SBB.BinaryPrimitives.WriteUInt64BigEndian(destination, hash);
                bytesWritten.$v = 8/*HashSize*/;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(90195034144)
            
            //--TRIMMABLE-BOUNDARY-START(68720197664)
            static /*int */ Hash$3(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < 8/*HashSize*/)
                {
                    $.$sih.SIH.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                /*ulong*/ let hash = $.$sih.SIH.XxHash64.HashToUInt64(source, seed);
                $.$$.SBB.BinaryPrimitives.WriteUInt64BigEndian(destination, hash);
                return 8/*HashSize*/;
            }
            //--TRIMMABLE-BOUNDARY-END(68720197664)
            
            //--TRIMMABLE-BOUNDARY-START(77310132256)
            static /*ulong */ HashToUInt64(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310132256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let totalLength = source.Length;
                /*State*/ let state = new $.$sih.SIH.XxHash64.State().$ctor$3($.$cast(seed, $.$$.S.UInt64));
                while(source.Length >= 32/*StripeSize*/)
                {
                    state.ProcessStripe(source);
                    source = source.Slice$1(32/*StripeSize*/);
                }
                return state.Complete(BigInt((totalLength >>> 0)), source);
            }
            //--TRIMMABLE-BOUNDARY-END(77310132256)
            
            //--TRIMMABLE-BOUNDARY-START(21475557408)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21475557408)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180590112)
                this._state = $.$default($.$sih.SIH.XxHash64.State);
                //--TRIMMABLE-BOUNDARY-END(17180590112)
                
            }
            static $h = 720928;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sih.SIH.NonCryptographicHashAlgorithm; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655426592),
    {
      "r": 983041,
      "p": [
        {
          "n": "hash",
          "p": 983041
        }
      ],
      "n": "Avalanche",
      "d": 720928,
      "h": 38655426592,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38655426592),
//--TRIMMABLE-BOUNDARY-START(42950393888),
    {
      "r": 720928,
      "n": "Clone",
      "d": 720928,
      "h": 42950393888,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950393888),
//--TRIMMABLE-BOUNDARY-START(81605099552),
    {
      "r": 65537,
      "n": "Reset",
      "d": 720928,
      "h": 81605099552,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605099552),
//--TRIMMABLE-BOUNDARY-START(34360459296),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": 720928,
      "h": 34360459296,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360459296),
//--TRIMMABLE-BOUNDARY-START(51540328480),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetCurrentHashCore",
      "d": 720928,
      "h": 51540328480,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540328480),
//--TRIMMABLE-BOUNDARY-START(47245361184),
    {
      "r": 983041,
      "n": "GetCurrentHashAsUInt64",
      "d": 720928,
      "h": 47245361184,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245361184),
//--TRIMMABLE-BOUNDARY-START(60130263072),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Hash",
      "o": "@$1",
      "d": 720928,
      "h": 60130263072,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130263072),
//--TRIMMABLE-BOUNDARY-START(55835295776),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 917505
        }
      ],
      "n": "Hash",
      "d": 720928,
      "h": 55835295776,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835295776),
//--TRIMMABLE-BOUNDARY-START(64425230368),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 917505,
          "f": 65,
          "v": 0
        }
      ],
      "n": "Hash",
      "o": "@$2",
      "d": 720928,
      "h": 64425230368,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64425230368),
//--TRIMMABLE-BOUNDARY-START(90195034144),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "seed",
          "p": 917505,
          "f": 65,
          "v": 0
        }
      ],
      "n": "TryHash",
      "d": 720928,
      "h": 90195034144,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90195034144),
//--TRIMMABLE-BOUNDARY-START(68720197664),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 917505,
          "f": 65,
          "v": 0
        }
      ],
      "n": "Hash",
      "o": "@$3",
      "d": 720928,
      "h": 68720197664,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68720197664),
//--TRIMMABLE-BOUNDARY-START(77310132256),
    {
      "r": 983041,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 917505,
          "f": 65,
          "v": 0
        }
      ],
      "n": "HashToUInt64",
      "d": 720928,
      "h": 77310132256,
      "f": 16777249,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310132256)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015164960),
    {
      "t": 655361,
      "n": "HashSize",
      "d": 720928,
      "h": 73015164960,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73015164960),
//--TRIMMABLE-BOUNDARY-START(85900066848),
    {
      "t": 655361,
      "n": "StripeSize",
      "d": 720928,
      "h": 85900066848,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(85900066848),
//--TRIMMABLE-BOUNDARY-START(12885622816),
    {
      "t": 983041,
      "n": "_seed",
      "d": 720928,
      "h": 12885622816,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622816),
//--TRIMMABLE-BOUNDARY-START(17180590112),
    {
      "t": 786464,
      "n": "_state",
      "d": 720928,
      "h": 17180590112,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590112),
//--TRIMMABLE-BOUNDARY-START(4295688224),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_holdback",
      "d": 720928,
      "h": 4295688224,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688224),
//--TRIMMABLE-BOUNDARY-START(8590655520),
    {
      "t": 917505,
      "n": "_length",
      "d": 720928,
      "h": 8590655520,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655520)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475557408),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720928,
      "h": 21475557408,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557408),
//--TRIMMABLE-BOUNDARY-START(25770524704),
    {
      "p": [
        {
          "n": "seed",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720928,
      "h": 25770524704,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770524704),
//--TRIMMABLE-BOUNDARY-START(30065492000),
    {
      "p": [
        {
          "n": "seed",
          "p": 983041
        },
        {
          "n": "state",
          "p": 786464
        },
        {
          "n": "holdback",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 720928,
      "h": 30065492000,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065492000)
  ],
  "h": 720928
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sih.SIH.XxHash64.State ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.XxHash64`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}XxHash64`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720928)
        
        

        //--TRIMMABLE-BOUNDARY-START(393248)
        $asm.$cls(`$sih.SIH.XxHash128`, ($self) => class XxHash128 extends $.$sih.SIH.NonCryptographicHashAlgorithm
        {
            //--TRIMMABLE-BOUNDARY-START(90194706464)
            /*int*/ static HashLengthInBytes$1 = 16;
            //--TRIMMABLE-BOUNDARY-END(90194706464)
            
            //--TRIMMABLE-BOUNDARY-START(4295360544)
            /*State*/ _state;
            //--TRIMMABLE-BOUNDARY-END(4295360544)
            
            //--TRIMMABLE-BOUNDARY-START(8590327840)
            $ctor$2()
            {
                this.$ctor$3(0n);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327840);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327840)
            
            //--TRIMMABLE-BOUNDARY-START(12885295136)
            $ctor$3(/*long*/ seed)
            {
                super.$ctor$1(16/*HashLengthInBytes*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295136);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$sih.SIH.XxHashShared.Initialize($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sih.SIH.XxHashShared.State, () => this._state, ($v) => this._state = $v, null, true), $.$cast(seed, $.$$.S.UInt64));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885295136)
            
            //--TRIMMABLE-BOUNDARY-START(17180262432)
            $ctor$4(/*State*/ state)
            {
                super.$ctor$1(16/*HashLengthInBytes*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180262432);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._state = $.$clone(state);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180262432)
            
            //--TRIMMABLE-BOUNDARY-START(30065164320)
            /*XxHash128 */ Clone()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065164320);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sih.SIH.XxHash128().$ctor$4($.$clone(this._state));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065164320)
            
            //--TRIMMABLE-BOUNDARY-START(51540000800)
            static /*byte[] */ Hash$1(/*byte[]*/ source)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540000800);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sih.SIH.XxHash128.Hash(source, 0n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540000800)
            
            //--TRIMMABLE-BOUNDARY-START(47245033504)
            static /*byte[] */ Hash(/*byte[]*/ source, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245033504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$sih.SIH.XxHash128.Hash$2(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7(source), seed);
            }
            //--TRIMMABLE-BOUNDARY-END(47245033504)
            
            //--TRIMMABLE-BOUNDARY-START(55834968096)
            static /*byte[] */ Hash$2(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834968096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let result = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [16/*HashLengthInBytes*/], null);
                $.$sih.SIH.XxHash128.Hash$3(source, $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(result), seed);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(55834968096)
            
            //--TRIMMABLE-BOUNDARY-START(60129935392)
            static /*int */ Hash$3(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*long*/ seed)
            {
                /*int*/ let bytesWritten;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129935392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$sih.SIH.XxHash128.TryHash(source, destination, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.S.Int32), seed))
                {
                    $.$sih.SIH.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                return bytesWritten;
            }
            //--TRIMMABLE-BOUNDARY-END(60129935392)
            
            //--TRIMMABLE-BOUNDARY-START(115964510240)
            static /*bool */ TryHash(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesWritten, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964510240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length >= ((8 * 2) | 0))
                {
                    /*Hash128*/ let hash = $.$sih.SIH.XxHash128.HashToHash128(source, seed);
                    $.$sih.SIH.XxHash128.WriteBigEndian128($.$ref(() => hash, ), destination);
                    bytesWritten.$v = 16/*HashLengthInBytes*/;
                    return true;
                }
                bytesWritten.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(115964510240)
            
            //--TRIMMABLE-BOUNDARY-START(103079608352)
            static /*UInt128 */ HashToUInt128(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079608352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Hash128*/ let hash = $.$sih.SIH.XxHash128.HashToHash128(source, seed);
                return new $.$$.S.UInt128().$ctor$3(hash.High64, hash.Low64);
            }
            //--TRIMMABLE-BOUNDARY-END(103079608352)
            
            //--TRIMMABLE-BOUNDARY-START(98784641056)
            static /*Hash128 */ HashToHash128(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784641056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let length = (source.Length >>> 0);
                /*fixed*/ 
                {
                    /*byte**/ let sourcePtr = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Byte, source);
                    if (length <= 16)
                    {
                        return $.$sih.SIH.XxHash128.HashLength0To16(sourcePtr, length, $.$cast(seed, $.$$.S.UInt64));
                    }
                    if (length <= 128)
                    {
                        return $.$sih.SIH.XxHash128.HashLength17To128(sourcePtr, length, $.$cast(seed, $.$$.S.UInt64));
                    }
                    if (length <= 240/*MidSizeMaxBytes*/)
                    {
                        return $.$sih.SIH.XxHash128.HashLength129To240(sourcePtr, length, $.$cast(seed, $.$$.S.UInt64));
                    }
                    return $.$sih.SIH.XxHash128.HashLengthOver240(sourcePtr, length, $.$cast(seed, $.$$.S.UInt64));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784641056)
            
            //--TRIMMABLE-BOUNDARY-START(111669542944)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669542944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sih.SIH.XxHashShared.Reset($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sih.SIH.XxHashShared.State, () => this._state, ($v) => this._state = $v, null, true));
            }
            //--TRIMMABLE-BOUNDARY-END(111669542944)
            
            //--TRIMMABLE-BOUNDARY-START(21475229728)
            /*void */ Append$2(/*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sih.SIH.XxHashShared.Append($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sih.SIH.XxHashShared.State, () => this._state, ($v) => this._state = $v, null, true), source);
            }
            //--TRIMMABLE-BOUNDARY-END(21475229728)
            
            //--TRIMMABLE-BOUNDARY-START(42950066208)
            /*void */ GetCurrentHashCore(/*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950066208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Hash128*/ let current = this.GetCurrentHashAsHash128();
                $.$sih.SIH.XxHash128.WriteBigEndian128($.$ref(() => current, ), destination);
            }
            //--TRIMMABLE-BOUNDARY-END(42950066208)
            
            //--TRIMMABLE-BOUNDARY-START(34360131616)
            /*Hash128 */ GetCurrentHashAsHash128()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360131616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Hash128*/ let current;
                if (this._state.TotalLength > BigInt(240/*MidSizeMaxBytes*/))
                {
                    /*ulong**/ let accumulators = $.$$.SRC.RuntimeHelpers.StackAllocPointer($.$$.S.UInt64, 8/*AccumulatorCount*/, null);
                    $.$sih.SIH.XxHashShared.CopyAccumulators($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sih.SIH.XxHashShared.State, () => this._state, ($v) => this._state = $v, null, true), accumulators);
                    /*fixed*/ 
                    {
                        /*byte**/ let secret = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$$.S.Byte, this._state.Secret, null, false, true);
                        $.$sih.SIH.XxHashShared.DigestLong($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sih.SIH.XxHashShared.State, () => this._state, ($v) => this._state = $v, null, true), accumulators, secret);
                        current = new $.$sih.SIH.XxHash128.Hash128().$ctor$3($.$sih.SIH.XxHashShared.MergeAccumulators(accumulators, secret.Add(11/*SecretMergeAccsStartBytes*/), BigInt.asUintN(64, this._state.TotalLength * 11400714785074694791n)), $.$sih.SIH.XxHashShared.MergeAccumulators(accumulators, secret.Add(192/*SecretLengthBytes*/).Add(-((8/*AccumulatorCount*/ * 8) | 0)).Add(-11/*SecretMergeAccsStartBytes*/), (~(BigInt.asUintN(64, this._state.TotalLength * 14029467366897019727n)) & 0xFFFFFFFFFFFFFFFFn)));
                    }
                }
                else 
                {
                    /*fixed*/ 
                    {
                        /*byte**/ let buffer = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$$.S.Byte, this._state.Buffer, null, false, true);
                        current = $.$sih.SIH.XxHash128.HashToHash128(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$4(buffer, $.$cast(this._state.TotalLength, $.$$.S.Int32)), $.$cast(this._state.Seed, $.$$.S.Int64));
                    }
                }
                return current;
            }
            //--TRIMMABLE-BOUNDARY-END(34360131616)
            
            //--TRIMMABLE-BOUNDARY-START(38655098912)
            /*UInt128 */ GetCurrentHashAsUInt128()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655098912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Hash128*/ let current = this.GetCurrentHashAsHash128();
                return new $.$$.S.UInt128().$ctor$3(current.High64, current.Low64);
            }
            //--TRIMMABLE-BOUNDARY-END(38655098912)
            
            //--TRIMMABLE-BOUNDARY-START(120259477536)
            static /*void */ WriteBigEndian128(/*in Hash128*/ hash, /*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259477536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ulong*/ let low = hash.$v.Low64;
                /*ulong*/ let high = hash.$v.High64;
                if ($.$$.S.BitConverter.IsLittleEndian)
                {
                    low = $.$$.SBB.BinaryPrimitives.ReverseEndianness$21(low);
                    high = $.$$.SBB.BinaryPrimitives.ReverseEndianness$21(high);
                }
                /*ref byte*/ let dest0 = $.$$.SRI.MemoryMarshal.GetReference$1($.$$.S.Byte, destination);
                $.$$.SRC.Unsafe.WriteUnaligned($.$$.S.UInt64, dest0, high);
                $.$$.SRC.Unsafe.WriteUnaligned($.$$.S.UInt64, $.$$.SRC.Unsafe.AddByteOffset($.$$.S.Byte, dest0, new $.$$.S.IntPtr().$ctor$3(8)), low);
            }
            //--TRIMMABLE-BOUNDARY-END(120259477536)
            
            //--TRIMMABLE-BOUNDARY-START(64424902688)
            static /*Hash128 */ HashLength0To16(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424902688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (length > 8)
                {
                    return $.$sih.SIH.XxHash128.HashLength9To16(source, length, seed);
                }
                if (length >= 4)
                {
                    return $.$sih.SIH.XxHash128.HashLength4To8(source, length, seed);
                }
                if (length !== 0)
                {
                    return $.$sih.SIH.XxHash128.HashLength1To3(source, length, seed);
                }
                /*ulong*/ let BitFlipL = 14627906620379768892n ^ 11758427054878871688n;
                /*ulong*/ let BitFlipH = 5690594596133299313n ^ 15613098826807580984n;
                return new $.$sih.SIH.XxHash128.Hash128().$ctor$3($.$sih.SIH.XxHash64.Avalanche(seed ^ BitFlipL), $.$sih.SIH.XxHash64.Avalanche(seed ^ BitFlipH));
            }
            //--TRIMMABLE-BOUNDARY-END(64424902688)
            
            //--TRIMMABLE-BOUNDARY-START(77309804576)
            static /*Hash128 */ HashLength1To3(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309804576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(length >= 1 && length <= 3, "length >= 1 && length <= 3");
                /*byte*/ let c1 = source.$v;
                /*byte*/ let c2 = source.GetAt(length >>> 1);
                /*byte*/ let c3 = source.GetAt(((length - 1) >>> 0));
                /*uint*/ let combinedl = ((c1 << 16) >>> 0) | ((c2 << 24) >>> 0) | c3 | ((length << 8) >>> 0);
                /*uint*/ let combinedh = $.$$.SN$1.BitOperations.RotateLeft($.$$.SBB.BinaryPrimitives.ReverseEndianness$20(combinedl), 13);
                /*uint*/ let SecretXorL = ($.$cast(13712233961653862072n, $.$$.S.UInt32) ^ $.$cast((13712233961653862072n >> 32n), $.$$.S.UInt32));
                /*uint*/ let SecretXorH = ($.$cast(2066345149520216444n, $.$$.S.UInt32) ^ $.$cast((2066345149520216444n >> 32n), $.$$.S.UInt32));
                /*ulong*/ let bitflipl = BigInt.asUintN(64, BigInt(SecretXorL) + seed);
                /*ulong*/ let bitfliph = BigInt.asUintN(64, BigInt(SecretXorH) - seed);
                /*ulong*/ let keyedLo = BigInt(combinedl) ^ bitflipl;
                /*ulong*/ let keyedHi = BigInt(combinedh) ^ bitfliph;
                return new $.$sih.SIH.XxHash128.Hash128().$ctor$3($.$sih.SIH.XxHash64.Avalanche(keyedLo), $.$sih.SIH.XxHash64.Avalanche(keyedHi));
            }
            //--TRIMMABLE-BOUNDARY-END(77309804576)
            
            //--TRIMMABLE-BOUNDARY-START(81604771872)
            static /*Hash128 */ HashLength4To8(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                /*ulong*/ let m128Low;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604771872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(length >= 4 && length <= 8, "length >= 4 && length <= 8");
                seed ^= BigInt.asUintN(64, $.$cast($.$$.SBB.BinaryPrimitives.ReverseEndianness$20($.$cast(seed, $.$$.S.UInt32)), $.$$.S.UInt64) << 32n);
                /*uint*/ let inputLo = $.$sih.SIH.XxHashShared.ReadUInt32LE(source);
                /*uint*/ let inputHi = $.$sih.SIH.XxHashShared.ReadUInt32LE(source.Add(length).Add(-4));
                /*ulong*/ let input64 = BigInt.asUintN(64, BigInt(inputLo) + (BigInt.asUintN(64, $.$cast(inputHi, $.$$.S.UInt64) << 32n)));
                /*ulong*/ let bitflip = BigInt.asUintN(64, (15823274712020931806n ^ 2262974939099578482n) + seed);
                /*ulong*/ let keyed = input64 ^ bitflip;
                /*ulong*/ let m128High = $.$sih.SIH.XxHashShared.Multiply64To128(keyed, BigInt.asUintN(64, 11400714785074694791n + BigInt((length << 2) >>> 0)), $.$ref(() => m128Low, ($v) => m128Low = $v, $.$$.S.UInt64));
                m128High += (BigInt.asUintN(64, m128Low << 1n));
                m128Low ^= (m128High >> 3n);
                m128Low = $.$sih.SIH.XxHashShared.XorShift(m128Low, 35);
                m128Low *= 0x9FB21C651E98DF25n;
                m128Low = $.$sih.SIH.XxHashShared.XorShift(m128Low, 28);
                m128High = $.$sih.SIH.XxHashShared.Avalanche(m128High);
                return new $.$sih.SIH.XxHash128.Hash128().$ctor$3(m128Low, m128High);
            }
            //--TRIMMABLE-BOUNDARY-END(81604771872)
            
            //--TRIMMABLE-BOUNDARY-START(85899739168)
            static /*Hash128 */ HashLength9To16(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                /*ulong*/ let m128Low;
                /*ulong*/ let h128Low;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899739168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(length >= 9 && length <= 16, "length >= 9 && length <= 16");
                /*ulong*/ let bitflipl = BigInt.asUintN(64, (8711581037947681227n ^ 2410270004345854594n) - seed);
                /*ulong*/ let bitfliph = BigInt.asUintN(64, (10242386182634080440n ^ 5487137525590930912n) + seed);
                /*ulong*/ let inputLo = $.$sih.SIH.XxHashShared.ReadUInt64LE(source);
                /*ulong*/ let inputHi = $.$sih.SIH.XxHashShared.ReadUInt64LE(source.Add(length).Add(-8));
                /*ulong*/ let m128High = $.$sih.SIH.XxHashShared.Multiply64To128(inputLo ^ inputHi ^ bitflipl, 11400714785074694791n, $.$ref(() => m128Low, ($v) => m128Low = $v, $.$$.S.UInt64));
                m128Low += BigInt.asUintN(64, $.$cast((((length - 1) >>> 0)), $.$$.S.UInt64) << 54n);
                inputHi ^= bitfliph;
                m128High += 4 < 8 ? BigInt.asUintN(64, (inputHi & 0xFFFFFFFF00000000n) + $.$sih.SIH.XxHashShared.Multiply32To64($.$cast(inputHi, $.$$.S.UInt32), 2246822519/*Prime32_2*/)) : BigInt.asUintN(64, inputHi + $.$sih.SIH.XxHashShared.Multiply32To64($.$cast(inputHi, $.$$.S.UInt32), ((2246822519/*Prime32_2*/ - 1) >>> 0)));
                m128Low ^= $.$$.SBB.BinaryPrimitives.ReverseEndianness$21(m128High);
                /*ulong*/ let h128High = $.$sih.SIH.XxHashShared.Multiply64To128(m128Low, 14029467366897019727n, $.$ref(() => h128Low, ($v) => h128Low = $v, $.$$.S.UInt64));
                h128High += BigInt.asUintN(64, m128High * 14029467366897019727n);
                h128Low = $.$sih.SIH.XxHashShared.Avalanche(h128Low);
                h128High = $.$sih.SIH.XxHashShared.Avalanche(h128High);
                return new $.$sih.SIH.XxHash128.Hash128().$ctor$3(h128Low, h128High);
            }
            //--TRIMMABLE-BOUNDARY-END(85899739168)
            
            //--TRIMMABLE-BOUNDARY-START(73014837280)
            static /*Hash128 */ HashLength17To128(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014837280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(length >= 17 && length <= 128, "length >= 17 && length <= 128");
                /*ulong*/ let accLow = BigInt.asUintN(64, BigInt(length) * 11400714785074694791n);
                /*ulong*/ let accHigh = 0n;
                let $switchJumpState13;
                $switchJumpStart13: while(true)
                {
                    let $switch13 = $switchJumpState13 ?? ($.trunc((((length - 1) >>> 0)) / 32));
                    switch($switch13)
                    {
                        default:
                        $.$sih.SIH.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$$.S.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$$.S.UInt64), source.Add(48), source.Add(length).Add(-64), 4554437623014685352n, 2111919702937427193n, 3556072174620004746n, 7238261902898274248n, seed);
                        $switchJumpState13 = 2; /*goto case 2*/
                        continue $switchJumpStart13;
                        case 2:
                        $.$sih.SIH.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$$.S.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$$.S.UInt64), source.Add(32), source.Add(length).Add(-48), 14627906620379768892n, 11758427054878871688n, 5690594596133299313n, 15613098826807580984n, seed);
                        $switchJumpState13 = 1; /*goto case 1*/
                        continue $switchJumpStart13;
                        case 1:
                        $.$sih.SIH.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$$.S.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$$.S.UInt64), source.Add(16), source.Add(length).Add(-32), 8711581037947681227n, 2410270004345854594n, 10242386182634080440n, 5487137525590930912n, seed);
                        $switchJumpState13 = 0; /*goto case 0*/
                        continue $switchJumpStart13;
                        case 0:
                        $.$sih.SIH.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$$.S.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$$.S.UInt64), source, source.Add(length).Add(-16), 13712233961653862072n, 2066345149520216444n, 15823274712020931806n, 2262974939099578482n, seed);
                        break;
                    }
                    break;
                }
                return $.$sih.SIH.XxHash128.AvalancheHash(accLow, accHigh, length, seed);
            }
            //--TRIMMABLE-BOUNDARY-END(73014837280)
            
            //--TRIMMABLE-BOUNDARY-START(68719869984)
            static /*Hash128 */ HashLength129To240(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719869984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(length >= 129 && length <= 240, "length >= 129 && length <= 240");
                /*ulong*/ let accLow = BigInt.asUintN(64, BigInt(length) * 11400714785074694791n);
                /*ulong*/ let accHigh = 0n;
                $.$sih.SIH.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$$.S.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$$.S.UInt64), source.Add((((32 * 0) | 0))), source.Add((((32 * 0) | 0))).Add(16), 13712233961653862072n, 2066345149520216444n, 15823274712020931806n, 2262974939099578482n, seed);
                $.$sih.SIH.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$$.S.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$$.S.UInt64), source.Add((((32 * 1) | 0))), source.Add((((32 * 1) | 0))).Add(16), 8711581037947681227n, 2410270004345854594n, 10242386182634080440n, 5487137525590930912n, seed);
                $.$sih.SIH.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$$.S.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$$.S.UInt64), source.Add((((32 * 2) | 0))), source.Add((((32 * 2) | 0))).Add(16), 14627906620379768892n, 11758427054878871688n, 5690594596133299313n, 15613098826807580984n, seed);
                $.$sih.SIH.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$$.S.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$$.S.UInt64), source.Add((((32 * 3) | 0))), source.Add((((32 * 3) | 0))).Add(16), 4554437623014685352n, 2111919702937427193n, 3556072174620004746n, 7238261902898274248n, seed);
                accLow = $.$sih.SIH.XxHashShared.Avalanche(accLow);
                accHigh = $.$sih.SIH.XxHashShared.Avalanche(accHigh);
                /*uint*/ let bound = ($.trunc((length - (((32 * 4) | 0))) / 32));
                if (bound !== 0)
                {
                    $.$sih.SIH.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$$.S.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$$.S.UInt64), source.Add((((32 * 4) | 0))), source.Add((((32 * 4) | 0))).Add(16), 9295848262624092985n, 7914194659941938988n, 11835586108195898345n, 16607528436649670564n, seed);
                    if (bound >= 2)
                    {
                        $.$sih.SIH.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$$.S.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$$.S.UInt64), source.Add((((32 * 5) | 0))), source.Add((((32 * 5) | 0))).Add(16), 15013455763555273806n, 5046485836271438973n, 10391458616325699444n, 5920048007935066598n, seed);
                        if (bound === 3)
                        {
                            $.$sih.SIH.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$$.S.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$$.S.UInt64), source.Add((((32 * 6) | 0))), source.Add((((32 * 6) | 0))).Add(16), 7336514198459093435n, 5216419214072683403n, 17228863761319568023n, 8573350489219836230n, seed);
                        }
                    }
                }
                $.$sih.SIH.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$$.S.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$$.S.UInt64), source.Add(length).Add(-16), source.Add(length).Add(-32), 5695865814404364607n, 6464017090953185821n, 8320639771003045937n, 16992983559143025252n, BigInt.asUintN(64, 0n - seed));
                return $.$sih.SIH.XxHash128.AvalancheHash(accLow, accHigh, length, seed);
            }
            //--TRIMMABLE-BOUNDARY-END(68719869984)
            
            //--TRIMMABLE-BOUNDARY-START(94489673760)
            static /*Hash128 */ HashLengthOver240(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489673760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(length > 240, "length > 240");
                /*fixed*/ 
                {
                    /*byte**/ let defaultSecret = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Byte, $.$sih.SIH.XxHashShared.DefaultSecret);
                    /*byte**/ let secret = defaultSecret;
                    if (seed !== 0n)
                    {
                        /*byte**/ let customSecret = $.$$.SRC.RuntimeHelpers.StackAllocPointer($.$$.S.Byte, 192/*SecretLengthBytes*/, null);
                        $.$sih.SIH.XxHashShared.DeriveSecretFromSeed(customSecret, seed);
                        secret = customSecret;
                    }
                    /*ulong**/ let accumulators = $.$$.SRC.RuntimeHelpers.StackAllocPointer($.$$.S.UInt64, 8/*AccumulatorCount*/, null);
                    $.$sih.SIH.XxHashShared.InitializeAccumulators(accumulators);
                    $.$sih.SIH.XxHashShared.HashInternalLoop(accumulators, source, length, secret);
                    return new $.$sih.SIH.XxHash128.Hash128().$ctor$3($.$sih.SIH.XxHashShared.MergeAccumulators(accumulators, secret.Add(11/*SecretMergeAccsStartBytes*/), BigInt.asUintN(64, BigInt(length) * 11400714785074694791n)), $.$sih.SIH.XxHashShared.MergeAccumulators(accumulators, secret.Add(192/*SecretLengthBytes*/).Add(-((8/*AccumulatorCount*/ * 8) | 0)).Add(-11/*SecretMergeAccsStartBytes*/), (~(BigInt.asUintN(64, BigInt(length) * 14029467366897019727n)) & 0xFFFFFFFFFFFFFFFFn)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489673760)
            
            //--TRIMMABLE-BOUNDARY-START(25770197024)
            static /*Hash128 */ AvalancheHash(/*ulong*/ accLow, /*ulong*/ accHigh, /*uint*/ length, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770197024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ulong*/ let h128Low = BigInt.asUintN(64, accLow + accHigh);
                /*ulong*/ let h128High = BigInt.asUintN(64, BigInt.asUintN(64, (BigInt.asUintN(64, accLow * 11400714785074694791n)) + (BigInt.asUintN(64, accHigh * 9650029242287828579n))) + (BigInt.asUintN(64, (BigInt.asUintN(64, BigInt(length) - seed)) * 14029467366897019727n)));
                h128Low = $.$sih.SIH.XxHashShared.Avalanche(h128Low);
                h128High = BigInt.asUintN(64, 0n - $.$sih.SIH.XxHashShared.Avalanche(h128High));
                return new $.$sih.SIH.XxHash128.Hash128().$ctor$3(h128Low, h128High);
            }
            //--TRIMMABLE-BOUNDARY-END(25770197024)
            
            //--TRIMMABLE-BOUNDARY-START(107374575648)
            static /*void */ Mix32Bytes(/*ref ulong*/ accLow, /*ref ulong*/ accHigh, /*byte**/ input1, /*byte**/ input2, /*ulong*/ secret1, /*ulong*/ secret2, /*ulong*/ secret3, /*ulong*/ secret4, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374575648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                accLow.$v += $.$sih.SIH.XxHashShared.Mix16Bytes(input1, secret1, secret2, seed);
                accLow.$v ^= BigInt.asUintN(64, $.$sih.SIH.XxHashShared.ReadUInt64LE(input2) + $.$sih.SIH.XxHashShared.ReadUInt64LE(input2.Add(8)));
                accHigh.$v += $.$sih.SIH.XxHashShared.Mix16Bytes(input2, secret3, secret4, seed);
                accHigh.$v ^= BigInt.asUintN(64, $.$sih.SIH.XxHashShared.ReadUInt64LE(input1) + $.$sih.SIH.XxHashShared.ReadUInt64LE(input1.Add(8)));
            }
            //--TRIMMABLE-BOUNDARY-END(107374575648)
            
            //--TRIMMABLE-BOUNDARY-START(458784)
            static $_Hash128;
            static get Hash128()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(458784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sih.SIH.XxHash128;
                return $cls.$_Hash128 ??= $asm.$nstr(`$sih.SIH.XxHash128.Hash128`, ($self) => class Hash128 extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(17180327968)
                    /*ulong*/ Low64 = 0n;
                    //--TRIMMABLE-BOUNDARY-END(17180327968)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885360672)
                    /*ulong*/ High64 = 0n;
                    //--TRIMMABLE-BOUNDARY-END(12885360672)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590393376)
                    $ctor$3(/*ulong*/ low64, /*ulong*/ high64)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590393376);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Low64 = low64;
                            this.High64 = high64;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590393376)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295426080)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295426080);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295426080)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295426080)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295426080)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Low64 = this.Low64;
                        copy.High64 = this.High64;
                        return copy;
                    }
                    static $h = 458784;
                    static $z = 16;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180327968),
    {
      "t": 983041,
      "n": "Low64",
      "d": 458784,
      "h": 17180327968,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17180327968),
//--TRIMMABLE-BOUNDARY-START(12885360672),
    {
      "t": 983041,
      "n": "High64",
      "d": 458784,
      "h": 12885360672,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12885360672)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590393376),
    {
      "p": [
        {
          "n": "low64",
          "p": 983041
        },
        {
          "n": "high64",
          "p": 983041
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458784,
      "h": 8590393376,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393376),
//--TRIMMABLE-BOUNDARY-START(4295426080),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458784,
      "h": 4295426080,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426080)
  ],
  "d": 393248,
  "h": 458784,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "Low64 = {Low64}, High64 = {High64}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.XxHash128+Hash128`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}XxHash128${separator}Hash128`; }
                }, $cls, ($v) => $cls.$_Hash128 = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(458784)
            
            //--TRIMMABLE-BOUNDARY-START(8590327840)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590327840)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295360544)
                this._state = $.$default($.$sih.SIH.XxHashShared.State);
                //--TRIMMABLE-BOUNDARY-END(4295360544)
                
            }
            static $h = 393248;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sih.SIH.NonCryptographicHashAlgorithm; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065164320),
    {
      "r": 393248,
      "n": "Clone",
      "d": 393248,
      "h": 30065164320,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065164320),
//--TRIMMABLE-BOUNDARY-START(51540000800),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Hash",
      "o": "@$1",
      "d": 393248,
      "h": 51540000800,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540000800),
//--TRIMMABLE-BOUNDARY-START(47245033504),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 917505
        }
      ],
      "n": "Hash",
      "d": 393248,
      "h": 47245033504,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245033504),
//--TRIMMABLE-BOUNDARY-START(55834968096),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 917505,
          "f": 65,
          "v": 0
        }
      ],
      "n": "Hash",
      "o": "@$2",
      "d": 393248,
      "h": 55834968096,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55834968096),
//--TRIMMABLE-BOUNDARY-START(60129935392),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 917505,
          "f": 65,
          "v": 0
        }
      ],
      "n": "Hash",
      "o": "@$3",
      "d": 393248,
      "h": 60129935392,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60129935392),
//--TRIMMABLE-BOUNDARY-START(115964510240),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "seed",
          "p": 917505,
          "f": 65,
          "v": 0
        }
      ],
      "n": "TryHash",
      "d": 393248,
      "h": 115964510240,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115964510240),
//--TRIMMABLE-BOUNDARY-START(103079608352),
    {
      "r": 189726721,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 917505,
          "f": 65,
          "v": 0
        }
      ],
      "n": "HashToUInt128",
      "d": 393248,
      "h": 103079608352,
      "f": 16777249,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103079608352),
//--TRIMMABLE-BOUNDARY-START(98784641056),
    {
      "r": 458784,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 917505,
          "f": 65,
          "v": 0
        }
      ],
      "n": "HashToHash128",
      "d": 393248,
      "h": 98784641056,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(98784641056),
//--TRIMMABLE-BOUNDARY-START(111669542944),
    {
      "r": 65537,
      "n": "Reset",
      "d": 393248,
      "h": 111669542944,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669542944),
//--TRIMMABLE-BOUNDARY-START(21475229728),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": 393248,
      "h": 21475229728,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475229728),
//--TRIMMABLE-BOUNDARY-START(42950066208),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetCurrentHashCore",
      "d": 393248,
      "h": 42950066208,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(42950066208),
//--TRIMMABLE-BOUNDARY-START(34360131616),
    {
      "r": 458784,
      "n": "GetCurrentHashAsHash128",
      "d": 393248,
      "h": 34360131616,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360131616),
//--TRIMMABLE-BOUNDARY-START(38655098912),
    {
      "r": 189726721,
      "n": "GetCurrentHashAsUInt128",
      "d": 393248,
      "h": 38655098912,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655098912),
//--TRIMMABLE-BOUNDARY-START(120259477536),
    {
      "r": 65537,
      "p": [
        {
          "n": "hash",
          "p": 458784,
          "f": 8
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "WriteBigEndian128",
      "d": 393248,
      "h": 120259477536,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120259477536),
//--TRIMMABLE-BOUNDARY-START(64424902688),
    {
      "r": 458784,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLength0To16",
      "d": 393248,
      "h": 64424902688,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424902688),
//--TRIMMABLE-BOUNDARY-START(77309804576),
    {
      "r": 458784,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLength1To3",
      "d": 393248,
      "h": 77309804576,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77309804576),
//--TRIMMABLE-BOUNDARY-START(81604771872),
    {
      "r": 458784,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLength4To8",
      "d": 393248,
      "h": 81604771872,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604771872),
//--TRIMMABLE-BOUNDARY-START(85899739168),
    {
      "r": 458784,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLength9To16",
      "d": 393248,
      "h": 85899739168,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85899739168),
//--TRIMMABLE-BOUNDARY-START(73014837280),
    {
      "r": 458784,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLength17To128",
      "d": 393248,
      "h": 73014837280,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73014837280),
//--TRIMMABLE-BOUNDARY-START(68719869984),
    {
      "r": 458784,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLength129To240",
      "d": 393248,
      "h": 68719869984,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68719869984),
//--TRIMMABLE-BOUNDARY-START(94489673760),
    {
      "r": 458784,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLengthOver240",
      "d": 393248,
      "h": 94489673760,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94489673760),
//--TRIMMABLE-BOUNDARY-START(25770197024),
    {
      "r": 458784,
      "p": [
        {
          "n": "accLow",
          "p": 983041
        },
        {
          "n": "accHigh",
          "p": 983041
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "AvalancheHash",
      "d": 393248,
      "h": 25770197024,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770197024),
//--TRIMMABLE-BOUNDARY-START(107374575648),
    {
      "r": 65537,
      "p": [
        {
          "n": "accLow",
          "p": 983041,
          "f": 4
        },
        {
          "n": "accHigh",
          "p": 983041,
          "f": 4
        },
        {
          "n": "input1",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "input2",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "secret1",
          "p": 983041
        },
        {
          "n": "secret2",
          "p": 983041
        },
        {
          "n": "secret3",
          "p": 983041
        },
        {
          "n": "secret4",
          "p": 983041
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "Mix32Bytes",
      "d": 393248,
      "h": 107374575648,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107374575648)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(90194706464),
    {
      "t": 655361,
      "n": "HashLengthInBytes",
      "o": "@$1",
      "d": 393248,
      "h": 90194706464,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(90194706464),
//--TRIMMABLE-BOUNDARY-START(4295360544),
    {
      "t": 917536,
      "n": "_state",
      "d": 393248,
      "h": 4295360544,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360544)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327840),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393248,
      "h": 8590327840,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327840),
//--TRIMMABLE-BOUNDARY-START(12885295136),
    {
      "p": [
        {
          "n": "seed",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393248,
      "h": 12885295136,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295136),
//--TRIMMABLE-BOUNDARY-START(17180262432),
    {
      "p": [
        {
          "n": "state",
          "p": 917536
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 393248,
      "h": 17180262432,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180262432)
  ],
  "h": 393248,
  "a": [
    {
      "t": 133693441,
      "c": 4428660737
    }
  ]
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sih.SIH.XxHash128.Hash128 ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.XxHash128`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}XxHash128`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393248)
        
        

        //--TRIMMABLE-BOUNDARY-START(524320)
        $asm.$cls(`$sih.SIH.XxHash3`, ($self) => class XxHash3 extends $.$sih.SIH.NonCryptographicHashAlgorithm
        {
            //--TRIMMABLE-BOUNDARY-START(81604902944)
            /*int*/ static HashLengthInBytes$1 = 8;
            //--TRIMMABLE-BOUNDARY-END(81604902944)
            
            //--TRIMMABLE-BOUNDARY-START(4295491616)
            /*State*/ _state;
            //--TRIMMABLE-BOUNDARY-END(4295491616)
            
            //--TRIMMABLE-BOUNDARY-START(8590458912)
            $ctor$2()
            {
                this.$ctor$3(0n);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458912);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458912)
            
            //--TRIMMABLE-BOUNDARY-START(12885426208)
            $ctor$3(/*long*/ seed)
            {
                super.$ctor$1(8/*HashLengthInBytes*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426208);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$sih.SIH.XxHashShared.Initialize($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sih.SIH.XxHashShared.State, () => this._state, ($v) => this._state = $v, null, true), $.$cast(seed, $.$$.S.UInt64));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426208)
            
            //--TRIMMABLE-BOUNDARY-START(17180393504)
            $ctor$4(/*State*/ state)
            {
                super.$ctor$1(8/*HashLengthInBytes*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180393504);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._state = $.$clone(state);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180393504)
            
            //--TRIMMABLE-BOUNDARY-START(25770328096)
            /*XxHash3 */ Clone()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328096);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sih.SIH.XxHash3().$ctor$4($.$clone(this._state));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770328096)
            
            //--TRIMMABLE-BOUNDARY-START(42950197280)
            static /*byte[] */ Hash$1(/*byte[]*/ source)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950197280);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sih.SIH.XxHash3.Hash(source, 0n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950197280)
            
            //--TRIMMABLE-BOUNDARY-START(38655229984)
            static /*byte[] */ Hash(/*byte[]*/ source, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655229984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$sih.SIH.XxHash3.Hash$2(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7(source), seed);
            }
            //--TRIMMABLE-BOUNDARY-END(38655229984)
            
            //--TRIMMABLE-BOUNDARY-START(47245164576)
            static /*byte[] */ Hash$2(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245164576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let result = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [8/*HashLengthInBytes*/], null);
                /*ulong*/ let hash = $.$sih.SIH.XxHash3.HashToUInt64(source, seed);
                $.$$.SBB.BinaryPrimitives.WriteUInt64BigEndian($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(result), hash);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(47245164576)
            
            //--TRIMMABLE-BOUNDARY-START(51540131872)
            static /*int */ Hash$3(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*long*/ seed)
            {
                /*int*/ let bytesWritten;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540131872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$sih.SIH.XxHash3.TryHash(source, destination, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.S.Int32), seed))
                {
                    $.$sih.SIH.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                return bytesWritten;
            }
            //--TRIMMABLE-BOUNDARY-END(51540131872)
            
            //--TRIMMABLE-BOUNDARY-START(98784772128)
            static /*bool */ TryHash(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesWritten, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784772128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length >= 8)
                {
                    /*ulong*/ let hash = $.$sih.SIH.XxHash3.HashToUInt64(source, seed);
                    if ($.$$.S.BitConverter.IsLittleEndian)
                    {
                        hash = $.$$.SBB.BinaryPrimitives.ReverseEndianness$21(hash);
                    }
                    $.$$.SRC.Unsafe.WriteUnaligned($.$$.S.UInt64, $.$$.SRI.MemoryMarshal.GetReference$1($.$$.S.Byte, destination), hash);
                    bytesWritten.$v = 8/*HashLengthInBytes*/;
                    return true;
                }
                bytesWritten.$v = 0;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(98784772128)
            
            //--TRIMMABLE-BOUNDARY-START(90194837536)
            static /*ulong */ HashToUInt64(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194837536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let length = (source.Length >>> 0);
                /*fixed*/ 
                {
                    /*byte**/ let sourcePtr = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Byte, source);
                    if (length <= 16)
                    {
                        return $.$sih.SIH.XxHash3.HashLength0To16(sourcePtr, length, $.$cast(seed, $.$$.S.UInt64));
                    }
                    if (length <= 128)
                    {
                        return $.$sih.SIH.XxHash3.HashLength17To128(sourcePtr, length, $.$cast(seed, $.$$.S.UInt64));
                    }
                    if (length <= 240/*MidSizeMaxBytes*/)
                    {
                        return $.$sih.SIH.XxHash3.HashLength129To240(sourcePtr, length, $.$cast(seed, $.$$.S.UInt64));
                    }
                    return $.$sih.SIH.XxHash3.HashLengthOver240(sourcePtr, length, $.$cast(seed, $.$$.S.UInt64));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194837536)
            
            //--TRIMMABLE-BOUNDARY-START(94489804832)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489804832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sih.SIH.XxHashShared.Reset($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sih.SIH.XxHashShared.State, () => this._state, ($v) => this._state = $v, null, true));
            }
            //--TRIMMABLE-BOUNDARY-END(94489804832)
            
            //--TRIMMABLE-BOUNDARY-START(21475360800)
            /*void */ Append$2(/*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sih.SIH.XxHashShared.Append($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sih.SIH.XxHashShared.State, () => this._state, ($v) => this._state = $v, null, true), source);
            }
            //--TRIMMABLE-BOUNDARY-END(21475360800)
            
            //--TRIMMABLE-BOUNDARY-START(34360262688)
            /*void */ GetCurrentHashCore(/*Span<byte>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ulong*/ let hash = this.GetCurrentHashAsUInt64();
                $.$$.SBB.BinaryPrimitives.WriteUInt64BigEndian(destination, hash);
            }
            //--TRIMMABLE-BOUNDARY-END(34360262688)
            
            //--TRIMMABLE-BOUNDARY-START(30065295392)
            /*ulong */ GetCurrentHashAsUInt64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065295392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ulong*/ let current;
                if (this._state.TotalLength > BigInt(240/*MidSizeMaxBytes*/))
                {
                    /*ulong**/ let accumulators = $.$$.SRC.RuntimeHelpers.StackAllocPointer($.$$.S.UInt64, 8/*AccumulatorCount*/, null);
                    $.$sih.SIH.XxHashShared.CopyAccumulators($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sih.SIH.XxHashShared.State, () => this._state, ($v) => this._state = $v, null, true), accumulators);
                    /*fixed*/ 
                    {
                        /*byte**/ let secret = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$$.S.Byte, this._state.Secret, null, false, true);
                        $.$sih.SIH.XxHashShared.DigestLong($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sih.SIH.XxHashShared.State, () => this._state, ($v) => this._state = $v, null, true), accumulators, secret);
                        current = $.$sih.SIH.XxHashShared.MergeAccumulators(accumulators, secret.Add(11/*SecretMergeAccsStartBytes*/), BigInt.asUintN(64, this._state.TotalLength * 11400714785074694791n));
                    }
                }
                else 
                {
                    /*fixed*/ 
                    {
                        /*byte**/ let buffer = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$$.S.Byte, this._state.Buffer, null, false, true);
                        current = $.$sih.SIH.XxHash3.HashToUInt64(new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$4(buffer, $.$cast(this._state.TotalLength, $.$$.S.Int32)), $.$cast(this._state.Seed, $.$$.S.Int64));
                    }
                }
                return current;
            }
            //--TRIMMABLE-BOUNDARY-END(30065295392)
            
            //--TRIMMABLE-BOUNDARY-START(55835099168)
            static /*ulong */ HashLength0To16(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835099168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (length > 8)
                {
                    return $.$sih.SIH.XxHash3.HashLength9To16(source, length, seed);
                }
                if (length >= 4)
                {
                    return $.$sih.SIH.XxHash3.HashLength4To8(source, length, seed);
                }
                if (length !== 0)
                {
                    return $.$sih.SIH.XxHash3.HashLength1To3(source, length, seed);
                }
                /*ulong*/ let SecretXor = 5487137525590930912n ^ 14627906620379768892n;
                return $.$sih.SIH.XxHash64.Avalanche(seed ^ SecretXor);
            }
            //--TRIMMABLE-BOUNDARY-END(55835099168)
            
            //--TRIMMABLE-BOUNDARY-START(68720001056)
            static /*ulong */ HashLength1To3(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720001056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(length >= 1 && length <= 3, "length >= 1 && length <= 3");
                /*byte*/ let c1 = source.$v;
                /*byte*/ let c2 = source.GetAt(length >>> 1);
                /*byte*/ let c3 = source.GetAt(((length - 1) >>> 0));
                /*uint*/ let combined = ((c1 << 16) >>> 0) | ((c2 << 24) >>> 0) | c3 | ((length << 8) >>> 0);
                /*uint*/ let SecretXor = $.$cast(13712233961653862072n, $.$$.S.UInt32) ^ $.$cast((13712233961653862072n >> 32n), $.$$.S.UInt32);
                return $.$sih.SIH.XxHash64.Avalanche(BigInt(combined) ^ (BigInt.asUintN(64, BigInt(SecretXor) + seed)));
            }
            //--TRIMMABLE-BOUNDARY-END(68720001056)
            
            //--TRIMMABLE-BOUNDARY-START(73014968352)
            static /*ulong */ HashLength4To8(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014968352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(length >= 4 && length <= 8, "length >= 4 && length <= 8");
                seed ^= BigInt.asUintN(64, $.$cast($.$$.SBB.BinaryPrimitives.ReverseEndianness$20($.$cast(seed, $.$$.S.UInt32)), $.$$.S.UInt64) << 32n);
                /*uint*/ let inputLow = $.$sih.SIH.XxHashShared.ReadUInt32LE(source);
                /*uint*/ let inputHigh = $.$sih.SIH.XxHashShared.ReadUInt32LE(source.Add(length).Add(-4));
                /*ulong*/ let SecretXor = 2066345149520216444n ^ 15823274712020931806n;
                /*ulong*/ let bitflip = BigInt.asUintN(64, SecretXor - seed);
                /*ulong*/ let input64 = BigInt.asUintN(64, BigInt(inputHigh) + (BigInt.asUintN(64, ($.$cast(inputLow, $.$$.S.UInt64)) << 32n)));
                return $.$sih.SIH.XxHashShared.Rrmxmx(input64 ^ bitflip, length);
            }
            //--TRIMMABLE-BOUNDARY-END(73014968352)
            
            //--TRIMMABLE-BOUNDARY-START(77309935648)
            static /*ulong */ HashLength9To16(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309935648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(length >= 9 && length <= 16, "length >= 9 && length <= 16");
                /*ulong*/ let SecretXorL = 2262974939099578482n ^ 8711581037947681227n;
                /*ulong*/ let SecretXorR = 2410270004345854594n ^ 10242386182634080440n;
                /*ulong*/ let bitflipLow = BigInt.asUintN(64, SecretXorL + seed);
                /*ulong*/ let bitflipHigh = BigInt.asUintN(64, SecretXorR - seed);
                /*ulong*/ let inputLow = $.$sih.SIH.XxHashShared.ReadUInt64LE(source) ^ bitflipLow;
                /*ulong*/ let inputHigh = $.$sih.SIH.XxHashShared.ReadUInt64LE(source.Add(length).Add(-8)) ^ bitflipHigh;
                return $.$sih.SIH.XxHashShared.Avalanche(BigInt.asUintN(64, BigInt.asUintN(64, BigInt.asUintN(64, BigInt(length) + $.$$.SBB.BinaryPrimitives.ReverseEndianness$21(inputLow)) + inputHigh) + $.$sih.SIH.XxHashShared.Multiply64To128ThenFold(inputLow, inputHigh)));
            }
            //--TRIMMABLE-BOUNDARY-END(77309935648)
            
            //--TRIMMABLE-BOUNDARY-START(64425033760)
            static /*ulong */ HashLength17To128(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(length >= 17 && length <= 128, "length >= 17 && length <= 128");
                /*ulong*/ let hash = BigInt.asUintN(64, BigInt(length) * 11400714785074694791n);
                let $switchJumpState8;
                $switchJumpStart8: while(true)
                {
                    let $switch8 = $switchJumpState8 ?? ($.trunc((((length - 1) >>> 0)) / 32));
                    switch($switch8)
                    {
                        default:
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add(48), 4554437623014685352n, 2111919702937427193n, seed);
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add(length).Add(-64), 3556072174620004746n, 7238261902898274248n, seed);
                        $switchJumpState8 = 2; /*goto case 2*/
                        continue $switchJumpStart8;
                        case 2:
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add(32), 14627906620379768892n, 11758427054878871688n, seed);
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add(length).Add(-48), 5690594596133299313n, 15613098826807580984n, seed);
                        $switchJumpState8 = 1; /*goto case 1*/
                        continue $switchJumpStart8;
                        case 1:
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add(16), 8711581037947681227n, 2410270004345854594n, seed);
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add(length).Add(-32), 10242386182634080440n, 5487137525590930912n, seed);
                        $switchJumpState8 = 0; /*goto case 0*/
                        continue $switchJumpStart8;
                        case 0:
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source, 13712233961653862072n, 2066345149520216444n, seed);
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add(length).Add(-16), 15823274712020931806n, 2262974939099578482n, seed);
                        break;
                    }
                    break;
                }
                return $.$sih.SIH.XxHashShared.Avalanche(hash);
            }
            //--TRIMMABLE-BOUNDARY-END(64425033760)
            
            //--TRIMMABLE-BOUNDARY-START(60130066464)
            static /*ulong */ HashLength129To240(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130066464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(length >= 129 && length <= 240, "length >= 129 && length <= 240");
                /*ulong*/ let hash = BigInt.asUintN(64, BigInt(length) * 11400714785074694791n);
                hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 0) | 0))), 13712233961653862072n, 2066345149520216444n, seed);
                hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 1) | 0))), 15823274712020931806n, 2262974939099578482n, seed);
                hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 2) | 0))), 8711581037947681227n, 2410270004345854594n, seed);
                hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 3) | 0))), 10242386182634080440n, 5487137525590930912n, seed);
                hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 4) | 0))), 14627906620379768892n, 11758427054878871688n, seed);
                hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 5) | 0))), 5690594596133299313n, 15613098826807580984n, seed);
                hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 6) | 0))), 4554437623014685352n, 2111919702937427193n, seed);
                hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 7) | 0))), 3556072174620004746n, 7238261902898274248n, seed);
                hash = $.$sih.SIH.XxHashShared.Avalanche(hash);
                let $switchJumpState9;
                $switchJumpStart9: while(true)
                {
                    let $switch9 = $switchJumpState9 ?? ($.trunc((length - (((16 * 8) | 0))) / 16));
                    switch($switch9)
                    {
                        default:
                        $.$$.SD.Debug.Assert$4(($.trunc((length - ((16 * 8) | 0)) / 16) >>> 0) == 7, "(length - 16 * 8) / 16 == 7");
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 14) | 0))), 13536968629829821247n, 16163852396094277575n, seed);
                        $switchJumpState9 = 6; /*goto case 6*/
                        continue $switchJumpStart9;
                        case 6:
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 13) | 0))), 17228863761319568023n, 8573350489219836230n, seed);
                        $switchJumpState9 = 5; /*goto case 5*/
                        continue $switchJumpStart9;
                        case 5:
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 12) | 0))), 7336514198459093435n, 5216419214072683403n, seed);
                        $switchJumpState9 = 4; /*goto case 4*/
                        continue $switchJumpStart9;
                        case 4:
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 11) | 0))), 10391458616325699444n, 5920048007935066598n, seed);
                        $switchJumpState9 = 3; /*goto case 3*/
                        continue $switchJumpStart9;
                        case 3:
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 10) | 0))), 15013455763555273806n, 5046485836271438973n, seed);
                        $switchJumpState9 = 2; /*goto case 2*/
                        continue $switchJumpStart9;
                        case 2:
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 9) | 0))), 11835586108195898345n, 16607528436649670564n, seed);
                        $switchJumpState9 = 1; /*goto case 1*/
                        continue $switchJumpStart9;
                        case 1:
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add((((16 * 8) | 0))), 9295848262624092985n, 7914194659941938988n, seed);
                        $switchJumpState9 = 0; /*goto case 0*/
                        continue $switchJumpStart9;
                        case 0:
                        hash += $.$sih.SIH.XxHashShared.Mix16Bytes(source.Add(length).Add(-16), 8320639771003045937n, 16992983559143025252n, seed);
                        break;
                    }
                    break;
                }
                return $.$sih.SIH.XxHashShared.Avalanche(hash);
            }
            //--TRIMMABLE-BOUNDARY-END(60130066464)
            
            //--TRIMMABLE-BOUNDARY-START(85899870240)
            static /*ulong */ HashLengthOver240(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899870240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(length > 240, "length > 240");
                /*fixed*/ 
                {
                    /*byte**/ let defaultSecret = $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Byte, $.$sih.SIH.XxHashShared.DefaultSecret);
                    /*byte**/ let secret = defaultSecret;
                    if (seed !== 0n)
                    {
                        /*byte**/ let customSecret = $.$$.SRC.RuntimeHelpers.StackAllocPointer($.$$.S.Byte, 192/*SecretLengthBytes*/, null);
                        $.$sih.SIH.XxHashShared.DeriveSecretFromSeed(customSecret, seed);
                        secret = customSecret;
                    }
                    /*ulong**/ let accumulators = $.$$.SRC.RuntimeHelpers.StackAllocPointer($.$$.S.UInt64, 8/*AccumulatorCount*/, null);
                    $.$sih.SIH.XxHashShared.InitializeAccumulators(accumulators);
                    $.$sih.SIH.XxHashShared.HashInternalLoop(accumulators, source, length, secret);
                    return $.$sih.SIH.XxHashShared.MergeAccumulators(accumulators, secret.Add(11), BigInt.asUintN(64, BigInt(length) * 11400714785074694791n));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899870240)
            
            //--TRIMMABLE-BOUNDARY-START(8590458912)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590458912)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295491616)
                this._state = $.$default($.$sih.SIH.XxHashShared.State);
                //--TRIMMABLE-BOUNDARY-END(4295491616)
                
            }
            static $h = 524320;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sih.SIH.NonCryptographicHashAlgorithm; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770328096),
    {
      "r": 524320,
      "n": "Clone",
      "d": 524320,
      "h": 25770328096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770328096),
//--TRIMMABLE-BOUNDARY-START(42950197280),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Hash",
      "o": "@$1",
      "d": 524320,
      "h": 42950197280,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950197280),
//--TRIMMABLE-BOUNDARY-START(38655229984),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 917505
        }
      ],
      "n": "Hash",
      "d": 524320,
      "h": 38655229984,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655229984),
//--TRIMMABLE-BOUNDARY-START(47245164576),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 917505,
          "f": 65,
          "v": 0
        }
      ],
      "n": "Hash",
      "o": "@$2",
      "d": 524320,
      "h": 47245164576,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245164576),
//--TRIMMABLE-BOUNDARY-START(51540131872),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 917505,
          "f": 65,
          "v": 0
        }
      ],
      "n": "Hash",
      "o": "@$3",
      "d": 524320,
      "h": 51540131872,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540131872),
//--TRIMMABLE-BOUNDARY-START(98784772128),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "bytesWritten",
          "p": 655361,
          "f": 2
        },
        {
          "n": "seed",
          "p": 917505,
          "f": 65,
          "v": 0
        }
      ],
      "n": "TryHash",
      "d": 524320,
      "h": 98784772128,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98784772128),
//--TRIMMABLE-BOUNDARY-START(90194837536),
    {
      "r": 983041,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "seed",
          "p": 917505,
          "f": 65,
          "v": 0
        }
      ],
      "n": "HashToUInt64",
      "d": 524320,
      "h": 90194837536,
      "f": 16777249,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194837536),
//--TRIMMABLE-BOUNDARY-START(94489804832),
    {
      "r": 65537,
      "n": "Reset",
      "d": 524320,
      "h": 94489804832,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489804832),
//--TRIMMABLE-BOUNDARY-START(21475360800),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": 524320,
      "h": 21475360800,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475360800),
//--TRIMMABLE-BOUNDARY-START(34360262688),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetCurrentHashCore",
      "d": 524320,
      "h": 34360262688,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34360262688),
//--TRIMMABLE-BOUNDARY-START(30065295392),
    {
      "r": 983041,
      "n": "GetCurrentHashAsUInt64",
      "d": 524320,
      "h": 30065295392,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065295392),
//--TRIMMABLE-BOUNDARY-START(55835099168),
    {
      "r": 983041,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLength0To16",
      "d": 524320,
      "h": 55835099168,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55835099168),
//--TRIMMABLE-BOUNDARY-START(68720001056),
    {
      "r": 983041,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLength1To3",
      "d": 524320,
      "h": 68720001056,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68720001056),
//--TRIMMABLE-BOUNDARY-START(73014968352),
    {
      "r": 983041,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLength4To8",
      "d": 524320,
      "h": 73014968352,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73014968352),
//--TRIMMABLE-BOUNDARY-START(77309935648),
    {
      "r": 983041,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLength9To16",
      "d": 524320,
      "h": 77309935648,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77309935648),
//--TRIMMABLE-BOUNDARY-START(64425033760),
    {
      "r": 983041,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLength17To128",
      "d": 524320,
      "h": 64425033760,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64425033760),
//--TRIMMABLE-BOUNDARY-START(60130066464),
    {
      "r": 983041,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLength129To240",
      "d": 524320,
      "h": 60130066464,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60130066464),
//--TRIMMABLE-BOUNDARY-START(85899870240),
    {
      "r": 983041,
      "p": [
        {
          "n": "source",
          "p": $.$typePointer($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 720897
        },
        {
          "n": "seed",
          "p": 983041
        }
      ],
      "n": "HashLengthOver240",
      "d": 524320,
      "h": 85899870240,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85899870240)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81604902944),
    {
      "t": 655361,
      "n": "HashLengthInBytes",
      "o": "@$1",
      "d": 524320,
      "h": 81604902944,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81604902944),
//--TRIMMABLE-BOUNDARY-START(4295491616),
    {
      "t": 917536,
      "n": "_state",
      "d": 524320,
      "h": 4295491616,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491616)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590458912),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524320,
      "h": 8590458912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458912),
//--TRIMMABLE-BOUNDARY-START(12885426208),
    {
      "p": [
        {
          "n": "seed",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524320,
      "h": 12885426208,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426208),
//--TRIMMABLE-BOUNDARY-START(17180393504),
    {
      "p": [
        {
          "n": "state",
          "p": 917536
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 524320,
      "h": 17180393504,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180393504)
  ],
  "h": 524320,
  "a": [
    {
      "t": 133693441,
      "c": 4428660737
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Hashing.XxHash3`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Hashing${separator}XxHash3`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524320)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory"));
})();
//--TRIMMABLE-BOUNDARY-END(32)
