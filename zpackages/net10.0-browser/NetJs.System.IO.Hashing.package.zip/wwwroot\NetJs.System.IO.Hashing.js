
(function ($global, $, $spc, $sm) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Hashing", 
    {"h":33111,"f":"System.IO.Hashing","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Hashing","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Hashing","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sih.System.IO.Hashing.NonCryptographicHashAlgorithm", ($self) => class NonCryptographicHashAlgorithm extends $.$spc.System.Object
        {
            /*int*/ HashLengthInBytes = 0;
            $ctor$1(/*int*/ hashLengthInBytes)
            {
                super.$ctor();
                {
                    if (hashLengthInBytes < 1)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("hashLengthInBytes");
                    }
                    this.HashLengthInBytes = hashLengthInBytes;
                }
                return this;
            }
            /*void */ Append$1(/*byte[]*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                this.Append(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2(source));
            }
            /*void */ Append$2(/*Stream*/ stream)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                stream.CopyTo(new $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm.CopyToDestinationStream().$ctor$3(this));
            }
            /*Task */ AppendAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(stream, "stream");
                return stream.CopyToAsync$2(new $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm.CopyToDestinationStream().$ctor$3(this), cancellationToken);
            }
            /*byte[] */ GetCurrentHash()
            {
                /*byte[]*/ let ret = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [this.HashLengthInBytes], null);
                this.GetCurrentHashCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(ret));
                return ret;
            }
            /*bool */ TryGetCurrentHash(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                if (destination.Length < this.HashLengthInBytes)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                this.GetCurrentHashCore(destination.Slice$1(0, this.HashLengthInBytes));
                bytesWritten.$v = this.HashLengthInBytes;
                return true;
            }
            /*int */ GetCurrentHash$1(/*Span<byte>*/ destination)
            {
                if (destination.Length < this.HashLengthInBytes)
                {
                    $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                this.GetCurrentHashCore(destination.Slice$1(0, this.HashLengthInBytes));
                return this.HashLengthInBytes;
            }
            /*byte[] */ GetHashAndReset()
            {
                /*byte[]*/ let ret = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [this.HashLengthInBytes], null);
                this.GetHashAndResetCore($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(ret));
                return ret;
            }
            /*bool */ TryGetHashAndReset(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                if (destination.Length < this.HashLengthInBytes)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                this.GetHashAndResetCore(destination.Slice$1(0, this.HashLengthInBytes));
                bytesWritten.$v = this.HashLengthInBytes;
                return true;
            }
            /*int */ GetHashAndReset$1(/*Span<byte>*/ destination)
            {
                if (destination.Length < this.HashLengthInBytes)
                {
                    $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                this.GetHashAndResetCore(destination.Slice$1(0, this.HashLengthInBytes));
                return this.HashLengthInBytes;
            }
            /*void */ GetHashAndResetCore(/*Span<byte>*/ destination)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(destination.Length === this.HashLengthInBytes, "destination.Length == HashLengthInBytes");
                this.GetCurrentHashCore(destination);
                this.Reset();
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sih.System.SR.NotSupported_GetHashCode);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm.GetHashCode.apply(this, arguments); }
            static /*void */ ThrowDestinationTooShort()
            {
                throw new $.$spc.System.ArgumentException().$ctor$13($.$sih.System.SR.Argument_DestinationTooShort, "destination");
            }
            static $_CopyToDestinationStream;
            static get CopyToDestinationStream()
            {
                let $cls = $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm;
                return $cls.$_CopyToDestinationStream ??= $asm.$ncls("$sih.System.IO.Hashing.NonCryptographicHashAlgorithm.CopyToDestinationStream", ($self) => class CopyToDestinationStream extends $.$spc.System.IO.Stream
                {
                    /*bool */ get CanWrite()
                    {
                        return true;
                    }
                    /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
                    {
                        return this.hash.Append($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, buffer, offset, count)));
                    }
                    /*void */ WriteByte(/*byte*/ value)
                    {
                        return this.hash.Append(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$5($.$ref(() => value, undefined, $.$spc.System.Byte)));
                    }
                    /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
                    {
                        this.hash.Append($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Byte, buffer, offset, count)));
                        return $.$spc.System.Threading.Tasks.Task.CompletedTask;
                    }
                    /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
                    {
                        return this.hash.Append(buffer);
                    }
                    /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
                    {
                        this.hash.Append(buffer.Span);
                        return new $.$spc.System.Threading.Tasks.ValueTask();
                    }
                    /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
                    {
                        return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.WriteAsync(buffer, offset, count), callback, state);
                    }
                    /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
                    {
                        return $.$spc.System.Threading.Tasks.TaskToAsyncResult.End(asyncResult);
                    }
                    /*void */ Flush()
                    {
                    }
                    /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
                    {
                        return $.$spc.System.Threading.Tasks.Task.CompletedTask;
                    }
                    /*bool */ get CanRead()
                    {
                        return false;
                    }
                    /*bool */ get CanSeek()
                    {
                        return false;
                    }
                    /*long */ get Length()
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*long */ get Position()
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*long */ set Position(value)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ SetLength(/*long*/ value)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$9();
                    }
                    //Begin primary constructor
                    /*NonCryptographicHashAlgorithm*/ hash = null;
                    $ctor$3(/*NonCryptographicHashAlgorithm*/$hash)
                    {
                        this.hash = $hash;
                        return this
                    }
                    //End primary constructor
                    static $h = 295255;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180164439,"f":32769},"n":"CanWrite","d":295255,"h":12885197143,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":64424804695,"f":32769},"n":"CanRead","d":295255,"h":60129837399,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":73014739287,"f":32769},"n":"CanSeek","d":295255,"h":68719771991,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":81604673879,"f":32769},"n":"Length","d":295255,"h":77309706583,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":90194608471,"f":32769},"s":{"r":0,"d":0,"h":94489575767,"f":32769},"n":"Position","d":295255,"h":85899641175,"f":32769}],"m":[{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":295255,"h":21475131735,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":295255,"h":25770099031,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":295255,"h":30065066327,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":295255,"h":34360033623,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":295255,"h":38655000919,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginWrite","d":295255,"h":42949968215,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":295255,"h":47244935511,"f":32769},{"r":65537,"n":"Flush","d":295255,"h":51539902807,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":295255,"h":55834870103,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":295255,"h":98784543063,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":295255,"h":103079510359,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":295255,"h":107374477655,"f":32769}],"l":[{"t":229719,"n":"\u003Chash\u003EP","d":295255,"h":8590229847,"f":2}],"c":[{"p":[{"n":"hash","p":229719}],"n":".ctor","o":"$ctor$3","d":295255,"h":4295262551,"f":1}],"i":[57540609,56950785],"d":229719,"h":295255}; }
                    static get $b() { return $.$spc.System.IO.Stream; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
                    static get $fullName() { return `System.IO.Hashing.NonCryptographicHashAlgorithm.CopyToDestinationStream`; }
                }, $cls, ($v) => $cls.$_CopyToDestinationStream = $v);
            }
            static $h = 229719;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885131607,"f":1},"n":"HashLengthInBytes","d":229719,"h":8590164311,"f":1}],"m":[{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Append","d":229719,"h":21475066199,"f":257},{"r":65537,"n":"Reset","d":229719,"h":25770033495,"f":257},{"r":65537,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetCurrentHashCore","d":229719,"h":30065000791,"f":260},{"r":65537,"p":[{"n":"source","p":0}],"n":"Append","o":"@$1","d":229719,"h":34359968087,"f":1},{"r":65537,"p":[{"n":"stream","p":62193665}],"n":"Append","o":"@$2","d":229719,"h":38654935383,"f":1},{"r":133300225,"p":[{"n":"stream","p":62193665},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AppendAsync","d":229719,"h":42949902679,"f":1},{"r":0,"n":"GetCurrentHash","d":229719,"h":47244869975,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryGetCurrentHash","d":229719,"h":51539837271,"f":1},{"r":655361,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetCurrentHash","o":"@$1","d":229719,"h":55834804567,"f":1},{"r":0,"n":"GetHashAndReset","d":229719,"h":60129771863,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryGetHashAndReset","d":229719,"h":64424739159,"f":1},{"r":655361,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetHashAndReset","o":"@$1","d":229719,"h":68719706455,"f":1},{"r":65537,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetHashAndResetCore","d":229719,"h":73014673751,"f":132},{"r":655361,"n":"GetHashCode","d":229719,"h":77309641047,"f":32769,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":70909953,"c":12955811841,"a":[{"v":"Use GetCurrentHash() to retrieve the computed hash code.","t":1310721},{"v":true,"t":262145}]}]},{"r":65537,"n":"ThrowDestinationTooShort","d":229719,"h":81604608343,"f":32}],"c":[{"p":[{"n":"hashLengthInBytes","p":655361}],"n":".ctor","o":"$ctor$1","d":229719,"h":17180098903,"f":4}],"j":[295255],"h":229719}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Hashing.NonCryptographicHashAlgorithm`; }
        });
        
        $asm.$cls("$sih.System.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowUnreachableException()
            {
                throw new $.$spc.System.Diagnostics.UnreachableException().$ctor$5();
            }
            static $h = 1081687;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"ThrowUnreachableException","d":1081687,"h":4296048983,"f":40}],"h":1081687}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.ThrowHelper`; }
        });
        
        $asm.$cls("$sih.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sih.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.IO.Hashing", $.$sih.System.SR.$type.Assembly);
                    $.$sih.System.SR.s_resourceManager = temp;
                }
                return $.$sih.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sih.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sih.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_DestinationTooShort()
            {
                return "Destination is too short.";
            }
            static /*string */ get NotSupported_GetHashCode()
            {
                return "The GetHashCode method is not supported on this object. Use GetCurrentHash or GetHashAndReset to retrieve the hash code computed by this object.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sih.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sih.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sih.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sih.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sih.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sih.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sih.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sih.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sih.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sih.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sih.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sih.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sih.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1016151;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1016151}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sih.System.IO.Hashing.VectorHelper", ($self) => class VectorHelper
        {
            static /*bool */ get IsSupported()
            {
                return /*$.$spc.System.Runtime.Intrinsics.X86.Pclmulqdq*/$.$spc.DeletedObject.IsSupported$3 || (/*$.$spc.System.Runtime.Intrinsics.Arm.Aes*/$.$spc.DeletedObject.IsSupported$1 && /*$.$spc.System.Runtime.Intrinsics.Arm.AdvSimd*/$.$spc.DeletedObject.IsSupported$1);
            }
            static /*Vector128<ulong> */ FoldPolynomialPair(/*Vector128<ulong>*/ target, /*Vector128<ulong>*/ source, /*Vector128<ulong>*/ constants)
            {
                target = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr(target, $.$sih.System.IO.Hashing.VectorHelper.CarrylessMultiplyUpper(source, constants));
                target = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr(target, $.$sih.System.IO.Hashing.VectorHelper.CarrylessMultiplyLower(source, constants));
                return target;
            }
            static /*Vector128<ulong> */ CarrylessMultiplyLower(/*Vector128<ulong>*/ left, /*Vector128<ulong>*/ right)
            {
                //if (Pclmulqdq.IsSupported) { ... }
                //if (Aes.IsSupported) { ... }
                $.$sih.System.ThrowHelper.ThrowUnreachableException();
                return new ($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64))();
            }
            static /*Vector128<ulong> */ CarrylessMultiplyUpper(/*Vector128<ulong>*/ left, /*Vector128<ulong>*/ right)
            {
                //if (Pclmulqdq.IsSupported) { ... }
                //if (Aes.IsSupported) { ... }
                $.$sih.System.ThrowHelper.ThrowUnreachableException();
                return new ($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64))();
            }
            static /*Vector128<ulong> */ CarrylessMultiplyLeftUpperRightLower(/*Vector128<ulong>*/ left, /*Vector128<ulong>*/ right)
            {
                //if (Pclmulqdq.IsSupported) { ... }
                //if (Aes.IsSupported) { ... }
                $.$sih.System.ThrowHelper.ThrowUnreachableException();
                return new ($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64))();
            }
            static /*Vector128<ulong> */ CarrylessMultiplyLeftLowerRightUpper(/*Vector128<ulong>*/ left, /*Vector128<ulong>*/ right)
            {
                //if (Pclmulqdq.IsSupported) { ... }
                //if (Aes.IsSupported) { ... }
                $.$sih.System.ThrowHelper.ThrowUnreachableException();
                return new ($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64))();
            }
            static /*Vector128<ulong> */ ShiftRightBytesInVector(/*Vector128<ulong>*/ operand, /*byte*/ numBytesToShift)
            {
                //if (Sse2.IsSupported) { ... }
                //if (AdvSimd.IsSupported) { ... }
                $.$sih.System.ThrowHelper.ThrowUnreachableException();
                return new ($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64))();
            }
            static /*Vector128<ulong> */ ShiftLowerToUpper(/*Vector128<ulong>*/ operand)
            {
                //if (Sse2.IsSupported) { ... }
                //if (AdvSimd.IsSupported) { ... }
                $.$sih.System.ThrowHelper.ThrowUnreachableException();
                return new ($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64))();
            }
            static $h = 360791;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590295383,"f":33},"n":"IsSupported","d":360791,"h":4295328087,"f":33}],"m":[{"r":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h,"p":[{"n":"target","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h},{"n":"source","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h},{"n":"constants","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h}],"n":"FoldPolynomialPair","d":360791,"h":12885262679,"f":33},{"r":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h,"p":[{"n":"left","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h},{"n":"right","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h}],"n":"CarrylessMultiplyLower","d":360791,"h":17180229975,"f":33},{"r":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h,"p":[{"n":"left","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h},{"n":"right","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h}],"n":"CarrylessMultiplyUpper","d":360791,"h":21475197271,"f":33},{"r":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h,"p":[{"n":"left","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h},{"n":"right","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h}],"n":"CarrylessMultiplyLeftUpperRightLower","d":360791,"h":25770164567,"f":33},{"r":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h,"p":[{"n":"left","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h},{"n":"right","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h}],"n":"CarrylessMultiplyLeftLowerRightUpper","d":360791,"h":30065131863,"f":33},{"r":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h,"p":[{"n":"operand","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h},{"n":"numBytesToShift","p":393217}],"n":"ShiftRightBytesInVector","d":360791,"h":34360099159,"f":33},{"r":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h,"p":[{"n":"operand","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h}],"n":"ShiftLowerToUpper","d":360791,"h":38655066455,"f":33}],"h":360791}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Hashing.VectorHelper`; }
        });
        
        $asm.$cls("$sih.System.IO.Hashing.XxHashShared", ($self) => class XxHashShared
        {
            /*int*/ static StripeLengthBytes = 64;
            /*int*/ static SecretLengthBytes = 192;
            /*int*/ static SecretSizeMin = 136;
            /*int*/ static SecretLastAccStartBytes = 7;
            /*int*/ static SecretConsumeRateBytes = 8;
            /*int*/ static SecretMergeAccsStartBytes = 11;
            /*int*/ static NumStripesPerBlock = 16;
            /*int*/ static AccumulatorCount = 8;
            /*int*/ static MidSizeMaxBytes = 240;
            /*int*/ static InternalBufferStripes = 4;
            /*int*/ static InternalBufferLengthBytes = 256;
            static /*ReadOnlySpan<byte> */ get DefaultSecret()
            {
                return this.$cacheDefaultSecret ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 184, 254, 108, 57, 35, 164, 75, 190, 124, 1, 129, 44, 247, 33, 173, 28, 222, 212, 109, 233, 131, 144, 151, 219, 114, 64, 164, 164, 183, 179, 103, 31, 203, 121, 230, 78, 204, 192, 229, 120, 130, 90, 208, 125, 204, 255, 114, 33, 184, 8, 70, 116, 247, 67, 36, 142, 224, 53, 144, 230, 129, 58, 38, 76, 60, 40, 82, 187, 145, 195, 0, 203, 136, 208, 101, 139, 27, 83, 46, 163, 113, 100, 72, 151, 162, 13, 249, 78, 56, 25, 239, 70, 169, 222, 172, 216, 168, 250, 118, 63, 227, 156, 52, 63, 249, 220, 187, 199, 199, 11, 79, 29, 138, 81, 224, 75, 205, 180, 89, 49, 200, 159, 126, 201, 217, 120, 115, 100, 234, 197, 172, 131, 52, 211, 235, 195, 197, 129, 160, 255, 250, 19, 99, 235, 23, 13, 221, 81, 183, 240, 218, 73, 211, 22, 85, 38, 41, 212, 104, 158, 43, 22, 190, 88, 125, 71, 161, 252, 143, 248, 184, 209, 122, 208, 49, 206, 69, 203, 58, 143, 149, 22, 4, 40, 175, 215, 251, 202, 187, 75, 64, 126 ]);
            }
            /*ulong*/ static DefaultSecretUInt64_0 = 0xBE4BA423396CFEB8n;
            /*ulong*/ static DefaultSecretUInt64_1 = 0x1CAD21F72C81017Cn;
            /*ulong*/ static DefaultSecretUInt64_2 = 0xDB979083E96DD4DEn;
            /*ulong*/ static DefaultSecretUInt64_3 = 0x1F67B3B7A4A44072n;
            /*ulong*/ static DefaultSecretUInt64_4 = 0x78E5C0CC4EE679CBn;
            /*ulong*/ static DefaultSecretUInt64_5 = 0x2172FFCC7DD05A82n;
            /*ulong*/ static DefaultSecretUInt64_6 = 0x8E2443F7744608B8n;
            /*ulong*/ static DefaultSecretUInt64_7 = 0x4C263A81E69035E0n;
            /*ulong*/ static DefaultSecretUInt64_8 = 0xCB00C391BB52283Cn;
            /*ulong*/ static DefaultSecretUInt64_9 = 0xA32E531B8B65D088n;
            /*ulong*/ static DefaultSecretUInt64_10 = 0x4EF90DA297486471n;
            /*ulong*/ static DefaultSecretUInt64_11 = 0xD8ACDEA946EF1938n;
            /*ulong*/ static DefaultSecretUInt64_12 = 0x3F349CE33F76FAA8n;
            /*ulong*/ static DefaultSecretUInt64_13 = 0x1D4F0BC7C7BBDCF9n;
            /*ulong*/ static DefaultSecretUInt64_14 = 0x3159B4CD4BE0518An;
            /*ulong*/ static DefaultSecretUInt64_15 = 0x647378D9C97E9FC8n;
            /*ulong*/ static DefaultSecret3UInt64_0 = 0x81017CBE4BA42339n;
            /*ulong*/ static DefaultSecret3UInt64_1 = 0x6DD4DE1CAD21F72Cn;
            /*ulong*/ static DefaultSecret3UInt64_2 = 0xA44072DB979083E9n;
            /*ulong*/ static DefaultSecret3UInt64_3 = 0xE679CB1F67B3B7A4n;
            /*ulong*/ static DefaultSecret3UInt64_4 = 0xD05A8278E5C0CC4En;
            /*ulong*/ static DefaultSecret3UInt64_5 = 0x4608B82172FFCC7Dn;
            /*ulong*/ static DefaultSecret3UInt64_6 = 0x9035E08E2443F774n;
            /*ulong*/ static DefaultSecret3UInt64_7 = 0x52283C4C263A81E6n;
            /*ulong*/ static DefaultSecret3UInt64_8 = 0x65D088CB00C391BBn;
            /*ulong*/ static DefaultSecret3UInt64_9 = 0x486471A32E531B8Bn;
            /*ulong*/ static DefaultSecret3UInt64_10 = 0xEF19384EF90DA297n;
            /*ulong*/ static DefaultSecret3UInt64_11 = 0x76FAA8D8ACDEA946n;
            /*ulong*/ static DefaultSecret3UInt64_12 = 0xBBDCF93F349CE33Fn;
            /*ulong*/ static DefaultSecret3UInt64_13 = 0xE0518A1D4F0BC7C7n;
            /*ulong*/ static Prime64_1 = 0x9E3779B185EBCA87n;
            /*ulong*/ static Prime64_2 = 0xC2B2AE3D27D4EB4Fn;
            /*ulong*/ static Prime64_3 = 0x165667B19E3779F9n;
            /*ulong*/ static Prime64_4 = 0x85EBCA77C2B2AE63n;
            /*ulong*/ static Prime64_5 = 0x27D4EB2F165667C5n;
            /*uint*/ static Prime32_1 = 2654435761;
            /*uint*/ static Prime32_2 = 2246822519;
            /*uint*/ static Prime32_3 = 3266489917;
            /*uint*/ static Prime32_4 = 668265263;
            /*uint*/ static Prime32_5 = 374761393;
            /*Static constructor*/ static $cctor()
            {
                /*byte**/ let secret = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.Byte, 192/*SecretLengthBytes*/, null);
                $.$sih.System.IO.Hashing.XxHashShared.DeriveSecretFromSeed(secret, 0n);
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.MemoryExtensions.SequenceEqual$1($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4(secret, 192/*SecretLengthBytes*/)), $.$sih.System.IO.Hashing.XxHashShared.DefaultSecret), "new Span<byte>(secret, SecretLengthBytes).SequenceEqual(DefaultSecret)");
                $.$spc.System.Diagnostics.Debug.Assert$1(256/*InternalBufferLengthBytes*/ % 64/*StripeLengthBytes*/ === 0, "InternalBufferLengthBytes % StripeLengthBytes == 0");
                /*ReadOnlySpan<ulong>*/ let defaultSecretUInt64 = $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Byte, $.$spc.System.UInt64, $.$sih.System.IO.Hashing.XxHashShared.DefaultSecret);
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(0).$v) === 13712233961653862072n, "ReadLE64(defaultSecretUInt64[0]) == DefaultSecretUInt64_0");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(1).$v) === 2066345149520216444n, "ReadLE64(defaultSecretUInt64[1]) == DefaultSecretUInt64_1");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(2).$v) === 15823274712020931806n, "ReadLE64(defaultSecretUInt64[2]) == DefaultSecretUInt64_2");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(3).$v) === 2262974939099578482n, "ReadLE64(defaultSecretUInt64[3]) == DefaultSecretUInt64_3");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(4).$v) === 8711581037947681227n, "ReadLE64(defaultSecretUInt64[4]) == DefaultSecretUInt64_4");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(5).$v) === 2410270004345854594n, "ReadLE64(defaultSecretUInt64[5]) == DefaultSecretUInt64_5");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(6).$v) === 10242386182634080440n, "ReadLE64(defaultSecretUInt64[6]) == DefaultSecretUInt64_6");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(7).$v) === 5487137525590930912n, "ReadLE64(defaultSecretUInt64[7]) == DefaultSecretUInt64_7");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(8).$v) === 14627906620379768892n, "ReadLE64(defaultSecretUInt64[8]) == DefaultSecretUInt64_8");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(9).$v) === 11758427054878871688n, "ReadLE64(defaultSecretUInt64[9]) == DefaultSecretUInt64_9");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(10).$v) === 5690594596133299313n, "ReadLE64(defaultSecretUInt64[10]) == DefaultSecretUInt64_10");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(11).$v) === 15613098826807580984n, "ReadLE64(defaultSecretUInt64[11]) == DefaultSecretUInt64_11");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(12).$v) === 4554437623014685352n, "ReadLE64(defaultSecretUInt64[12]) == DefaultSecretUInt64_12");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(13).$v) === 2111919702937427193n, "ReadLE64(defaultSecretUInt64[13]) == DefaultSecretUInt64_13");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(14).$v) === 3556072174620004746n, "ReadLE64(defaultSecretUInt64[14]) == DefaultSecretUInt64_14");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecretUInt64.get_Item(15).$v) === 7238261902898274248n, "ReadLE64(defaultSecretUInt64[15]) == DefaultSecretUInt64_15");
                /*ReadOnlySpan<ulong>*/ let defaultSecret3UInt64 = $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1($.$spc.System.Byte, $.$spc.System.UInt64, $.$sih.System.IO.Hashing.XxHashShared.DefaultSecret.Slice(3));
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(0).$v) === 9295848262624092985n, "ReadLE64(defaultSecret3UInt64[0]) == DefaultSecret3UInt64_0");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(1).$v) === 7914194659941938988n, "ReadLE64(defaultSecret3UInt64[1]) == DefaultSecret3UInt64_1");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(2).$v) === 11835586108195898345n, "ReadLE64(defaultSecret3UInt64[2]) == DefaultSecret3UInt64_2");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(3).$v) === 16607528436649670564n, "ReadLE64(defaultSecret3UInt64[3]) == DefaultSecret3UInt64_3");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(4).$v) === 15013455763555273806n, "ReadLE64(defaultSecret3UInt64[4]) == DefaultSecret3UInt64_4");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(5).$v) === 5046485836271438973n, "ReadLE64(defaultSecret3UInt64[5]) == DefaultSecret3UInt64_5");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(6).$v) === 10391458616325699444n, "ReadLE64(defaultSecret3UInt64[6]) == DefaultSecret3UInt64_6");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(7).$v) === 5920048007935066598n, "ReadLE64(defaultSecret3UInt64[7]) == DefaultSecret3UInt64_7");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(8).$v) === 7336514198459093435n, "ReadLE64(defaultSecret3UInt64[8]) == DefaultSecret3UInt64_8");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(9).$v) === 5216419214072683403n, "ReadLE64(defaultSecret3UInt64[9]) == DefaultSecret3UInt64_9");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(10).$v) === 17228863761319568023n, "ReadLE64(defaultSecret3UInt64[10]) == DefaultSecret3UInt64_10");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(11).$v) === 8573350489219836230n, "ReadLE64(defaultSecret3UInt64[11]) == DefaultSecret3UInt64_11");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(12).$v) === 13536968629829821247n, "ReadLE64(defaultSecret3UInt64[12]) == DefaultSecret3UInt64_12");
                $.$spc.System.Diagnostics.Debug.Assert$1(ReadLE64(defaultSecret3UInt64.get_Item(13).$v) === 16163852396094277575n, "ReadLE64(defaultSecret3UInt64[13]) == DefaultSecret3UInt64_13");
                /*static ulong*/  function ReadLE64(/*ulong*/ data)
                {
                    return $.$spc.System.BitConverter.IsLittleEndian ? data : $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$10(data);
                }
            }
            static /*void */ Initialize(/*ref State*/ state, /*ulong*/ seed)
            {
                state.$v.Seed = seed;
                /*fixed*/ 
                {
                    /*byte**/ let secret = state.$v.Secret;
                    if (seed === 0n)
                    {
                        $.$sih.System.IO.Hashing.XxHashShared.DefaultSecret.CopyTo(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4(secret, 192/*SecretLengthBytes*/));
                    }
                    else 
                    {
                        $.$sih.System.IO.Hashing.XxHashShared.DeriveSecretFromSeed(secret, seed);
                    }
                }
                $.$sih.System.IO.Hashing.XxHashShared.Reset(state);
            }
            static /*void */ Reset(/*ref State*/ state)
            {
                state.$v.BufferedCount = 0;
                state.$v.StripesProcessedInCurrentBlock = 0n;
                state.$v.TotalLength = 0n;
                /*fixed*/ 
                {
                    /*ulong**/ let accumulators = state.$v.Accumulators;
                    $.$sih.System.IO.Hashing.XxHashShared.InitializeAccumulators(accumulators);
                }
            }
            static /*ulong */ Rrmxmx(/*ulong*/ hash, /*uint*/ length)
            {
                hash ^= $.$spc.System.Numerics.BitOperations.RotateLeft$1(hash, 49) ^ $.$spc.System.Numerics.BitOperations.RotateLeft$1(hash, 24);
                hash *= 11507291218515648293n;
                hash ^= (hash >> 35n) + BigInt(length);
                hash *= 11507291218515648293n;
                return $.$sih.System.IO.Hashing.XxHashShared.XorShift(hash, 28);
            }
            static /*void */ HashInternalLoop(/*ulong**/ accumulators, /*byte**/ source, /*uint*/ length, /*byte**/ secret)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length > 240, "length > 240");
                /*int*/ let StripesPerBlock = $.trunc((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0)) / 8/*SecretConsumeRateBytes*/);
                /*int*/ let BlockLen = ((64/*StripeLengthBytes*/ * StripesPerBlock) | 0);
                /*int*/ let blocksNum = (($.trunc((((length - 1) >>> 0)) / BlockLen)) | 0);
                $.$sih.System.IO.Hashing.XxHashShared.Accumulate(accumulators, source, secret, StripesPerBlock, true, blocksNum);
                /*int*/ let offset = ((BlockLen * blocksNum) | 0);
                /*int*/ let stripesNumber = $.$cast(((BigInt(length - 1) - BigInt(offset)) / BigInt(64/*StripeLengthBytes*/)), $.$spc.System.Int32);
                $.$sih.System.IO.Hashing.XxHashShared.Accumulate(accumulators, source.Add(offset), secret, stripesNumber, false, 1);
                $.$sih.System.IO.Hashing.XxHashShared.Accumulate512(accumulators, source.Add(length).Add(-64/*StripeLengthBytes*/), secret.Add((((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0) - 7/*SecretLastAccStartBytes*/) | 0))));
            }
            static /*void */ ConsumeStripes(/*ulong**/ accumulators, /*ref ulong*/ stripesSoFar, /*ulong*/ stripesPerBlock, /*byte**/ source, /*ulong*/ stripes, /*byte**/ secret)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(stripes <= stripesPerBlock, "stripes <= stripesPerBlock");
                $.$spc.System.Diagnostics.Debug.Assert$1(stripesSoFar.$v < stripesPerBlock, "stripesSoFar < stripesPerBlock");
                /*ulong*/ let stripesToEndOfBlock = stripesPerBlock - stripesSoFar.$v;
                if (stripesToEndOfBlock <= stripes)
                {
                    /*ulong*/ let stripesAfterBlock = stripes - stripesToEndOfBlock;
                    $.$sih.System.IO.Hashing.XxHashShared.Accumulate(accumulators, source, secret.Add(((($.$cast(stripesSoFar.$v, $.$spc.System.Int32) * 8/*SecretConsumeRateBytes*/) | 0))), $.$cast(stripesToEndOfBlock, $.$spc.System.Int32), false, 1);
                    $.$sih.System.IO.Hashing.XxHashShared.ScrambleAccumulators(accumulators, secret.Add((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0))));
                    $.$sih.System.IO.Hashing.XxHashShared.Accumulate(accumulators, source.Add(((($.$cast(stripesToEndOfBlock, $.$spc.System.Int32) * 64/*StripeLengthBytes*/) | 0))), secret, $.$cast(stripesAfterBlock, $.$spc.System.Int32), false, 1);
                    stripesSoFar.$v = stripesAfterBlock;
                }
                else 
                {
                    $.$sih.System.IO.Hashing.XxHashShared.Accumulate(accumulators, source, secret.Add(((($.$cast(stripesSoFar.$v, $.$spc.System.Int32) * 8/*SecretConsumeRateBytes*/) | 0))), $.$cast(stripes, $.$spc.System.Int32), false, 1);
                    stripesSoFar.$v += stripes;
                }
            }
            static /*void */ Append(/*ref State*/ state, /*ReadOnlySpan<byte>*/ source)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(state.$v.BufferedCount <= 256/*InternalBufferLengthBytes*/, "state.BufferedCount <= InternalBufferLengthBytes");
                state.$v.TotalLength += BigInt((source.Length >>> 0));
                /*fixed*/ 
                {
                    /*byte**/ let buffer = state.$v.Buffer;
                    if (BigInt(source.Length) <= BigInt(256/*InternalBufferLengthBytes*/ - state.$v.BufferedCount))
                    {
                        source.CopyTo(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4(buffer.Add(state.$v.BufferedCount), source.Length));
                        state.$v.BufferedCount += (source.Length >>> 0);
                        return;
                    }
                    /*fixed*/ 
                    {
                        /*byte**/ let secret = state.$v.Secret;
                        /*fixed*/ 
                        {
                            /*ulong**/ let accumulators = state.$v.Accumulators;
                            /*fixed*/ 
                            {
                                /*byte**/ let sourcePtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, source);
                                /*int*/ let sourceIndex = 0;
                                if (state.$v.BufferedCount !== 0)
                                {
                                    /*int*/ let loadSize = ((256/*InternalBufferLengthBytes*/ - (state.$v.BufferedCount | 0)) | 0);
                                    source.Slice$1(0, loadSize).CopyTo(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4(buffer.Add(state.$v.BufferedCount), loadSize));
                                    sourceIndex = loadSize;
                                    $.$sih.System.IO.Hashing.XxHashShared.ConsumeStripes(accumulators, $.$ref(() => state.$v.StripesProcessedInCurrentBlock, ($v) => state.$v.StripesProcessedInCurrentBlock = $v, $.$spc.System.UInt64), BigInt(16/*NumStripesPerBlock*/), buffer, BigInt(4/*InternalBufferStripes*/), secret);
                                    state.$v.BufferedCount = 0;
                                }
                                $.$spc.System.Diagnostics.Debug.Assert$1(sourceIndex < source.Length, "sourceIndex < source.Length");
                                if (((source.Length - sourceIndex) | 0) > ((16/*NumStripesPerBlock*/ * 64/*StripeLengthBytes*/) | 0))
                                {
                                    /*ulong*/ let stripes = $.$cast((((((source.Length - sourceIndex) | 0) - 1) | 0)), $.$spc.System.UInt64) / BigInt(64/*StripeLengthBytes*/);
                                    $.$spc.System.Diagnostics.Debug.Assert$1(BigInt(16/*NumStripesPerBlock*/) >= state.$v.StripesProcessedInCurrentBlock, "NumStripesPerBlock >= state.StripesProcessedInCurrentBlock");
                                    /*ulong*/ let stripesToEnd = BigInt(16/*NumStripesPerBlock*/) - state.$v.StripesProcessedInCurrentBlock;
                                    $.$spc.System.Diagnostics.Debug.Assert$1(stripesToEnd <= stripes, "stripesToEnd <= stripes");
                                    $.$sih.System.IO.Hashing.XxHashShared.Accumulate(accumulators, sourcePtr.Add(sourceIndex), secret.Add(((($.$cast(state.$v.StripesProcessedInCurrentBlock, $.$spc.System.Int32) * 8/*SecretConsumeRateBytes*/) | 0))), $.$cast(stripesToEnd, $.$spc.System.Int32), false, 1);
                                    $.$sih.System.IO.Hashing.XxHashShared.ScrambleAccumulators(accumulators, secret.Add((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0))));
                                    state.$v.StripesProcessedInCurrentBlock = 0n;
                                    sourceIndex += (($.$cast(stripesToEnd, $.$spc.System.Int32) * 64/*StripeLengthBytes*/) | 0);
                                    stripes -= stripesToEnd;
                                    while(stripes >= BigInt(16/*NumStripesPerBlock*/))
                                    {
                                        $.$sih.System.IO.Hashing.XxHashShared.Accumulate(accumulators, sourcePtr.Add(sourceIndex), secret, 16/*NumStripesPerBlock*/, false, 1);
                                        $.$sih.System.IO.Hashing.XxHashShared.ScrambleAccumulators(accumulators, secret.Add((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0))));
                                        sourceIndex += ((16/*NumStripesPerBlock*/ * 64/*StripeLengthBytes*/) | 0);
                                        stripes -= BigInt(16/*NumStripesPerBlock*/);
                                    }
                                    $.$sih.System.IO.Hashing.XxHashShared.Accumulate(accumulators, sourcePtr.Add(sourceIndex), secret, $.$cast(stripes, $.$spc.System.Int32), false, 1);
                                    sourceIndex += (($.$cast(stripes, $.$spc.System.Int32) * 64/*StripeLengthBytes*/) | 0);
                                    $.$spc.System.Diagnostics.Debug.Assert$1(sourceIndex < source.Length, "sourceIndex < source.Length");
                                    state.$v.StripesProcessedInCurrentBlock = stripes;
                                    source.Slice$1(((sourceIndex - 64/*StripeLengthBytes*/) | 0), 64/*StripeLengthBytes*/).CopyTo(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4(buffer.Add(256/*InternalBufferLengthBytes*/).Add(-64/*StripeLengthBytes*/), 64/*StripeLengthBytes*/));
                                }
                                else if (((source.Length - sourceIndex) | 0) > 256/*InternalBufferLengthBytes*/)
                                {
                                    do
                                    {
                                        $.$sih.System.IO.Hashing.XxHashShared.ConsumeStripes(accumulators, $.$ref(() => state.$v.StripesProcessedInCurrentBlock, ($v) => state.$v.StripesProcessedInCurrentBlock = $v, $.$spc.System.UInt64), BigInt(16/*NumStripesPerBlock*/), sourcePtr.Add(sourceIndex), BigInt(4/*InternalBufferStripes*/), secret);
                                        sourceIndex += 256/*InternalBufferLengthBytes*/;
                                    }
                                    while(((source.Length - sourceIndex) | 0) > 256/*InternalBufferLengthBytes*/);
                                    source.Slice$1(((sourceIndex - 64/*StripeLengthBytes*/) | 0), 64/*StripeLengthBytes*/).CopyTo(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4(buffer.Add(256/*InternalBufferLengthBytes*/).Add(-64/*StripeLengthBytes*/), 64/*StripeLengthBytes*/));
                                }
                                /*Span<byte>*/ let remaining = new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4(buffer, ((source.Length - sourceIndex) | 0));
                                $.$spc.System.Diagnostics.Debug.Assert$1(sourceIndex < source.Length, "sourceIndex < source.Length");
                                $.$spc.System.Diagnostics.Debug.Assert$1(remaining.Length <= 256/*InternalBufferLengthBytes*/, "remaining.Length <= InternalBufferLengthBytes");
                                $.$spc.System.Diagnostics.Debug.Assert$1(state.$v.BufferedCount === 0, "state.BufferedCount == 0");
                                source.Slice(sourceIndex).CopyTo(remaining);
                                state.$v.BufferedCount = (remaining.Length >>> 0);
                            }
                        }
                    }
                }
            }
            static /*void */ CopyAccumulators(/*ref State*/ state, /*ulong**/ accumulators)
            {
                /*fixed*/ 
                {
                    /*ulong**/ let stateAccumulators = state.$v.Accumulators;
                    //if (Vector256.IsHardwareAccelerated) { ... }
                    /*else*/ //if (Vector128.IsHardwareAccelerated) { ... }
                    //else 
                    {
                        for(/*int*/ let i = 0; i < 8; i++)
                        {
                            accumulators.SetAt(stateAccumulators.GetAt(i), i);
                        }
                    }
                }
            }
            static /*void */ DigestLong(/*ref State*/ state, /*ulong**/ accumulators, /*byte**/ secret)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(state.$v.BufferedCount > 0, "state.BufferedCount > 0");
                /*fixed*/ 
                {
                    /*byte**/ let buffer = state.$v.Buffer;
                    /*byte**/ let accumulateData;
                    if (state.$v.BufferedCount >= 64/*StripeLengthBytes*/)
                    {
                        /*uint*/ let stripes = $.trunc((((state.$v.BufferedCount - 1) >>> 0)) / 64/*StripeLengthBytes*/);
                        /*ulong*/ let stripesSoFar = state.$v.StripesProcessedInCurrentBlock;
                        $.$sih.System.IO.Hashing.XxHashShared.ConsumeStripes(accumulators, $.$ref(() => stripesSoFar, ($v) => stripesSoFar = $v, $.$spc.System.UInt64), BigInt(16/*NumStripesPerBlock*/), buffer, BigInt(stripes), secret);
                        accumulateData = buffer.Add(state.$v.BufferedCount).Add(-64/*StripeLengthBytes*/);
                    }
                    else 
                    {
                        /*byte**/ let lastStripe = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.Byte, 64/*StripeLengthBytes*/, null);
                        /*int*/ let catchupSize = ((64/*StripeLengthBytes*/ - (state.$v.BufferedCount | 0)) | 0);
                        new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$4(buffer.Add(256/*InternalBufferLengthBytes*/).Add(-catchupSize), catchupSize).CopyTo(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4(lastStripe, 64/*StripeLengthBytes*/));
                        new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$4(buffer, (state.$v.BufferedCount | 0)).CopyTo(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4(lastStripe.Add(catchupSize), (state.$v.BufferedCount | 0)));
                        accumulateData = lastStripe;
                    }
                    $.$sih.System.IO.Hashing.XxHashShared.Accumulate512(accumulators, accumulateData, secret.Add((((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0) - 7/*SecretLastAccStartBytes*/) | 0))));
                }
            }
            static /*void */ InitializeAccumulators(/*ulong**/ accumulators)
            {
                //if (Vector256.IsHardwareAccelerated) { ... }
                /*else*/ //if (Vector128.IsHardwareAccelerated) { ... }
                //else 
                {
                    accumulators.SetAt(BigInt(3266489917/*Prime32_3*/), 0);
                    accumulators.SetAt(11400714785074694791n, 1);
                    accumulators.SetAt(14029467366897019727n, 2);
                    accumulators.SetAt(1609587929392839161n, 3);
                    accumulators.SetAt(9650029242287828579n, 4);
                    accumulators.SetAt(BigInt(2246822519/*Prime32_2*/), 5);
                    accumulators.SetAt(2870177450012600261n, 6);
                    accumulators.SetAt(BigInt(2654435761/*Prime32_1*/), 7);
                }
            }
            static /*ulong */ MergeAccumulators(/*ulong**/ accumulators, /*byte**/ secret, /*ulong*/ start)
            {
                /*ulong*/ let result64 = start;
                result64 += $.$sih.System.IO.Hashing.XxHashShared.Multiply64To128ThenFold(accumulators.GetAt(0) ^ $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(secret), accumulators.GetAt(1) ^ $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(secret.Add(8)));
                result64 += $.$sih.System.IO.Hashing.XxHashShared.Multiply64To128ThenFold(accumulators.GetAt(2) ^ $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(secret.Add(16)), accumulators.GetAt(3) ^ $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(secret.Add(24)));
                result64 += $.$sih.System.IO.Hashing.XxHashShared.Multiply64To128ThenFold(accumulators.GetAt(4) ^ $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(secret.Add(32)), accumulators.GetAt(5) ^ $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(secret.Add(40)));
                result64 += $.$sih.System.IO.Hashing.XxHashShared.Multiply64To128ThenFold(accumulators.GetAt(6) ^ $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(secret.Add(48)), accumulators.GetAt(7) ^ $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(secret.Add(56)));
                return $.$sih.System.IO.Hashing.XxHashShared.Avalanche(result64);
            }
            static /*ulong */ Mix16Bytes(/*byte**/ source, /*ulong*/ secretLow, /*ulong*/ secretHigh, /*ulong*/ seed)
            {
                return $.$sih.System.IO.Hashing.XxHashShared.Multiply64To128ThenFold($.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(source) ^ (secretLow + seed), $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(source.Add($.$spc.System.UInt64.$z)) ^ (secretHigh - seed));
            }
            static /*ulong */ Multiply32To64(/*uint*/ v1, /*uint*/ v2)
            {
                return $.$cast(v1, $.$spc.System.UInt64) * BigInt(v2);
            }
            static /*ulong */ Avalanche(/*ulong*/ hash)
            {
                hash = $.$sih.System.IO.Hashing.XxHashShared.XorShift(hash, 37);
                hash *= 1609587791953885689n;
                hash = $.$sih.System.IO.Hashing.XxHashShared.XorShift(hash, 32);
                return hash;
            }
            static /*ulong */ Multiply64To128(/*ulong*/ left, /*ulong*/ right, /*out ulong*/ lower)
            {
                return $.$spc.System.Math.BigMul$4(left, right, lower);
            }
            static /*ulong */ Multiply64To128ThenFold(/*ulong*/ left, /*ulong*/ right)
            {
                /*ulong*/ let lower;
                /*ulong*/ let upper = $.$sih.System.IO.Hashing.XxHashShared.Multiply64To128(left, right, $.$ref(() => lower, ($v) => lower = $v, $.$spc.System.UInt64));
                return lower ^ upper;
            }
            static /*void */ DeriveSecretFromSeed(/*byte**/ destinationSecret, /*ulong*/ seed)
            {
                /*fixed*/ 
                {
                    /*byte**/ let defaultSecret = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, $.$sih.System.IO.Hashing.XxHashShared.DefaultSecret);
                    //if (Vector256.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                    /*else*/ //if (Vector128.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                    //else 
                    {
                        for(/*int*/ let i = 0; i < 192/*SecretLengthBytes*/; i += (($.$spc.System.UInt64.$z * 2) | 0))
                        {
                            $.$sih.System.IO.Hashing.XxHashShared.WriteUInt64LE(destinationSecret.Add(i), $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(defaultSecret.Add(i)) + seed);
                            $.$sih.System.IO.Hashing.XxHashShared.WriteUInt64LE(destinationSecret.Add(i).Add(8), $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(defaultSecret.Add(i).Add(8)) - seed);
                        }
                    }
                }
            }
            static /*void */ Accumulate(/*ulong**/ accumulators, /*byte**/ source, /*byte**/ secret, /*int*/ stripesToProcess, /*bool*/ scramble, /*int*/ blockCount)
            {
                /*byte**/ let secretForAccumulate = secret;
                /*byte**/ let secretForScramble = secret.Add((((192/*SecretLengthBytes*/ - 64/*StripeLengthBytes*/) | 0)));
                //if (Vector256.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                /*else*/ //if (Vector128.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                //else 
                {
                    for(/*int*/ let j = 0; j < blockCount; j++)
                    {
                        for(/*int*/ let i = 0; i < stripesToProcess; i++)
                        {
                            $.$sih.System.IO.Hashing.XxHashShared.Accumulate512Inlined(accumulators, source, secret.Add((((i * 8/*SecretConsumeRateBytes*/) | 0))));
                            source = source.Add(64/*StripeLengthBytes*/);
                        }
                        if (scramble)
                        {
                            $.$sih.System.IO.Hashing.XxHashShared.ScrambleAccumulators(accumulators, secretForScramble);
                        }
                    }
                }
            }
            static /*void */ Accumulate512(/*ulong**/ accumulators, /*byte**/ source, /*byte**/ secret)
            {
                $.$sih.System.IO.Hashing.XxHashShared.Accumulate512Inlined(accumulators, source, secret);
            }
            static /*void */ Accumulate512Inlined(/*ulong**/ accumulators, /*byte**/ source, /*byte**/ secret)
            {
                //if (Vector256.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                /*else*/ //if (Vector128.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                //else 
                {
                    for(/*int*/ let i = 0; i < 8/*AccumulatorCount*/; i++)
                    {
                        /*ulong*/ let sourceVal = $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(source.Add((((8 * i) | 0))));
                        /*ulong*/ let sourceKey = sourceVal ^ $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(secret.Add((((i * 8) | 0))));
                        accumulators.SetAt(sourceVal, i ^ 1);
                        accumulators.SetAt($.$sih.System.IO.Hashing.XxHashShared.Multiply32To64($.$cast(sourceKey, $.$spc.System.UInt32), $.$cast((sourceKey >> 32n), $.$spc.System.UInt32)), i);
                    }
                }
            }
            static /*Vector256<ulong> */ Accumulate256(/*Vector256<ulong>*/ accVec, /*byte**/ source, /*Vector256<uint>*/ secret)
            {
                /*Vector256<uint>*/ let sourceVec = $.$spc.System.Runtime.Intrinsics.Vector256.Load($.$spc.System.UInt32, $.$cast(source, $.$typePointer($.$spc.System.UInt32)));
                /*Vector256<uint>*/ let sourceKey = $.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt32).op_ExclusiveOr(sourceVec, secret);
                /*Vector256<uint>*/ let sourceKeyLow = $.$spc.System.Runtime.Intrinsics.Vector256.Shuffle$5(sourceKey, $.$spc.System.Runtime.Intrinsics.Vector256.Create$24(1, 0, 3, 0, 5, 0, 7, 0));
                /*Vector256<uint>*/ let sourceSwap = $.$spc.System.Runtime.Intrinsics.Vector256.Shuffle$5(sourceVec, $.$spc.System.Runtime.Intrinsics.Vector256.Create$24(2, 3, 0, 1, 6, 7, 4, 5));
                /*Vector256<ulong>*/ let sum = $.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt64).op_Addition(accVec, $.$spc.System.Runtime.Intrinsics.Vector256.AsUInt64($.$spc.System.UInt32, sourceSwap));
                /*Vector256<ulong>*/ let product = /*Avx2.IsSupported ? Avx2.Multiply(sourceKey, sourceKeyLow) : */ $.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt64).op_Multiply($.$spc.System.Runtime.Intrinsics.Vector256.AsUInt64($.$spc.System.UInt32, ($.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt32).op_BitwiseAnd(sourceKey, $.$spc.System.Runtime.Intrinsics.Vector256.Create$24(~0, 0, ~0, 0, ~0, 0, ~0, 0)))), $.$spc.System.Runtime.Intrinsics.Vector256.AsUInt64($.$spc.System.UInt32, ($.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt32).op_BitwiseAnd(sourceKeyLow, $.$spc.System.Runtime.Intrinsics.Vector256.Create$24(~0, 0, ~0, 0, ~0, 0, ~0, 0)))));
                accVec = $.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt64).op_Addition(product, sum);
                return accVec;
            }
            static /*Vector128<ulong> */ Accumulate128(/*Vector128<ulong>*/ accVec, /*byte**/ source, /*Vector128<uint>*/ secret)
            {
                /*Vector128<uint>*/ let sourceVec = $.$spc.System.Runtime.Intrinsics.Vector128.Load($.$spc.System.UInt32, $.$cast(source, $.$typePointer($.$spc.System.UInt32)));
                /*Vector128<uint>*/ let sourceKey = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt32).op_ExclusiveOr(sourceVec, secret);
                /*Vector128<uint>*/ let sourceSwap = $.$spc.System.Runtime.Intrinsics.Vector128.Shuffle$5(sourceVec, $.$spc.System.Runtime.Intrinsics.Vector128.Create$24(2, 3, 0, 1));
                /*Vector128<ulong>*/ let sum = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_Addition(accVec, $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.UInt32, sourceSwap));
                /*Vector128<ulong>*/ let product = $.$sih.System.IO.Hashing.XxHashShared.MultiplyWideningLower(sourceKey);
                accVec = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_Addition(product, sum);
                return accVec;
            }
            static /*Vector128<ulong> */ MultiplyWideningLower(/*Vector128<uint>*/ source)
            {
                //if (AdvSimd.IsSupported) { ... }
                //else 
                {
                    /*Vector128<uint>*/ let sourceLow = $.$spc.System.Runtime.Intrinsics.Vector128.Shuffle$5(source, $.$spc.System.Runtime.Intrinsics.Vector128.Create$24(1, 0, 3, 0));
                    return /*Sse2.IsSupported ? Sse2.Multiply(source, sourceLow) : */ $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_Multiply($.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.UInt32, ($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt32).op_BitwiseAnd(source, $.$spc.System.Runtime.Intrinsics.Vector128.Create$24(~0, 0, ~0, 0)))), $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.UInt32, ($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt32).op_BitwiseAnd(sourceLow, $.$spc.System.Runtime.Intrinsics.Vector128.Create$24(~0, 0, ~0, 0)))));
                }
            }
            static /*void */ ScrambleAccumulators(/*ulong**/ accumulators, /*byte**/ secret)
            {
                //if (Vector256.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                /*else*/ //if (Vector128.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                //else 
                {
                    for(/*int*/ let i = 0; i < 8/*AccumulatorCount*/; i++)
                    {
                        /*ulong*/ let xorShift = $.$sih.System.IO.Hashing.XxHashShared.XorShift(accumulators.$v, 47);
                        /*ulong*/ let xorWithKey = xorShift ^ $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(secret);
                        accumulators.$v = xorWithKey * BigInt(2654435761/*Prime32_1*/);
                        accumulators = accumulators.Add(1);
                        secret = secret.Add($.$spc.System.UInt64.$z);
                    }
                }
            }
            static /*Vector256<ulong> */ ScrambleAccumulator256(/*Vector256<ulong>*/ accVec, /*Vector256<ulong>*/ secret)
            {
                /*Vector256<ulong>*/ let xorShift = $.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt64).op_ExclusiveOr(accVec, $.$spc.System.Runtime.Intrinsics.Vector256.ShiftRightLogical$10(accVec, 47));
                /*Vector256<ulong>*/ let xorWithKey = $.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt64).op_ExclusiveOr(xorShift, secret);
                accVec = $.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt64).op_Multiply(xorWithKey, $.$spc.System.Runtime.Intrinsics.Vector256.Create$12($.$cast(2654435761/*Prime32_1*/, $.$spc.System.UInt64)));
                return accVec;
            }
            static /*Vector128<ulong> */ ScrambleAccumulator128(/*Vector128<ulong>*/ accVec, /*Vector128<ulong>*/ secret)
            {
                /*Vector128<ulong>*/ let xorShift = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr(accVec, $.$spc.System.Runtime.Intrinsics.Vector128.ShiftRightLogical$10(accVec, 47));
                /*Vector128<ulong>*/ let xorWithKey = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr(xorShift, secret);
                accVec = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_Multiply(xorWithKey, $.$spc.System.Runtime.Intrinsics.Vector128.Create$12($.$cast(2654435761/*Prime32_1*/, $.$spc.System.UInt64)));
                return accVec;
            }
            static /*ulong */ XorShift(/*ulong*/ value, /*int*/ shift)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(shift >= 0 && shift < 64, "shift >= 0 && shift < 64");
                return value ^ (value >> BigInt(shift));
            }
            static /*uint */ ReadUInt32LE(/*byte**/ data)
            {
                return $.$spc.System.BitConverter.IsLittleEndian ? $.$spc.System.Runtime.CompilerServices.Unsafe.ReadUnaligned($.$spc.System.UInt32, data) : $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$9($.$spc.System.Runtime.CompilerServices.Unsafe.ReadUnaligned($.$spc.System.UInt32, data));
            }
            static /*ulong */ ReadUInt64LE(/*byte**/ data)
            {
                return $.$spc.System.BitConverter.IsLittleEndian ? $.$spc.System.Runtime.CompilerServices.Unsafe.ReadUnaligned($.$spc.System.UInt64, data) : $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$10($.$spc.System.Runtime.CompilerServices.Unsafe.ReadUnaligned($.$spc.System.UInt64, data));
            }
            static /*void */ WriteUInt64LE(/*byte**/ data, /*ulong*/ value)
            {
                if (!$.$spc.System.BitConverter.IsLittleEndian)
                {
                    value = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$10(value);
                }
                $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned($.$spc.System.UInt64, data, value);
            }
            static $_State;
            static get State()
            {
                let $cls = $.$sih.System.IO.Hashing.XxHashShared;
                return $cls.$_State ??= $asm.$nstr("$sih.System.IO.Hashing.XxHashShared.State", ($self) => class State extends $.$spc.System.ValueType
                {
                    /*ulong[8]*/  get Accumulators() { return this.$getField(0, 0x80000000|8); }
                    /*ulong[8]*/  set Accumulators(value) { this.$setField(0, 0x80000000|8, value); }
                    /*byte[192]*/  get Secret() { return this.$getField(8, 0x80000000|192); }
                    /*byte[192]*/  set Secret(value) { this.$setField(8, 0x80000000|192, value); }
                    /*byte[256]*/  get Buffer() { return this.$getField(200, 0x80000000|256); }
                    /*byte[256]*/  set Buffer(value) { this.$setField(200, 0x80000000|256, value); }
                    /*uint*/  get BufferedCount() { return this.$getField(456, 4); }
                    /*uint*/  set BufferedCount(value) { this.$setField(456, 4, value); }
                    /*ulong*/  get StripesProcessedInCurrentBlock() { return this.$getField(460, 8); }
                    /*ulong*/  set StripesProcessedInCurrentBlock(value) { this.$setField(460, 8, value); }
                    /*ulong*/  get TotalLength() { return this.$getField(468, 8); }
                    /*ulong*/  set TotalLength(value) { this.$setField(468, 8, value); }
                    /*ulong*/  get Seed() { return this.$getField(476, 8); }
                    /*ulong*/  set Seed(value) { this.$setField(476, 8, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        //InlineArray(8)
                        copy.Accumulators = [...this.Accumulators];
                        $.$spc.System.Array.CopyMetadata(copy.Accumulators, this.Accumulators)
                        //InlineArray(192)
                        copy.Secret = [...this.Secret];
                        $.$spc.System.Array.CopyMetadata(copy.Secret, this.Secret)
                        //InlineArray(256)
                        copy.Buffer = [...this.Buffer];
                        $.$spc.System.Array.CopyMetadata(copy.Buffer, this.Buffer)
                        copy.BufferedCount = this.BufferedCount;
                        copy.StripesProcessedInCurrentBlock = this.StripesProcessedInCurrentBlock;
                        copy.TotalLength = this.TotalLength;
                        copy.Seed = this.Seed;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //FixedSizeArray(ulong*, 8)
                        let $t1 = this.Accumulators;
                        $.$spc.System.Array.AddMetadata($t1, $.$spc.System.UInt64.$type, null, null);
                        for (let $i = 0; $i < 8; $i++)
                        {
                            $t1[$i] = 0n;
                        }
                        //FixedSizeArray(byte*, 192)
                        let $t2 = this.Secret;
                        $.$spc.System.Array.AddMetadata($t2, $.$spc.System.Byte.$type, null, null);
                        for (let $i = 0; $i < 192; $i++)
                        {
                            $t2[$i] = 0;
                        }
                        //FixedSizeArray(byte*, 256)
                        let $t3 = this.Buffer;
                        $.$spc.System.Array.AddMetadata($t3, $.$spc.System.Byte.$type, null, null);
                        for (let $i = 0; $i < 256; $i++)
                        {
                            $t3[$i] = 0;
                        }
                        this.BufferedCount = 0;
                        this.StripesProcessedInCurrentBlock = 0n;
                        this.TotalLength = 0n;
                        this.Seed = 0n;
                    }
                    static $h = 950615;
                    static $z = 484;
                    static $f = 0b100010000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":0,"n":"Accumulators","d":950615,"h":4295917911,"f":8},{"t":0,"n":"Secret","d":950615,"h":8590885207,"f":8},{"t":0,"n":"Buffer","d":950615,"h":12885852503,"f":8},{"t":720897,"n":"BufferedCount","d":950615,"h":17180819799,"f":8},{"t":983041,"n":"StripesProcessedInCurrentBlock","d":950615,"h":21475787095,"f":8},{"t":983041,"n":"TotalLength","d":950615,"h":25770754391,"f":8},{"t":983041,"n":"Seed","d":950615,"h":30065721687,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":950615,"h":34360688983,"f":1}],"d":885079,"h":950615,"a":[{"t":109903873,"c":4404871169,"a":[{"v":3,"t":105381889}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.IO.Hashing.XxHashShared.State`; }
                }, $cls, ($v) => $cls.$_State = $v);
            }
            static $h = 885079;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":55835459927,"f":33},"n":"DefaultSecret","d":885079,"h":51540492631,"f":33}],"m":[{"r":65537,"p":[{"n":"state","p":950615,"f":4},{"n":"seed","p":983041}],"n":"Initialize","d":885079,"h":236224086359,"f":33},{"r":65537,"p":[{"n":"state","p":950615,"f":4}],"n":"Reset","d":885079,"h":240519053655,"f":33},{"r":983041,"p":[{"n":"hash","p":983041},{"n":"length","p":720897}],"n":"Rrmxmx","d":885079,"h":244814020951,"f":33},{"r":65537,"p":[{"n":"accumulators","p":0},{"n":"source","p":0},{"n":"length","p":720897},{"n":"secret","p":0}],"n":"HashInternalLoop","d":885079,"h":249108988247,"f":33},{"r":65537,"p":[{"n":"accumulators","p":0},{"n":"stripesSoFar","p":983041,"f":4},{"n":"stripesPerBlock","p":983041},{"n":"source","p":0},{"n":"stripes","p":983041},{"n":"secret","p":0}],"n":"ConsumeStripes","d":885079,"h":253403955543,"f":33},{"r":65537,"p":[{"n":"state","p":950615,"f":4},{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Append","d":885079,"h":257698922839,"f":33},{"r":65537,"p":[{"n":"state","p":950615,"f":4},{"n":"accumulators","p":0}],"n":"CopyAccumulators","d":885079,"h":261993890135,"f":33},{"r":65537,"p":[{"n":"state","p":950615,"f":4},{"n":"accumulators","p":0},{"n":"secret","p":0}],"n":"DigestLong","d":885079,"h":266288857431,"f":33},{"r":65537,"p":[{"n":"accumulators","p":0}],"n":"InitializeAccumulators","d":885079,"h":270583824727,"f":33},{"r":983041,"p":[{"n":"accumulators","p":0},{"n":"secret","p":0},{"n":"start","p":983041}],"n":"MergeAccumulators","d":885079,"h":274878792023,"f":33},{"r":983041,"p":[{"n":"source","p":0},{"n":"secretLow","p":983041},{"n":"secretHigh","p":983041},{"n":"seed","p":983041}],"n":"Mix16Bytes","d":885079,"h":279173759319,"f":33},{"r":983041,"p":[{"n":"v1","p":720897},{"n":"v2","p":720897}],"n":"Multiply32To64","d":885079,"h":283468726615,"f":33},{"r":983041,"p":[{"n":"hash","p":983041}],"n":"Avalanche","d":885079,"h":287763693911,"f":33},{"r":983041,"p":[{"n":"left","p":983041},{"n":"right","p":983041},{"n":"lower","p":983041,"f":2}],"n":"Multiply64To128","d":885079,"h":292058661207,"f":33},{"r":983041,"p":[{"n":"left","p":983041},{"n":"right","p":983041}],"n":"Multiply64To128ThenFold","d":885079,"h":296353628503,"f":33},{"r":65537,"p":[{"n":"destinationSecret","p":0},{"n":"seed","p":983041}],"n":"DeriveSecretFromSeed","d":885079,"h":300648595799,"f":33},{"r":65537,"p":[{"n":"accumulators","p":0},{"n":"source","p":0},{"n":"secret","p":0},{"n":"stripesToProcess","p":655361},{"n":"scramble","p":262145,"f":65,"v":false},{"n":"blockCount","p":655361,"f":65,"v":1}],"n":"Accumulate","d":885079,"h":304943563095,"f":34},{"r":65537,"p":[{"n":"accumulators","p":0},{"n":"source","p":0},{"n":"secret","p":0}],"n":"Accumulate512","d":885079,"h":309238530391,"f":33},{"r":65537,"p":[{"n":"accumulators","p":0},{"n":"source","p":0},{"n":"secret","p":0}],"n":"Accumulate512Inlined","d":885079,"h":313533497687,"f":34},{"r":$.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt64).$h,"p":[{"n":"accVec","p":$.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt64).$h},{"n":"source","p":0},{"n":"secret","p":$.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt32).$h}],"n":"Accumulate256","d":885079,"h":317828464983,"f":34},{"r":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h,"p":[{"n":"accVec","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h},{"n":"source","p":0},{"n":"secret","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt32).$h}],"n":"Accumulate128","d":885079,"h":322123432279,"f":34},{"r":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h,"p":[{"n":"source","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt32).$h}],"n":"MultiplyWideningLower","d":885079,"h":326418399575,"f":34},{"r":65537,"p":[{"n":"accumulators","p":0},{"n":"secret","p":0}],"n":"ScrambleAccumulators","d":885079,"h":330713366871,"f":34},{"r":$.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt64).$h,"p":[{"n":"accVec","p":$.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt64).$h},{"n":"secret","p":$.$spc.System.Runtime.Intrinsics.Vector256$$($.$spc.System.UInt64).$h}],"n":"ScrambleAccumulator256","d":885079,"h":335008334167,"f":34},{"r":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h,"p":[{"n":"accVec","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h},{"n":"secret","p":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h}],"n":"ScrambleAccumulator128","d":885079,"h":339303301463,"f":34},{"r":983041,"p":[{"n":"value","p":983041},{"n":"shift","p":655361}],"n":"XorShift","d":885079,"h":343598268759,"f":33},{"r":720897,"p":[{"n":"data","p":0}],"n":"ReadUInt32LE","d":885079,"h":347893236055,"f":33},{"r":983041,"p":[{"n":"data","p":0}],"n":"ReadUInt64LE","d":885079,"h":352188203351,"f":33},{"r":65537,"p":[{"n":"data","p":0},{"n":"value","p":983041}],"n":"WriteUInt64LE","d":885079,"h":356483170647,"f":34}],"l":[{"t":655361,"n":"StripeLengthBytes","d":885079,"h":4295852375,"f":33},{"t":655361,"n":"SecretLengthBytes","d":885079,"h":8590819671,"f":33},{"t":655361,"n":"SecretSizeMin","d":885079,"h":12885786967,"f":33},{"t":655361,"n":"SecretLastAccStartBytes","d":885079,"h":17180754263,"f":33},{"t":655361,"n":"SecretConsumeRateBytes","d":885079,"h":21475721559,"f":33},{"t":655361,"n":"SecretMergeAccsStartBytes","d":885079,"h":25770688855,"f":33},{"t":655361,"n":"NumStripesPerBlock","d":885079,"h":30065656151,"f":33},{"t":655361,"n":"AccumulatorCount","d":885079,"h":34360623447,"f":33},{"t":655361,"n":"MidSizeMaxBytes","d":885079,"h":38655590743,"f":33},{"t":655361,"n":"InternalBufferStripes","d":885079,"h":42950558039,"f":33},{"t":655361,"n":"InternalBufferLengthBytes","d":885079,"h":47245525335,"f":33},{"t":983041,"n":"DefaultSecretUInt64_0","d":885079,"h":60130427223,"f":33},{"t":983041,"n":"DefaultSecretUInt64_1","d":885079,"h":64425394519,"f":33},{"t":983041,"n":"DefaultSecretUInt64_2","d":885079,"h":68720361815,"f":33},{"t":983041,"n":"DefaultSecretUInt64_3","d":885079,"h":73015329111,"f":33},{"t":983041,"n":"DefaultSecretUInt64_4","d":885079,"h":77310296407,"f":33},{"t":983041,"n":"DefaultSecretUInt64_5","d":885079,"h":81605263703,"f":33},{"t":983041,"n":"DefaultSecretUInt64_6","d":885079,"h":85900230999,"f":33},{"t":983041,"n":"DefaultSecretUInt64_7","d":885079,"h":90195198295,"f":33},{"t":983041,"n":"DefaultSecretUInt64_8","d":885079,"h":94490165591,"f":33},{"t":983041,"n":"DefaultSecretUInt64_9","d":885079,"h":98785132887,"f":33},{"t":983041,"n":"DefaultSecretUInt64_10","d":885079,"h":103080100183,"f":33},{"t":983041,"n":"DefaultSecretUInt64_11","d":885079,"h":107375067479,"f":33},{"t":983041,"n":"DefaultSecretUInt64_12","d":885079,"h":111670034775,"f":33},{"t":983041,"n":"DefaultSecretUInt64_13","d":885079,"h":115965002071,"f":33},{"t":983041,"n":"DefaultSecretUInt64_14","d":885079,"h":120259969367,"f":33},{"t":983041,"n":"DefaultSecretUInt64_15","d":885079,"h":124554936663,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_0","d":885079,"h":128849903959,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_1","d":885079,"h":133144871255,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_2","d":885079,"h":137439838551,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_3","d":885079,"h":141734805847,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_4","d":885079,"h":146029773143,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_5","d":885079,"h":150324740439,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_6","d":885079,"h":154619707735,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_7","d":885079,"h":158914675031,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_8","d":885079,"h":163209642327,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_9","d":885079,"h":167504609623,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_10","d":885079,"h":171799576919,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_11","d":885079,"h":176094544215,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_12","d":885079,"h":180389511511,"f":33},{"t":983041,"n":"DefaultSecret3UInt64_13","d":885079,"h":184684478807,"f":33},{"t":983041,"n":"Prime64_1","d":885079,"h":188979446103,"f":33},{"t":983041,"n":"Prime64_2","d":885079,"h":193274413399,"f":33},{"t":983041,"n":"Prime64_3","d":885079,"h":197569380695,"f":33},{"t":983041,"n":"Prime64_4","d":885079,"h":201864347991,"f":33},{"t":983041,"n":"Prime64_5","d":885079,"h":206159315287,"f":33},{"t":720897,"n":"Prime32_1","d":885079,"h":210454282583,"f":33},{"t":720897,"n":"Prime32_2","d":885079,"h":214749249879,"f":33},{"t":720897,"n":"Prime32_3","d":885079,"h":219044217175,"f":33},{"t":720897,"n":"Prime32_4","d":885079,"h":223339184471,"f":33},{"t":720897,"n":"Prime32_5","d":885079,"h":227634151767,"f":33}],"j":[950615],"h":885079,"a":[{"t":95485953,"c":4390453249}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Hashing.XxHashShared`; }
        });
        
        $asm.$cls("$sih.System.IO.Hashing.Crc64", ($self) => class Crc64 extends $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm
        {
            /*ulong*/ static InitialState = 0n;
            /*int*/ static Size = 8;
            /*ulong*/ _crc = 0n;
            $ctor$2()
            {
                super.$ctor$1(8/*Size*/);
                {
                }
                return this;
            }
            $ctor$3(/*ulong*/ crc)
            {
                super.$ctor$1(8/*Size*/);
                {
                    this._crc = crc;
                }
                return this;
            }
            /*Crc64 */ Clone()
            {
                return new $.$sih.System.IO.Hashing.Crc64().$ctor$3(this._crc);
            }
            /*void */ Append(/*ReadOnlySpan<byte>*/ source)
            {
                this._crc = $.$sih.System.IO.Hashing.Crc64.Update(this._crc, source);
            }
            /*void */ Reset()
            {
                this._crc = 0n;
            }
            /*void */ GetCurrentHashCore(/*Span<byte>*/ destination)
            {
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt64BigEndian(destination, this._crc);
            }
            /*void */ GetHashAndResetCore(/*Span<byte>*/ destination)
            {
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt64BigEndian(destination, this._crc);
                this._crc = 0n;
            }
            /*ulong */ GetCurrentHashAsUInt64()
            {
                return this._crc;
            }
            static /*byte[] */ Hash(/*byte[]*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$sih.System.IO.Hashing.Crc64.Hash$1(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2(source));
            }
            static /*byte[] */ Hash$1(/*ReadOnlySpan<byte>*/ source)
            {
                /*byte[]*/ let ret = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [8/*Size*/], null);
                /*ulong*/ let hash = $.$sih.System.IO.Hashing.Crc64.HashToUInt64(source);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt64BigEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(ret), hash);
                return ret;
            }
            static /*bool */ TryHash(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                if (destination.Length < 8/*Size*/)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                /*ulong*/ let hash = $.$sih.System.IO.Hashing.Crc64.HashToUInt64(source);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt64BigEndian(destination, hash);
                bytesWritten.$v = 8/*Size*/;
                return true;
            }
            static /*int */ Hash$2(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination)
            {
                if (destination.Length < 8/*Size*/)
                {
                    $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                /*ulong*/ let hash = $.$sih.System.IO.Hashing.Crc64.HashToUInt64(source);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt64BigEndian(destination, hash);
                return 8/*Size*/;
            }
            static /*ulong */ HashToUInt64(/*ReadOnlySpan<byte>*/ source)
            {
                return $.$sih.System.IO.Hashing.Crc64.Update(0n, source);
            }
            static /*ulong */ Update(/*ulong*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                if ($.$sih.System.IO.Hashing.Crc64.CanBeVectorized(source))
                {
                    return $.$sih.System.IO.Hashing.Crc64.UpdateVectorized(crc, source);
                }
                return $.$sih.System.IO.Hashing.Crc64.UpdateScalar(crc, source);
            }
            static /*ulong */ UpdateScalar(/*ulong*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                /*ReadOnlySpan<ulong>*/ let crcLookup = $.$sih.System.IO.Hashing.Crc64.CrcLookup;
                for(/*int*/ let i = 0; i < source.Length; i++)
                {
                    /*ulong*/ let idx = (crc >> 56n);
                    idx ^= BigInt(source.get_Item(i).$v);
                    crc = crcLookup.get_Item($.$cast(idx, $.$spc.System.Int32)).$v ^ (BigInt.asUintN(64, crc << 8n));
                }
                return crc;
            }
            static /*ReadOnlySpan<ulong> */ get CrcLookup()
            {
                return this.$cacheCrcLookup ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt64))().$ctor$2([ 0n, 4823603603198064275n, 9647207206396128550n, 14344283933443513269n, 5274672035359026399n, 847670339082705484n, 14759040976900489721n, 10241823793177474922n, 10549344070718052798n, 15030250704074698541n, 1695340678165410968n, 6158653484774949387n, 15804726273676621153n, 11071337880091427826n, 6824194888265062471n, 2036903512645398228n, 7367177604490692079n, 2651944067726553980n, 16419204125234161865n, 11613757334439845466n, 3390681356330821936n, 7926053118503640995n, 12317306969549898774n, 16726154088988619397n, 17607865585094646865n, 13162708473643690690n, 8194994013375312247n, 3695931686473304036n, 13648389776530124942n, 18417527692557321757n, 4073807025290796456n, 8825348881154370363n, 14734355208981384158n, 10271039580541631821n, 5303888135453107960n, 822984195088142443n, 9604374506261047041n, 14391664176758772114n, 47380625301539367n, 4780770595170139316n, 6781362712661643872n, 2084283301222999283n, 15852106237007281990n, 11028505464239851989n, 1670654249350217407n, 6187869865390245932n, 10578560694269006745n, 15005564104267687178n, 12269926345859042865n, 16768987096479742114n, 3433514057002836759n, 7878672873577829764n, 16389988026750624494n, 11638443477897467005n, 7391863372946608072n, 2622728278751721819n, 4044590402276644751n, 8850035479350698268n, 13673076206955870889n, 18388311311405091898n, 8147614050581592912n, 3738764100714335683n, 17650697762308740726n, 13115328684529279205n, 15709965168302367023n, 11021966344253216700n, 6909860770376862729n, 2095335087373712026n, 10607776270906215920n, 15115916238825782115n, 1645968390176284886n, 6063892853452478021n, 5216239979862816913n, 762004938812542466n, 14808413130408695223n, 10336584279807992612n, 94761250603078734n, 4872975272980325085n, 9561541190340278632n, 14285852213486374907n, 13562725425323287744n, 18359094313119879763n, 4168566602445998566n, 8874722219015798645n, 17657238303940757535n, 13257468400305012364n, 8136561383943382329n, 3610266854770152362n, 3341308498700434814n, 7831293060043656173n, 12375739730780491864n, 16811819059476047563n, 7452841817450123681n, 2710377314828461874n, 16324444680414493831n, 11564384134825822740n, 1621282580641819377n, 6093108618008534114n, 10636992411005044695n, 15091230119249932612n, 6867028114005673518n, 2142715359940571325n, 15757345747155659528n, 10979133309658045851n, 9518708972583580495n, 14333231979791697372n, 142141253402664553n, 4830142882085382394n, 14783726745893216144n, 10365800689136969987n, 5245456557503443638n, 737318311902463013n, 8089180804553289502n, 3653099890976004493n, 17700070958701396536n, 13210088128275084459n, 4139350461810230209n, 8899408340202190162n, 13587411233247080167n, 18329878549100632180n, 16295228101163185824n, 11589070762272702515n, 7477528201428671366n, 2681160907110034709n, 12328359726370364031n, 16854651450907929836n, 3384140715920324441n, 7783913295349006794n, 17796789492404876493n, 12973186262895182430n, 8294265019745835499n, 3597188614796881784n, 13819721540753725458n, 18246723593521770113n, 4190670174747424052n, 8707887697765516199n, 7249714899603402099n, 2768808468102880224n, 16248400991498780757n, 11785088403942012614n, 3291936780352569772n, 8025325358597240639n, 12127785706904956042n, 16915077318774037017n, 10432479959725633826n, 15147713122803500977n, 1524009877625084932n, 6329456346323069591n, 15705454305770282493n, 11170082187107838830n, 6635271944638132443n, 2226424485906433608n, 189522501206157468n, 4634679410803088911n, 9745950545960650170n, 14245012653811987241n, 5445476407655580739n, 676338306971005648n, 14876502445374089573n, 10124960353263198198n, 4215391513593610003n, 8678706776937023872n, 13790540925671641653n, 18271444552530207910n, 8337133204891997132n, 3549843186494580063n, 17749444438031597290n, 13016054137459951737n, 12170653315997410989n, 16867732534171963454n, 3244592164593781643n, 8068192726900473112n, 16273122767886764658n, 11755906975779290337n, 7220533709540304724n, 2793530071884239303n, 6682616997400869628n, 2183556611878603887n, 15662586120087312346n, 11217427617020813641n, 1553190491096487459n, 6304735387851432112n, 10407758620342516485n, 15176894045242543510n, 14905683634900247362n, 10100238751092381137n, 5420754629656923748n, 705519735670536439n, 9793295161182637981n, 14202145287119436046n, 146654890503152315n, 4682024195942093864n, 3242565161283638754n, 7930564333232481137n, 12186217236017068228n, 17000743249723264599n, 7335380351123765565n, 2827240748300537774n, 16153640314560107547n, 11735716164790313608n, 13734056228011347036n, 18188291445129067215n, 4285430719881142650n, 8757259798139230185n, 17846161249714921603n, 13067947420601767440n, 8235833358291897765n, 3511522545606540086n, 5387043107155988493n, 590673871457609374n, 14925875833148783915n, 10219719885873843128n, 284282506805329106n, 4684052045342640705n, 9660285764170764788n, 14186579979835500391n, 15610694155489642931n, 11120709418076880672n, 6720936860919424149n, 2284857304564388358n, 10490913115006887276n, 15233377424362361855n, 1474636623804926026n, 6234696958930763481n, 16178361609106579004n, 11706535215248140463n, 7306199781952008986n, 2851961734412043657n, 12229085463316509411n, 16953397843693241456n, 3195220067441434565n, 7973432182840617302n, 8278700923620460418n, 3464177731752866065n, 17798816680404380324n, 13110814815472245815n, 4310152537884486493n, 8728078392784608718n, 13704874997943502459n, 18213013024491712744n, 9707630858549910483n, 14143712128616820032n, 241414281116563189n, 4731397450835853414n, 14955056402857342732n, 10194998898151653791n, 5362321814220069418n, 619854820462849209n, 1503817855483314797n, 6209975379031176446n, 10466191297540353867n, 15262558828106308056n, 6768281431840648882n, 2241989909157107745n, 15567826590698013588n, 11168054230320002311n ]);
            }
            static /*Vector128<ulong> */ LoadFromSource(/*ref byte*/ source, /*nuint*/ elementOffset)
            {
                /*Vector128<byte>*/ let vector = $.$spc.System.Runtime.Intrinsics.Vector128.LoadUnsafe$1($.$spc.System.Byte, source, elementOffset);
                if ($.$spc.System.BitConverter.IsLittleEndian)
                {
                    vector = $.$spc.System.Runtime.Intrinsics.Vector128.Shuffle(vector, $.$spc.System.Runtime.Intrinsics.Vector128.Create$16(15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0));
                }
                return $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.Byte, vector);
            }
            static /*bool */ CanBeVectorized(/*ReadOnlySpan<byte>*/ source)
            {
                return $.$sih.System.IO.Hashing.VectorHelper.IsSupported && source.Length >= $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count;
            }
            static /*ulong */ UpdateVectorized(/*ulong*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$sih.System.IO.Hashing.Crc64.CanBeVectorized(source), "source cannot be vectorized.");
                /*ref byte*/ let srcRef = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, source);
                /*int*/ let length = source.Length;
                /*Vector128<ulong>*/ let x7;
                /*Vector128<ulong>*/ let kConstants;
                if (length >= (($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count * 16) | 0))
                {
                    /*Vector128<ulong>*/ let x0 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 0);
                    /*Vector128<ulong>*/ let x1 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 16);
                    /*Vector128<ulong>*/ let x2 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 32);
                    /*Vector128<ulong>*/ let x3 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 48);
                    /*Vector128<ulong>*/ let x4 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 64);
                    /*Vector128<ulong>*/ let x5 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 80);
                    /*Vector128<ulong>*/ let x6 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 96);
                    x7 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 112);
                    srcRef = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, srcRef, (($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count * 8) | 0));
                    length -= (($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count * 8) | 0);
                    x0 = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr(x0, $.$sih.System.IO.Hashing.VectorHelper.ShiftLowerToUpper($.$spc.System.Runtime.Intrinsics.Vector128.CreateScalar$12(crc)));
                    kConstants = $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0x5CF79DEA9AC37D6n, 0x1067E571D7D5C2n);
                    do
                    {
                        /*Vector128<ulong>*/ let y1 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 0);
                        /*Vector128<ulong>*/ let y2 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 16);
                        x0 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(y1, x0, kConstants);
                        x1 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(y2, x1, kConstants);
                        y1 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 32);
                        y2 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 48);
                        x2 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(y1, x2, kConstants);
                        x3 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(y2, x3, kConstants);
                        y1 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 64);
                        y2 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 80);
                        x4 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(y1, x4, kConstants);
                        x5 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(y2, x5, kConstants);
                        y1 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 96);
                        y2 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 112);
                        x6 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(y1, x6, kConstants);
                        x7 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(y2, x7, kConstants);
                        srcRef = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, srcRef, (($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count * 8) | 0));
                        length -= (($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count * 8) | 0);
                    }
                    while(length >= (($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count * 8) | 0));
                    x7 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(x7, x0, $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0xE464F4DF5FB60AC1n, 0xB649C5B35A759CF2n));
                    x7 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(x7, x1, $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0x9AF04E1EFF82D0DDn, 0x6E82E609297F8FE8n));
                    x7 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(x7, x2, $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0x97C516E98BD2E73n, 0xB76477B31E22E7Bn));
                    x7 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(x7, x3, $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0x5F6843CA540DF020n, 0xDDF4B6981205B83Fn));
                    x7 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(x7, x4, $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0x54819D8713758B2Cn, 0x4A6B90073EB0AF5An));
                    x7 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(x7, x5, $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0x571BEE0A227EF92Bn, 0x44BEF2A201B5200Cn));
                    x7 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(x7, x6, $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0x5F5C3C7EB52FAB6n, 0x4EB938A7D257740En));
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(length >= 16, "length >= 16");
                    x7 = $.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 0);
                    x7 = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr(x7, $.$sih.System.IO.Hashing.VectorHelper.ShiftLowerToUpper($.$spc.System.Runtime.Intrinsics.Vector128.CreateScalar$12(crc)));
                    srcRef = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, srcRef, $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count);
                    length -= $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count;
                }
                while(length >= $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count)
                {
                    x7 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair($.$sih.System.IO.Hashing.Crc64.LoadFromSource(srcRef, 0), x7, $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0x5F5C3C7EB52FAB6n, 0x4EB938A7D257740En));
                    srcRef = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, srcRef, $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count);
                    length -= $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count;
                }
                x7 = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr($.$sih.System.IO.Hashing.VectorHelper.CarrylessMultiplyLeftUpperRightLower(x7, $.$spc.System.Runtime.Intrinsics.Vector128.CreateScalar$12(0x5F5C3C7EB52FAB6n)), $.$sih.System.IO.Hashing.VectorHelper.ShiftLowerToUpper(x7));
                kConstants = $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0x578D29D06CC4F872n, 0x42F0E1EBA9EA3693n);
                /*Vector128<ulong>*/ let temp = x7;
                x7 = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr($.$sih.System.IO.Hashing.VectorHelper.CarrylessMultiplyLeftUpperRightLower(x7, kConstants), ($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_BitwiseAnd(x7, $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0n, (~0n & 0xFFFFFFFFFFFFFFFFn)))));
                x7 = $.$sih.System.IO.Hashing.VectorHelper.CarrylessMultiplyUpper(x7, kConstants);
                x7 = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr(x7, temp);
                /*ulong*/ let result = $.$spc.System.Runtime.Intrinsics.Vector128.GetElement($.$spc.System.UInt64, x7, 0);
                return length > 0 ? $.$sih.System.IO.Hashing.Crc64.UpdateScalar(result, $.$spc.System.Runtime.InteropServices.MemoryMarshal.CreateReadOnlySpan($.$spc.System.Byte, srcRef, length)) : result;
            }
            static $h = 164183;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":229719,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt64).$h,"g":{"r":0,"d":0,"h":85899510103,"f":34},"n":"CrcLookup","d":164183,"h":81604542807,"f":34}],"m":[{"r":164183,"n":"Clone","d":164183,"h":25769967959,"f":1},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Append","d":164183,"h":30064935255,"f":32769},{"r":65537,"n":"Reset","d":164183,"h":34359902551,"f":32769},{"r":65537,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetCurrentHashCore","d":164183,"h":38654869847,"f":32772},{"r":65537,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetHashAndResetCore","d":164183,"h":42949837143,"f":32772},{"r":983041,"n":"GetCurrentHashAsUInt64","d":164183,"h":47244804439,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":0,"p":[{"n":"source","p":0}],"n":"Hash","d":164183,"h":51539771735,"f":33},{"r":0,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Hash","o":"@$1","d":164183,"h":55834739031,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryHash","d":164183,"h":60129706327,"f":33},{"r":655361,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Hash","o":"@$2","d":164183,"h":64424673623,"f":33},{"r":983041,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"HashToUInt64","d":164183,"h":68719640919,"f":33,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":983041,"p":[{"n":"crc","p":983041},{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Update","d":164183,"h":73014608215,"f":34},{"r":983041,"p":[{"n":"crc","p":983041},{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"UpdateScalar","d":164183,"h":77309575511,"f":34},{"r":$.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).$h,"p":[{"n":"source","p":393217,"f":4},{"n":"elementOffset","p":851969}],"n":"LoadFromSource","d":164183,"h":90194477399,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"CanBeVectorized","d":164183,"h":94489444695,"f":34},{"r":983041,"p":[{"n":"crc","p":983041},{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"UpdateVectorized","d":164183,"h":98784411991,"f":34}],"l":[{"t":983041,"n":"InitialState","d":164183,"h":4295131479,"f":34},{"t":655361,"n":"Size","d":164183,"h":8590098775,"f":34},{"t":983041,"n":"_crc","d":164183,"h":12885066071,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":164183,"h":17180033367,"f":1},{"p":[{"n":"crc","p":983041}],"n":".ctor","o":"$ctor$3","d":164183,"h":21475000663,"f":2}],"h":164183}; }
            static get $b() { return $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm; }
            static get $fullName() { return `System.IO.Hashing.Crc64`; }
        });
        
        $asm.$cls("$sih.System.IO.Hashing.XxHash32", ($self) => class XxHash32 extends $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm
        {
            static $_State;
            static get State()
            {
                let $cls = $.$sih.System.IO.Hashing.XxHash32;
                return $cls.$_State ??= $asm.$nstr("$sih.System.IO.Hashing.XxHash32.State", ($self) => class State extends $.$spc.System.ValueType
                {
                    /*uint*/  get _acc1() { return this.$getField(0, 4); }
                    /*uint*/  set _acc1(value) { this.$setField(0, 4, value); }
                    /*uint*/  get _acc2() { return this.$getField(4, 4); }
                    /*uint*/  set _acc2(value) { this.$setField(4, 4, value); }
                    /*uint*/  get _acc3() { return this.$getField(8, 4); }
                    /*uint*/  set _acc3(value) { this.$setField(8, 4, value); }
                    /*uint*/  get _acc4() { return this.$getField(12, 4); }
                    /*uint*/  set _acc4(value) { this.$setField(12, 4, value); }
                    /*uint*/  get _smallAcc() { return this.$getField(16, 4); }
                    /*uint*/  set _smallAcc(value) { this.$setField(16, 4, value); }
                    /*bool*/  get _hadFullStripe() { return this.$getField(20, 1); }
                    /*bool*/  set _hadFullStripe(value) { this.$setField(20, 1, value); }
                    $ctor$2(/*uint*/ seed)
                    {
                        super.$ctor$1();
                        {
                            this._acc1 = ((seed + ((2654435761/*Prime32_1*/ + 2246822519/*Prime32_2*/) >>> 0)) >>> 0);
                            this._acc2 = ((seed + 2246822519/*Prime32_2*/) >>> 0);
                            this._acc3 = seed;
                            this._acc4 = ((seed - 2654435761/*Prime32_1*/) >>> 0);
                            this._smallAcc = ((seed + 374761393/*Prime32_5*/) >>> 0);
                            this._hadFullStripe = false;
                        }
                        return this;
                    }
                    /*void */ ProcessStripe(/*ReadOnlySpan<byte>*/ source)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(source.Length >= 16/*StripeSize*/, "source.Length >= StripeSize");
                        source = source.Slice$1(0, 16/*StripeSize*/);
                        this._acc1 = $.$sih.System.IO.Hashing.XxHash32.State.ApplyRound(this._acc1, source);
                        this._acc2 = $.$sih.System.IO.Hashing.XxHash32.State.ApplyRound(this._acc2, source.Slice($.$spc.System.UInt32.$z));
                        this._acc3 = $.$sih.System.IO.Hashing.XxHash32.State.ApplyRound(this._acc3, source.Slice(((2 * $.$spc.System.UInt32.$z) | 0)));
                        this._acc4 = $.$sih.System.IO.Hashing.XxHash32.State.ApplyRound(this._acc4, source.Slice(((3 * $.$spc.System.UInt32.$z) | 0)));
                        this._hadFullStripe = true;
                    }
                    /*uint */ Converge()
                    {
                        return (((((($.$spc.System.Numerics.BitOperations.RotateLeft(this._acc1, 1) + $.$spc.System.Numerics.BitOperations.RotateLeft(this._acc2, 7)) >>> 0) + $.$spc.System.Numerics.BitOperations.RotateLeft(this._acc3, 12)) >>> 0) + $.$spc.System.Numerics.BitOperations.RotateLeft(this._acc4, 18)) >>> 0);
                    }
                    static /*uint */ ApplyRound(/*uint*/ acc, /*ReadOnlySpan<byte>*/ lane)
                    {
                        acc += (($.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(lane) * 2246822519/*Prime32_2*/) >>> 0);
                        acc = $.$spc.System.Numerics.BitOperations.RotateLeft(acc, 13);
                        acc *= 2654435761/*Prime32_1*/;
                        return acc;
                    }
                    /*uint */ Complete(/*int*/ length, /*ReadOnlySpan<byte>*/ remaining)
                    {
                        /*uint*/ let acc = this._hadFullStripe ? this.Converge() : this._smallAcc;
                        acc += (length >>> 0);
                        while(remaining.Length >= $.$spc.System.UInt32.$z)
                        {
                            /*uint*/ let lane = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(remaining);
                            acc += ((lane * 3266489917/*Prime32_3*/) >>> 0);
                            acc = $.$spc.System.Numerics.BitOperations.RotateLeft(acc, 17);
                            acc *= 668265263/*Prime32_4*/;
                            remaining = remaining.Slice($.$spc.System.UInt32.$z);
                        }
                        for(/*int*/ let i = 0; i < remaining.Length; i++)
                        {
                            /*uint*/ let lane = remaining.get_Item(i).$v;
                            acc += ((lane * 374761393/*Prime32_5*/) >>> 0);
                            acc = $.$spc.System.Numerics.BitOperations.RotateLeft(acc, 11);
                            acc *= 2654435761/*Prime32_1*/;
                        }
                        acc ^= (acc >>> 15);
                        acc *= 2246822519/*Prime32_2*/;
                        acc ^= (acc >>> 13);
                        acc *= 3266489917/*Prime32_3*/;
                        acc ^= (acc >>> 16);
                        return acc;
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._acc1 = this._acc1;
                        copy._acc2 = this._acc2;
                        copy._acc3 = this._acc3;
                        copy._acc4 = this._acc4;
                        copy._smallAcc = this._smallAcc;
                        copy._hadFullStripe = this._hadFullStripe;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._acc1 = 0;
                        this._acc2 = 0;
                        this._acc3 = 0;
                        this._acc4 = 0;
                        this._smallAcc = 0;
                        this._hadFullStripe = false;
                    }
                    static $h = 688471;
                    static $z = 21;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"ProcessStripe","d":688471,"h":34360426839,"f":8},{"r":720897,"n":"Converge","d":688471,"h":38655394135,"f":2},{"r":720897,"p":[{"n":"acc","p":720897},{"n":"lane","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"ApplyRound","d":688471,"h":42950361431,"f":34},{"r":720897,"p":[{"n":"length","p":655361},{"n":"remaining","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Complete","d":688471,"h":47245328727,"f":8}],"l":[{"t":720897,"n":"_acc1","d":688471,"h":4295655767,"f":2},{"t":720897,"n":"_acc2","d":688471,"h":8590623063,"f":2},{"t":720897,"n":"_acc3","d":688471,"h":12885590359,"f":2},{"t":720897,"n":"_acc4","d":688471,"h":17180557655,"f":2},{"t":720897,"n":"_smallAcc","d":688471,"h":21475524951,"f":2},{"t":262145,"n":"_hadFullStripe","d":688471,"h":25770492247,"f":2}],"c":[{"p":[{"n":"seed","p":720897}],"n":".ctor","o":"$ctor$2","d":688471,"h":30065459543,"f":8},{"n":".ctor","o":"$ctor$3","d":688471,"h":51540296023,"f":1}],"d":622935,"h":688471}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.IO.Hashing.XxHash32.State`; }
                }, $cls, ($v) => $cls.$_State = $v);
            }
            /*int*/ static HashSize = 4;
            /*int*/ static StripeSize = 16;
            /*uint*/ _seed = 0;
            /*State*/ _state;
            /*byte[]?*/ _holdback = null;
            /*int*/ _length = 0;
            $ctor$2()
            {
                this.$ctor$3(0);
                {
                }
                return this;
            }
            $ctor$3(/*int*/ seed)
            {
                super.$ctor$1(4/*HashSize*/);
                {
                    this._seed = (seed >>> 0);
                    this.Reset();
                }
                return this;
            }
            $ctor$4(/*uint*/ seed, /*State*/ state, /*byte[]?*/ holdback, /*int*/ length)
            {
                super.$ctor$1(4/*HashSize*/);
                {
                    this._seed = seed;
                    this._state = state.Clone();
                    if ((length & 15) > 0)
                    {
                        this._holdback = $.$cast((holdback?.Clone() ?? null), $.$typeArray($.$spc.System.Byte));
                    }
                    this._length = length;
                }
                return this;
            }
            /*XxHash32 */ Clone()
            {
                return new $.$sih.System.IO.Hashing.XxHash32().$ctor$4(this._seed, this._state.Clone(), this._holdback, this._length);
            }
            /*void */ Reset()
            {
                this._state = new $.$sih.System.IO.Hashing.XxHash32.State().$ctor$2(this._seed);
                this._length = 0;
            }
            /*void */ Append(/*ReadOnlySpan<byte>*/ source)
            {
                /*int*/ let held = this._length & 15;
                if (held !== 0)
                {
                    /*int*/ let remain = ((16/*StripeSize*/ - held) | 0);
                    if (source.Length >= remain)
                    {
                        source.Slice$1(0, remain).CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._holdback, held));
                        this._state.ProcessStripe($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this._holdback));
                        source = source.Slice(remain);
                        this._length += remain;
                    }
                    else 
                    {
                        source.CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._holdback, held));
                        this._length += source.Length;
                        return;
                    }
                }
                while(source.Length >= 16/*StripeSize*/)
                {
                    this._state.ProcessStripe(source);
                    source = source.Slice(16/*StripeSize*/);
                    this._length += 16/*StripeSize*/;
                }
                if (source.Length > 0)
                {
                    this._holdback ??= $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [16/*StripeSize*/], null);
                    source.CopyTo($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(this._holdback));
                    this._length += source.Length;
                }
            }
            /*void */ GetCurrentHashCore(/*Span<byte>*/ destination)
            {
                /*uint*/ let hash = this.GetCurrentHashAsUInt32();
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32BigEndian(destination, hash);
            }
            /*uint */ GetCurrentHashAsUInt32()
            {
                /*int*/ let remainingLength = this._length & 15;
                /*ReadOnlySpan<byte>*/ let remaining = $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).Empty;
                if (remainingLength > 0)
                {
                    remaining = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$3(this._holdback, 0, remainingLength);
                }
                return this._state.Complete(this._length, remaining);
            }
            static /*byte[] */ Hash(/*byte[]*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$sih.System.IO.Hashing.XxHash32.Hash$2(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2(source), 0);
            }
            static /*byte[] */ Hash$1(/*byte[]*/ source, /*int*/ seed)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$sih.System.IO.Hashing.XxHash32.Hash$2(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2(source), seed);
            }
            static /*byte[] */ Hash$2(/*ReadOnlySpan<byte>*/ source, /*int*/ seed)
            {
                /*byte[]*/ let ret = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [4/*HashSize*/], null);
                /*uint*/ let hash = $.$sih.System.IO.Hashing.XxHash32.HashToUInt32(source, seed);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32BigEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(ret), hash);
                return ret;
            }
            static /*bool */ TryHash(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesWritten, /*int*/ seed)
            {
                if (destination.Length < 4/*HashSize*/)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                /*uint*/ let hash = $.$sih.System.IO.Hashing.XxHash32.HashToUInt32(source, seed);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32BigEndian(destination, hash);
                bytesWritten.$v = 4/*HashSize*/;
                return true;
            }
            static /*int */ Hash$3(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*int*/ seed)
            {
                if (destination.Length < 4/*HashSize*/)
                {
                    $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                /*uint*/ let hash = $.$sih.System.IO.Hashing.XxHash32.HashToUInt32(source, seed);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32BigEndian(destination, hash);
                return 4/*HashSize*/;
            }
            static /*uint */ HashToUInt32(/*ReadOnlySpan<byte>*/ source, /*int*/ seed)
            {
                /*int*/ let totalLength = source.Length;
                /*State*/ let state = new $.$sih.System.IO.Hashing.XxHash32.State().$ctor$2((seed >>> 0));
                while(source.Length >= 16/*StripeSize*/)
                {
                    state.ProcessStripe(source);
                    source = source.Slice(16/*StripeSize*/);
                }
                return state.Complete(totalLength, source);
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = $.$default($.$sih.System.IO.Hashing.XxHash32.State);
            }
            static $h = 622935;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":229719,"m":[{"r":622935,"n":"Clone","d":622935,"h":47245263191,"f":1},{"r":65537,"n":"Reset","d":622935,"h":51540230487,"f":32769},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Append","d":622935,"h":55835197783,"f":32769},{"r":65537,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetCurrentHashCore","d":622935,"h":60130165079,"f":32772},{"r":720897,"n":"GetCurrentHashAsUInt32","d":622935,"h":64425132375,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":0,"p":[{"n":"source","p":0}],"n":"Hash","d":622935,"h":68720099671,"f":33},{"r":0,"p":[{"n":"source","p":0},{"n":"seed","p":655361}],"n":"Hash","o":"@$1","d":622935,"h":73015066967,"f":33},{"r":0,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"seed","p":655361,"f":65,"v":0}],"n":"Hash","o":"@$2","d":622935,"h":77310034263,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2},{"n":"seed","p":655361,"f":65,"v":0}],"n":"TryHash","d":622935,"h":81605001559,"f":33},{"r":655361,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"seed","p":655361,"f":65,"v":0}],"n":"Hash","o":"@$3","d":622935,"h":85899968855,"f":33},{"r":720897,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"seed","p":655361,"f":65,"v":0}],"n":"HashToUInt32","d":622935,"h":90194936151,"f":33,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]}],"l":[{"t":655361,"n":"HashSize","d":622935,"h":8590557527,"f":34},{"t":655361,"n":"StripeSize","d":622935,"h":12885524823,"f":34},{"t":720897,"n":"_seed","d":622935,"h":17180492119,"f":2},{"t":688471,"n":"_state","d":622935,"h":21475459415,"f":2},{"t":0,"n":"_holdback","d":622935,"h":25770426711,"f":2},{"t":655361,"n":"_length","d":622935,"h":30065394007,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":622935,"h":34360361303,"f":1},{"p":[{"n":"seed","p":655361}],"n":".ctor","o":"$ctor$3","d":622935,"h":38655328599,"f":1},{"p":[{"n":"seed","p":720897},{"n":"state","p":688471},{"n":"holdback","p":0},{"n":"length","p":655361}],"n":".ctor","o":"$ctor$4","d":622935,"h":42950295895,"f":2}],"j":[688471],"h":622935}; }
            static get $b() { return $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm; }
            static get $fullName() { return `System.IO.Hashing.XxHash32`; }
        });
        
        $asm.$cls("$sih.System.IO.Hashing.XxHash64", ($self) => class XxHash64 extends $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm
        {
            static /*ulong */ Avalanche(/*ulong*/ hash)
            {
                hash ^= hash >> 33n;
                hash *= 14029467366897019727n;
                hash ^= hash >> 29n;
                hash *= 1609587929392839161n;
                hash ^= hash >> 32n;
                return hash;
            }
            static $_State;
            static get State()
            {
                let $cls = $.$sih.System.IO.Hashing.XxHash64;
                return $cls.$_State ??= $asm.$nstr("$sih.System.IO.Hashing.XxHash64.State", ($self) => class State extends $.$spc.System.ValueType
                {
                    /*ulong*/  get _acc1() { return this.$getField(0, 8); }
                    /*ulong*/  set _acc1(value) { this.$setField(0, 8, value); }
                    /*ulong*/  get _acc2() { return this.$getField(8, 8); }
                    /*ulong*/  set _acc2(value) { this.$setField(8, 8, value); }
                    /*ulong*/  get _acc3() { return this.$getField(16, 8); }
                    /*ulong*/  set _acc3(value) { this.$setField(16, 8, value); }
                    /*ulong*/  get _acc4() { return this.$getField(24, 8); }
                    /*ulong*/  set _acc4(value) { this.$setField(24, 8, value); }
                    /*ulong*/  get _smallAcc() { return this.$getField(32, 8); }
                    /*ulong*/  set _smallAcc(value) { this.$setField(32, 8, value); }
                    /*bool*/  get _hadFullStripe() { return this.$getField(40, 1); }
                    /*bool*/  set _hadFullStripe(value) { this.$setField(40, 1, value); }
                    $ctor$2(/*ulong*/ seed)
                    {
                        super.$ctor$1();
                        {
                            this._acc1 = seed + 11400714785074694791n + 14029467366897019727n;
                            this._acc2 = seed + 14029467366897019727n;
                            this._acc3 = seed;
                            this._acc4 = seed - 11400714785074694791n;
                            this._smallAcc = seed + 2870177450012600261n;
                            this._hadFullStripe = false;
                        }
                        return this;
                    }
                    /*void */ ProcessStripe(/*ReadOnlySpan<byte>*/ source)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(source.Length >= 32/*StripeSize*/, "source.Length >= StripeSize");
                        source = source.Slice$1(0, 32/*StripeSize*/);
                        this._acc1 = $.$sih.System.IO.Hashing.XxHash64.State.ApplyRound(this._acc1, source);
                        this._acc2 = $.$sih.System.IO.Hashing.XxHash64.State.ApplyRound(this._acc2, source.Slice($.$spc.System.UInt64.$z));
                        this._acc3 = $.$sih.System.IO.Hashing.XxHash64.State.ApplyRound(this._acc3, source.Slice(((2 * $.$spc.System.UInt64.$z) | 0)));
                        this._acc4 = $.$sih.System.IO.Hashing.XxHash64.State.ApplyRound(this._acc4, source.Slice(((3 * $.$spc.System.UInt64.$z) | 0)));
                        this._hadFullStripe = true;
                    }
                    static /*ulong */ MergeAccumulator(/*ulong*/ acc, /*ulong*/ accN)
                    {
                        acc ^= $.$sih.System.IO.Hashing.XxHash64.State.ApplyRound$1(0n, accN);
                        acc *= 11400714785074694791n;
                        acc += 9650029242287828579n;
                        return acc;
                    }
                    /*ulong */ Converge()
                    {
                        /*ulong*/ let acc = $.$spc.System.Numerics.BitOperations.RotateLeft$1(this._acc1, 1) + $.$spc.System.Numerics.BitOperations.RotateLeft$1(this._acc2, 7) + $.$spc.System.Numerics.BitOperations.RotateLeft$1(this._acc3, 12) + $.$spc.System.Numerics.BitOperations.RotateLeft$1(this._acc4, 18);
                        acc = $.$sih.System.IO.Hashing.XxHash64.State.MergeAccumulator(acc, this._acc1);
                        acc = $.$sih.System.IO.Hashing.XxHash64.State.MergeAccumulator(acc, this._acc2);
                        acc = $.$sih.System.IO.Hashing.XxHash64.State.MergeAccumulator(acc, this._acc3);
                        acc = $.$sih.System.IO.Hashing.XxHash64.State.MergeAccumulator(acc, this._acc4);
                        return acc;
                    }
                    static /*ulong */ ApplyRound(/*ulong*/ acc, /*ReadOnlySpan<byte>*/ lane)
                    {
                        return $.$sih.System.IO.Hashing.XxHash64.State.ApplyRound$1(acc, $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian(lane));
                    }
                    static /*ulong */ ApplyRound$1(/*ulong*/ acc, /*ulong*/ lane)
                    {
                        acc += lane * 14029467366897019727n;
                        acc = $.$spc.System.Numerics.BitOperations.RotateLeft$1(acc, 31);
                        acc *= 11400714785074694791n;
                        return acc;
                    }
                    /*ulong */ Complete(/*long*/ length, /*ReadOnlySpan<byte>*/ remaining)
                    {
                        /*ulong*/ let acc = this._hadFullStripe ? this.Converge() : this._smallAcc;
                        acc += $.$cast(length, $.$spc.System.UInt64);
                        while(remaining.Length >= $.$spc.System.UInt64.$z)
                        {
                            /*ulong*/ let lane = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian(remaining);
                            acc ^= $.$sih.System.IO.Hashing.XxHash64.State.ApplyRound$1(0n, lane);
                            acc = $.$spc.System.Numerics.BitOperations.RotateLeft$1(acc, 27);
                            acc *= 11400714785074694791n;
                            acc += 9650029242287828579n;
                            remaining = remaining.Slice($.$spc.System.UInt64.$z);
                        }
                        if (remaining.Length >= $.$spc.System.UInt32.$z)
                        {
                            /*ulong*/ let lane = BigInt($.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(remaining));
                            acc ^= lane * 11400714785074694791n;
                            acc = $.$spc.System.Numerics.BitOperations.RotateLeft$1(acc, 23);
                            acc *= 14029467366897019727n;
                            acc += 1609587929392839161n;
                            remaining = remaining.Slice($.$spc.System.UInt32.$z);
                        }
                        for(/*int*/ let i = 0; i < remaining.Length; i++)
                        {
                            /*ulong*/ let lane = BigInt(remaining.get_Item(i).$v);
                            acc ^= lane * 2870177450012600261n;
                            acc = $.$spc.System.Numerics.BitOperations.RotateLeft$1(acc, 11);
                            acc *= 11400714785074694791n;
                        }
                        return $.$sih.System.IO.Hashing.XxHash64.Avalanche(acc);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._acc1 = this._acc1;
                        copy._acc2 = this._acc2;
                        copy._acc3 = this._acc3;
                        copy._acc4 = this._acc4;
                        copy._smallAcc = this._smallAcc;
                        copy._hadFullStripe = this._hadFullStripe;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._acc1 = 0n;
                        this._acc2 = 0n;
                        this._acc3 = 0n;
                        this._acc4 = 0n;
                        this._smallAcc = 0n;
                        this._hadFullStripe = false;
                    }
                    static $h = 819543;
                    static $z = 41;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"ProcessStripe","d":819543,"h":34360557911,"f":8},{"r":983041,"p":[{"n":"acc","p":983041},{"n":"accN","p":983041}],"n":"MergeAccumulator","d":819543,"h":38655525207,"f":34},{"r":983041,"n":"Converge","d":819543,"h":42950492503,"f":2},{"r":983041,"p":[{"n":"acc","p":983041},{"n":"lane","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"ApplyRound","d":819543,"h":47245459799,"f":34},{"r":983041,"p":[{"n":"acc","p":983041},{"n":"lane","p":983041}],"n":"ApplyRound","o":"@$1","d":819543,"h":51540427095,"f":34},{"r":983041,"p":[{"n":"length","p":917505},{"n":"remaining","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Complete","d":819543,"h":55835394391,"f":8}],"l":[{"t":983041,"n":"_acc1","d":819543,"h":4295786839,"f":2},{"t":983041,"n":"_acc2","d":819543,"h":8590754135,"f":2},{"t":983041,"n":"_acc3","d":819543,"h":12885721431,"f":2},{"t":983041,"n":"_acc4","d":819543,"h":17180688727,"f":2},{"t":983041,"n":"_smallAcc","d":819543,"h":21475656023,"f":2},{"t":262145,"n":"_hadFullStripe","d":819543,"h":25770623319,"f":2}],"c":[{"p":[{"n":"seed","p":983041}],"n":".ctor","o":"$ctor$2","d":819543,"h":30065590615,"f":8},{"n":".ctor","o":"$ctor$3","d":819543,"h":60130361687,"f":1}],"d":754007,"h":819543}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.IO.Hashing.XxHash64.State`; }
                }, $cls, ($v) => $cls.$_State = $v);
            }
            /*int*/ static HashSize = 8;
            /*int*/ static StripeSize = 32;
            /*ulong*/ _seed = 0n;
            /*State*/ _state;
            /*byte[]?*/ _holdback = null;
            /*long*/ _length = 0n;
            $ctor$2()
            {
                this.$ctor$3(0n);
                {
                }
                return this;
            }
            $ctor$3(/*long*/ seed)
            {
                super.$ctor$1(8/*HashSize*/);
                {
                    this._seed = $.$cast(seed, $.$spc.System.UInt64);
                    this.Reset();
                }
                return this;
            }
            $ctor$4(/*ulong*/ seed, /*State*/ state, /*byte[]?*/ holdback, /*long*/ length)
            {
                super.$ctor$1(8/*HashSize*/);
                {
                    this._seed = seed;
                    this._state = state.Clone();
                    if (($.$cast(length, $.$spc.System.Int32) & 31) > 0)
                    {
                        this._holdback = $.$cast((holdback?.Clone() ?? null), $.$typeArray($.$spc.System.Byte));
                    }
                    this._length = length;
                }
                return this;
            }
            /*XxHash64 */ Clone()
            {
                return new $.$sih.System.IO.Hashing.XxHash64().$ctor$4(this._seed, this._state.Clone(), this._holdback, this._length);
            }
            /*void */ Reset()
            {
                this._state = new $.$sih.System.IO.Hashing.XxHash64.State().$ctor$2(this._seed);
                this._length = 0n;
            }
            /*void */ Append(/*ReadOnlySpan<byte>*/ source)
            {
                /*int*/ let held = $.$cast(this._length, $.$spc.System.Int32) & 31;
                if (held !== 0)
                {
                    /*int*/ let remain = ((32/*StripeSize*/ - held) | 0);
                    if (source.Length >= remain)
                    {
                        source.Slice$1(0, remain).CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._holdback, held));
                        this._state.ProcessStripe($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this._holdback));
                        source = source.Slice(remain);
                        this._length += BigInt(remain);
                    }
                    else 
                    {
                        source.CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Byte, this._holdback, held));
                        this._length += BigInt(source.Length);
                        return;
                    }
                }
                while(source.Length >= 32/*StripeSize*/)
                {
                    this._state.ProcessStripe(source);
                    source = source.Slice(32/*StripeSize*/);
                    this._length += BigInt(32/*StripeSize*/);
                }
                if (source.Length > 0)
                {
                    this._holdback ??= $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [32/*StripeSize*/], null);
                    source.CopyTo($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(this._holdback));
                    this._length += BigInt(source.Length);
                }
            }
            /*void */ GetCurrentHashCore(/*Span<byte>*/ destination)
            {
                /*ulong*/ let hash = this.GetCurrentHashAsUInt64();
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt64BigEndian(destination, hash);
            }
            /*ulong */ GetCurrentHashAsUInt64()
            {
                /*int*/ let remainingLength = $.$cast(this._length, $.$spc.System.Int32) & 31;
                /*ReadOnlySpan<byte>*/ let remaining = $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).Empty;
                if (remainingLength > 0)
                {
                    remaining = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$3(this._holdback, 0, remainingLength);
                }
                return this._state.Complete(this._length, remaining);
            }
            static /*byte[] */ Hash(/*byte[]*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$sih.System.IO.Hashing.XxHash64.Hash$2(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2(source), 0n);
            }
            static /*byte[] */ Hash$1(/*byte[]*/ source, /*long*/ seed)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$sih.System.IO.Hashing.XxHash64.Hash$2(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2(source), seed);
            }
            static /*byte[] */ Hash$2(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                /*byte[]*/ let ret = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [8/*HashSize*/], null);
                /*ulong*/ let hash = $.$sih.System.IO.Hashing.XxHash64.HashToUInt64(source, seed);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt64BigEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(ret), hash);
                return ret;
            }
            static /*bool */ TryHash(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesWritten, /*long*/ seed)
            {
                if (destination.Length < 8/*HashSize*/)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                /*ulong*/ let hash = $.$sih.System.IO.Hashing.XxHash64.HashToUInt64(source, seed);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt64BigEndian(destination, hash);
                bytesWritten.$v = 8/*HashSize*/;
                return true;
            }
            static /*int */ Hash$3(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*long*/ seed)
            {
                if (destination.Length < 8/*HashSize*/)
                {
                    $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                /*ulong*/ let hash = $.$sih.System.IO.Hashing.XxHash64.HashToUInt64(source, seed);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt64BigEndian(destination, hash);
                return 8/*HashSize*/;
            }
            static /*ulong */ HashToUInt64(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                /*int*/ let totalLength = source.Length;
                /*State*/ let state = new $.$sih.System.IO.Hashing.XxHash64.State().$ctor$2($.$cast(seed, $.$spc.System.UInt64));
                while(source.Length >= 32/*StripeSize*/)
                {
                    state.ProcessStripe(source);
                    source = source.Slice(32/*StripeSize*/);
                }
                return state.Complete(BigInt((totalLength >>> 0)), source);
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = $.$default($.$sih.System.IO.Hashing.XxHash64.State);
            }
            static $h = 754007;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":229719,"m":[{"r":983041,"p":[{"n":"hash","p":983041}],"n":"Avalanche","d":754007,"h":4295721303,"f":40},{"r":754007,"n":"Clone","d":754007,"h":51540361559,"f":1},{"r":65537,"n":"Reset","d":754007,"h":55835328855,"f":32769},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Append","d":754007,"h":60130296151,"f":32769},{"r":65537,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetCurrentHashCore","d":754007,"h":64425263447,"f":32772},{"r":983041,"n":"GetCurrentHashAsUInt64","d":754007,"h":68720230743,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":0,"p":[{"n":"source","p":0}],"n":"Hash","d":754007,"h":73015198039,"f":33},{"r":0,"p":[{"n":"source","p":0},{"n":"seed","p":917505}],"n":"Hash","o":"@$1","d":754007,"h":77310165335,"f":33},{"r":0,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"seed","p":917505,"f":65,"v":0}],"n":"Hash","o":"@$2","d":754007,"h":81605132631,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2},{"n":"seed","p":917505,"f":65,"v":0}],"n":"TryHash","d":754007,"h":85900099927,"f":33},{"r":655361,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"seed","p":917505,"f":65,"v":0}],"n":"Hash","o":"@$3","d":754007,"h":90195067223,"f":33},{"r":983041,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"seed","p":917505,"f":65,"v":0}],"n":"HashToUInt64","d":754007,"h":94490034519,"f":33,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]}],"l":[{"t":655361,"n":"HashSize","d":754007,"h":12885655895,"f":34},{"t":655361,"n":"StripeSize","d":754007,"h":17180623191,"f":34},{"t":983041,"n":"_seed","d":754007,"h":21475590487,"f":2},{"t":819543,"n":"_state","d":754007,"h":25770557783,"f":2},{"t":0,"n":"_holdback","d":754007,"h":30065525079,"f":2},{"t":917505,"n":"_length","d":754007,"h":34360492375,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":754007,"h":38655459671,"f":1},{"p":[{"n":"seed","p":917505}],"n":".ctor","o":"$ctor$3","d":754007,"h":42950426967,"f":1},{"p":[{"n":"seed","p":983041},{"n":"state","p":819543},{"n":"holdback","p":0},{"n":"length","p":917505}],"n":".ctor","o":"$ctor$4","d":754007,"h":47245394263,"f":2}],"j":[819543],"h":754007}; }
            static get $b() { return $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm; }
            static get $fullName() { return `System.IO.Hashing.XxHash64`; }
        });
        
        $asm.$cls("$sih.System.IO.Hashing.Crc32", ($self) => class Crc32 extends $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm
        {
            static /*ReadOnlySpan<uint> */ get CrcLookup()
            {
                return this.$cacheCrcLookup ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$2([ 0, 1996959894, 3993919788, 2567524794, 124634137, 1886057615, 3915621685, 2657392035, 249268274, 2044508324, 3772115230, 2547177864, 162941995, 2125561021, 3887607047, 2428444049, 498536548, 1789927666, 4089016648, 2227061214, 450548861, 1843258603, 4107580753, 2211677639, 325883990, 1684777152, 4251122042, 2321926636, 335633487, 1661365465, 4195302755, 2366115317, 997073096, 1281953886, 3579855332, 2724688242, 1006888145, 1258607687, 3524101629, 2768942443, 901097722, 1119000684, 3686517206, 2898065728, 853044451, 1172266101, 3705015759, 2882616665, 651767980, 1373503546, 3369554304, 3218104598, 565507253, 1454621731, 3485111705, 3099436303, 671266974, 1594198024, 3322730930, 2970347812, 795835527, 1483230225, 3244367275, 3060149565, 1994146192, 31158534, 2563907772, 4023717930, 1907459465, 112637215, 2680153253, 3904427059, 2013776290, 251722036, 2517215374, 3775830040, 2137656763, 141376813, 2439277719, 3865271297, 1802195444, 476864866, 2238001368, 4066508878, 1812370925, 453092731, 2181625025, 4111451223, 1706088902, 314042704, 2344532202, 4240017532, 1658658271, 366619977, 2362670323, 4224994405, 1303535960, 984961486, 2747007092, 3569037538, 1256170817, 1037604311, 2765210733, 3554079995, 1131014506, 879679996, 2909243462, 3663771856, 1141124467, 855842277, 2852801631, 3708648649, 1342533948, 654459306, 3188396048, 3373015174, 1466479909, 544179635, 3110523913, 3462522015, 1591671054, 702138776, 2966460450, 3352799412, 1504918807, 783551873, 3082640443, 3233442989, 3988292384, 2596254646, 62317068, 1957810842, 3939845945, 2647816111, 81470997, 1943803523, 3814918930, 2489596804, 225274430, 2053790376, 3826175755, 2466906013, 167816743, 2097651377, 4027552580, 2265490386, 503444072, 1762050814, 4150417245, 2154129355, 426522225, 1852507879, 4275313526, 2312317920, 282753626, 1742555852, 4189708143, 2394877945, 397917763, 1622183637, 3604390888, 2714866558, 953729732, 1340076626, 3518719985, 2797360999, 1068828381, 1219638859, 3624741850, 2936675148, 906185462, 1090812512, 3747672003, 2825379669, 829329135, 1181335161, 3412177804, 3160834842, 628085408, 1382605366, 3423369109, 3138078467, 570562233, 1426400815, 3317316542, 2998733608, 733239954, 1555261956, 3268935591, 3050360625, 752459403, 1541320221, 2607071920, 3965973030, 1969922972, 40735498, 2617837225, 3943577151, 1913087877, 83908371, 2512341634, 3803740692, 2075208622, 213261112, 2463272603, 3855990285, 2094854071, 198958881, 2262029012, 4057260610, 1759359992, 534414190, 2176718541, 4139329115, 1873836001, 414664567, 2282248934, 4279200368, 1711684554, 285281116, 2405801727, 4167216745, 1634467795, 376229701, 2685067896, 3608007406, 1308918612, 956543938, 2808555105, 3495958263, 1231636301, 1047427035, 2932959818, 3654703836, 1088359270, 936918000, 2847714899, 3736837829, 1202900863, 817233897, 3183342108, 3401237130, 1404277552, 615818150, 3134207493, 3453421203, 1423857449, 601450431, 3009837614, 3294710456, 1567103746, 711928724, 3020668471, 3272380065, 1510334235, 755167117 ]);
            }
            static /*uint */ UpdateScalarArm64(/*uint*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(/*$.$spc.System.Runtime.Intrinsics.Arm.Crc32*/$.$spc.DeletedObject.Arm64.IsSupported$1, "ARM CRC support is required.");
                if (source.Length >= $.$spc.System.UInt64.$z)
                {
                    /*ref byte*/ let ptr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, source);
                    /*int*/ let longLength = source.Length & ~7;
                    for(/*int*/ let i = 0; i < longLength; i += $.$spc.System.UInt64.$z)
                    {
                        crc = /*$.$spc.System.Runtime.Intrinsics.Arm.Crc32*/$.$spc.DeletedObject.Arm64.ComputeCrc32(crc, $.$spc.System.Runtime.CompilerServices.Unsafe.ReadUnaligned$1($.$spc.System.UInt64, $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, ptr, i)));
                    }
                    source = source.Slice(longLength);
                }
                for(/*int*/ let i = 0; i < source.Length; i++)
                {
                    crc = /*$.$spc.System.Runtime.Intrinsics.Arm.Crc32*/$.$spc.DeletedObject.ComputeCrc32(crc, source.get_Item(i).$v);
                }
                return crc;
            }
            static /*uint */ UpdateScalarArm32(/*uint*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(/*$.$spc.System.Runtime.Intrinsics.Arm.Crc32*/$.$spc.DeletedObject.IsSupported$1, "ARM CRC support is required.");
                if (source.Length >= $.$spc.System.UInt32.$z)
                {
                    /*ref byte*/ let ptr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, source);
                    /*int*/ let intLength = source.Length & ~3;
                    for(/*int*/ let i = 0; i < intLength; i += $.$spc.System.UInt32.$z)
                    {
                        crc = /*$.$spc.System.Runtime.Intrinsics.Arm.Crc32*/$.$spc.DeletedObject.ComputeCrc32$2(crc, $.$spc.System.Runtime.CompilerServices.Unsafe.ReadUnaligned$1($.$spc.System.UInt32, $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, ptr, i)));
                    }
                    source = source.Slice(intLength);
                }
                for(/*int*/ let i = 0; i < source.Length; i++)
                {
                    crc = /*$.$spc.System.Runtime.Intrinsics.Arm.Crc32*/$.$spc.DeletedObject.ComputeCrc32(crc, source.get_Item(i).$v);
                }
                return crc;
            }
            /*uint*/ static InitialState = 4294967295;
            /*int*/ static Size = 4;
            /*uint*/ _crc = 4294967295;
            $ctor$2()
            {
                super.$ctor$1(4/*Size*/);
                {
                }
                return this;
            }
            $ctor$3(/*uint*/ crc)
            {
                super.$ctor$1(4/*Size*/);
                {
                    this._crc = crc;
                }
                return this;
            }
            /*Crc32 */ Clone()
            {
                return new $.$sih.System.IO.Hashing.Crc32().$ctor$3(this._crc);
            }
            /*void */ Append(/*ReadOnlySpan<byte>*/ source)
            {
                this._crc = $.$sih.System.IO.Hashing.Crc32.Update(this._crc, source);
            }
            /*void */ Reset()
            {
                this._crc = 4294967295/*InitialState*/;
            }
            /*void */ GetCurrentHashCore(/*Span<byte>*/ destination)
            {
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian(destination, ~this._crc);
            }
            /*void */ GetHashAndResetCore(/*Span<byte>*/ destination)
            {
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian(destination, ~this._crc);
                this._crc = 4294967295/*InitialState*/;
            }
            /*uint */ GetCurrentHashAsUInt32()
            {
                return ~this._crc;
            }
            static /*byte[] */ Hash(/*byte[]*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$sih.System.IO.Hashing.Crc32.Hash$1(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2(source));
            }
            static /*byte[] */ Hash$1(/*ReadOnlySpan<byte>*/ source)
            {
                /*byte[]*/ let ret = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [4/*Size*/], null);
                /*uint*/ let hash = $.$sih.System.IO.Hashing.Crc32.HashToUInt32(source);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(ret), hash);
                return ret;
            }
            static /*bool */ TryHash(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                if (destination.Length < 4/*Size*/)
                {
                    bytesWritten.$v = 0;
                    return false;
                }
                /*uint*/ let hash = $.$sih.System.IO.Hashing.Crc32.HashToUInt32(source);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian(destination, hash);
                bytesWritten.$v = 4/*Size*/;
                return true;
            }
            static /*int */ Hash$2(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination)
            {
                if (destination.Length < 4/*Size*/)
                {
                    $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                /*uint*/ let hash = $.$sih.System.IO.Hashing.Crc32.HashToUInt32(source);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt32LittleEndian(destination, hash);
                return 4/*Size*/;
            }
            static /*uint */ HashToUInt32(/*ReadOnlySpan<byte>*/ source)
            {
                return ~$.$sih.System.IO.Hashing.Crc32.Update(4294967295/*InitialState*/, source);
            }
            static /*uint */ Update(/*uint*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                if ($.$sih.System.IO.Hashing.Crc32.CanBeVectorized(source))
                {
                    return $.$sih.System.IO.Hashing.Crc32.UpdateVectorized(crc, source);
                }
                return $.$sih.System.IO.Hashing.Crc32.UpdateScalar(crc, source);
            }
            static /*uint */ UpdateScalar(/*uint*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                //if (System.Runtime.Intrinsics.Arm.Crc32.Arm64.IsSupported) { ... }
                //if (System.Runtime.Intrinsics.Arm.Crc32.IsSupported) { ... }
                /*ReadOnlySpan<uint>*/ let crcLookup = $.$sih.System.IO.Hashing.Crc32.CrcLookup;
                for(/*int*/ let i = 0; i < source.Length; i++)
                {
                    /*byte*/ let idx = $.$cast(crc, $.$spc.System.Byte);
                    idx ^= source.get_Item(i).$v;
                    crc = crcLookup.get_Item(idx).$v ^ (crc >>> 8);
                }
                return crc;
            }
            static /*bool */ CanBeVectorized(/*ReadOnlySpan<byte>*/ source)
            {
                return $.$spc.System.BitConverter.IsLittleEndian && $.$sih.System.IO.Hashing.VectorHelper.IsSupported && source.Length >= (($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count * (/*System.Runtime.Intrinsics.Arm.Crc32.IsSupported ? 8 : */ 1)) | 0);
            }
            static /*uint */ UpdateVectorized(/*uint*/ crc, /*ReadOnlySpan<byte>*/ source)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$sih.System.IO.Hashing.Crc32.CanBeVectorized(source), "source cannot be vectorized.");
                /*ref byte*/ let srcRef = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, source);
                /*int*/ let length = source.Length;
                /*Vector128<ulong>*/ let kConstants;
                /*Vector128<ulong>*/ let x1;
                /*Vector128<ulong>*/ let x2;
                if (length >= (($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count * 8) | 0))
                {
                    x1 = $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.Byte, $.$spc.System.Runtime.Intrinsics.Vector128.LoadUnsafe($.$spc.System.Byte, srcRef));
                    x2 = $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.Byte, $.$spc.System.Runtime.Intrinsics.Vector128.LoadUnsafe$1($.$spc.System.Byte, srcRef, 16));
                    /*Vector128<ulong>*/ let x3 = $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.Byte, $.$spc.System.Runtime.Intrinsics.Vector128.LoadUnsafe$1($.$spc.System.Byte, srcRef, 32));
                    /*Vector128<ulong>*/ let x4 = $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.Byte, $.$spc.System.Runtime.Intrinsics.Vector128.LoadUnsafe$1($.$spc.System.Byte, srcRef, 48));
                    srcRef = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, srcRef, (($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count * 4) | 0));
                    length -= (($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count * 4) | 0);
                    x1 = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr(x1, $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.UInt32, $.$spc.System.Runtime.Intrinsics.Vector128.CreateScalar$11(crc)));
                    kConstants = $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0x154442BD4n, 0x1C6E41596n);
                    do
                    {
                        /*Vector128<ulong>*/ let y5 = $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.Byte, $.$spc.System.Runtime.Intrinsics.Vector128.LoadUnsafe($.$spc.System.Byte, srcRef));
                        /*Vector128<ulong>*/ let y6 = $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.Byte, $.$spc.System.Runtime.Intrinsics.Vector128.LoadUnsafe$1($.$spc.System.Byte, srcRef, 16));
                        /*Vector128<ulong>*/ let y7 = $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.Byte, $.$spc.System.Runtime.Intrinsics.Vector128.LoadUnsafe$1($.$spc.System.Byte, srcRef, 32));
                        /*Vector128<ulong>*/ let y8 = $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.Byte, $.$spc.System.Runtime.Intrinsics.Vector128.LoadUnsafe$1($.$spc.System.Byte, srcRef, 48));
                        x1 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(y5, x1, kConstants);
                        x2 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(y6, x2, kConstants);
                        x3 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(y7, x3, kConstants);
                        x4 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(y8, x4, kConstants);
                        srcRef = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, srcRef, (($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count * 4) | 0));
                        length -= (($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count * 4) | 0);
                    }
                    while(length >= (($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count * 4) | 0));
                    kConstants = $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0x1751997D0n, 0xCCAA009En);
                    x1 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(x2, x1, kConstants);
                    x1 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(x3, x1, kConstants);
                    x1 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair(x4, x1, kConstants);
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(length >= 16, "length >= 16");
                    x1 = $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.Byte, $.$spc.System.Runtime.Intrinsics.Vector128.LoadUnsafe($.$spc.System.Byte, srcRef));
                    x1 = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr(x1, $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.UInt32, $.$spc.System.Runtime.Intrinsics.Vector128.CreateScalar$11(crc)));
                    srcRef = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, srcRef, $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count);
                    length -= $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count;
                }
                while(length >= $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count)
                {
                    x1 = $.$sih.System.IO.Hashing.VectorHelper.FoldPolynomialPair($.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.Byte, $.$spc.System.Runtime.Intrinsics.Vector128.LoadUnsafe($.$spc.System.Byte, srcRef)), x1, $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0x1751997D0n, 0xCCAA009En));
                    srcRef = $.$spc.System.Runtime.CompilerServices.Unsafe.Add($.$spc.System.Byte, srcRef, $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count);
                    length -= $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.Byte).Count;
                }
                /*Vector128<ulong>*/ let bitmask = $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt64($.$spc.System.Int32, $.$spc.System.Runtime.Intrinsics.Vector128.Create$19(~0, 0, ~0, 0));
                x1 = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr($.$sih.System.IO.Hashing.VectorHelper.ShiftRightBytesInVector(x1, 8), $.$sih.System.IO.Hashing.VectorHelper.CarrylessMultiplyLower(x1, $.$spc.System.Runtime.Intrinsics.Vector128.CreateScalar$12(0xCCAA009En)));
                x1 = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr($.$sih.System.IO.Hashing.VectorHelper.CarrylessMultiplyLower($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_BitwiseAnd(x1, bitmask), $.$spc.System.Runtime.Intrinsics.Vector128.CreateScalar$12(0x163CD6124n)), $.$sih.System.IO.Hashing.VectorHelper.ShiftRightBytesInVector(x1, 4));
                kConstants = $.$spc.System.Runtime.Intrinsics.Vector128.Create$25(0x1DB710641n, 0x1F7011641n);
                x2 = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_BitwiseAnd($.$sih.System.IO.Hashing.VectorHelper.CarrylessMultiplyLeftLowerRightUpper($.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_BitwiseAnd(x1, bitmask), kConstants), bitmask);
                x2 = $.$sih.System.IO.Hashing.VectorHelper.CarrylessMultiplyLower(x2, kConstants);
                x1 = $.$spc.System.Runtime.Intrinsics.Vector128$$($.$spc.System.UInt64).op_ExclusiveOr(x1, x2);
                /*uint*/ let result = $.$spc.System.Runtime.Intrinsics.Vector128.GetElement($.$spc.System.UInt32, $.$spc.System.Runtime.Intrinsics.Vector128.AsUInt32($.$spc.System.UInt64, x1), 1);
                return length > 0 ? $.$sih.System.IO.Hashing.Crc32.UpdateScalar(result, $.$spc.System.Runtime.InteropServices.MemoryMarshal.CreateReadOnlySpan($.$spc.System.Byte, srcRef, length)) : result;
            }
            static $h = 98647;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":229719,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"g":{"r":0,"d":0,"h":8590033239,"f":34},"n":"CrcLookup","d":98647,"h":4295065943,"f":34}],"m":[{"r":720897,"p":[{"n":"crc","p":720897},{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"UpdateScalarArm64","d":98647,"h":12885000535,"f":34},{"r":720897,"p":[{"n":"crc","p":720897},{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"UpdateScalarArm32","d":98647,"h":17179967831,"f":34},{"r":98647,"n":"Clone","d":98647,"h":42949771607,"f":1},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Append","d":98647,"h":47244738903,"f":32769},{"r":65537,"n":"Reset","d":98647,"h":51539706199,"f":32769},{"r":65537,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetCurrentHashCore","d":98647,"h":55834673495,"f":32772},{"r":65537,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetHashAndResetCore","d":98647,"h":60129640791,"f":32772},{"r":720897,"n":"GetCurrentHashAsUInt32","d":98647,"h":64424608087,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":0,"p":[{"n":"source","p":0}],"n":"Hash","d":98647,"h":68719575383,"f":33},{"r":0,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Hash","o":"@$1","d":98647,"h":73014542679,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryHash","d":98647,"h":77309509975,"f":33},{"r":655361,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Hash","o":"@$2","d":98647,"h":81604477271,"f":33},{"r":720897,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"HashToUInt32","d":98647,"h":85899444567,"f":33,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":720897,"p":[{"n":"crc","p":720897},{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Update","d":98647,"h":90194411863,"f":34},{"r":720897,"p":[{"n":"crc","p":720897},{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"UpdateScalar","d":98647,"h":94489379159,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"CanBeVectorized","d":98647,"h":98784346455,"f":34},{"r":720897,"p":[{"n":"crc","p":720897},{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"UpdateVectorized","d":98647,"h":103079313751,"f":34}],"l":[{"t":720897,"n":"InitialState","d":98647,"h":21474935127,"f":34},{"t":655361,"n":"Size","d":98647,"h":25769902423,"f":34},{"t":720897,"n":"_crc","d":98647,"h":30064869719,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":98647,"h":34359837015,"f":1},{"p":[{"n":"crc","p":720897}],"n":".ctor","o":"$ctor$3","d":98647,"h":38654804311,"f":2}],"h":98647}; }
            static get $b() { return $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm; }
            static get $fullName() { return `System.IO.Hashing.Crc32`; }
        });
        
        $asm.$cls("$sih.System.IO.Hashing.XxHash128", ($self) => class XxHash128 extends $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm
        {
            /*int*/ static HashLengthInBytes = 16;
            /*State*/ _state;
            $ctor$2()
            {
                this.$ctor$3(0n);
                {
                }
                return this;
            }
            $ctor$3(/*long*/ seed)
            {
                super.$ctor$1(16/*HashLengthInBytes*/);
                {
                    $.$sih.System.IO.Hashing.XxHashShared.Initialize($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sih.System.IO.Hashing.XxHashShared.State, () => this._state, ($v) => this._state = $v, null), $.$cast(seed, $.$spc.System.UInt64));
                }
                return this;
            }
            $ctor$4(/*State*/ state)
            {
                super.$ctor$1(16/*HashLengthInBytes*/);
                {
                    this._state = state.Clone();
                }
                return this;
            }
            /*XxHash128 */ Clone()
            {
                return new $.$sih.System.IO.Hashing.XxHash128().$ctor$4(this._state.Clone());
            }
            static /*byte[] */ Hash(/*byte[]*/ source)
            {
                return $.$sih.System.IO.Hashing.XxHash128.Hash$1(source, 0n);
            }
            static /*byte[] */ Hash$1(/*byte[]*/ source, /*long*/ seed)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$sih.System.IO.Hashing.XxHash128.Hash$2(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2(source), seed);
            }
            static /*byte[] */ Hash$2(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                /*byte[]*/ let result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [16/*HashLengthInBytes*/], null);
                $.$sih.System.IO.Hashing.XxHash128.Hash$3(source, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(result), seed);
                return result;
            }
            static /*int */ Hash$3(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*long*/ seed)
            {
                /*int*/ let bytesWritten;
                if (!$.$sih.System.IO.Hashing.XxHash128.TryHash(source, destination, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32), seed))
                {
                    $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                return bytesWritten;
            }
            static /*bool */ TryHash(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesWritten, /*long*/ seed)
            {
                if (destination.Length >= (($.$spc.System.UInt64.$z * 2) | 0))
                {
                    /*Hash128*/ let hash = $.$sih.System.IO.Hashing.XxHash128.HashToHash128(source, seed);
                    $.$sih.System.IO.Hashing.XxHash128.WriteBigEndian128($.$ref(() => hash, ), destination);
                    bytesWritten.$v = 16/*HashLengthInBytes*/;
                    return true;
                }
                bytesWritten.$v = 0;
                return false;
            }
            static /*UInt128 */ HashToUInt128(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                /*Hash128*/ let hash = $.$sih.System.IO.Hashing.XxHash128.HashToHash128(source, seed);
                return new $.$spc.System.UInt128().$ctor$2(hash.High64, hash.Low64);
            }
            static /*Hash128 */ HashToHash128(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                /*uint*/ let length = (source.Length >>> 0);
                /*fixed*/ 
                {
                    /*byte**/ let sourcePtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, source);
                    if (length <= 16)
                    {
                        return $.$sih.System.IO.Hashing.XxHash128.HashLength0To16(sourcePtr, length, $.$cast(seed, $.$spc.System.UInt64));
                    }
                    if (length <= 128)
                    {
                        return $.$sih.System.IO.Hashing.XxHash128.HashLength17To128(sourcePtr, length, $.$cast(seed, $.$spc.System.UInt64));
                    }
                    if (length <= 240/*MidSizeMaxBytes*/)
                    {
                        return $.$sih.System.IO.Hashing.XxHash128.HashLength129To240(sourcePtr, length, $.$cast(seed, $.$spc.System.UInt64));
                    }
                    return $.$sih.System.IO.Hashing.XxHash128.HashLengthOver240(sourcePtr, length, $.$cast(seed, $.$spc.System.UInt64));
                }
            }
            /*void */ Reset()
            {
                $.$sih.System.IO.Hashing.XxHashShared.Reset($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sih.System.IO.Hashing.XxHashShared.State, () => this._state, ($v) => this._state = $v, null));
            }
            /*void */ Append(/*ReadOnlySpan<byte>*/ source)
            {
                $.$sih.System.IO.Hashing.XxHashShared.Append($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sih.System.IO.Hashing.XxHashShared.State, () => this._state, ($v) => this._state = $v, null), source);
            }
            /*void */ GetCurrentHashCore(/*Span<byte>*/ destination)
            {
                /*Hash128*/ let current = this.GetCurrentHashAsHash128();
                $.$sih.System.IO.Hashing.XxHash128.WriteBigEndian128($.$ref(() => current, ), destination);
            }
            /*Hash128 */ GetCurrentHashAsHash128()
            {
                /*Hash128*/ let current;
                if (this._state.TotalLength > BigInt(240/*MidSizeMaxBytes*/))
                {
                    /*ulong**/ let accumulators = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.UInt64, 8/*AccumulatorCount*/, null);
                    $.$sih.System.IO.Hashing.XxHashShared.CopyAccumulators($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sih.System.IO.Hashing.XxHashShared.State, () => this._state, ($v) => this._state = $v, null), accumulators);
                    /*fixed*/ 
                    {
                        /*byte**/ let secret = this._state.Secret;
                        $.$sih.System.IO.Hashing.XxHashShared.DigestLong($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sih.System.IO.Hashing.XxHashShared.State, () => this._state, ($v) => this._state = $v, null), accumulators, secret);
                        current = new $.$sih.System.IO.Hashing.XxHash128.Hash128().$ctor$2($.$sih.System.IO.Hashing.XxHashShared.MergeAccumulators(accumulators, secret.Add(11/*SecretMergeAccsStartBytes*/), this._state.TotalLength * 11400714785074694791n), $.$sih.System.IO.Hashing.XxHashShared.MergeAccumulators(accumulators, secret.Add(192/*SecretLengthBytes*/).Add(-((8/*AccumulatorCount*/ * $.$spc.System.UInt64.$z) | 0)).Add(-11/*SecretMergeAccsStartBytes*/), (~(this._state.TotalLength * 14029467366897019727n) & 0xFFFFFFFFFFFFFFFFn)));
                    }
                }
                else 
                {
                    /*fixed*/ 
                    {
                        /*byte**/ let buffer = this._state.Buffer;
                        current = $.$sih.System.IO.Hashing.XxHash128.HashToHash128(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$4(buffer, $.$cast(this._state.TotalLength, $.$spc.System.Int32)), $.$cast(this._state.Seed, $.$spc.System.Int64));
                    }
                }
                return current;
            }
            /*UInt128 */ GetCurrentHashAsUInt128()
            {
                /*Hash128*/ let current = this.GetCurrentHashAsHash128();
                return new $.$spc.System.UInt128().$ctor$2(current.High64, current.Low64);
            }
            static /*void */ WriteBigEndian128(/*in Hash128*/ hash, /*Span<byte>*/ destination)
            {
                /*ulong*/ let low = hash.$v.Low64;
                /*ulong*/ let high = hash.$v.High64;
                if ($.$spc.System.BitConverter.IsLittleEndian)
                {
                    low = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$10(low);
                    high = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$10(high);
                }
                /*ref byte*/ let dest0 = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, destination);
                $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.UInt64, dest0, high);
                $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.UInt64, $.$spc.System.Runtime.CompilerServices.Unsafe.AddByteOffset$1($.$spc.System.Byte, dest0, new $.$spc.System.IntPtr().$ctor$2($.$spc.System.UInt64.$z)), low);
            }
            static /*Hash128 */ HashLength0To16(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                if (length > 8)
                {
                    return $.$sih.System.IO.Hashing.XxHash128.HashLength9To16(source, length, seed);
                }
                if (length >= 4)
                {
                    return $.$sih.System.IO.Hashing.XxHash128.HashLength4To8(source, length, seed);
                }
                if (length !== 0)
                {
                    return $.$sih.System.IO.Hashing.XxHash128.HashLength1To3(source, length, seed);
                }
                /*ulong*/ let BitFlipL = 14627906620379768892n ^ 11758427054878871688n;
                /*ulong*/ let BitFlipH = 5690594596133299313n ^ 15613098826807580984n;
                return new $.$sih.System.IO.Hashing.XxHash128.Hash128().$ctor$2($.$sih.System.IO.Hashing.XxHash64.Avalanche(seed ^ BitFlipL), $.$sih.System.IO.Hashing.XxHash64.Avalanche(seed ^ BitFlipH));
            }
            static /*Hash128 */ HashLength1To3(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 1 && length <= 3, "length >= 1 && length <= 3");
                /*byte*/ let c1 = source.$v;
                /*byte*/ let c2 = source.GetAt(length >>> 1);
                /*byte*/ let c3 = source.GetAt(((length - 1) >>> 0));
                /*uint*/ let combinedl = ((c1 << 16) >>> 0) | ((c2 << 24) >>> 0) | c3 | ((length << 8) >>> 0);
                /*uint*/ let combinedh = $.$spc.System.Numerics.BitOperations.RotateLeft($.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$9(combinedl), 13);
                /*uint*/ let SecretXorL = ($.$cast(13712233961653862072n, $.$spc.System.UInt32) ^ $.$cast((13712233961653862072n >> 32n), $.$spc.System.UInt32));
                /*uint*/ let SecretXorH = ($.$cast(2066345149520216444n, $.$spc.System.UInt32) ^ $.$cast((2066345149520216444n >> 32n), $.$spc.System.UInt32));
                /*ulong*/ let bitflipl = BigInt(SecretXorL) + seed;
                /*ulong*/ let bitfliph = BigInt(SecretXorH) - seed;
                /*ulong*/ let keyedLo = BigInt(combinedl) ^ bitflipl;
                /*ulong*/ let keyedHi = BigInt(combinedh) ^ bitfliph;
                return new $.$sih.System.IO.Hashing.XxHash128.Hash128().$ctor$2($.$sih.System.IO.Hashing.XxHash64.Avalanche(keyedLo), $.$sih.System.IO.Hashing.XxHash64.Avalanche(keyedHi));
            }
            static /*Hash128 */ HashLength4To8(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 4 && length <= 8, "length >= 4 && length <= 8");
                seed ^= BigInt.asUintN(64, $.$cast($.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$9($.$cast(seed, $.$spc.System.UInt32)), $.$spc.System.UInt64) << 32n);
                /*uint*/ let inputLo = $.$sih.System.IO.Hashing.XxHashShared.ReadUInt32LE(source);
                /*uint*/ let inputHi = $.$sih.System.IO.Hashing.XxHashShared.ReadUInt32LE(source.Add(length).Add(-4));
                /*ulong*/ let input64 = BigInt(inputLo) + (BigInt.asUintN(64, $.$cast(inputHi, $.$spc.System.UInt64) << 32n));
                /*ulong*/ let bitflip = (15823274712020931806n ^ 2262974939099578482n) + seed;
                /*ulong*/ let keyed = input64 ^ bitflip;
                /*ulong*/ let m128Low;
                /*ulong*/ let m128High = $.$sih.System.IO.Hashing.XxHashShared.Multiply64To128(keyed, 11400714785074694791n + (BigInt((length << 2) >>> 0)), $.$ref(() => m128Low, ($v) => m128Low = $v, $.$spc.System.UInt64));
                m128High += (BigInt.asUintN(64, m128Low << 1n));
                m128Low ^= (m128High >> 3n);
                m128Low = $.$sih.System.IO.Hashing.XxHashShared.XorShift(m128Low, 35);
                m128Low *= 0x9FB21C651E98DF25n;
                m128Low = $.$sih.System.IO.Hashing.XxHashShared.XorShift(m128Low, 28);
                m128High = $.$sih.System.IO.Hashing.XxHashShared.Avalanche(m128High);
                return new $.$sih.System.IO.Hashing.XxHash128.Hash128().$ctor$2(m128Low, m128High);
            }
            static /*Hash128 */ HashLength9To16(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 9 && length <= 16, "length >= 9 && length <= 16");
                /*ulong*/ let bitflipl = (8711581037947681227n ^ 2410270004345854594n) - seed;
                /*ulong*/ let bitfliph = (10242386182634080440n ^ 5487137525590930912n) + seed;
                /*ulong*/ let inputLo = $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(source);
                /*ulong*/ let inputHi = $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(source.Add(length).Add(-8));
                /*ulong*/ let m128Low;
                /*ulong*/ let m128High = $.$sih.System.IO.Hashing.XxHashShared.Multiply64To128(inputLo ^ inputHi ^ bitflipl, 11400714785074694791n, $.$ref(() => m128Low, ($v) => m128Low = $v, $.$spc.System.UInt64));
                m128Low += BigInt.asUintN(64, $.$cast((((length - 1) >>> 0)), $.$spc.System.UInt64) << 54n);
                inputHi ^= bitfliph;
                m128High += $.$typePointer($.$spc.System.Void).$z < $.$spc.System.UInt64.$z ? (inputHi & 0xFFFFFFFF00000000n) + $.$sih.System.IO.Hashing.XxHashShared.Multiply32To64($.$cast(inputHi, $.$spc.System.UInt32), 2246822519/*Prime32_2*/) : inputHi + $.$sih.System.IO.Hashing.XxHashShared.Multiply32To64($.$cast(inputHi, $.$spc.System.UInt32), ((2246822519/*Prime32_2*/ - 1) >>> 0));
                m128Low ^= $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$10(m128High);
                /*ulong*/ let h128Low;
                /*ulong*/ let h128High = $.$sih.System.IO.Hashing.XxHashShared.Multiply64To128(m128Low, 14029467366897019727n, $.$ref(() => h128Low, ($v) => h128Low = $v, $.$spc.System.UInt64));
                h128High += m128High * 14029467366897019727n;
                h128Low = $.$sih.System.IO.Hashing.XxHashShared.Avalanche(h128Low);
                h128High = $.$sih.System.IO.Hashing.XxHashShared.Avalanche(h128High);
                return new $.$sih.System.IO.Hashing.XxHash128.Hash128().$ctor$2(h128Low, h128High);
            }
            static /*Hash128 */ HashLength17To128(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 17 && length <= 128, "length >= 17 && length <= 128");
                /*ulong*/ let accLow = BigInt(length) * 11400714785074694791n;
                /*ulong*/ let accHigh = 0n;
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    let $switch1 = $switchJumpState1 ?? ($.trunc((((length - 1) >>> 0)) / 32));
                    switch($switch1)
                    {
                        default:
                        $.$sih.System.IO.Hashing.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$spc.System.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$spc.System.UInt64), source.Add(48), source.Add(length).Add(-64), 4554437623014685352n, 2111919702937427193n, 3556072174620004746n, 7238261902898274248n, seed);
                        $switchJumpState1 = 2; /*goto case 2*/
                        continue $switchJumpStart1;
                        case 2:
                        $.$sih.System.IO.Hashing.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$spc.System.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$spc.System.UInt64), source.Add(32), source.Add(length).Add(-48), 14627906620379768892n, 11758427054878871688n, 5690594596133299313n, 15613098826807580984n, seed);
                        $switchJumpState1 = 1; /*goto case 1*/
                        continue $switchJumpStart1;
                        case 1:
                        $.$sih.System.IO.Hashing.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$spc.System.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$spc.System.UInt64), source.Add(16), source.Add(length).Add(-32), 8711581037947681227n, 2410270004345854594n, 10242386182634080440n, 5487137525590930912n, seed);
                        $switchJumpState1 = 0; /*goto case 0*/
                        continue $switchJumpStart1;
                        case 0:
                        $.$sih.System.IO.Hashing.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$spc.System.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$spc.System.UInt64), source, source.Add(length).Add(-16), 13712233961653862072n, 2066345149520216444n, 15823274712020931806n, 2262974939099578482n, seed);
                        break;
                    }
                    break;
                }
                return $.$sih.System.IO.Hashing.XxHash128.AvalancheHash(accLow, accHigh, length, seed);
            }
            static /*Hash128 */ HashLength129To240(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 129 && length <= 240, "length >= 129 && length <= 240");
                /*ulong*/ let accLow = BigInt(length) * 11400714785074694791n;
                /*ulong*/ let accHigh = 0n;
                $.$sih.System.IO.Hashing.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$spc.System.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$spc.System.UInt64), source.Add((((32 * 0) | 0))), source.Add((((32 * 0) | 0))).Add(16), 13712233961653862072n, 2066345149520216444n, 15823274712020931806n, 2262974939099578482n, seed);
                $.$sih.System.IO.Hashing.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$spc.System.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$spc.System.UInt64), source.Add((((32 * 1) | 0))), source.Add((((32 * 1) | 0))).Add(16), 8711581037947681227n, 2410270004345854594n, 10242386182634080440n, 5487137525590930912n, seed);
                $.$sih.System.IO.Hashing.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$spc.System.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$spc.System.UInt64), source.Add((((32 * 2) | 0))), source.Add((((32 * 2) | 0))).Add(16), 14627906620379768892n, 11758427054878871688n, 5690594596133299313n, 15613098826807580984n, seed);
                $.$sih.System.IO.Hashing.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$spc.System.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$spc.System.UInt64), source.Add((((32 * 3) | 0))), source.Add((((32 * 3) | 0))).Add(16), 4554437623014685352n, 2111919702937427193n, 3556072174620004746n, 7238261902898274248n, seed);
                accLow = $.$sih.System.IO.Hashing.XxHashShared.Avalanche(accLow);
                accHigh = $.$sih.System.IO.Hashing.XxHashShared.Avalanche(accHigh);
                /*uint*/ let bound = ($.trunc((length - (((32 * 4) | 0))) / 32));
                if (bound !== 0)
                {
                    $.$sih.System.IO.Hashing.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$spc.System.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$spc.System.UInt64), source.Add((((32 * 4) | 0))), source.Add((((32 * 4) | 0))).Add(16), 9295848262624092985n, 7914194659941938988n, 11835586108195898345n, 16607528436649670564n, seed);
                    if (bound >= 2)
                    {
                        $.$sih.System.IO.Hashing.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$spc.System.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$spc.System.UInt64), source.Add((((32 * 5) | 0))), source.Add((((32 * 5) | 0))).Add(16), 15013455763555273806n, 5046485836271438973n, 10391458616325699444n, 5920048007935066598n, seed);
                        if (bound === 3)
                        {
                            $.$sih.System.IO.Hashing.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$spc.System.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$spc.System.UInt64), source.Add((((32 * 6) | 0))), source.Add((((32 * 6) | 0))).Add(16), 7336514198459093435n, 5216419214072683403n, 17228863761319568023n, 8573350489219836230n, seed);
                        }
                    }
                }
                $.$sih.System.IO.Hashing.XxHash128.Mix32Bytes($.$ref(() => accLow, ($v) => accLow = $v, $.$spc.System.UInt64), $.$ref(() => accHigh, ($v) => accHigh = $v, $.$spc.System.UInt64), source.Add(length).Add(-16), source.Add(length).Add(-32), 5695865814404364607n, 6464017090953185821n, 8320639771003045937n, 16992983559143025252n, 0n - seed);
                return $.$sih.System.IO.Hashing.XxHash128.AvalancheHash(accLow, accHigh, length, seed);
            }
            static /*Hash128 */ HashLengthOver240(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length > 240, "length > 240");
                /*fixed*/ 
                {
                    /*byte**/ let defaultSecret = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, $.$sih.System.IO.Hashing.XxHashShared.DefaultSecret);
                    /*byte**/ let secret = defaultSecret;
                    if (seed !== 0n)
                    {
                        /*byte**/ let customSecret = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.Byte, 192/*SecretLengthBytes*/, null);
                        $.$sih.System.IO.Hashing.XxHashShared.DeriveSecretFromSeed(customSecret, seed);
                        secret = customSecret;
                    }
                    /*ulong**/ let accumulators = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.UInt64, 8/*AccumulatorCount*/, null);
                    $.$sih.System.IO.Hashing.XxHashShared.InitializeAccumulators(accumulators);
                    $.$sih.System.IO.Hashing.XxHashShared.HashInternalLoop(accumulators, source, length, secret);
                    return new $.$sih.System.IO.Hashing.XxHash128.Hash128().$ctor$2($.$sih.System.IO.Hashing.XxHashShared.MergeAccumulators(accumulators, secret.Add(11/*SecretMergeAccsStartBytes*/), BigInt(length) * 11400714785074694791n), $.$sih.System.IO.Hashing.XxHashShared.MergeAccumulators(accumulators, secret.Add(192/*SecretLengthBytes*/).Add(-((8/*AccumulatorCount*/ * $.$spc.System.UInt64.$z) | 0)).Add(-11/*SecretMergeAccsStartBytes*/), (~(BigInt(length) * 14029467366897019727n) & 0xFFFFFFFFFFFFFFFFn)));
                }
            }
            static /*Hash128 */ AvalancheHash(/*ulong*/ accLow, /*ulong*/ accHigh, /*uint*/ length, /*ulong*/ seed)
            {
                /*ulong*/ let h128Low = accLow + accHigh;
                /*ulong*/ let h128High = (accLow * 11400714785074694791n) + (accHigh * 9650029242287828579n) + ((BigInt(length) - seed) * 14029467366897019727n);
                h128Low = $.$sih.System.IO.Hashing.XxHashShared.Avalanche(h128Low);
                h128High = 0n - $.$sih.System.IO.Hashing.XxHashShared.Avalanche(h128High);
                return new $.$sih.System.IO.Hashing.XxHash128.Hash128().$ctor$2(h128Low, h128High);
            }
            static /*void */ Mix32Bytes(/*ref ulong*/ accLow, /*ref ulong*/ accHigh, /*byte**/ input1, /*byte**/ input2, /*ulong*/ secret1, /*ulong*/ secret2, /*ulong*/ secret3, /*ulong*/ secret4, /*ulong*/ seed)
            {
                accLow.$v += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(input1, secret1, secret2, seed);
                accLow.$v ^= $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(input2) + $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(input2.Add(8));
                accHigh.$v += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(input2, secret3, secret4, seed);
                accHigh.$v ^= $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(input1) + $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(input1.Add(8));
            }
            static $_Hash128;
            static get Hash128()
            {
                let $cls = $.$sih.System.IO.Hashing.XxHash128;
                return $cls.$_Hash128 ??= $asm.$nstr("$sih.System.IO.Hashing.XxHash128.Hash128", ($self) => class Hash128 extends $.$spc.System.ValueType
                {
                    /*ulong*/  get Low64() { return this.$getField(0, $.$spc.System.UInt64); }
                    /*ulong*/  set Low64(value) { this.$setField(0, $.$spc.System.UInt64, value); }
                    /*ulong*/  get High64() { return this.$getField(8, $.$spc.System.UInt64); }
                    /*ulong*/  set High64(value) { this.$setField(8, $.$spc.System.UInt64, value); }
                    $ctor$2(/*ulong*/ low64, /*ulong*/ high64)
                    {
                        super.$ctor$1();
                        {
                            this.Low64 = low64;
                            this.High64 = high64;
                        }
                        return this;
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Low64 = this.Low64;
                        copy.High64 = this.High64;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Low64 = 0n;
                        this.High64 = 0n;
                    }
                    static $h = 491863;
                    static $z = 16;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":983041,"n":"Low64","d":491863,"h":4295459159,"f":1},{"t":983041,"n":"High64","d":491863,"h":8590426455,"f":1}],"c":[{"p":[{"n":"low64","p":983041},{"n":"high64","p":983041}],"n":".ctor","o":"$ctor$2","d":491863,"h":12885393751,"f":1},{"n":".ctor","o":"$ctor$3","d":491863,"h":17180361047,"f":1}],"d":426327,"h":491863,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Low64 = {Low64}, High64 = {High64}","t":1310721}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.IO.Hashing.XxHash128.Hash128`; }
                }, $cls, ($v) => $cls.$_Hash128 = $v);
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = $.$default($.$sih.System.IO.Hashing.XxHashShared.State);
            }
            static $h = 426327;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":229719,"m":[{"r":426327,"n":"Clone","d":426327,"h":25770230103,"f":1},{"r":0,"p":[{"n":"source","p":0}],"n":"Hash","d":426327,"h":30065197399,"f":33},{"r":0,"p":[{"n":"source","p":0},{"n":"seed","p":917505}],"n":"Hash","o":"@$1","d":426327,"h":34360164695,"f":33},{"r":0,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"seed","p":917505,"f":65,"v":0}],"n":"Hash","o":"@$2","d":426327,"h":38655131991,"f":33},{"r":655361,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"seed","p":917505,"f":65,"v":0}],"n":"Hash","o":"@$3","d":426327,"h":42950099287,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2},{"n":"seed","p":917505,"f":65,"v":0}],"n":"TryHash","d":426327,"h":47245066583,"f":33},{"r":143785985,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"seed","p":917505,"f":65,"v":0}],"n":"HashToUInt128","d":426327,"h":51540033879,"f":33,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":491863,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"seed","p":917505,"f":65,"v":0}],"n":"HashToHash128","d":426327,"h":55835001175,"f":34},{"r":65537,"n":"Reset","d":426327,"h":60129968471,"f":32769},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Append","d":426327,"h":64424935767,"f":32769},{"r":65537,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetCurrentHashCore","d":426327,"h":68719903063,"f":32772},{"r":491863,"n":"GetCurrentHashAsHash128","d":426327,"h":73014870359,"f":2},{"r":143785985,"n":"GetCurrentHashAsUInt128","d":426327,"h":77309837655,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"hash","p":491863,"f":8},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"WriteBigEndian128","d":426327,"h":81604804951,"f":34},{"r":491863,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLength0To16","d":426327,"h":85899772247,"f":34},{"r":491863,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLength1To3","d":426327,"h":90194739543,"f":34},{"r":491863,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLength4To8","d":426327,"h":94489706839,"f":34},{"r":491863,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLength9To16","d":426327,"h":98784674135,"f":34},{"r":491863,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLength17To128","d":426327,"h":103079641431,"f":34},{"r":491863,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLength129To240","d":426327,"h":107374608727,"f":34},{"r":491863,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLengthOver240","d":426327,"h":111669576023,"f":34},{"r":491863,"p":[{"n":"accLow","p":983041},{"n":"accHigh","p":983041},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"AvalancheHash","d":426327,"h":115964543319,"f":34},{"r":65537,"p":[{"n":"accLow","p":983041,"f":4},{"n":"accHigh","p":983041,"f":4},{"n":"input1","p":0},{"n":"input2","p":0},{"n":"secret1","p":983041},{"n":"secret2","p":983041},{"n":"secret3","p":983041},{"n":"secret4","p":983041},{"n":"seed","p":983041}],"n":"Mix32Bytes","d":426327,"h":120259510615,"f":34}],"l":[{"t":655361,"n":"HashLengthInBytes","d":426327,"h":4295393623,"f":34},{"t":950615,"n":"_state","d":426327,"h":8590360919,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":426327,"h":12885328215,"f":1},{"p":[{"n":"seed","p":917505}],"n":".ctor","o":"$ctor$3","d":426327,"h":17180295511,"f":1},{"p":[{"n":"state","p":950615}],"n":".ctor","o":"$ctor$4","d":426327,"h":21475262807,"f":2}],"j":[491863],"h":426327,"a":[{"t":95485953,"c":4390453249}]}; }
            static get $b() { return $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm; }
            static get $fullName() { return `System.IO.Hashing.XxHash128`; }
        });
        
        $asm.$cls("$sih.System.IO.Hashing.XxHash3", ($self) => class XxHash3 extends $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm
        {
            /*int*/ static HashLengthInBytes = 8;
            /*State*/ _state;
            $ctor$2()
            {
                this.$ctor$3(0n);
                {
                }
                return this;
            }
            $ctor$3(/*long*/ seed)
            {
                super.$ctor$1(8/*HashLengthInBytes*/);
                {
                    $.$sih.System.IO.Hashing.XxHashShared.Initialize($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sih.System.IO.Hashing.XxHashShared.State, () => this._state, ($v) => this._state = $v, null), $.$cast(seed, $.$spc.System.UInt64));
                }
                return this;
            }
            $ctor$4(/*State*/ state)
            {
                super.$ctor$1(8/*HashLengthInBytes*/);
                {
                    this._state = state.Clone();
                }
                return this;
            }
            /*XxHash3 */ Clone()
            {
                return new $.$sih.System.IO.Hashing.XxHash3().$ctor$4(this._state.Clone());
            }
            static /*byte[] */ Hash(/*byte[]*/ source)
            {
                return $.$sih.System.IO.Hashing.XxHash3.Hash$1(source, 0n);
            }
            static /*byte[] */ Hash$1(/*byte[]*/ source, /*long*/ seed)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$sih.System.IO.Hashing.XxHash3.Hash$2(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2(source), seed);
            }
            static /*byte[] */ Hash$2(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                /*byte[]*/ let result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [8/*HashLengthInBytes*/], null);
                /*ulong*/ let hash = $.$sih.System.IO.Hashing.XxHash3.HashToUInt64(source, seed);
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt64BigEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(result), hash);
                return result;
            }
            static /*int */ Hash$3(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*long*/ seed)
            {
                /*int*/ let bytesWritten;
                if (!$.$sih.System.IO.Hashing.XxHash3.TryHash(source, destination, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32), seed))
                {
                    $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm.ThrowDestinationTooShort();
                }
                return bytesWritten;
            }
            static /*bool */ TryHash(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*out int*/ bytesWritten, /*long*/ seed)
            {
                if (destination.Length >= $.$spc.System.Int64.$z)
                {
                    /*ulong*/ let hash = $.$sih.System.IO.Hashing.XxHash3.HashToUInt64(source, seed);
                    if ($.$spc.System.BitConverter.IsLittleEndian)
                    {
                        hash = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$10(hash);
                    }
                    $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.UInt64, $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, destination), hash);
                    bytesWritten.$v = 8/*HashLengthInBytes*/;
                    return true;
                }
                bytesWritten.$v = 0;
                return false;
            }
            static /*ulong */ HashToUInt64(/*ReadOnlySpan<byte>*/ source, /*long*/ seed)
            {
                /*uint*/ let length = (source.Length >>> 0);
                /*fixed*/ 
                {
                    /*byte**/ let sourcePtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, source);
                    if (length <= 16)
                    {
                        return $.$sih.System.IO.Hashing.XxHash3.HashLength0To16(sourcePtr, length, $.$cast(seed, $.$spc.System.UInt64));
                    }
                    if (length <= 128)
                    {
                        return $.$sih.System.IO.Hashing.XxHash3.HashLength17To128(sourcePtr, length, $.$cast(seed, $.$spc.System.UInt64));
                    }
                    if (length <= 240/*MidSizeMaxBytes*/)
                    {
                        return $.$sih.System.IO.Hashing.XxHash3.HashLength129To240(sourcePtr, length, $.$cast(seed, $.$spc.System.UInt64));
                    }
                    return $.$sih.System.IO.Hashing.XxHash3.HashLengthOver240(sourcePtr, length, $.$cast(seed, $.$spc.System.UInt64));
                }
            }
            /*void */ Reset()
            {
                $.$sih.System.IO.Hashing.XxHashShared.Reset($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sih.System.IO.Hashing.XxHashShared.State, () => this._state, ($v) => this._state = $v, null));
            }
            /*void */ Append(/*ReadOnlySpan<byte>*/ source)
            {
                $.$sih.System.IO.Hashing.XxHashShared.Append($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sih.System.IO.Hashing.XxHashShared.State, () => this._state, ($v) => this._state = $v, null), source);
            }
            /*void */ GetCurrentHashCore(/*Span<byte>*/ destination)
            {
                /*ulong*/ let hash = this.GetCurrentHashAsUInt64();
                $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt64BigEndian(destination, hash);
            }
            /*ulong */ GetCurrentHashAsUInt64()
            {
                /*ulong*/ let current;
                if (this._state.TotalLength > BigInt(240/*MidSizeMaxBytes*/))
                {
                    /*ulong**/ let accumulators = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.UInt64, 8/*AccumulatorCount*/, null);
                    $.$sih.System.IO.Hashing.XxHashShared.CopyAccumulators($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sih.System.IO.Hashing.XxHashShared.State, () => this._state, ($v) => this._state = $v, null), accumulators);
                    /*fixed*/ 
                    {
                        /*byte**/ let secret = this._state.Secret;
                        $.$sih.System.IO.Hashing.XxHashShared.DigestLong($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sih.System.IO.Hashing.XxHashShared.State, () => this._state, ($v) => this._state = $v, null), accumulators, secret);
                        current = $.$sih.System.IO.Hashing.XxHashShared.MergeAccumulators(accumulators, secret.Add(11/*SecretMergeAccsStartBytes*/), this._state.TotalLength * 11400714785074694791n);
                    }
                }
                else 
                {
                    /*fixed*/ 
                    {
                        /*byte**/ let buffer = this._state.Buffer;
                        current = $.$sih.System.IO.Hashing.XxHash3.HashToUInt64(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$4(buffer, $.$cast(this._state.TotalLength, $.$spc.System.Int32)), $.$cast(this._state.Seed, $.$spc.System.Int64));
                    }
                }
                return current;
            }
            static /*ulong */ HashLength0To16(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                if (length > 8)
                {
                    return $.$sih.System.IO.Hashing.XxHash3.HashLength9To16(source, length, seed);
                }
                if (length >= 4)
                {
                    return $.$sih.System.IO.Hashing.XxHash3.HashLength4To8(source, length, seed);
                }
                if (length !== 0)
                {
                    return $.$sih.System.IO.Hashing.XxHash3.HashLength1To3(source, length, seed);
                }
                /*ulong*/ let SecretXor = 5487137525590930912n ^ 14627906620379768892n;
                return $.$sih.System.IO.Hashing.XxHash64.Avalanche(seed ^ SecretXor);
            }
            static /*ulong */ HashLength1To3(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 1 && length <= 3, "length >= 1 && length <= 3");
                /*byte*/ let c1 = source.$v;
                /*byte*/ let c2 = source.GetAt(length >>> 1);
                /*byte*/ let c3 = source.GetAt(((length - 1) >>> 0));
                /*uint*/ let combined = ((c1 << 16) >>> 0) | ((c2 << 24) >>> 0) | c3 | ((length << 8) >>> 0);
                /*uint*/ let SecretXor = $.$cast(13712233961653862072n, $.$spc.System.UInt32) ^ $.$cast((13712233961653862072n >> 32n), $.$spc.System.UInt32);
                return $.$sih.System.IO.Hashing.XxHash64.Avalanche(BigInt(combined) ^ (BigInt(SecretXor) + seed));
            }
            static /*ulong */ HashLength4To8(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 4 && length <= 8, "length >= 4 && length <= 8");
                seed ^= BigInt.asUintN(64, $.$cast($.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$9($.$cast(seed, $.$spc.System.UInt32)), $.$spc.System.UInt64) << 32n);
                /*uint*/ let inputLow = $.$sih.System.IO.Hashing.XxHashShared.ReadUInt32LE(source);
                /*uint*/ let inputHigh = $.$sih.System.IO.Hashing.XxHashShared.ReadUInt32LE(source.Add(length).Add(-$.$spc.System.UInt32.$z));
                /*ulong*/ let SecretXor = 2066345149520216444n ^ 15823274712020931806n;
                /*ulong*/ let bitflip = SecretXor - seed;
                /*ulong*/ let input64 = BigInt(inputHigh) + (BigInt.asUintN(64, ($.$cast(inputLow, $.$spc.System.UInt64)) << 32n));
                return $.$sih.System.IO.Hashing.XxHashShared.Rrmxmx(input64 ^ bitflip, length);
            }
            static /*ulong */ HashLength9To16(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 9 && length <= 16, "length >= 9 && length <= 16");
                /*ulong*/ let SecretXorL = 2262974939099578482n ^ 8711581037947681227n;
                /*ulong*/ let SecretXorR = 2410270004345854594n ^ 10242386182634080440n;
                /*ulong*/ let bitflipLow = SecretXorL + seed;
                /*ulong*/ let bitflipHigh = SecretXorR - seed;
                /*ulong*/ let inputLow = $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(source) ^ bitflipLow;
                /*ulong*/ let inputHigh = $.$sih.System.IO.Hashing.XxHashShared.ReadUInt64LE(source.Add(length).Add(-$.$spc.System.UInt64.$z)) ^ bitflipHigh;
                return $.$sih.System.IO.Hashing.XxHashShared.Avalanche(BigInt(length) + $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$10(inputLow) + inputHigh + $.$sih.System.IO.Hashing.XxHashShared.Multiply64To128ThenFold(inputLow, inputHigh));
            }
            static /*ulong */ HashLength17To128(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 17 && length <= 128, "length >= 17 && length <= 128");
                /*ulong*/ let hash = BigInt(length) * 11400714785074694791n;
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    let $switch1 = $switchJumpState1 ?? ($.trunc((((length - 1) >>> 0)) / 32));
                    switch($switch1)
                    {
                        default:
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add(48), 4554437623014685352n, 2111919702937427193n, seed);
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add(length).Add(-64), 3556072174620004746n, 7238261902898274248n, seed);
                        $switchJumpState1 = 2; /*goto case 2*/
                        continue $switchJumpStart1;
                        case 2:
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add(32), 14627906620379768892n, 11758427054878871688n, seed);
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add(length).Add(-48), 5690594596133299313n, 15613098826807580984n, seed);
                        $switchJumpState1 = 1; /*goto case 1*/
                        continue $switchJumpStart1;
                        case 1:
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add(16), 8711581037947681227n, 2410270004345854594n, seed);
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add(length).Add(-32), 10242386182634080440n, 5487137525590930912n, seed);
                        $switchJumpState1 = 0; /*goto case 0*/
                        continue $switchJumpStart1;
                        case 0:
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source, 13712233961653862072n, 2066345149520216444n, seed);
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add(length).Add(-16), 15823274712020931806n, 2262974939099578482n, seed);
                        break;
                    }
                    break;
                }
                return $.$sih.System.IO.Hashing.XxHashShared.Avalanche(hash);
            }
            static /*ulong */ HashLength129To240(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length >= 129 && length <= 240, "length >= 129 && length <= 240");
                /*ulong*/ let hash = BigInt(length) * 11400714785074694791n;
                hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 0) | 0))), 13712233961653862072n, 2066345149520216444n, seed);
                hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 1) | 0))), 15823274712020931806n, 2262974939099578482n, seed);
                hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 2) | 0))), 8711581037947681227n, 2410270004345854594n, seed);
                hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 3) | 0))), 10242386182634080440n, 5487137525590930912n, seed);
                hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 4) | 0))), 14627906620379768892n, 11758427054878871688n, seed);
                hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 5) | 0))), 5690594596133299313n, 15613098826807580984n, seed);
                hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 6) | 0))), 4554437623014685352n, 2111919702937427193n, seed);
                hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 7) | 0))), 3556072174620004746n, 7238261902898274248n, seed);
                hash = $.$sih.System.IO.Hashing.XxHashShared.Avalanche(hash);
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    let $switch1 = $switchJumpState1 ?? ($.trunc((length - (((16 * 8) | 0))) / 16));
                    switch($switch1)
                    {
                        default:
                        $.$spc.System.Diagnostics.Debug.Assert$1(($.trunc((length - ((16 * 8) | 0)) / 16) >>> 0) == 7, "(length - 16 * 8) / 16 == 7");
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 14) | 0))), 13536968629829821247n, 16163852396094277575n, seed);
                        $switchJumpState1 = 6; /*goto case 6*/
                        continue $switchJumpStart1;
                        case 6:
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 13) | 0))), 17228863761319568023n, 8573350489219836230n, seed);
                        $switchJumpState1 = 5; /*goto case 5*/
                        continue $switchJumpStart1;
                        case 5:
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 12) | 0))), 7336514198459093435n, 5216419214072683403n, seed);
                        $switchJumpState1 = 4; /*goto case 4*/
                        continue $switchJumpStart1;
                        case 4:
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 11) | 0))), 10391458616325699444n, 5920048007935066598n, seed);
                        $switchJumpState1 = 3; /*goto case 3*/
                        continue $switchJumpStart1;
                        case 3:
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 10) | 0))), 15013455763555273806n, 5046485836271438973n, seed);
                        $switchJumpState1 = 2; /*goto case 2*/
                        continue $switchJumpStart1;
                        case 2:
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 9) | 0))), 11835586108195898345n, 16607528436649670564n, seed);
                        $switchJumpState1 = 1; /*goto case 1*/
                        continue $switchJumpStart1;
                        case 1:
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add((((16 * 8) | 0))), 9295848262624092985n, 7914194659941938988n, seed);
                        $switchJumpState1 = 0; /*goto case 0*/
                        continue $switchJumpStart1;
                        case 0:
                        hash += $.$sih.System.IO.Hashing.XxHashShared.Mix16Bytes(source.Add(length).Add(-16), 8320639771003045937n, 16992983559143025252n, seed);
                        break;
                    }
                    break;
                }
                return $.$sih.System.IO.Hashing.XxHashShared.Avalanche(hash);
            }
            static /*ulong */ HashLengthOver240(/*byte**/ source, /*uint*/ length, /*ulong*/ seed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(length > 240, "length > 240");
                /*fixed*/ 
                {
                    /*byte**/ let defaultSecret = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, $.$sih.System.IO.Hashing.XxHashShared.DefaultSecret);
                    /*byte**/ let secret = defaultSecret;
                    if (seed !== 0n)
                    {
                        /*byte**/ let customSecret = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.Byte, 192/*SecretLengthBytes*/, null);
                        $.$sih.System.IO.Hashing.XxHashShared.DeriveSecretFromSeed(customSecret, seed);
                        secret = customSecret;
                    }
                    /*ulong**/ let accumulators = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.UInt64, 8/*AccumulatorCount*/, null);
                    $.$sih.System.IO.Hashing.XxHashShared.InitializeAccumulators(accumulators);
                    $.$sih.System.IO.Hashing.XxHashShared.HashInternalLoop(accumulators, source, length, secret);
                    return $.$sih.System.IO.Hashing.XxHashShared.MergeAccumulators(accumulators, secret.Add(11), BigInt(length) * 11400714785074694791n);
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = $.$default($.$sih.System.IO.Hashing.XxHashShared.State);
            }
            static $h = 557399;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":229719,"m":[{"r":557399,"n":"Clone","d":557399,"h":25770361175,"f":1},{"r":0,"p":[{"n":"source","p":0}],"n":"Hash","d":557399,"h":30065328471,"f":33},{"r":0,"p":[{"n":"source","p":0},{"n":"seed","p":917505}],"n":"Hash","o":"@$1","d":557399,"h":34360295767,"f":33},{"r":0,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"seed","p":917505,"f":65,"v":0}],"n":"Hash","o":"@$2","d":557399,"h":38655263063,"f":33},{"r":655361,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"seed","p":917505,"f":65,"v":0}],"n":"Hash","o":"@$3","d":557399,"h":42950230359,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2},{"n":"seed","p":917505,"f":65,"v":0}],"n":"TryHash","d":557399,"h":47245197655,"f":33},{"r":983041,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"seed","p":917505,"f":65,"v":0}],"n":"HashToUInt64","d":557399,"h":51540164951,"f":33,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":65537,"n":"Reset","d":557399,"h":55835132247,"f":32769},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Append","d":557399,"h":60130099543,"f":32769},{"r":65537,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"GetCurrentHashCore","d":557399,"h":64425066839,"f":32772},{"r":983041,"n":"GetCurrentHashAsUInt64","d":557399,"h":68720034135,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"r":983041,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLength0To16","d":557399,"h":73015001431,"f":34},{"r":983041,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLength1To3","d":557399,"h":77309968727,"f":34},{"r":983041,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLength4To8","d":557399,"h":81604936023,"f":34},{"r":983041,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLength9To16","d":557399,"h":85899903319,"f":34},{"r":983041,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLength17To128","d":557399,"h":90194870615,"f":34},{"r":983041,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLength129To240","d":557399,"h":94489837911,"f":34},{"r":983041,"p":[{"n":"source","p":0},{"n":"length","p":720897},{"n":"seed","p":983041}],"n":"HashLengthOver240","d":557399,"h":98784805207,"f":34}],"l":[{"t":655361,"n":"HashLengthInBytes","d":557399,"h":4295524695,"f":34},{"t":950615,"n":"_state","d":557399,"h":8590491991,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":557399,"h":12885459287,"f":1},{"p":[{"n":"seed","p":917505}],"n":".ctor","o":"$ctor$3","d":557399,"h":17180426583,"f":1},{"p":[{"n":"state","p":950615}],"n":".ctor","o":"$ctor$4","d":557399,"h":21475393879,"f":2}],"h":557399,"a":[{"t":95485953,"c":4390453249}]}; }
            static get $b() { return $.$sih.System.IO.Hashing.NonCryptographicHashAlgorithm; }
            static get $fullName() { return `System.IO.Hashing.XxHash3`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory"))