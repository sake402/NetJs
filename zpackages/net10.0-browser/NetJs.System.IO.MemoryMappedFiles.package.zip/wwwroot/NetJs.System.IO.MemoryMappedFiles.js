
//--TRIMMABLE-BOUNDARY-START(31)
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $stt) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.MemoryMappedFiles", 
    {
  "h": 31,
  "f": "System.IO.MemoryMappedFiles",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 127533057,
      "c": 4422500353
    },
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.IO.MemoryMappedFiles",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.IO.MemoryMappedFiles",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1703967)
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.Nop", ($self) => class Nop extends $.$$.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1703967;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671263),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1703967,
      "h": 4296671263,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296671263)
  ],
  "h": 1703967
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.Nop`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703967)
        
        
        //--TRIMMABLE-BOUNDARY-START(65567)
        $asm.$cls("$sim.Interop", ($self) => class Interop
        {
            //--TRIMMABLE-BOUNDARY-START(262175)
            static $_Libraries;
            static get Libraries()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_Libraries ??= $asm.$ncls("$sim.Interop.Libraries", ($self) => class Libraries
                {
                    //--TRIMMABLE-BOUNDARY-START(25770065951)
                    /*string*/ static libc = null;
                    //--TRIMMABLE-BOUNDARY-END(25770065951)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360000543)
                    /*string*/ static SystemNative = null;
                    //--TRIMMABLE-BOUNDARY-END(34360000543)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065033247)
                    /*string*/ static NetSecurityNative = null;
                    //--TRIMMABLE-BOUNDARY-END(30065033247)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590196767)
                    /*string*/ static CryptoNative = null;
                    //--TRIMMABLE-BOUNDARY-END(8590196767)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295229471)
                    /*string*/ static CompressionNative = null;
                    //--TRIMMABLE-BOUNDARY-END(4295229471)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885164063)
                    /*string*/ static GlobalizationNative = null;
                    //--TRIMMABLE-BOUNDARY-END(12885164063)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475098655)
                    /*string*/ static IOPortsNative = null;
                    //--TRIMMABLE-BOUNDARY-END(21475098655)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180131359)
                    /*string*/ static HostPolicy = null;
                    //--TRIMMABLE-BOUNDARY-END(17180131359)
                    
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(25770065951)
                            this.libc = "libc";
                            //--TRIMMABLE-BOUNDARY-END(25770065951)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(34360000543)
                            this.SystemNative = "libSystem.Native";
                            //--TRIMMABLE-BOUNDARY-END(34360000543)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(30065033247)
                            this.NetSecurityNative = "libSystem.Net.Security.Native";
                            //--TRIMMABLE-BOUNDARY-END(30065033247)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(8590196767)
                            this.CryptoNative = "libSystem.Security.Cryptography.Native.OpenSsl";
                            //--TRIMMABLE-BOUNDARY-END(8590196767)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(4295229471)
                            this.CompressionNative = "libSystem.IO.Compression.Native";
                            //--TRIMMABLE-BOUNDARY-END(4295229471)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12885164063)
                            this.GlobalizationNative = "libSystem.Globalization.Native";
                            //--TRIMMABLE-BOUNDARY-END(12885164063)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(21475098655)
                            this.IOPortsNative = "libSystem.IO.Ports.Native";
                            //--TRIMMABLE-BOUNDARY-END(21475098655)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(17180131359)
                            this.HostPolicy = "libhostpolicy";
                            //--TRIMMABLE-BOUNDARY-END(17180131359)
                            
                        }
                    }
                    static $h = 262175;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770065951),
    {
      "t": 1310721,
      "n": "libc",
      "d": 262175,
      "h": 25770065951,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770065951),
//--TRIMMABLE-BOUNDARY-START(34360000543),
    {
      "t": 1310721,
      "n": "SystemNative",
      "d": 262175,
      "h": 34360000543,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360000543),
//--TRIMMABLE-BOUNDARY-START(30065033247),
    {
      "t": 1310721,
      "n": "NetSecurityNative",
      "d": 262175,
      "h": 30065033247,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065033247),
//--TRIMMABLE-BOUNDARY-START(8590196767),
    {
      "t": 1310721,
      "n": "CryptoNative",
      "d": 262175,
      "h": 8590196767,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590196767),
//--TRIMMABLE-BOUNDARY-START(4295229471),
    {
      "t": 1310721,
      "n": "CompressionNative",
      "d": 262175,
      "h": 4295229471,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295229471),
//--TRIMMABLE-BOUNDARY-START(12885164063),
    {
      "t": 1310721,
      "n": "GlobalizationNative",
      "d": 262175,
      "h": 12885164063,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885164063),
//--TRIMMABLE-BOUNDARY-START(21475098655),
    {
      "t": 1310721,
      "n": "IOPortsNative",
      "d": 262175,
      "h": 21475098655,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475098655),
//--TRIMMABLE-BOUNDARY-START(17180131359),
    {
      "t": 1310721,
      "n": "HostPolicy",
      "d": 262175,
      "h": 17180131359,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180131359)
  ],
  "d": 65567,
  "h": 262175
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Interop.Libraries`; }
                }, $cls, ($v) => $cls.$_Libraries = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(262175)
            
            //--TRIMMABLE-BOUNDARY-START(327711)
            static $_Sys;
            static get Sys()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_Sys ??= $asm.$ncls("$sim.Interop.Sys", ($self) => class Sys
                {
                    //--TRIMMABLE-BOUNDARY-START(393247)
                    static $_Fcntl;
                    static get Fcntl()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_Fcntl ??= $asm.$ncls("$sim.Interop.Sys.Fcntl", ($self) => class Fcntl
                        {
                            //--TRIMMABLE-BOUNDARY-START(4295360543)
                            static /*int */ DangerousSetIsNonBlocking(/*IntPtr*/ fd, /*int*/ isNonBlocking)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4295360543);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return -1;
                            }
                            //--TRIMMABLE-BOUNDARY-END(4295360543)
                            
                            //--TRIMMABLE-BOUNDARY-START(25770197023)
                            static /*int */ SetIsNonBlocking(/*SafeHandle*/ fd, /*int*/ isNonBlocking)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(25770197023);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return -1;
                            }
                            //--TRIMMABLE-BOUNDARY-END(25770197023)
                            
                            //--TRIMMABLE-BOUNDARY-START(17180262431)
                            static /*int */ GetIsNonBlocking(/*SafeHandle*/ fd, /*out bool*/ isNonBlocking)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17180262431);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                isNonBlocking.$v = false;
                                return -1;
                            }
                            //--TRIMMABLE-BOUNDARY-END(17180262431)
                            
                            //--TRIMMABLE-BOUNDARY-START(21475229727)
                            static /*int */ SetFD(/*SafeHandle*/ fd, /*int*/ flags)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(21475229727);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return -1;
                            }
                            //--TRIMMABLE-BOUNDARY-END(21475229727)
                            
                            //--TRIMMABLE-BOUNDARY-START(8590327839)
                            static /*int */ GetFD$1(/*SafeHandle*/ fd)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(8590327839);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return -1;
                            }
                            //--TRIMMABLE-BOUNDARY-END(8590327839)
                            
                            //--TRIMMABLE-BOUNDARY-START(12885295135)
                            static /*int */ GetFD(/*IntPtr*/ fd)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(12885295135);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return -1;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12885295135)
                            
                            static $h = 393247;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295360543),
    {
      "r": 655361,
      "p": [
        {
          "n": "fd",
          "p": 786433
        },
        {
          "n": "isNonBlocking",
          "p": 655361
        }
      ],
      "n": "DangerousSetIsNonBlocking",
      "d": 393247,
      "h": 4295360543,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_FcntlSetIsNonBlocking",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295360543),
//--TRIMMABLE-BOUNDARY-START(25770197023),
    {
      "r": 655361,
      "p": [
        {
          "n": "fd",
          "p": 146931713
        },
        {
          "n": "isNonBlocking",
          "p": 655361
        }
      ],
      "n": "SetIsNonBlocking",
      "d": 393247,
      "h": 25770197023,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_FcntlSetIsNonBlocking",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770197023),
//--TRIMMABLE-BOUNDARY-START(17180262431),
    {
      "r": 655361,
      "p": [
        {
          "n": "fd",
          "p": 146931713
        },
        {
          "n": "isNonBlocking",
          "p": 262145,
          "f": 2,
          "a": [
            {
              "t": 143065089,
              "c": 4438032385,
              "a": [
                {
                  "v": 2,
                  "t": 148242433
                }
              ]
            }
          ]
        }
      ],
      "n": "GetIsNonBlocking",
      "d": 393247,
      "h": 17180262431,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_FcntlGetIsNonBlocking",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180262431),
//--TRIMMABLE-BOUNDARY-START(21475229727),
    {
      "r": 655361,
      "p": [
        {
          "n": "fd",
          "p": 146931713
        },
        {
          "n": "flags",
          "p": 655361
        }
      ],
      "n": "SetFD",
      "d": 393247,
      "h": 21475229727,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_FcntlSetFD",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475229727),
//--TRIMMABLE-BOUNDARY-START(8590327839),
    {
      "r": 655361,
      "p": [
        {
          "n": "fd",
          "p": 146931713
        }
      ],
      "n": "GetFD",
      "o": "@$1",
      "d": 393247,
      "h": 8590327839,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_FcntlGetFD",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590327839),
//--TRIMMABLE-BOUNDARY-START(12885295135),
    {
      "r": 655361,
      "p": [
        {
          "n": "fd",
          "p": 786433
        }
      ],
      "n": "GetFD",
      "d": 393247,
      "h": 12885295135,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_FcntlGetFD",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885295135)
  ],
  "d": 327711,
  "h": 393247
}; }
                            static get $b() { return $.$$.System.Object; }
                            static get $fullName() { return `Interop.Sys.Fcntl`; }
                        }, $cls, ($v) => $cls.$_Fcntl = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(393247)
                    
                    //--TRIMMABLE-BOUNDARY-START(786463)
                    static $_MemoryMappedProtections;
                    static get MemoryMappedProtections()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryMappedProtections ??= $asm.$nstr("$sim.Interop.Sys.MemoryMappedProtections", ($self) => class MemoryMappedProtections extends $.$$.System.Enum
                        {
                            static PROT_NONE = 0;
                            static PROT_READ = 1;
                            static PROT_WRITE = 2;
                            static PROT_EXEC = 4;
                            static $map;
                            static get Map()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(786463);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.$map ??= 
                                {
                                    "PROT_NONE": 0n,
                                    "PROT_READ": 1n,
                                    "PROT_WRITE": 2n,
                                    "PROT_EXEC": 4n
                                };
                            }
                            static $h = 786463;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885688351),
    {
      "t": 786463,
      "n": "PROT_NONE",
      "d": 786463,
      "h": 12885688351,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885688351),
//--TRIMMABLE-BOUNDARY-START(17180655647),
    {
      "t": 786463,
      "n": "PROT_READ",
      "d": 786463,
      "h": 17180655647,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180655647),
//--TRIMMABLE-BOUNDARY-START(21475622943),
    {
      "t": 786463,
      "n": "PROT_WRITE",
      "d": 786463,
      "h": 21475622943,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475622943),
//--TRIMMABLE-BOUNDARY-START(8590721055),
    {
      "t": 786463,
      "n": "PROT_EXEC",
      "d": 786463,
      "h": 8590721055,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590721055)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753759),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786463,
      "h": 4295753759,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753759)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "d": 327711,
  "h": 786463,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryMappedProtections`; }
                        }, $cls, ($v) => $cls.$_MemoryMappedProtections = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(786463)
                    
                    //--TRIMMABLE-BOUNDARY-START(720927)
                    static $_MemoryMappedFlags;
                    static get MemoryMappedFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryMappedFlags ??= $asm.$nstr("$sim.Interop.Sys.MemoryMappedFlags", ($self) => class MemoryMappedFlags extends $.$$.System.Enum
                        {
                            static MAP_SHARED = 1;
                            static MAP_PRIVATE = 2;
                            static MAP_ANONYMOUS = 16;
                            static $map;
                            static get Map()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(720927);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.$map ??= 
                                {
                                    "MAP_SHARED": 1n,
                                    "MAP_PRIVATE": 2n,
                                    "MAP_ANONYMOUS": 16n
                                };
                            }
                            static $h = 720927;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180590111),
    {
      "t": 720927,
      "n": "MAP_SHARED",
      "d": 720927,
      "h": 17180590111,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590111),
//--TRIMMABLE-BOUNDARY-START(12885622815),
    {
      "t": 720927,
      "n": "MAP_PRIVATE",
      "d": 720927,
      "h": 12885622815,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622815),
//--TRIMMABLE-BOUNDARY-START(8590655519),
    {
      "t": 720927,
      "n": "MAP_ANONYMOUS",
      "d": 720927,
      "h": 8590655519,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655519)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688223),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720927,
      "h": 4295688223,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688223)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "d": 327711,
  "h": 720927,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryMappedFlags`; }
                        }, $cls, ($v) => $cls.$_MemoryMappedFlags = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(720927)
                    
                    //--TRIMMABLE-BOUNDARY-START(917535)
                    static $_OpenFlags;
                    static get OpenFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_OpenFlags ??= $asm.$nstr("$sim.Interop.Sys.OpenFlags", ($self) => class OpenFlags extends $.$$.System.Enum
                        {
                            static O_RDONLY = 0;
                            static O_WRONLY = 1;
                            static O_RDWR = 2;
                            static O_CLOEXEC = 16;
                            static O_CREAT = 32;
                            static O_EXCL = 64;
                            static O_TRUNC = 128;
                            static O_SYNC = 256;
                            static O_NOFOLLOW = 512;
                            static $map;
                            static get Map()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(917535);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.$map ??= 
                                {
                                    "O_RDONLY": 0n,
                                    "O_WRONLY": 1n,
                                    "O_RDWR": 2n,
                                    "O_CLOEXEC": 16n,
                                    "O_CREAT": 32n,
                                    "O_EXCL": 64n,
                                    "O_TRUNC": 128n,
                                    "O_SYNC": 256n,
                                    "O_NOFOLLOW": 512n
                                };
                            }
                            static $h = 917535;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770721311),
    {
      "t": 917535,
      "n": "O_RDONLY",
      "d": 917535,
      "h": 25770721311,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770721311),
//--TRIMMABLE-BOUNDARY-START(42950590495),
    {
      "t": 917535,
      "n": "O_WRONLY",
      "d": 917535,
      "h": 42950590495,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950590495),
//--TRIMMABLE-BOUNDARY-START(30065688607),
    {
      "t": 917535,
      "n": "O_RDWR",
      "d": 917535,
      "h": 30065688607,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065688607),
//--TRIMMABLE-BOUNDARY-START(8590852127),
    {
      "t": 917535,
      "n": "O_CLOEXEC",
      "d": 917535,
      "h": 8590852127,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590852127),
//--TRIMMABLE-BOUNDARY-START(12885819423),
    {
      "t": 917535,
      "n": "O_CREAT",
      "d": 917535,
      "h": 12885819423,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885819423),
//--TRIMMABLE-BOUNDARY-START(17180786719),
    {
      "t": 917535,
      "n": "O_EXCL",
      "d": 917535,
      "h": 17180786719,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180786719),
//--TRIMMABLE-BOUNDARY-START(38655623199),
    {
      "t": 917535,
      "n": "O_TRUNC",
      "d": 917535,
      "h": 38655623199,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655623199),
//--TRIMMABLE-BOUNDARY-START(34360655903),
    {
      "t": 917535,
      "n": "O_SYNC",
      "d": 917535,
      "h": 34360655903,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360655903),
//--TRIMMABLE-BOUNDARY-START(21475754015),
    {
      "t": 917535,
      "n": "O_NOFOLLOW",
      "d": 917535,
      "h": 21475754015,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475754015)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884831),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917535,
      "h": 4295884831,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884831)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "d": 327711,
  "h": 917535,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.OpenFlags`; }
                        }, $cls, ($v) => $cls.$_OpenFlags = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(917535)
                    
                    //--TRIMMABLE-BOUNDARY-START(851999)
                    static $_MemoryMappedSyncFlags;
                    static get MemoryMappedSyncFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryMappedSyncFlags ??= $asm.$nstr("$sim.Interop.Sys.MemoryMappedSyncFlags", ($self) => class MemoryMappedSyncFlags extends $.$$.System.Enum
                        {
                            static MS_ASYNC = 1;
                            static MS_SYNC = 2;
                            static MS_INVALIDATE = 16;
                            static $map;
                            static get Map()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(851999);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.$map ??= 
                                {
                                    "MS_ASYNC": 1n,
                                    "MS_SYNC": 2n,
                                    "MS_INVALIDATE": 16n
                                };
                            }
                            static $h = 851999;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590786591),
    {
      "t": 851999,
      "n": "MS_ASYNC",
      "d": 851999,
      "h": 8590786591,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590786591),
//--TRIMMABLE-BOUNDARY-START(17180721183),
    {
      "t": 851999,
      "n": "MS_SYNC",
      "d": 851999,
      "h": 17180721183,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180721183),
//--TRIMMABLE-BOUNDARY-START(12885753887),
    {
      "t": 851999,
      "n": "MS_INVALIDATE",
      "d": 851999,
      "h": 12885753887,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885753887)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819295),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 851999,
      "h": 4295819295,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819295)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "d": 327711,
  "h": 851999,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryMappedSyncFlags`; }
                        }, $cls, ($v) => $cls.$_MemoryMappedSyncFlags = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(851999)
                    
                    //--TRIMMABLE-BOUNDARY-START(983071)
                    static $_SysConfName;
                    static get SysConfName()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_SysConfName ??= $asm.$nstr("$sim.Interop.Sys.SysConfName", ($self) => class SysConfName extends $.$$.System.Enum
                        {
                            static _SC_CLK_TCK = 1;
                            static _SC_PAGESIZE = 2;
                            static $map;
                            static get Map()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(983071);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.$map ??= 
                                {
                                    "_SC_CLK_TCK": 1n,
                                    "_SC_PAGESIZE": 2n
                                };
                            }
                            static $h = 983071;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295950367),
    {
      "t": 983071,
      "n": "_SC_CLK_TCK",
      "d": 983071,
      "h": 4295950367,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295950367),
//--TRIMMABLE-BOUNDARY-START(8590917663),
    {
      "t": 983071,
      "n": "_SC_PAGESIZE",
      "d": 983071,
      "h": 8590917663,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590917663)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885884959),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 983071,
      "h": 12885884959,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885884959)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "d": 327711,
  "h": 983071
}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.SysConfName`; }
                        }, $cls, ($v) => $cls.$_SysConfName = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(983071)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539935263)
                    static /*Error */ GetLastError()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51539935263);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$sim.Interop.Sys.ConvertErrorPlatformToPal($.$$.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    //--TRIMMABLE-BOUNDARY-END(51539935263)
                    
                    //--TRIMMABLE-BOUNDARY-START(55834902559)
                    static /*ErrorInfo */ GetLastErrorInfo()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55834902559);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$sim.Interop.ErrorInfo().$ctor$3($.$$.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    //--TRIMMABLE-BOUNDARY-END(55834902559)
                    
                    //--TRIMMABLE-BOUNDARY-START(141734248479)
                    static /*string */ StrError(/*int*/ platformErrno)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(141734248479);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*int*/ let MaxBufferLength = 1024;
                        /*byte**/ let buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$$.System.Byte, MaxBufferLength, null);
                        /*byte**/ let message = $.$sim.Interop.Sys.StrErrorR(platformErrno, buffer, MaxBufferLength);
                        if (message === null)
                        {
                            message = buffer;
                        }
                        return $.$$.System.Runtime.InteropServices.Marshal.PtrToStringUTF8$1($.$cast(message, $.$$.System.IntPtr));
                    }
                    //--TRIMMABLE-BOUNDARY-END(141734248479)
                    
                    //--TRIMMABLE-BOUNDARY-START(458783)
                    static $_FileStatus;
                    static get FileStatus()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_FileStatus ??= $asm.$nstr("$sim.Interop.Sys.FileStatus", ($self) => class FileStatus extends $.$$.System.ValueType
                        {
                            //--TRIMMABLE-BOUNDARY-START(38655164447)
                            /*FileStatusFlags*/  get Flags() { return this.$getField(0, $.$sim.Interop.Sys.FileStatusFlags); }
                            /*FileStatusFlags*/  set Flags(value) { this.$setField(0, $.$sim.Interop.Sys.FileStatusFlags, value); }
                            //--TRIMMABLE-BOUNDARY-END(38655164447)
                            
                            //--TRIMMABLE-BOUNDARY-START(51540066335)
                            /*int*/  get Mode() { return this.$getField(4, $.$$.System.Int32); }
                            /*int*/  set Mode(value) { this.$setField(4, $.$$.System.Int32, value); }
                            //--TRIMMABLE-BOUNDARY-END(51540066335)
                            
                            //--TRIMMABLE-BOUNDARY-START(73014902815)
                            /*uint*/  get Uid() { return this.$getField(8, $.$$.System.UInt32); }
                            /*uint*/  set Uid(value) { this.$setField(8, $.$$.System.UInt32, value); }
                            //--TRIMMABLE-BOUNDARY-END(73014902815)
                            
                            //--TRIMMABLE-BOUNDARY-START(42950131743)
                            /*uint*/  get Gid() { return this.$getField(12, $.$$.System.UInt32); }
                            /*uint*/  set Gid(value) { this.$setField(12, $.$$.System.UInt32, value); }
                            //--TRIMMABLE-BOUNDARY-END(42950131743)
                            
                            //--TRIMMABLE-BOUNDARY-START(68719935519)
                            /*long*/  get Size() { return this.$getField(16, $.$$.System.Int64); }
                            /*long*/  set Size(value) { this.$setField(16, $.$$.System.Int64, value); }
                            //--TRIMMABLE-BOUNDARY-END(68719935519)
                            
                            //--TRIMMABLE-BOUNDARY-START(8590393375)
                            /*long*/  get ATime() { return this.$getField(24, $.$$.System.Int64); }
                            /*long*/  set ATime(value) { this.$setField(24, $.$$.System.Int64, value); }
                            //--TRIMMABLE-BOUNDARY-END(8590393375)
                            
                            //--TRIMMABLE-BOUNDARY-START(12885360671)
                            /*long*/  get ATimeNsec() { return this.$getField(32, $.$$.System.Int64); }
                            /*long*/  set ATimeNsec(value) { this.$setField(32, $.$$.System.Int64, value); }
                            //--TRIMMABLE-BOUNDARY-END(12885360671)
                            
                            //--TRIMMABLE-BOUNDARY-START(55835033631)
                            /*long*/  get MTime() { return this.$getField(40, $.$$.System.Int64); }
                            /*long*/  set MTime(value) { this.$setField(40, $.$$.System.Int64, value); }
                            //--TRIMMABLE-BOUNDARY-END(55835033631)
                            
                            //--TRIMMABLE-BOUNDARY-START(60130000927)
                            /*long*/  get MTimeNsec() { return this.$getField(48, $.$$.System.Int64); }
                            /*long*/  set MTimeNsec(value) { this.$setField(48, $.$$.System.Int64, value); }
                            //--TRIMMABLE-BOUNDARY-END(60130000927)
                            
                            //--TRIMMABLE-BOUNDARY-START(25770262559)
                            /*long*/  get CTime() { return this.$getField(56, $.$$.System.Int64); }
                            /*long*/  set CTime(value) { this.$setField(56, $.$$.System.Int64, value); }
                            //--TRIMMABLE-BOUNDARY-END(25770262559)
                            
                            //--TRIMMABLE-BOUNDARY-START(30065229855)
                            /*long*/  get CTimeNsec() { return this.$getField(64, $.$$.System.Int64); }
                            /*long*/  set CTimeNsec(value) { this.$setField(64, $.$$.System.Int64, value); }
                            //--TRIMMABLE-BOUNDARY-END(30065229855)
                            
                            //--TRIMMABLE-BOUNDARY-START(17180327967)
                            /*long*/  get BirthTime() { return this.$getField(72, $.$$.System.Int64); }
                            /*long*/  set BirthTime(value) { this.$setField(72, $.$$.System.Int64, value); }
                            //--TRIMMABLE-BOUNDARY-END(17180327967)
                            
                            //--TRIMMABLE-BOUNDARY-START(21475295263)
                            /*long*/  get BirthTimeNsec() { return this.$getField(80, $.$$.System.Int64); }
                            /*long*/  set BirthTimeNsec(value) { this.$setField(80, $.$$.System.Int64, value); }
                            //--TRIMMABLE-BOUNDARY-END(21475295263)
                            
                            //--TRIMMABLE-BOUNDARY-START(34360197151)
                            /*long*/  get Dev() { return this.$getField(88, $.$$.System.Int64); }
                            /*long*/  set Dev(value) { this.$setField(88, $.$$.System.Int64, value); }
                            //--TRIMMABLE-BOUNDARY-END(34360197151)
                            
                            //--TRIMMABLE-BOUNDARY-START(64424968223)
                            /*long*/  get RDev() { return this.$getField(96, $.$$.System.Int64); }
                            /*long*/  set RDev(value) { this.$setField(96, $.$$.System.Int64, value); }
                            //--TRIMMABLE-BOUNDARY-END(64424968223)
                            
                            //--TRIMMABLE-BOUNDARY-START(47245099039)
                            /*long*/  get Ino() { return this.$getField(104, $.$$.System.Int64); }
                            /*long*/  set Ino(value) { this.$setField(104, $.$$.System.Int64, value); }
                            //--TRIMMABLE-BOUNDARY-END(47245099039)
                            
                            //--TRIMMABLE-BOUNDARY-START(77309870111)
                            /*uint*/  get UserFlags() { return this.$getField(112, $.$$.System.UInt32); }
                            /*uint*/  set UserFlags(value) { this.$setField(112, $.$$.System.UInt32, value); }
                            //--TRIMMABLE-BOUNDARY-END(77309870111)
                            
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy.Flags = this.Flags;
                                copy.Mode = this.Mode;
                                copy.Uid = this.Uid;
                                copy.Gid = this.Gid;
                                copy.Size = this.Size;
                                copy.ATime = this.ATime;
                                copy.ATimeNsec = this.ATimeNsec;
                                copy.MTime = this.MTime;
                                copy.MTimeNsec = this.MTimeNsec;
                                copy.CTime = this.CTime;
                                copy.CTimeNsec = this.CTimeNsec;
                                copy.BirthTime = this.BirthTime;
                                copy.BirthTimeNsec = this.BirthTimeNsec;
                                copy.Dev = this.Dev;
                                copy.RDev = this.RDev;
                                copy.Ino = this.Ino;
                                copy.UserFlags = this.UserFlags;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                //--TRIMMABLE-BOUNDARY-START(38655164447)
                                this.Flags = 0;
                                //--TRIMMABLE-BOUNDARY-END(38655164447)
                                
                                //--TRIMMABLE-BOUNDARY-START(51540066335)
                                this.Mode = 0;
                                //--TRIMMABLE-BOUNDARY-END(51540066335)
                                
                                //--TRIMMABLE-BOUNDARY-START(73014902815)
                                this.Uid = 0;
                                //--TRIMMABLE-BOUNDARY-END(73014902815)
                                
                                //--TRIMMABLE-BOUNDARY-START(42950131743)
                                this.Gid = 0;
                                //--TRIMMABLE-BOUNDARY-END(42950131743)
                                
                                //--TRIMMABLE-BOUNDARY-START(68719935519)
                                this.Size = 0n;
                                //--TRIMMABLE-BOUNDARY-END(68719935519)
                                
                                //--TRIMMABLE-BOUNDARY-START(8590393375)
                                this.ATime = 0n;
                                //--TRIMMABLE-BOUNDARY-END(8590393375)
                                
                                //--TRIMMABLE-BOUNDARY-START(12885360671)
                                this.ATimeNsec = 0n;
                                //--TRIMMABLE-BOUNDARY-END(12885360671)
                                
                                //--TRIMMABLE-BOUNDARY-START(55835033631)
                                this.MTime = 0n;
                                //--TRIMMABLE-BOUNDARY-END(55835033631)
                                
                                //--TRIMMABLE-BOUNDARY-START(60130000927)
                                this.MTimeNsec = 0n;
                                //--TRIMMABLE-BOUNDARY-END(60130000927)
                                
                                //--TRIMMABLE-BOUNDARY-START(25770262559)
                                this.CTime = 0n;
                                //--TRIMMABLE-BOUNDARY-END(25770262559)
                                
                                //--TRIMMABLE-BOUNDARY-START(30065229855)
                                this.CTimeNsec = 0n;
                                //--TRIMMABLE-BOUNDARY-END(30065229855)
                                
                                //--TRIMMABLE-BOUNDARY-START(17180327967)
                                this.BirthTime = 0n;
                                //--TRIMMABLE-BOUNDARY-END(17180327967)
                                
                                //--TRIMMABLE-BOUNDARY-START(21475295263)
                                this.BirthTimeNsec = 0n;
                                //--TRIMMABLE-BOUNDARY-END(21475295263)
                                
                                //--TRIMMABLE-BOUNDARY-START(34360197151)
                                this.Dev = 0n;
                                //--TRIMMABLE-BOUNDARY-END(34360197151)
                                
                                //--TRIMMABLE-BOUNDARY-START(64424968223)
                                this.RDev = 0n;
                                //--TRIMMABLE-BOUNDARY-END(64424968223)
                                
                                //--TRIMMABLE-BOUNDARY-START(47245099039)
                                this.Ino = 0n;
                                //--TRIMMABLE-BOUNDARY-END(47245099039)
                                
                                //--TRIMMABLE-BOUNDARY-START(77309870111)
                                this.UserFlags = 0;
                                //--TRIMMABLE-BOUNDARY-END(77309870111)
                                
                            }
                            static $h = 458783;
                            static $z = 116;
                            static $f = 0b10100010000001010000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655164447),
    {
      "t": 524319,
      "n": "Flags",
      "d": 458783,
      "h": 38655164447,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(38655164447),
//--TRIMMABLE-BOUNDARY-START(51540066335),
    {
      "t": 655361,
      "n": "Mode",
      "d": 458783,
      "h": 51540066335,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(51540066335),
//--TRIMMABLE-BOUNDARY-START(73014902815),
    {
      "t": 720897,
      "n": "Uid",
      "d": 458783,
      "h": 73014902815,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(73014902815),
//--TRIMMABLE-BOUNDARY-START(42950131743),
    {
      "t": 720897,
      "n": "Gid",
      "d": 458783,
      "h": 42950131743,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(42950131743),
//--TRIMMABLE-BOUNDARY-START(68719935519),
    {
      "t": 917505,
      "n": "Size",
      "d": 458783,
      "h": 68719935519,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(68719935519),
//--TRIMMABLE-BOUNDARY-START(8590393375),
    {
      "t": 917505,
      "n": "ATime",
      "d": 458783,
      "h": 8590393375,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590393375),
//--TRIMMABLE-BOUNDARY-START(12885360671),
    {
      "t": 917505,
      "n": "ATimeNsec",
      "d": 458783,
      "h": 12885360671,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885360671),
//--TRIMMABLE-BOUNDARY-START(55835033631),
    {
      "t": 917505,
      "n": "MTime",
      "d": 458783,
      "h": 55835033631,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(55835033631),
//--TRIMMABLE-BOUNDARY-START(60130000927),
    {
      "t": 917505,
      "n": "MTimeNsec",
      "d": 458783,
      "h": 60130000927,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(60130000927),
//--TRIMMABLE-BOUNDARY-START(25770262559),
    {
      "t": 917505,
      "n": "CTime",
      "d": 458783,
      "h": 25770262559,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(25770262559),
//--TRIMMABLE-BOUNDARY-START(30065229855),
    {
      "t": 917505,
      "n": "CTimeNsec",
      "d": 458783,
      "h": 30065229855,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(30065229855),
//--TRIMMABLE-BOUNDARY-START(17180327967),
    {
      "t": 917505,
      "n": "BirthTime",
      "d": 458783,
      "h": 17180327967,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180327967),
//--TRIMMABLE-BOUNDARY-START(21475295263),
    {
      "t": 917505,
      "n": "BirthTimeNsec",
      "d": 458783,
      "h": 21475295263,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21475295263),
//--TRIMMABLE-BOUNDARY-START(34360197151),
    {
      "t": 917505,
      "n": "Dev",
      "d": 458783,
      "h": 34360197151,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(34360197151),
//--TRIMMABLE-BOUNDARY-START(64424968223),
    {
      "t": 917505,
      "n": "RDev",
      "d": 458783,
      "h": 64424968223,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(64424968223),
//--TRIMMABLE-BOUNDARY-START(47245099039),
    {
      "t": 917505,
      "n": "Ino",
      "d": 458783,
      "h": 47245099039,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(47245099039),
//--TRIMMABLE-BOUNDARY-START(77309870111),
    {
      "t": 720897,
      "n": "UserFlags",
      "d": 458783,
      "h": 77309870111,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(77309870111)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426079),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458783,
      "h": 4295426079,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426079)
  ],
  "d": 327711,
  "h": 458783,
  "a": [
    {
      "t": 147259393,
      "c": 4442226689,
      "a": [
        {
          "v": 0,
          "t": 142737409
        }
      ]
    }
  ]
}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static get $fullName() { return `Interop.Sys.FileStatus`; }
                        }, $cls, ($v) => $cls.$_FileStatus = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(458783)
                    
                    //--TRIMMABLE-BOUNDARY-START(589855)
                    static $_FileTypes;
                    static get FileTypes()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_FileTypes ??= $asm.$ncls("$sim.Interop.Sys.FileTypes", ($self) => class FileTypes
                        {
                            //--TRIMMABLE-BOUNDARY-START(25770393631)
                            /*int*/ static S_IFMT = 61440;
                            //--TRIMMABLE-BOUNDARY-END(25770393631)
                            
                            //--TRIMMABLE-BOUNDARY-START(17180459039)
                            /*int*/ static S_IFIFO = 4096;
                            //--TRIMMABLE-BOUNDARY-END(17180459039)
                            
                            //--TRIMMABLE-BOUNDARY-START(8590524447)
                            /*int*/ static S_IFCHR = 8192;
                            //--TRIMMABLE-BOUNDARY-END(8590524447)
                            
                            //--TRIMMABLE-BOUNDARY-START(12885491743)
                            /*int*/ static S_IFDIR = 16384;
                            //--TRIMMABLE-BOUNDARY-END(12885491743)
                            
                            //--TRIMMABLE-BOUNDARY-START(4295557151)
                            /*int*/ static S_IFBLK = 24576;
                            //--TRIMMABLE-BOUNDARY-END(4295557151)
                            
                            //--TRIMMABLE-BOUNDARY-START(30065360927)
                            /*int*/ static S_IFREG = 32768;
                            //--TRIMMABLE-BOUNDARY-END(30065360927)
                            
                            //--TRIMMABLE-BOUNDARY-START(21475426335)
                            /*int*/ static S_IFLNK = 40960;
                            //--TRIMMABLE-BOUNDARY-END(21475426335)
                            
                            //--TRIMMABLE-BOUNDARY-START(34360328223)
                            /*int*/ static S_IFSOCK = 49152;
                            //--TRIMMABLE-BOUNDARY-END(34360328223)
                            
                            static $h = 589855;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770393631),
    {
      "t": 655361,
      "n": "S_IFMT",
      "d": 589855,
      "h": 25770393631,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770393631),
//--TRIMMABLE-BOUNDARY-START(17180459039),
    {
      "t": 655361,
      "n": "S_IFIFO",
      "d": 589855,
      "h": 17180459039,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180459039),
//--TRIMMABLE-BOUNDARY-START(8590524447),
    {
      "t": 655361,
      "n": "S_IFCHR",
      "d": 589855,
      "h": 8590524447,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590524447),
//--TRIMMABLE-BOUNDARY-START(12885491743),
    {
      "t": 655361,
      "n": "S_IFDIR",
      "d": 589855,
      "h": 12885491743,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885491743),
//--TRIMMABLE-BOUNDARY-START(4295557151),
    {
      "t": 655361,
      "n": "S_IFBLK",
      "d": 589855,
      "h": 4295557151,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295557151),
//--TRIMMABLE-BOUNDARY-START(30065360927),
    {
      "t": 655361,
      "n": "S_IFREG",
      "d": 589855,
      "h": 30065360927,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065360927),
//--TRIMMABLE-BOUNDARY-START(21475426335),
    {
      "t": 655361,
      "n": "S_IFLNK",
      "d": 589855,
      "h": 21475426335,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475426335),
//--TRIMMABLE-BOUNDARY-START(34360328223),
    {
      "t": 655361,
      "n": "S_IFSOCK",
      "d": 589855,
      "h": 34360328223,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360328223)
  ],
  "d": 327711,
  "h": 589855
}; }
                            static get $b() { return $.$$.System.Object; }
                            static get $fullName() { return `Interop.Sys.FileTypes`; }
                        }, $cls, ($v) => $cls.$_FileTypes = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(589855)
                    
                    //--TRIMMABLE-BOUNDARY-START(524319)
                    static $_FileStatusFlags;
                    static get FileStatusFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_FileStatusFlags ??= $asm.$nstr("$sim.Interop.Sys.FileStatusFlags", ($self) => class FileStatusFlags extends $.$$.System.Enum
                        {
                            static None = 0;
                            static HasBirthTime = 1;
                            static $map;
                            static get Map()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(524319);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.$map ??= 
                                {
                                    "None": 0n,
                                    "HasBirthTime": 1n
                                };
                            }
                            static $h = 524319;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885426207),
    {
      "t": 524319,
      "n": "None",
      "d": 524319,
      "h": 12885426207,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426207),
//--TRIMMABLE-BOUNDARY-START(8590458911),
    {
      "t": 524319,
      "n": "HasBirthTime",
      "d": 524319,
      "h": 8590458911,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458911)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491615),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524319,
      "h": 4295491615,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491615)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "d": 327711,
  "h": 524319,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.FileStatusFlags`; }
                        }, $cls, ($v) => $cls.$_FileStatusFlags = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(524319)
                    
                    //--TRIMMABLE-BOUNDARY-START(655391)
                    static $_MemoryAdvice;
                    static get MemoryAdvice()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryAdvice ??= $asm.$nstr("$sim.Interop.Sys.MemoryAdvice", ($self) => class MemoryAdvice extends $.$$.System.Enum
                        {
                            static MADV_DONTFORK = 1;
                            static $map;
                            static get Map()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(655391);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.$map ??= 
                                {
                                    "MADV_DONTFORK": 1n
                                };
                            }
                            static $h = 655391;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590589983),
    {
      "t": 655391,
      "n": "MADV_DONTFORK",
      "d": 655391,
      "h": 8590589983,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590589983)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622687),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655391,
      "h": 4295622687,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622687)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "d": 327711,
  "h": 655391
}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryAdvice`; }
                        }, $cls, ($v) => $cls.$_MemoryAdvice = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(655391)
                    
                    //--TRIMMABLE-BOUNDARY-START(124554379295)
                    /*sbyte*/ static s_memfdSupported = 0;
                    //--TRIMMABLE-BOUNDARY-END(124554379295)
                    
                    //--TRIMMABLE-BOUNDARY-START(60129869855)
                    static /*bool */ get IsMemfdSupported()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47244967967);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*sbyte*/ let memfdSupported = $.$sim.Interop.Sys.s_memfdSupported;
                        if (memfdSupported === 0)
                        {
                            $.$$.System.Threading.Interlocked.CompareExchange$8($.$ref(() => $.$sim.Interop.Sys.s_memfdSupported, ($v) => $.$sim.Interop.Sys.s_memfdSupported = $v, $.$$.System.SByte), $.$cast(($.$sim.Interop.Sys.MemfdSupportedImpl() === 1 ? 1 : -1), $.$$.System.SByte), 0);
                            memfdSupported = $.$sim.Interop.Sys.s_memfdSupported;
                        }
                        return memfdSupported > 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60129869855)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655033375)
                    static /*int */ FTruncate(/*SafeFileHandle*/ fd, /*long*/ length)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655033375);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655033375)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885229599)
                    static /*Error */ ConvertErrorPlatformToPal(/*int*/ platformErrno)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885229599);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$cast(platformErrno, $.$sim.Interop.Error);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885229599)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590262303)
                    static /*int */ ConvertErrorPalToPlatform(/*Error*/ error)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590262303);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return error;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590262303)
                    
                    //--TRIMMABLE-BOUNDARY-START(146029215775)
                    static /*byte* */ StrErrorR(/*int*/ platformErrno, /*byte**/ buffer, /*int*/ bufferSize)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(146029215775);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*RefOrPointer<byte>*/ let ptr = buffer;
                        $.$$.System.String.TryCopyTo.call("Error", new ($.$$.System.Span$$($.$$.System.Char))().$ctor$5($.$cast(buffer, $.$typePointer($.$$.System.Void)), bufferSize));
                        return buffer;
                    }
                    //--TRIMMABLE-BOUNDARY-END(146029215775)
                    
                    //--TRIMMABLE-BOUNDARY-START(98784575519)
                    static /*IntPtr */ MMap(/*IntPtr*/ addr, /*ulong*/ len, /*MemoryMappedProtections*/ prot, /*MemoryMappedFlags*/ flags, /*SafeFileHandle*/ fd, /*long*/ offset)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(98784575519);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$$.System.IntPtr.Zero;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98784575519)
                    
                    //--TRIMMABLE-BOUNDARY-START(103079542815)
                    static /*IntPtr */ MMap$1(/*IntPtr*/ addr, /*ulong*/ len, /*MemoryMappedProtections*/ prot, /*MemoryMappedFlags*/ flags, /*IntPtr*/ fd, /*long*/ offset)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(103079542815);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$$.System.IntPtr.Zero;
                    }
                    //--TRIMMABLE-BOUNDARY-END(103079542815)
                    
                    //--TRIMMABLE-BOUNDARY-START(158914117663)
                    static /*int */ Unlink(/*string*/ pathname)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(158914117663);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(158914117663)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295295007)
                    static /*int */ Close(/*IntPtr*/ fd)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295295007);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295295007)
                    
                    //--TRIMMABLE-BOUNDARY-START(68719804447)
                    static /*int */ MAdvise(/*IntPtr*/ addr, /*ulong*/ length, /*MemoryAdvice*/ advice)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68719804447);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    //--TRIMMABLE-BOUNDARY-END(68719804447)
                    
                    //--TRIMMABLE-BOUNDARY-START(107374510111)
                    static /*int */ MSync(/*IntPtr*/ addr, /*ulong*/ len, /*MemoryMappedSyncFlags*/ flags)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(107374510111);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    //--TRIMMABLE-BOUNDARY-END(107374510111)
                    
                    //--TRIMMABLE-BOUNDARY-START(128849346591)
                    static /*SafeFileHandle */ ShmOpen(/*string*/ name, /*OpenFlags*/ flags, /*int*/ mode)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(128849346591);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    //--TRIMMABLE-BOUNDARY-END(128849346591)
                    
                    //--TRIMMABLE-BOUNDARY-START(133144313887)
                    static /*int */ ShmUnlink(/*string*/ name)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(133144313887);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    //--TRIMMABLE-BOUNDARY-END(133144313887)
                    
                    //--TRIMMABLE-BOUNDARY-START(111669477407)
                    static /*int */ MUnmap(/*IntPtr*/ addr, /*ulong*/ len)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(111669477407);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(111669477407)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360066079)
                    static /*int */ FStat(/*SafeHandle*/ fd, /*out FileStatus*/ output)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360066079);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        output.$v = $.$default($.$sim.Interop.Sys.FileStatus);
                        return -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360066079)
                    
                    //--TRIMMABLE-BOUNDARY-START(137439281183)
                    static /*int */ Stat(/*string*/ path, /*out FileStatus*/ output)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(137439281183);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        output.$v = $.$default($.$sim.Interop.Sys.FileStatus);
                        return -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(137439281183)
                    
                    //--TRIMMABLE-BOUNDARY-START(64424837151)
                    static /*int */ LStat(/*string*/ path, /*out FileStatus*/ output)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64424837151);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        output.$v = $.$default($.$sim.Interop.Sys.FileStatus);
                        return -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(64424837151)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014771743)
                    static /*SafeFileHandle */ MemfdCreate(/*string*/ name, /*int*/ isReadonly)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014771743);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    //--TRIMMABLE-BOUNDARY-END(73014771743)
                    
                    //--TRIMMABLE-BOUNDARY-START(77309739039)
                    static /*int */ MemfdSupportedImpl()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77309739039);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(77309739039)
                    
                    //--TRIMMABLE-BOUNDARY-START(150324183071)
                    static /*long */ SysConf(/*SysConfName*/ name)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(150324183071);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return BigInt(-1);
                    }
                    //--TRIMMABLE-BOUNDARY-END(150324183071)
                    
                    //--TRIMMABLE-BOUNDARY-START(115964444703)
                    static /*SafeFileHandle */ Open(/*string*/ filename, /*OpenFlags*/ flags, /*int*/ mode)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(115964444703);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$$.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$4();
                    }
                    //--TRIMMABLE-BOUNDARY-END(115964444703)
                    
                    static $h = 327711;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129869855),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244967967,
        "f": 50331688
      },
      "n": "IsMemfdSupported",
      "d": 327711,
      "h": 60129869855,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(60129869855)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295295007),
    {
      "r": 655361,
      "p": [
        {
          "n": "fd",
          "p": 786433
        }
      ],
      "n": "Close",
      "d": 327711,
      "h": 4295295007,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_Close",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295295007),
//--TRIMMABLE-BOUNDARY-START(98784575519),
    {
      "r": 786433,
      "p": [
        {
          "n": "addr",
          "p": 786433
        },
        {
          "n": "len",
          "p": 983041
        },
        {
          "n": "prot",
          "p": 786463
        },
        {
          "n": "flags",
          "p": 720927
        },
        {
          "n": "fd",
          "p": 7733249
        },
        {
          "n": "offset",
          "p": 917505
        }
      ],
      "n": "MMap",
      "d": 327711,
      "h": 98784575519,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_MMap",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98784575519),
//--TRIMMABLE-BOUNDARY-START(103079542815),
    {
      "r": 786433,
      "p": [
        {
          "n": "addr",
          "p": 786433
        },
        {
          "n": "len",
          "p": 983041
        },
        {
          "n": "prot",
          "p": 786463
        },
        {
          "n": "flags",
          "p": 720927
        },
        {
          "n": "fd",
          "p": 786433
        },
        {
          "n": "offset",
          "p": 917505
        }
      ],
      "n": "MMap",
      "o": "@$1",
      "d": 327711,
      "h": 103079542815,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_MMap",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103079542815),
//--TRIMMABLE-BOUNDARY-START(111669477407),
    {
      "r": 655361,
      "p": [
        {
          "n": "addr",
          "p": 786433
        },
        {
          "n": "len",
          "p": 983041
        }
      ],
      "n": "MUnmap",
      "d": 327711,
      "h": 111669477407,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_MUnmap",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669477407),
//--TRIMMABLE-BOUNDARY-START(115964444703),
    {
      "r": 7733249,
      "p": [
        {
          "n": "filename",
          "p": 1310721
        },
        {
          "n": "flags",
          "p": 917535
        },
        {
          "n": "mode",
          "p": 655361
        }
      ],
      "n": "Open",
      "d": 327711,
      "h": 115964444703,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_Open",
              "t": 1310721
            },
            {
              "n": "StringMarshalling",
              "v": 1,
              "t": 147193857
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115964444703),
//--TRIMMABLE-BOUNDARY-START(107374510111),
    {
      "r": 655361,
      "p": [
        {
          "n": "addr",
          "p": 786433
        },
        {
          "n": "len",
          "p": 983041
        },
        {
          "n": "flags",
          "p": 851999
        }
      ],
      "n": "MSync",
      "d": 327711,
      "h": 107374510111,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_MSync",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107374510111),
//--TRIMMABLE-BOUNDARY-START(150324183071),
    {
      "r": 917505,
      "p": [
        {
          "n": "name",
          "p": 983071
        }
      ],
      "n": "SysConf",
      "d": 327711,
      "h": 150324183071,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_SysConf",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324183071),
//--TRIMMABLE-BOUNDARY-START(51539935263),
    {
      "r": 131103,
      "n": "GetLastError",
      "d": 327711,
      "h": 51539935263,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51539935263),
//--TRIMMABLE-BOUNDARY-START(55834902559),
    {
      "r": 196639,
      "n": "GetLastErrorInfo",
      "d": 327711,
      "h": 55834902559,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55834902559),
//--TRIMMABLE-BOUNDARY-START(141734248479),
    {
      "r": 1310721,
      "p": [
        {
          "n": "platformErrno",
          "p": 655361
        }
      ],
      "n": "StrError",
      "d": 327711,
      "h": 141734248479,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(141734248479),
//--TRIMMABLE-BOUNDARY-START(12885229599),
    {
      "r": 131103,
      "p": [
        {
          "n": "platformErrno",
          "p": 655361
        }
      ],
      "n": "ConvertErrorPlatformToPal",
      "d": 327711,
      "h": 12885229599,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_ConvertErrorPlatformToPal",
              "t": 1310721
            }
          ]
        },
        {
          "t": 147324929,
          "c": 4442292225
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885229599),
//--TRIMMABLE-BOUNDARY-START(8590262303),
    {
      "r": 655361,
      "p": [
        {
          "n": "error",
          "p": 131103
        }
      ],
      "n": "ConvertErrorPalToPlatform",
      "d": 327711,
      "h": 8590262303,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_ConvertErrorPalToPlatform",
              "t": 1310721
            }
          ]
        },
        {
          "t": 147324929,
          "c": 4442292225
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590262303),
//--TRIMMABLE-BOUNDARY-START(146029215775),
    {
      "r": $.$typePointer($.$$.System.Byte).$h,
      "p": [
        {
          "n": "platformErrno",
          "p": 655361
        },
        {
          "n": "buffer",
          "p": $.$typePointer($.$$.System.Byte).$h
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": "StrErrorR",
      "d": 327711,
      "h": 146029215775,
      "f": 16777250,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_StrErrorR",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029215775),
//--TRIMMABLE-BOUNDARY-START(34360066079),
    {
      "r": 655361,
      "p": [
        {
          "n": "fd",
          "p": 146931713
        },
        {
          "n": "output",
          "p": 458783,
          "f": 2
        }
      ],
      "n": "FStat",
      "d": 327711,
      "h": 34360066079,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_FStat",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360066079),
//--TRIMMABLE-BOUNDARY-START(137439281183),
    {
      "r": 655361,
      "p": [
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "output",
          "p": 458783,
          "f": 2
        }
      ],
      "n": "Stat",
      "d": 327711,
      "h": 137439281183,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_Stat",
              "t": 1310721
            },
            {
              "n": "StringMarshalling",
              "v": 1,
              "t": 147193857
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439281183),
//--TRIMMABLE-BOUNDARY-START(64424837151),
    {
      "r": 655361,
      "p": [
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "output",
          "p": 458783,
          "f": 2
        }
      ],
      "n": "LStat",
      "d": 327711,
      "h": 64424837151,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_LStat",
              "t": 1310721
            },
            {
              "n": "StringMarshalling",
              "v": 1,
              "t": 147193857
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64424837151),
//--TRIMMABLE-BOUNDARY-START(68719804447),
    {
      "r": 655361,
      "p": [
        {
          "n": "addr",
          "p": 786433
        },
        {
          "n": "length",
          "p": 983041
        },
        {
          "n": "advice",
          "p": 655391
        }
      ],
      "n": "MAdvise",
      "d": 327711,
      "h": 68719804447,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_MAdvise",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719804447),
//--TRIMMABLE-BOUNDARY-START(73014771743),
    {
      "r": 7733249,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "isReadonly",
          "p": 655361
        }
      ],
      "n": "MemfdCreate",
      "d": 327711,
      "h": 73014771743,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_MemfdCreate",
              "t": 1310721
            },
            {
              "n": "StringMarshalling",
              "v": 1,
              "t": 147193857
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73014771743),
//--TRIMMABLE-BOUNDARY-START(77309739039),
    {
      "r": 655361,
      "n": "MemfdSupportedImpl",
      "d": 327711,
      "h": 77309739039,
      "f": 16777250,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_IsMemfdSupported",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77309739039),
//--TRIMMABLE-BOUNDARY-START(128849346591),
    {
      "r": 7733249,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "flags",
          "p": 917535
        },
        {
          "n": "mode",
          "p": 655361
        }
      ],
      "n": "ShmOpen",
      "d": 327711,
      "h": 128849346591,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_ShmOpen",
              "t": 1310721
            },
            {
              "n": "StringMarshalling",
              "v": 1,
              "t": 147193857
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849346591),
//--TRIMMABLE-BOUNDARY-START(133144313887),
    {
      "r": 655361,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "ShmUnlink",
      "d": 327711,
      "h": 133144313887,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_ShmUnlink",
              "t": 1310721
            },
            {
              "n": "StringMarshalling",
              "v": 1,
              "t": 147193857
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133144313887),
//--TRIMMABLE-BOUNDARY-START(158914117663),
    {
      "r": 655361,
      "p": [
        {
          "n": "pathname",
          "p": 1310721
        }
      ],
      "n": "Unlink",
      "d": 327711,
      "h": 158914117663,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_Unlink",
              "t": 1310721
            },
            {
              "n": "StringMarshalling",
              "v": 1,
              "t": 147193857
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914117663),
//--TRIMMABLE-BOUNDARY-START(38655033375),
    {
      "r": 655361,
      "p": [
        {
          "n": "fd",
          "p": 7733249
        },
        {
          "n": "length",
          "p": 917505
        }
      ],
      "n": "FTruncate",
      "d": 327711,
      "h": 38655033375,
      "f": 16777256,
      "a": [
        {
          "t": 142868481,
          "c": 4437835777,
          "a": [
            {
              "v": "libSystem.Native",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EntryPoint",
              "v": "SystemNative_FTruncate",
              "t": 1310721
            },
            {
              "n": "SetLastError",
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655033375)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(124554379295),
    {
      "t": 327681,
      "n": "s_memfdSupported",
      "d": 327711,
      "h": 124554379295,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(124554379295)
  ],
  "j": [393247,786463,720927,917535,851999,983071,458783,589855,524319,655391
  ],
  "d": 65567,
  "h": 327711
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Interop.Sys`; }
                }, $cls, ($v) => $cls.$_Sys = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327711)
            
            //--TRIMMABLE-BOUNDARY-START(131103)
            static $_Error;
            static get Error()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_Error ??= $asm.$nstr("$sim.Interop.Error", ($self) => class Error extends $.$$.System.Enum
                {
                    static SUCCESS = 0;
                    static E2BIG = 65537;
                    static EACCES = 65538;
                    static EADDRINUSE = 65539;
                    static EADDRNOTAVAIL = 65540;
                    static EAFNOSUPPORT = 65541;
                    static EAGAIN = 65542;
                    static EALREADY = 65543;
                    static EBADF = 65544;
                    static EBADMSG = 65545;
                    static EBUSY = 65546;
                    static ECANCELED = 65547;
                    static ECHILD = 65548;
                    static ECONNABORTED = 65549;
                    static ECONNREFUSED = 65550;
                    static ECONNRESET = 65551;
                    static EDEADLK = 65552;
                    static EDESTADDRREQ = 65553;
                    static EDOM = 65554;
                    static EDQUOT = 65555;
                    static EEXIST = 65556;
                    static EFAULT = 65557;
                    static EFBIG = 65558;
                    static EHOSTUNREACH = 65559;
                    static EIDRM = 65560;
                    static EILSEQ = 65561;
                    static EINPROGRESS = 65562;
                    static EINTR = 65563;
                    static EINVAL = 65564;
                    static EIO = 65565;
                    static EISCONN = 65566;
                    static EISDIR = 65567;
                    static ELOOP = 65568;
                    static EMFILE = 65569;
                    static EMLINK = 65570;
                    static EMSGSIZE = 65571;
                    static EMULTIHOP = 65572;
                    static ENAMETOOLONG = 65573;
                    static ENETDOWN = 65574;
                    static ENETRESET = 65575;
                    static ENETUNREACH = 65576;
                    static ENFILE = 65577;
                    static ENOBUFS = 65578;
                    static ENODEV = 65580;
                    static ENOENT = 65581;
                    static ENOEXEC = 65582;
                    static ENOLCK = 65583;
                    static ENOLINK = 65584;
                    static ENOMEM = 65585;
                    static ENOMSG = 65586;
                    static ENOPROTOOPT = 65587;
                    static ENOSPC = 65588;
                    static ENOSYS = 65591;
                    static ENOTCONN = 65592;
                    static ENOTDIR = 65593;
                    static ENOTEMPTY = 65594;
                    static ENOTRECOVERABLE = 65595;
                    static ENOTSOCK = 65596;
                    static ENOTSUP = 65597;
                    static ENOTTY = 65598;
                    static ENXIO = 65599;
                    static EOVERFLOW = 65600;
                    static EOWNERDEAD = 65601;
                    static EPERM = 65602;
                    static EPIPE = 65603;
                    static EPROTO = 65604;
                    static EPROTONOSUPPORT = 65605;
                    static EPROTOTYPE = 65606;
                    static ERANGE = 65607;
                    static EROFS = 65608;
                    static ESPIPE = 65609;
                    static ESRCH = 65610;
                    static ESTALE = 65611;
                    static ETIMEDOUT = 65613;
                    static ETXTBSY = 65614;
                    static EXDEV = 65615;
                    static ESOCKTNOSUPPORT = 65630;
                    static EPFNOSUPPORT = 65632;
                    static ESHUTDOWN = 65644;
                    static EHOSTDOWN = 65648;
                    static ENODATA = 65649;
                    static EHOSTNOTFOUND = 131073;
                    static ESOCKETERROR = 131074;
                    static EOPNOTSUPP = 65597;
                    static EWOULDBLOCK = 65542;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(131103);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "SUCCESS": 0n,
                            "E2BIG": 65537n,
                            "EACCES": 65538n,
                            "EADDRINUSE": 65539n,
                            "EADDRNOTAVAIL": 65540n,
                            "EAFNOSUPPORT": 65541n,
                            "EAGAIN": 65542n,
                            "EALREADY": 65543n,
                            "EBADF": 65544n,
                            "EBADMSG": 65545n,
                            "EBUSY": 65546n,
                            "ECANCELED": 65547n,
                            "ECHILD": 65548n,
                            "ECONNABORTED": 65549n,
                            "ECONNREFUSED": 65550n,
                            "ECONNRESET": 65551n,
                            "EDEADLK": 65552n,
                            "EDESTADDRREQ": 65553n,
                            "EDOM": 65554n,
                            "EDQUOT": 65555n,
                            "EEXIST": 65556n,
                            "EFAULT": 65557n,
                            "EFBIG": 65558n,
                            "EHOSTUNREACH": 65559n,
                            "EIDRM": 65560n,
                            "EILSEQ": 65561n,
                            "EINPROGRESS": 65562n,
                            "EINTR": 65563n,
                            "EINVAL": 65564n,
                            "EIO": 65565n,
                            "EISCONN": 65566n,
                            "EISDIR": 65567n,
                            "ELOOP": 65568n,
                            "EMFILE": 65569n,
                            "EMLINK": 65570n,
                            "EMSGSIZE": 65571n,
                            "EMULTIHOP": 65572n,
                            "ENAMETOOLONG": 65573n,
                            "ENETDOWN": 65574n,
                            "ENETRESET": 65575n,
                            "ENETUNREACH": 65576n,
                            "ENFILE": 65577n,
                            "ENOBUFS": 65578n,
                            "ENODEV": 65580n,
                            "ENOENT": 65581n,
                            "ENOEXEC": 65582n,
                            "ENOLCK": 65583n,
                            "ENOLINK": 65584n,
                            "ENOMEM": 65585n,
                            "ENOMSG": 65586n,
                            "ENOPROTOOPT": 65587n,
                            "ENOSPC": 65588n,
                            "ENOSYS": 65591n,
                            "ENOTCONN": 65592n,
                            "ENOTDIR": 65593n,
                            "ENOTEMPTY": 65594n,
                            "ENOTRECOVERABLE": 65595n,
                            "ENOTSOCK": 65596n,
                            "ENOTSUP": 65597n,
                            "ENOTTY": 65598n,
                            "ENXIO": 65599n,
                            "EOVERFLOW": 65600n,
                            "EOWNERDEAD": 65601n,
                            "EPERM": 65602n,
                            "EPIPE": 65603n,
                            "EPROTO": 65604n,
                            "EPROTONOSUPPORT": 65605n,
                            "EPROTOTYPE": 65606n,
                            "ERANGE": 65607n,
                            "EROFS": 65608n,
                            "ESPIPE": 65609n,
                            "ESRCH": 65610n,
                            "ESTALE": 65611n,
                            "ETIMEDOUT": 65613n,
                            "ETXTBSY": 65614n,
                            "EXDEV": 65615n,
                            "ESOCKTNOSUPPORT": 65630n,
                            "EPFNOSUPPORT": 65632n,
                            "ESHUTDOWN": 65644n,
                            "EHOSTDOWN": 65648n,
                            "ENODATA": 65649n,
                            "EHOSTNOTFOUND": 131073n,
                            "ESOCKETERROR": 131074n,
                            "EOPNOTSUPP": 65597n,
                            "EWOULDBLOCK": 65542n
                        };
                    }
                    static $h = 131103;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(369367318559),
    {
      "t": 131103,
      "n": "SUCCESS",
      "d": 131103,
      "h": 369367318559,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(369367318559),
//--TRIMMABLE-BOUNDARY-START(8590065695),
    {
      "t": 131103,
      "n": "E2BIG",
      "d": 131103,
      "h": 8590065695,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590065695),
//--TRIMMABLE-BOUNDARY-START(12885032991),
    {
      "t": 131103,
      "n": "EACCES",
      "d": 131103,
      "h": 12885032991,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885032991),
//--TRIMMABLE-BOUNDARY-START(17180000287),
    {
      "t": 131103,
      "n": "EADDRINUSE",
      "d": 131103,
      "h": 17180000287,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180000287),
//--TRIMMABLE-BOUNDARY-START(21474967583),
    {
      "t": 131103,
      "n": "EADDRNOTAVAIL",
      "d": 131103,
      "h": 21474967583,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474967583),
//--TRIMMABLE-BOUNDARY-START(25769934879),
    {
      "t": 131103,
      "n": "EAFNOSUPPORT",
      "d": 131103,
      "h": 25769934879,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25769934879),
//--TRIMMABLE-BOUNDARY-START(30064902175),
    {
      "t": 131103,
      "n": "EAGAIN",
      "d": 131103,
      "h": 30064902175,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30064902175),
//--TRIMMABLE-BOUNDARY-START(34359869471),
    {
      "t": 131103,
      "n": "EALREADY",
      "d": 131103,
      "h": 34359869471,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34359869471),
//--TRIMMABLE-BOUNDARY-START(38654836767),
    {
      "t": 131103,
      "n": "EBADF",
      "d": 131103,
      "h": 38654836767,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654836767),
//--TRIMMABLE-BOUNDARY-START(42949804063),
    {
      "t": 131103,
      "n": "EBADMSG",
      "d": 131103,
      "h": 42949804063,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949804063),
//--TRIMMABLE-BOUNDARY-START(47244771359),
    {
      "t": 131103,
      "n": "EBUSY",
      "d": 131103,
      "h": 47244771359,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47244771359),
//--TRIMMABLE-BOUNDARY-START(51539738655),
    {
      "t": 131103,
      "n": "ECANCELED",
      "d": 131103,
      "h": 51539738655,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539738655),
//--TRIMMABLE-BOUNDARY-START(55834705951),
    {
      "t": 131103,
      "n": "ECHILD",
      "d": 131103,
      "h": 55834705951,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834705951),
//--TRIMMABLE-BOUNDARY-START(60129673247),
    {
      "t": 131103,
      "n": "ECONNABORTED",
      "d": 131103,
      "h": 60129673247,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129673247),
//--TRIMMABLE-BOUNDARY-START(64424640543),
    {
      "t": 131103,
      "n": "ECONNREFUSED",
      "d": 131103,
      "h": 64424640543,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424640543),
//--TRIMMABLE-BOUNDARY-START(68719607839),
    {
      "t": 131103,
      "n": "ECONNRESET",
      "d": 131103,
      "h": 68719607839,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68719607839),
//--TRIMMABLE-BOUNDARY-START(73014575135),
    {
      "t": 131103,
      "n": "EDEADLK",
      "d": 131103,
      "h": 73014575135,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014575135),
//--TRIMMABLE-BOUNDARY-START(77309542431),
    {
      "t": 131103,
      "n": "EDESTADDRREQ",
      "d": 131103,
      "h": 77309542431,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77309542431),
//--TRIMMABLE-BOUNDARY-START(81604509727),
    {
      "t": 131103,
      "n": "EDOM",
      "d": 131103,
      "h": 81604509727,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604509727),
//--TRIMMABLE-BOUNDARY-START(85899477023),
    {
      "t": 131103,
      "n": "EDQUOT",
      "d": 131103,
      "h": 85899477023,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899477023),
//--TRIMMABLE-BOUNDARY-START(90194444319),
    {
      "t": 131103,
      "n": "EEXIST",
      "d": 131103,
      "h": 90194444319,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194444319),
//--TRIMMABLE-BOUNDARY-START(94489411615),
    {
      "t": 131103,
      "n": "EFAULT",
      "d": 131103,
      "h": 94489411615,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489411615),
//--TRIMMABLE-BOUNDARY-START(98784378911),
    {
      "t": 131103,
      "n": "EFBIG",
      "d": 131103,
      "h": 98784378911,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784378911),
//--TRIMMABLE-BOUNDARY-START(111669280799),
    {
      "t": 131103,
      "n": "EHOSTUNREACH",
      "d": 131103,
      "h": 111669280799,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669280799),
//--TRIMMABLE-BOUNDARY-START(115964248095),
    {
      "t": 131103,
      "n": "EIDRM",
      "d": 131103,
      "h": 115964248095,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964248095),
//--TRIMMABLE-BOUNDARY-START(120259215391),
    {
      "t": 131103,
      "n": "EILSEQ",
      "d": 131103,
      "h": 120259215391,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259215391),
//--TRIMMABLE-BOUNDARY-START(124554182687),
    {
      "t": 131103,
      "n": "EINPROGRESS",
      "d": 131103,
      "h": 124554182687,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554182687),
//--TRIMMABLE-BOUNDARY-START(128849149983),
    {
      "t": 131103,
      "n": "EINTR",
      "d": 131103,
      "h": 128849149983,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849149983),
//--TRIMMABLE-BOUNDARY-START(133144117279),
    {
      "t": 131103,
      "n": "EINVAL",
      "d": 131103,
      "h": 133144117279,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144117279),
//--TRIMMABLE-BOUNDARY-START(137439084575),
    {
      "t": 131103,
      "n": "EIO",
      "d": 131103,
      "h": 137439084575,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439084575),
//--TRIMMABLE-BOUNDARY-START(141734051871),
    {
      "t": 131103,
      "n": "EISCONN",
      "d": 131103,
      "h": 141734051871,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734051871),
//--TRIMMABLE-BOUNDARY-START(146029019167),
    {
      "t": 131103,
      "n": "EISDIR",
      "d": 131103,
      "h": 146029019167,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029019167),
//--TRIMMABLE-BOUNDARY-START(150323986463),
    {
      "t": 131103,
      "n": "ELOOP",
      "d": 131103,
      "h": 150323986463,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150323986463),
//--TRIMMABLE-BOUNDARY-START(154618953759),
    {
      "t": 131103,
      "n": "EMFILE",
      "d": 131103,
      "h": 154618953759,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154618953759),
//--TRIMMABLE-BOUNDARY-START(158913921055),
    {
      "t": 131103,
      "n": "EMLINK",
      "d": 131103,
      "h": 158913921055,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158913921055),
//--TRIMMABLE-BOUNDARY-START(163208888351),
    {
      "t": 131103,
      "n": "EMSGSIZE",
      "d": 131103,
      "h": 163208888351,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163208888351),
//--TRIMMABLE-BOUNDARY-START(167503855647),
    {
      "t": 131103,
      "n": "EMULTIHOP",
      "d": 131103,
      "h": 167503855647,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167503855647),
//--TRIMMABLE-BOUNDARY-START(171798822943),
    {
      "t": 131103,
      "n": "ENAMETOOLONG",
      "d": 131103,
      "h": 171798822943,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171798822943),
//--TRIMMABLE-BOUNDARY-START(176093790239),
    {
      "t": 131103,
      "n": "ENETDOWN",
      "d": 131103,
      "h": 176093790239,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176093790239),
//--TRIMMABLE-BOUNDARY-START(180388757535),
    {
      "t": 131103,
      "n": "ENETRESET",
      "d": 131103,
      "h": 180388757535,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180388757535),
//--TRIMMABLE-BOUNDARY-START(184683724831),
    {
      "t": 131103,
      "n": "ENETUNREACH",
      "d": 131103,
      "h": 184683724831,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(184683724831),
//--TRIMMABLE-BOUNDARY-START(188978692127),
    {
      "t": 131103,
      "n": "ENFILE",
      "d": 131103,
      "h": 188978692127,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(188978692127),
//--TRIMMABLE-BOUNDARY-START(193273659423),
    {
      "t": 131103,
      "n": "ENOBUFS",
      "d": 131103,
      "h": 193273659423,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193273659423),
//--TRIMMABLE-BOUNDARY-START(201863594015),
    {
      "t": 131103,
      "n": "ENODEV",
      "d": 131103,
      "h": 201863594015,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(201863594015),
//--TRIMMABLE-BOUNDARY-START(206158561311),
    {
      "t": 131103,
      "n": "ENOENT",
      "d": 131103,
      "h": 206158561311,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206158561311),
//--TRIMMABLE-BOUNDARY-START(210453528607),
    {
      "t": 131103,
      "n": "ENOEXEC",
      "d": 131103,
      "h": 210453528607,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(210453528607),
//--TRIMMABLE-BOUNDARY-START(214748495903),
    {
      "t": 131103,
      "n": "ENOLCK",
      "d": 131103,
      "h": 214748495903,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(214748495903),
//--TRIMMABLE-BOUNDARY-START(219043463199),
    {
      "t": 131103,
      "n": "ENOLINK",
      "d": 131103,
      "h": 219043463199,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219043463199),
//--TRIMMABLE-BOUNDARY-START(223338430495),
    {
      "t": 131103,
      "n": "ENOMEM",
      "d": 131103,
      "h": 223338430495,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(223338430495),
//--TRIMMABLE-BOUNDARY-START(227633397791),
    {
      "t": 131103,
      "n": "ENOMSG",
      "d": 131103,
      "h": 227633397791,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(227633397791),
//--TRIMMABLE-BOUNDARY-START(231928365087),
    {
      "t": 131103,
      "n": "ENOPROTOOPT",
      "d": 131103,
      "h": 231928365087,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(231928365087),
//--TRIMMABLE-BOUNDARY-START(236223332383),
    {
      "t": 131103,
      "n": "ENOSPC",
      "d": 131103,
      "h": 236223332383,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(236223332383),
//--TRIMMABLE-BOUNDARY-START(240518299679),
    {
      "t": 131103,
      "n": "ENOSYS",
      "d": 131103,
      "h": 240518299679,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(240518299679),
//--TRIMMABLE-BOUNDARY-START(244813266975),
    {
      "t": 131103,
      "n": "ENOTCONN",
      "d": 131103,
      "h": 244813266975,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(244813266975),
//--TRIMMABLE-BOUNDARY-START(249108234271),
    {
      "t": 131103,
      "n": "ENOTDIR",
      "d": 131103,
      "h": 249108234271,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(249108234271),
//--TRIMMABLE-BOUNDARY-START(253403201567),
    {
      "t": 131103,
      "n": "ENOTEMPTY",
      "d": 131103,
      "h": 253403201567,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(253403201567),
//--TRIMMABLE-BOUNDARY-START(257698168863),
    {
      "t": 131103,
      "n": "ENOTRECOVERABLE",
      "d": 131103,
      "h": 257698168863,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(257698168863),
//--TRIMMABLE-BOUNDARY-START(261993136159),
    {
      "t": 131103,
      "n": "ENOTSOCK",
      "d": 131103,
      "h": 261993136159,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(261993136159),
//--TRIMMABLE-BOUNDARY-START(266288103455),
    {
      "t": 131103,
      "n": "ENOTSUP",
      "d": 131103,
      "h": 266288103455,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(266288103455),
//--TRIMMABLE-BOUNDARY-START(270583070751),
    {
      "t": 131103,
      "n": "ENOTTY",
      "d": 131103,
      "h": 270583070751,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(270583070751),
//--TRIMMABLE-BOUNDARY-START(274878038047),
    {
      "t": 131103,
      "n": "ENXIO",
      "d": 131103,
      "h": 274878038047,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(274878038047),
//--TRIMMABLE-BOUNDARY-START(283467972639),
    {
      "t": 131103,
      "n": "EOVERFLOW",
      "d": 131103,
      "h": 283467972639,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(283467972639),
//--TRIMMABLE-BOUNDARY-START(287762939935),
    {
      "t": 131103,
      "n": "EOWNERDEAD",
      "d": 131103,
      "h": 287762939935,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(287762939935),
//--TRIMMABLE-BOUNDARY-START(292057907231),
    {
      "t": 131103,
      "n": "EPERM",
      "d": 131103,
      "h": 292057907231,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(292057907231),
//--TRIMMABLE-BOUNDARY-START(300647841823),
    {
      "t": 131103,
      "n": "EPIPE",
      "d": 131103,
      "h": 300647841823,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(300647841823),
//--TRIMMABLE-BOUNDARY-START(304942809119),
    {
      "t": 131103,
      "n": "EPROTO",
      "d": 131103,
      "h": 304942809119,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(304942809119),
//--TRIMMABLE-BOUNDARY-START(309237776415),
    {
      "t": 131103,
      "n": "EPROTONOSUPPORT",
      "d": 131103,
      "h": 309237776415,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(309237776415),
//--TRIMMABLE-BOUNDARY-START(313532743711),
    {
      "t": 131103,
      "n": "EPROTOTYPE",
      "d": 131103,
      "h": 313532743711,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(313532743711),
//--TRIMMABLE-BOUNDARY-START(317827711007),
    {
      "t": 131103,
      "n": "ERANGE",
      "d": 131103,
      "h": 317827711007,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(317827711007),
//--TRIMMABLE-BOUNDARY-START(322122678303),
    {
      "t": 131103,
      "n": "EROFS",
      "d": 131103,
      "h": 322122678303,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(322122678303),
//--TRIMMABLE-BOUNDARY-START(339302547487),
    {
      "t": 131103,
      "n": "ESPIPE",
      "d": 131103,
      "h": 339302547487,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(339302547487),
//--TRIMMABLE-BOUNDARY-START(343597514783),
    {
      "t": 131103,
      "n": "ESRCH",
      "d": 131103,
      "h": 343597514783,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(343597514783),
//--TRIMMABLE-BOUNDARY-START(347892482079),
    {
      "t": 131103,
      "n": "ESTALE",
      "d": 131103,
      "h": 347892482079,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(347892482079),
//--TRIMMABLE-BOUNDARY-START(352187449375),
    {
      "t": 131103,
      "n": "ETIMEDOUT",
      "d": 131103,
      "h": 352187449375,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(352187449375),
//--TRIMMABLE-BOUNDARY-START(356482416671),
    {
      "t": 131103,
      "n": "ETXTBSY",
      "d": 131103,
      "h": 356482416671,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(356482416671),
//--TRIMMABLE-BOUNDARY-START(365072351263),
    {
      "t": 131103,
      "n": "EXDEV",
      "d": 131103,
      "h": 365072351263,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(365072351263),
//--TRIMMABLE-BOUNDARY-START(335007580191),
    {
      "t": 131103,
      "n": "ESOCKTNOSUPPORT",
      "d": 131103,
      "h": 335007580191,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(335007580191),
//--TRIMMABLE-BOUNDARY-START(296352874527),
    {
      "t": 131103,
      "n": "EPFNOSUPPORT",
      "d": 131103,
      "h": 296352874527,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(296352874527),
//--TRIMMABLE-BOUNDARY-START(326417645599),
    {
      "t": 131103,
      "n": "ESHUTDOWN",
      "d": 131103,
      "h": 326417645599,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(326417645599),
//--TRIMMABLE-BOUNDARY-START(103079346207),
    {
      "t": 131103,
      "n": "EHOSTDOWN",
      "d": 131103,
      "h": 103079346207,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079346207),
//--TRIMMABLE-BOUNDARY-START(197568626719),
    {
      "t": 131103,
      "n": "ENODATA",
      "d": 131103,
      "h": 197568626719,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(197568626719),
//--TRIMMABLE-BOUNDARY-START(107374313503),
    {
      "t": 131103,
      "n": "EHOSTNOTFOUND",
      "d": 131103,
      "h": 107374313503,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374313503),
//--TRIMMABLE-BOUNDARY-START(330712612895),
    {
      "t": 131103,
      "n": "ESOCKETERROR",
      "d": 131103,
      "h": 330712612895,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(330712612895),
//--TRIMMABLE-BOUNDARY-START(279173005343),
    {
      "t": 131103,
      "n": "EOPNOTSUPP",
      "d": 131103,
      "h": 279173005343,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(279173005343),
//--TRIMMABLE-BOUNDARY-START(360777383967),
    {
      "t": 131103,
      "n": "EWOULDBLOCK",
      "d": 131103,
      "h": 360777383967,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(360777383967)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098399),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131103,
      "h": 4295098399,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098399)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "d": 65567,
  "h": 131103
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `Interop.Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(131103)
            
            //--TRIMMABLE-BOUNDARY-START(196639)
            static $_ErrorInfo;
            static get ErrorInfo()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_ErrorInfo ??= $asm.$nstr("$sim.Interop.ErrorInfo", ($self) => class ErrorInfo extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295163935)
                    /*Error*/  get _error() { return this.$getField(0, $.$sim.Interop.Error); }
                    /*Error*/  set _error(value) { this.$setField(0, $.$sim.Interop.Error, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295163935)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590131231)
                    /*int*/  get _rawErrno() { return this.$getField(4, $.$$.System.Int32); }
                    /*int*/  set _rawErrno(value) { this.$setField(4, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590131231)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885098527)
                    $ctor$3(/*int*/ errno)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885098527);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._error = $.$sim.Interop.Sys.ConvertErrorPlatformToPal(errno);
                            this._rawErrno = errno;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885098527)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180065823)
                    $ctor$4(/*Error*/ error)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180065823);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._error = error;
                            this._rawErrno = -1;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180065823)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000415)
                    /*Error */ get Error()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34359935007);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._error;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000415)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539804191)
                    /*int */ get RawErrno()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42949869599);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._rawErrno === -1 ? (this._rawErrno = $.$sim.Interop.Sys.ConvertErrorPalToPlatform(this._error)) : this._rawErrno;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51539804191)
                    
                    //--TRIMMABLE-BOUNDARY-START(47244836895)
                    /*string */ GetErrorMessage()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47244836895);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$sim.Interop.Sys.StrError(this.RawErrno);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47244836895)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 55834771487, 330712612865)
                    static/*conventional*/ /*string */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55834771487);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return `RawErrno: ${this.RawErrno} Error: ${this.Error} GetErrorMessage: ${this.GetErrorMessage()}`;
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$sim.Interop.ErrorInfo.ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 55834771487, 330712612865)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._error = this._error;
                        copy._rawErrno = this._rawErrno;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4295163935)
                        this._error = 0;
                        //--TRIMMABLE-BOUNDARY-END(4295163935)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590131231)
                        this._rawErrno = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590131231)
                        
                    }
                    static $h = 196639;
                    static $z = 8;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770000415),
    {
      "p": 131103,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359935007,
        "f": 50331656
      },
      "n": "Error",
      "d": 196639,
      "h": 25770000415,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(25770000415),
//--TRIMMABLE-BOUNDARY-START(51539804191),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949869599,
        "f": 50331656
      },
      "n": "RawErrno",
      "d": 196639,
      "h": 51539804191,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(51539804191)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47244836895),
    {
      "r": 1310721,
      "n": "GetErrorMessage",
      "d": 196639,
      "h": 47244836895,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47244836895),
//--TRIMMABLE-BOUNDARY-START(ALL, 55834771487, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 196639,
      "h": 55834771487,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55834771487, 330712612865)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295163935),
    {
      "t": 131103,
      "n": "_error",
      "d": 196639,
      "h": 4295163935,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295163935),
//--TRIMMABLE-BOUNDARY-START(8590131231),
    {
      "t": 655361,
      "n": "_rawErrno",
      "d": 196639,
      "h": 8590131231,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590131231)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885098527),
    {
      "p": [
        {
          "n": "errno",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196639,
      "h": 12885098527,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885098527),
//--TRIMMABLE-BOUNDARY-START(17180065823),
    {
      "p": [
        {
          "n": "error",
          "p": 131103
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 196639,
      "h": 17180065823,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180065823),
//--TRIMMABLE-BOUNDARY-START(21475033119),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196639,
      "h": 21475033119,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475033119)
  ],
  "d": 65567,
  "h": 196639
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Interop.ErrorInfo`; }
                }, $cls, ($v) => $cls.$_ErrorInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196639)
            
            //--TRIMMABLE-BOUNDARY-START(51539673119)
            static /*void */ ThrowExceptionForIoErrno(/*ErrorInfo*/ errorInfo, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(errorInfo.Error !== 0/*Error.SUCCESS*/, "errorInfo.Error != Error.SUCCESS");
                $.$$.System.Diagnostics.Debug.Assert$2(errorInfo.Error !== 65563/*Error.EINTR*/, "EINTR errors should be handled by the native shim and never bubble up to managed code");
                throw $.$sim.Interop.GetExceptionForIoErrno(errorInfo.Clone(), path, isDirError);
            }
            //--TRIMMABLE-BOUNDARY-END(51539673119)
            
            //--TRIMMABLE-BOUNDARY-START(4295032863)
            static /*void */ CheckIo$3(/*Error*/ error, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (error !== 0/*Interop.Error.SUCCESS*/)
                {
                    $.$sim.Interop.ThrowExceptionForIoErrno($.$sim.InteropErrorExtensions.Info(error), path, isDirError);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295032863)
            
            //--TRIMMABLE-BOUNDARY-START(8590000159)
            static /*long */ CheckIo$1(/*long*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (result < 0n)
                {
                    $.$sim.Interop.ThrowExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), path, isDirError);
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000159)
            
            //--TRIMMABLE-BOUNDARY-START(55834640415)
            static /*void */ ThrowIOExceptionForLastError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834640415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sim.Interop.ThrowExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(55834640415)
            
            //--TRIMMABLE-BOUNDARY-START(12884967455)
            static /*int */ CheckIo(/*int*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sim.Interop.CheckIo$1($.$cast(result, $.$$.System.Int64), path, isDirError);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967455)
            
            //--TRIMMABLE-BOUNDARY-START(17179934751)
            static /*IntPtr */ CheckIo$2(/*IntPtr*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sim.Interop.CheckIo$1($.$cast(result, $.$$.System.Int64), path, isDirError);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(17179934751)
            
            //--TRIMMABLE-BOUNDARY-START(21474902047)
            static /*TSafeHandle */ CheckIo$4(TSafeHandle, /*TSafeHandle*/ handle, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (handle.IsInvalid)
                {
                    /*Exception*/ let e = $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), path, isDirError);
                    $.$dsp(handle, TSafeHandle, ($t) => $t.Dispose,);
                    throw e;
                }
                return handle;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902047)
            
            //--TRIMMABLE-BOUNDARY-START(34359803935)
            static /*Exception */ GetExceptionForIoErrno(/*ErrorInfo*/ errorInfo, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    let $switch1 = $switchJumpState1 ?? (errorInfo.Error);
                    switch($switch1)
                    {
                        case 65581/*Error.ENOENT*/:
                        if (!isDirError && (path === null || ParentDirectoryExists(path)))
                        {
                            return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.IO.FileNotFoundException().$ctor$18($.$sim.System.SR.Format$6($.$sim.System.SR.IO_FileNotFound_FileName, path), path) : new $.$$.System.IO.FileNotFoundException().$ctor$19($.$sim.System.SR.IO_FileNotFound);
                        }
                        $switchJumpState1 = 65593/*Error.ENOTDIR*/; /*goto case Error.ENOTDIR*/
                        continue $switchJumpStart1;
                        case 65593/*Error.ENOTDIR*/:
                        return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.IO.DirectoryNotFoundException().$ctor$17($.$sim.System.SR.Format$6($.$sim.System.SR.IO_PathNotFound_Path, path)) : new $.$$.System.IO.DirectoryNotFoundException().$ctor$17($.$sim.System.SR.IO_PathNotFound_NoPathName);
                        case 65538/*Error.EACCES*/:
                        case 65544/*Error.EBADF*/:
                        case 65602/*Error.EPERM*/:
                        /*Exception*/ let inner = $.$sim.Interop.GetIOException(errorInfo.Clone(), null);
                        return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.UnauthorizedAccessException().$ctor$11($.$sim.System.SR.Format$6($.$sim.System.SR.UnauthorizedAccess_IODenied_Path, path), inner) : new $.$$.System.UnauthorizedAccessException().$ctor$11($.$sim.System.SR.UnauthorizedAccess_IODenied_NoPathName, inner);
                        case 65573/*Error.ENAMETOOLONG*/:
                        return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.IO.PathTooLongException().$ctor$17($.$sim.System.SR.Format$6($.$sim.System.SR.IO_PathTooLong_Path, path)) : new $.$$.System.IO.PathTooLongException().$ctor$17($.$sim.System.SR.IO_PathTooLong);
                        case 65542/*Error.EWOULDBLOCK*/:
                        return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.IO.IOException().$ctor$12($.$sim.System.SR.Format$6($.$sim.System.SR.IO_SharingViolation_File, path), errorInfo.RawErrno) : new $.$$.System.IO.IOException().$ctor$12($.$sim.System.SR.IO_SharingViolation_NoFileName, errorInfo.RawErrno);
                        case 65547/*Error.ECANCELED*/:
                        return new $.$$.System.OperationCanceledException().$ctor$9();
                        case 65558/*Error.EFBIG*/:
                        return new $.$$.System.ArgumentOutOfRangeException().$ctor$19("value", $.$sim.System.SR.ArgumentOutOfRange_FileLengthTooBig);
                        case 65556/*Error.EEXIST*/:
                        if (!$.$$.System.String.IsNullOrEmpty(path))
                        {
                            return new $.$$.System.IO.IOException().$ctor$12($.$sim.System.SR.Format$6($.$sim.System.SR.IO_FileExists_Name, path), errorInfo.RawErrno);
                        }
                        $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                        continue $switchJumpStart1;
                        default:
                        return $.$sim.Interop.GetIOException(errorInfo.Clone(), path);
                        /*static bool*/  function ParentDirectoryExists(/*string*/ fullPath)
                        {
                            /*string?*/ let parentPath = $.$$.System.IO.Path.GetDirectoryName$1($.$$.System.IO.Path.TrimEndingDirectorySeparator$1(fullPath));
                            return $.$$.System.IO.Directory.Exists(parentPath);
                        }
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359803935)
            
            //--TRIMMABLE-BOUNDARY-START(38654771231)
            static /*Exception */ GetIOException(/*Interop.ErrorInfo*/ errorInfo, /*string?*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let msg = errorInfo.GetErrorMessage();
                return new $.$$.System.IO.IOException().$ctor$12($.$$.System.String.IsNullOrEmpty(path) ? msg : `${msg} : '${path}'`, errorInfo.RawErrno);
            }
            //--TRIMMABLE-BOUNDARY-END(38654771231)
            
            static $h = 65567;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539673119),
    {
      "r": 65537,
      "p": [
        {
          "n": "errorInfo",
          "p": 196639
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "isDirError",
          "p": 262145
        }
      ],
      "n": "ThrowExceptionForIoErrno",
      "d": 65567,
      "h": 51539673119,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51539673119),
//--TRIMMABLE-BOUNDARY-START(4295032863),
    {
      "r": 65537,
      "p": [
        {
          "n": "error",
          "p": 131103
        },
        {
          "n": "path",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "isDirError",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "CheckIo",
      "o": "@$3",
      "d": 65567,
      "h": 4295032863,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295032863),
//--TRIMMABLE-BOUNDARY-START(8590000159),
    {
      "r": 917505,
      "p": [
        {
          "n": "result",
          "p": 917505
        },
        {
          "n": "path",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "isDirError",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "CheckIo",
      "o": "@$1",
      "d": 65567,
      "h": 8590000159,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590000159),
//--TRIMMABLE-BOUNDARY-START(55834640415),
    {
      "r": 65537,
      "n": "ThrowIOExceptionForLastError",
      "d": 65567,
      "h": 55834640415,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55834640415),
//--TRIMMABLE-BOUNDARY-START(12884967455),
    {
      "r": 655361,
      "p": [
        {
          "n": "result",
          "p": 655361
        },
        {
          "n": "path",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "isDirError",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "CheckIo",
      "d": 65567,
      "h": 12884967455,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12884967455),
//--TRIMMABLE-BOUNDARY-START(17179934751),
    {
      "r": 786433,
      "p": [
        {
          "n": "result",
          "p": 786433
        },
        {
          "n": "path",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "isDirError",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "CheckIo",
      "o": "@$2",
      "d": 65567,
      "h": 17179934751,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17179934751),
//--TRIMMABLE-BOUNDARY-START(21474902047),
    {
      "r": (TSafeHandle) => TSafeHandle.$h,
      "p": [
        {
          "n": "handle",
          "p": (TSafeHandle) => TSafeHandle.$h
        },
        {
          "n": "path",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "isDirError",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "g": [
        "TSafeHandle"
      ],
      "n": "CheckIo",
      "o": "@$4",
      "d": 65567,
      "h": 21474902047,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(21474902047),
//--TRIMMABLE-BOUNDARY-START(34359803935),
    {
      "r": 79888385,
      "p": [
        {
          "n": "errorInfo",
          "p": 196639
        },
        {
          "n": "path",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "isDirError",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "GetExceptionForIoErrno",
      "d": 65567,
      "h": 34359803935,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34359803935),
//--TRIMMABLE-BOUNDARY-START(38654771231),
    {
      "r": 79888385,
      "p": [
        {
          "n": "errorInfo",
          "p": 196639
        },
        {
          "n": "path",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": "GetIOException",
      "d": 65567,
      "h": 38654771231,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38654771231)
  ],
  "j": [262175,327711,131103,196639
  ],
  "h": 65567
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65567)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048607)
        $asm.$cls("$sim.InteropErrorExtensions", ($self) => class InteropErrorExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4296015903)
            static /*Interop.ErrorInfo */ Info(/*this Interop.Error*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sim.Interop.ErrorInfo().$ctor$4(error);
            }
            //--TRIMMABLE-BOUNDARY-END(4296015903)
            
            static $h = 1048607;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296015903),
    {
      "r": 196639,
      "p": [
        {
          "n": "error",
          "p": 131103
        }
      ],
      "n": "Info",
      "d": 1048607,
      "h": 4296015903,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296015903)
  ],
  "h": 1048607
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `InteropErrorExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048607)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769503)
        $asm.$cls("$sim.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(519692812319)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(519692812319)
            
            //--TRIMMABLE-BOUNDARY-START(511102877727)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(511102877727)
            
            //--TRIMMABLE-BOUNDARY-START(515397845023)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395138760735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$sim.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.IO.MemoryMappedFiles", $.$sim.System.SR.$type.Assembly);
                    $.$sim.System.SR.s_resourceManager = temp;
                }
                return $.$sim.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(515397845023)
            
            //--TRIMMABLE-BOUNDARY-START(55836344351)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340068895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sim.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532577714207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sim.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(55836344351)
            
            //--TRIMMABLE-BOUNDARY-START(442383400991)
            static /*string */ get IO_FileNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699807263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to find the specified file.";
            }
            //--TRIMMABLE-BOUNDARY-END(442383400991)
            
            //--TRIMMABLE-BOUNDARY-START(446678368287)
            static /*string */ get IO_FileNotFound_FileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289741855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find file '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(446678368287)
            
            //--TRIMMABLE-BOUNDARY-START(103080984607)
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080984607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Could not find file '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(103080984607)
            
            //--TRIMMABLE-BOUNDARY-START(433793466399)
            static /*string */ get IO_AlreadyExists_Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519938079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create '{0}' because a file or directory with the same name already exists.";
            }
            //--TRIMMABLE-BOUNDARY-END(433793466399)
            
            //--TRIMMABLE-BOUNDARY-START(94491050015)
            static /*string */ FormatIO_AlreadyExists_Name(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491050015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot create '{0}' because a file or directory with the same name already exists.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(94491050015)
            
            //--TRIMMABLE-BOUNDARY-START(438088433695)
            static /*string */ get IO_FileExists_Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109872671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The file '{0}' already exists.";
            }
            //--TRIMMABLE-BOUNDARY-END(438088433695)
            
            //--TRIMMABLE-BOUNDARY-START(98786017311)
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786017311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The file '{0}' already exists.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(98786017311)
            
            //--TRIMMABLE-BOUNDARY-START(472448172063)
            static /*string */ get IO_SharingViolation_File()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317829349407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            //--TRIMMABLE-BOUNDARY-END(472448172063)
            
            //--TRIMMABLE-BOUNDARY-START(115965886495)
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965886495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(115965886495)
            
            //--TRIMMABLE-BOUNDARY-START(476743139359)
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326419283999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The process cannot access the file because it is being used by another process.";
            }
            //--TRIMMABLE-BOUNDARY-END(476743139359)
            
            //--TRIMMABLE-BOUNDARY-START(459563270175)
            static /*string */ get IO_PathNotFound_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059545631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find a part of the path '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(459563270175)
            
            //--TRIMMABLE-BOUNDARY-START(107375951903)
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375951903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Could not find a part of the path '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(107375951903)
            
            //--TRIMMABLE-BOUNDARY-START(455268302879)
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469611039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find a part of the path.";
            }
            //--TRIMMABLE-BOUNDARY-END(455268302879)
            
            //--TRIMMABLE-BOUNDARY-START(463858237471)
            static /*string */ get IO_PathTooLong()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300649480223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            //--TRIMMABLE-BOUNDARY-END(463858237471)
            
            //--TRIMMABLE-BOUNDARY-START(541167648799)
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412318629919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Access to the path '{0}' is denied.";
            }
            //--TRIMMABLE-BOUNDARY-END(541167648799)
            
            //--TRIMMABLE-BOUNDARY-START(120260853791)
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260853791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Access to the path '{0}' is denied.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(120260853791)
            
            //--TRIMMABLE-BOUNDARY-START(536872681503)
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403728695327);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Access to the path is denied.";
            }
            //--TRIMMABLE-BOUNDARY-END(536872681503)
            
            //--TRIMMABLE-BOUNDARY-START(12886671391)
            static /*string */ get Argument_MapNameEmptyString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440722975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Map name cannot be an empty string.";
            }
            //--TRIMMABLE-BOUNDARY-END(12886671391)
            
            //--TRIMMABLE-BOUNDARY-START(8591704095)
            static /*string */ get Argument_EmptyFile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850788383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A positive capacity must be specified for a Memory Mapped File backed by an empty file.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591704095)
            
            //--TRIMMABLE-BOUNDARY-START(25771573279)
            static /*string */ get Argument_NewMMFWriteAccessNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210526751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "MemoryMappedFileAccess.Write is not permitted when creating new memory mapped files. Use MemoryMappedFileAccess.ReadWrite instead.";
            }
            //--TRIMMABLE-BOUNDARY-END(25771573279)
            
            //--TRIMMABLE-BOUNDARY-START(30066540575)
            static /*string */ get Argument_ReadAccessWithLargeCapacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800461343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "When specifying MemoryMappedFileAccess.Read access, the capacity must not be larger than the file size.";
            }
            //--TRIMMABLE-BOUNDARY-END(30066540575)
            
            //--TRIMMABLE-BOUNDARY-START(17181638687)
            static /*string */ get Argument_NewMMFAppendModeNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030657567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "FileMode.Append is not permitted when creating new memory mapped files. Instead, use MemoryMappedFileView to ensure write-only access within a specified region.";
            }
            //--TRIMMABLE-BOUNDARY-END(17181638687)
            
            //--TRIMMABLE-BOUNDARY-START(21476605983)
            static /*string */ get Argument_NewMMFTruncateModeNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620592159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "FileMode.Truncate is not permitted when creating new memory mapped files.";
            }
            //--TRIMMABLE-BOUNDARY-END(21476605983)
            
            //--TRIMMABLE-BOUNDARY-START(38656475167)
            static /*string */ get ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980330527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The capacity cannot be greater than the size of the system's logical address space.";
            }
            //--TRIMMABLE-BOUNDARY-END(38656475167)
            
            //--TRIMMABLE-BOUNDARY-START(42951442463)
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570265119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Specified file length was too large for the file system.";
            }
            //--TRIMMABLE-BOUNDARY-END(42951442463)
            
            //--TRIMMABLE-BOUNDARY-START(47246409759)
            static /*string */ get ArgumentOutOfRange_PositiveOrDefaultCapacityRequired()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160199711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The capacity must be greater than or equal to 0. 0 represents the size of the file being mapped.";
            }
            //--TRIMMABLE-BOUNDARY-END(47246409759)
            
            //--TRIMMABLE-BOUNDARY-START(51541377055)
            static /*string */ get ArgumentOutOfRange_PositiveOrDefaultSizeRequired()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750134303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The size must be greater than or equal to 0. If 0 is specified, the view extends from the specified offset to the end of the file mapping.";
            }
            //--TRIMMABLE-BOUNDARY-END(51541377055)
            
            //--TRIMMABLE-BOUNDARY-START(34361507871)
            static /*string */ get ArgumentOutOfRange_CapacityGEFileSizeRequired()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390395935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The capacity may not be smaller than the file size.";
            }
            //--TRIMMABLE-BOUNDARY-END(34361507871)
            
            //--TRIMMABLE-BOUNDARY-START(450973335583)
            static /*string */ get IO_NotEnoughMemory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879676447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Not enough memory to map view.";
            }
            //--TRIMMABLE-BOUNDARY-END(450973335583)
            
            //--TRIMMABLE-BOUNDARY-START(429498499103)
            static /*string */ get InvalidOperation_CantCreateFileMapping()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930003487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create file mapping.";
            }
            //--TRIMMABLE-BOUNDARY-END(429498499103)
            
            //--TRIMMABLE-BOUNDARY-START(481038106655)
            static /*string */ get NotSupported_MMViewStreamsFixedLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335009218591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "MemoryMappedViewStreams are fixed length.";
            }
            //--TRIMMABLE-BOUNDARY-END(481038106655)
            
            //--TRIMMABLE-BOUNDARY-START(485333073951)
            static /*string */ get NotSupported_UnreadableStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343599153183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stream does not support reading.";
            }
            //--TRIMMABLE-BOUNDARY-END(485333073951)
            
            //--TRIMMABLE-BOUNDARY-START(489628041247)
            static /*string */ get NotSupported_UnwritableStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352189087775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stream does not support writing.";
            }
            //--TRIMMABLE-BOUNDARY-END(489628041247)
            
            //--TRIMMABLE-BOUNDARY-START(498217975839)
            static /*string */ get ObjectDisposed_ViewAccessorClosed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369368956959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot access a closed accessor.";
            }
            //--TRIMMABLE-BOUNDARY-END(498217975839)
            
            //--TRIMMABLE-BOUNDARY-START(493923008543)
            static /*string */ get ObjectDisposed_StreamIsClosed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360779022367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot access a closed Stream.";
            }
            //--TRIMMABLE-BOUNDARY-END(493923008543)
            
            //--TRIMMABLE-BOUNDARY-START(506807910431)
            static /*string */ get PlatformNotSupported_NamedMaps()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548826143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Named maps are not supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(506807910431)
            
            //--TRIMMABLE-BOUNDARY-START(468153204767)
            static /*string */ get IO_PathTooLong_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309239414815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            //--TRIMMABLE-BOUNDARY-END(468153204767)
            
            //--TRIMMABLE-BOUNDARY-START(111670919199)
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670919199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(111670919199)
            
            //--TRIMMABLE-BOUNDARY-START(502512943135)
            static /*string */ get PlatformNotSupported_MemoryMappedFiles()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377958891551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "System.IO.MemoryMappedFiles is not supported on this platform.";
            }
            //--TRIMMABLE-BOUNDARY-END(502512943135)
            
            //--TRIMMABLE-BOUNDARY-START(523987779615)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(523987779615)
            
            //--TRIMMABLE-BOUNDARY-START(425203531807)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(425203531807);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(425203531807)
            
            //--TRIMMABLE-BOUNDARY-START(545462616095)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(545462616095);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sim.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(545462616095)
            
            //--TRIMMABLE-BOUNDARY-START(416613597215)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416613597215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sim.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(416613597215)
            
            //--TRIMMABLE-BOUNDARY-START(420908564511)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420908564511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sim.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(420908564511)
            
            //--TRIMMABLE-BOUNDARY-START(60131311647)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131311647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(60131311647)
            
            //--TRIMMABLE-BOUNDARY-START(64426278943)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426278943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(64426278943)
            
            //--TRIMMABLE-BOUNDARY-START(68721246239)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721246239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(68721246239)
            
            //--TRIMMABLE-BOUNDARY-START(73016213535)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016213535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sim.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(73016213535)
            
            //--TRIMMABLE-BOUNDARY-START(77311180831)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311180831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(77311180831)
            
            //--TRIMMABLE-BOUNDARY-START(81606148127)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606148127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(81606148127)
            
            //--TRIMMABLE-BOUNDARY-START(85901115423)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901115423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(85901115423)
            
            //--TRIMMABLE-BOUNDARY-START(90196082719)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196082719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sim.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(90196082719)
            
            //--TRIMMABLE-BOUNDARY-START(4296736799)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(523987779615)
                    this.s_usingResourceKeys = $.$sim.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(523987779615)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296736799)
            
            static $h = 1769503;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 1769503
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769503)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507359)
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedView", ($self) => class MemoryMappedView extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181376543)
            /*SafeMemoryMappedViewHandle*/ _viewHandle = null;
            //--TRIMMABLE-BOUNDARY-END(17181376543)
            
            //--TRIMMABLE-BOUNDARY-START(8591441951)
            /*long*/ _pointerOffset = 0n;
            //--TRIMMABLE-BOUNDARY-END(8591441951)
            
            //--TRIMMABLE-BOUNDARY-START(12886409247)
            /*long*/ _size = 0n;
            //--TRIMMABLE-BOUNDARY-END(12886409247)
            
            //--TRIMMABLE-BOUNDARY-START(4296474655)
            /*MemoryMappedFileAccess*/ _access = 0;
            //--TRIMMABLE-BOUNDARY-END(4296474655)
            
            //--TRIMMABLE-BOUNDARY-START(21476343839)
            $ctor$1(/*SafeMemoryMappedViewHandle*/ viewHandle, /*long*/ pointerOffset, /*long*/ size, /*MemoryMappedFileAccess*/ access)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476343839);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(viewHandle !== null, "viewHandle != null");
                    this._viewHandle = viewHandle;
                    this._pointerOffset = pointerOffset;
                    this._size = size;
                    this._access = access;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476343839)
            
            //--TRIMMABLE-BOUNDARY-START(115965624351)
            /*SafeMemoryMappedViewHandle */ get ViewHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900853279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._viewHandle;
            }
            //--TRIMMABLE-BOUNDARY-END(115965624351)
            
            //--TRIMMABLE-BOUNDARY-START(103080722463)
            /*long */ get PointerOffset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720984095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._pointerOffset;
            }
            //--TRIMMABLE-BOUNDARY-END(103080722463)
            
            //--TRIMMABLE-BOUNDARY-START(107375689759)
            /*long */ get Size()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310918687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._size;
            }
            //--TRIMMABLE-BOUNDARY-END(107375689759)
            
            //--TRIMMABLE-BOUNDARY-START(25771311135)
            /*MemoryMappedFileAccess */ get Access()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541114911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._access;
            }
            //--TRIMMABLE-BOUNDARY-END(25771311135)
            
            //--TRIMMABLE-BOUNDARY-START(38656213023)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656213023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._viewHandle.IsClosed)
                {
                    this._viewHandle.Dispose();
                }
                $.$$.System.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(38656213023)
            
            //--TRIMMABLE-BOUNDARY-START(94490787871)
            /*bool */ get IsClosed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131049503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._viewHandle.IsClosed;
            }
            //--TRIMMABLE-BOUNDARY-END(94490787871)
            
            //--TRIMMABLE-BOUNDARY-START(111670657055)
            static /*void */ ValidateSizeAndOffset(/*long*/ size, /*long*/ offset, /*long*/ allocationGranularity, /*out ulong*/ newSize, /*out long*/ extraMemNeeded, /*out long*/ newOffset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670657055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(size >= 0n, "size >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(offset >= 0n, "offset >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(allocationGranularity > 0n, "allocationGranularity > 0");
                extraMemNeeded.$v = offset % allocationGranularity;
                newOffset.$v = offset - extraMemNeeded.$v;
                newSize.$v = (size !== BigInt(0/*MemoryMappedFile.DefaultSize*/)) ? $.$cast(size, $.$$.System.UInt64) + $.$cast(extraMemNeeded.$v, $.$$.System.UInt64) : 0n;
                if ($.$$.System.IntPtr.Size === 4 && newSize.$v > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("size", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111670657055)
            
            //--TRIMMABLE-BOUNDARY-START(30066278431)
            static /*MemoryMappedView */ CreateView(/*SafeMemoryMappedFileHandle*/ memMappedFileHandle, /*MemoryMappedFileAccess*/ access, /*long*/ requestedOffset, /*long*/ requestedSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int64, requestedOffset, memMappedFileHandle._capacity, "offset");
                if (requestedSize > 8192000000000n)
                {
                    throw new $.$$.System.IO.IOException().$ctor$13($.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                if (requestedOffset + requestedSize > memMappedFileHandle._capacity)
                {
                    throw new $.$$.System.UnauthorizedAccessException().$ctor$9();
                }
                $.$$.System.ObjectDisposedException.ThrowIf(memMappedFileHandle.IsClosed, memMappedFileHandle);
                if (requestedSize === BigInt(0/*MemoryMappedFile.DefaultSize*/))
                {
                    requestedSize = memMappedFileHandle._capacity - requestedOffset;
                }
                /*ulong*/ let nativeSize;
                /*long*/ let extraMemNeeded, nativeOffset;
                /*long*/ let pageSize = $.$sim.Interop.Sys.SysConf(2/*Interop.Sys.SysConfName._SC_PAGESIZE*/);
                $.$$.System.Diagnostics.Debug.Assert$2(pageSize > 0n, "pageSize > 0");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.ValidateSizeAndOffset(requestedSize, requestedOffset, pageSize, $.$ref(() => nativeSize, ($v) => nativeSize = $v, $.$$.System.UInt64), $.$ref(() => extraMemNeeded, ($v) => extraMemNeeded = $v, $.$$.System.Int64), $.$ref(() => nativeOffset, ($v) => nativeOffset = $v, $.$$.System.Int64));
                /*Interop.Sys.MemoryMappedFlags*/ let flags = (memMappedFileHandle._access === 3/*MemoryMappedFileAccess.CopyOnWrite*/ || access === 3/*MemoryMappedFileAccess.CopyOnWrite*/) ? 2/*Interop.Sys.MemoryMappedFlags.MAP_PRIVATE*/ : 1/*Interop.Sys.MemoryMappedFlags.MAP_SHARED*/;
                /*SafeFileHandle*/ let fd;
                if (memMappedFileHandle._fileStreamHandle !== null)
                {
                    fd = memMappedFileHandle._fileStreamHandle;
                    $.$$.System.Diagnostics.Debug.Assert$2(!fd.IsInvalid, "!fd.IsInvalid");
                }
                else 
                {
                    fd = new $.$$.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$6(new $.$$.System.IntPtr().$ctor$3(-1), false);
                    flags |= 16/*Interop.Sys.MemoryMappedFlags.MAP_ANONYMOUS*/;
                }
                /*Interop.Sys.MemoryMappedProtections*/ let viewProtForVerification = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(access, true);
                /*Interop.Sys.MemoryMappedProtections*/ let mapProtForVerification = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(memMappedFileHandle._access, true);
                if ((viewProtForVerification & mapProtForVerification) !== viewProtForVerification)
                {
                    throw new $.$$.System.UnauthorizedAccessException().$ctor$9();
                }
                /*Interop.Sys.MemoryMappedProtections*/ let viewProtForCreation = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(access, false);
                /*IntPtr*/ let addr;
                if (nativeSize > 0n)
                {
                    addr = $.$sim.Interop.Sys.MMap($.$$.System.IntPtr.Zero, nativeSize, viewProtForCreation, flags, fd, nativeOffset);
                }
                else 
                {
                    addr = $.$sim.Interop.Sys.MMap($.$$.System.IntPtr.Zero, 1n, viewProtForCreation, flags | 16/*Interop.Sys.MemoryMappedFlags.MAP_ANONYMOUS*/, new $.$$.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$6(new $.$$.System.IntPtr().$ctor$3(-1), false), 0n);
                    requestedSize = 0n;
                    extraMemNeeded = 0n;
                }
                if (addr === $.$$.System.IntPtr.Zero)
                {
                    throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                }
                if (memMappedFileHandle._inheritability === 0/*HandleInheritability.None*/)
                {
                    $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.DisableForkingIfPossible(addr, nativeSize);
                }
                /*var*/ let viewHandle = new $.$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle().$ctor$6(addr, true);
                viewHandle.Initialize$1(nativeSize);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView().$ctor$1(viewHandle, extraMemNeeded, requestedSize, access);
            }
            //--TRIMMABLE-BOUNDARY-END(30066278431)
            
            //--TRIMMABLE-BOUNDARY-START(42951180319)
            /*void */ Flush(/*UIntPtr*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951180319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (capacity === $.$$.System.UIntPtr.Zero)
                {
                    return;
                }
                /*byte**/ let ptr = null;
                try
                {
                    this._viewHandle.AcquirePointer($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typePointer($.$$.System.Byte), () => ptr, ($v) => ptr = $v, null));
                    /*int*/ let result = $.$sim.Interop.Sys.MSync($.$cast(ptr, $.$$.System.IntPtr), $.$cast(capacity, $.$$.System.UInt64), 2/*Interop.Sys.MemoryMappedSyncFlags.MS_SYNC*/ | 16/*Interop.Sys.MemoryMappedSyncFlags.MS_INVALIDATE*/);
                    if (result < 0)
                    {
                        throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                    }
                }
                finally
                {
                    {
                        if (ptr !== null)
                        {
                            this._viewHandle.ReleasePointer();
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951180319)
            
            //--TRIMMABLE-BOUNDARY-START(34361245727)
            static /*void */ DisableForkingIfPossible(/*IntPtr*/ addr, /*ulong*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361245727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (length > 0n)
                {
                    $.$sim.Interop.Sys.MAdvise(addr, length, 1/*Interop.Sys.MemoryAdvice.MADV_DONTFORK*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361245727)
            
            //--TRIMMABLE-BOUNDARY-START(98785755167)
            /*long*/ static MaxProcessAddressSpace = 8192000000000n;
            //--TRIMMABLE-BOUNDARY-END(98785755167)
            
            //--TRIMMABLE-BOUNDARY-START(90195820575)
            static /*Interop.Sys.MemoryMappedProtections */ GetProtections(/*MemoryMappedFileAccess*/ access, /*bool*/ forVerification)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195820575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(access)
                {
                    default:
                    case 1/*MemoryMappedFileAccess.Read*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/;
                    case 2/*MemoryMappedFileAccess.Write*/:
                    return 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/;
                    case 0/*MemoryMappedFileAccess.ReadWrite*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/;
                    case 4/*MemoryMappedFileAccess.ReadExecute*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 4/*Interop.Sys.MemoryMappedProtections.PROT_EXEC*/;
                    case 5/*MemoryMappedFileAccess.ReadWriteExecute*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/ | 4/*Interop.Sys.MemoryMappedProtections.PROT_EXEC*/;
                    case 3/*MemoryMappedFileAccess.CopyOnWrite*/:
                    return forVerification ? 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ : 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195820575)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            static $h = 1507359;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(115965624351),
    {
      "p": 1179679,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900853279,
        "f": 50331649
      },
      "n": "ViewHandle",
      "d": 1507359,
      "h": 115965624351,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965624351),
//--TRIMMABLE-BOUNDARY-START(103080722463),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720984095,
        "f": 50331649
      },
      "n": "PointerOffset",
      "d": 1507359,
      "h": 103080722463,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080722463),
//--TRIMMABLE-BOUNDARY-START(107375689759),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310918687,
        "f": 50331649
      },
      "n": "Size",
      "d": 1507359,
      "h": 107375689759,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375689759),
//--TRIMMABLE-BOUNDARY-START(25771311135),
    {
      "p": 1310751,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541114911,
        "f": 50331649
      },
      "n": "Access",
      "d": 1507359,
      "h": 25771311135,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771311135),
//--TRIMMABLE-BOUNDARY-START(94490787871),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131049503,
        "f": 50331649
      },
      "n": "IsClosed",
      "d": 1507359,
      "h": 94490787871,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490787871)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38656213023),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1507359,
      "h": 38656213023,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656213023),
//--TRIMMABLE-BOUNDARY-START(111670657055),
    {
      "r": 65537,
      "p": [
        {
          "n": "size",
          "p": 917505
        },
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "allocationGranularity",
          "p": 917505
        },
        {
          "n": "newSize",
          "p": 983041,
          "f": 2
        },
        {
          "n": "extraMemNeeded",
          "p": 917505,
          "f": 2
        },
        {
          "n": "newOffset",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "ValidateSizeAndOffset",
      "d": 1507359,
      "h": 111670657055,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(111670657055),
//--TRIMMABLE-BOUNDARY-START(30066278431),
    {
      "r": 1507359,
      "p": [
        {
          "n": "memMappedFileHandle",
          "p": 1114143
        },
        {
          "n": "access",
          "p": 1310751
        },
        {
          "n": "requestedOffset",
          "p": 917505
        },
        {
          "n": "requestedSize",
          "p": 917505
        }
      ],
      "n": "CreateView",
      "d": 1507359,
      "h": 30066278431,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066278431),
//--TRIMMABLE-BOUNDARY-START(42951180319),
    {
      "r": 65537,
      "p": [
        {
          "n": "capacity",
          "p": 851969
        }
      ],
      "n": "Flush",
      "d": 1507359,
      "h": 42951180319,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951180319),
//--TRIMMABLE-BOUNDARY-START(34361245727),
    {
      "r": 65537,
      "p": [
        {
          "n": "addr",
          "p": 786433
        },
        {
          "n": "length",
          "p": 983041
        }
      ],
      "n": "DisableForkingIfPossible",
      "d": 1507359,
      "h": 34361245727,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361245727),
//--TRIMMABLE-BOUNDARY-START(90195820575),
    {
      "r": 786463,
      "p": [
        {
          "n": "access",
          "p": 1310751
        },
        {
          "n": "forVerification",
          "p": 262145
        }
      ],
      "n": "GetProtections",
      "d": 1507359,
      "h": 90195820575,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(90195820575)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181376543),
    {
      "t": 1179679,
      "n": "_viewHandle",
      "d": 1507359,
      "h": 17181376543,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181376543),
//--TRIMMABLE-BOUNDARY-START(8591441951),
    {
      "t": 917505,
      "n": "_pointerOffset",
      "d": 1507359,
      "h": 8591441951,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591441951),
//--TRIMMABLE-BOUNDARY-START(12886409247),
    {
      "t": 917505,
      "n": "_size",
      "d": 1507359,
      "h": 12886409247,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886409247),
//--TRIMMABLE-BOUNDARY-START(4296474655),
    {
      "t": 1310751,
      "n": "_access",
      "d": 1507359,
      "h": 4296474655,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474655),
//--TRIMMABLE-BOUNDARY-START(98785755167),
    {
      "t": 917505,
      "n": "MaxProcessAddressSpace",
      "d": 1507359,
      "h": 98785755167,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(98785755167)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476343839),
    {
      "p": [
        {
          "n": "viewHandle",
          "p": 1179679
        },
        {
          "n": "pointerOffset",
          "p": 917505
        },
        {
          "n": "size",
          "p": 917505
        },
        {
          "n": "access",
          "p": 1310751
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507359,
      "h": 21476343839,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476343839)
  ],
  "i": [90177537
  ],
  "h": 1507359
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedView`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507359)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245215)
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedFile", ($self) => class MemoryMappedFile extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591179807)
            /*SafeMemoryMappedFileHandle*/ _handle = null;
            //--TRIMMABLE-BOUNDARY-END(8591179807)
            
            //--TRIMMABLE-BOUNDARY-START(12886147103)
            /*bool*/ _leaveOpen = false;
            //--TRIMMABLE-BOUNDARY-END(12886147103)
            
            //--TRIMMABLE-BOUNDARY-START(4296212511)
            /*SafeFileHandle?*/ _fileHandle = null;
            //--TRIMMABLE-BOUNDARY-END(4296212511)
            
            //--TRIMMABLE-BOUNDARY-START(141735165983)
            /*int*/ static DefaultSize = 0;
            //--TRIMMABLE-BOUNDARY-END(141735165983)
            
            //--TRIMMABLE-BOUNDARY-START(17181114399)
            $ctor$2(/*SafeMemoryMappedFileHandle*/ handle)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181114399);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(handle !== null, "handle != null");
                    $.$$.System.Diagnostics.Debug.Assert$2(!handle.IsClosed, "!handle.IsClosed");
                    $.$$.System.Diagnostics.Debug.Assert$2(!handle.IsInvalid, "!handle.IsInvalid");
                    this._handle = handle;
                    this._leaveOpen = true;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181114399)
            
            //--TRIMMABLE-BOUNDARY-START(21476081695)
            $ctor$1(/*SafeMemoryMappedFileHandle*/ handle, /*SafeFileHandle*/ fileHandle, /*bool*/ leaveOpen)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476081695);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(handle !== null, "handle != null");
                    $.$$.System.Diagnostics.Debug.Assert$2(!handle.IsClosed, "!handle.IsClosed");
                    $.$$.System.Diagnostics.Debug.Assert$2(!handle.IsInvalid, "!handle.IsInvalid");
                    $.$$.System.Diagnostics.Debug.Assert$2(fileHandle !== null, "fileHandle != null");
                    this._handle = handle;
                    this._fileHandle = fileHandle;
                    this._leaveOpen = leaveOpen;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476081695)
            
            //--TRIMMABLE-BOUNDARY-START(180389871647)
            static /*MemoryMappedFile */ OpenExisting$2(/*string*/ mapName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389871647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenExisting(mapName, 6/*MemoryMappedFileRights.ReadWrite*/, 0/*HandleInheritability.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(180389871647)
            
            //--TRIMMABLE-BOUNDARY-START(184684838943)
            static /*MemoryMappedFile */ OpenExisting$1(/*string*/ mapName, /*MemoryMappedFileRights*/ desiredAccessRights)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684838943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenExisting(mapName, desiredAccessRights, 0/*HandleInheritability.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(184684838943)
            
            //--TRIMMABLE-BOUNDARY-START(188979806239)
            static /*MemoryMappedFile */ OpenExisting(/*string*/ mapName, /*MemoryMappedFileRights*/ desiredAccessRights, /*HandleInheritability*/ inheritability)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979806239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(mapName, "mapName");
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("inheritability");
                }
                if ((desiredAccessRights & ~((983055/*MemoryMappedFileRights.FullControl*/ | 16777216/*MemoryMappedFileRights.AccessSystemSecurity*/))) !== 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("desiredAccessRights");
                }
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenCore$1(mapName, inheritability, desiredAccessRights, false);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$2(handle);
            }
            //--TRIMMABLE-BOUNDARY-END(188979806239)
            
            //--TRIMMABLE-BOUNDARY-START(34360983583)
            static /*MemoryMappedFile */ CreateFromFile$6(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360983583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$2(path, 3/*FileMode.Open*/, null, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            //--TRIMMABLE-BOUNDARY-END(34360983583)
            
            //--TRIMMABLE-BOUNDARY-START(38655950879)
            static /*MemoryMappedFile */ CreateFromFile$5(/*string*/ path, /*FileMode*/ mode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655950879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$2(path, mode, null, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            //--TRIMMABLE-BOUNDARY-END(38655950879)
            
            //--TRIMMABLE-BOUNDARY-START(42950918175)
            static /*MemoryMappedFile */ CreateFromFile$4(/*string*/ path, /*FileMode*/ mode, /*string?*/ mapName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950918175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$2(path, mode, mapName, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            //--TRIMMABLE-BOUNDARY-END(42950918175)
            
            //--TRIMMABLE-BOUNDARY-START(47245885471)
            static /*MemoryMappedFile */ CreateFromFile$3(/*string*/ path, /*FileMode*/ mode, /*string?*/ mapName, /*long*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245885471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$2(path, mode, mapName, capacity, 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            //--TRIMMABLE-BOUNDARY-END(47245885471)
            
            //--TRIMMABLE-BOUNDARY-START(51540852767)
            static /*MemoryMappedFile */ CreateFromFile$2(/*string*/ path, /*FileMode*/ mode, /*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540852767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(path, "path");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.ValidateCreateFile(mapName, capacity, access);
                if (mode === 6/*FileMode.Append*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFAppendModeNotAllowed, "mode");
                }
                if (mode === 5/*FileMode.Truncate*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFTruncateModeNotAllowed, "mode");
                }
                /*bool*/ let existed = (() =>
                {
                    if (mode === 3/*FileMode.Open*/)
                    {
                        return true;
                    }
                    if (mode === 1/*FileMode.CreateNew*/)
                    {
                        return false;
                    }
                    return $.$$.System.IO.File.Exists(path);
                })();
                /*SafeFileHandle*/ let fileHandle = $.$$.System.IO.File.OpenHandle(path, mode, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GetFileAccess(access), 1/*FileShare.Read*/, 0/*FileOptions.None*/, 0n);
                /*long*/ let fileSize = 0n;
                if (!((mode === 1/*FileMode.CreateNew*/) || (mode === 2/*FileMode.Create*/)))
                {
                    try
                    {
                        fileSize = $.$$.System.IO.RandomAccess.GetLength(fileHandle);
                    }
                    catch($e)
                    {
                        fileHandle.Dispose();
                        throw $e;
                    }
                }
                if (capacity === 0n && fileSize === 0n)
                {
                    $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CleanupFile(fileHandle, existed, path);
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sim.System.SR.Argument_EmptyFile);
                }
                if (capacity === BigInt(0/*DefaultSize*/))
                {
                    capacity = fileSize;
                }
                /*SafeMemoryMappedFileHandle?*/ let handle;
                try
                {
                    handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(fileHandle, mapName, 0/*HandleInheritability.None*/, access, 0/*MemoryMappedFileOptions.None*/, capacity, fileSize);
                }
                catch($e)
                {
                    $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CleanupFile(fileHandle, existed, path);
                    throw $e;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(handle !== null, "handle != null");
                $.$$.System.Diagnostics.Debug.Assert$2(!handle.IsInvalid, "!handle.IsInvalid");
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$1(handle, fileHandle, false);
            }
            //--TRIMMABLE-BOUNDARY-END(51540852767)
            
            //--TRIMMABLE-BOUNDARY-START(55835820063)
            static /*MemoryMappedFile */ CreateFromFile(/*SafeFileHandle*/ fileHandle, /*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*HandleInheritability*/ inheritability, /*bool*/ leaveOpen)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835820063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(fileHandle, "fileHandle");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.ValidateCreateFile(mapName, capacity, access);
                /*long*/ let fileSize = $.$$.System.IO.RandomAccess.GetLength(fileHandle);
                if (capacity === 0n && fileSize === 0n)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sim.System.SR.Argument_EmptyFile);
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("inheritability");
                }
                if (capacity === BigInt(0/*DefaultSize*/))
                {
                    capacity = fileSize;
                }
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(fileHandle, mapName, inheritability, access, 0/*MemoryMappedFileOptions.None*/, capacity, fileSize);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$1(handle, fileHandle, leaveOpen);
            }
            //--TRIMMABLE-BOUNDARY-END(55835820063)
            
            //--TRIMMABLE-BOUNDARY-START(60130787359)
            static /*MemoryMappedFile */ CreateFromFile$1(/*FileStream*/ fileStream, /*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*HandleInheritability*/ inheritability, /*bool*/ leaveOpen)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130787359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(fileStream, "fileStream");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.ValidateCreateFile(mapName, capacity, access);
                /*long*/ let fileSize = fileStream.Length;
                if (capacity === 0n && fileSize === 0n)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sim.System.SR.Argument_EmptyFile);
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("inheritability");
                }
                fileStream.Flush();
                if (capacity === BigInt(0/*DefaultSize*/))
                {
                    capacity = fileSize;
                }
                /*SafeFileHandle*/ let fileHandle = fileStream.SafeFileHandle;
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(fileHandle, mapName, inheritability, access, 0/*MemoryMappedFileOptions.None*/, capacity, fileSize);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$1(handle, fileHandle, leaveOpen);
            }
            //--TRIMMABLE-BOUNDARY-END(60130787359)
            
            //--TRIMMABLE-BOUNDARY-START(68720721951)
            static /*MemoryMappedFile */ CreateNew$2(/*string?*/ mapName, /*long*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720721951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNew(mapName, capacity, 0/*MemoryMappedFileAccess.ReadWrite*/, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(68720721951)
            
            //--TRIMMABLE-BOUNDARY-START(73015689247)
            static /*MemoryMappedFile */ CreateNew$1(/*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015689247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNew(mapName, capacity, access, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(73015689247)
            
            //--TRIMMABLE-BOUNDARY-START(77310656543)
            static /*MemoryMappedFile */ CreateNew(/*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*HandleInheritability*/ inheritability)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310656543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Inequality(mapName, null) && mapName.length === 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sim.System.SR.Argument_MapNameEmptyString);
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int64, capacity, "capacity");
                if ($.$$.System.IntPtr.Size === 4 && capacity > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("capacity", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("access");
                }
                if (access === 2/*MemoryMappedFileAccess.Write*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFWriteAccessNotAllowed, "access");
                }
                if ((options & ~((67108864/*MemoryMappedFileOptions.DelayAllocatePages*/))) !== 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("options");
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("inheritability");
                }
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(null, mapName, inheritability, access, options, capacity, BigInt(-1));
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$2(handle);
            }
            //--TRIMMABLE-BOUNDARY-END(77310656543)
            
            //--TRIMMABLE-BOUNDARY-START(81605623839)
            static /*MemoryMappedFile */ CreateOrOpen$2(/*string*/ mapName, /*long*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605623839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateOrOpen(mapName, capacity, 0/*MemoryMappedFileAccess.ReadWrite*/, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(81605623839)
            
            //--TRIMMABLE-BOUNDARY-START(85900591135)
            static /*MemoryMappedFile */ CreateOrOpen$1(/*string*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900591135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateOrOpen(mapName, capacity, access, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(85900591135)
            
            //--TRIMMABLE-BOUNDARY-START(90195558431)
            static /*MemoryMappedFile */ CreateOrOpen(/*string*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*HandleInheritability*/ inheritability)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195558431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(mapName, "mapName");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int64, capacity, "capacity");
                if ($.$$.System.IntPtr.Size === 4 && capacity > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("capacity", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("access");
                }
                if ((options & ~((67108864/*MemoryMappedFileOptions.DelayAllocatePages*/))) !== 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("options");
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("inheritability");
                }
                /*SafeMemoryMappedFileHandle*/ let handle;
                if (access === 2/*MemoryMappedFileAccess.Write*/)
                {
                    handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenCore(mapName, inheritability, access, true);
                }
                else 
                {
                    handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateOrOpenCore(mapName, inheritability, access, options, capacity);
                }
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$2(handle);
            }
            //--TRIMMABLE-BOUNDARY-END(90195558431)
            
            //--TRIMMABLE-BOUNDARY-START(128850264095)
            /*MemoryMappedViewStream */ CreateViewStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850264095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateViewStream$1(0n, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            //--TRIMMABLE-BOUNDARY-END(128850264095)
            
            //--TRIMMABLE-BOUNDARY-START(133145231391)
            /*MemoryMappedViewStream */ CreateViewStream$2(/*long*/ offset, /*long*/ size)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145231391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateViewStream$1(offset, size, 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133145231391)
            
            //--TRIMMABLE-BOUNDARY-START(137440198687)
            /*MemoryMappedViewStream */ CreateViewStream$1(/*long*/ offset, /*long*/ size, /*MemoryMappedFileAccess*/ access)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440198687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, offset, "offset");
                if (size < 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("size", $.$sim.System.SR.ArgumentOutOfRange_PositiveOrDefaultSizeRequired);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("access");
                }
                if ($.$$.System.IntPtr.Size === 4 && size > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("size", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                /*MemoryMappedView*/ let view = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.CreateView(this._handle, access, offset, size);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedViewStream().$ctor$8(view);
            }
            //--TRIMMABLE-BOUNDARY-END(137440198687)
            
            //--TRIMMABLE-BOUNDARY-START(115965362207)
            /*MemoryMappedViewAccessor */ CreateViewAccessor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965362207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateViewAccessor$1(0n, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            //--TRIMMABLE-BOUNDARY-END(115965362207)
            
            //--TRIMMABLE-BOUNDARY-START(120260329503)
            /*MemoryMappedViewAccessor */ CreateViewAccessor$2(/*long*/ offset, /*long*/ size)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260329503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateViewAccessor$1(offset, size, 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            //--TRIMMABLE-BOUNDARY-END(120260329503)
            
            //--TRIMMABLE-BOUNDARY-START(124555296799)
            /*MemoryMappedViewAccessor */ CreateViewAccessor$1(/*long*/ offset, /*long*/ size, /*MemoryMappedFileAccess*/ access)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555296799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, offset, "offset");
                if (size < 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("size", $.$sim.System.SR.ArgumentOutOfRange_PositiveOrDefaultSizeRequired);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("access");
                }
                if ($.$$.System.IntPtr.Size === 4 && size > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("size", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                /*MemoryMappedView*/ let view = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.CreateView(this._handle, access, offset, size);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedViewAccessor().$ctor$4(view);
            }
            //--TRIMMABLE-BOUNDARY-END(124555296799)
            
            //--TRIMMABLE-BOUNDARY-START(146030133279)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030133279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(146030133279)
            
            //--TRIMMABLE-BOUNDARY-START(150325100575)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325100575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    if (!this._handle.IsClosed)
                    {
                        this._handle.Dispose();
                    }
                }
                finally
                {
                    {
                        if (!this._leaveOpen)
                        {
                            this._fileHandle?.Dispose();
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150325100575)
            
            //--TRIMMABLE-BOUNDARY-START(193274773535)
            /*SafeMemoryMappedFileHandle */ get SafeMemoryMappedFileHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210002463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._handle;
            }
            //--TRIMMABLE-BOUNDARY-END(193274773535)
            
            //--TRIMMABLE-BOUNDARY-START(167504969759)
            static /*FileAccess */ GetFileAccess(/*MemoryMappedFileAccess*/ access)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504969759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(access)
                {
                    case 1/*MemoryMappedFileAccess.Read*/:
                    case 4/*MemoryMappedFileAccess.ReadExecute*/:
                    return 1/*FileAccess.Read*/;
                    case 0/*MemoryMappedFileAccess.ReadWrite*/:
                    case 3/*MemoryMappedFileAccess.CopyOnWrite*/:
                    case 5/*MemoryMappedFileAccess.ReadWriteExecute*/:
                    return 3/*FileAccess.ReadWrite*/;
                    default:
                    $.$$.System.Diagnostics.Debug.Assert$2(access === 2/*MemoryMappedFileAccess.Write*/, "access == MemoryMappedFileAccess.Write");
                    return 2/*FileAccess.Write*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504969759)
            
            //--TRIMMABLE-BOUNDARY-START(25771048991)
            static /*void */ CleanupFile(/*SafeFileHandle*/ fileHandle, /*bool*/ existed, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771048991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                fileHandle.Dispose();
                if (!existed)
                {
                    $.$$.System.IO.File.Delete(path);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771048991)
            
            //--TRIMMABLE-BOUNDARY-START(201864708127)
            static /*void */ ValidateCreateFile(/*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864708127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Inequality(mapName, null) && mapName.length === 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sim.System.SR.Argument_MapNameEmptyString);
                }
                if (capacity < 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("capacity", $.$sim.System.SR.ArgumentOutOfRange_PositiveOrDefaultCapacityRequired);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("access");
                }
                if (access === 2/*MemoryMappedFileAccess.Write*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFWriteAccessNotAllowed, "access");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201864708127)
            
            //--TRIMMABLE-BOUNDARY-START(206159675423)
            static /*void */ VerifyMemoryMappedFileAccess(/*MemoryMappedFileAccess*/ access, /*long*/ capacity, /*SafeFileHandle?*/ fileHandle, /*long*/ fileSize, /*out bool*/ isRegularFile)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159675423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                isRegularFile.$v = !(fileHandle === null) && (fileSize > 0n || IsRegularFile(fileHandle));
                if (isRegularFile.$v)
                {
                    if (access === 1/*MemoryMappedFileAccess.Read*/ && capacity > fileSize)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$sim.System.SR.Argument_ReadAccessWithLargeCapacity);
                    }
                    if (fileSize > capacity)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("capacity", $.$sim.System.SR.ArgumentOutOfRange_CapacityGEFileSizeRequired);
                    }
                    if (access === 2/*MemoryMappedFileAccess.Write*/)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFWriteAccessNotAllowed, "access");
                    }
                }
                /*static bool*/  function IsRegularFile(/*SafeFileHandle*/ fileHandle)
                {
                    /*Interop.Sys.FileStatus*/ let status;
                    $.$sim.Interop.CheckIo($.$sim.Interop.Sys.FStat(fileHandle, $.$ref(() => status, ($v) => status = $v, $.$sim.Interop.Sys.FileStatus)), null, false);
                    return (status.Mode & 32768/*Interop.Sys.FileTypes.S_IFREG*/) !== 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206159675423)
            
            //--TRIMMABLE-BOUNDARY-START(30066016287)
            static /*SafeMemoryMappedFileHandle */ CreateCore(/*SafeFileHandle?*/ fileHandle, /*string?*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*long*/ capacity, /*long*/ fileSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066016287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let isRegularFile;
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.VerifyMemoryMappedFileAccess(access, capacity, fileHandle, fileSize, $.$ref(() => isRegularFile, ($v) => isRegularFile = $v, $.$$.System.Boolean));
                if ($.$$.System.String.op_Inequality(mapName, null))
                {
                    throw $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNamedMapsNotSupportedException();
                }
                /*bool*/ let ownsFileStream = false;
                if (fileHandle !== null)
                {
                    if (isRegularFile && fileSize >= 0n && capacity > fileSize)
                    {
                        try
                        {
                            $.$sim.Interop.CheckIo($.$sim.Interop.Sys.FTruncate(fileHandle, capacity), null, false);
                        }
                        catch(exc)
                        {
                            throw new $.$$.System.IO.IOException().$ctor$11(exc.Message, exc);
                        }
                    }
                }
                else 
                {
                    /*Interop.Sys.MemoryMappedProtections*/ let protections = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(access, false);
                    if ((protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) !== 0 && capacity > 0n)
                    {
                        ownsFileStream = true;
                        fileHandle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObject(protections, capacity, inheritability);
                    }
                }
                return new $.$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedFileHandle().$ctor$5(fileHandle, ownsFileStream, inheritability, access, options, capacity);
            }
            //--TRIMMABLE-BOUNDARY-END(30066016287)
            
            //--TRIMMABLE-BOUNDARY-START(94490525727)
            static /*SafeMemoryMappedFileHandle */ CreateOrOpenCore(/*string*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*long*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490525727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(null, mapName, inheritability, access, options, capacity, BigInt(-1));
            }
            //--TRIMMABLE-BOUNDARY-END(94490525727)
            
            //--TRIMMABLE-BOUNDARY-START(171799937055)
            static /*SafeMemoryMappedFileHandle */ OpenCore(/*string*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*bool*/ createOrOpen)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799937055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNamedMapsNotSupportedException();
            }
            //--TRIMMABLE-BOUNDARY-END(171799937055)
            
            //--TRIMMABLE-BOUNDARY-START(176094904351)
            static /*SafeMemoryMappedFileHandle */ OpenCore$1(/*string*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileRights*/ rights, /*bool*/ createOrOpen)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094904351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNamedMapsNotSupportedException();
            }
            //--TRIMMABLE-BOUNDARY-END(176094904351)
            
            //--TRIMMABLE-BOUNDARY-START(64425754655)
            static /*PlatformNotSupportedException */ CreateNamedMapsNotSupportedException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425754655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.PlatformNotSupportedException().$ctor$16($.$sim.System.SR.PlatformNotSupported_NamedMaps);
            }
            //--TRIMMABLE-BOUNDARY-END(64425754655)
            
            //--TRIMMABLE-BOUNDARY-START(197569740831)
            static /*FileAccess */ TranslateProtectionsToFileAccess(/*Interop.Sys.MemoryMappedProtections*/ protections)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569740831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (protections & (1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/)) !== 0 ? 3/*FileAccess.ReadWrite*/ : (protections & (2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/)) !== 0 ? 2/*FileAccess.Write*/ : 1/*FileAccess.Read*/;
            }
            //--TRIMMABLE-BOUNDARY-END(197569740831)
            
            //--TRIMMABLE-BOUNDARY-START(98785493023)
            static /*SafeFileHandle */ CreateSharedBackingObject(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785493023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sim.Interop.Sys.IsMemfdSupported ? $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObjectUsingMemoryMemfdCreate(protections, capacity, inheritability) : $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObjectUsingMemoryShmOpen(protections, capacity, inheritability) ?? $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObjectUsingFile(protections, capacity, inheritability);
            }
            //--TRIMMABLE-BOUNDARY-END(98785493023)
            
            //--TRIMMABLE-BOUNDARY-START(111670394911)
            static /*SafeFileHandle? */ CreateSharedBackingObjectUsingMemoryShmOpen(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670394911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Interop.Sys.OpenFlags*/ let flags = (protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) !== 0 ? 2/*Interop.Sys.OpenFlags.O_RDWR*/ : 0/*Interop.Sys.OpenFlags.O_RDONLY*/;
                flags |= 32/*Interop.Sys.OpenFlags.O_CREAT*/ | 64/*Interop.Sys.OpenFlags.O_EXCL*/;
                /*var*/ let perms = 0/*UnixFileMode.None*/;
                if ((protections & 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/) !== 0)
                {
                    perms |= 256/*UnixFileMode.UserRead*/;
                }
                if ((protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) !== 0)
                {
                    perms |= 128/*UnixFileMode.UserWrite*/;
                }
                if ((protections & 4/*Interop.Sys.MemoryMappedProtections.PROT_EXEC*/) !== 0)
                {
                    perms |= 64/*UnixFileMode.UserExecute*/;
                }
                /*string*/ let mapName;
                /*SafeFileHandle*/ let fd;
                do
                {
                    mapName = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GenerateMapName();
                    fd = $.$sim.Interop.Sys.ShmOpen(mapName, flags, perms);
                    if (fd.IsInvalid)
                    {
                        /*Interop.ErrorInfo*/ let errorInfo = $.$sim.Interop.Sys.GetLastErrorInfo();
                        fd.Dispose();
                        if (errorInfo.Error === 65597/*Interop.Error.ENOTSUP*/)
                        {
                            return null;
                        }
                        else if (errorInfo.Error === 65573/*Interop.Error.ENAMETOOLONG*/)
                        {
                            $.$$.System.Diagnostics.Debug.Fail$1(`shm_open failed with ENAMETOOLONG for ${$.$$.System.Text.Encoding.UTF8.GetByteCount$6(mapName)} byte long name.`);
                            return null;
                        }
                        else if (errorInfo.Error !== 65556/*Interop.Error.EEXIST*/)
                        {
                            throw $.$sim.Interop.GetExceptionForIoErrno(errorInfo.Clone(), null, false);
                        }
                    }
                }
                while(fd.IsInvalid);
                try
                {
                    $.$sim.Interop.CheckIo($.$sim.Interop.Sys.ShmUnlink(mapName), null, false);
                    $.$sim.Interop.CheckIo($.$sim.Interop.Sys.FTruncate(fd, capacity), null, false);
                    if (inheritability === 1/*HandleInheritability.Inheritable*/ && $.$sim.Interop.Sys.Fcntl.SetFD(fd, 0) === -1)
                    {
                        throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                    }
                    return fd;
                }
                catch($e)
                {
                    fd.Dispose();
                    throw $e;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111670394911)
            
            //--TRIMMABLE-BOUNDARY-START(154620067871)
            static /*string */ GenerateMapName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620067871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let MaxNameLength = 30;
                /*string*/ let NamePrefix = "/dotnet_";
                return $.$$.System.String.Create$10($.$$.System.Int32, MaxNameLength, 0, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.Int32))().$ctor(this,  (/*span*/ span, /*state*/ state) =>
                {
                    /*Span<char>*/ let guid = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 32, null);
                    /*int*/ let charsWritten;
                    $.$$.System.Guid.NewGuid().TryFormat$1(guid, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), $.$$.System.String.op_Implicit("N"));
                    $.$$.System.Diagnostics.Debug.Assert$2(charsWritten === 32, "charsWritten == 32");
                    $.$$.System.String.CopyTo$1.call(NamePrefix, span);
                    guid.Slice(0, ((MaxNameLength - NamePrefix.length) | 0)).CopyTo(span.Slice$1(NamePrefix.length));
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Text.Encoding.UTF8.GetByteCount$4($.$$.System.Span$$($.$$.System.Char).op_Implicit(span)) <= MaxNameLength, "Encoding.UTF8.GetByteCount(span) <= MaxNameLength");
                }, {
  "r": 65537,
  "p": [
    {
      "n": "span",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "state",
      "p": 655361
    }
  ],
  "n": "",
  "d": 1245215,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(154620067871)
            
            //--TRIMMABLE-BOUNDARY-START(107375427615)
            static /*SafeFileHandle */ CreateSharedBackingObjectUsingMemoryMemfdCreate(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375427615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let isReadonly = ((protections & 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/) !== 0 && (protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) === 0) ? 1 : 0;
                /*SafeFileHandle*/ let fd = $.$sim.Interop.Sys.MemfdCreate($.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GenerateMapName(), isReadonly);
                if (fd.IsInvalid)
                {
                    /*Interop.ErrorInfo*/ let errorInfo = $.$sim.Interop.Sys.GetLastErrorInfo();
                    fd.Dispose();
                    throw $.$sim.Interop.GetExceptionForIoErrno(errorInfo.Clone(), null, false);
                }
                try
                {
                    $.$sim.Interop.CheckIo($.$sim.Interop.Sys.FTruncate(fd, capacity), null, false);
                    if (inheritability === 1/*HandleInheritability.Inheritable*/ && $.$sim.Interop.Sys.Fcntl.SetFD(fd, 0) === -1)
                    {
                        throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                    }
                    return fd;
                }
                catch($e)
                {
                    fd.Dispose();
                    throw $e;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107375427615)
            
            //--TRIMMABLE-BOUNDARY-START(103080460319)
            static /*SafeFileHandle */ CreateSharedBackingObjectUsingFile(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080460319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let path = $.$$.System.IO.Path.Combine$3($.$$.System.IO.Path.GetTempPath(), $.$$.System.Guid.NewGuid().ToString$2("N"));
                /*FileShare*/ let share = inheritability === 0/*HandleInheritability.None*/ ? 3/*FileShare.ReadWrite*/ : 3/*FileShare.ReadWrite*/ | 16/*FileShare.Inheritable*/;
                /*SafeFileHandle*/ let fileHandle = $.$$.System.IO.File.OpenHandle(path, 1/*FileMode.CreateNew*/, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.TranslateProtectionsToFileAccess(protections), share, 0, 0n);
                try
                {
                    $.$sim.Interop.CheckIo($.$sim.Interop.Sys.Unlink(path), null, false);
                    $.$sim.Interop.CheckIo($.$sim.Interop.Sys.FTruncate(fileHandle, capacity), path, false);
                }
                catch($e)
                {
                    fileHandle.Dispose();
                    throw $e;
                }
                return fileHandle;
            }
            //--TRIMMABLE-BOUNDARY-END(103080460319)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            static $h = 1245215;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(193274773535),
    {
      "p": 1114143,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163210002463,
        "f": 50331649
      },
      "n": "SafeMemoryMappedFileHandle",
      "d": 1245215,
      "h": 193274773535,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274773535)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(180389871647),
    {
      "r": 1245215,
      "p": [
        {
          "n": "mapName",
          "p": 1310721
        }
      ],
      "n": "OpenExisting",
      "o": "@$2",
      "d": 1245215,
      "h": 180389871647,
      "f": 16777249,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180389871647),
//--TRIMMABLE-BOUNDARY-START(184684838943),
    {
      "r": 1245215,
      "p": [
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "desiredAccessRights",
          "p": 1441823
        }
      ],
      "n": "OpenExisting",
      "o": "@$1",
      "d": 1245215,
      "h": 184684838943,
      "f": 16777249,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184684838943),
//--TRIMMABLE-BOUNDARY-START(188979806239),
    {
      "r": 1245215,
      "p": [
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "desiredAccessRights",
          "p": 1441823
        },
        {
          "n": "inheritability",
          "p": 93257729
        }
      ],
      "n": "OpenExisting",
      "d": 1245215,
      "h": 188979806239,
      "f": 16777249,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188979806239),
//--TRIMMABLE-BOUNDARY-START(34360983583),
    {
      "r": 1245215,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "CreateFromFile",
      "o": "@$6",
      "d": 1245215,
      "h": 34360983583,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360983583),
//--TRIMMABLE-BOUNDARY-START(38655950879),
    {
      "r": 1245215,
      "p": [
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "mode",
          "p": 92667905
        }
      ],
      "n": "CreateFromFile",
      "o": "@$5",
      "d": 1245215,
      "h": 38655950879,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655950879),
//--TRIMMABLE-BOUNDARY-START(42950918175),
    {
      "r": 1245215,
      "p": [
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "mode",
          "p": 92667905
        },
        {
          "n": "mapName",
          "p": 1310721
        }
      ],
      "n": "CreateFromFile",
      "o": "@$4",
      "d": 1245215,
      "h": 42950918175,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950918175),
//--TRIMMABLE-BOUNDARY-START(47245885471),
    {
      "r": 1245215,
      "p": [
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "mode",
          "p": 92667905
        },
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "capacity",
          "p": 917505
        }
      ],
      "n": "CreateFromFile",
      "o": "@$3",
      "d": 1245215,
      "h": 47245885471,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245885471),
//--TRIMMABLE-BOUNDARY-START(51540852767),
    {
      "r": 1245215,
      "p": [
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "mode",
          "p": 92667905
        },
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "access",
          "p": 1310751
        }
      ],
      "n": "CreateFromFile",
      "o": "@$2",
      "d": 1245215,
      "h": 51540852767,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540852767),
//--TRIMMABLE-BOUNDARY-START(55835820063),
    {
      "r": 1245215,
      "p": [
        {
          "n": "fileHandle",
          "p": 7733249
        },
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "access",
          "p": 1310751
        },
        {
          "n": "inheritability",
          "p": 93257729
        },
        {
          "n": "leaveOpen",
          "p": 262145
        }
      ],
      "n": "CreateFromFile",
      "d": 1245215,
      "h": 55835820063,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835820063),
//--TRIMMABLE-BOUNDARY-START(60130787359),
    {
      "r": 1245215,
      "p": [
        {
          "n": "fileStream",
          "p": 92995585
        },
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "access",
          "p": 1310751
        },
        {
          "n": "inheritability",
          "p": 93257729
        },
        {
          "n": "leaveOpen",
          "p": 262145
        }
      ],
      "n": "CreateFromFile",
      "o": "@$1",
      "d": 1245215,
      "h": 60130787359,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130787359),
//--TRIMMABLE-BOUNDARY-START(68720721951),
    {
      "r": 1245215,
      "p": [
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "capacity",
          "p": 917505
        }
      ],
      "n": "CreateNew",
      "o": "@$2",
      "d": 1245215,
      "h": 68720721951,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68720721951),
//--TRIMMABLE-BOUNDARY-START(73015689247),
    {
      "r": 1245215,
      "p": [
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "access",
          "p": 1310751
        }
      ],
      "n": "CreateNew",
      "o": "@$1",
      "d": 1245215,
      "h": 73015689247,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73015689247),
//--TRIMMABLE-BOUNDARY-START(77310656543),
    {
      "r": 1245215,
      "p": [
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "access",
          "p": 1310751
        },
        {
          "n": "options",
          "p": 1376287
        },
        {
          "n": "inheritability",
          "p": 93257729
        }
      ],
      "n": "CreateNew",
      "d": 1245215,
      "h": 77310656543,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77310656543),
//--TRIMMABLE-BOUNDARY-START(81605623839),
    {
      "r": 1245215,
      "p": [
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "capacity",
          "p": 917505
        }
      ],
      "n": "CreateOrOpen",
      "o": "@$2",
      "d": 1245215,
      "h": 81605623839,
      "f": 16777249,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605623839),
//--TRIMMABLE-BOUNDARY-START(85900591135),
    {
      "r": 1245215,
      "p": [
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "access",
          "p": 1310751
        }
      ],
      "n": "CreateOrOpen",
      "o": "@$1",
      "d": 1245215,
      "h": 85900591135,
      "f": 16777249,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900591135),
//--TRIMMABLE-BOUNDARY-START(90195558431),
    {
      "r": 1245215,
      "p": [
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "access",
          "p": 1310751
        },
        {
          "n": "options",
          "p": 1376287
        },
        {
          "n": "inheritability",
          "p": 93257729
        }
      ],
      "n": "CreateOrOpen",
      "d": 1245215,
      "h": 90195558431,
      "f": 16777249,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90195558431),
//--TRIMMABLE-BOUNDARY-START(128850264095),
    {
      "r": 1638431,
      "n": "CreateViewStream",
      "d": 1245215,
      "h": 128850264095,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128850264095),
//--TRIMMABLE-BOUNDARY-START(133145231391),
    {
      "r": 1638431,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "size",
          "p": 917505
        }
      ],
      "n": "CreateViewStream",
      "o": "@$2",
      "d": 1245215,
      "h": 133145231391,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133145231391),
//--TRIMMABLE-BOUNDARY-START(137440198687),
    {
      "r": 1638431,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "size",
          "p": 917505
        },
        {
          "n": "access",
          "p": 1310751
        }
      ],
      "n": "CreateViewStream",
      "o": "@$1",
      "d": 1245215,
      "h": 137440198687,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137440198687),
//--TRIMMABLE-BOUNDARY-START(115965362207),
    {
      "r": 1572895,
      "n": "CreateViewAccessor",
      "d": 1245215,
      "h": 115965362207,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115965362207),
//--TRIMMABLE-BOUNDARY-START(120260329503),
    {
      "r": 1572895,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "size",
          "p": 917505
        }
      ],
      "n": "CreateViewAccessor",
      "o": "@$2",
      "d": 1245215,
      "h": 120260329503,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120260329503),
//--TRIMMABLE-BOUNDARY-START(124555296799),
    {
      "r": 1572895,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "size",
          "p": 917505
        },
        {
          "n": "access",
          "p": 1310751
        }
      ],
      "n": "CreateViewAccessor",
      "o": "@$1",
      "d": 1245215,
      "h": 124555296799,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124555296799),
//--TRIMMABLE-BOUNDARY-START(146030133279),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1245215,
      "h": 146030133279,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146030133279),
//--TRIMMABLE-BOUNDARY-START(150325100575),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 1245215,
      "h": 150325100575,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(150325100575),
//--TRIMMABLE-BOUNDARY-START(167504969759),
    {
      "r": 92405761,
      "p": [
        {
          "n": "access",
          "p": 1310751
        }
      ],
      "n": "GetFileAccess",
      "d": 1245215,
      "h": 167504969759,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(167504969759),
//--TRIMMABLE-BOUNDARY-START(25771048991),
    {
      "r": 65537,
      "p": [
        {
          "n": "fileHandle",
          "p": 7733249
        },
        {
          "n": "existed",
          "p": 262145
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "CleanupFile",
      "d": 1245215,
      "h": 25771048991,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25771048991),
//--TRIMMABLE-BOUNDARY-START(201864708127),
    {
      "r": 65537,
      "p": [
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "access",
          "p": 1310751
        }
      ],
      "n": "ValidateCreateFile",
      "d": 1245215,
      "h": 201864708127,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(201864708127),
//--TRIMMABLE-BOUNDARY-START(206159675423),
    {
      "r": 65537,
      "p": [
        {
          "n": "access",
          "p": 1310751
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "fileHandle",
          "p": 7733249
        },
        {
          "n": "fileSize",
          "p": 917505
        },
        {
          "n": "isRegularFile",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "VerifyMemoryMappedFileAccess",
      "d": 1245215,
      "h": 206159675423,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(206159675423),
//--TRIMMABLE-BOUNDARY-START(30066016287),
    {
      "r": 1114143,
      "p": [
        {
          "n": "fileHandle",
          "p": 7733249
        },
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "inheritability",
          "p": 93257729
        },
        {
          "n": "access",
          "p": 1310751
        },
        {
          "n": "options",
          "p": 1376287
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "fileSize",
          "p": 917505
        }
      ],
      "n": "CreateCore",
      "d": 1245215,
      "h": 30066016287,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066016287),
//--TRIMMABLE-BOUNDARY-START(94490525727),
    {
      "r": 1114143,
      "p": [
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "inheritability",
          "p": 93257729
        },
        {
          "n": "access",
          "p": 1310751
        },
        {
          "n": "options",
          "p": 1376287
        },
        {
          "n": "capacity",
          "p": 917505
        }
      ],
      "n": "CreateOrOpenCore",
      "d": 1245215,
      "h": 94490525727,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94490525727),
//--TRIMMABLE-BOUNDARY-START(171799937055),
    {
      "r": 1114143,
      "p": [
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "inheritability",
          "p": 93257729
        },
        {
          "n": "access",
          "p": 1310751
        },
        {
          "n": "createOrOpen",
          "p": 262145
        }
      ],
      "n": "OpenCore",
      "d": 1245215,
      "h": 171799937055,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(171799937055),
//--TRIMMABLE-BOUNDARY-START(176094904351),
    {
      "r": 1114143,
      "p": [
        {
          "n": "mapName",
          "p": 1310721
        },
        {
          "n": "inheritability",
          "p": 93257729
        },
        {
          "n": "rights",
          "p": 1441823
        },
        {
          "n": "createOrOpen",
          "p": 262145
        }
      ],
      "n": "OpenCore",
      "o": "@$1",
      "d": 1245215,
      "h": 176094904351,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(176094904351),
//--TRIMMABLE-BOUNDARY-START(64425754655),
    {
      "r": 104923137,
      "n": "CreateNamedMapsNotSupportedException",
      "d": 1245215,
      "h": 64425754655,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64425754655),
//--TRIMMABLE-BOUNDARY-START(197569740831),
    {
      "r": 92405761,
      "p": [
        {
          "n": "protections",
          "p": 786463
        }
      ],
      "n": "TranslateProtectionsToFileAccess",
      "d": 1245215,
      "h": 197569740831,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(197569740831),
//--TRIMMABLE-BOUNDARY-START(98785493023),
    {
      "r": 7733249,
      "p": [
        {
          "n": "protections",
          "p": 786463
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "inheritability",
          "p": 93257729
        }
      ],
      "n": "CreateSharedBackingObject",
      "d": 1245215,
      "h": 98785493023,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(98785493023),
//--TRIMMABLE-BOUNDARY-START(111670394911),
    {
      "r": 7733249,
      "p": [
        {
          "n": "protections",
          "p": 786463
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "inheritability",
          "p": 93257729
        }
      ],
      "n": "CreateSharedBackingObjectUsingMemoryShmOpen",
      "d": 1245215,
      "h": 111670394911,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(111670394911),
//--TRIMMABLE-BOUNDARY-START(154620067871),
    {
      "r": 1310721,
      "n": "GenerateMapName",
      "d": 1245215,
      "h": 154620067871,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(154620067871),
//--TRIMMABLE-BOUNDARY-START(107375427615),
    {
      "r": 7733249,
      "p": [
        {
          "n": "protections",
          "p": 786463
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "inheritability",
          "p": 93257729
        }
      ],
      "n": "CreateSharedBackingObjectUsingMemoryMemfdCreate",
      "d": 1245215,
      "h": 107375427615,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107375427615),
//--TRIMMABLE-BOUNDARY-START(103080460319),
    {
      "r": 7733249,
      "p": [
        {
          "n": "protections",
          "p": 786463
        },
        {
          "n": "capacity",
          "p": 917505
        },
        {
          "n": "inheritability",
          "p": 93257729
        }
      ],
      "n": "CreateSharedBackingObjectUsingFile",
      "d": 1245215,
      "h": 103080460319,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103080460319)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591179807),
    {
      "t": 1114143,
      "n": "_handle",
      "d": 1245215,
      "h": 8591179807,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591179807),
//--TRIMMABLE-BOUNDARY-START(12886147103),
    {
      "t": 262145,
      "n": "_leaveOpen",
      "d": 1245215,
      "h": 12886147103,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886147103),
//--TRIMMABLE-BOUNDARY-START(4296212511),
    {
      "t": 7733249,
      "n": "_fileHandle",
      "d": 1245215,
      "h": 4296212511,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212511),
//--TRIMMABLE-BOUNDARY-START(141735165983),
    {
      "t": 655361,
      "n": "DefaultSize",
      "d": 1245215,
      "h": 141735165983,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141735165983)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181114399),
    {
      "p": [
        {
          "n": "handle",
          "p": 1114143
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245215,
      "h": 17181114399,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17181114399),
//--TRIMMABLE-BOUNDARY-START(21476081695),
    {
      "p": [
        {
          "n": "handle",
          "p": 1114143
        },
        {
          "n": "fileHandle",
          "p": 7733249
        },
        {
          "n": "leaveOpen",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245215,
      "h": 21476081695,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476081695)
  ],
  "i": [90177537
  ],
  "h": 1245215
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFile`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245215)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441823)
        $asm.$str("$sim.System.IO.MemoryMappedFiles.MemoryMappedFileRights", ($self) => class MemoryMappedFileRights extends $.$$.System.Enum
        {
            static CopyOnWrite = 1;
            static Write = 2;
            static Read = 4;
            static Execute = 8;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static ReadWrite = 6;
            static ReadExecute = 12;
            static ReadWriteExecute = 14;
            static FullControl = 983055;
            static AccessSystemSecurity = 16777216;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1441823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "CopyOnWrite": 1n,
                    "Write": 2n,
                    "Read": 4n,
                    "Execute": 8n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "ReadWrite": 6n,
                    "ReadExecute": 12n,
                    "ReadWriteExecute": 14n,
                    "FullControl": 983055n,
                    "AccessSystemSecurity": 16777216n
                };
            }
            static $h = 1441823;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181311007),
    {
      "t": 1441823,
      "n": "CopyOnWrite",
      "d": 1441823,
      "h": 17181311007,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181311007),
//--TRIMMABLE-BOUNDARY-START(60130983967),
    {
      "t": 1441823,
      "n": "Write",
      "d": 1441823,
      "h": 60130983967,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130983967),
//--TRIMMABLE-BOUNDARY-START(34361180191),
    {
      "t": 1441823,
      "n": "Read",
      "d": 1441823,
      "h": 34361180191,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361180191),
//--TRIMMABLE-BOUNDARY-START(25771245599),
    {
      "t": 1441823,
      "n": "Execute",
      "d": 1441823,
      "h": 25771245599,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771245599),
//--TRIMMABLE-BOUNDARY-START(21476278303),
    {
      "t": 1441823,
      "n": "Delete",
      "d": 1441823,
      "h": 21476278303,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476278303),
//--TRIMMABLE-BOUNDARY-START(42951114783),
    {
      "t": 1441823,
      "n": "ReadPermissions",
      "d": 1441823,
      "h": 42951114783,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951114783),
//--TRIMMABLE-BOUNDARY-START(12886343711),
    {
      "t": 1441823,
      "n": "ChangePermissions",
      "d": 1441823,
      "h": 12886343711,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886343711),
//--TRIMMABLE-BOUNDARY-START(55836016671),
    {
      "t": 1441823,
      "n": "TakeOwnership",
      "d": 1441823,
      "h": 55836016671,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836016671),
//--TRIMMABLE-BOUNDARY-START(47246082079),
    {
      "t": 1441823,
      "n": "ReadWrite",
      "d": 1441823,
      "h": 47246082079,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246082079),
//--TRIMMABLE-BOUNDARY-START(38656147487),
    {
      "t": 1441823,
      "n": "ReadExecute",
      "d": 1441823,
      "h": 38656147487,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656147487),
//--TRIMMABLE-BOUNDARY-START(51541049375),
    {
      "t": 1441823,
      "n": "ReadWriteExecute",
      "d": 1441823,
      "h": 51541049375,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541049375),
//--TRIMMABLE-BOUNDARY-START(30066212895),
    {
      "t": 1441823,
      "n": "FullControl",
      "d": 1441823,
      "h": 30066212895,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066212895),
//--TRIMMABLE-BOUNDARY-START(8591376415),
    {
      "t": 1441823,
      "n": "AccessSystemSecurity",
      "d": 1441823,
      "h": 8591376415,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591376415)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409119),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1441823,
      "h": 4296409119,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409119)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 1441823,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFileRights`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441823)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376287)
        $asm.$str("$sim.System.IO.MemoryMappedFiles.MemoryMappedFileOptions", ($self) => class MemoryMappedFileOptions extends $.$$.System.Enum
        {
            static None = 0;
            static DelayAllocatePages = 67108864;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1376287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "DelayAllocatePages": 67108864n
                };
            }
            static $h = 1376287;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886278175),
    {
      "t": 1376287,
      "n": "None",
      "d": 1376287,
      "h": 12886278175,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886278175),
//--TRIMMABLE-BOUNDARY-START(8591310879),
    {
      "t": 1376287,
      "n": "DelayAllocatePages",
      "d": 1376287,
      "h": 8591310879,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591310879)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343583),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1376287,
      "h": 4296343583,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343583)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 1376287,
  "a": [
    {
      "t": 80347137,
      "c": 4375314433
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFileOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376287)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310751)
        $asm.$str("$sim.System.IO.MemoryMappedFiles.MemoryMappedFileAccess", ($self) => class MemoryMappedFileAccess extends $.$$.System.Enum
        {
            static ReadWrite = 0;
            static Read = 1;
            static Write = 2;
            static CopyOnWrite = 3;
            static ReadExecute = 4;
            static ReadWriteExecute = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1310751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "ReadWrite": 0n,
                    "Read": 1n,
                    "Write": 2n,
                    "CopyOnWrite": 3n,
                    "ReadExecute": 4n,
                    "ReadWriteExecute": 5n
                };
            }
            static $h = 1310751;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476147231),
    {
      "t": 1310751,
      "n": "ReadWrite",
      "d": 1310751,
      "h": 21476147231,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476147231),
//--TRIMMABLE-BOUNDARY-START(12886212639),
    {
      "t": 1310751,
      "n": "Read",
      "d": 1310751,
      "h": 12886212639,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886212639),
//--TRIMMABLE-BOUNDARY-START(30066081823),
    {
      "t": 1310751,
      "n": "Write",
      "d": 1310751,
      "h": 30066081823,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066081823),
//--TRIMMABLE-BOUNDARY-START(8591245343),
    {
      "t": 1310751,
      "n": "CopyOnWrite",
      "d": 1310751,
      "h": 8591245343,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591245343),
//--TRIMMABLE-BOUNDARY-START(17181179935),
    {
      "t": 1310751,
      "n": "ReadExecute",
      "d": 1310751,
      "h": 17181179935,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181179935),
//--TRIMMABLE-BOUNDARY-START(25771114527),
    {
      "t": 1310751,
      "n": "ReadWriteExecute",
      "d": 1310751,
      "h": 25771114527,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771114527)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278047),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1310751,
      "h": 4296278047,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278047)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 1310751
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFileAccess`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310751)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114143)
        $asm.$cls("$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedFileHandle", ($self) => class SafeMemoryMappedFileHandle extends $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            //--TRIMMABLE-BOUNDARY-START(30065885215)
            $ctor$4()
            {
                super.$ctor$3(true);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065885215);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065885215)
            
            //--TRIMMABLE-BOUNDARY-START(12886016031)
            /*SafeFileHandle?*/ _fileStreamHandle = null;
            //--TRIMMABLE-BOUNDARY-END(12886016031)
            
            //--TRIMMABLE-BOUNDARY-START(25770917919)
            /*bool*/ _ownsFileHandle = false;
            //--TRIMMABLE-BOUNDARY-END(25770917919)
            
            //--TRIMMABLE-BOUNDARY-START(17180983327)
            /*HandleInheritability*/ _inheritability = 0;
            //--TRIMMABLE-BOUNDARY-END(17180983327)
            
            //--TRIMMABLE-BOUNDARY-START(4296081439)
            /*MemoryMappedFileAccess*/ _access = 0;
            //--TRIMMABLE-BOUNDARY-END(4296081439)
            
            //--TRIMMABLE-BOUNDARY-START(21475950623)
            /*MemoryMappedFileOptions*/ _options = 0;
            //--TRIMMABLE-BOUNDARY-END(21475950623)
            
            //--TRIMMABLE-BOUNDARY-START(8591048735)
            /*long*/ _capacity = 0n;
            //--TRIMMABLE-BOUNDARY-END(8591048735)
            
            //--TRIMMABLE-BOUNDARY-START(34360852511)
            $ctor$5(/*SafeFileHandle?*/ fileHandle, /*bool*/ ownsFileHandle, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*long*/ capacity)
            {
                super.$ctor$3(true);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360852511);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(!ownsFileHandle || fileHandle !== null, "We can only own a FileStream we're actually given.");
                    this._ownsFileHandle = ownsFileHandle;
                    this._inheritability = inheritability;
                    this._access = access;
                    this._options = options;
                    this._capacity = capacity;
                    /*IntPtr*/ let handlePtr;
                    if (fileHandle !== null)
                    {
                        /*bool*/ let ignored = false;
                        fileHandle.DangerousAddRef$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => ignored, ($v) => ignored = $v, null));
                        this._fileStreamHandle = fileHandle;
                        handlePtr = fileHandle.DangerousGetHandle();
                    }
                    else 
                    {
                        handlePtr = $.$$.System.IntPtr.MaxValue;
                    }
                    this.SetHandle(handlePtr);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360852511)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 51540721695, 103226146817)
            /*bool */ ReleaseHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540721695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._fileStreamHandle !== null)
                {
                    this.SetHandle((-1));
                    if (this._ownsFileHandle)
                    {
                        this._fileStreamHandle.Dispose();
                    }
                    this._fileStreamHandle.DangerousRelease();
                    this._fileStreamHandle = null;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 51540721695, 103226146817)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 47245754399, 94636212225)
            /*bool */ get IsInvalid()
            {
                return $.$cast(this.handle, $.$$.System.Int64) <= 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 47245754399, 94636212225)
            
            static $h = 1114143;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 8060929,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 47245754399, 94636212225),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950787103,
        "f": 50364417
      },
      "n": "IsInvalid",
      "d": 1114143,
      "h": 47245754399,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47245754399, 94636212225)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 51540721695, 103226146817),
    {
      "r": 262145,
      "n": "ReleaseHandle",
      "d": 1114143,
      "h": 51540721695,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51540721695, 103226146817)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886016031),
    {
      "t": 7733249,
      "n": "_fileStreamHandle",
      "d": 1114143,
      "h": 12886016031,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12886016031),
//--TRIMMABLE-BOUNDARY-START(25770917919),
    {
      "t": 262145,
      "n": "_ownsFileHandle",
      "d": 1114143,
      "h": 25770917919,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(25770917919),
//--TRIMMABLE-BOUNDARY-START(17180983327),
    {
      "t": 93257729,
      "n": "_inheritability",
      "d": 1114143,
      "h": 17180983327,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180983327),
//--TRIMMABLE-BOUNDARY-START(4296081439),
    {
      "t": 1310751,
      "n": "_access",
      "d": 1114143,
      "h": 4296081439,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4296081439),
//--TRIMMABLE-BOUNDARY-START(21475950623),
    {
      "t": 1376287,
      "n": "_options",
      "d": 1114143,
      "h": 21475950623,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21475950623),
//--TRIMMABLE-BOUNDARY-START(8591048735),
    {
      "t": 917505,
      "n": "_capacity",
      "d": 1114143,
      "h": 8591048735,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8591048735)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065885215),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1114143,
      "h": 30065885215,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065885215),
//--TRIMMABLE-BOUNDARY-START(34360852511),
    {
      "p": [
        {
          "n": "fileHandle",
          "p": 7733249
        },
        {
          "n": "ownsFileHandle",
          "p": 262145
        },
        {
          "n": "inheritability",
          "p": 93257729
        },
        {
          "n": "access",
          "p": 1310751
        },
        {
          "n": "options",
          "p": 1376287
        },
        {
          "n": "capacity",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1114143,
      "h": 34360852511,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34360852511)
  ],
  "i": [90177537
  ],
  "h": 1114143
}; }
            static get $b() { return $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeMemoryMappedFileHandle`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114143)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179679)
        $asm.$cls("$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle", ($self) => class SafeMemoryMappedViewHandle extends $.$$.System.Runtime.InteropServices.SafeBuffer
        {
            //--TRIMMABLE-BOUNDARY-START(4296146975)
            $ctor$5()
            {
                super.$ctor$4(true);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296146975);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296146975)
            
            //--TRIMMABLE-BOUNDARY-START(8591114271)
            $ctor$6(/*IntPtr*/ handle, /*bool*/ ownsHandle)
            {
                super.$ctor$4(ownsHandle);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591114271);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    super.SetHandle(handle);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114271)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12886081567, 103226146817)
            /*bool */ ReleaseHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IntPtr*/ let addr = this.handle;
                this.handle = new $.$$.System.IntPtr().$ctor$3(-1);
                return $.$sim.Interop.Sys.MUnmap(addr, super.ByteLength) === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12886081567, 103226146817)
            
            static $h = 1179679;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 146866177,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12886081567, 103226146817),
    {
      "r": 262145,
      "n": "ReleaseHandle",
      "d": 1179679,
      "h": 12886081567,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12886081567, 103226146817)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296146975),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1179679,
      "h": 4296146975,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296146975),
//--TRIMMABLE-BOUNDARY-START(8591114271),
    {
      "p": [
        {
          "n": "handle",
          "p": 786433
        },
        {
          "n": "ownsHandle",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1179679,
      "h": 8591114271,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591114271)
  ],
  "i": [90177537
  ],
  "h": 1179679
}; }
            static get $b() { return $.$$.System.Runtime.InteropServices.SafeBuffer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179679)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572895)
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedViewAccessor", ($self) => class MemoryMappedViewAccessor extends $.$$.System.IO.UnmanagedMemoryAccessor
        {
            //--TRIMMABLE-BOUNDARY-START(4296540191)
            /*MemoryMappedView*/ _view = null;
            //--TRIMMABLE-BOUNDARY-END(4296540191)
            
            //--TRIMMABLE-BOUNDARY-START(8591507487)
            $ctor$4(/*MemoryMappedView*/ view)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591507487);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(view !== null, "view is null");
                    this._view = view;
                    this.Initialize(this._view.ViewHandle, this._view.PointerOffset, this._view.Size, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GetFileAccess(this._view.Access));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591507487)
            
            //--TRIMMABLE-BOUNDARY-START(42951245855)
            /*SafeMemoryMappedViewHandle */ get SafeMemoryMappedViewHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361311263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._view.ViewHandle;
            }
            //--TRIMMABLE-BOUNDARY-END(42951245855)
            
            //--TRIMMABLE-BOUNDARY-START(38656278559)
            /*long */ get PointerOffset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771376671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._view.PointerOffset;
            }
            //--TRIMMABLE-BOUNDARY-END(38656278559)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12886474783, 60225552385)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886474783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    if (disposing && !this._view.IsClosed && this.CanWrite)
                    {
                        this.Flush();
                    }
                }
                finally
                {
                    {
                        try
                        {
                            this._view.Dispose();
                        }
                        finally
                        {
                            {
                                super.Dispose$1(disposing);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12886474783, 60225552385)
            
            //--TRIMMABLE-BOUNDARY-START(17181442079)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181442079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsOpen)
                {
                    throw new $.$$.System.ObjectDisposedException().$ctor$16("MemoryMappedViewAccessor", $.$sim.System.SR.ObjectDisposed_ViewAccessorClosed);
                }
                this._view.Flush($.$cast(this.Capacity, $.$$.System.UIntPtr));
            }
            //--TRIMMABLE-BOUNDARY-END(17181442079)
            
            static $h = 1572895;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 96010241,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951245855),
    {
      "p": 1179679,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361311263,
        "f": 50331649
      },
      "n": "SafeMemoryMappedViewHandle",
      "d": 1572895,
      "h": 42951245855,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951245855),
//--TRIMMABLE-BOUNDARY-START(38656278559),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771376671,
        "f": 50331649
      },
      "n": "PointerOffset",
      "d": 1572895,
      "h": 38656278559,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656278559)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12886474783, 60225552385),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 1572895,
      "h": 12886474783,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12886474783, 60225552385),
//--TRIMMABLE-BOUNDARY-START(17181442079),
    {
      "r": 65537,
      "n": "Flush",
      "d": 1572895,
      "h": 17181442079,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181442079)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296540191),
    {
      "t": 1507359,
      "n": "_view",
      "d": 1572895,
      "h": 4296540191,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296540191)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591507487),
    {
      "p": [
        {
          "n": "view",
          "p": 1507359
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1572895,
      "h": 8591507487,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591507487)
  ],
  "i": [90177537
  ],
  "h": 1572895
}; }
            static get $b() { return $.$$.System.IO.UnmanagedMemoryAccessor; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedViewAccessor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572895)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638431)
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedViewStream", ($self) => class MemoryMappedViewStream extends $.$$.System.IO.UnmanagedMemoryStream
        {
            //--TRIMMABLE-BOUNDARY-START(4296605727)
            /*MemoryMappedView*/ _view = null;
            //--TRIMMABLE-BOUNDARY-END(4296605727)
            
            //--TRIMMABLE-BOUNDARY-START(8591573023)
            $ctor$8(/*MemoryMappedView*/ view)
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591573023);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(view !== null, "view is null");
                    this._view = view;
                    this.Initialize$1(this._view.ViewHandle, this._view.PointerOffset, this._view.Size, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GetFileAccess(this._view.Access));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591573023)
            
            //--TRIMMABLE-BOUNDARY-START(42951311391)
            /*SafeMemoryMappedViewHandle */ get SafeMemoryMappedViewHandle()
            {
                return this._view.ViewHandle;
            }
            //--TRIMMABLE-BOUNDARY-END(42951311391)
            
            //--TRIMMABLE-BOUNDARY-START(38656344095)
            /*long */ get PointerOffset()
            {
                return this._view.PointerOffset;
            }
            //--TRIMMABLE-BOUNDARY-END(38656344095)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 47246278687, 356577116161)
            /*void */ SetLength(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246278687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, value, "value");
                throw new $.$$.System.NotSupportedException().$ctor$12($.$sim.System.SR.NotSupported_MMViewStreamsFixedLength);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 47246278687, 356577116161)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12886540319, 98879078401)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886540319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    if (disposing && !this._view.IsClosed && this.CanWrite)
                    {
                        this.Flush();
                    }
                }
                finally
                {
                    {
                        try
                        {
                            this._view.Dispose();
                        }
                        finally
                        {
                            {
                                super.Dispose$1(disposing);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12886540319, 98879078401)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17181507615, 128943849473)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181507615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.CanSeek)
                {
                    throw new $.$$.System.ObjectDisposedException().$ctor$16(null, $.$sim.System.SR.ObjectDisposed_StreamIsClosed);
                }
                this._view.Flush($.$cast(this.Capacity, $.$$.System.UIntPtr));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17181507615, 128943849473)
            
            static $h = 1638431;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 96075777,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951311391),
    {
      "p": 1179679,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361376799,
        "f": 50331649
      },
      "n": "SafeMemoryMappedViewHandle",
      "d": 1638431,
      "h": 42951311391,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951311391),
//--TRIMMABLE-BOUNDARY-START(38656344095),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771442207,
        "f": 50331649
      },
      "n": "PointerOffset",
      "d": 1638431,
      "h": 38656344095,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656344095)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 47246278687, 356577116161),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 1638431,
      "h": 47246278687,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47246278687, 356577116161),
//--TRIMMABLE-BOUNDARY-START(ALL, 12886540319, 98879078401),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 1638431,
      "h": 12886540319,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12886540319, 98879078401),
//--TRIMMABLE-BOUNDARY-START(ALL, 17181507615, 128943849473),
    {
      "r": 65537,
      "n": "Flush",
      "d": 1638431,
      "h": 17181507615,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17181507615, 128943849473)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296605727),
    {
      "t": 1507359,
      "n": "_view",
      "d": 1638431,
      "h": 4296605727,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296605727)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591573023),
    {
      "p": [
        {
          "n": "view",
          "p": 1507359
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1638431,
      "h": 8591573023,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591573023)
  ],
  "i": [90177537,89587713
  ],
  "h": 1638431
}; }
            static get $b() { return $.$$.System.IO.UnmanagedMemoryStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedViewStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638431)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread"))
//--TRIMMABLE-BOUNDARY-END(31)
