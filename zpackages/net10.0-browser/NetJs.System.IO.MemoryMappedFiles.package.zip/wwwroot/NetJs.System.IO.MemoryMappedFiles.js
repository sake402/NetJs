
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $stt) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.MemoryMappedFiles", 
    {"h":33161,"f":"System.IO.MemoryMappedFiles","v":"1.0.35.0","a":[{"t":90243073,"c":4385210369},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.MemoryMappedFiles","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.MemoryMappedFiles","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.Nop", ($self) => class Nop extends $.$$.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1737097;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":1737097,"h":4296704393,"f":16777217}],"h":1737097}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.Nop`; }
        });
        
        $asm.$cls("$sim.Interop", ($self) => class Interop
        {
            static $_Libraries;
            static get Libraries()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_Libraries ??= $asm.$ncls("$sim.Interop.Libraries", ($self) => class Libraries
                {
                    /*string*/ static libc = null;
                    /*string*/ static SystemNative = null;
                    /*string*/ static NetSecurityNative = null;
                    /*string*/ static CryptoNative = null;
                    /*string*/ static CompressionNative = null;
                    /*string*/ static GlobalizationNative = null;
                    /*string*/ static IOPortsNative = null;
                    /*string*/ static HostPolicy = null;
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.libc = "libc";
                        }
                        {
                            this.SystemNative = "libSystem.Native";
                        }
                        {
                            this.NetSecurityNative = "libSystem.Net.Security.Native";
                        }
                        {
                            this.CryptoNative = "libSystem.Security.Cryptography.Native.OpenSsl";
                        }
                        {
                            this.CompressionNative = "libSystem.IO.Compression.Native";
                        }
                        {
                            this.GlobalizationNative = "libSystem.Globalization.Native";
                        }
                        {
                            this.IOPortsNative = "libSystem.IO.Ports.Native";
                        }
                        {
                            this.HostPolicy = "libhostpolicy";
                        }
                    }
                    static $h = 295305;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"libc","d":295305,"h":4295262601,"f":4194344},{"t":1310721,"n":"SystemNative","d":295305,"h":8590229897,"f":4194344},{"t":1310721,"n":"NetSecurityNative","d":295305,"h":12885197193,"f":4194344},{"t":1310721,"n":"CryptoNative","d":295305,"h":17180164489,"f":4194344},{"t":1310721,"n":"CompressionNative","d":295305,"h":21475131785,"f":4194344},{"t":1310721,"n":"GlobalizationNative","d":295305,"h":25770099081,"f":4194344},{"t":1310721,"n":"IOPortsNative","d":295305,"h":30065066377,"f":4194344},{"t":1310721,"n":"HostPolicy","d":295305,"h":34360033673,"f":4194344}],"d":98697,"h":295305}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Interop.Libraries`; }
                }, $cls, ($v) => $cls.$_Libraries = $v);
            }
            static $_Sys;
            static get Sys()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_Sys ??= $asm.$ncls("$sim.Interop.Sys", ($self) => class Sys
                {
                    static $_MemoryMappedProtections;
                    static get MemoryMappedProtections()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryMappedProtections ??= $asm.$nstr("$sim.Interop.Sys.MemoryMappedProtections", ($self) => class MemoryMappedProtections extends $.$$.System.Enum
                        {
                            static PROT_NONE = 0;
                            static PROT_READ = 1;
                            static PROT_WRITE = 2;
                            static PROT_EXEC = 4;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "PROT_NONE": 0n,
                                    "PROT_READ": 1n,
                                    "PROT_WRITE": 2n,
                                    "PROT_EXEC": 4n
                                };
                            }
                            static $h = 819593;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":819593,"n":"PROT_NONE","d":819593,"h":4295786889,"f":4194337},{"t":819593,"n":"PROT_READ","d":819593,"h":8590754185,"f":4194337},{"t":819593,"n":"PROT_WRITE","d":819593,"h":12885721481,"f":4194337},{"t":819593,"n":"PROT_EXEC","d":819593,"h":17180688777,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":819593,"h":21475656073,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":360841,"h":819593,"a":[{"t":47710209,"c":4342677505}]}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryMappedProtections`; }
                        }, $cls, ($v) => $cls.$_MemoryMappedProtections = $v);
                    }
                    static $_MemoryMappedFlags;
                    static get MemoryMappedFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryMappedFlags ??= $asm.$nstr("$sim.Interop.Sys.MemoryMappedFlags", ($self) => class MemoryMappedFlags extends $.$$.System.Enum
                        {
                            static MAP_SHARED = 1;
                            static MAP_PRIVATE = 2;
                            static MAP_ANONYMOUS = 16;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "MAP_SHARED": 1n,
                                    "MAP_PRIVATE": 2n,
                                    "MAP_ANONYMOUS": 16n
                                };
                            }
                            static $h = 754057;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":754057,"n":"MAP_SHARED","d":754057,"h":4295721353,"f":4194337},{"t":754057,"n":"MAP_PRIVATE","d":754057,"h":8590688649,"f":4194337},{"t":754057,"n":"MAP_ANONYMOUS","d":754057,"h":12885655945,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":754057,"h":17180623241,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":360841,"h":754057,"a":[{"t":47710209,"c":4342677505}]}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryMappedFlags`; }
                        }, $cls, ($v) => $cls.$_MemoryMappedFlags = $v);
                    }
                    static $_SysConfName;
                    static get SysConfName()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_SysConfName ??= $asm.$nstr("$sim.Interop.Sys.SysConfName", ($self) => class SysConfName extends $.$$.System.Enum
                        {
                            static _SC_CLK_TCK = 1;
                            static _SC_PAGESIZE = 2;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "_SC_CLK_TCK": 1n,
                                    "_SC_PAGESIZE": 2n
                                };
                            }
                            static $h = 1016201;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1016201,"n":"_SC_CLK_TCK","d":1016201,"h":4295983497,"f":4194337},{"t":1016201,"n":"_SC_PAGESIZE","d":1016201,"h":8590950793,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1016201,"h":12885918089,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":360841,"h":1016201}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.SysConfName`; }
                        }, $cls, ($v) => $cls.$_SysConfName = $v);
                    }
                    static $_MemoryMappedSyncFlags;
                    static get MemoryMappedSyncFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryMappedSyncFlags ??= $asm.$nstr("$sim.Interop.Sys.MemoryMappedSyncFlags", ($self) => class MemoryMappedSyncFlags extends $.$$.System.Enum
                        {
                            static MS_ASYNC = 1;
                            static MS_SYNC = 2;
                            static MS_INVALIDATE = 16;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "MS_ASYNC": 1n,
                                    "MS_SYNC": 2n,
                                    "MS_INVALIDATE": 16n
                                };
                            }
                            static $h = 885129;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":885129,"n":"MS_ASYNC","d":885129,"h":4295852425,"f":4194337},{"t":885129,"n":"MS_SYNC","d":885129,"h":8590819721,"f":4194337},{"t":885129,"n":"MS_INVALIDATE","d":885129,"h":12885787017,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":885129,"h":17180754313,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":360841,"h":885129,"a":[{"t":47710209,"c":4342677505}]}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryMappedSyncFlags`; }
                        }, $cls, ($v) => $cls.$_MemoryMappedSyncFlags = $v);
                    }
                    static $_MemoryAdvice;
                    static get MemoryAdvice()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryAdvice ??= $asm.$nstr("$sim.Interop.Sys.MemoryAdvice", ($self) => class MemoryAdvice extends $.$$.System.Enum
                        {
                            static MADV_DONTFORK = 1;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "MADV_DONTFORK": 1n
                                };
                            }
                            static $h = 688521;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":688521,"n":"MADV_DONTFORK","d":688521,"h":4295655817,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":688521,"h":8590623113,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":360841,"h":688521}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryAdvice`; }
                        }, $cls, ($v) => $cls.$_MemoryAdvice = $v);
                    }
                    /*sbyte*/ static s_memfdSupported = 0;
                    static /*bool */ get IsMemfdSupported()
                    {
                        /*sbyte*/ let memfdSupported = $.$sim.Interop.Sys.s_memfdSupported;
                        if (memfdSupported === 0)
                        {
                            $.$$.System.Threading.Interlocked.CompareExchange$8($.$ref(() => $.$sim.Interop.Sys.s_memfdSupported, ($v) => $.$sim.Interop.Sys.s_memfdSupported = $v, $.$$.System.SByte), $.$cast(($.$sim.Interop.Sys.MemfdSupportedImpl() === 1 ? 1 : -1), $.$$.System.SByte), 0);
                            memfdSupported = $.$sim.Interop.Sys.s_memfdSupported;
                        }
                        return memfdSupported > 0;
                    }
                    static /*Error */ ConvertErrorPlatformToPal(/*int*/ platformErrno)
                    {
                        return $.$cast(platformErrno, $.$sim.Interop.Error);
                    }
                    static /*int */ ConvertErrorPalToPlatform(/*Error*/ error)
                    {
                        return error;
                    }
                    static /*byte* */ StrErrorR(/*int*/ platformErrno, /*byte**/ buffer, /*int*/ bufferSize)
                    {
                        /*RefOrPointer<byte>*/ let ptr = buffer;
                        $.$$.System.String.TryCopyTo.call("Error", new ($.$$.System.Span$$($.$$.System.Char))().$ctor$5($.$cast(buffer, $.$typePointer($.$$.System.Void)), bufferSize));
                        return buffer;
                    }
                    static $_OpenFlags;
                    static get OpenFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_OpenFlags ??= $asm.$nstr("$sim.Interop.Sys.OpenFlags", ($self) => class OpenFlags extends $.$$.System.Enum
                        {
                            static O_RDONLY = 0;
                            static O_WRONLY = 1;
                            static O_RDWR = 2;
                            static O_CLOEXEC = 16;
                            static O_CREAT = 32;
                            static O_EXCL = 64;
                            static O_TRUNC = 128;
                            static O_SYNC = 256;
                            static O_NOFOLLOW = 512;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "O_RDONLY": 0n,
                                    "O_WRONLY": 1n,
                                    "O_RDWR": 2n,
                                    "O_CLOEXEC": 16n,
                                    "O_CREAT": 32n,
                                    "O_EXCL": 64n,
                                    "O_TRUNC": 128n,
                                    "O_SYNC": 256n,
                                    "O_NOFOLLOW": 512n
                                };
                            }
                            static $h = 950665;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":950665,"n":"O_RDONLY","d":950665,"h":4295917961,"f":4194337},{"t":950665,"n":"O_WRONLY","d":950665,"h":8590885257,"f":4194337},{"t":950665,"n":"O_RDWR","d":950665,"h":12885852553,"f":4194337},{"t":950665,"n":"O_CLOEXEC","d":950665,"h":17180819849,"f":4194337},{"t":950665,"n":"O_CREAT","d":950665,"h":21475787145,"f":4194337},{"t":950665,"n":"O_EXCL","d":950665,"h":25770754441,"f":4194337},{"t":950665,"n":"O_TRUNC","d":950665,"h":30065721737,"f":4194337},{"t":950665,"n":"O_SYNC","d":950665,"h":34360689033,"f":4194337},{"t":950665,"n":"O_NOFOLLOW","d":950665,"h":38655656329,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":950665,"h":42950623625,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":360841,"h":950665,"a":[{"t":47710209,"c":4342677505}]}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.OpenFlags`; }
                        }, $cls, ($v) => $cls.$_OpenFlags = $v);
                    }
                    static /*Error */ GetLastError()
                    {
                        return $.$sim.Interop.Sys.ConvertErrorPlatformToPal($.$$.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    static /*ErrorInfo */ GetLastErrorInfo()
                    {
                        return new $.$sim.Interop.ErrorInfo().$ctor$3($.$$.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    static /*string */ StrError(/*int*/ platformErrno)
                    {
                        /*int*/ let MaxBufferLength = 1024;
                        /*byte**/ let buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$$.System.Byte, MaxBufferLength, null);
                        /*byte**/ let message = $.$sim.Interop.Sys.StrErrorR(platformErrno, buffer, MaxBufferLength);
                        if (message === null)
                        {
                            message = buffer;
                        }
                        return $.$$.System.Runtime.InteropServices.Marshal.PtrToStringUTF8$1($.$cast(message, $.$$.System.IntPtr));
                    }
                    static /*int */ MUnmap(/*IntPtr*/ addr, /*ulong*/ len)
                    {
                        return 0;
                    }
                    static /*int */ FTruncate(/*SafeFileHandle*/ fd, /*long*/ length)
                    {
                        return 0;
                    }
                    static /*int */ FStat(/*SafeHandle*/ fd, /*out FileStatus*/ output)
                    {
                        output.$v = $.$default($.$sim.Interop.Sys.FileStatus);
                        return -1;
                    }
                    static /*int */ Stat(/*string*/ path, /*out FileStatus*/ output)
                    {
                        output.$v = $.$default($.$sim.Interop.Sys.FileStatus);
                        return -1;
                    }
                    static /*int */ LStat(/*string*/ path, /*out FileStatus*/ output)
                    {
                        output.$v = $.$default($.$sim.Interop.Sys.FileStatus);
                        return -1;
                    }
                    static /*long */ SysConf(/*SysConfName*/ name)
                    {
                        return BigInt(-1);
                    }
                    static /*int */ Unlink(/*string*/ pathname)
                    {
                        return -1;
                    }
                    static /*int */ Close(/*IntPtr*/ fd)
                    {
                        return 0;
                    }
                    static $_FileStatus;
                    static get FileStatus()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_FileStatus ??= $asm.$nstr("$sim.Interop.Sys.FileStatus", ($self) => class FileStatus extends $.$$.System.ValueType
                        {
                            /*FileStatusFlags*/  get Flags() { return this.$getField(0, $.$sim.Interop.Sys.FileStatusFlags); }
                            /*FileStatusFlags*/  set Flags(value) { this.$setField(0, $.$sim.Interop.Sys.FileStatusFlags, value); }
                            /*int*/  get Mode() { return this.$getField(4, $.$$.System.Int32); }
                            /*int*/  set Mode(value) { this.$setField(4, $.$$.System.Int32, value); }
                            /*uint*/  get Uid() { return this.$getField(8, $.$$.System.UInt32); }
                            /*uint*/  set Uid(value) { this.$setField(8, $.$$.System.UInt32, value); }
                            /*uint*/  get Gid() { return this.$getField(12, $.$$.System.UInt32); }
                            /*uint*/  set Gid(value) { this.$setField(12, $.$$.System.UInt32, value); }
                            /*long*/  get Size() { return this.$getField(16, $.$$.System.Int64); }
                            /*long*/  set Size(value) { this.$setField(16, $.$$.System.Int64, value); }
                            /*long*/  get ATime() { return this.$getField(24, $.$$.System.Int64); }
                            /*long*/  set ATime(value) { this.$setField(24, $.$$.System.Int64, value); }
                            /*long*/  get ATimeNsec() { return this.$getField(32, $.$$.System.Int64); }
                            /*long*/  set ATimeNsec(value) { this.$setField(32, $.$$.System.Int64, value); }
                            /*long*/  get MTime() { return this.$getField(40, $.$$.System.Int64); }
                            /*long*/  set MTime(value) { this.$setField(40, $.$$.System.Int64, value); }
                            /*long*/  get MTimeNsec() { return this.$getField(48, $.$$.System.Int64); }
                            /*long*/  set MTimeNsec(value) { this.$setField(48, $.$$.System.Int64, value); }
                            /*long*/  get CTime() { return this.$getField(56, $.$$.System.Int64); }
                            /*long*/  set CTime(value) { this.$setField(56, $.$$.System.Int64, value); }
                            /*long*/  get CTimeNsec() { return this.$getField(64, $.$$.System.Int64); }
                            /*long*/  set CTimeNsec(value) { this.$setField(64, $.$$.System.Int64, value); }
                            /*long*/  get BirthTime() { return this.$getField(72, $.$$.System.Int64); }
                            /*long*/  set BirthTime(value) { this.$setField(72, $.$$.System.Int64, value); }
                            /*long*/  get BirthTimeNsec() { return this.$getField(80, $.$$.System.Int64); }
                            /*long*/  set BirthTimeNsec(value) { this.$setField(80, $.$$.System.Int64, value); }
                            /*long*/  get Dev() { return this.$getField(88, $.$$.System.Int64); }
                            /*long*/  set Dev(value) { this.$setField(88, $.$$.System.Int64, value); }
                            /*long*/  get RDev() { return this.$getField(96, $.$$.System.Int64); }
                            /*long*/  set RDev(value) { this.$setField(96, $.$$.System.Int64, value); }
                            /*long*/  get Ino() { return this.$getField(104, $.$$.System.Int64); }
                            /*long*/  set Ino(value) { this.$setField(104, $.$$.System.Int64, value); }
                            /*uint*/  get UserFlags() { return this.$getField(112, $.$$.System.UInt32); }
                            /*uint*/  set UserFlags(value) { this.$setField(112, $.$$.System.UInt32, value); }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy.Flags = this.Flags;
                                copy.Mode = this.Mode;
                                copy.Uid = this.Uid;
                                copy.Gid = this.Gid;
                                copy.Size = this.Size;
                                copy.ATime = this.ATime;
                                copy.ATimeNsec = this.ATimeNsec;
                                copy.MTime = this.MTime;
                                copy.MTimeNsec = this.MTimeNsec;
                                copy.CTime = this.CTime;
                                copy.CTimeNsec = this.CTimeNsec;
                                copy.BirthTime = this.BirthTime;
                                copy.BirthTimeNsec = this.BirthTimeNsec;
                                copy.Dev = this.Dev;
                                copy.RDev = this.RDev;
                                copy.Ino = this.Ino;
                                copy.UserFlags = this.UserFlags;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this.Flags = 0;
                                this.Mode = 0;
                                this.Uid = 0;
                                this.Gid = 0;
                                this.Size = 0n;
                                this.ATime = 0n;
                                this.ATimeNsec = 0n;
                                this.MTime = 0n;
                                this.MTimeNsec = 0n;
                                this.CTime = 0n;
                                this.CTimeNsec = 0n;
                                this.BirthTime = 0n;
                                this.BirthTimeNsec = 0n;
                                this.Dev = 0n;
                                this.RDev = 0n;
                                this.Ino = 0n;
                                this.UserFlags = 0;
                            }
                            static $h = 491913;
                            static $z = 116;
                            static $f = 0b10100010000001010000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":557449,"n":"Flags","d":491913,"h":4295459209,"f":4194312},{"t":655361,"n":"Mode","d":491913,"h":8590426505,"f":4194312},{"t":720897,"n":"Uid","d":491913,"h":12885393801,"f":4194312},{"t":720897,"n":"Gid","d":491913,"h":17180361097,"f":4194312},{"t":917505,"n":"Size","d":491913,"h":21475328393,"f":4194312},{"t":917505,"n":"ATime","d":491913,"h":25770295689,"f":4194312},{"t":917505,"n":"ATimeNsec","d":491913,"h":30065262985,"f":4194312},{"t":917505,"n":"MTime","d":491913,"h":34360230281,"f":4194312},{"t":917505,"n":"MTimeNsec","d":491913,"h":38655197577,"f":4194312},{"t":917505,"n":"CTime","d":491913,"h":42950164873,"f":4194312},{"t":917505,"n":"CTimeNsec","d":491913,"h":47245132169,"f":4194312},{"t":917505,"n":"BirthTime","d":491913,"h":51540099465,"f":4194312},{"t":917505,"n":"BirthTimeNsec","d":491913,"h":55835066761,"f":4194312},{"t":917505,"n":"Dev","d":491913,"h":60130034057,"f":4194312},{"t":917505,"n":"RDev","d":491913,"h":64425001353,"f":4194312},{"t":917505,"n":"Ino","d":491913,"h":68719968649,"f":4194312},{"t":720897,"n":"UserFlags","d":491913,"h":73014935945,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$2","d":491913,"h":77309903241,"f":16777217}],"d":360841,"h":491913,"a":[{"t":109772801,"c":4404740097,"a":[{"v":0,"t":105250817}]}]}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static get $fullName() { return `Interop.Sys.FileStatus`; }
                        }, $cls, ($v) => $cls.$_FileStatus = $v);
                    }
                    static $_FileTypes;
                    static get FileTypes()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_FileTypes ??= $asm.$ncls("$sim.Interop.Sys.FileTypes", ($self) => class FileTypes
                        {
                            /*int*/ static S_IFMT = 61440;
                            /*int*/ static S_IFIFO = 4096;
                            /*int*/ static S_IFCHR = 8192;
                            /*int*/ static S_IFDIR = 16384;
                            /*int*/ static S_IFBLK = 24576;
                            /*int*/ static S_IFREG = 32768;
                            /*int*/ static S_IFLNK = 40960;
                            /*int*/ static S_IFSOCK = 49152;
                            static $h = 622985;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"S_IFMT","d":622985,"h":4295590281,"f":4194344},{"t":655361,"n":"S_IFIFO","d":622985,"h":8590557577,"f":4194344},{"t":655361,"n":"S_IFCHR","d":622985,"h":12885524873,"f":4194344},{"t":655361,"n":"S_IFDIR","d":622985,"h":17180492169,"f":4194344},{"t":655361,"n":"S_IFBLK","d":622985,"h":21475459465,"f":4194344},{"t":655361,"n":"S_IFREG","d":622985,"h":25770426761,"f":4194344},{"t":655361,"n":"S_IFLNK","d":622985,"h":30065394057,"f":4194344},{"t":655361,"n":"S_IFSOCK","d":622985,"h":34360361353,"f":4194344}],"d":360841,"h":622985}; }
                            static get $b() { return $.$$.System.Object; }
                            static get $fullName() { return `Interop.Sys.FileTypes`; }
                        }, $cls, ($v) => $cls.$_FileTypes = $v);
                    }
                    static $_FileStatusFlags;
                    static get FileStatusFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_FileStatusFlags ??= $asm.$nstr("$sim.Interop.Sys.FileStatusFlags", ($self) => class FileStatusFlags extends $.$$.System.Enum
                        {
                            static None = 0;
                            static HasBirthTime = 1;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "None": 0n,
                                    "HasBirthTime": 1n
                                };
                            }
                            static $h = 557449;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$$.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":557449,"n":"None","d":557449,"h":4295524745,"f":4194337},{"t":557449,"n":"HasBirthTime","d":557449,"h":8590492041,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":557449,"h":12885459337,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":360841,"h":557449,"a":[{"t":47710209,"c":4342677505}]}; }
                            static get $b() { return $.$$.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.FileStatusFlags`; }
                        }, $cls, ($v) => $cls.$_FileStatusFlags = $v);
                    }
                    static $_Fcntl;
                    static get Fcntl()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_Fcntl ??= $asm.$ncls("$sim.Interop.Sys.Fcntl", ($self) => class Fcntl
                        {
                            static /*int */ DangerousSetIsNonBlocking(/*IntPtr*/ fd, /*int*/ isNonBlocking)
                            {
                                return -1;
                            }
                            static /*int */ SetIsNonBlocking(/*SafeHandle*/ fd, /*int*/ isNonBlocking)
                            {
                                return -1;
                            }
                            static /*int */ GetIsNonBlocking(/*SafeHandle*/ fd, /*out bool*/ isNonBlocking)
                            {
                                isNonBlocking.$v = false;
                                return -1;
                            }
                            static /*int */ SetFD(/*SafeHandle*/ fd, /*int*/ flags)
                            {
                                return -1;
                            }
                            static /*int */ GetFD$1(/*SafeHandle*/ fd)
                            {
                                return -1;
                            }
                            static /*int */ GetFD(/*IntPtr*/ fd)
                            {
                                return -1;
                            }
                            static $h = 426377;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"fd","p":786433},{"n":"isNonBlocking","p":655361}],"n":"DangerousSetIsNonBlocking","d":426377,"h":4295393673,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlSetIsNonBlocking","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109445121},{"n":"isNonBlocking","p":655361}],"n":"SetIsNonBlocking","d":426377,"h":8590360969,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlSetIsNonBlocking","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109445121},{"n":"isNonBlocking","p":262145,"f":2,"a":[{"t":105578497,"c":8695513089,"a":[{"v":2,"t":110755841}]}]}],"n":"GetIsNonBlocking","d":426377,"h":12885328265,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlGetIsNonBlocking","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109445121},{"n":"flags","p":655361}],"n":"SetFD","d":426377,"h":17180295561,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlSetFD","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109445121}],"n":"GetFD","o":"@$1","d":426377,"h":21475262857,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlGetFD","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":786433}],"n":"GetFD","d":426377,"h":25770230153,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlGetFD","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]}],"d":360841,"h":426377}; }
                            static get $b() { return $.$$.System.Object; }
                            static get $fullName() { return `Interop.Sys.Fcntl`; }
                        }, $cls, ($v) => $cls.$_Fcntl = $v);
                    }
                    static /*SafeFileHandle */ Open(/*string*/ filename, /*OpenFlags*/ flags, /*int*/ mode)
                    {
                        return new $.$$.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$4();
                    }
                    static /*IntPtr */ MMap(/*IntPtr*/ addr, /*ulong*/ len, /*MemoryMappedProtections*/ prot, /*MemoryMappedFlags*/ flags, /*SafeFileHandle*/ fd, /*long*/ offset)
                    {
                        return $.$$.System.IntPtr.Zero;
                    }
                    static /*IntPtr */ MMap$1(/*IntPtr*/ addr, /*ulong*/ len, /*MemoryMappedProtections*/ prot, /*MemoryMappedFlags*/ flags, /*IntPtr*/ fd, /*long*/ offset)
                    {
                        return $.$$.System.IntPtr.Zero;
                    }
                    static /*int */ MAdvise(/*IntPtr*/ addr, /*ulong*/ length, /*MemoryAdvice*/ advice)
                    {
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*SafeFileHandle */ MemfdCreate(/*string*/ name, /*int*/ isReadonly)
                    {
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*int */ MemfdSupportedImpl()
                    {
                        return 0;
                    }
                    static /*int */ MSync(/*IntPtr*/ addr, /*ulong*/ len, /*MemoryMappedSyncFlags*/ flags)
                    {
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*SafeFileHandle */ ShmOpen(/*string*/ name, /*OpenFlags*/ flags, /*int*/ mode)
                    {
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*int */ ShmUnlink(/*string*/ name)
                    {
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static $h = 360841;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":81604739465,"f":50331688},"n":"IsMemfdSupported","d":360841,"h":77309772169,"f":2097192}],"m":[{"r":655361,"p":[{"n":"addr","p":786433},{"n":"len","p":983041}],"n":"MUnmap","d":360841,"h":4295328137,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MUnmap","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":786433,"p":[{"n":"addr","p":786433},{"n":"len","p":983041},{"n":"prot","p":819593},{"n":"flags","p":754057},{"n":"fd","p":7143425},{"n":"offset","p":917505}],"n":"MMap","d":360841,"h":17180230025,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MMap","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":786433,"p":[{"n":"addr","p":786433},{"n":"len","p":983041},{"n":"prot","p":819593},{"n":"flags","p":754057},{"n":"fd","p":786433},{"n":"offset","p":917505}],"n":"MMap","o":"@$1","d":360841,"h":21475197321,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MMap","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":917505,"p":[{"n":"name","p":1016201}],"n":"SysConf","d":360841,"h":30065131913,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_SysConf","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":7143425,"p":[{"n":"filename","p":1310721},{"n":"flags","p":950665},{"n":"mode","p":655361}],"n":"Open","d":360841,"h":34360099209,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Open","t":1310721},{"n":"StringMarshalling","v":1,"t":109707265},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"addr","p":786433},{"n":"len","p":983041},{"n":"flags","p":885129}],"n":"MSync","d":360841,"h":42950033801,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MSync","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"addr","p":786433},{"n":"length","p":983041},{"n":"advice","p":688521}],"n":"MAdvise","d":360841,"h":47245001097,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MAdvise","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":7143425,"p":[{"n":"name","p":1310721},{"n":"flags","p":950665},{"n":"mode","p":655361}],"n":"ShmOpen","d":360841,"h":55834935689,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ShmOpen","t":1310721},{"n":"StringMarshalling","v":1,"t":109707265},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"name","p":1310721}],"n":"ShmUnlink","d":360841,"h":60129902985,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ShmUnlink","t":1310721},{"n":"StringMarshalling","v":1,"t":109707265},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":7143425,"p":[{"n":"name","p":1310721},{"n":"isReadonly","p":655361}],"n":"MemfdCreate","d":360841,"h":64424870281,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MemfdCreate","t":1310721},{"n":"StringMarshalling","v":1,"t":109707265},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"n":"MemfdSupportedImpl","d":360841,"h":68719837577,"f":16777250,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_IsMemfdSupported","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"pathname","p":1310721}],"n":"Unlink","d":360841,"h":85899706761,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Unlink","t":1310721},{"n":"StringMarshalling","v":1,"t":109707265},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":164233,"n":"GetLastError","d":360841,"h":94489641353,"f":16777256},{"r":229769,"n":"GetLastErrorInfo","d":360841,"h":98784608649,"f":16777256},{"r":1310721,"p":[{"n":"platformErrno","p":655361}],"n":"StrError","d":360841,"h":103079575945,"f":16777256},{"r":164233,"p":[{"n":"platformErrno","p":655361}],"n":"ConvertErrorPlatformToPal","d":360841,"h":107374543241,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ConvertErrorPlatformToPal","t":1310721}]},{"t":109838337,"c":4404805633}]},{"r":655361,"p":[{"n":"error","p":164233}],"n":"ConvertErrorPalToPlatform","d":360841,"h":111669510537,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ConvertErrorPalToPlatform","t":1310721}]},{"t":109838337,"c":4404805633}]},{"r":$.$typePointer($.$$.System.Byte).$h,"p":[{"n":"platformErrno","p":655361},{"n":"buffer","p":$.$typePointer($.$$.System.Byte).$h},{"n":"bufferSize","p":655361}],"n":"StrErrorR","d":360841,"h":115964477833,"f":16777250,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_StrErrorR","t":1310721}]}]},{"r":655361,"p":[{"n":"fd","p":786433}],"n":"Close","d":360841,"h":120259445129,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Close","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109445121},{"n":"output","p":491913,"f":2}],"n":"FStat","d":360841,"h":137439314313,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FStat","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"path","p":1310721},{"n":"output","p":491913,"f":2}],"n":"Stat","d":360841,"h":141734281609,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Stat","t":1310721},{"n":"StringMarshalling","v":1,"t":109707265},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"path","p":1310721},{"n":"output","p":491913,"f":2}],"n":"LStat","d":360841,"h":146029248905,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_LStat","t":1310721},{"n":"StringMarshalling","v":1,"t":109707265},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":7143425},{"n":"length","p":917505}],"n":"FTruncate","d":360841,"h":154619183497,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FTruncate","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]}],"l":[{"t":327681,"n":"s_memfdSupported","d":360841,"h":73014804873,"f":4194338}],"j":[819593,754057,1016201,885129,688521,950665,491913,622985,557449,426377],"d":98697,"h":360841}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Interop.Sys`; }
                }, $cls, ($v) => $cls.$_Sys = $v);
            }
            static /*void */ ThrowExceptionForIoErrno(/*ErrorInfo*/ errorInfo, /*string?*/ path, /*bool*/ isDirError)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(errorInfo.Error !== 0/*Error.SUCCESS*/, "errorInfo.Error != Error.SUCCESS");
                $.$$.System.Diagnostics.Debug.Assert$2(errorInfo.Error !== 65563/*Error.EINTR*/, "EINTR errors should be handled by the native shim and never bubble up to managed code");
                throw $.$sim.Interop.GetExceptionForIoErrno(errorInfo.Clone(), path, isDirError);
            }
            static /*void */ CheckIo$3(/*Error*/ error, /*string?*/ path, /*bool*/ isDirError)
            {
                if (error !== 0/*Interop.Error.SUCCESS*/)
                {
                    $.$sim.Interop.ThrowExceptionForIoErrno($.$sim.InteropErrorExtensions.Info(error), path, isDirError);
                }
            }
            static /*long */ CheckIo$1(/*long*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                if (result < 0n)
                {
                    $.$sim.Interop.ThrowExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), path, isDirError);
                }
                return result;
            }
            static /*void */ ThrowIOExceptionForLastError()
            {
                $.$sim.Interop.ThrowExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
            }
            static /*int */ CheckIo(/*int*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                $.$sim.Interop.CheckIo$1($.$cast(result, $.$$.System.Int64), path, isDirError);
                return result;
            }
            static /*IntPtr */ CheckIo$2(/*IntPtr*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                $.$sim.Interop.CheckIo$1($.$cast(result, $.$$.System.Int64), path, isDirError);
                return result;
            }
            static /*TSafeHandle */ CheckIo$4(TSafeHandle, /*TSafeHandle*/ handle, /*string?*/ path, /*bool*/ isDirError)
            {
                if (handle.IsInvalid)
                {
                    /*Exception*/ let e = $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), path, isDirError);
                    $.$dsp(handle, TSafeHandle, ($t) => $t.Dispose,);
                    throw e;
                }
                return handle;
            }
            static /*Exception */ GetExceptionForIoErrno(/*ErrorInfo*/ errorInfo, /*string?*/ path, /*bool*/ isDirError)
            {
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    let $switch1 = $switchJumpState1 ?? (errorInfo.Error);
                    switch($switch1)
                    {
                        case 65581/*Error.ENOENT*/:
                        if (!isDirError && (path === null || ParentDirectoryExists(path)))
                        {
                            return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.IO.FileNotFoundException().$ctor$18($.$sim.System.SR.Format$6($.$sim.System.SR.IO_FileNotFound_FileName, path), path) : new $.$$.System.IO.FileNotFoundException().$ctor$19($.$sim.System.SR.IO_FileNotFound);
                        }
                        $switchJumpState1 = 65593/*Error.ENOTDIR*/; /*goto case Error.ENOTDIR*/
                        continue $switchJumpStart1;
                        case 65593/*Error.ENOTDIR*/:
                        return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.IO.DirectoryNotFoundException().$ctor$17($.$sim.System.SR.Format$6($.$sim.System.SR.IO_PathNotFound_Path, path)) : new $.$$.System.IO.DirectoryNotFoundException().$ctor$17($.$sim.System.SR.IO_PathNotFound_NoPathName);
                        case 65538/*Error.EACCES*/:
                        case 65544/*Error.EBADF*/:
                        case 65602/*Error.EPERM*/:
                        /*Exception*/ let inner = $.$sim.Interop.GetIOException(errorInfo.Clone(), null);
                        return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.UnauthorizedAccessException().$ctor$11($.$sim.System.SR.Format$6($.$sim.System.SR.UnauthorizedAccess_IODenied_Path, path), inner) : new $.$$.System.UnauthorizedAccessException().$ctor$11($.$sim.System.SR.UnauthorizedAccess_IODenied_NoPathName, inner);
                        case 65573/*Error.ENAMETOOLONG*/:
                        return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.IO.PathTooLongException().$ctor$17($.$sim.System.SR.Format$6($.$sim.System.SR.IO_PathTooLong_Path, path)) : new $.$$.System.IO.PathTooLongException().$ctor$17($.$sim.System.SR.IO_PathTooLong);
                        case 65542/*Error.EWOULDBLOCK*/:
                        return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.IO.IOException().$ctor$12($.$sim.System.SR.Format$6($.$sim.System.SR.IO_SharingViolation_File, path), errorInfo.RawErrno) : new $.$$.System.IO.IOException().$ctor$12($.$sim.System.SR.IO_SharingViolation_NoFileName, errorInfo.RawErrno);
                        case 65547/*Error.ECANCELED*/:
                        return new $.$$.System.OperationCanceledException().$ctor$9();
                        case 65558/*Error.EFBIG*/:
                        return new $.$$.System.ArgumentOutOfRangeException().$ctor$19("value", $.$sim.System.SR.ArgumentOutOfRange_FileLengthTooBig);
                        case 65556/*Error.EEXIST*/:
                        if (!$.$$.System.String.IsNullOrEmpty(path))
                        {
                            return new $.$$.System.IO.IOException().$ctor$12($.$sim.System.SR.Format$6($.$sim.System.SR.IO_FileExists_Name, path), errorInfo.RawErrno);
                        }
                        $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                        continue $switchJumpStart1;
                        default:
                        return $.$sim.Interop.GetIOException(errorInfo.Clone(), path);
                        /*static bool*/  function ParentDirectoryExists(/*string*/ fullPath)
                        {
                            /*string?*/ let parentPath = $.$$.System.IO.Path.GetDirectoryName$1($.$$.System.IO.Path.TrimEndingDirectorySeparator$1(fullPath));
                            return $.$$.System.IO.Directory.Exists(parentPath);
                        }
                    }
                    break;
                }
            }
            static /*Exception */ GetIOException(/*Interop.ErrorInfo*/ errorInfo, /*string?*/ path)
            {
                /*string*/ let msg = errorInfo.GetErrorMessage();
                return new $.$$.System.IO.IOException().$ctor$12($.$$.System.String.IsNullOrEmpty(path) ? msg : `${msg} : '${path}'`, errorInfo.RawErrno);
            }
            static $_Error;
            static get Error()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_Error ??= $asm.$nstr("$sim.Interop.Error", ($self) => class Error extends $.$$.System.Enum
                {
                    static SUCCESS = 0;
                    static E2BIG = 65537;
                    static EACCES = 65538;
                    static EADDRINUSE = 65539;
                    static EADDRNOTAVAIL = 65540;
                    static EAFNOSUPPORT = 65541;
                    static EAGAIN = 65542;
                    static EALREADY = 65543;
                    static EBADF = 65544;
                    static EBADMSG = 65545;
                    static EBUSY = 65546;
                    static ECANCELED = 65547;
                    static ECHILD = 65548;
                    static ECONNABORTED = 65549;
                    static ECONNREFUSED = 65550;
                    static ECONNRESET = 65551;
                    static EDEADLK = 65552;
                    static EDESTADDRREQ = 65553;
                    static EDOM = 65554;
                    static EDQUOT = 65555;
                    static EEXIST = 65556;
                    static EFAULT = 65557;
                    static EFBIG = 65558;
                    static EHOSTUNREACH = 65559;
                    static EIDRM = 65560;
                    static EILSEQ = 65561;
                    static EINPROGRESS = 65562;
                    static EINTR = 65563;
                    static EINVAL = 65564;
                    static EIO = 65565;
                    static EISCONN = 65566;
                    static EISDIR = 65567;
                    static ELOOP = 65568;
                    static EMFILE = 65569;
                    static EMLINK = 65570;
                    static EMSGSIZE = 65571;
                    static EMULTIHOP = 65572;
                    static ENAMETOOLONG = 65573;
                    static ENETDOWN = 65574;
                    static ENETRESET = 65575;
                    static ENETUNREACH = 65576;
                    static ENFILE = 65577;
                    static ENOBUFS = 65578;
                    static ENODEV = 65580;
                    static ENOENT = 65581;
                    static ENOEXEC = 65582;
                    static ENOLCK = 65583;
                    static ENOLINK = 65584;
                    static ENOMEM = 65585;
                    static ENOMSG = 65586;
                    static ENOPROTOOPT = 65587;
                    static ENOSPC = 65588;
                    static ENOSYS = 65591;
                    static ENOTCONN = 65592;
                    static ENOTDIR = 65593;
                    static ENOTEMPTY = 65594;
                    static ENOTRECOVERABLE = 65595;
                    static ENOTSOCK = 65596;
                    static ENOTSUP = 65597;
                    static ENOTTY = 65598;
                    static ENXIO = 65599;
                    static EOVERFLOW = 65600;
                    static EOWNERDEAD = 65601;
                    static EPERM = 65602;
                    static EPIPE = 65603;
                    static EPROTO = 65604;
                    static EPROTONOSUPPORT = 65605;
                    static EPROTOTYPE = 65606;
                    static ERANGE = 65607;
                    static EROFS = 65608;
                    static ESPIPE = 65609;
                    static ESRCH = 65610;
                    static ESTALE = 65611;
                    static ETIMEDOUT = 65613;
                    static ETXTBSY = 65614;
                    static EXDEV = 65615;
                    static ESOCKTNOSUPPORT = 65630;
                    static EPFNOSUPPORT = 65632;
                    static ESHUTDOWN = 65644;
                    static EHOSTDOWN = 65648;
                    static ENODATA = 65649;
                    static EHOSTNOTFOUND = 131073;
                    static ESOCKETERROR = 131074;
                    static EOPNOTSUPP = 65597;
                    static EWOULDBLOCK = 65542;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "SUCCESS": 0n,
                            "E2BIG": 65537n,
                            "EACCES": 65538n,
                            "EADDRINUSE": 65539n,
                            "EADDRNOTAVAIL": 65540n,
                            "EAFNOSUPPORT": 65541n,
                            "EAGAIN": 65542n,
                            "EALREADY": 65543n,
                            "EBADF": 65544n,
                            "EBADMSG": 65545n,
                            "EBUSY": 65546n,
                            "ECANCELED": 65547n,
                            "ECHILD": 65548n,
                            "ECONNABORTED": 65549n,
                            "ECONNREFUSED": 65550n,
                            "ECONNRESET": 65551n,
                            "EDEADLK": 65552n,
                            "EDESTADDRREQ": 65553n,
                            "EDOM": 65554n,
                            "EDQUOT": 65555n,
                            "EEXIST": 65556n,
                            "EFAULT": 65557n,
                            "EFBIG": 65558n,
                            "EHOSTUNREACH": 65559n,
                            "EIDRM": 65560n,
                            "EILSEQ": 65561n,
                            "EINPROGRESS": 65562n,
                            "EINTR": 65563n,
                            "EINVAL": 65564n,
                            "EIO": 65565n,
                            "EISCONN": 65566n,
                            "EISDIR": 65567n,
                            "ELOOP": 65568n,
                            "EMFILE": 65569n,
                            "EMLINK": 65570n,
                            "EMSGSIZE": 65571n,
                            "EMULTIHOP": 65572n,
                            "ENAMETOOLONG": 65573n,
                            "ENETDOWN": 65574n,
                            "ENETRESET": 65575n,
                            "ENETUNREACH": 65576n,
                            "ENFILE": 65577n,
                            "ENOBUFS": 65578n,
                            "ENODEV": 65580n,
                            "ENOENT": 65581n,
                            "ENOEXEC": 65582n,
                            "ENOLCK": 65583n,
                            "ENOLINK": 65584n,
                            "ENOMEM": 65585n,
                            "ENOMSG": 65586n,
                            "ENOPROTOOPT": 65587n,
                            "ENOSPC": 65588n,
                            "ENOSYS": 65591n,
                            "ENOTCONN": 65592n,
                            "ENOTDIR": 65593n,
                            "ENOTEMPTY": 65594n,
                            "ENOTRECOVERABLE": 65595n,
                            "ENOTSOCK": 65596n,
                            "ENOTSUP": 65597n,
                            "ENOTTY": 65598n,
                            "ENXIO": 65599n,
                            "EOVERFLOW": 65600n,
                            "EOWNERDEAD": 65601n,
                            "EPERM": 65602n,
                            "EPIPE": 65603n,
                            "EPROTO": 65604n,
                            "EPROTONOSUPPORT": 65605n,
                            "EPROTOTYPE": 65606n,
                            "ERANGE": 65607n,
                            "EROFS": 65608n,
                            "ESPIPE": 65609n,
                            "ESRCH": 65610n,
                            "ESTALE": 65611n,
                            "ETIMEDOUT": 65613n,
                            "ETXTBSY": 65614n,
                            "EXDEV": 65615n,
                            "ESOCKTNOSUPPORT": 65630n,
                            "EPFNOSUPPORT": 65632n,
                            "ESHUTDOWN": 65644n,
                            "EHOSTDOWN": 65648n,
                            "ENODATA": 65649n,
                            "EHOSTNOTFOUND": 131073n,
                            "ESOCKETERROR": 131074n,
                            "EOPNOTSUPP": 65597n,
                            "EWOULDBLOCK": 65542n
                        };
                    }
                    static $h = 164233;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":164233,"n":"SUCCESS","d":164233,"h":4295131529,"f":4194337},{"t":164233,"n":"E2BIG","d":164233,"h":8590098825,"f":4194337},{"t":164233,"n":"EACCES","d":164233,"h":12885066121,"f":4194337},{"t":164233,"n":"EADDRINUSE","d":164233,"h":17180033417,"f":4194337},{"t":164233,"n":"EADDRNOTAVAIL","d":164233,"h":21475000713,"f":4194337},{"t":164233,"n":"EAFNOSUPPORT","d":164233,"h":25769968009,"f":4194337},{"t":164233,"n":"EAGAIN","d":164233,"h":30064935305,"f":4194337},{"t":164233,"n":"EALREADY","d":164233,"h":34359902601,"f":4194337},{"t":164233,"n":"EBADF","d":164233,"h":38654869897,"f":4194337},{"t":164233,"n":"EBADMSG","d":164233,"h":42949837193,"f":4194337},{"t":164233,"n":"EBUSY","d":164233,"h":47244804489,"f":4194337},{"t":164233,"n":"ECANCELED","d":164233,"h":51539771785,"f":4194337},{"t":164233,"n":"ECHILD","d":164233,"h":55834739081,"f":4194337},{"t":164233,"n":"ECONNABORTED","d":164233,"h":60129706377,"f":4194337},{"t":164233,"n":"ECONNREFUSED","d":164233,"h":64424673673,"f":4194337},{"t":164233,"n":"ECONNRESET","d":164233,"h":68719640969,"f":4194337},{"t":164233,"n":"EDEADLK","d":164233,"h":73014608265,"f":4194337},{"t":164233,"n":"EDESTADDRREQ","d":164233,"h":77309575561,"f":4194337},{"t":164233,"n":"EDOM","d":164233,"h":81604542857,"f":4194337},{"t":164233,"n":"EDQUOT","d":164233,"h":85899510153,"f":4194337},{"t":164233,"n":"EEXIST","d":164233,"h":90194477449,"f":4194337},{"t":164233,"n":"EFAULT","d":164233,"h":94489444745,"f":4194337},{"t":164233,"n":"EFBIG","d":164233,"h":98784412041,"f":4194337},{"t":164233,"n":"EHOSTUNREACH","d":164233,"h":103079379337,"f":4194337},{"t":164233,"n":"EIDRM","d":164233,"h":107374346633,"f":4194337},{"t":164233,"n":"EILSEQ","d":164233,"h":111669313929,"f":4194337},{"t":164233,"n":"EINPROGRESS","d":164233,"h":115964281225,"f":4194337},{"t":164233,"n":"EINTR","d":164233,"h":120259248521,"f":4194337},{"t":164233,"n":"EINVAL","d":164233,"h":124554215817,"f":4194337},{"t":164233,"n":"EIO","d":164233,"h":128849183113,"f":4194337},{"t":164233,"n":"EISCONN","d":164233,"h":133144150409,"f":4194337},{"t":164233,"n":"EISDIR","d":164233,"h":137439117705,"f":4194337},{"t":164233,"n":"ELOOP","d":164233,"h":141734085001,"f":4194337},{"t":164233,"n":"EMFILE","d":164233,"h":146029052297,"f":4194337},{"t":164233,"n":"EMLINK","d":164233,"h":150324019593,"f":4194337},{"t":164233,"n":"EMSGSIZE","d":164233,"h":154618986889,"f":4194337},{"t":164233,"n":"EMULTIHOP","d":164233,"h":158913954185,"f":4194337},{"t":164233,"n":"ENAMETOOLONG","d":164233,"h":163208921481,"f":4194337},{"t":164233,"n":"ENETDOWN","d":164233,"h":167503888777,"f":4194337},{"t":164233,"n":"ENETRESET","d":164233,"h":171798856073,"f":4194337},{"t":164233,"n":"ENETUNREACH","d":164233,"h":176093823369,"f":4194337},{"t":164233,"n":"ENFILE","d":164233,"h":180388790665,"f":4194337},{"t":164233,"n":"ENOBUFS","d":164233,"h":184683757961,"f":4194337},{"t":164233,"n":"ENODEV","d":164233,"h":188978725257,"f":4194337},{"t":164233,"n":"ENOENT","d":164233,"h":193273692553,"f":4194337},{"t":164233,"n":"ENOEXEC","d":164233,"h":197568659849,"f":4194337},{"t":164233,"n":"ENOLCK","d":164233,"h":201863627145,"f":4194337},{"t":164233,"n":"ENOLINK","d":164233,"h":206158594441,"f":4194337},{"t":164233,"n":"ENOMEM","d":164233,"h":210453561737,"f":4194337},{"t":164233,"n":"ENOMSG","d":164233,"h":214748529033,"f":4194337},{"t":164233,"n":"ENOPROTOOPT","d":164233,"h":219043496329,"f":4194337},{"t":164233,"n":"ENOSPC","d":164233,"h":223338463625,"f":4194337},{"t":164233,"n":"ENOSYS","d":164233,"h":227633430921,"f":4194337},{"t":164233,"n":"ENOTCONN","d":164233,"h":231928398217,"f":4194337},{"t":164233,"n":"ENOTDIR","d":164233,"h":236223365513,"f":4194337},{"t":164233,"n":"ENOTEMPTY","d":164233,"h":240518332809,"f":4194337},{"t":164233,"n":"ENOTRECOVERABLE","d":164233,"h":244813300105,"f":4194337},{"t":164233,"n":"ENOTSOCK","d":164233,"h":249108267401,"f":4194337},{"t":164233,"n":"ENOTSUP","d":164233,"h":253403234697,"f":4194337},{"t":164233,"n":"ENOTTY","d":164233,"h":257698201993,"f":4194337},{"t":164233,"n":"ENXIO","d":164233,"h":261993169289,"f":4194337},{"t":164233,"n":"EOVERFLOW","d":164233,"h":266288136585,"f":4194337},{"t":164233,"n":"EOWNERDEAD","d":164233,"h":270583103881,"f":4194337},{"t":164233,"n":"EPERM","d":164233,"h":274878071177,"f":4194337},{"t":164233,"n":"EPIPE","d":164233,"h":279173038473,"f":4194337},{"t":164233,"n":"EPROTO","d":164233,"h":283468005769,"f":4194337},{"t":164233,"n":"EPROTONOSUPPORT","d":164233,"h":287762973065,"f":4194337},{"t":164233,"n":"EPROTOTYPE","d":164233,"h":292057940361,"f":4194337},{"t":164233,"n":"ERANGE","d":164233,"h":296352907657,"f":4194337},{"t":164233,"n":"EROFS","d":164233,"h":300647874953,"f":4194337},{"t":164233,"n":"ESPIPE","d":164233,"h":304942842249,"f":4194337},{"t":164233,"n":"ESRCH","d":164233,"h":309237809545,"f":4194337},{"t":164233,"n":"ESTALE","d":164233,"h":313532776841,"f":4194337},{"t":164233,"n":"ETIMEDOUT","d":164233,"h":317827744137,"f":4194337},{"t":164233,"n":"ETXTBSY","d":164233,"h":322122711433,"f":4194337},{"t":164233,"n":"EXDEV","d":164233,"h":326417678729,"f":4194337},{"t":164233,"n":"ESOCKTNOSUPPORT","d":164233,"h":330712646025,"f":4194337},{"t":164233,"n":"EPFNOSUPPORT","d":164233,"h":335007613321,"f":4194337},{"t":164233,"n":"ESHUTDOWN","d":164233,"h":339302580617,"f":4194337},{"t":164233,"n":"EHOSTDOWN","d":164233,"h":343597547913,"f":4194337},{"t":164233,"n":"ENODATA","d":164233,"h":347892515209,"f":4194337},{"t":164233,"n":"EHOSTNOTFOUND","d":164233,"h":352187482505,"f":4194337},{"t":164233,"n":"ESOCKETERROR","d":164233,"h":356482449801,"f":4194337},{"t":164233,"n":"EOPNOTSUPP","d":164233,"h":360777417097,"f":4194337},{"t":164233,"n":"EWOULDBLOCK","d":164233,"h":365072384393,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":164233,"h":369367351689,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":98697,"h":164233}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `Interop.Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            static $_ErrorInfo;
            static get ErrorInfo()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_ErrorInfo ??= $asm.$nstr("$sim.Interop.ErrorInfo", ($self) => class ErrorInfo extends $.$$.System.ValueType
                {
                    /*Error*/  get _error() { return this.$getField(0, $.$sim.Interop.Error); }
                    /*Error*/  set _error(value) { this.$setField(0, $.$sim.Interop.Error, value); }
                    /*int*/  get _rawErrno() { return this.$getField(4, $.$$.System.Int32); }
                    /*int*/  set _rawErrno(value) { this.$setField(4, $.$$.System.Int32, value); }
                    $ctor$3(/*int*/ errno)
                    {
                        super.$ctor$1();
                        {
                            this._error = $.$sim.Interop.Sys.ConvertErrorPlatformToPal(errno);
                            this._rawErrno = errno;
                        }
                        return this;
                    }
                    $ctor$4(/*Error*/ error)
                    {
                        super.$ctor$1();
                        {
                            this._error = error;
                            this._rawErrno = -1;
                        }
                        return this;
                    }
                    /*Error */ get Error()
                    {
                        return this._error;
                    }
                    /*int */ get RawErrno()
                    {
                        return this._rawErrno === -1 ? (this._rawErrno = $.$sim.Interop.Sys.ConvertErrorPalToPlatform(this._error)) : this._rawErrno;
                    }
                    /*string */ GetErrorMessage()
                    {
                        return $.$sim.Interop.Sys.StrError(this.RawErrno);
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return `RawErrno: ${this.RawErrno} Error: ${this.Error} GetErrorMessage: ${this.GetErrorMessage()}`;
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$sim.Interop.ErrorInfo.ToString.apply(this, arguments); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._error = this._error;
                        copy._rawErrno = this._rawErrno;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._error = 0;
                        this._rawErrno = 0;
                    }
                    static $h = 229769;
                    static $z = 8;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":164233,"g":{"r":0,"d":0,"h":25770033545,"f":50331656},"n":"Error","d":229769,"h":21475066249,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":34359968137,"f":50331656},"n":"RawErrno","d":229769,"h":30065000841,"f":2097160}],"m":[{"r":1310721,"n":"GetErrorMessage","d":229769,"h":38654935433,"f":16777224},{"r":1310721,"n":"ToString","d":229769,"h":42949902729,"f":16809985}],"l":[{"t":164233,"n":"_error","d":229769,"h":4295197065,"f":4194306},{"t":655361,"n":"_rawErrno","d":229769,"h":8590164361,"f":4194306}],"c":[{"p":[{"n":"errno","p":655361}],"n":".ctor","o":"$ctor$3","d":229769,"h":12885131657,"f":16777224},{"p":[{"n":"error","p":164233}],"n":".ctor","o":"$ctor$4","d":229769,"h":17180098953,"f":16777224},{"n":".ctor","o":"$ctor$2","d":229769,"h":47244870025,"f":16777217}],"d":98697,"h":229769}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Interop.ErrorInfo`; }
                }, $cls, ($v) => $cls.$_ErrorInfo = $v);
            }
            static $h = 98697;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"errorInfo","p":229769},{"n":"path","p":1310721},{"n":"isDirError","p":262145}],"n":"ThrowExceptionForIoErrno","d":98697,"h":12885000585,"f":16777250},{"r":65537,"p":[{"n":"error","p":164233},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"CheckIo","o":"@$3","d":98697,"h":17179967881,"f":16777256},{"r":917505,"p":[{"n":"result","p":917505},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"CheckIo","o":"@$1","d":98697,"h":21474935177,"f":16777256},{"r":65537,"n":"ThrowIOExceptionForLastError","d":98697,"h":25769902473,"f":16777256},{"r":655361,"p":[{"n":"result","p":655361},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"CheckIo","d":98697,"h":30064869769,"f":16777256},{"r":786433,"p":[{"n":"result","p":786433},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"CheckIo","o":"@$2","d":98697,"h":34359837065,"f":16777256},{"r":(TSafeHandle) => TSafeHandle.$h,"p":[{"n":"handle","p":(TSafeHandle) => TSafeHandle.$h},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"g":["TSafeHandle"],"n":"CheckIo","o":"@$4","d":98697,"h":38654804361,"f":16908328},{"r":47251457,"p":[{"n":"errorInfo","p":229769},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"GetExceptionForIoErrno","d":98697,"h":42949771657,"f":16777256},{"r":47251457,"p":[{"n":"errorInfo","p":229769},{"n":"path","p":1310721,"f":65}],"n":"GetIOException","d":98697,"h":47244738953,"f":16777256}],"j":[295305,360841,164233,229769],"h":98697}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        
        $asm.$cls("$sim.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$sim.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.IO.MemoryMappedFiles", $.$sim.System.SR.$type.Assembly);
                    $.$sim.System.SR.s_resourceManager = temp;
                }
                return $.$sim.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sim.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sim.System.SR.resourceCulture = value;
            }
            static /*string */ get IO_FileNotFound()
            {
                return "Unable to find the specified file.";
            }
            static /*string */ get IO_FileNotFound_FileName()
            {
                return "Could not find file '{0}'.";
            }
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Could not find file '{0}'.", arg1);
            }
            static /*string */ get IO_AlreadyExists_Name()
            {
                return "Cannot create '{0}' because a file or directory with the same name already exists.";
            }
            static /*string */ FormatIO_AlreadyExists_Name(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot create '{0}' because a file or directory with the same name already exists.", arg1);
            }
            static /*string */ get IO_FileExists_Name()
            {
                return "The file '{0}' already exists.";
            }
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The file '{0}' already exists.", arg1);
            }
            static /*string */ get IO_SharingViolation_File()
            {
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                return "The process cannot access the file because it is being used by another process.";
            }
            static /*string */ get IO_PathNotFound_Path()
            {
                return "Could not find a part of the path '{0}'.";
            }
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Could not find a part of the path '{0}'.", arg1);
            }
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                return "Could not find a part of the path.";
            }
            static /*string */ get IO_PathTooLong()
            {
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                return "Access to the path '{0}' is denied.";
            }
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Access to the path '{0}' is denied.", arg1);
            }
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                return "Access to the path is denied.";
            }
            static /*string */ get Argument_MapNameEmptyString()
            {
                return "Map name cannot be an empty string.";
            }
            static /*string */ get Argument_EmptyFile()
            {
                return "A positive capacity must be specified for a Memory Mapped File backed by an empty file.";
            }
            static /*string */ get Argument_NewMMFWriteAccessNotAllowed()
            {
                return "MemoryMappedFileAccess.Write is not permitted when creating new memory mapped files. Use MemoryMappedFileAccess.ReadWrite instead.";
            }
            static /*string */ get Argument_ReadAccessWithLargeCapacity()
            {
                return "When specifying MemoryMappedFileAccess.Read access, the capacity must not be larger than the file size.";
            }
            static /*string */ get Argument_NewMMFAppendModeNotAllowed()
            {
                return "FileMode.Append is not permitted when creating new memory mapped files. Instead, use MemoryMappedFileView to ensure write-only access within a specified region.";
            }
            static /*string */ get Argument_NewMMFTruncateModeNotAllowed()
            {
                return "FileMode.Truncate is not permitted when creating new memory mapped files.";
            }
            static /*string */ get ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed()
            {
                return "The capacity cannot be greater than the size of the system's logical address space.";
            }
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                return "Specified file length was too large for the file system.";
            }
            static /*string */ get ArgumentOutOfRange_PositiveOrDefaultCapacityRequired()
            {
                return "The capacity must be greater than or equal to 0. 0 represents the size of the file being mapped.";
            }
            static /*string */ get ArgumentOutOfRange_PositiveOrDefaultSizeRequired()
            {
                return "The size must be greater than or equal to 0. If 0 is specified, the view extends from the specified offset to the end of the file mapping.";
            }
            static /*string */ get ArgumentOutOfRange_CapacityGEFileSizeRequired()
            {
                return "The capacity may not be smaller than the file size.";
            }
            static /*string */ get IO_NotEnoughMemory()
            {
                return "Not enough memory to map view.";
            }
            static /*string */ get InvalidOperation_CantCreateFileMapping()
            {
                return "Cannot create file mapping.";
            }
            static /*string */ get NotSupported_MMViewStreamsFixedLength()
            {
                return "MemoryMappedViewStreams are fixed length.";
            }
            static /*string */ get NotSupported_UnreadableStream()
            {
                return "Stream does not support reading.";
            }
            static /*string */ get NotSupported_UnwritableStream()
            {
                return "Stream does not support writing.";
            }
            static /*string */ get ObjectDisposed_ViewAccessorClosed()
            {
                return "Cannot access a closed accessor.";
            }
            static /*string */ get ObjectDisposed_StreamIsClosed()
            {
                return "Cannot access a closed Stream.";
            }
            static /*string */ get PlatformNotSupported_NamedMaps()
            {
                return "Named maps are not supported.";
            }
            static /*string */ get IO_PathTooLong_Path()
            {
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            static /*string */ get PlatformNotSupported_MemoryMappedFiles()
            {
                return "System.IO.MemoryMappedFiles is not supported on this platform.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sim.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sim.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sim.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sim.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sim.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sim.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1802633;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1802633}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sim.InteropErrorExtensions", ($self) => class InteropErrorExtensions
        {
            static /*Interop.ErrorInfo */ Info(/*this Interop.Error*/ error)
            {
                return new $.$sim.Interop.ErrorInfo().$ctor$4(error);
            }
            static $h = 1081737;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":229769,"p":[{"n":"error","p":164233}],"n":"Info","d":1081737,"h":4296049033,"f":16777249}],"h":1081737}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `InteropErrorExtensions`; }
        });
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedView", ($self) => class MemoryMappedView extends $.$$.System.Object
        {
            /*SafeMemoryMappedViewHandle*/ _viewHandle = null;
            /*long*/ _pointerOffset = 0n;
            /*long*/ _size = 0n;
            /*MemoryMappedFileAccess*/ _access = 0;
            $ctor$1(/*SafeMemoryMappedViewHandle*/ viewHandle, /*long*/ pointerOffset, /*long*/ size, /*MemoryMappedFileAccess*/ access)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(viewHandle !== null, "viewHandle != null");
                    this._viewHandle = viewHandle;
                    this._pointerOffset = pointerOffset;
                    this._size = size;
                    this._access = access;
                }
                return this;
            }
            /*SafeMemoryMappedViewHandle */ get ViewHandle()
            {
                return this._viewHandle;
            }
            /*long */ get PointerOffset()
            {
                return this._pointerOffset;
            }
            /*long */ get Size()
            {
                return this._size;
            }
            /*MemoryMappedFileAccess */ get Access()
            {
                return this._access;
            }
            /*void */ Dispose()
            {
                if (!this._viewHandle.IsClosed)
                {
                    this._viewHandle.Dispose();
                }
                $.$$.System.GC.SuppressFinalize(this);
            }
            /*bool */ get IsClosed()
            {
                return this._viewHandle.IsClosed;
            }
            static /*void */ ValidateSizeAndOffset(/*long*/ size, /*long*/ offset, /*long*/ allocationGranularity, /*out ulong*/ newSize, /*out long*/ extraMemNeeded, /*out long*/ newOffset)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(size >= 0n, "size >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(offset >= 0n, "offset >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(allocationGranularity > 0n, "allocationGranularity > 0");
                extraMemNeeded.$v = offset % allocationGranularity;
                newOffset.$v = offset - extraMemNeeded.$v;
                newSize.$v = (size !== BigInt(0/*MemoryMappedFile.DefaultSize*/)) ? $.$cast(size, $.$$.System.UInt64) + $.$cast(extraMemNeeded.$v, $.$$.System.UInt64) : 0n;
                if ($.$$.System.IntPtr.Size === 4 && newSize.$v > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("size", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
            }
            static /*MemoryMappedView */ CreateView(/*SafeMemoryMappedFileHandle*/ memMappedFileHandle, /*MemoryMappedFileAccess*/ access, /*long*/ requestedOffset, /*long*/ requestedSize)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int64, requestedOffset, memMappedFileHandle._capacity, "offset");
                if (requestedSize > 8192000000000n)
                {
                    throw new $.$$.System.IO.IOException().$ctor$13($.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                if (requestedOffset + requestedSize > memMappedFileHandle._capacity)
                {
                    throw new $.$$.System.UnauthorizedAccessException().$ctor$9();
                }
                $.$$.System.ObjectDisposedException.ThrowIf(memMappedFileHandle.IsClosed, memMappedFileHandle);
                if (requestedSize === BigInt(0/*MemoryMappedFile.DefaultSize*/))
                {
                    requestedSize = memMappedFileHandle._capacity - requestedOffset;
                }
                /*ulong*/ let nativeSize;
                /*long*/ let extraMemNeeded, nativeOffset;
                /*long*/ let pageSize = $.$sim.Interop.Sys.SysConf(2/*Interop.Sys.SysConfName._SC_PAGESIZE*/);
                $.$$.System.Diagnostics.Debug.Assert$2(pageSize > 0n, "pageSize > 0");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.ValidateSizeAndOffset(requestedSize, requestedOffset, pageSize, $.$ref(() => nativeSize, ($v) => nativeSize = $v, $.$$.System.UInt64), $.$ref(() => extraMemNeeded, ($v) => extraMemNeeded = $v, $.$$.System.Int64), $.$ref(() => nativeOffset, ($v) => nativeOffset = $v, $.$$.System.Int64));
                /*Interop.Sys.MemoryMappedFlags*/ let flags = (memMappedFileHandle._access === 3/*MemoryMappedFileAccess.CopyOnWrite*/ || access === 3/*MemoryMappedFileAccess.CopyOnWrite*/) ? 2/*Interop.Sys.MemoryMappedFlags.MAP_PRIVATE*/ : 1/*Interop.Sys.MemoryMappedFlags.MAP_SHARED*/;
                /*SafeFileHandle*/ let fd;
                if (memMappedFileHandle._fileStreamHandle !== null)
                {
                    fd = memMappedFileHandle._fileStreamHandle;
                    $.$$.System.Diagnostics.Debug.Assert$2(!fd.IsInvalid, "!fd.IsInvalid");
                }
                else 
                {
                    fd = new $.$$.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$6(new $.$$.System.IntPtr().$ctor$3(-1), false);
                    flags |= 16/*Interop.Sys.MemoryMappedFlags.MAP_ANONYMOUS*/;
                }
                /*Interop.Sys.MemoryMappedProtections*/ let viewProtForVerification = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(access, true);
                /*Interop.Sys.MemoryMappedProtections*/ let mapProtForVerification = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(memMappedFileHandle._access, true);
                if ((viewProtForVerification & mapProtForVerification) !== viewProtForVerification)
                {
                    throw new $.$$.System.UnauthorizedAccessException().$ctor$9();
                }
                /*Interop.Sys.MemoryMappedProtections*/ let viewProtForCreation = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(access, false);
                /*IntPtr*/ let addr;
                if (nativeSize > 0n)
                {
                    addr = $.$sim.Interop.Sys.MMap($.$$.System.IntPtr.Zero, nativeSize, viewProtForCreation, flags, fd, nativeOffset);
                }
                else 
                {
                    addr = $.$sim.Interop.Sys.MMap($.$$.System.IntPtr.Zero, 1n, viewProtForCreation, flags | 16/*Interop.Sys.MemoryMappedFlags.MAP_ANONYMOUS*/, new $.$$.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$6(new $.$$.System.IntPtr().$ctor$3(-1), false), 0n);
                    requestedSize = 0n;
                    extraMemNeeded = 0n;
                }
                if (addr === $.$$.System.IntPtr.Zero)
                {
                    throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                }
                if (memMappedFileHandle._inheritability === 0/*HandleInheritability.None*/)
                {
                    $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.DisableForkingIfPossible(addr, nativeSize);
                }
                /*var*/ let viewHandle = new $.$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle().$ctor$6(addr, true);
                viewHandle.Initialize$1(nativeSize);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView().$ctor$1(viewHandle, extraMemNeeded, requestedSize, access);
            }
            /*void */ Flush(/*UIntPtr*/ capacity)
            {
                if (capacity === $.$$.System.UIntPtr.Zero)
                {
                    return;
                }
                /*byte**/ let ptr = null;
                try
                {
                    this._viewHandle.AcquirePointer($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typePointer($.$$.System.Byte), () => ptr, ($v) => ptr = $v, null));
                    /*int*/ let result = $.$sim.Interop.Sys.MSync($.$cast(ptr, $.$$.System.IntPtr), $.$cast(capacity, $.$$.System.UInt64), 2/*Interop.Sys.MemoryMappedSyncFlags.MS_SYNC*/ | 16/*Interop.Sys.MemoryMappedSyncFlags.MS_INVALIDATE*/);
                    if (result < 0)
                    {
                        throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                    }
                }
                finally
                {
                    {
                        if (ptr !== null)
                        {
                            this._viewHandle.ReleasePointer();
                        }
                    }
                }
            }
            static /*void */ DisableForkingIfPossible(/*IntPtr*/ addr, /*ulong*/ length)
            {
                if (length > 0n)
                {
                    $.$sim.Interop.Sys.MAdvise(addr, length, 1/*Interop.Sys.MemoryAdvice.MADV_DONTFORK*/);
                }
            }
            /*long*/ static MaxProcessAddressSpace = 8192000000000n;
            static /*Interop.Sys.MemoryMappedProtections */ GetProtections(/*MemoryMappedFileAccess*/ access, /*bool*/ forVerification)
            {
                switch(access)
                {
                    default:
                    case 1/*MemoryMappedFileAccess.Read*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/;
                    case 2/*MemoryMappedFileAccess.Write*/:
                    return 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/;
                    case 0/*MemoryMappedFileAccess.ReadWrite*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/;
                    case 4/*MemoryMappedFileAccess.ReadExecute*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 4/*Interop.Sys.MemoryMappedProtections.PROT_EXEC*/;
                    case 5/*MemoryMappedFileAccess.ReadWriteExecute*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/ | 4/*Interop.Sys.MemoryMappedProtections.PROT_EXEC*/;
                    case 3/*MemoryMappedFileAccess.CopyOnWrite*/:
                    return forVerification ? 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ : 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/;
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1540489;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1212809,"g":{"r":0,"d":0,"h":30066311561,"f":50331649},"n":"ViewHandle","d":1540489,"h":25771344265,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":38656246153,"f":50331649},"n":"PointerOffset","d":1540489,"h":34361278857,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":47246180745,"f":50331649},"n":"Size","d":1540489,"h":42951213449,"f":2097153},{"p":1343881,"g":{"r":0,"d":0,"h":55836115337,"f":50331649},"n":"Access","d":1540489,"h":51541148041,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":68721017225,"f":50331649},"n":"IsClosed","d":1540489,"h":64426049929,"f":2097153}],"m":[{"r":65537,"n":"Dispose","d":1540489,"h":60131082633,"f":16777217},{"r":65537,"p":[{"n":"size","p":917505},{"n":"offset","p":917505},{"n":"allocationGranularity","p":917505},{"n":"newSize","p":983041,"f":2},{"n":"extraMemNeeded","p":917505,"f":2},{"n":"newOffset","p":917505,"f":2}],"n":"ValidateSizeAndOffset","d":1540489,"h":73015984521,"f":16777250},{"r":1540489,"p":[{"n":"memMappedFileHandle","p":1147273},{"n":"access","p":1343881},{"n":"requestedOffset","p":917505},{"n":"requestedSize","p":917505}],"n":"CreateView","d":1540489,"h":77310951817,"f":16777249},{"r":65537,"p":[{"n":"capacity","p":851969}],"n":"Flush","d":1540489,"h":81605919113,"f":16777217},{"r":65537,"p":[{"n":"addr","p":786433},{"n":"length","p":983041}],"n":"DisableForkingIfPossible","d":1540489,"h":85900886409,"f":16777250},{"r":819593,"p":[{"n":"access","p":1343881},{"n":"forVerification","p":262145}],"n":"GetProtections","d":1540489,"h":94490821001,"f":16777256}],"l":[{"t":1212809,"n":"_viewHandle","d":1540489,"h":4296507785,"f":4194306},{"t":917505,"n":"_pointerOffset","d":1540489,"h":8591475081,"f":4194306},{"t":917505,"n":"_size","d":1540489,"h":12886442377,"f":4194306},{"t":1343881,"n":"_access","d":1540489,"h":17181409673,"f":4194306},{"t":917505,"n":"MaxProcessAddressSpace","d":1540489,"h":90195853705,"f":4194338}],"c":[{"p":[{"n":"viewHandle","p":1212809},{"n":"pointerOffset","p":917505},{"n":"size","p":917505},{"n":"access","p":1343881}],"n":".ctor","o":"$ctor$1","d":1540489,"h":21476376969,"f":16777218}],"i":[57540609],"h":1540489}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedView`; }
        });
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedFile", ($self) => class MemoryMappedFile extends $.$$.System.Object
        {
            /*SafeMemoryMappedFileHandle*/ _handle = null;
            /*bool*/ _leaveOpen = false;
            /*SafeFileHandle?*/ _fileHandle = null;
            /*int*/ static DefaultSize = 0;
            $ctor$2(/*SafeMemoryMappedFileHandle*/ handle)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(handle !== null, "handle != null");
                    $.$$.System.Diagnostics.Debug.Assert$2(!handle.IsClosed, "!handle.IsClosed");
                    $.$$.System.Diagnostics.Debug.Assert$2(!handle.IsInvalid, "!handle.IsInvalid");
                    this._handle = handle;
                    this._leaveOpen = true;
                }
                return this;
            }
            $ctor$1(/*SafeMemoryMappedFileHandle*/ handle, /*SafeFileHandle*/ fileHandle, /*bool*/ leaveOpen)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(handle !== null, "handle != null");
                    $.$$.System.Diagnostics.Debug.Assert$2(!handle.IsClosed, "!handle.IsClosed");
                    $.$$.System.Diagnostics.Debug.Assert$2(!handle.IsInvalid, "!handle.IsInvalid");
                    $.$$.System.Diagnostics.Debug.Assert$2(fileHandle !== null, "fileHandle != null");
                    this._handle = handle;
                    this._fileHandle = fileHandle;
                    this._leaveOpen = leaveOpen;
                }
                return this;
            }
            static /*MemoryMappedFile */ OpenExisting$2(/*string*/ mapName)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenExisting(mapName, 6/*MemoryMappedFileRights.ReadWrite*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ OpenExisting$1(/*string*/ mapName, /*MemoryMappedFileRights*/ desiredAccessRights)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenExisting(mapName, desiredAccessRights, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ OpenExisting(/*string*/ mapName, /*MemoryMappedFileRights*/ desiredAccessRights, /*HandleInheritability*/ inheritability)
            {
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(mapName, "mapName");
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("inheritability");
                }
                if ((desiredAccessRights & ~((983055/*MemoryMappedFileRights.FullControl*/ | 16777216/*MemoryMappedFileRights.AccessSystemSecurity*/))) !== 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("desiredAccessRights");
                }
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenCore$1(mapName, inheritability, desiredAccessRights, false);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$2(handle);
            }
            static /*MemoryMappedFile */ CreateFromFile$6(/*string*/ path)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$2(path, 3/*FileMode.Open*/, null, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            static /*MemoryMappedFile */ CreateFromFile$5(/*string*/ path, /*FileMode*/ mode)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$2(path, mode, null, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            static /*MemoryMappedFile */ CreateFromFile$4(/*string*/ path, /*FileMode*/ mode, /*string?*/ mapName)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$2(path, mode, mapName, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            static /*MemoryMappedFile */ CreateFromFile$3(/*string*/ path, /*FileMode*/ mode, /*string?*/ mapName, /*long*/ capacity)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$2(path, mode, mapName, capacity, 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            static /*MemoryMappedFile */ CreateFromFile$2(/*string*/ path, /*FileMode*/ mode, /*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(path, "path");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.ValidateCreateFile(mapName, capacity, access);
                if (mode === 6/*FileMode.Append*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFAppendModeNotAllowed, "mode");
                }
                if (mode === 5/*FileMode.Truncate*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFTruncateModeNotAllowed, "mode");
                }
                /*bool*/ let existed = (() =>
                {
                    if (mode === 3/*FileMode.Open*/)
                    {
                        return true;
                    }
                    if (mode === 1/*FileMode.CreateNew*/)
                    {
                        return false;
                    }
                    return $.$$.System.IO.File.Exists(path);
                })();
                /*SafeFileHandle*/ let fileHandle = $.$$.System.IO.File.OpenHandle(path, mode, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GetFileAccess(access), 1/*FileShare.Read*/, 0/*FileOptions.None*/, 0n);
                /*long*/ let fileSize = 0n;
                if (!((mode === 1/*FileMode.CreateNew*/) || (mode === 2/*FileMode.Create*/)))
                {
                    try
                    {
                        fileSize = $.$$.System.IO.RandomAccess.GetLength(fileHandle);
                    }
                    catch($e)
                    {
                        fileHandle.Dispose();
                        throw $e;
                    }
                }
                if (capacity === 0n && fileSize === 0n)
                {
                    $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CleanupFile(fileHandle, existed, path);
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sim.System.SR.Argument_EmptyFile);
                }
                if (capacity === BigInt(0/*DefaultSize*/))
                {
                    capacity = fileSize;
                }
                /*SafeMemoryMappedFileHandle?*/ let handle;
                try
                {
                    handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(fileHandle, mapName, 0/*HandleInheritability.None*/, access, 0/*MemoryMappedFileOptions.None*/, capacity, fileSize);
                }
                catch($e)
                {
                    $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CleanupFile(fileHandle, existed, path);
                    throw $e;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(handle !== null, "handle != null");
                $.$$.System.Diagnostics.Debug.Assert$2(!handle.IsInvalid, "!handle.IsInvalid");
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$1(handle, fileHandle, false);
            }
            static /*MemoryMappedFile */ CreateFromFile(/*SafeFileHandle*/ fileHandle, /*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*HandleInheritability*/ inheritability, /*bool*/ leaveOpen)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(fileHandle, "fileHandle");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.ValidateCreateFile(mapName, capacity, access);
                /*long*/ let fileSize = $.$$.System.IO.RandomAccess.GetLength(fileHandle);
                if (capacity === 0n && fileSize === 0n)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sim.System.SR.Argument_EmptyFile);
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("inheritability");
                }
                if (capacity === BigInt(0/*DefaultSize*/))
                {
                    capacity = fileSize;
                }
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(fileHandle, mapName, inheritability, access, 0/*MemoryMappedFileOptions.None*/, capacity, fileSize);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$1(handle, fileHandle, leaveOpen);
            }
            static /*MemoryMappedFile */ CreateFromFile$1(/*FileStream*/ fileStream, /*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*HandleInheritability*/ inheritability, /*bool*/ leaveOpen)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(fileStream, "fileStream");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.ValidateCreateFile(mapName, capacity, access);
                /*long*/ let fileSize = fileStream.Length;
                if (capacity === 0n && fileSize === 0n)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sim.System.SR.Argument_EmptyFile);
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("inheritability");
                }
                fileStream.Flush();
                if (capacity === BigInt(0/*DefaultSize*/))
                {
                    capacity = fileSize;
                }
                /*SafeFileHandle*/ let fileHandle = fileStream.SafeFileHandle;
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(fileHandle, mapName, inheritability, access, 0/*MemoryMappedFileOptions.None*/, capacity, fileSize);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$1(handle, fileHandle, leaveOpen);
            }
            static /*MemoryMappedFile */ CreateNew$2(/*string?*/ mapName, /*long*/ capacity)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNew(mapName, capacity, 0/*MemoryMappedFileAccess.ReadWrite*/, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ CreateNew$1(/*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNew(mapName, capacity, access, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ CreateNew(/*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*HandleInheritability*/ inheritability)
            {
                if ($.$$.System.String.op_Inequality(mapName, null) && mapName.length === 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sim.System.SR.Argument_MapNameEmptyString);
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int64, capacity, "capacity");
                if ($.$$.System.IntPtr.Size === 4 && capacity > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("capacity", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("access");
                }
                if (access === 2/*MemoryMappedFileAccess.Write*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFWriteAccessNotAllowed, "access");
                }
                if ((options & ~((67108864/*MemoryMappedFileOptions.DelayAllocatePages*/))) !== 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("options");
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("inheritability");
                }
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(null, mapName, inheritability, access, options, capacity, BigInt(-1));
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$2(handle);
            }
            static /*MemoryMappedFile */ CreateOrOpen$2(/*string*/ mapName, /*long*/ capacity)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateOrOpen(mapName, capacity, 0/*MemoryMappedFileAccess.ReadWrite*/, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ CreateOrOpen$1(/*string*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateOrOpen(mapName, capacity, access, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ CreateOrOpen(/*string*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*HandleInheritability*/ inheritability)
            {
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(mapName, "mapName");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int64, capacity, "capacity");
                if ($.$$.System.IntPtr.Size === 4 && capacity > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("capacity", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("access");
                }
                if ((options & ~((67108864/*MemoryMappedFileOptions.DelayAllocatePages*/))) !== 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("options");
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("inheritability");
                }
                /*SafeMemoryMappedFileHandle*/ let handle;
                if (access === 2/*MemoryMappedFileAccess.Write*/)
                {
                    handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenCore(mapName, inheritability, access, true);
                }
                else 
                {
                    handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateOrOpenCore(mapName, inheritability, access, options, capacity);
                }
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$2(handle);
            }
            /*MemoryMappedViewStream */ CreateViewStream()
            {
                return this.CreateViewStream$1(0n, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            /*MemoryMappedViewStream */ CreateViewStream$2(/*long*/ offset, /*long*/ size)
            {
                return this.CreateViewStream$1(offset, size, 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            /*MemoryMappedViewStream */ CreateViewStream$1(/*long*/ offset, /*long*/ size, /*MemoryMappedFileAccess*/ access)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, offset, "offset");
                if (size < 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("size", $.$sim.System.SR.ArgumentOutOfRange_PositiveOrDefaultSizeRequired);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("access");
                }
                if ($.$$.System.IntPtr.Size === 4 && size > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("size", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                /*MemoryMappedView*/ let view = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.CreateView(this._handle, access, offset, size);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedViewStream().$ctor$8(view);
            }
            /*MemoryMappedViewAccessor */ CreateViewAccessor()
            {
                return this.CreateViewAccessor$1(0n, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            /*MemoryMappedViewAccessor */ CreateViewAccessor$2(/*long*/ offset, /*long*/ size)
            {
                return this.CreateViewAccessor$1(offset, size, 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            /*MemoryMappedViewAccessor */ CreateViewAccessor$1(/*long*/ offset, /*long*/ size, /*MemoryMappedFileAccess*/ access)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, offset, "offset");
                if (size < 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("size", $.$sim.System.SR.ArgumentOutOfRange_PositiveOrDefaultSizeRequired);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("access");
                }
                if ($.$$.System.IntPtr.Size === 4 && size > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("size", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                /*MemoryMappedView*/ let view = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.CreateView(this._handle, access, offset, size);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedViewAccessor().$ctor$4(view);
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    if (!this._handle.IsClosed)
                    {
                        this._handle.Dispose();
                    }
                }
                finally
                {
                    {
                        if (!this._leaveOpen)
                        {
                            this._fileHandle?.Dispose();
                        }
                    }
                }
            }
            /*SafeMemoryMappedFileHandle */ get SafeMemoryMappedFileHandle()
            {
                return this._handle;
            }
            static /*FileAccess */ GetFileAccess(/*MemoryMappedFileAccess*/ access)
            {
                switch(access)
                {
                    case 1/*MemoryMappedFileAccess.Read*/:
                    case 4/*MemoryMappedFileAccess.ReadExecute*/:
                    return 1/*FileAccess.Read*/;
                    case 0/*MemoryMappedFileAccess.ReadWrite*/:
                    case 3/*MemoryMappedFileAccess.CopyOnWrite*/:
                    case 5/*MemoryMappedFileAccess.ReadWriteExecute*/:
                    return 3/*FileAccess.ReadWrite*/;
                    default:
                    $.$$.System.Diagnostics.Debug.Assert$2(access === 2/*MemoryMappedFileAccess.Write*/, "access == MemoryMappedFileAccess.Write");
                    return 2/*FileAccess.Write*/;
                }
            }
            static /*void */ CleanupFile(/*SafeFileHandle*/ fileHandle, /*bool*/ existed, /*string*/ path)
            {
                fileHandle.Dispose();
                if (!existed)
                {
                    $.$$.System.IO.File.Delete(path);
                }
            }
            static /*void */ ValidateCreateFile(/*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                if ($.$$.System.String.op_Inequality(mapName, null) && mapName.length === 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sim.System.SR.Argument_MapNameEmptyString);
                }
                if (capacity < 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("capacity", $.$sim.System.SR.ArgumentOutOfRange_PositiveOrDefaultCapacityRequired);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("access");
                }
                if (access === 2/*MemoryMappedFileAccess.Write*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFWriteAccessNotAllowed, "access");
                }
            }
            static /*void */ VerifyMemoryMappedFileAccess(/*MemoryMappedFileAccess*/ access, /*long*/ capacity, /*SafeFileHandle?*/ fileHandle, /*long*/ fileSize, /*out bool*/ isRegularFile)
            {
                isRegularFile.$v = !(fileHandle === null) && (fileSize > 0n || IsRegularFile(fileHandle));
                if (isRegularFile.$v)
                {
                    if (access === 1/*MemoryMappedFileAccess.Read*/ && capacity > fileSize)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$sim.System.SR.Argument_ReadAccessWithLargeCapacity);
                    }
                    if (fileSize > capacity)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("capacity", $.$sim.System.SR.ArgumentOutOfRange_CapacityGEFileSizeRequired);
                    }
                    if (access === 2/*MemoryMappedFileAccess.Write*/)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFWriteAccessNotAllowed, "access");
                    }
                }
                /*static bool*/  function IsRegularFile(/*SafeFileHandle*/ fileHandle)
                {
                    /*Interop.Sys.FileStatus*/ let status;
                    $.$sim.Interop.CheckIo($.$sim.Interop.Sys.FStat(fileHandle, $.$ref(() => status, ($v) => status = $v, $.$sim.Interop.Sys.FileStatus)), null, false);
                    return (status.Mode & 32768/*Interop.Sys.FileTypes.S_IFREG*/) !== 0;
                }
            }
            static /*SafeMemoryMappedFileHandle */ CreateCore(/*SafeFileHandle?*/ fileHandle, /*string?*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*long*/ capacity, /*long*/ fileSize)
            {
                /*bool*/ let isRegularFile;
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.VerifyMemoryMappedFileAccess(access, capacity, fileHandle, fileSize, $.$ref(() => isRegularFile, ($v) => isRegularFile = $v, $.$$.System.Boolean));
                if ($.$$.System.String.op_Inequality(mapName, null))
                {
                    throw $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNamedMapsNotSupportedException();
                }
                /*bool*/ let ownsFileStream = false;
                if (fileHandle !== null)
                {
                    if (isRegularFile && fileSize >= 0n && capacity > fileSize)
                    {
                        try
                        {
                            $.$sim.Interop.CheckIo($.$sim.Interop.Sys.FTruncate(fileHandle, capacity), null, false);
                        }
                        catch(exc)
                        {
                            throw new $.$$.System.IO.IOException().$ctor$11(exc.Message, exc);
                        }
                    }
                }
                else 
                {
                    /*Interop.Sys.MemoryMappedProtections*/ let protections = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(access, false);
                    if ((protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) !== 0 && capacity > 0n)
                    {
                        ownsFileStream = true;
                        fileHandle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObject(protections, capacity, inheritability);
                    }
                }
                return new $.$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedFileHandle().$ctor$5(fileHandle, ownsFileStream, inheritability, access, options, capacity);
            }
            static /*SafeMemoryMappedFileHandle */ CreateOrOpenCore(/*string*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*long*/ capacity)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(null, mapName, inheritability, access, options, capacity, BigInt(-1));
            }
            static /*SafeMemoryMappedFileHandle */ OpenCore(/*string*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*bool*/ createOrOpen)
            {
                throw $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNamedMapsNotSupportedException();
            }
            static /*SafeMemoryMappedFileHandle */ OpenCore$1(/*string*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileRights*/ rights, /*bool*/ createOrOpen)
            {
                throw $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNamedMapsNotSupportedException();
            }
            static /*PlatformNotSupportedException */ CreateNamedMapsNotSupportedException()
            {
                return new $.$$.System.PlatformNotSupportedException().$ctor$16($.$sim.System.SR.PlatformNotSupported_NamedMaps);
            }
            static /*FileAccess */ TranslateProtectionsToFileAccess(/*Interop.Sys.MemoryMappedProtections*/ protections)
            {
                return (protections & (1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/)) !== 0 ? 3/*FileAccess.ReadWrite*/ : (protections & (2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/)) !== 0 ? 2/*FileAccess.Write*/ : 1/*FileAccess.Read*/;
            }
            static /*SafeFileHandle */ CreateSharedBackingObject(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                return $.$sim.Interop.Sys.IsMemfdSupported ? $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObjectUsingMemoryMemfdCreate(protections, capacity, inheritability) : $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObjectUsingMemoryShmOpen(protections, capacity, inheritability) ?? $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObjectUsingFile(protections, capacity, inheritability);
            }
            static /*SafeFileHandle? */ CreateSharedBackingObjectUsingMemoryShmOpen(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                /*Interop.Sys.OpenFlags*/ let flags = (protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) !== 0 ? 2/*Interop.Sys.OpenFlags.O_RDWR*/ : 0/*Interop.Sys.OpenFlags.O_RDONLY*/;
                flags |= 32/*Interop.Sys.OpenFlags.O_CREAT*/ | 64/*Interop.Sys.OpenFlags.O_EXCL*/;
                /*var*/ let perms = 0/*UnixFileMode.None*/;
                if ((protections & 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/) !== 0)
                {
                    perms |= 256/*UnixFileMode.UserRead*/;
                }
                if ((protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) !== 0)
                {
                    perms |= 128/*UnixFileMode.UserWrite*/;
                }
                if ((protections & 4/*Interop.Sys.MemoryMappedProtections.PROT_EXEC*/) !== 0)
                {
                    perms |= 64/*UnixFileMode.UserExecute*/;
                }
                /*string*/ let mapName;
                /*SafeFileHandle*/ let fd;
                do
                {
                    mapName = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GenerateMapName();
                    fd = $.$sim.Interop.Sys.ShmOpen(mapName, flags, perms);
                    if (fd.IsInvalid)
                    {
                        /*Interop.ErrorInfo*/ let errorInfo = $.$sim.Interop.Sys.GetLastErrorInfo();
                        fd.Dispose();
                        if (errorInfo.Error === 65597/*Interop.Error.ENOTSUP*/)
                        {
                            return null;
                        }
                        else if (errorInfo.Error === 65573/*Interop.Error.ENAMETOOLONG*/)
                        {
                            $.$$.System.Diagnostics.Debug.Fail$1(`shm_open failed with ENAMETOOLONG for ${$.$$.System.Text.Encoding.UTF8.GetByteCount$6(mapName)} byte long name.`);
                            return null;
                        }
                        else if (errorInfo.Error !== 65556/*Interop.Error.EEXIST*/)
                        {
                            throw $.$sim.Interop.GetExceptionForIoErrno(errorInfo.Clone(), null, false);
                        }
                    }
                }
                while(fd.IsInvalid);
                try
                {
                    $.$sim.Interop.CheckIo($.$sim.Interop.Sys.ShmUnlink(mapName), null, false);
                    $.$sim.Interop.CheckIo($.$sim.Interop.Sys.FTruncate(fd, capacity), null, false);
                    if (inheritability === 1/*HandleInheritability.Inheritable*/ && $.$sim.Interop.Sys.Fcntl.SetFD(fd, 0) === -1)
                    {
                        throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                    }
                    return fd;
                }
                catch($e)
                {
                    fd.Dispose();
                    throw $e;
                }
            }
            static /*string */ GenerateMapName()
            {
                /*int*/ let MaxNameLength = 30;
                /*string*/ let NamePrefix = "/dotnet_";
                return $.$$.System.String.Create$10($.$$.System.Int32, MaxNameLength, 0, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.Int32))().$ctor(this,  (/*span*/ span, /*state*/ state) =>
                {
                    /*Span<char>*/ let guid = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 32, null);
                    /*int*/ let charsWritten;
                    $.$$.System.Guid.NewGuid().TryFormat$1(guid, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), $.$$.System.String.op_Implicit("N"));
                    $.$$.System.Diagnostics.Debug.Assert$2(charsWritten === 32, "charsWritten == 32");
                    $.$$.System.String.CopyTo$1.call(NamePrefix, span);
                    guid.Slice(0, ((MaxNameLength - NamePrefix.length) | 0)).CopyTo(span.Slice$1(NamePrefix.length));
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Text.Encoding.UTF8.GetByteCount$4($.$$.System.Span$$($.$$.System.Char).op_Implicit(span)) <= MaxNameLength, "Encoding.UTF8.GetByteCount(span) <= MaxNameLength");
                }, {"r":65537,"p":[{"n":"span","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"state","p":655361}],"n":"","d":1278345,"h":0,"f":17825794}));
            }
            static /*SafeFileHandle */ CreateSharedBackingObjectUsingMemoryMemfdCreate(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                /*int*/ let isReadonly = ((protections & 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/) !== 0 && (protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) === 0) ? 1 : 0;
                /*SafeFileHandle*/ let fd = $.$sim.Interop.Sys.MemfdCreate($.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GenerateMapName(), isReadonly);
                if (fd.IsInvalid)
                {
                    /*Interop.ErrorInfo*/ let errorInfo = $.$sim.Interop.Sys.GetLastErrorInfo();
                    fd.Dispose();
                    throw $.$sim.Interop.GetExceptionForIoErrno(errorInfo.Clone(), null, false);
                }
                try
                {
                    $.$sim.Interop.CheckIo($.$sim.Interop.Sys.FTruncate(fd, capacity), null, false);
                    if (inheritability === 1/*HandleInheritability.Inheritable*/ && $.$sim.Interop.Sys.Fcntl.SetFD(fd, 0) === -1)
                    {
                        throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                    }
                    return fd;
                }
                catch($e)
                {
                    fd.Dispose();
                    throw $e;
                }
            }
            static /*SafeFileHandle */ CreateSharedBackingObjectUsingFile(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                /*string*/ let path = $.$$.System.IO.Path.Combine$3($.$$.System.IO.Path.GetTempPath(), $.$$.System.Guid.NewGuid().ToString$2("N"));
                /*FileShare*/ let share = inheritability === 0/*HandleInheritability.None*/ ? 3/*FileShare.ReadWrite*/ : 3/*FileShare.ReadWrite*/ | 16/*FileShare.Inheritable*/;
                /*SafeFileHandle*/ let fileHandle = $.$$.System.IO.File.OpenHandle(path, 1/*FileMode.CreateNew*/, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.TranslateProtectionsToFileAccess(protections), share, 0, 0n);
                try
                {
                    $.$sim.Interop.CheckIo($.$sim.Interop.Sys.Unlink(path), null, false);
                    $.$sim.Interop.CheckIo($.$sim.Interop.Sys.FTruncate(fileHandle, capacity), path, false);
                }
                catch($e)
                {
                    fileHandle.Dispose();
                    throw $e;
                }
                return fileHandle;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1278345;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1147273,"g":{"r":0,"d":0,"h":137440231817,"f":50331649},"n":"SafeMemoryMappedFileHandle","d":1278345,"h":133145264521,"f":2097153}],"m":[{"r":1278345,"p":[{"n":"mapName","p":1310721}],"n":"OpenExisting","o":"@$2","d":1278345,"h":30066049417,"f":16777249,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":1278345,"p":[{"n":"mapName","p":1310721},{"n":"desiredAccessRights","p":1474953}],"n":"OpenExisting","o":"@$1","d":1278345,"h":34361016713,"f":16777249,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":1278345,"p":[{"n":"mapName","p":1310721},{"n":"desiredAccessRights","p":1474953},{"n":"inheritability","p":60620801}],"n":"OpenExisting","d":1278345,"h":38655984009,"f":16777249,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":1278345,"p":[{"n":"path","p":1310721}],"n":"CreateFromFile","o":"@$6","d":1278345,"h":42950951305,"f":16777249},{"r":1278345,"p":[{"n":"path","p":1310721},{"n":"mode","p":60030977}],"n":"CreateFromFile","o":"@$5","d":1278345,"h":47245918601,"f":16777249},{"r":1278345,"p":[{"n":"path","p":1310721},{"n":"mode","p":60030977},{"n":"mapName","p":1310721}],"n":"CreateFromFile","o":"@$4","d":1278345,"h":51540885897,"f":16777249},{"r":1278345,"p":[{"n":"path","p":1310721},{"n":"mode","p":60030977},{"n":"mapName","p":1310721},{"n":"capacity","p":917505}],"n":"CreateFromFile","o":"@$3","d":1278345,"h":55835853193,"f":16777249},{"r":1278345,"p":[{"n":"path","p":1310721},{"n":"mode","p":60030977},{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1343881}],"n":"CreateFromFile","o":"@$2","d":1278345,"h":60130820489,"f":16777249},{"r":1278345,"p":[{"n":"fileHandle","p":7143425},{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1343881},{"n":"inheritability","p":60620801},{"n":"leaveOpen","p":262145}],"n":"CreateFromFile","d":1278345,"h":64425787785,"f":16777249},{"r":1278345,"p":[{"n":"fileStream","p":60358657},{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1343881},{"n":"inheritability","p":60620801},{"n":"leaveOpen","p":262145}],"n":"CreateFromFile","o":"@$1","d":1278345,"h":68720755081,"f":16777249},{"r":1278345,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505}],"n":"CreateNew","o":"@$2","d":1278345,"h":73015722377,"f":16777249},{"r":1278345,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1343881}],"n":"CreateNew","o":"@$1","d":1278345,"h":77310689673,"f":16777249},{"r":1278345,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1343881},{"n":"options","p":1409417},{"n":"inheritability","p":60620801}],"n":"CreateNew","d":1278345,"h":81605656969,"f":16777249},{"r":1278345,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505}],"n":"CreateOrOpen","o":"@$2","d":1278345,"h":85900624265,"f":16777249,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":1278345,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1343881}],"n":"CreateOrOpen","o":"@$1","d":1278345,"h":90195591561,"f":16777249,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":1278345,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1343881},{"n":"options","p":1409417},{"n":"inheritability","p":60620801}],"n":"CreateOrOpen","d":1278345,"h":94490558857,"f":16777249,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":1671561,"n":"CreateViewStream","d":1278345,"h":98785526153,"f":16777217},{"r":1671561,"p":[{"n":"offset","p":917505},{"n":"size","p":917505}],"n":"CreateViewStream","o":"@$2","d":1278345,"h":103080493449,"f":16777217},{"r":1671561,"p":[{"n":"offset","p":917505},{"n":"size","p":917505},{"n":"access","p":1343881}],"n":"CreateViewStream","o":"@$1","d":1278345,"h":107375460745,"f":16777217},{"r":1606025,"n":"CreateViewAccessor","d":1278345,"h":111670428041,"f":16777217},{"r":1606025,"p":[{"n":"offset","p":917505},{"n":"size","p":917505}],"n":"CreateViewAccessor","o":"@$2","d":1278345,"h":115965395337,"f":16777217},{"r":1606025,"p":[{"n":"offset","p":917505},{"n":"size","p":917505},{"n":"access","p":1343881}],"n":"CreateViewAccessor","o":"@$1","d":1278345,"h":120260362633,"f":16777217},{"r":65537,"n":"Dispose","d":1278345,"h":124555329929,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1278345,"h":128850297225,"f":16777348},{"r":59768833,"p":[{"n":"access","p":1343881}],"n":"GetFileAccess","d":1278345,"h":141735199113,"f":16777256},{"r":65537,"p":[{"n":"fileHandle","p":7143425},{"n":"existed","p":262145},{"n":"path","p":1310721}],"n":"CleanupFile","d":1278345,"h":146030166409,"f":16777250},{"r":65537,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1343881}],"n":"ValidateCreateFile","d":1278345,"h":150325133705,"f":16777250},{"r":65537,"p":[{"n":"access","p":1343881},{"n":"capacity","p":917505},{"n":"fileHandle","p":7143425},{"n":"fileSize","p":917505},{"n":"isRegularFile","p":262145,"f":2}],"n":"VerifyMemoryMappedFileAccess","d":1278345,"h":154620101001,"f":16777250},{"r":1147273,"p":[{"n":"fileHandle","p":7143425},{"n":"mapName","p":1310721},{"n":"inheritability","p":60620801},{"n":"access","p":1343881},{"n":"options","p":1409417},{"n":"capacity","p":917505},{"n":"fileSize","p":917505}],"n":"CreateCore","d":1278345,"h":158915068297,"f":16777250},{"r":1147273,"p":[{"n":"mapName","p":1310721},{"n":"inheritability","p":60620801},{"n":"access","p":1343881},{"n":"options","p":1409417},{"n":"capacity","p":917505}],"n":"CreateOrOpenCore","d":1278345,"h":163210035593,"f":16777250},{"r":1147273,"p":[{"n":"mapName","p":1310721},{"n":"inheritability","p":60620801},{"n":"access","p":1343881},{"n":"createOrOpen","p":262145}],"n":"OpenCore","d":1278345,"h":167505002889,"f":16777250},{"r":1147273,"p":[{"n":"mapName","p":1310721},{"n":"inheritability","p":60620801},{"n":"rights","p":1474953},{"n":"createOrOpen","p":262145}],"n":"OpenCore","o":"@$1","d":1278345,"h":171799970185,"f":16777250},{"r":72220673,"n":"CreateNamedMapsNotSupportedException","d":1278345,"h":176094937481,"f":16777250},{"r":59768833,"p":[{"n":"protections","p":819593}],"n":"TranslateProtectionsToFileAccess","d":1278345,"h":180389904777,"f":16777250},{"r":7143425,"p":[{"n":"protections","p":819593},{"n":"capacity","p":917505},{"n":"inheritability","p":60620801}],"n":"CreateSharedBackingObject","d":1278345,"h":184684872073,"f":16777250},{"r":7143425,"p":[{"n":"protections","p":819593},{"n":"capacity","p":917505},{"n":"inheritability","p":60620801}],"n":"CreateSharedBackingObjectUsingMemoryShmOpen","d":1278345,"h":188979839369,"f":16777250},{"r":1310721,"n":"GenerateMapName","d":1278345,"h":193274806665,"f":16777250},{"r":7143425,"p":[{"n":"protections","p":819593},{"n":"capacity","p":917505},{"n":"inheritability","p":60620801}],"n":"CreateSharedBackingObjectUsingMemoryMemfdCreate","d":1278345,"h":197569773961,"f":16777250},{"r":7143425,"p":[{"n":"protections","p":819593},{"n":"capacity","p":917505},{"n":"inheritability","p":60620801}],"n":"CreateSharedBackingObjectUsingFile","d":1278345,"h":201864741257,"f":16777250}],"l":[{"t":1147273,"n":"_handle","d":1278345,"h":4296245641,"f":4194306},{"t":262145,"n":"_leaveOpen","d":1278345,"h":8591212937,"f":4194306},{"t":7143425,"n":"_fileHandle","d":1278345,"h":12886180233,"f":4194306},{"t":655361,"n":"DefaultSize","d":1278345,"h":17181147529,"f":4194344}],"c":[{"p":[{"n":"handle","p":1147273}],"n":".ctor","o":"$ctor$2","d":1278345,"h":21476114825,"f":16777218},{"p":[{"n":"handle","p":1147273},{"n":"fileHandle","p":7143425},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$1","d":1278345,"h":25771082121,"f":16777218}],"i":[57540609],"h":1278345}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFile`; }
        });
        
        $asm.$str("$sim.System.IO.MemoryMappedFiles.MemoryMappedFileOptions", ($self) => class MemoryMappedFileOptions extends $.$$.System.Enum
        {
            static None = 0;
            static DelayAllocatePages = 67108864;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "DelayAllocatePages": 67108864n
                };
            }
            static $h = 1409417;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1409417,"n":"None","d":1409417,"h":4296376713,"f":4194337},{"t":1409417,"n":"DelayAllocatePages","d":1409417,"h":8591344009,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1409417,"h":12886311305,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1409417,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFileOptions`; }
        });
        
        $asm.$str("$sim.System.IO.MemoryMappedFiles.MemoryMappedFileAccess", ($self) => class MemoryMappedFileAccess extends $.$$.System.Enum
        {
            static ReadWrite = 0;
            static Read = 1;
            static Write = 2;
            static CopyOnWrite = 3;
            static ReadExecute = 4;
            static ReadWriteExecute = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ReadWrite": 0n,
                    "Read": 1n,
                    "Write": 2n,
                    "CopyOnWrite": 3n,
                    "ReadExecute": 4n,
                    "ReadWriteExecute": 5n
                };
            }
            static $h = 1343881;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1343881,"n":"ReadWrite","d":1343881,"h":4296311177,"f":4194337},{"t":1343881,"n":"Read","d":1343881,"h":8591278473,"f":4194337},{"t":1343881,"n":"Write","d":1343881,"h":12886245769,"f":4194337},{"t":1343881,"n":"CopyOnWrite","d":1343881,"h":17181213065,"f":4194337},{"t":1343881,"n":"ReadExecute","d":1343881,"h":21476180361,"f":4194337},{"t":1343881,"n":"ReadWriteExecute","d":1343881,"h":25771147657,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1343881,"h":30066114953,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1343881}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFileAccess`; }
        });
        
        $asm.$str("$sim.System.IO.MemoryMappedFiles.MemoryMappedFileRights", ($self) => class MemoryMappedFileRights extends $.$$.System.Enum
        {
            static CopyOnWrite = 1;
            static Write = 2;
            static Read = 4;
            static Execute = 8;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static ReadWrite = 6;
            static ReadExecute = 12;
            static ReadWriteExecute = 14;
            static FullControl = 983055;
            static AccessSystemSecurity = 16777216;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "CopyOnWrite": 1n,
                    "Write": 2n,
                    "Read": 4n,
                    "Execute": 8n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "ReadWrite": 6n,
                    "ReadExecute": 12n,
                    "ReadWriteExecute": 14n,
                    "FullControl": 983055n,
                    "AccessSystemSecurity": 16777216n
                };
            }
            static $h = 1474953;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1474953,"n":"CopyOnWrite","d":1474953,"h":4296442249,"f":4194337},{"t":1474953,"n":"Write","d":1474953,"h":8591409545,"f":4194337},{"t":1474953,"n":"Read","d":1474953,"h":12886376841,"f":4194337},{"t":1474953,"n":"Execute","d":1474953,"h":17181344137,"f":4194337},{"t":1474953,"n":"Delete","d":1474953,"h":21476311433,"f":4194337},{"t":1474953,"n":"ReadPermissions","d":1474953,"h":25771278729,"f":4194337},{"t":1474953,"n":"ChangePermissions","d":1474953,"h":30066246025,"f":4194337},{"t":1474953,"n":"TakeOwnership","d":1474953,"h":34361213321,"f":4194337},{"t":1474953,"n":"ReadWrite","d":1474953,"h":38656180617,"f":4194337},{"t":1474953,"n":"ReadExecute","d":1474953,"h":42951147913,"f":4194337},{"t":1474953,"n":"ReadWriteExecute","d":1474953,"h":47246115209,"f":4194337},{"t":1474953,"n":"FullControl","d":1474953,"h":51541082505,"f":4194337},{"t":1474953,"n":"AccessSystemSecurity","d":1474953,"h":55836049801,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1474953,"h":60131017097,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1474953,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFileRights`; }
        });
        
        $asm.$cls("$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedFileHandle", ($self) => class SafeMemoryMappedFileHandle extends $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(true);
                {
                }
                return this;
            }
            /*SafeFileHandle?*/ _fileStreamHandle = null;
            /*bool*/ _ownsFileHandle = false;
            /*HandleInheritability*/ _inheritability = 0;
            /*MemoryMappedFileAccess*/ _access = 0;
            /*MemoryMappedFileOptions*/ _options = 0;
            /*long*/ _capacity = 0n;
            $ctor$5(/*SafeFileHandle?*/ fileHandle, /*bool*/ ownsFileHandle, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*long*/ capacity)
            {
                super.$ctor$3(true);
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!ownsFileHandle || fileHandle !== null, "We can only own a FileStream we're actually given.");
                    this._ownsFileHandle = ownsFileHandle;
                    this._inheritability = inheritability;
                    this._access = access;
                    this._options = options;
                    this._capacity = capacity;
                    /*IntPtr*/ let handlePtr;
                    if (fileHandle !== null)
                    {
                        /*bool*/ let ignored = false;
                        fileHandle.DangerousAddRef$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => ignored, ($v) => ignored = $v, null));
                        this._fileStreamHandle = fileHandle;
                        handlePtr = fileHandle.DangerousGetHandle();
                    }
                    else 
                    {
                        handlePtr = $.$$.System.IntPtr.MaxValue;
                    }
                    this.SetHandle(handlePtr);
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                if (this._fileStreamHandle !== null)
                {
                    this.SetHandle((-1));
                    if (this._ownsFileHandle)
                    {
                        this._fileStreamHandle.Dispose();
                    }
                    this._fileStreamHandle.DangerousRelease();
                    this._fileStreamHandle = null;
                }
                return true;
            }
            /*bool */ get IsInvalid()
            {
                return $.$cast(this.handle, $.$$.System.Int64) <= 0n;
            }
            static $h = 1147273;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"p":[{"p":262145,"g":{"r":0,"d":0,"h":47245787529,"f":50364417},"n":"IsInvalid","d":1147273,"h":42950820233,"f":2129921}],"m":[{"r":262145,"n":"ReleaseHandle","d":1147273,"h":38655852937,"f":16809988}],"l":[{"t":7143425,"n":"_fileStreamHandle","d":1147273,"h":8591081865,"f":4194312},{"t":262145,"n":"_ownsFileHandle","d":1147273,"h":12886049161,"f":4194312},{"t":60620801,"n":"_inheritability","d":1147273,"h":17181016457,"f":4194312},{"t":1343881,"n":"_access","d":1147273,"h":21475983753,"f":4194312},{"t":1409417,"n":"_options","d":1147273,"h":25770951049,"f":4194312},{"t":917505,"n":"_capacity","d":1147273,"h":30065918345,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$4","d":1147273,"h":4296114569,"f":16777217},{"p":[{"n":"fileHandle","p":7143425},{"n":"ownsFileHandle","p":262145},{"n":"inheritability","p":60620801},{"n":"access","p":1343881},{"n":"options","p":1409417},{"n":"capacity","p":917505}],"n":".ctor","o":"$ctor$5","d":1147273,"h":34360885641,"f":16777224}],"i":[57540609],"h":1147273}; }
            static get $b() { return $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeMemoryMappedFileHandle`; }
        });
        
        $asm.$cls("$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle", ($self) => class SafeMemoryMappedViewHandle extends $.$$.System.Runtime.InteropServices.SafeBuffer
        {
            $ctor$5()
            {
                super.$ctor$4(true);
                {
                }
                return this;
            }
            $ctor$6(/*IntPtr*/ handle, /*bool*/ ownsHandle)
            {
                super.$ctor$4(ownsHandle);
                {
                    super.SetHandle(handle);
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                /*IntPtr*/ let addr = this.handle;
                this.handle = new $.$$.System.IntPtr().$ctor$3(-1);
                return $.$sim.Interop.Sys.MUnmap(addr, super.ByteLength) === 0;
            }
            static $h = 1212809;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":109379585,"m":[{"r":262145,"n":"ReleaseHandle","d":1212809,"h":12886114697,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$5","d":1212809,"h":4296180105,"f":16777217},{"p":[{"n":"handle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$6","d":1212809,"h":8591147401,"f":16777224}],"i":[57540609],"h":1212809}; }
            static get $b() { return $.$$.System.Runtime.InteropServices.SafeBuffer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle`; }
        });
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedViewAccessor", ($self) => class MemoryMappedViewAccessor extends $.$$.System.IO.UnmanagedMemoryAccessor
        {
            /*MemoryMappedView*/ _view = null;
            $ctor$4(/*MemoryMappedView*/ view)
            {
                super.$ctor$1();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(view !== null, "view is null");
                    this._view = view;
                    this.Initialize(this._view.ViewHandle, this._view.PointerOffset, this._view.Size, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GetFileAccess(this._view.Access));
                }
                return this;
            }
            /*SafeMemoryMappedViewHandle */ get SafeMemoryMappedViewHandle()
            {
                return this._view.ViewHandle;
            }
            /*long */ get PointerOffset()
            {
                return this._view.PointerOffset;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    if (disposing && !this._view.IsClosed && this.CanWrite)
                    {
                        this.Flush();
                    }
                }
                finally
                {
                    {
                        try
                        {
                            this._view.Dispose();
                        }
                        finally
                        {
                            {
                                super.Dispose$1(disposing);
                            }
                        }
                    }
                }
            }
            /*void */ Flush()
            {
                if (!this.IsOpen)
                {
                    throw new $.$$.System.ObjectDisposedException().$ctor$16("MemoryMappedViewAccessor", $.$sim.System.SR.ObjectDisposed_ViewAccessorClosed);
                }
                this._view.Flush($.$cast(this.Capacity, $.$$.System.UIntPtr));
            }
            static $h = 1606025;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":63373313,"p":[{"p":1212809,"g":{"r":0,"d":0,"h":17181475209,"f":50331649},"n":"SafeMemoryMappedViewHandle","d":1606025,"h":12886507913,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":25771409801,"f":50331649},"n":"PointerOffset","d":1606025,"h":21476442505,"f":2097153}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1606025,"h":30066377097,"f":16809988},{"r":65537,"n":"Flush","d":1606025,"h":34361344393,"f":16777217}],"l":[{"t":1540489,"n":"_view","d":1606025,"h":4296573321,"f":4194306}],"c":[{"p":[{"n":"view","p":1540489}],"n":".ctor","o":"$ctor$4","d":1606025,"h":8591540617,"f":16777224}],"i":[57540609],"h":1606025}; }
            static get $b() { return $.$$.System.IO.UnmanagedMemoryAccessor; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedViewAccessor`; }
        });
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedViewStream", ($self) => class MemoryMappedViewStream extends $.$$.System.IO.UnmanagedMemoryStream
        {
            /*MemoryMappedView*/ _view = null;
            $ctor$8(/*MemoryMappedView*/ view)
            {
                super.$ctor$3();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(view !== null, "view is null");
                    this._view = view;
                    this.Initialize$1(this._view.ViewHandle, this._view.PointerOffset, this._view.Size, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GetFileAccess(this._view.Access));
                }
                return this;
            }
            /*SafeMemoryMappedViewHandle */ get SafeMemoryMappedViewHandle()
            {
                return this._view.ViewHandle;
            }
            /*long */ get PointerOffset()
            {
                return this._view.PointerOffset;
            }
            /*void */ SetLength(/*long*/ value)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, value, "value");
                throw new $.$$.System.NotSupportedException().$ctor$12($.$sim.System.SR.NotSupported_MMViewStreamsFixedLength);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    if (disposing && !this._view.IsClosed && this.CanWrite)
                    {
                        this.Flush();
                    }
                }
                finally
                {
                    {
                        try
                        {
                            this._view.Dispose();
                        }
                        finally
                        {
                            {
                                super.Dispose$1(disposing);
                            }
                        }
                    }
                }
            }
            /*void */ Flush()
            {
                if (!this.CanSeek)
                {
                    throw new $.$$.System.ObjectDisposedException().$ctor$16(null, $.$sim.System.SR.ObjectDisposed_StreamIsClosed);
                }
                this._view.Flush($.$cast(this.Capacity, $.$$.System.UIntPtr));
            }
            static $h = 1671561;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":63438849,"p":[{"p":1212809,"g":{"r":0,"d":0,"h":17181540745,"f":50331649},"n":"SafeMemoryMappedViewHandle","d":1671561,"h":12886573449,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":25771475337,"f":50331649},"n":"PointerOffset","d":1671561,"h":21476508041,"f":2097153}],"m":[{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1671561,"h":30066442633,"f":16809985},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1671561,"h":34361409929,"f":16809988},{"r":65537,"n":"Flush","d":1671561,"h":38656377225,"f":16809985}],"l":[{"t":1540489,"n":"_view","d":1671561,"h":4296638857,"f":4194306}],"c":[{"p":[{"n":"view","p":1540489}],"n":".ctor","o":"$ctor$8","d":1671561,"h":8591606153,"f":16777224}],"i":[57540609,56950785],"h":1671561}; }
            static get $b() { return $.$$.System.IO.UnmanagedMemoryStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedViewStream`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread"))