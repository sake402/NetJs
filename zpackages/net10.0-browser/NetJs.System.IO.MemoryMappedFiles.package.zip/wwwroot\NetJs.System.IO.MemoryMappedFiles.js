
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $stt) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.MemoryMappedFiles", 
    {"h":43252,"f":"System.IO.MemoryMappedFiles","v":"1.0.35.0","a":[{"t":90374145,"c":4385341441},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.MemoryMappedFiles","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.MemoryMappedFiles","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.Nop", ($self) => class Nop extends $.$spc.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1747188;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":1747188,"h":4296714484,"f":1}],"h":1747188}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.Nop`; }
        });
        
        $asm.$cls("$sim.Interop", ($self) => class Interop
        {
            static $_Libraries;
            static get Libraries()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_Libraries ??= $asm.$ncls("$sim.Interop.Libraries", ($self) => class Libraries
                {
                    /*string*/ static libc = null;
                    /*string*/ static SystemNative = null;
                    /*string*/ static NetSecurityNative = null;
                    /*string*/ static CryptoNative = null;
                    /*string*/ static CompressionNative = null;
                    /*string*/ static GlobalizationNative = null;
                    /*string*/ static IOPortsNative = null;
                    /*string*/ static HostPolicy = null;
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.libc = "libc";
                        }
                        {
                            this.SystemNative = "libSystem.Native";
                        }
                        {
                            this.NetSecurityNative = "libSystem.Net.Security.Native";
                        }
                        {
                            this.CryptoNative = "libSystem.Security.Cryptography.Native.OpenSsl";
                        }
                        {
                            this.CompressionNative = "libSystem.IO.Compression.Native";
                        }
                        {
                            this.GlobalizationNative = "libSystem.Globalization.Native";
                        }
                        {
                            this.IOPortsNative = "libSystem.IO.Ports.Native";
                        }
                        {
                            this.HostPolicy = "libhostpolicy";
                        }
                    }
                    static $h = 305396;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"libc","d":305396,"h":4295272692,"f":40},{"t":1310721,"n":"SystemNative","d":305396,"h":8590239988,"f":40},{"t":1310721,"n":"NetSecurityNative","d":305396,"h":12885207284,"f":40},{"t":1310721,"n":"CryptoNative","d":305396,"h":17180174580,"f":40},{"t":1310721,"n":"CompressionNative","d":305396,"h":21475141876,"f":40},{"t":1310721,"n":"GlobalizationNative","d":305396,"h":25770109172,"f":40},{"t":1310721,"n":"IOPortsNative","d":305396,"h":30065076468,"f":40},{"t":1310721,"n":"HostPolicy","d":305396,"h":34360043764,"f":40}],"d":108788,"h":305396}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Libraries`; }
                }, $cls, ($v) => $cls.$_Libraries = $v);
            }
            static $_Sys;
            static get Sys()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_Sys ??= $asm.$ncls("$sim.Interop.Sys", ($self) => class Sys
                {
                    static $_Fcntl;
                    static get Fcntl()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_Fcntl ??= $asm.$ncls("$sim.Interop.Sys.Fcntl", ($self) => class Fcntl
                        {
                            static /*int */ DangerousSetIsNonBlocking(/*IntPtr*/ fd, /*int*/ isNonBlocking)
                            {
                                return -1;
                            }
                            static /*int */ SetIsNonBlocking(/*SafeHandle*/ fd, /*int*/ isNonBlocking)
                            {
                                return -1;
                            }
                            static /*int */ GetIsNonBlocking(/*SafeHandle*/ fd, /*out bool*/ isNonBlocking)
                            {
                                isNonBlocking.$v = false;
                                return -1;
                            }
                            static /*int */ SetFD(/*SafeHandle*/ fd, /*int*/ flags)
                            {
                                return -1;
                            }
                            static /*int */ GetFD(/*SafeHandle*/ fd)
                            {
                                return -1;
                            }
                            static /*int */ GetFD$1(/*IntPtr*/ fd)
                            {
                                return -1;
                            }
                            static $h = 436468;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"fd","p":786433},{"n":"isNonBlocking","p":655361}],"n":"DangerousSetIsNonBlocking","d":436468,"h":4295403764,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlSetIsNonBlocking","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109576193},{"n":"isNonBlocking","p":655361}],"n":"SetIsNonBlocking","d":436468,"h":8590371060,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlSetIsNonBlocking","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109576193},{"n":"isNonBlocking","p":262145,"f":2,"a":[{"t":105709569,"c":8695644161,"a":[{"v":2,"t":110886913}]}]}],"n":"GetIsNonBlocking","d":436468,"h":12885338356,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlGetIsNonBlocking","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109576193},{"n":"flags","p":655361}],"n":"SetFD","d":436468,"h":17180305652,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlSetFD","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109576193}],"n":"GetFD","d":436468,"h":21475272948,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlGetFD","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":786433}],"n":"GetFD","o":"@$1","d":436468,"h":25770240244,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlGetFD","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]}],"d":370932,"h":436468}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `Interop.Sys.Fcntl`; }
                        }, $cls, ($v) => $cls.$_Fcntl = $v);
                    }
                    static $_MemoryMappedSyncFlags;
                    static get MemoryMappedSyncFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryMappedSyncFlags ??= $asm.$nstr("$sim.Interop.Sys.MemoryMappedSyncFlags", ($self) => class MemoryMappedSyncFlags extends $.$spc.System.Enum
                        {
                            static MS_ASYNC = 1;
                            static MS_SYNC = 2;
                            static MS_INVALIDATE = 16;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "MS_ASYNC": 1n,
                                    "MS_SYNC": 2n,
                                    "MS_INVALIDATE": 16n
                                };
                            }
                            static $h = 895220;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":895220,"n":"MS_ASYNC","d":895220,"h":4295862516,"f":33},{"t":895220,"n":"MS_SYNC","d":895220,"h":8590829812,"f":33},{"t":895220,"n":"MS_INVALIDATE","d":895220,"h":12885797108,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":895220,"h":17180764404,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":370932,"h":895220,"a":[{"t":47710209,"c":4342677505}]}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryMappedSyncFlags`; }
                        }, $cls, ($v) => $cls.$_MemoryMappedSyncFlags = $v);
                    }
                    static $_OpenFlags;
                    static get OpenFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_OpenFlags ??= $asm.$nstr("$sim.Interop.Sys.OpenFlags", ($self) => class OpenFlags extends $.$spc.System.Enum
                        {
                            static O_RDONLY = 0;
                            static O_WRONLY = 1;
                            static O_RDWR = 2;
                            static O_CLOEXEC = 16;
                            static O_CREAT = 32;
                            static O_EXCL = 64;
                            static O_TRUNC = 128;
                            static O_SYNC = 256;
                            static O_NOFOLLOW = 512;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "O_RDONLY": 0n,
                                    "O_WRONLY": 1n,
                                    "O_RDWR": 2n,
                                    "O_CLOEXEC": 16n,
                                    "O_CREAT": 32n,
                                    "O_EXCL": 64n,
                                    "O_TRUNC": 128n,
                                    "O_SYNC": 256n,
                                    "O_NOFOLLOW": 512n
                                };
                            }
                            static $h = 960756;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":960756,"n":"O_RDONLY","d":960756,"h":4295928052,"f":33},{"t":960756,"n":"O_WRONLY","d":960756,"h":8590895348,"f":33},{"t":960756,"n":"O_RDWR","d":960756,"h":12885862644,"f":33},{"t":960756,"n":"O_CLOEXEC","d":960756,"h":17180829940,"f":33},{"t":960756,"n":"O_CREAT","d":960756,"h":21475797236,"f":33},{"t":960756,"n":"O_EXCL","d":960756,"h":25770764532,"f":33},{"t":960756,"n":"O_TRUNC","d":960756,"h":30065731828,"f":33},{"t":960756,"n":"O_SYNC","d":960756,"h":34360699124,"f":33},{"t":960756,"n":"O_NOFOLLOW","d":960756,"h":38655666420,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":960756,"h":42950633716,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":370932,"h":960756,"a":[{"t":47710209,"c":4342677505}]}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.OpenFlags`; }
                        }, $cls, ($v) => $cls.$_OpenFlags = $v);
                    }
                    static $_FileStatus;
                    static get FileStatus()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_FileStatus ??= $asm.$nstr("$sim.Interop.Sys.FileStatus", ($self) => class FileStatus extends $.$spc.System.ValueType
                        {
                            /*FileStatusFlags*/  get Flags() { return this.$getField(0, $.$sim.Interop.Sys.FileStatusFlags); }
                            /*FileStatusFlags*/  set Flags(value) { this.$setField(0, $.$sim.Interop.Sys.FileStatusFlags, value); }
                            /*int*/  get Mode() { return this.$getField(4, $.$spc.System.Int32); }
                            /*int*/  set Mode(value) { this.$setField(4, $.$spc.System.Int32, value); }
                            /*uint*/  get Uid() { return this.$getField(8, $.$spc.System.UInt32); }
                            /*uint*/  set Uid(value) { this.$setField(8, $.$spc.System.UInt32, value); }
                            /*uint*/  get Gid() { return this.$getField(12, $.$spc.System.UInt32); }
                            /*uint*/  set Gid(value) { this.$setField(12, $.$spc.System.UInt32, value); }
                            /*long*/  get Size() { return this.$getField(16, $.$spc.System.Int64); }
                            /*long*/  set Size(value) { this.$setField(16, $.$spc.System.Int64, value); }
                            /*long*/  get ATime() { return this.$getField(24, $.$spc.System.Int64); }
                            /*long*/  set ATime(value) { this.$setField(24, $.$spc.System.Int64, value); }
                            /*long*/  get ATimeNsec() { return this.$getField(32, $.$spc.System.Int64); }
                            /*long*/  set ATimeNsec(value) { this.$setField(32, $.$spc.System.Int64, value); }
                            /*long*/  get MTime() { return this.$getField(40, $.$spc.System.Int64); }
                            /*long*/  set MTime(value) { this.$setField(40, $.$spc.System.Int64, value); }
                            /*long*/  get MTimeNsec() { return this.$getField(48, $.$spc.System.Int64); }
                            /*long*/  set MTimeNsec(value) { this.$setField(48, $.$spc.System.Int64, value); }
                            /*long*/  get CTime() { return this.$getField(56, $.$spc.System.Int64); }
                            /*long*/  set CTime(value) { this.$setField(56, $.$spc.System.Int64, value); }
                            /*long*/  get CTimeNsec() { return this.$getField(64, $.$spc.System.Int64); }
                            /*long*/  set CTimeNsec(value) { this.$setField(64, $.$spc.System.Int64, value); }
                            /*long*/  get BirthTime() { return this.$getField(72, $.$spc.System.Int64); }
                            /*long*/  set BirthTime(value) { this.$setField(72, $.$spc.System.Int64, value); }
                            /*long*/  get BirthTimeNsec() { return this.$getField(80, $.$spc.System.Int64); }
                            /*long*/  set BirthTimeNsec(value) { this.$setField(80, $.$spc.System.Int64, value); }
                            /*long*/  get Dev() { return this.$getField(88, $.$spc.System.Int64); }
                            /*long*/  set Dev(value) { this.$setField(88, $.$spc.System.Int64, value); }
                            /*long*/  get RDev() { return this.$getField(96, $.$spc.System.Int64); }
                            /*long*/  set RDev(value) { this.$setField(96, $.$spc.System.Int64, value); }
                            /*long*/  get Ino() { return this.$getField(104, $.$spc.System.Int64); }
                            /*long*/  set Ino(value) { this.$setField(104, $.$spc.System.Int64, value); }
                            /*uint*/  get UserFlags() { return this.$getField(112, $.$spc.System.UInt32); }
                            /*uint*/  set UserFlags(value) { this.$setField(112, $.$spc.System.UInt32, value); }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy.Flags = this.Flags;
                                copy.Mode = this.Mode;
                                copy.Uid = this.Uid;
                                copy.Gid = this.Gid;
                                copy.Size = this.Size;
                                copy.ATime = this.ATime;
                                copy.ATimeNsec = this.ATimeNsec;
                                copy.MTime = this.MTime;
                                copy.MTimeNsec = this.MTimeNsec;
                                copy.CTime = this.CTime;
                                copy.CTimeNsec = this.CTimeNsec;
                                copy.BirthTime = this.BirthTime;
                                copy.BirthTimeNsec = this.BirthTimeNsec;
                                copy.Dev = this.Dev;
                                copy.RDev = this.RDev;
                                copy.Ino = this.Ino;
                                copy.UserFlags = this.UserFlags;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this.Flags = 0;
                                this.Mode = 0;
                                this.Uid = 0;
                                this.Gid = 0;
                                this.Size = 0n;
                                this.ATime = 0n;
                                this.ATimeNsec = 0n;
                                this.MTime = 0n;
                                this.MTimeNsec = 0n;
                                this.CTime = 0n;
                                this.CTimeNsec = 0n;
                                this.BirthTime = 0n;
                                this.BirthTimeNsec = 0n;
                                this.Dev = 0n;
                                this.RDev = 0n;
                                this.Ino = 0n;
                                this.UserFlags = 0;
                            }
                            static $h = 502004;
                            static $z = 116;
                            static $f = 0b10100010000001010000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":567540,"n":"Flags","d":502004,"h":4295469300,"f":8},{"t":655361,"n":"Mode","d":502004,"h":8590436596,"f":8},{"t":720897,"n":"Uid","d":502004,"h":12885403892,"f":8},{"t":720897,"n":"Gid","d":502004,"h":17180371188,"f":8},{"t":917505,"n":"Size","d":502004,"h":21475338484,"f":8},{"t":917505,"n":"ATime","d":502004,"h":25770305780,"f":8},{"t":917505,"n":"ATimeNsec","d":502004,"h":30065273076,"f":8},{"t":917505,"n":"MTime","d":502004,"h":34360240372,"f":8},{"t":917505,"n":"MTimeNsec","d":502004,"h":38655207668,"f":8},{"t":917505,"n":"CTime","d":502004,"h":42950174964,"f":8},{"t":917505,"n":"CTimeNsec","d":502004,"h":47245142260,"f":8},{"t":917505,"n":"BirthTime","d":502004,"h":51540109556,"f":8},{"t":917505,"n":"BirthTimeNsec","d":502004,"h":55835076852,"f":8},{"t":917505,"n":"Dev","d":502004,"h":60130044148,"f":8},{"t":917505,"n":"RDev","d":502004,"h":64425011444,"f":8},{"t":917505,"n":"Ino","d":502004,"h":68719978740,"f":8},{"t":720897,"n":"UserFlags","d":502004,"h":73014946036,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":502004,"h":77309913332,"f":1}],"d":370932,"h":502004,"a":[{"t":109903873,"c":4404871169,"a":[{"v":0,"t":105381889}]}]}; }
                            static get $b() { return $.$spc.System.ValueType; }
                            static get $fullName() { return `Interop.Sys.FileStatus`; }
                        }, $cls, ($v) => $cls.$_FileStatus = $v);
                    }
                    static $_FileTypes;
                    static get FileTypes()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_FileTypes ??= $asm.$ncls("$sim.Interop.Sys.FileTypes", ($self) => class FileTypes
                        {
                            /*int*/ static S_IFMT = 61440;
                            /*int*/ static S_IFIFO = 4096;
                            /*int*/ static S_IFCHR = 8192;
                            /*int*/ static S_IFDIR = 16384;
                            /*int*/ static S_IFBLK = 24576;
                            /*int*/ static S_IFREG = 32768;
                            /*int*/ static S_IFLNK = 40960;
                            /*int*/ static S_IFSOCK = 49152;
                            static $h = 633076;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"S_IFMT","d":633076,"h":4295600372,"f":40},{"t":655361,"n":"S_IFIFO","d":633076,"h":8590567668,"f":40},{"t":655361,"n":"S_IFCHR","d":633076,"h":12885534964,"f":40},{"t":655361,"n":"S_IFDIR","d":633076,"h":17180502260,"f":40},{"t":655361,"n":"S_IFBLK","d":633076,"h":21475469556,"f":40},{"t":655361,"n":"S_IFREG","d":633076,"h":25770436852,"f":40},{"t":655361,"n":"S_IFLNK","d":633076,"h":30065404148,"f":40},{"t":655361,"n":"S_IFSOCK","d":633076,"h":34360371444,"f":40}],"d":370932,"h":633076}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `Interop.Sys.FileTypes`; }
                        }, $cls, ($v) => $cls.$_FileTypes = $v);
                    }
                    static $_FileStatusFlags;
                    static get FileStatusFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_FileStatusFlags ??= $asm.$nstr("$sim.Interop.Sys.FileStatusFlags", ($self) => class FileStatusFlags extends $.$spc.System.Enum
                        {
                            static None = 0;
                            static HasBirthTime = 1;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "None": 0n,
                                    "HasBirthTime": 1n
                                };
                            }
                            static $h = 567540;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":567540,"n":"None","d":567540,"h":4295534836,"f":33},{"t":567540,"n":"HasBirthTime","d":567540,"h":8590502132,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":567540,"h":12885469428,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":370932,"h":567540,"a":[{"t":47710209,"c":4342677505}]}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.FileStatusFlags`; }
                        }, $cls, ($v) => $cls.$_FileStatusFlags = $v);
                    }
                    static $_MemoryMappedProtections;
                    static get MemoryMappedProtections()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryMappedProtections ??= $asm.$nstr("$sim.Interop.Sys.MemoryMappedProtections", ($self) => class MemoryMappedProtections extends $.$spc.System.Enum
                        {
                            static PROT_NONE = 0;
                            static PROT_READ = 1;
                            static PROT_WRITE = 2;
                            static PROT_EXEC = 4;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "PROT_NONE": 0n,
                                    "PROT_READ": 1n,
                                    "PROT_WRITE": 2n,
                                    "PROT_EXEC": 4n
                                };
                            }
                            static $h = 829684;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":829684,"n":"PROT_NONE","d":829684,"h":4295796980,"f":33},{"t":829684,"n":"PROT_READ","d":829684,"h":8590764276,"f":33},{"t":829684,"n":"PROT_WRITE","d":829684,"h":12885731572,"f":33},{"t":829684,"n":"PROT_EXEC","d":829684,"h":17180698868,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":829684,"h":21475666164,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":370932,"h":829684,"a":[{"t":47710209,"c":4342677505}]}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryMappedProtections`; }
                        }, $cls, ($v) => $cls.$_MemoryMappedProtections = $v);
                    }
                    static $_MemoryMappedFlags;
                    static get MemoryMappedFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryMappedFlags ??= $asm.$nstr("$sim.Interop.Sys.MemoryMappedFlags", ($self) => class MemoryMappedFlags extends $.$spc.System.Enum
                        {
                            static MAP_SHARED = 1;
                            static MAP_PRIVATE = 2;
                            static MAP_ANONYMOUS = 16;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "MAP_SHARED": 1n,
                                    "MAP_PRIVATE": 2n,
                                    "MAP_ANONYMOUS": 16n
                                };
                            }
                            static $h = 764148;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":764148,"n":"MAP_SHARED","d":764148,"h":4295731444,"f":33},{"t":764148,"n":"MAP_PRIVATE","d":764148,"h":8590698740,"f":33},{"t":764148,"n":"MAP_ANONYMOUS","d":764148,"h":12885666036,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":764148,"h":17180633332,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":370932,"h":764148,"a":[{"t":47710209,"c":4342677505}]}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryMappedFlags`; }
                        }, $cls, ($v) => $cls.$_MemoryMappedFlags = $v);
                    }
                    static $_SysConfName;
                    static get SysConfName()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_SysConfName ??= $asm.$nstr("$sim.Interop.Sys.SysConfName", ($self) => class SysConfName extends $.$spc.System.Enum
                        {
                            static _SC_CLK_TCK = 1;
                            static _SC_PAGESIZE = 2;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "_SC_CLK_TCK": 1n,
                                    "_SC_PAGESIZE": 2n
                                };
                            }
                            static $h = 1026292;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1026292,"n":"_SC_CLK_TCK","d":1026292,"h":4295993588,"f":33},{"t":1026292,"n":"_SC_PAGESIZE","d":1026292,"h":8590960884,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1026292,"h":12885928180,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":370932,"h":1026292}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.SysConfName`; }
                        }, $cls, ($v) => $cls.$_SysConfName = $v);
                    }
                    static $_MemoryAdvice;
                    static get MemoryAdvice()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryAdvice ??= $asm.$nstr("$sim.Interop.Sys.MemoryAdvice", ($self) => class MemoryAdvice extends $.$spc.System.Enum
                        {
                            static MADV_DONTFORK = 1;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "MADV_DONTFORK": 1n
                                };
                            }
                            static $h = 698612;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":698612,"n":"MADV_DONTFORK","d":698612,"h":4295665908,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":698612,"h":8590633204,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":370932,"h":698612}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryAdvice`; }
                        }, $cls, ($v) => $cls.$_MemoryAdvice = $v);
                    }
                    /*sbyte*/ static s_memfdSupported = 0;
                    static /*bool */ get IsMemfdSupported()
                    {
                        /*sbyte*/ let memfdSupported = $.$sim.Interop.Sys.s_memfdSupported;
                        if (memfdSupported === 0)
                        {
                            $.$spc.System.Threading.Interlocked.CompareExchange$4($.$ref(() => $.$sim.Interop.Sys.s_memfdSupported, ($v) => $.$sim.Interop.Sys.s_memfdSupported = $v, $.$spc.System.SByte), $.$cast(($.$sim.Interop.Sys.MemfdSupportedImpl() === 1 ? 1 : -1), $.$spc.System.SByte), 0);
                            memfdSupported = $.$sim.Interop.Sys.s_memfdSupported;
                        }
                        return memfdSupported > 0;
                    }
                    static /*int */ FTruncate(/*SafeFileHandle*/ fd, /*long*/ length)
                    {
                        return 0;
                    }
                    static /*Error */ ConvertErrorPlatformToPal(/*int*/ platformErrno)
                    {
                        return $.$cast(platformErrno, $.$sim.Interop.Error);
                    }
                    static /*int */ ConvertErrorPalToPlatform(/*Error*/ error)
                    {
                        return error;
                    }
                    static /*byte* */ StrErrorR(/*int*/ platformErrno, /*byte**/ buffer, /*int*/ bufferSize)
                    {
                        /*RefOrPointer<byte>*/ let ptr = buffer;
                        $.$spc.System.String.TryCopyTo.call("Error", new ($.$spc.System.Span$$($.$spc.System.Char))().$ctor$4($.$cast(buffer, $.$typePointer($.$spc.System.Void)), bufferSize));
                        return buffer;
                    }
                    static /*IntPtr */ MMap(/*IntPtr*/ addr, /*ulong*/ len, /*MemoryMappedProtections*/ prot, /*MemoryMappedFlags*/ flags, /*SafeFileHandle*/ fd, /*long*/ offset)
                    {
                        return $.$spc.System.IntPtr.Zero;
                    }
                    static /*IntPtr */ MMap$1(/*IntPtr*/ addr, /*ulong*/ len, /*MemoryMappedProtections*/ prot, /*MemoryMappedFlags*/ flags, /*IntPtr*/ fd, /*long*/ offset)
                    {
                        return $.$spc.System.IntPtr.Zero;
                    }
                    static /*int */ MUnmap(/*IntPtr*/ addr, /*ulong*/ len)
                    {
                        return 0;
                    }
                    static /*int */ FStat(/*SafeHandle*/ fd, /*out FileStatus*/ output)
                    {
                        output.$v = $.$default($.$sim.Interop.Sys.FileStatus);
                        return -1;
                    }
                    static /*int */ Stat(/*string*/ path, /*out FileStatus*/ output)
                    {
                        output.$v = $.$default($.$sim.Interop.Sys.FileStatus);
                        return -1;
                    }
                    static /*int */ LStat(/*string*/ path, /*out FileStatus*/ output)
                    {
                        output.$v = $.$default($.$sim.Interop.Sys.FileStatus);
                        return -1;
                    }
                    static /*SafeFileHandle */ Open(/*string*/ filename, /*OpenFlags*/ flags, /*int*/ mode)
                    {
                        return new $.$spc.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$5();
                    }
                    static /*int */ Unlink(/*string*/ pathname)
                    {
                        return -1;
                    }
                    static /*long */ SysConf(/*SysConfName*/ name)
                    {
                        return BigInt(-1);
                    }
                    static /*int */ MSync(/*IntPtr*/ addr, /*ulong*/ len, /*MemoryMappedSyncFlags*/ flags)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*int */ Close(/*IntPtr*/ fd)
                    {
                        return 0;
                    }
                    static /*SafeFileHandle */ ShmOpen(/*string*/ name, /*OpenFlags*/ flags, /*int*/ mode)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*int */ ShmUnlink(/*string*/ name)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*Error */ GetLastError()
                    {
                        return $.$sim.Interop.Sys.ConvertErrorPlatformToPal($.$spc.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    static /*ErrorInfo */ GetLastErrorInfo()
                    {
                        return new $.$sim.Interop.ErrorInfo().$ctor$2($.$spc.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    static /*string */ StrError(/*int*/ platformErrno)
                    {
                        /*int*/ let MaxBufferLength = 1024;
                        /*byte**/ let buffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.Byte, MaxBufferLength, null);
                        /*byte**/ let message = $.$sim.Interop.Sys.StrErrorR(platformErrno, buffer, MaxBufferLength);
                        if (message === null)
                        {
                            message = buffer;
                        }
                        return $.$spc.System.Runtime.InteropServices.Marshal.PtrToStringUTF8($.$cast(message, $.$spc.System.IntPtr));
                    }
                    static /*int */ MAdvise(/*IntPtr*/ addr, /*ulong*/ length, /*MemoryAdvice*/ advice)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*SafeFileHandle */ MemfdCreate(/*string*/ name, /*int*/ isReadonly)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*int */ MemfdSupportedImpl()
                    {
                        return 0;
                    }
                    static $h = 370932;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":120259455220,"f":40},"n":"IsMemfdSupported","d":370932,"h":115964487924,"f":40}],"m":[{"r":655361,"p":[{"n":"fd","p":786433}],"n":"Close","d":370932,"h":4295338228,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Close","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"addr","p":786433},{"n":"len","p":983041}],"n":"MUnmap","d":370932,"h":12885272820,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MUnmap","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"addr","p":786433},{"n":"len","p":983041},{"n":"flags","p":895220}],"n":"MSync","d":370932,"h":21475207412,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MSync","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":7143425,"p":[{"n":"filename","p":1310721},{"n":"flags","p":960756},{"n":"mode","p":655361}],"n":"Open","d":370932,"h":30065142004,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Open","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109576193},{"n":"output","p":502004,"f":2}],"n":"FStat","d":370932,"h":47245011188,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FStat","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"path","p":1310721},{"n":"output","p":502004,"f":2}],"n":"Stat","d":370932,"h":51539978484,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Stat","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"path","p":1310721},{"n":"output","p":502004,"f":2}],"n":"LStat","d":370932,"h":55834945780,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_LStat","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":786433,"p":[{"n":"addr","p":786433},{"n":"len","p":983041},{"n":"prot","p":829684},{"n":"flags","p":764148},{"n":"fd","p":7143425},{"n":"offset","p":917505}],"n":"MMap","d":370932,"h":68719847668,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MMap","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":786433,"p":[{"n":"addr","p":786433},{"n":"len","p":983041},{"n":"prot","p":829684},{"n":"flags","p":764148},{"n":"fd","p":786433},{"n":"offset","p":917505}],"n":"MMap","o":"@$1","d":370932,"h":73014814964,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MMap","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":917505,"p":[{"n":"name","p":1026292}],"n":"SysConf","d":370932,"h":81604749556,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_SysConf","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"addr","p":786433},{"n":"length","p":983041},{"n":"advice","p":698612}],"n":"MAdvise","d":370932,"h":85899716852,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MAdvise","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":7143425,"p":[{"n":"name","p":1310721},{"n":"flags","p":960756},{"n":"mode","p":655361}],"n":"ShmOpen","d":370932,"h":94489651444,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ShmOpen","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"name","p":1310721}],"n":"ShmUnlink","d":370932,"h":98784618740,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ShmUnlink","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":7143425,"p":[{"n":"name","p":1310721},{"n":"isReadonly","p":655361}],"n":"MemfdCreate","d":370932,"h":103079586036,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MemfdCreate","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"n":"MemfdSupportedImpl","d":370932,"h":107374553332,"f":34,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_IsMemfdSupported","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"pathname","p":1310721}],"n":"Unlink","d":370932,"h":124554422516,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Unlink","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":174324,"n":"GetLastError","d":370932,"h":128849389812,"f":40},{"r":239860,"n":"GetLastErrorInfo","d":370932,"h":133144357108,"f":40},{"r":1310721,"p":[{"n":"platformErrno","p":655361}],"n":"StrError","d":370932,"h":137439324404,"f":40},{"r":174324,"p":[{"n":"platformErrno","p":655361}],"n":"ConvertErrorPlatformToPal","d":370932,"h":141734291700,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ConvertErrorPlatformToPal","t":1310721}]},{"t":109969409,"c":4404936705}]},{"r":655361,"p":[{"n":"error","p":174324}],"n":"ConvertErrorPalToPlatform","d":370932,"h":146029258996,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ConvertErrorPalToPlatform","t":1310721}]},{"t":109969409,"c":4404936705}]},{"r":0,"p":[{"n":"platformErrno","p":655361},{"n":"buffer","p":0},{"n":"bufferSize","p":655361}],"n":"StrErrorR","d":370932,"h":150324226292,"f":34,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_StrErrorR","t":1310721}]}]},{"r":655361,"p":[{"n":"fd","p":7143425},{"n":"length","p":917505}],"n":"FTruncate","d":370932,"h":154619193588,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FTruncate","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]}],"l":[{"t":327681,"n":"s_memfdSupported","d":370932,"h":111669520628,"f":34}],"j":[436468,895220,960756,502004,633076,567540,829684,764148,1026292,698612],"d":108788,"h":370932}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Sys`; }
                }, $cls, ($v) => $cls.$_Sys = $v);
            }
            static /*void */ ThrowExceptionForIoErrno(/*ErrorInfo*/ errorInfo, /*string?*/ path, /*bool*/ isDirError)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(errorInfo.Error !== 0/*Error.SUCCESS*/, "errorInfo.Error != Error.SUCCESS");
                $.$spc.System.Diagnostics.Debug.Assert$1(errorInfo.Error !== 65563/*Error.EINTR*/, "EINTR errors should be handled by the native shim and never bubble up to managed code");
                throw $.$sim.Interop.GetExceptionForIoErrno(errorInfo.Clone(), path, isDirError);
            }
            static /*void */ CheckIo(/*Error*/ error, /*string?*/ path, /*bool*/ isDirError)
            {
                if (error !== 0/*Interop.Error.SUCCESS*/)
                {
                    $.$sim.Interop.ThrowExceptionForIoErrno($.$sim.InteropErrorExtensions.Info(error), path, isDirError);
                }
            }
            static /*long */ CheckIo$1(/*long*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                if (result < 0n)
                {
                    $.$sim.Interop.ThrowExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), path, isDirError);
                }
                return result;
            }
            static /*void */ ThrowIOExceptionForLastError()
            {
                $.$sim.Interop.ThrowExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
            }
            static /*int */ CheckIo$2(/*int*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                $.$sim.Interop.CheckIo$1($.$cast(result, $.$spc.System.Int64), path, isDirError);
                return result;
            }
            static /*IntPtr */ CheckIo$3(/*IntPtr*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                $.$sim.Interop.CheckIo$1($.$cast(result, $.$spc.System.Int64), path, isDirError);
                return result;
            }
            static /*TSafeHandle */ CheckIo$4(TSafeHandle, /*TSafeHandle*/ handle, /*string?*/ path, /*bool*/ isDirError)
            {
                if (handle.IsInvalid)
                {
                    /*Exception*/ let e = $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), path, isDirError);
                    $.$dsp(handle, TSafeHandle, ($t) => $t.Dispose,);
                    throw e;
                }
                return handle;
            }
            static /*Exception */ GetExceptionForIoErrno(/*ErrorInfo*/ errorInfo, /*string?*/ path, /*bool*/ isDirError)
            {
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    let $switch1 = $switchJumpState1 ?? (errorInfo.Error);
                    switch($switch1)
                    {
                        case 65581/*Error.ENOENT*/:
                        if (!isDirError && (path === null || ParentDirectoryExists(path)))
                        {
                            return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.IO.FileNotFoundException().$ctor$17($.$sim.System.SR.Format($.$sim.System.SR.IO_FileNotFound_FileName, path), path) : new $.$spc.System.IO.FileNotFoundException().$ctor$15($.$sim.System.SR.IO_FileNotFound);
                        }
                        $switchJumpState1 = 65593/*Error.ENOTDIR*/; /*goto case Error.ENOTDIR*/
                        continue $switchJumpStart1;
                        case 65593/*Error.ENOTDIR*/:
                        return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.IO.DirectoryNotFoundException().$ctor$15($.$sim.System.SR.Format($.$sim.System.SR.IO_PathNotFound_Path, path)) : new $.$spc.System.IO.DirectoryNotFoundException().$ctor$15($.$sim.System.SR.IO_PathNotFound_NoPathName);
                        case 65538/*Error.EACCES*/:
                        case 65544/*Error.EBADF*/:
                        case 65602/*Error.EPERM*/:
                        /*Exception*/ let inner = $.$sim.Interop.GetIOException(errorInfo.Clone(), null);
                        return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.UnauthorizedAccessException().$ctor$11($.$sim.System.SR.Format($.$sim.System.SR.UnauthorizedAccess_IODenied_Path, path), inner) : new $.$spc.System.UnauthorizedAccessException().$ctor$11($.$sim.System.SR.UnauthorizedAccess_IODenied_NoPathName, inner);
                        case 65573/*Error.ENAMETOOLONG*/:
                        return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.IO.PathTooLongException().$ctor$15($.$sim.System.SR.Format($.$sim.System.SR.IO_PathTooLong_Path, path)) : new $.$spc.System.IO.PathTooLongException().$ctor$15($.$sim.System.SR.IO_PathTooLong);
                        case 65542/*Error.EWOULDBLOCK*/:
                        return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.IO.IOException().$ctor$11($.$sim.System.SR.Format($.$sim.System.SR.IO_SharingViolation_File, path), errorInfo.RawErrno) : new $.$spc.System.IO.IOException().$ctor$11($.$sim.System.SR.IO_SharingViolation_NoFileName, errorInfo.RawErrno);
                        case 65547/*Error.ECANCELED*/:
                        return new $.$spc.System.OperationCanceledException().$ctor$9();
                        case 65558/*Error.EFBIG*/:
                        return new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("value", $.$sim.System.SR.ArgumentOutOfRange_FileLengthTooBig);
                        case 65556/*Error.EEXIST*/:
                        if (!$.$spc.System.String.IsNullOrEmpty(path))
                        {
                            return new $.$spc.System.IO.IOException().$ctor$11($.$sim.System.SR.Format($.$sim.System.SR.IO_FileExists_Name, path), errorInfo.RawErrno);
                        }
                        $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                        continue $switchJumpStart1;
                        default:
                        return $.$sim.Interop.GetIOException(errorInfo.Clone(), path);
                        /*static bool*/  function ParentDirectoryExists(/*string*/ fullPath)
                        {
                            /*string?*/ let parentPath = $.$spc.System.IO.Path.GetDirectoryName($.$spc.System.IO.Path.TrimEndingDirectorySeparator(fullPath));
                            return $.$spc.System.IO.Directory.Exists(parentPath);
                        }
                    }
                    break;
                }
            }
            static /*Exception */ GetIOException(/*Interop.ErrorInfo*/ errorInfo, /*string?*/ path)
            {
                /*string*/ let msg = errorInfo.GetErrorMessage();
                return new $.$spc.System.IO.IOException().$ctor$11($.$spc.System.String.IsNullOrEmpty(path) ? msg : `${msg} : '${path}'`, errorInfo.RawErrno);
            }
            static $_Error;
            static get Error()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_Error ??= $asm.$nstr("$sim.Interop.Error", ($self) => class Error extends $.$spc.System.Enum
                {
                    static SUCCESS = 0;
                    static E2BIG = 65537;
                    static EACCES = 65538;
                    static EADDRINUSE = 65539;
                    static EADDRNOTAVAIL = 65540;
                    static EAFNOSUPPORT = 65541;
                    static EAGAIN = 65542;
                    static EALREADY = 65543;
                    static EBADF = 65544;
                    static EBADMSG = 65545;
                    static EBUSY = 65546;
                    static ECANCELED = 65547;
                    static ECHILD = 65548;
                    static ECONNABORTED = 65549;
                    static ECONNREFUSED = 65550;
                    static ECONNRESET = 65551;
                    static EDEADLK = 65552;
                    static EDESTADDRREQ = 65553;
                    static EDOM = 65554;
                    static EDQUOT = 65555;
                    static EEXIST = 65556;
                    static EFAULT = 65557;
                    static EFBIG = 65558;
                    static EHOSTUNREACH = 65559;
                    static EIDRM = 65560;
                    static EILSEQ = 65561;
                    static EINPROGRESS = 65562;
                    static EINTR = 65563;
                    static EINVAL = 65564;
                    static EIO = 65565;
                    static EISCONN = 65566;
                    static EISDIR = 65567;
                    static ELOOP = 65568;
                    static EMFILE = 65569;
                    static EMLINK = 65570;
                    static EMSGSIZE = 65571;
                    static EMULTIHOP = 65572;
                    static ENAMETOOLONG = 65573;
                    static ENETDOWN = 65574;
                    static ENETRESET = 65575;
                    static ENETUNREACH = 65576;
                    static ENFILE = 65577;
                    static ENOBUFS = 65578;
                    static ENODEV = 65580;
                    static ENOENT = 65581;
                    static ENOEXEC = 65582;
                    static ENOLCK = 65583;
                    static ENOLINK = 65584;
                    static ENOMEM = 65585;
                    static ENOMSG = 65586;
                    static ENOPROTOOPT = 65587;
                    static ENOSPC = 65588;
                    static ENOSYS = 65591;
                    static ENOTCONN = 65592;
                    static ENOTDIR = 65593;
                    static ENOTEMPTY = 65594;
                    static ENOTRECOVERABLE = 65595;
                    static ENOTSOCK = 65596;
                    static ENOTSUP = 65597;
                    static ENOTTY = 65598;
                    static ENXIO = 65599;
                    static EOVERFLOW = 65600;
                    static EOWNERDEAD = 65601;
                    static EPERM = 65602;
                    static EPIPE = 65603;
                    static EPROTO = 65604;
                    static EPROTONOSUPPORT = 65605;
                    static EPROTOTYPE = 65606;
                    static ERANGE = 65607;
                    static EROFS = 65608;
                    static ESPIPE = 65609;
                    static ESRCH = 65610;
                    static ESTALE = 65611;
                    static ETIMEDOUT = 65613;
                    static ETXTBSY = 65614;
                    static EXDEV = 65615;
                    static ESOCKTNOSUPPORT = 65630;
                    static EPFNOSUPPORT = 65632;
                    static ESHUTDOWN = 65644;
                    static EHOSTDOWN = 65648;
                    static ENODATA = 65649;
                    static EHOSTNOTFOUND = 131073;
                    static ESOCKETERROR = 131074;
                    static EOPNOTSUPP = 65597;
                    static EWOULDBLOCK = 65542;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "SUCCESS": 0n,
                            "E2BIG": 65537n,
                            "EACCES": 65538n,
                            "EADDRINUSE": 65539n,
                            "EADDRNOTAVAIL": 65540n,
                            "EAFNOSUPPORT": 65541n,
                            "EAGAIN": 65542n,
                            "EALREADY": 65543n,
                            "EBADF": 65544n,
                            "EBADMSG": 65545n,
                            "EBUSY": 65546n,
                            "ECANCELED": 65547n,
                            "ECHILD": 65548n,
                            "ECONNABORTED": 65549n,
                            "ECONNREFUSED": 65550n,
                            "ECONNRESET": 65551n,
                            "EDEADLK": 65552n,
                            "EDESTADDRREQ": 65553n,
                            "EDOM": 65554n,
                            "EDQUOT": 65555n,
                            "EEXIST": 65556n,
                            "EFAULT": 65557n,
                            "EFBIG": 65558n,
                            "EHOSTUNREACH": 65559n,
                            "EIDRM": 65560n,
                            "EILSEQ": 65561n,
                            "EINPROGRESS": 65562n,
                            "EINTR": 65563n,
                            "EINVAL": 65564n,
                            "EIO": 65565n,
                            "EISCONN": 65566n,
                            "EISDIR": 65567n,
                            "ELOOP": 65568n,
                            "EMFILE": 65569n,
                            "EMLINK": 65570n,
                            "EMSGSIZE": 65571n,
                            "EMULTIHOP": 65572n,
                            "ENAMETOOLONG": 65573n,
                            "ENETDOWN": 65574n,
                            "ENETRESET": 65575n,
                            "ENETUNREACH": 65576n,
                            "ENFILE": 65577n,
                            "ENOBUFS": 65578n,
                            "ENODEV": 65580n,
                            "ENOENT": 65581n,
                            "ENOEXEC": 65582n,
                            "ENOLCK": 65583n,
                            "ENOLINK": 65584n,
                            "ENOMEM": 65585n,
                            "ENOMSG": 65586n,
                            "ENOPROTOOPT": 65587n,
                            "ENOSPC": 65588n,
                            "ENOSYS": 65591n,
                            "ENOTCONN": 65592n,
                            "ENOTDIR": 65593n,
                            "ENOTEMPTY": 65594n,
                            "ENOTRECOVERABLE": 65595n,
                            "ENOTSOCK": 65596n,
                            "ENOTSUP": 65597n,
                            "ENOTTY": 65598n,
                            "ENXIO": 65599n,
                            "EOVERFLOW": 65600n,
                            "EOWNERDEAD": 65601n,
                            "EPERM": 65602n,
                            "EPIPE": 65603n,
                            "EPROTO": 65604n,
                            "EPROTONOSUPPORT": 65605n,
                            "EPROTOTYPE": 65606n,
                            "ERANGE": 65607n,
                            "EROFS": 65608n,
                            "ESPIPE": 65609n,
                            "ESRCH": 65610n,
                            "ESTALE": 65611n,
                            "ETIMEDOUT": 65613n,
                            "ETXTBSY": 65614n,
                            "EXDEV": 65615n,
                            "ESOCKTNOSUPPORT": 65630n,
                            "EPFNOSUPPORT": 65632n,
                            "ESHUTDOWN": 65644n,
                            "EHOSTDOWN": 65648n,
                            "ENODATA": 65649n,
                            "EHOSTNOTFOUND": 131073n,
                            "ESOCKETERROR": 131074n,
                            "EOPNOTSUPP": 65597n,
                            "EWOULDBLOCK": 65542n
                        };
                    }
                    static $h = 174324;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":174324,"n":"SUCCESS","d":174324,"h":4295141620,"f":33},{"t":174324,"n":"E2BIG","d":174324,"h":8590108916,"f":33},{"t":174324,"n":"EACCES","d":174324,"h":12885076212,"f":33},{"t":174324,"n":"EADDRINUSE","d":174324,"h":17180043508,"f":33},{"t":174324,"n":"EADDRNOTAVAIL","d":174324,"h":21475010804,"f":33},{"t":174324,"n":"EAFNOSUPPORT","d":174324,"h":25769978100,"f":33},{"t":174324,"n":"EAGAIN","d":174324,"h":30064945396,"f":33},{"t":174324,"n":"EALREADY","d":174324,"h":34359912692,"f":33},{"t":174324,"n":"EBADF","d":174324,"h":38654879988,"f":33},{"t":174324,"n":"EBADMSG","d":174324,"h":42949847284,"f":33},{"t":174324,"n":"EBUSY","d":174324,"h":47244814580,"f":33},{"t":174324,"n":"ECANCELED","d":174324,"h":51539781876,"f":33},{"t":174324,"n":"ECHILD","d":174324,"h":55834749172,"f":33},{"t":174324,"n":"ECONNABORTED","d":174324,"h":60129716468,"f":33},{"t":174324,"n":"ECONNREFUSED","d":174324,"h":64424683764,"f":33},{"t":174324,"n":"ECONNRESET","d":174324,"h":68719651060,"f":33},{"t":174324,"n":"EDEADLK","d":174324,"h":73014618356,"f":33},{"t":174324,"n":"EDESTADDRREQ","d":174324,"h":77309585652,"f":33},{"t":174324,"n":"EDOM","d":174324,"h":81604552948,"f":33},{"t":174324,"n":"EDQUOT","d":174324,"h":85899520244,"f":33},{"t":174324,"n":"EEXIST","d":174324,"h":90194487540,"f":33},{"t":174324,"n":"EFAULT","d":174324,"h":94489454836,"f":33},{"t":174324,"n":"EFBIG","d":174324,"h":98784422132,"f":33},{"t":174324,"n":"EHOSTUNREACH","d":174324,"h":103079389428,"f":33},{"t":174324,"n":"EIDRM","d":174324,"h":107374356724,"f":33},{"t":174324,"n":"EILSEQ","d":174324,"h":111669324020,"f":33},{"t":174324,"n":"EINPROGRESS","d":174324,"h":115964291316,"f":33},{"t":174324,"n":"EINTR","d":174324,"h":120259258612,"f":33},{"t":174324,"n":"EINVAL","d":174324,"h":124554225908,"f":33},{"t":174324,"n":"EIO","d":174324,"h":128849193204,"f":33},{"t":174324,"n":"EISCONN","d":174324,"h":133144160500,"f":33},{"t":174324,"n":"EISDIR","d":174324,"h":137439127796,"f":33},{"t":174324,"n":"ELOOP","d":174324,"h":141734095092,"f":33},{"t":174324,"n":"EMFILE","d":174324,"h":146029062388,"f":33},{"t":174324,"n":"EMLINK","d":174324,"h":150324029684,"f":33},{"t":174324,"n":"EMSGSIZE","d":174324,"h":154618996980,"f":33},{"t":174324,"n":"EMULTIHOP","d":174324,"h":158913964276,"f":33},{"t":174324,"n":"ENAMETOOLONG","d":174324,"h":163208931572,"f":33},{"t":174324,"n":"ENETDOWN","d":174324,"h":167503898868,"f":33},{"t":174324,"n":"ENETRESET","d":174324,"h":171798866164,"f":33},{"t":174324,"n":"ENETUNREACH","d":174324,"h":176093833460,"f":33},{"t":174324,"n":"ENFILE","d":174324,"h":180388800756,"f":33},{"t":174324,"n":"ENOBUFS","d":174324,"h":184683768052,"f":33},{"t":174324,"n":"ENODEV","d":174324,"h":188978735348,"f":33},{"t":174324,"n":"ENOENT","d":174324,"h":193273702644,"f":33},{"t":174324,"n":"ENOEXEC","d":174324,"h":197568669940,"f":33},{"t":174324,"n":"ENOLCK","d":174324,"h":201863637236,"f":33},{"t":174324,"n":"ENOLINK","d":174324,"h":206158604532,"f":33},{"t":174324,"n":"ENOMEM","d":174324,"h":210453571828,"f":33},{"t":174324,"n":"ENOMSG","d":174324,"h":214748539124,"f":33},{"t":174324,"n":"ENOPROTOOPT","d":174324,"h":219043506420,"f":33},{"t":174324,"n":"ENOSPC","d":174324,"h":223338473716,"f":33},{"t":174324,"n":"ENOSYS","d":174324,"h":227633441012,"f":33},{"t":174324,"n":"ENOTCONN","d":174324,"h":231928408308,"f":33},{"t":174324,"n":"ENOTDIR","d":174324,"h":236223375604,"f":33},{"t":174324,"n":"ENOTEMPTY","d":174324,"h":240518342900,"f":33},{"t":174324,"n":"ENOTRECOVERABLE","d":174324,"h":244813310196,"f":33},{"t":174324,"n":"ENOTSOCK","d":174324,"h":249108277492,"f":33},{"t":174324,"n":"ENOTSUP","d":174324,"h":253403244788,"f":33},{"t":174324,"n":"ENOTTY","d":174324,"h":257698212084,"f":33},{"t":174324,"n":"ENXIO","d":174324,"h":261993179380,"f":33},{"t":174324,"n":"EOVERFLOW","d":174324,"h":266288146676,"f":33},{"t":174324,"n":"EOWNERDEAD","d":174324,"h":270583113972,"f":33},{"t":174324,"n":"EPERM","d":174324,"h":274878081268,"f":33},{"t":174324,"n":"EPIPE","d":174324,"h":279173048564,"f":33},{"t":174324,"n":"EPROTO","d":174324,"h":283468015860,"f":33},{"t":174324,"n":"EPROTONOSUPPORT","d":174324,"h":287762983156,"f":33},{"t":174324,"n":"EPROTOTYPE","d":174324,"h":292057950452,"f":33},{"t":174324,"n":"ERANGE","d":174324,"h":296352917748,"f":33},{"t":174324,"n":"EROFS","d":174324,"h":300647885044,"f":33},{"t":174324,"n":"ESPIPE","d":174324,"h":304942852340,"f":33},{"t":174324,"n":"ESRCH","d":174324,"h":309237819636,"f":33},{"t":174324,"n":"ESTALE","d":174324,"h":313532786932,"f":33},{"t":174324,"n":"ETIMEDOUT","d":174324,"h":317827754228,"f":33},{"t":174324,"n":"ETXTBSY","d":174324,"h":322122721524,"f":33},{"t":174324,"n":"EXDEV","d":174324,"h":326417688820,"f":33},{"t":174324,"n":"ESOCKTNOSUPPORT","d":174324,"h":330712656116,"f":33},{"t":174324,"n":"EPFNOSUPPORT","d":174324,"h":335007623412,"f":33},{"t":174324,"n":"ESHUTDOWN","d":174324,"h":339302590708,"f":33},{"t":174324,"n":"EHOSTDOWN","d":174324,"h":343597558004,"f":33},{"t":174324,"n":"ENODATA","d":174324,"h":347892525300,"f":33},{"t":174324,"n":"EHOSTNOTFOUND","d":174324,"h":352187492596,"f":33},{"t":174324,"n":"ESOCKETERROR","d":174324,"h":356482459892,"f":33},{"t":174324,"n":"EOPNOTSUPP","d":174324,"h":360777427188,"f":33},{"t":174324,"n":"EWOULDBLOCK","d":174324,"h":365072394484,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":174324,"h":369367361780,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":108788,"h":174324}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `Interop.Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            static $_ErrorInfo;
            static get ErrorInfo()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_ErrorInfo ??= $asm.$nstr("$sim.Interop.ErrorInfo", ($self) => class ErrorInfo extends $.$spc.System.ValueType
                {
                    /*Error*/  get _error() { return this.$getField(0, $.$sim.Interop.Error); }
                    /*Error*/  set _error(value) { this.$setField(0, $.$sim.Interop.Error, value); }
                    /*int*/  get _rawErrno() { return this.$getField(4, $.$spc.System.Int32); }
                    /*int*/  set _rawErrno(value) { this.$setField(4, $.$spc.System.Int32, value); }
                    $ctor$2(/*int*/ errno)
                    {
                        super.$ctor$1();
                        {
                            this._error = $.$sim.Interop.Sys.ConvertErrorPlatformToPal(errno);
                            this._rawErrno = errno;
                        }
                        return this;
                    }
                    $ctor$3(/*Error*/ error)
                    {
                        super.$ctor$1();
                        {
                            this._error = error;
                            this._rawErrno = -1;
                        }
                        return this;
                    }
                    /*Error */ get Error()
                    {
                        return this._error;
                    }
                    /*int */ get RawErrno()
                    {
                        return this._rawErrno === -1 ? (this._rawErrno = $.$sim.Interop.Sys.ConvertErrorPalToPlatform(this._error)) : this._rawErrno;
                    }
                    /*string */ GetErrorMessage()
                    {
                        return $.$sim.Interop.Sys.StrError(this.RawErrno);
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return `RawErrno: ${this.RawErrno} Error: ${this.Error} GetErrorMessage: ${this.GetErrorMessage()}`;
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$sim.Interop.ErrorInfo.ToString.apply(this, arguments); }
                    //default value type constructor
                    $ctor$4()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._error = this._error;
                        copy._rawErrno = this._rawErrno;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._error = 0;
                        this._rawErrno = 0;
                    }
                    static $h = 239860;
                    static $z = 8;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":174324,"g":{"r":0,"d":0,"h":25770043636,"f":8},"n":"Error","d":239860,"h":21475076340,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":34359978228,"f":8},"n":"RawErrno","d":239860,"h":30065010932,"f":8}],"m":[{"r":1310721,"n":"GetErrorMessage","d":239860,"h":38654945524,"f":8},{"r":1310721,"n":"ToString","d":239860,"h":42949912820,"f":32769}],"l":[{"t":174324,"n":"_error","d":239860,"h":4295207156,"f":2},{"t":655361,"n":"_rawErrno","d":239860,"h":8590174452,"f":2}],"c":[{"p":[{"n":"errno","p":655361}],"n":".ctor","o":"$ctor$2","d":239860,"h":12885141748,"f":8},{"p":[{"n":"error","p":174324}],"n":".ctor","o":"$ctor$3","d":239860,"h":17180109044,"f":8},{"n":".ctor","o":"$ctor$4","d":239860,"h":47244880116,"f":1}],"d":108788,"h":239860}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Interop.ErrorInfo`; }
                }, $cls, ($v) => $cls.$_ErrorInfo = $v);
            }
            static $h = 108788;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"errorInfo","p":239860},{"n":"path","p":1310721},{"n":"isDirError","p":262145}],"n":"ThrowExceptionForIoErrno","d":108788,"h":12885010676,"f":34},{"r":65537,"p":[{"n":"error","p":174324},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"CheckIo","d":108788,"h":17179977972,"f":40},{"r":917505,"p":[{"n":"result","p":917505},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"CheckIo","o":"@$1","d":108788,"h":21474945268,"f":40},{"r":65537,"n":"ThrowIOExceptionForLastError","d":108788,"h":25769912564,"f":40},{"r":655361,"p":[{"n":"result","p":655361},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"CheckIo","o":"@$2","d":108788,"h":30064879860,"f":40},{"r":786433,"p":[{"n":"result","p":786433},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"CheckIo","o":"@$3","d":108788,"h":34359847156,"f":40},{"r":(TSafeHandle) => TSafeHandle.$h,"p":[{"n":"handle","p":(TSafeHandle) => TSafeHandle.$h},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"g":["TSafeHandle"],"n":"CheckIo","o":"@$4","d":108788,"h":38654814452,"f":131112},{"r":47251457,"p":[{"n":"errorInfo","p":239860},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"GetExceptionForIoErrno","d":108788,"h":42949781748,"f":40},{"r":47251457,"p":[{"n":"errorInfo","p":239860},{"n":"path","p":1310721,"f":65}],"n":"GetIOException","d":108788,"h":47244749044,"f":40}],"j":[305396,370932,174324,239860],"h":108788}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        
        $asm.$cls("$sim.InteropErrorExtensions", ($self) => class InteropErrorExtensions
        {
            static /*Interop.ErrorInfo */ Info(/*this Interop.Error*/ error)
            {
                return new $.$sim.Interop.ErrorInfo().$ctor$3(error);
            }
            static $h = 1091828;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":239860,"p":[{"n":"error","p":174324}],"n":"Info","d":1091828,"h":4296059124,"f":33}],"h":1091828}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `InteropErrorExtensions`; }
        });
        
        $asm.$cls("$sim.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sim.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.IO.MemoryMappedFiles", $.$sim.System.SR.$type.Assembly);
                    $.$sim.System.SR.s_resourceManager = temp;
                }
                return $.$sim.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sim.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sim.System.SR.resourceCulture = value;
            }
            static /*string */ get IO_FileNotFound()
            {
                return "Unable to find the specified file.";
            }
            static /*string */ get IO_FileNotFound_FileName()
            {
                return "Could not find file '{0}'.";
            }
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find file '{0}'.", arg1);
            }
            static /*string */ get IO_AlreadyExists_Name()
            {
                return "Cannot create '{0}' because a file or directory with the same name already exists.";
            }
            static /*string */ FormatIO_AlreadyExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Cannot create '{0}' because a file or directory with the same name already exists.", arg1);
            }
            static /*string */ get IO_FileExists_Name()
            {
                return "The file '{0}' already exists.";
            }
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The file '{0}' already exists.", arg1);
            }
            static /*string */ get IO_SharingViolation_File()
            {
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                return "The process cannot access the file because it is being used by another process.";
            }
            static /*string */ get IO_PathNotFound_Path()
            {
                return "Could not find a part of the path '{0}'.";
            }
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find a part of the path '{0}'.", arg1);
            }
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                return "Could not find a part of the path.";
            }
            static /*string */ get IO_PathTooLong()
            {
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                return "Access to the path '{0}' is denied.";
            }
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Access to the path '{0}' is denied.", arg1);
            }
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                return "Access to the path is denied.";
            }
            static /*string */ get Argument_MapNameEmptyString()
            {
                return "Map name cannot be an empty string.";
            }
            static /*string */ get Argument_EmptyFile()
            {
                return "A positive capacity must be specified for a Memory Mapped File backed by an empty file.";
            }
            static /*string */ get Argument_NewMMFWriteAccessNotAllowed()
            {
                return "MemoryMappedFileAccess.Write is not permitted when creating new memory mapped files. Use MemoryMappedFileAccess.ReadWrite instead.";
            }
            static /*string */ get Argument_ReadAccessWithLargeCapacity()
            {
                return "When specifying MemoryMappedFileAccess.Read access, the capacity must not be larger than the file size.";
            }
            static /*string */ get Argument_NewMMFAppendModeNotAllowed()
            {
                return "FileMode.Append is not permitted when creating new memory mapped files. Instead, use MemoryMappedFileView to ensure write-only access within a specified region.";
            }
            static /*string */ get Argument_NewMMFTruncateModeNotAllowed()
            {
                return "FileMode.Truncate is not permitted when creating new memory mapped files.";
            }
            static /*string */ get ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed()
            {
                return "The capacity cannot be greater than the size of the system's logical address space.";
            }
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                return "Specified file length was too large for the file system.";
            }
            static /*string */ get ArgumentOutOfRange_PositiveOrDefaultCapacityRequired()
            {
                return "The capacity must be greater than or equal to 0. 0 represents the size of the file being mapped.";
            }
            static /*string */ get ArgumentOutOfRange_PositiveOrDefaultSizeRequired()
            {
                return "The size must be greater than or equal to 0. If 0 is specified, the view extends from the specified offset to the end of the file mapping.";
            }
            static /*string */ get ArgumentOutOfRange_CapacityGEFileSizeRequired()
            {
                return "The capacity may not be smaller than the file size.";
            }
            static /*string */ get IO_NotEnoughMemory()
            {
                return "Not enough memory to map view.";
            }
            static /*string */ get InvalidOperation_CantCreateFileMapping()
            {
                return "Cannot create file mapping.";
            }
            static /*string */ get NotSupported_MMViewStreamsFixedLength()
            {
                return "MemoryMappedViewStreams are fixed length.";
            }
            static /*string */ get NotSupported_UnreadableStream()
            {
                return "Stream does not support reading.";
            }
            static /*string */ get NotSupported_UnwritableStream()
            {
                return "Stream does not support writing.";
            }
            static /*string */ get ObjectDisposed_ViewAccessorClosed()
            {
                return "Cannot access a closed accessor.";
            }
            static /*string */ get ObjectDisposed_StreamIsClosed()
            {
                return "Cannot access a closed Stream.";
            }
            static /*string */ get PlatformNotSupported_NamedMaps()
            {
                return "Named maps are not supported.";
            }
            static /*string */ get IO_PathTooLong_Path()
            {
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            static /*string */ get PlatformNotSupported_MemoryMappedFiles()
            {
                return "System.IO.MemoryMappedFiles is not supported on this platform.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sim.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sim.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sim.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sim.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sim.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sim.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1812724;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1812724}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedView", ($self) => class MemoryMappedView extends $.$spc.System.Object
        {
            /*SafeMemoryMappedViewHandle*/ _viewHandle = null;
            /*long*/ _pointerOffset = 0n;
            /*long*/ _size = 0n;
            /*MemoryMappedFileAccess*/ _access = 0;
            $ctor$1(/*SafeMemoryMappedViewHandle*/ viewHandle, /*long*/ pointerOffset, /*long*/ size, /*MemoryMappedFileAccess*/ access)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(viewHandle !== null, "viewHandle != null");
                    this._viewHandle = viewHandle;
                    this._pointerOffset = pointerOffset;
                    this._size = size;
                    this._access = access;
                }
                return this;
            }
            /*SafeMemoryMappedViewHandle */ get ViewHandle()
            {
                return this._viewHandle;
            }
            /*long */ get PointerOffset()
            {
                return this._pointerOffset;
            }
            /*long */ get Size()
            {
                return this._size;
            }
            /*MemoryMappedFileAccess */ get Access()
            {
                return this._access;
            }
            /*void */ Dispose()
            {
                if (!this._viewHandle.IsClosed)
                {
                    this._viewHandle.Dispose();
                }
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*bool */ get IsClosed()
            {
                return this._viewHandle.IsClosed;
            }
            static /*void */ ValidateSizeAndOffset(/*long*/ size, /*long*/ offset, /*long*/ allocationGranularity, /*out ulong*/ newSize, /*out long*/ extraMemNeeded, /*out long*/ newOffset)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(size >= 0n, "size >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(offset >= 0n, "offset >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(allocationGranularity > 0n, "allocationGranularity > 0");
                extraMemNeeded.$v = offset % allocationGranularity;
                newOffset.$v = offset - extraMemNeeded.$v;
                newSize.$v = (size !== BigInt(0/*MemoryMappedFile.DefaultSize*/)) ? $.$cast(size, $.$spc.System.UInt64) + $.$cast(extraMemNeeded.$v, $.$spc.System.UInt64) : 0n;
                if ($.$spc.System.IntPtr.Size === 4 && newSize.$v > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("size", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
            }
            static /*MemoryMappedView */ CreateView(/*SafeMemoryMappedFileHandle*/ memMappedFileHandle, /*MemoryMappedFileAccess*/ access, /*long*/ requestedOffset, /*long*/ requestedSize)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int64, requestedOffset, memMappedFileHandle._capacity, "offset");
                if (requestedSize > 8192000000000n)
                {
                    throw new $.$spc.System.IO.IOException().$ctor$10($.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                if (requestedOffset + requestedSize > memMappedFileHandle._capacity)
                {
                    throw new $.$spc.System.UnauthorizedAccessException().$ctor$9();
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(memMappedFileHandle.IsClosed, memMappedFileHandle);
                if (requestedSize === BigInt(0/*MemoryMappedFile.DefaultSize*/))
                {
                    requestedSize = memMappedFileHandle._capacity - requestedOffset;
                }
                /*ulong*/ let nativeSize;
                /*long*/ let extraMemNeeded, nativeOffset;
                /*long*/ let pageSize = $.$sim.Interop.Sys.SysConf(2/*Interop.Sys.SysConfName._SC_PAGESIZE*/);
                $.$spc.System.Diagnostics.Debug.Assert$1(pageSize > 0n, "pageSize > 0");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.ValidateSizeAndOffset(requestedSize, requestedOffset, pageSize, $.$ref(() => nativeSize, ($v) => nativeSize = $v, $.$spc.System.UInt64), $.$ref(() => extraMemNeeded, ($v) => extraMemNeeded = $v, $.$spc.System.Int64), $.$ref(() => nativeOffset, ($v) => nativeOffset = $v, $.$spc.System.Int64));
                /*Interop.Sys.MemoryMappedFlags*/ let flags = (memMappedFileHandle._access === 3/*MemoryMappedFileAccess.CopyOnWrite*/ || access === 3/*MemoryMappedFileAccess.CopyOnWrite*/) ? 2/*Interop.Sys.MemoryMappedFlags.MAP_PRIVATE*/ : 1/*Interop.Sys.MemoryMappedFlags.MAP_SHARED*/;
                /*SafeFileHandle*/ let fd;
                if (memMappedFileHandle._fileStreamHandle !== null)
                {
                    fd = memMappedFileHandle._fileStreamHandle;
                    $.$spc.System.Diagnostics.Debug.Assert$1(!fd.IsInvalid, "!fd.IsInvalid");
                }
                else 
                {
                    fd = new $.$spc.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$4(new $.$spc.System.IntPtr().$ctor$2(-1), false);
                    flags |= 16/*Interop.Sys.MemoryMappedFlags.MAP_ANONYMOUS*/;
                }
                /*Interop.Sys.MemoryMappedProtections*/ let viewProtForVerification = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(access, true);
                /*Interop.Sys.MemoryMappedProtections*/ let mapProtForVerification = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(memMappedFileHandle._access, true);
                if ((viewProtForVerification & mapProtForVerification) !== viewProtForVerification)
                {
                    throw new $.$spc.System.UnauthorizedAccessException().$ctor$9();
                }
                /*Interop.Sys.MemoryMappedProtections*/ let viewProtForCreation = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(access, false);
                /*IntPtr*/ let addr;
                if (nativeSize > 0n)
                {
                    addr = $.$sim.Interop.Sys.MMap($.$spc.System.IntPtr.Zero, nativeSize, viewProtForCreation, flags, fd, nativeOffset);
                }
                else 
                {
                    addr = $.$sim.Interop.Sys.MMap($.$spc.System.IntPtr.Zero, 1n, viewProtForCreation, flags | 16/*Interop.Sys.MemoryMappedFlags.MAP_ANONYMOUS*/, new $.$spc.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$4(new $.$spc.System.IntPtr().$ctor$2(-1), false), 0n);
                    requestedSize = 0n;
                    extraMemNeeded = 0n;
                }
                if (addr === $.$spc.System.IntPtr.Zero)
                {
                    throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                }
                if (memMappedFileHandle._inheritability === 0/*HandleInheritability.None*/)
                {
                    $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.DisableForkingIfPossible(addr, nativeSize);
                }
                /*var*/ let viewHandle = new $.$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle().$ctor$6(addr, true);
                viewHandle.Initialize(nativeSize);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView().$ctor$1(viewHandle, extraMemNeeded, requestedSize, access);
            }
            /*void */ Flush(/*UIntPtr*/ capacity)
            {
                if (capacity === $.$spc.System.UIntPtr.Zero)
                {
                    return;
                }
                /*byte**/ let ptr = null;
                try
                {
                    this._viewHandle.AcquirePointer($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typePointer($.$spc.System.Byte), () => ptr, ($v) => ptr = $v, null));
                    /*int*/ let result = $.$sim.Interop.Sys.MSync($.$cast(ptr, $.$spc.System.IntPtr), $.$cast(capacity, $.$spc.System.UInt64), 2/*Interop.Sys.MemoryMappedSyncFlags.MS_SYNC*/ | 16/*Interop.Sys.MemoryMappedSyncFlags.MS_INVALIDATE*/);
                    if (result < 0)
                    {
                        throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                    }
                }
                finally
                {
                    {
                        if (ptr !== null)
                        {
                            this._viewHandle.ReleasePointer();
                        }
                    }
                }
            }
            static /*void */ DisableForkingIfPossible(/*IntPtr*/ addr, /*ulong*/ length)
            {
                if (length > 0n)
                {
                    $.$sim.Interop.Sys.MAdvise(addr, length, 1/*Interop.Sys.MemoryAdvice.MADV_DONTFORK*/);
                }
            }
            /*long*/ static MaxProcessAddressSpace = 8192000000000n;
            static /*Interop.Sys.MemoryMappedProtections */ GetProtections(/*MemoryMappedFileAccess*/ access, /*bool*/ forVerification)
            {
                switch(access)
                {
                    default:
                    case 1/*MemoryMappedFileAccess.Read*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/;
                    case 2/*MemoryMappedFileAccess.Write*/:
                    return 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/;
                    case 0/*MemoryMappedFileAccess.ReadWrite*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/;
                    case 4/*MemoryMappedFileAccess.ReadExecute*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 4/*Interop.Sys.MemoryMappedProtections.PROT_EXEC*/;
                    case 5/*MemoryMappedFileAccess.ReadWriteExecute*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/ | 4/*Interop.Sys.MemoryMappedProtections.PROT_EXEC*/;
                    case 3/*MemoryMappedFileAccess.CopyOnWrite*/:
                    return forVerification ? 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ : 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/;
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1550580;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1222900,"g":{"r":0,"d":0,"h":30066321652,"f":1},"n":"ViewHandle","d":1550580,"h":25771354356,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":38656256244,"f":1},"n":"PointerOffset","d":1550580,"h":34361288948,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":47246190836,"f":1},"n":"Size","d":1550580,"h":42951223540,"f":1},{"p":1353972,"g":{"r":0,"d":0,"h":55836125428,"f":1},"n":"Access","d":1550580,"h":51541158132,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721027316,"f":1},"n":"IsClosed","d":1550580,"h":64426060020,"f":1}],"m":[{"r":65537,"n":"Dispose","d":1550580,"h":60131092724,"f":1},{"r":65537,"p":[{"n":"size","p":917505},{"n":"offset","p":917505},{"n":"allocationGranularity","p":917505},{"n":"newSize","p":983041,"f":2},{"n":"extraMemNeeded","p":917505,"f":2},{"n":"newOffset","p":917505,"f":2}],"n":"ValidateSizeAndOffset","d":1550580,"h":73015994612,"f":34},{"r":1550580,"p":[{"n":"memMappedFileHandle","p":1157364},{"n":"access","p":1353972},{"n":"requestedOffset","p":917505},{"n":"requestedSize","p":917505}],"n":"CreateView","d":1550580,"h":77310961908,"f":33},{"r":65537,"p":[{"n":"capacity","p":851969}],"n":"Flush","d":1550580,"h":81605929204,"f":1},{"r":65537,"p":[{"n":"addr","p":786433},{"n":"length","p":983041}],"n":"DisableForkingIfPossible","d":1550580,"h":85900896500,"f":34},{"r":829684,"p":[{"n":"access","p":1353972},{"n":"forVerification","p":262145}],"n":"GetProtections","d":1550580,"h":94490831092,"f":40}],"l":[{"t":1222900,"n":"_viewHandle","d":1550580,"h":4296517876,"f":2},{"t":917505,"n":"_pointerOffset","d":1550580,"h":8591485172,"f":2},{"t":917505,"n":"_size","d":1550580,"h":12886452468,"f":2},{"t":1353972,"n":"_access","d":1550580,"h":17181419764,"f":2},{"t":917505,"n":"MaxProcessAddressSpace","d":1550580,"h":90195863796,"f":34}],"c":[{"p":[{"n":"viewHandle","p":1222900},{"n":"pointerOffset","p":917505},{"n":"size","p":917505},{"n":"access","p":1353972}],"n":".ctor","o":"$ctor$1","d":1550580,"h":21476387060,"f":2}],"i":[57540609],"h":1550580}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedView`; }
        });
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedFile", ($self) => class MemoryMappedFile extends $.$spc.System.Object
        {
            /*SafeMemoryMappedFileHandle*/ _handle = null;
            /*bool*/ _leaveOpen = false;
            /*SafeFileHandle?*/ _fileHandle = null;
            /*int*/ static DefaultSize = 0;
            $ctor$1(/*SafeMemoryMappedFileHandle*/ handle)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(handle !== null, "handle != null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(!handle.IsClosed, "!handle.IsClosed");
                    $.$spc.System.Diagnostics.Debug.Assert$1(!handle.IsInvalid, "!handle.IsInvalid");
                    this._handle = handle;
                    this._leaveOpen = true;
                }
                return this;
            }
            $ctor$2(/*SafeMemoryMappedFileHandle*/ handle, /*SafeFileHandle*/ fileHandle, /*bool*/ leaveOpen)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(handle !== null, "handle != null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(!handle.IsClosed, "!handle.IsClosed");
                    $.$spc.System.Diagnostics.Debug.Assert$1(!handle.IsInvalid, "!handle.IsInvalid");
                    $.$spc.System.Diagnostics.Debug.Assert$1(fileHandle !== null, "fileHandle != null");
                    this._handle = handle;
                    this._fileHandle = fileHandle;
                    this._leaveOpen = leaveOpen;
                }
                return this;
            }
            static /*MemoryMappedFile */ OpenExisting(/*string*/ mapName)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenExisting$2(mapName, 6/*MemoryMappedFileRights.ReadWrite*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ OpenExisting$1(/*string*/ mapName, /*MemoryMappedFileRights*/ desiredAccessRights)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenExisting$2(mapName, desiredAccessRights, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ OpenExisting$2(/*string*/ mapName, /*MemoryMappedFileRights*/ desiredAccessRights, /*HandleInheritability*/ inheritability)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(mapName, "mapName");
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("inheritability");
                }
                if ((desiredAccessRights & ~((983055/*MemoryMappedFileRights.FullControl*/ | 16777216/*MemoryMappedFileRights.AccessSystemSecurity*/))) !== 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("desiredAccessRights");
                }
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenCore$1(mapName, inheritability, desiredAccessRights, false);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$1(handle);
            }
            static /*MemoryMappedFile */ CreateFromFile(/*string*/ path)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$4(path, 3/*FileMode.Open*/, null, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            static /*MemoryMappedFile */ CreateFromFile$1(/*string*/ path, /*FileMode*/ mode)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$4(path, mode, null, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            static /*MemoryMappedFile */ CreateFromFile$2(/*string*/ path, /*FileMode*/ mode, /*string?*/ mapName)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$4(path, mode, mapName, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            static /*MemoryMappedFile */ CreateFromFile$3(/*string*/ path, /*FileMode*/ mode, /*string?*/ mapName, /*long*/ capacity)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$4(path, mode, mapName, capacity, 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            static /*MemoryMappedFile */ CreateFromFile$4(/*string*/ path, /*FileMode*/ mode, /*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(path, "path");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.ValidateCreateFile(mapName, capacity, access);
                if (mode === 6/*FileMode.Append*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFAppendModeNotAllowed, "mode");
                }
                if (mode === 5/*FileMode.Truncate*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFTruncateModeNotAllowed, "mode");
                }
                /*bool*/ let existed = (() =>
                {
                    if (mode === 3/*FileMode.Open*/)
                    {
                        return true;
                    }
                    if (mode === 1/*FileMode.CreateNew*/)
                    {
                        return false;
                    }
                    return $.$spc.System.IO.File.Exists(path);
                })();
                /*SafeFileHandle*/ let fileHandle = $.$spc.System.IO.File.OpenHandle(path, mode, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GetFileAccess(access), 1/*FileShare.Read*/, 0/*FileOptions.None*/, 0n);
                /*long*/ let fileSize = 0n;
                if (!((mode === 1/*FileMode.CreateNew*/) || (mode === 2/*FileMode.Create*/)))
                {
                    try
                    {
                        fileSize = $.$spc.System.IO.RandomAccess.GetLength(fileHandle);
                    }
                    catch($e)
                    {
                        fileHandle.Dispose();
                        throw $e;
                    }
                }
                if (capacity === 0n && fileSize === 0n)
                {
                    $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CleanupFile(fileHandle, existed, path);
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sim.System.SR.Argument_EmptyFile);
                }
                if (capacity === BigInt(0/*DefaultSize*/))
                {
                    capacity = fileSize;
                }
                /*SafeMemoryMappedFileHandle?*/ let handle;
                try
                {
                    handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(fileHandle, mapName, 0/*HandleInheritability.None*/, access, 0/*MemoryMappedFileOptions.None*/, capacity, fileSize);
                }
                catch($e)
                {
                    $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CleanupFile(fileHandle, existed, path);
                    throw $e;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(handle !== null, "handle != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(!handle.IsInvalid, "!handle.IsInvalid");
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$2(handle, fileHandle, false);
            }
            static /*MemoryMappedFile */ CreateFromFile$5(/*SafeFileHandle*/ fileHandle, /*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*HandleInheritability*/ inheritability, /*bool*/ leaveOpen)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(fileHandle, "fileHandle");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.ValidateCreateFile(mapName, capacity, access);
                /*long*/ let fileSize = $.$spc.System.IO.RandomAccess.GetLength(fileHandle);
                if (capacity === 0n && fileSize === 0n)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sim.System.SR.Argument_EmptyFile);
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("inheritability");
                }
                if (capacity === BigInt(0/*DefaultSize*/))
                {
                    capacity = fileSize;
                }
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(fileHandle, mapName, inheritability, access, 0/*MemoryMappedFileOptions.None*/, capacity, fileSize);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$2(handle, fileHandle, leaveOpen);
            }
            static /*MemoryMappedFile */ CreateFromFile$6(/*FileStream*/ fileStream, /*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*HandleInheritability*/ inheritability, /*bool*/ leaveOpen)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(fileStream, "fileStream");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.ValidateCreateFile(mapName, capacity, access);
                /*long*/ let fileSize = fileStream.Length;
                if (capacity === 0n && fileSize === 0n)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sim.System.SR.Argument_EmptyFile);
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("inheritability");
                }
                fileStream.Flush();
                if (capacity === BigInt(0/*DefaultSize*/))
                {
                    capacity = fileSize;
                }
                /*SafeFileHandle*/ let fileHandle = fileStream.SafeFileHandle;
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(fileHandle, mapName, inheritability, access, 0/*MemoryMappedFileOptions.None*/, capacity, fileSize);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$2(handle, fileHandle, leaveOpen);
            }
            static /*MemoryMappedFile */ CreateNew(/*string?*/ mapName, /*long*/ capacity)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNew$2(mapName, capacity, 0/*MemoryMappedFileAccess.ReadWrite*/, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ CreateNew$1(/*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNew$2(mapName, capacity, access, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ CreateNew$2(/*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*HandleInheritability*/ inheritability)
            {
                if ($.$spc.System.String.op_Inequality(mapName, null) && mapName.length === 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sim.System.SR.Argument_MapNameEmptyString);
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int64, capacity, "capacity");
                if ($.$spc.System.IntPtr.Size === 4 && capacity > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("capacity", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("access");
                }
                if (access === 2/*MemoryMappedFileAccess.Write*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFWriteAccessNotAllowed, "access");
                }
                if ((options & ~((67108864/*MemoryMappedFileOptions.DelayAllocatePages*/))) !== 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("options");
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("inheritability");
                }
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(null, mapName, inheritability, access, options, capacity, BigInt(-1));
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$1(handle);
            }
            static /*MemoryMappedFile */ CreateOrOpen(/*string*/ mapName, /*long*/ capacity)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateOrOpen$2(mapName, capacity, 0/*MemoryMappedFileAccess.ReadWrite*/, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ CreateOrOpen$1(/*string*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateOrOpen$2(mapName, capacity, access, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ CreateOrOpen$2(/*string*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*HandleInheritability*/ inheritability)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(mapName, "mapName");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int64, capacity, "capacity");
                if ($.$spc.System.IntPtr.Size === 4 && capacity > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("capacity", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("access");
                }
                if ((options & ~((67108864/*MemoryMappedFileOptions.DelayAllocatePages*/))) !== 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("options");
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("inheritability");
                }
                /*SafeMemoryMappedFileHandle*/ let handle;
                if (access === 2/*MemoryMappedFileAccess.Write*/)
                {
                    handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenCore(mapName, inheritability, access, true);
                }
                else 
                {
                    handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateOrOpenCore(mapName, inheritability, access, options, capacity);
                }
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$1(handle);
            }
            /*MemoryMappedViewStream */ CreateViewStream()
            {
                return this.CreateViewStream$2(0n, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            /*MemoryMappedViewStream */ CreateViewStream$1(/*long*/ offset, /*long*/ size)
            {
                return this.CreateViewStream$2(offset, size, 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            /*MemoryMappedViewStream */ CreateViewStream$2(/*long*/ offset, /*long*/ size, /*MemoryMappedFileAccess*/ access)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int64, offset, "offset");
                if (size < 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("size", $.$sim.System.SR.ArgumentOutOfRange_PositiveOrDefaultSizeRequired);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("access");
                }
                if ($.$spc.System.IntPtr.Size === 4 && size > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("size", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                /*MemoryMappedView*/ let view = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.CreateView(this._handle, access, offset, size);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedViewStream().$ctor$8(view);
            }
            /*MemoryMappedViewAccessor */ CreateViewAccessor()
            {
                return this.CreateViewAccessor$2(0n, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            /*MemoryMappedViewAccessor */ CreateViewAccessor$1(/*long*/ offset, /*long*/ size)
            {
                return this.CreateViewAccessor$2(offset, size, 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            /*MemoryMappedViewAccessor */ CreateViewAccessor$2(/*long*/ offset, /*long*/ size, /*MemoryMappedFileAccess*/ access)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int64, offset, "offset");
                if (size < 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("size", $.$sim.System.SR.ArgumentOutOfRange_PositiveOrDefaultSizeRequired);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("access");
                }
                if ($.$spc.System.IntPtr.Size === 4 && size > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("size", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                /*MemoryMappedView*/ let view = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.CreateView(this._handle, access, offset, size);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedViewAccessor().$ctor$4(view);
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    if (!this._handle.IsClosed)
                    {
                        this._handle.Dispose();
                    }
                }
                finally
                {
                    {
                        if (!this._leaveOpen)
                        {
                            this._fileHandle?.Dispose();
                        }
                    }
                }
            }
            /*SafeMemoryMappedFileHandle */ get SafeMemoryMappedFileHandle()
            {
                return this._handle;
            }
            static /*FileAccess */ GetFileAccess(/*MemoryMappedFileAccess*/ access)
            {
                switch(access)
                {
                    case 1/*MemoryMappedFileAccess.Read*/:
                    case 4/*MemoryMappedFileAccess.ReadExecute*/:
                    return 1/*FileAccess.Read*/;
                    case 0/*MemoryMappedFileAccess.ReadWrite*/:
                    case 3/*MemoryMappedFileAccess.CopyOnWrite*/:
                    case 5/*MemoryMappedFileAccess.ReadWriteExecute*/:
                    return 3/*FileAccess.ReadWrite*/;
                    default:
                    $.$spc.System.Diagnostics.Debug.Assert$1(access === 2/*MemoryMappedFileAccess.Write*/, "access == MemoryMappedFileAccess.Write");
                    return 2/*FileAccess.Write*/;
                }
            }
            static /*void */ CleanupFile(/*SafeFileHandle*/ fileHandle, /*bool*/ existed, /*string*/ path)
            {
                fileHandle.Dispose();
                if (!existed)
                {
                    $.$spc.System.IO.File.Delete(path);
                }
            }
            static /*void */ ValidateCreateFile(/*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                if ($.$spc.System.String.op_Inequality(mapName, null) && mapName.length === 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sim.System.SR.Argument_MapNameEmptyString);
                }
                if (capacity < 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("capacity", $.$sim.System.SR.ArgumentOutOfRange_PositiveOrDefaultCapacityRequired);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("access");
                }
                if (access === 2/*MemoryMappedFileAccess.Write*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFWriteAccessNotAllowed, "access");
                }
            }
            static /*void */ VerifyMemoryMappedFileAccess(/*MemoryMappedFileAccess*/ access, /*long*/ capacity, /*SafeFileHandle?*/ fileHandle, /*long*/ fileSize, /*out bool*/ isRegularFile)
            {
                isRegularFile.$v = !(fileHandle === null) && (fileSize > 0n || IsRegularFile(fileHandle));
                if (isRegularFile.$v)
                {
                    if (access === 1/*MemoryMappedFileAccess.Read*/ && capacity > fileSize)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$sim.System.SR.Argument_ReadAccessWithLargeCapacity);
                    }
                    if (fileSize > capacity)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("capacity", $.$sim.System.SR.ArgumentOutOfRange_CapacityGEFileSizeRequired);
                    }
                    if (access === 2/*MemoryMappedFileAccess.Write*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFWriteAccessNotAllowed, "access");
                    }
                }
                /*static bool*/  function IsRegularFile(/*SafeFileHandle*/ fileHandle)
                {
                    /*Interop.Sys.FileStatus*/ let status;
                    $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.FStat(fileHandle, $.$ref(() => status, ($v) => status = $v, $.$sim.Interop.Sys.FileStatus)), null, false);
                    return (status.Mode & 32768/*Interop.Sys.FileTypes.S_IFREG*/) !== 0;
                }
            }
            static /*SafeMemoryMappedFileHandle */ CreateCore(/*SafeFileHandle?*/ fileHandle, /*string?*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*long*/ capacity, /*long*/ fileSize)
            {
                /*bool*/ let isRegularFile;
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.VerifyMemoryMappedFileAccess(access, capacity, fileHandle, fileSize, $.$ref(() => isRegularFile, ($v) => isRegularFile = $v, $.$spc.System.Boolean));
                if ($.$spc.System.String.op_Inequality(mapName, null))
                {
                    throw $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNamedMapsNotSupportedException();
                }
                /*bool*/ let ownsFileStream = false;
                if (fileHandle !== null)
                {
                    if (isRegularFile && fileSize >= 0n && capacity > fileSize)
                    {
                        try
                        {
                            $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.FTruncate(fileHandle, capacity), null, false);
                        }
                        catch(exc)
                        {
                            throw new $.$spc.System.IO.IOException().$ctor$12(exc.Message, exc);
                        }
                    }
                }
                else 
                {
                    /*Interop.Sys.MemoryMappedProtections*/ let protections = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(access, false);
                    if ((protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) !== 0 && capacity > 0n)
                    {
                        ownsFileStream = true;
                        fileHandle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObject(protections, capacity, inheritability);
                    }
                }
                return new $.$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedFileHandle().$ctor$5(fileHandle, ownsFileStream, inheritability, access, options, capacity);
            }
            static /*SafeMemoryMappedFileHandle */ CreateOrOpenCore(/*string*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*long*/ capacity)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(null, mapName, inheritability, access, options, capacity, BigInt(-1));
            }
            static /*SafeMemoryMappedFileHandle */ OpenCore(/*string*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*bool*/ createOrOpen)
            {
                throw $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNamedMapsNotSupportedException();
            }
            static /*SafeMemoryMappedFileHandle */ OpenCore$1(/*string*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileRights*/ rights, /*bool*/ createOrOpen)
            {
                throw $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNamedMapsNotSupportedException();
            }
            static /*PlatformNotSupportedException */ CreateNamedMapsNotSupportedException()
            {
                return new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$sim.System.SR.PlatformNotSupported_NamedMaps);
            }
            static /*FileAccess */ TranslateProtectionsToFileAccess(/*Interop.Sys.MemoryMappedProtections*/ protections)
            {
                return (protections & (1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/)) !== 0 ? 3/*FileAccess.ReadWrite*/ : (protections & (2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/)) !== 0 ? 2/*FileAccess.Write*/ : 1/*FileAccess.Read*/;
            }
            static /*SafeFileHandle */ CreateSharedBackingObject(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                return $.$sim.Interop.Sys.IsMemfdSupported ? $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObjectUsingMemoryMemfdCreate(protections, capacity, inheritability) : $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObjectUsingMemoryShmOpen(protections, capacity, inheritability) ?? $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObjectUsingFile(protections, capacity, inheritability);
            }
            static /*SafeFileHandle? */ CreateSharedBackingObjectUsingMemoryShmOpen(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                /*Interop.Sys.OpenFlags*/ let flags = (protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) !== 0 ? 2/*Interop.Sys.OpenFlags.O_RDWR*/ : 0/*Interop.Sys.OpenFlags.O_RDONLY*/;
                flags |= 32/*Interop.Sys.OpenFlags.O_CREAT*/ | 64/*Interop.Sys.OpenFlags.O_EXCL*/;
                /*var*/ let perms = 0/*UnixFileMode.None*/;
                if ((protections & 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/) !== 0)
                {
                    perms |= 256/*UnixFileMode.UserRead*/;
                }
                if ((protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) !== 0)
                {
                    perms |= 128/*UnixFileMode.UserWrite*/;
                }
                if ((protections & 4/*Interop.Sys.MemoryMappedProtections.PROT_EXEC*/) !== 0)
                {
                    perms |= 64/*UnixFileMode.UserExecute*/;
                }
                /*string*/ let mapName;
                /*SafeFileHandle*/ let fd;
                do
                {
                    mapName = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GenerateMapName();
                    fd = $.$sim.Interop.Sys.ShmOpen(mapName, flags, perms);
                    if (fd.IsInvalid)
                    {
                        /*Interop.ErrorInfo*/ let errorInfo = $.$sim.Interop.Sys.GetLastErrorInfo();
                        fd.Dispose();
                        if (errorInfo.Error === 65597/*Interop.Error.ENOTSUP*/)
                        {
                            return null;
                        }
                        else if (errorInfo.Error === 65573/*Interop.Error.ENAMETOOLONG*/)
                        {
                            $.$spc.System.Diagnostics.Debug.Fail(`shm_open failed with ENAMETOOLONG for ${$.$spc.System.Text.Encoding.UTF8.GetByteCount$1(mapName)} byte long name.`);
                            return null;
                        }
                        else if (errorInfo.Error !== 65556/*Interop.Error.EEXIST*/)
                        {
                            throw $.$sim.Interop.GetExceptionForIoErrno(errorInfo.Clone(), null, false);
                        }
                    }
                }
                while(fd.IsInvalid);
                try
                {
                    $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.ShmUnlink(mapName), null, false);
                    $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.FTruncate(fd, capacity), null, false);
                    if (inheritability === 1/*HandleInheritability.Inheritable*/ && $.$sim.Interop.Sys.Fcntl.SetFD(fd, 0) === -1)
                    {
                        throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                    }
                    return fd;
                }
                catch($e)
                {
                    fd.Dispose();
                    throw $e;
                }
            }
            static /*string */ GenerateMapName()
            {
                /*int*/ let MaxNameLength = 30;
                /*string*/ let NamePrefix = "/dotnet_";
                return $.$spc.System.String.Create$8($.$spc.System.Int32, MaxNameLength, 0, new ($.$spc.System.Buffers.SpanAction$$$($.$spc.System.Char, $.$spc.System.Int32))().$ctor(this,  (/*span*/ span, /*state*/ state) =>
                {
                    /*Span<char>*/ let guid = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 32, null);
                    /*int*/ let charsWritten;
                    $.$spc.System.Guid.NewGuid().TryFormat(guid, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), $.$spc.System.String.op_Implicit("N"));
                    $.$spc.System.Diagnostics.Debug.Assert$1(charsWritten === 32, "charsWritten == 32");
                    $.$spc.System.String.CopyTo$1.call(NamePrefix, span);
                    guid.Slice$1(0, ((MaxNameLength - NamePrefix.length) | 0)).CopyTo(span.Slice(NamePrefix.length));
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Text.Encoding.UTF8.GetByteCount$5($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(span)) <= MaxNameLength, "Encoding.UTF8.GetByteCount(span) <= MaxNameLength");
                }, {"r":65537,"p":[{"n":"span","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"state","p":655361}],"n":"","d":1288436,"h":0,"f":1048578}));
            }
            static /*SafeFileHandle */ CreateSharedBackingObjectUsingMemoryMemfdCreate(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                /*int*/ let isReadonly = ((protections & 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/) !== 0 && (protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) === 0) ? 1 : 0;
                /*SafeFileHandle*/ let fd = $.$sim.Interop.Sys.MemfdCreate($.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GenerateMapName(), isReadonly);
                if (fd.IsInvalid)
                {
                    /*Interop.ErrorInfo*/ let errorInfo = $.$sim.Interop.Sys.GetLastErrorInfo();
                    fd.Dispose();
                    throw $.$sim.Interop.GetExceptionForIoErrno(errorInfo.Clone(), null, false);
                }
                try
                {
                    $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.FTruncate(fd, capacity), null, false);
                    if (inheritability === 1/*HandleInheritability.Inheritable*/ && $.$sim.Interop.Sys.Fcntl.SetFD(fd, 0) === -1)
                    {
                        throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                    }
                    return fd;
                }
                catch($e)
                {
                    fd.Dispose();
                    throw $e;
                }
            }
            static /*SafeFileHandle */ CreateSharedBackingObjectUsingFile(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                /*string*/ let path = $.$spc.System.IO.Path.Combine($.$spc.System.IO.Path.GetTempPath(), $.$spc.System.Guid.NewGuid().ToString$1("N"));
                /*FileShare*/ let share = inheritability === 0/*HandleInheritability.None*/ ? 3/*FileShare.ReadWrite*/ : 3/*FileShare.ReadWrite*/ | 16/*FileShare.Inheritable*/;
                /*SafeFileHandle*/ let fileHandle = $.$spc.System.IO.File.OpenHandle(path, 1/*FileMode.CreateNew*/, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.TranslateProtectionsToFileAccess(protections), share, 0, 0n);
                try
                {
                    $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.Unlink(path), null, false);
                    $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.FTruncate(fileHandle, capacity), path, false);
                }
                catch($e)
                {
                    fileHandle.Dispose();
                    throw $e;
                }
                return fileHandle;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1288436;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1157364,"g":{"r":0,"d":0,"h":137440241908,"f":1},"n":"SafeMemoryMappedFileHandle","d":1288436,"h":133145274612,"f":1}],"m":[{"r":1288436,"p":[{"n":"mapName","p":1310721}],"n":"OpenExisting","d":1288436,"h":30066059508,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1288436,"p":[{"n":"mapName","p":1310721},{"n":"desiredAccessRights","p":1485044}],"n":"OpenExisting","o":"@$1","d":1288436,"h":34361026804,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1288436,"p":[{"n":"mapName","p":1310721},{"n":"desiredAccessRights","p":1485044},{"n":"inheritability","p":60620801}],"n":"OpenExisting","o":"@$2","d":1288436,"h":38655994100,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1288436,"p":[{"n":"path","p":1310721}],"n":"CreateFromFile","d":1288436,"h":42950961396,"f":33},{"r":1288436,"p":[{"n":"path","p":1310721},{"n":"mode","p":60030977}],"n":"CreateFromFile","o":"@$1","d":1288436,"h":47245928692,"f":33},{"r":1288436,"p":[{"n":"path","p":1310721},{"n":"mode","p":60030977},{"n":"mapName","p":1310721}],"n":"CreateFromFile","o":"@$2","d":1288436,"h":51540895988,"f":33},{"r":1288436,"p":[{"n":"path","p":1310721},{"n":"mode","p":60030977},{"n":"mapName","p":1310721},{"n":"capacity","p":917505}],"n":"CreateFromFile","o":"@$3","d":1288436,"h":55835863284,"f":33},{"r":1288436,"p":[{"n":"path","p":1310721},{"n":"mode","p":60030977},{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1353972}],"n":"CreateFromFile","o":"@$4","d":1288436,"h":60130830580,"f":33},{"r":1288436,"p":[{"n":"fileHandle","p":7143425},{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1353972},{"n":"inheritability","p":60620801},{"n":"leaveOpen","p":262145}],"n":"CreateFromFile","o":"@$5","d":1288436,"h":64425797876,"f":33},{"r":1288436,"p":[{"n":"fileStream","p":60358657},{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1353972},{"n":"inheritability","p":60620801},{"n":"leaveOpen","p":262145}],"n":"CreateFromFile","o":"@$6","d":1288436,"h":68720765172,"f":33},{"r":1288436,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505}],"n":"CreateNew","d":1288436,"h":73015732468,"f":33},{"r":1288436,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1353972}],"n":"CreateNew","o":"@$1","d":1288436,"h":77310699764,"f":33},{"r":1288436,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1353972},{"n":"options","p":1419508},{"n":"inheritability","p":60620801}],"n":"CreateNew","o":"@$2","d":1288436,"h":81605667060,"f":33},{"r":1288436,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505}],"n":"CreateOrOpen","d":1288436,"h":85900634356,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1288436,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1353972}],"n":"CreateOrOpen","o":"@$1","d":1288436,"h":90195601652,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1288436,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1353972},{"n":"options","p":1419508},{"n":"inheritability","p":60620801}],"n":"CreateOrOpen","o":"@$2","d":1288436,"h":94490568948,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1681652,"n":"CreateViewStream","d":1288436,"h":98785536244,"f":1},{"r":1681652,"p":[{"n":"offset","p":917505},{"n":"size","p":917505}],"n":"CreateViewStream","o":"@$1","d":1288436,"h":103080503540,"f":1},{"r":1681652,"p":[{"n":"offset","p":917505},{"n":"size","p":917505},{"n":"access","p":1353972}],"n":"CreateViewStream","o":"@$2","d":1288436,"h":107375470836,"f":1},{"r":1616116,"n":"CreateViewAccessor","d":1288436,"h":111670438132,"f":1},{"r":1616116,"p":[{"n":"offset","p":917505},{"n":"size","p":917505}],"n":"CreateViewAccessor","o":"@$1","d":1288436,"h":115965405428,"f":1},{"r":1616116,"p":[{"n":"offset","p":917505},{"n":"size","p":917505},{"n":"access","p":1353972}],"n":"CreateViewAccessor","o":"@$2","d":1288436,"h":120260372724,"f":1},{"r":65537,"n":"Dispose","d":1288436,"h":124555340020,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1288436,"h":128850307316,"f":132},{"r":59768833,"p":[{"n":"access","p":1353972}],"n":"GetFileAccess","d":1288436,"h":141735209204,"f":40},{"r":65537,"p":[{"n":"fileHandle","p":7143425},{"n":"existed","p":262145},{"n":"path","p":1310721}],"n":"CleanupFile","d":1288436,"h":146030176500,"f":34},{"r":65537,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1353972}],"n":"ValidateCreateFile","d":1288436,"h":150325143796,"f":34},{"r":65537,"p":[{"n":"access","p":1353972},{"n":"capacity","p":917505},{"n":"fileHandle","p":7143425},{"n":"fileSize","p":917505},{"n":"isRegularFile","p":262145,"f":2}],"n":"VerifyMemoryMappedFileAccess","d":1288436,"h":154620111092,"f":34},{"r":1157364,"p":[{"n":"fileHandle","p":7143425},{"n":"mapName","p":1310721},{"n":"inheritability","p":60620801},{"n":"access","p":1353972},{"n":"options","p":1419508},{"n":"capacity","p":917505},{"n":"fileSize","p":917505}],"n":"CreateCore","d":1288436,"h":158915078388,"f":34},{"r":1157364,"p":[{"n":"mapName","p":1310721},{"n":"inheritability","p":60620801},{"n":"access","p":1353972},{"n":"options","p":1419508},{"n":"capacity","p":917505}],"n":"CreateOrOpenCore","d":1288436,"h":163210045684,"f":34},{"r":1157364,"p":[{"n":"mapName","p":1310721},{"n":"inheritability","p":60620801},{"n":"access","p":1353972},{"n":"createOrOpen","p":262145}],"n":"OpenCore","d":1288436,"h":167505012980,"f":34},{"r":1157364,"p":[{"n":"mapName","p":1310721},{"n":"inheritability","p":60620801},{"n":"rights","p":1485044},{"n":"createOrOpen","p":262145}],"n":"OpenCore","o":"@$1","d":1288436,"h":171799980276,"f":34},{"r":72220673,"n":"CreateNamedMapsNotSupportedException","d":1288436,"h":176094947572,"f":34},{"r":59768833,"p":[{"n":"protections","p":829684}],"n":"TranslateProtectionsToFileAccess","d":1288436,"h":180389914868,"f":34},{"r":7143425,"p":[{"n":"protections","p":829684},{"n":"capacity","p":917505},{"n":"inheritability","p":60620801}],"n":"CreateSharedBackingObject","d":1288436,"h":184684882164,"f":34},{"r":7143425,"p":[{"n":"protections","p":829684},{"n":"capacity","p":917505},{"n":"inheritability","p":60620801}],"n":"CreateSharedBackingObjectUsingMemoryShmOpen","d":1288436,"h":188979849460,"f":34},{"r":1310721,"n":"GenerateMapName","d":1288436,"h":193274816756,"f":34},{"r":7143425,"p":[{"n":"protections","p":829684},{"n":"capacity","p":917505},{"n":"inheritability","p":60620801}],"n":"CreateSharedBackingObjectUsingMemoryMemfdCreate","d":1288436,"h":197569784052,"f":34},{"r":7143425,"p":[{"n":"protections","p":829684},{"n":"capacity","p":917505},{"n":"inheritability","p":60620801}],"n":"CreateSharedBackingObjectUsingFile","d":1288436,"h":201864751348,"f":34}],"l":[{"t":1157364,"n":"_handle","d":1288436,"h":4296255732,"f":2},{"t":262145,"n":"_leaveOpen","d":1288436,"h":8591223028,"f":2},{"t":7143425,"n":"_fileHandle","d":1288436,"h":12886190324,"f":2},{"t":655361,"n":"DefaultSize","d":1288436,"h":17181157620,"f":40}],"c":[{"p":[{"n":"handle","p":1157364}],"n":".ctor","o":"$ctor$1","d":1288436,"h":21476124916,"f":2},{"p":[{"n":"handle","p":1157364},{"n":"fileHandle","p":7143425},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$2","d":1288436,"h":25771092212,"f":2}],"i":[57540609],"h":1288436}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFile`; }
        });
        
        $asm.$str("$sim.System.IO.MemoryMappedFiles.MemoryMappedFileAccess", ($self) => class MemoryMappedFileAccess extends $.$spc.System.Enum
        {
            static ReadWrite = 0;
            static Read = 1;
            static Write = 2;
            static CopyOnWrite = 3;
            static ReadExecute = 4;
            static ReadWriteExecute = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ReadWrite": 0n,
                    "Read": 1n,
                    "Write": 2n,
                    "CopyOnWrite": 3n,
                    "ReadExecute": 4n,
                    "ReadWriteExecute": 5n
                };
            }
            static $h = 1353972;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1353972,"n":"ReadWrite","d":1353972,"h":4296321268,"f":33},{"t":1353972,"n":"Read","d":1353972,"h":8591288564,"f":33},{"t":1353972,"n":"Write","d":1353972,"h":12886255860,"f":33},{"t":1353972,"n":"CopyOnWrite","d":1353972,"h":17181223156,"f":33},{"t":1353972,"n":"ReadExecute","d":1353972,"h":21476190452,"f":33},{"t":1353972,"n":"ReadWriteExecute","d":1353972,"h":25771157748,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1353972,"h":30066125044,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1353972}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFileAccess`; }
        });
        
        $asm.$str("$sim.System.IO.MemoryMappedFiles.MemoryMappedFileOptions", ($self) => class MemoryMappedFileOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static DelayAllocatePages = 67108864;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "DelayAllocatePages": 67108864n
                };
            }
            static $h = 1419508;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1419508,"n":"None","d":1419508,"h":4296386804,"f":33},{"t":1419508,"n":"DelayAllocatePages","d":1419508,"h":8591354100,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1419508,"h":12886321396,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1419508,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFileOptions`; }
        });
        
        $asm.$str("$sim.System.IO.MemoryMappedFiles.MemoryMappedFileRights", ($self) => class MemoryMappedFileRights extends $.$spc.System.Enum
        {
            static CopyOnWrite = 1;
            static Write = 2;
            static Read = 4;
            static Execute = 8;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static ReadWrite = 6;
            static ReadExecute = 12;
            static ReadWriteExecute = 14;
            static FullControl = 983055;
            static AccessSystemSecurity = 16777216;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "CopyOnWrite": 1n,
                    "Write": 2n,
                    "Read": 4n,
                    "Execute": 8n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "ReadWrite": 6n,
                    "ReadExecute": 12n,
                    "ReadWriteExecute": 14n,
                    "FullControl": 983055n,
                    "AccessSystemSecurity": 16777216n
                };
            }
            static $h = 1485044;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1485044,"n":"CopyOnWrite","d":1485044,"h":4296452340,"f":33},{"t":1485044,"n":"Write","d":1485044,"h":8591419636,"f":33},{"t":1485044,"n":"Read","d":1485044,"h":12886386932,"f":33},{"t":1485044,"n":"Execute","d":1485044,"h":17181354228,"f":33},{"t":1485044,"n":"Delete","d":1485044,"h":21476321524,"f":33},{"t":1485044,"n":"ReadPermissions","d":1485044,"h":25771288820,"f":33},{"t":1485044,"n":"ChangePermissions","d":1485044,"h":30066256116,"f":33},{"t":1485044,"n":"TakeOwnership","d":1485044,"h":34361223412,"f":33},{"t":1485044,"n":"ReadWrite","d":1485044,"h":38656190708,"f":33},{"t":1485044,"n":"ReadExecute","d":1485044,"h":42951158004,"f":33},{"t":1485044,"n":"ReadWriteExecute","d":1485044,"h":47246125300,"f":33},{"t":1485044,"n":"FullControl","d":1485044,"h":51541092596,"f":33},{"t":1485044,"n":"AccessSystemSecurity","d":1485044,"h":55836059892,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1485044,"h":60131027188,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1485044,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFileRights`; }
        });
        
        $asm.$cls("$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedFileHandle", ($self) => class SafeMemoryMappedFileHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(true);
                {
                }
                return this;
            }
            /*SafeFileHandle?*/ _fileStreamHandle = null;
            /*bool*/ _ownsFileHandle = false;
            /*HandleInheritability*/ _inheritability = 0;
            /*MemoryMappedFileAccess*/ _access = 0;
            /*MemoryMappedFileOptions*/ _options = 0;
            /*long*/ _capacity = 0n;
            $ctor$5(/*SafeFileHandle?*/ fileHandle, /*bool*/ ownsFileHandle, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*long*/ capacity)
            {
                super.$ctor$3(true);
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!ownsFileHandle || fileHandle !== null, "We can only own a FileStream we're actually given.");
                    this._ownsFileHandle = ownsFileHandle;
                    this._inheritability = inheritability;
                    this._access = access;
                    this._options = options;
                    this._capacity = capacity;
                    /*IntPtr*/ let handlePtr;
                    if (fileHandle !== null)
                    {
                        /*bool*/ let ignored = false;
                        fileHandle.DangerousAddRef($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => ignored, ($v) => ignored = $v, null));
                        this._fileStreamHandle = fileHandle;
                        handlePtr = fileHandle.DangerousGetHandle();
                    }
                    else 
                    {
                        handlePtr = $.$spc.System.IntPtr.MaxValue;
                    }
                    this.SetHandle(handlePtr);
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                if (this._fileStreamHandle !== null)
                {
                    this.SetHandle((-1));
                    if (this._ownsFileHandle)
                    {
                        this._fileStreamHandle.Dispose();
                    }
                    this._fileStreamHandle.DangerousRelease();
                    this._fileStreamHandle = null;
                }
                return true;
            }
            /*bool */ get IsInvalid()
            {
                return $.$cast(this.handle, $.$spc.System.Int64) <= 0n;
            }
            static $h = 1157364;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"p":[{"p":262145,"g":{"r":0,"d":0,"h":47245797620,"f":32769},"n":"IsInvalid","d":1157364,"h":42950830324,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":1157364,"h":38655863028,"f":32772}],"l":[{"t":7143425,"n":"_fileStreamHandle","d":1157364,"h":8591091956,"f":8},{"t":262145,"n":"_ownsFileHandle","d":1157364,"h":12886059252,"f":8},{"t":60620801,"n":"_inheritability","d":1157364,"h":17181026548,"f":8},{"t":1353972,"n":"_access","d":1157364,"h":21475993844,"f":8},{"t":1419508,"n":"_options","d":1157364,"h":25770961140,"f":8},{"t":917505,"n":"_capacity","d":1157364,"h":30065928436,"f":8}],"c":[{"n":".ctor","o":"$ctor$4","d":1157364,"h":4296124660,"f":1},{"p":[{"n":"fileHandle","p":7143425},{"n":"ownsFileHandle","p":262145},{"n":"inheritability","p":60620801},{"n":"access","p":1353972},{"n":"options","p":1419508},{"n":"capacity","p":917505}],"n":".ctor","o":"$ctor$5","d":1157364,"h":34360895732,"f":8}],"i":[57540609],"h":1157364}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeMemoryMappedFileHandle`; }
        });
        
        $asm.$cls("$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle", ($self) => class SafeMemoryMappedViewHandle extends $.$spc.System.Runtime.InteropServices.SafeBuffer
        {
            $ctor$5()
            {
                super.$ctor$4(true);
                {
                }
                return this;
            }
            $ctor$6(/*IntPtr*/ handle, /*bool*/ ownsHandle)
            {
                super.$ctor$4(ownsHandle);
                {
                    super.SetHandle(handle);
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                /*IntPtr*/ let addr = this.handle;
                this.handle = new $.$spc.System.IntPtr().$ctor$2(-1);
                return $.$sim.Interop.Sys.MUnmap(addr, super.ByteLength) === 0;
            }
            static $h = 1222900;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":109510657,"m":[{"r":262145,"n":"ReleaseHandle","d":1222900,"h":12886124788,"f":32772}],"c":[{"n":".ctor","o":"$ctor$5","d":1222900,"h":4296190196,"f":1},{"p":[{"n":"handle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$6","d":1222900,"h":8591157492,"f":8}],"i":[57540609],"h":1222900}; }
            static get $b() { return $.$spc.System.Runtime.InteropServices.SafeBuffer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle`; }
        });
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedViewAccessor", ($self) => class MemoryMappedViewAccessor extends $.$spc.System.IO.UnmanagedMemoryAccessor
        {
            /*MemoryMappedView*/ _view = null;
            $ctor$4(/*MemoryMappedView*/ view)
            {
                super.$ctor$1();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(view !== null, "view is null");
                    this._view = view;
                    this.Initialize(this._view.ViewHandle, this._view.PointerOffset, this._view.Size, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GetFileAccess(this._view.Access));
                }
                return this;
            }
            /*SafeMemoryMappedViewHandle */ get SafeMemoryMappedViewHandle()
            {
                return this._view.ViewHandle;
            }
            /*long */ get PointerOffset()
            {
                return this._view.PointerOffset;
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                try
                {
                    if (disposing && !this._view.IsClosed && this.CanWrite)
                    {
                        this.Flush();
                    }
                }
                finally
                {
                    {
                        try
                        {
                            this._view.Dispose();
                        }
                        finally
                        {
                            {
                                super.Dispose(disposing);
                            }
                        }
                    }
                }
            }
            /*void */ Flush()
            {
                if (!this.IsOpen)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15("MemoryMappedViewAccessor", $.$sim.System.SR.ObjectDisposed_ViewAccessorClosed);
                }
                this._view.Flush($.$cast(this.Capacity, $.$spc.System.UIntPtr));
            }
            static $h = 1616116;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":63373313,"p":[{"p":1222900,"g":{"r":0,"d":0,"h":17181485300,"f":1},"n":"SafeMemoryMappedViewHandle","d":1616116,"h":12886518004,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":25771419892,"f":1},"n":"PointerOffset","d":1616116,"h":21476452596,"f":1}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":1616116,"h":30066387188,"f":32772},{"r":65537,"n":"Flush","d":1616116,"h":34361354484,"f":1}],"l":[{"t":1550580,"n":"_view","d":1616116,"h":4296583412,"f":2}],"c":[{"p":[{"n":"view","p":1550580}],"n":".ctor","o":"$ctor$4","d":1616116,"h":8591550708,"f":8}],"i":[57540609],"h":1616116}; }
            static get $b() { return $.$spc.System.IO.UnmanagedMemoryAccessor; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedViewAccessor`; }
        });
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedViewStream", ($self) => class MemoryMappedViewStream extends $.$spc.System.IO.UnmanagedMemoryStream
        {
            /*MemoryMappedView*/ _view = null;
            $ctor$8(/*MemoryMappedView*/ view)
            {
                super.$ctor$3();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(view !== null, "view is null");
                    this._view = view;
                    this.Initialize(this._view.ViewHandle, this._view.PointerOffset, this._view.Size, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GetFileAccess(this._view.Access));
                }
                return this;
            }
            /*SafeMemoryMappedViewHandle */ get SafeMemoryMappedViewHandle()
            {
                return this._view.ViewHandle;
            }
            /*long */ get PointerOffset()
            {
                return this._view.PointerOffset;
            }
            /*void */ SetLength(/*long*/ value)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int64, value, "value");
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sim.System.SR.NotSupported_MMViewStreamsFixedLength);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    if (disposing && !this._view.IsClosed && this.CanWrite)
                    {
                        this.Flush();
                    }
                }
                finally
                {
                    {
                        try
                        {
                            this._view.Dispose();
                        }
                        finally
                        {
                            {
                                super.Dispose$1(disposing);
                            }
                        }
                    }
                }
            }
            /*void */ Flush()
            {
                if (!this.CanSeek)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15(null, $.$sim.System.SR.ObjectDisposed_StreamIsClosed);
                }
                this._view.Flush($.$cast(this.Capacity, $.$spc.System.UIntPtr));
            }
            static $h = 1681652;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":63438849,"p":[{"p":1222900,"g":{"r":0,"d":0,"h":17181550836,"f":1},"n":"SafeMemoryMappedViewHandle","d":1681652,"h":12886583540,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":25771485428,"f":1},"n":"PointerOffset","d":1681652,"h":21476518132,"f":1}],"m":[{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1681652,"h":30066452724,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1681652,"h":34361420020,"f":32772},{"r":65537,"n":"Flush","d":1681652,"h":38656387316,"f":32769}],"l":[{"t":1550580,"n":"_view","d":1681652,"h":4296648948,"f":2}],"c":[{"p":[{"n":"view","p":1550580}],"n":".ctor","o":"$ctor$8","d":1681652,"h":8591616244,"f":8}],"i":[57540609,56950785],"h":1681652}; }
            static get $b() { return $.$spc.System.IO.UnmanagedMemoryStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedViewStream`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread"))