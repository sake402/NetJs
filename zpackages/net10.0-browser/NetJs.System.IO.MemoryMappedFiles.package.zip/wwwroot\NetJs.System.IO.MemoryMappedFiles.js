
(function ($global, $, $spc, $sc, $sdt, $sm, $spu, $st, $stt, $sr, $scc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.MemoryMappedFiles", 
    {"h":54402,"f":"System.IO.MemoryMappedFiles","v":"1.0.35.0","a":[{"t":90374145,"c":4385341441},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.MemoryMappedFiles","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.MemoryMappedFiles","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sim.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sim.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.IO.MemoryMappedFiles", $.$sim.System.SR.$type.Assembly);
                    $.$sim.System.SR.s_resourceManager = temp;
                }
                return $.$sim.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sim.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sim.System.SR.resourceCulture = value;
            }
            static /*string */ get IO_FileNotFound()
            {
                return "Unable to find the specified file.";
            }
            static /*string */ get IO_FileNotFound_FileName()
            {
                return "Could not find file '{0}'.";
            }
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find file '{0}'.", arg1);
            }
            static /*string */ get IO_AlreadyExists_Name()
            {
                return "Cannot create '{0}' because a file or directory with the same name already exists.";
            }
            static /*string */ FormatIO_AlreadyExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Cannot create '{0}' because a file or directory with the same name already exists.", arg1);
            }
            static /*string */ get IO_FileExists_Name()
            {
                return "The file '{0}' already exists.";
            }
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The file '{0}' already exists.", arg1);
            }
            static /*string */ get IO_SharingViolation_File()
            {
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                return "The process cannot access the file because it is being used by another process.";
            }
            static /*string */ get IO_PathNotFound_Path()
            {
                return "Could not find a part of the path '{0}'.";
            }
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find a part of the path '{0}'.", arg1);
            }
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                return "Could not find a part of the path.";
            }
            static /*string */ get IO_PathTooLong()
            {
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                return "Access to the path '{0}' is denied.";
            }
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Access to the path '{0}' is denied.", arg1);
            }
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                return "Access to the path is denied.";
            }
            static /*string */ get Argument_MapNameEmptyString()
            {
                return "Map name cannot be an empty string.";
            }
            static /*string */ get Argument_EmptyFile()
            {
                return "A positive capacity must be specified for a Memory Mapped File backed by an empty file.";
            }
            static /*string */ get Argument_NewMMFWriteAccessNotAllowed()
            {
                return "MemoryMappedFileAccess.Write is not permitted when creating new memory mapped files. Use MemoryMappedFileAccess.ReadWrite instead.";
            }
            static /*string */ get Argument_ReadAccessWithLargeCapacity()
            {
                return "When specifying MemoryMappedFileAccess.Read access, the capacity must not be larger than the file size.";
            }
            static /*string */ get Argument_NewMMFAppendModeNotAllowed()
            {
                return "FileMode.Append is not permitted when creating new memory mapped files. Instead, use MemoryMappedFileView to ensure write-only access within a specified region.";
            }
            static /*string */ get Argument_NewMMFTruncateModeNotAllowed()
            {
                return "FileMode.Truncate is not permitted when creating new memory mapped files.";
            }
            static /*string */ get ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed()
            {
                return "The capacity cannot be greater than the size of the system's logical address space.";
            }
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                return "Specified file length was too large for the file system.";
            }
            static /*string */ get ArgumentOutOfRange_PositiveOrDefaultCapacityRequired()
            {
                return "The capacity must be greater than or equal to 0. 0 represents the size of the file being mapped.";
            }
            static /*string */ get ArgumentOutOfRange_PositiveOrDefaultSizeRequired()
            {
                return "The size must be greater than or equal to 0. If 0 is specified, the view extends from the specified offset to the end of the file mapping.";
            }
            static /*string */ get ArgumentOutOfRange_CapacityGEFileSizeRequired()
            {
                return "The capacity may not be smaller than the file size.";
            }
            static /*string */ get IO_NotEnoughMemory()
            {
                return "Not enough memory to map view.";
            }
            static /*string */ get InvalidOperation_CantCreateFileMapping()
            {
                return "Cannot create file mapping.";
            }
            static /*string */ get NotSupported_MMViewStreamsFixedLength()
            {
                return "MemoryMappedViewStreams are fixed length.";
            }
            static /*string */ get NotSupported_UnreadableStream()
            {
                return "Stream does not support reading.";
            }
            static /*string */ get NotSupported_UnwritableStream()
            {
                return "Stream does not support writing.";
            }
            static /*string */ get ObjectDisposed_ViewAccessorClosed()
            {
                return "Cannot access a closed accessor.";
            }
            static /*string */ get ObjectDisposed_StreamIsClosed()
            {
                return "Cannot access a closed Stream.";
            }
            static /*string */ get PlatformNotSupported_NamedMaps()
            {
                return "Named maps are not supported.";
            }
            static /*string */ get IO_PathTooLong_Path()
            {
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            static /*string */ get PlatformNotSupported_MemoryMappedFiles()
            {
                return "System.IO.MemoryMappedFiles is not supported on this platform.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sim.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sim.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sim.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sim.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sim.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sim.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sim.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1823874;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1823874}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.Nop", ($self) => class Nop extends $.$spc.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1758338;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":1758338,"h":4296725634,"f":1}],"h":1758338}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.Nop`; }
        });
        
        $asm.$cls("$sim.Interop", ($self) => class Interop
        {
            static $_Libraries;
            static get Libraries()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_Libraries ??= $asm.$ncls("$sim.Interop.Libraries", ($self) => class Libraries
                {
                    /*string*/ static libc = null;
                    /*string*/ static SystemNative = null;
                    /*string*/ static NetSecurityNative = null;
                    /*string*/ static CryptoNative = null;
                    /*string*/ static CompressionNative = null;
                    /*string*/ static GlobalizationNative = null;
                    /*string*/ static IOPortsNative = null;
                    /*string*/ static HostPolicy = null;
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.libc = "libc";
                        }
                        {
                            this.SystemNative = "libSystem.Native";
                        }
                        {
                            this.NetSecurityNative = "libSystem.Net.Security.Native";
                        }
                        {
                            this.CryptoNative = "libSystem.Security.Cryptography.Native.OpenSsl";
                        }
                        {
                            this.CompressionNative = "libSystem.IO.Compression.Native";
                        }
                        {
                            this.GlobalizationNative = "libSystem.Globalization.Native";
                        }
                        {
                            this.IOPortsNative = "libSystem.IO.Ports.Native";
                        }
                        {
                            this.HostPolicy = "libhostpolicy";
                        }
                    }
                    static $h = 316546;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"libc","d":316546,"h":4295283842,"f":40},{"t":1310721,"n":"SystemNative","d":316546,"h":8590251138,"f":40},{"t":1310721,"n":"NetSecurityNative","d":316546,"h":12885218434,"f":40},{"t":1310721,"n":"CryptoNative","d":316546,"h":17180185730,"f":40},{"t":1310721,"n":"CompressionNative","d":316546,"h":21475153026,"f":40},{"t":1310721,"n":"GlobalizationNative","d":316546,"h":25770120322,"f":40},{"t":1310721,"n":"IOPortsNative","d":316546,"h":30065087618,"f":40},{"t":1310721,"n":"HostPolicy","d":316546,"h":34360054914,"f":40}],"d":119938,"h":316546}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Libraries`; }
                }, $cls, ($v) => $cls.$_Libraries = $v);
            }
            static $_Error;
            static get Error()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_Error ??= $asm.$nstr("$sim.Interop.Error", ($self) => class Error extends $.$spc.System.Enum
                {
                    static SUCCESS = 0;
                    static E2BIG = 65537;
                    static EACCES = 65538;
                    static EADDRINUSE = 65539;
                    static EADDRNOTAVAIL = 65540;
                    static EAFNOSUPPORT = 65541;
                    static EAGAIN = 65542;
                    static EALREADY = 65543;
                    static EBADF = 65544;
                    static EBADMSG = 65545;
                    static EBUSY = 65546;
                    static ECANCELED = 65547;
                    static ECHILD = 65548;
                    static ECONNABORTED = 65549;
                    static ECONNREFUSED = 65550;
                    static ECONNRESET = 65551;
                    static EDEADLK = 65552;
                    static EDESTADDRREQ = 65553;
                    static EDOM = 65554;
                    static EDQUOT = 65555;
                    static EEXIST = 65556;
                    static EFAULT = 65557;
                    static EFBIG = 65558;
                    static EHOSTUNREACH = 65559;
                    static EIDRM = 65560;
                    static EILSEQ = 65561;
                    static EINPROGRESS = 65562;
                    static EINTR = 65563;
                    static EINVAL = 65564;
                    static EIO = 65565;
                    static EISCONN = 65566;
                    static EISDIR = 65567;
                    static ELOOP = 65568;
                    static EMFILE = 65569;
                    static EMLINK = 65570;
                    static EMSGSIZE = 65571;
                    static EMULTIHOP = 65572;
                    static ENAMETOOLONG = 65573;
                    static ENETDOWN = 65574;
                    static ENETRESET = 65575;
                    static ENETUNREACH = 65576;
                    static ENFILE = 65577;
                    static ENOBUFS = 65578;
                    static ENODEV = 65580;
                    static ENOENT = 65581;
                    static ENOEXEC = 65582;
                    static ENOLCK = 65583;
                    static ENOLINK = 65584;
                    static ENOMEM = 65585;
                    static ENOMSG = 65586;
                    static ENOPROTOOPT = 65587;
                    static ENOSPC = 65588;
                    static ENOSYS = 65591;
                    static ENOTCONN = 65592;
                    static ENOTDIR = 65593;
                    static ENOTEMPTY = 65594;
                    static ENOTRECOVERABLE = 65595;
                    static ENOTSOCK = 65596;
                    static ENOTSUP = 65597;
                    static ENOTTY = 65598;
                    static ENXIO = 65599;
                    static EOVERFLOW = 65600;
                    static EOWNERDEAD = 65601;
                    static EPERM = 65602;
                    static EPIPE = 65603;
                    static EPROTO = 65604;
                    static EPROTONOSUPPORT = 65605;
                    static EPROTOTYPE = 65606;
                    static ERANGE = 65607;
                    static EROFS = 65608;
                    static ESPIPE = 65609;
                    static ESRCH = 65610;
                    static ESTALE = 65611;
                    static ETIMEDOUT = 65613;
                    static ETXTBSY = 65614;
                    static EXDEV = 65615;
                    static ESOCKTNOSUPPORT = 65630;
                    static EPFNOSUPPORT = 65632;
                    static ESHUTDOWN = 65644;
                    static EHOSTDOWN = 65648;
                    static ENODATA = 65649;
                    static EHOSTNOTFOUND = 131073;
                    static ESOCKETERROR = 131074;
                    static EOPNOTSUPP = 65597;
                    static EWOULDBLOCK = 65542;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "SUCCESS": 0n,
                            "E2BIG": 65537n,
                            "EACCES": 65538n,
                            "EADDRINUSE": 65539n,
                            "EADDRNOTAVAIL": 65540n,
                            "EAFNOSUPPORT": 65541n,
                            "EAGAIN": 65542n,
                            "EALREADY": 65543n,
                            "EBADF": 65544n,
                            "EBADMSG": 65545n,
                            "EBUSY": 65546n,
                            "ECANCELED": 65547n,
                            "ECHILD": 65548n,
                            "ECONNABORTED": 65549n,
                            "ECONNREFUSED": 65550n,
                            "ECONNRESET": 65551n,
                            "EDEADLK": 65552n,
                            "EDESTADDRREQ": 65553n,
                            "EDOM": 65554n,
                            "EDQUOT": 65555n,
                            "EEXIST": 65556n,
                            "EFAULT": 65557n,
                            "EFBIG": 65558n,
                            "EHOSTUNREACH": 65559n,
                            "EIDRM": 65560n,
                            "EILSEQ": 65561n,
                            "EINPROGRESS": 65562n,
                            "EINTR": 65563n,
                            "EINVAL": 65564n,
                            "EIO": 65565n,
                            "EISCONN": 65566n,
                            "EISDIR": 65567n,
                            "ELOOP": 65568n,
                            "EMFILE": 65569n,
                            "EMLINK": 65570n,
                            "EMSGSIZE": 65571n,
                            "EMULTIHOP": 65572n,
                            "ENAMETOOLONG": 65573n,
                            "ENETDOWN": 65574n,
                            "ENETRESET": 65575n,
                            "ENETUNREACH": 65576n,
                            "ENFILE": 65577n,
                            "ENOBUFS": 65578n,
                            "ENODEV": 65580n,
                            "ENOENT": 65581n,
                            "ENOEXEC": 65582n,
                            "ENOLCK": 65583n,
                            "ENOLINK": 65584n,
                            "ENOMEM": 65585n,
                            "ENOMSG": 65586n,
                            "ENOPROTOOPT": 65587n,
                            "ENOSPC": 65588n,
                            "ENOSYS": 65591n,
                            "ENOTCONN": 65592n,
                            "ENOTDIR": 65593n,
                            "ENOTEMPTY": 65594n,
                            "ENOTRECOVERABLE": 65595n,
                            "ENOTSOCK": 65596n,
                            "ENOTSUP": 65597n,
                            "ENOTTY": 65598n,
                            "ENXIO": 65599n,
                            "EOVERFLOW": 65600n,
                            "EOWNERDEAD": 65601n,
                            "EPERM": 65602n,
                            "EPIPE": 65603n,
                            "EPROTO": 65604n,
                            "EPROTONOSUPPORT": 65605n,
                            "EPROTOTYPE": 65606n,
                            "ERANGE": 65607n,
                            "EROFS": 65608n,
                            "ESPIPE": 65609n,
                            "ESRCH": 65610n,
                            "ESTALE": 65611n,
                            "ETIMEDOUT": 65613n,
                            "ETXTBSY": 65614n,
                            "EXDEV": 65615n,
                            "ESOCKTNOSUPPORT": 65630n,
                            "EPFNOSUPPORT": 65632n,
                            "ESHUTDOWN": 65644n,
                            "EHOSTDOWN": 65648n,
                            "ENODATA": 65649n,
                            "EHOSTNOTFOUND": 131073n,
                            "ESOCKETERROR": 131074n,
                            "EOPNOTSUPP": 65597n,
                            "EWOULDBLOCK": 65542n
                        };
                    }
                    static $h = 185474;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":185474,"n":"SUCCESS","d":185474,"h":4295152770,"f":33},{"t":185474,"n":"E2BIG","d":185474,"h":8590120066,"f":33},{"t":185474,"n":"EACCES","d":185474,"h":12885087362,"f":33},{"t":185474,"n":"EADDRINUSE","d":185474,"h":17180054658,"f":33},{"t":185474,"n":"EADDRNOTAVAIL","d":185474,"h":21475021954,"f":33},{"t":185474,"n":"EAFNOSUPPORT","d":185474,"h":25769989250,"f":33},{"t":185474,"n":"EAGAIN","d":185474,"h":30064956546,"f":33},{"t":185474,"n":"EALREADY","d":185474,"h":34359923842,"f":33},{"t":185474,"n":"EBADF","d":185474,"h":38654891138,"f":33},{"t":185474,"n":"EBADMSG","d":185474,"h":42949858434,"f":33},{"t":185474,"n":"EBUSY","d":185474,"h":47244825730,"f":33},{"t":185474,"n":"ECANCELED","d":185474,"h":51539793026,"f":33},{"t":185474,"n":"ECHILD","d":185474,"h":55834760322,"f":33},{"t":185474,"n":"ECONNABORTED","d":185474,"h":60129727618,"f":33},{"t":185474,"n":"ECONNREFUSED","d":185474,"h":64424694914,"f":33},{"t":185474,"n":"ECONNRESET","d":185474,"h":68719662210,"f":33},{"t":185474,"n":"EDEADLK","d":185474,"h":73014629506,"f":33},{"t":185474,"n":"EDESTADDRREQ","d":185474,"h":77309596802,"f":33},{"t":185474,"n":"EDOM","d":185474,"h":81604564098,"f":33},{"t":185474,"n":"EDQUOT","d":185474,"h":85899531394,"f":33},{"t":185474,"n":"EEXIST","d":185474,"h":90194498690,"f":33},{"t":185474,"n":"EFAULT","d":185474,"h":94489465986,"f":33},{"t":185474,"n":"EFBIG","d":185474,"h":98784433282,"f":33},{"t":185474,"n":"EHOSTUNREACH","d":185474,"h":103079400578,"f":33},{"t":185474,"n":"EIDRM","d":185474,"h":107374367874,"f":33},{"t":185474,"n":"EILSEQ","d":185474,"h":111669335170,"f":33},{"t":185474,"n":"EINPROGRESS","d":185474,"h":115964302466,"f":33},{"t":185474,"n":"EINTR","d":185474,"h":120259269762,"f":33},{"t":185474,"n":"EINVAL","d":185474,"h":124554237058,"f":33},{"t":185474,"n":"EIO","d":185474,"h":128849204354,"f":33},{"t":185474,"n":"EISCONN","d":185474,"h":133144171650,"f":33},{"t":185474,"n":"EISDIR","d":185474,"h":137439138946,"f":33},{"t":185474,"n":"ELOOP","d":185474,"h":141734106242,"f":33},{"t":185474,"n":"EMFILE","d":185474,"h":146029073538,"f":33},{"t":185474,"n":"EMLINK","d":185474,"h":150324040834,"f":33},{"t":185474,"n":"EMSGSIZE","d":185474,"h":154619008130,"f":33},{"t":185474,"n":"EMULTIHOP","d":185474,"h":158913975426,"f":33},{"t":185474,"n":"ENAMETOOLONG","d":185474,"h":163208942722,"f":33},{"t":185474,"n":"ENETDOWN","d":185474,"h":167503910018,"f":33},{"t":185474,"n":"ENETRESET","d":185474,"h":171798877314,"f":33},{"t":185474,"n":"ENETUNREACH","d":185474,"h":176093844610,"f":33},{"t":185474,"n":"ENFILE","d":185474,"h":180388811906,"f":33},{"t":185474,"n":"ENOBUFS","d":185474,"h":184683779202,"f":33},{"t":185474,"n":"ENODEV","d":185474,"h":188978746498,"f":33},{"t":185474,"n":"ENOENT","d":185474,"h":193273713794,"f":33},{"t":185474,"n":"ENOEXEC","d":185474,"h":197568681090,"f":33},{"t":185474,"n":"ENOLCK","d":185474,"h":201863648386,"f":33},{"t":185474,"n":"ENOLINK","d":185474,"h":206158615682,"f":33},{"t":185474,"n":"ENOMEM","d":185474,"h":210453582978,"f":33},{"t":185474,"n":"ENOMSG","d":185474,"h":214748550274,"f":33},{"t":185474,"n":"ENOPROTOOPT","d":185474,"h":219043517570,"f":33},{"t":185474,"n":"ENOSPC","d":185474,"h":223338484866,"f":33},{"t":185474,"n":"ENOSYS","d":185474,"h":227633452162,"f":33},{"t":185474,"n":"ENOTCONN","d":185474,"h":231928419458,"f":33},{"t":185474,"n":"ENOTDIR","d":185474,"h":236223386754,"f":33},{"t":185474,"n":"ENOTEMPTY","d":185474,"h":240518354050,"f":33},{"t":185474,"n":"ENOTRECOVERABLE","d":185474,"h":244813321346,"f":33},{"t":185474,"n":"ENOTSOCK","d":185474,"h":249108288642,"f":33},{"t":185474,"n":"ENOTSUP","d":185474,"h":253403255938,"f":33},{"t":185474,"n":"ENOTTY","d":185474,"h":257698223234,"f":33},{"t":185474,"n":"ENXIO","d":185474,"h":261993190530,"f":33},{"t":185474,"n":"EOVERFLOW","d":185474,"h":266288157826,"f":33},{"t":185474,"n":"EOWNERDEAD","d":185474,"h":270583125122,"f":33},{"t":185474,"n":"EPERM","d":185474,"h":274878092418,"f":33},{"t":185474,"n":"EPIPE","d":185474,"h":279173059714,"f":33},{"t":185474,"n":"EPROTO","d":185474,"h":283468027010,"f":33},{"t":185474,"n":"EPROTONOSUPPORT","d":185474,"h":287762994306,"f":33},{"t":185474,"n":"EPROTOTYPE","d":185474,"h":292057961602,"f":33},{"t":185474,"n":"ERANGE","d":185474,"h":296352928898,"f":33},{"t":185474,"n":"EROFS","d":185474,"h":300647896194,"f":33},{"t":185474,"n":"ESPIPE","d":185474,"h":304942863490,"f":33},{"t":185474,"n":"ESRCH","d":185474,"h":309237830786,"f":33},{"t":185474,"n":"ESTALE","d":185474,"h":313532798082,"f":33},{"t":185474,"n":"ETIMEDOUT","d":185474,"h":317827765378,"f":33},{"t":185474,"n":"ETXTBSY","d":185474,"h":322122732674,"f":33},{"t":185474,"n":"EXDEV","d":185474,"h":326417699970,"f":33},{"t":185474,"n":"ESOCKTNOSUPPORT","d":185474,"h":330712667266,"f":33},{"t":185474,"n":"EPFNOSUPPORT","d":185474,"h":335007634562,"f":33},{"t":185474,"n":"ESHUTDOWN","d":185474,"h":339302601858,"f":33},{"t":185474,"n":"EHOSTDOWN","d":185474,"h":343597569154,"f":33},{"t":185474,"n":"ENODATA","d":185474,"h":347892536450,"f":33},{"t":185474,"n":"EHOSTNOTFOUND","d":185474,"h":352187503746,"f":33},{"t":185474,"n":"ESOCKETERROR","d":185474,"h":356482471042,"f":33},{"t":185474,"n":"EOPNOTSUPP","d":185474,"h":360777438338,"f":33},{"t":185474,"n":"EWOULDBLOCK","d":185474,"h":365072405634,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":185474,"h":369367372930,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":119938,"h":185474}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `Interop.Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            static $_ErrorInfo;
            static get ErrorInfo()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_ErrorInfo ??= $asm.$nstr("$sim.Interop.ErrorInfo", ($self) => class ErrorInfo extends $.$spc.System.ValueType
                {
                    /*Error*/  get _error() { return this.$getField(0, $.$sim.Interop.Error); }
                    /*Error*/  set _error(value) { this.$setField(0, $.$sim.Interop.Error, value); }
                    /*int*/  get _rawErrno() { return this.$getField(4, $.$spc.System.Int32); }
                    /*int*/  set _rawErrno(value) { this.$setField(4, $.$spc.System.Int32, value); }
                    $ctor$2(/*int*/ errno)
                    {
                        super.$ctor$1();
                        {
                            this._error = $.$sim.Interop.Sys.ConvertErrorPlatformToPal(errno);
                            this._rawErrno = errno;
                        }
                        return this;
                    }
                    $ctor$3(/*Error*/ error)
                    {
                        super.$ctor$1();
                        {
                            this._error = error;
                            this._rawErrno = -1;
                        }
                        return this;
                    }
                    /*Error */ get Error()
                    {
                        return this._error;
                    }
                    /*int */ get RawErrno()
                    {
                        return this._rawErrno === -1 ? (this._rawErrno = $.$sim.Interop.Sys.ConvertErrorPalToPlatform(this._error)) : this._rawErrno;
                    }
                    /*string */ GetErrorMessage()
                    {
                        return $.$sim.Interop.Sys.StrError(this.RawErrno);
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return `RawErrno: ${this.RawErrno} Error: ${this.Error} GetErrorMessage: ${this.GetErrorMessage()}`;
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$sim.Interop.ErrorInfo.ToString.apply(this, arguments); }
                    //default value type constructor
                    $ctor$4()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._error = this._error;
                        copy._rawErrno = this._rawErrno;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._error = 0;
                        this._rawErrno = 0;
                    }
                    static $h = 251010;
                    static $z = 8;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":185474,"g":{"r":0,"d":0,"h":25770054786,"f":8},"n":"Error","d":251010,"h":21475087490,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":34359989378,"f":8},"n":"RawErrno","d":251010,"h":30065022082,"f":8}],"m":[{"r":1310721,"n":"GetErrorMessage","d":251010,"h":38654956674,"f":8},{"r":1310721,"n":"ToString","d":251010,"h":42949923970,"f":32769}],"l":[{"t":185474,"n":"_error","d":251010,"h":4295218306,"f":2},{"t":655361,"n":"_rawErrno","d":251010,"h":8590185602,"f":2}],"c":[{"p":[{"n":"errno","p":655361}],"n":".ctor","o":"$ctor$2","d":251010,"h":12885152898,"f":8},{"p":[{"n":"error","p":185474}],"n":".ctor","o":"$ctor$3","d":251010,"h":17180120194,"f":8},{"n":".ctor","o":"$ctor$4","d":251010,"h":47244891266,"f":1}],"d":119938,"h":251010}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Interop.ErrorInfo`; }
                }, $cls, ($v) => $cls.$_ErrorInfo = $v);
            }
            static $_Sys;
            static get Sys()
            {
                let $cls = $.$sim.Interop;
                return $cls.$_Sys ??= $asm.$ncls("$sim.Interop.Sys", ($self) => class Sys
                {
                    static /*Error */ GetLastError()
                    {
                        return $.$sim.Interop.Sys.ConvertErrorPlatformToPal($.$spc.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    static /*ErrorInfo */ GetLastErrorInfo()
                    {
                        return new $.$sim.Interop.ErrorInfo().$ctor$2($.$spc.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    static /*string */ StrError(/*int*/ platformErrno)
                    {
                        /*int*/ let MaxBufferLength = 1024;
                        /*byte**/ let buffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.Byte, MaxBufferLength, null);
                        /*byte**/ let message = $.$sim.Interop.Sys.StrErrorR(platformErrno, buffer, MaxBufferLength);
                        if (message === null)
                        {
                            message = buffer;
                        }
                        return $.$spc.System.Runtime.InteropServices.Marshal.PtrToStringUTF8($.$cast(message, $.$spc.System.IntPtr));
                    }
                    static $_Fcntl;
                    static get Fcntl()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_Fcntl ??= $asm.$ncls("$sim.Interop.Sys.Fcntl", ($self) => class Fcntl
                        {
                            static /*int */ DangerousSetIsNonBlocking(/*IntPtr*/ fd, /*int*/ isNonBlocking)
                            {
                                return -1;
                            }
                            static /*int */ SetIsNonBlocking(/*SafeHandle*/ fd, /*int*/ isNonBlocking)
                            {
                                return -1;
                            }
                            static /*int */ GetIsNonBlocking(/*SafeHandle*/ fd, /*out bool*/ isNonBlocking)
                            {
                                isNonBlocking.$v = false;
                                return -1;
                            }
                            static /*int */ SetFD(/*SafeHandle*/ fd, /*int*/ flags)
                            {
                                return -1;
                            }
                            static /*int */ GetFD(/*SafeHandle*/ fd)
                            {
                                return -1;
                            }
                            static /*int */ GetFD$1(/*IntPtr*/ fd)
                            {
                                return -1;
                            }
                            static $h = 447618;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"fd","p":786433},{"n":"isNonBlocking","p":655361}],"n":"DangerousSetIsNonBlocking","d":447618,"h":4295414914,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlSetIsNonBlocking","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109576193},{"n":"isNonBlocking","p":655361}],"n":"SetIsNonBlocking","d":447618,"h":8590382210,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlSetIsNonBlocking","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109576193},{"n":"isNonBlocking","p":262145,"f":2,"a":[{"t":105709569,"c":8695644161,"a":[{"v":2,"t":110886913}]}]}],"n":"GetIsNonBlocking","d":447618,"h":12885349506,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlGetIsNonBlocking","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109576193},{"n":"flags","p":655361}],"n":"SetFD","d":447618,"h":17180316802,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlSetFD","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109576193}],"n":"GetFD","d":447618,"h":21475284098,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlGetFD","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":786433}],"n":"GetFD","o":"@$1","d":447618,"h":25770251394,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FcntlGetFD","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]}],"d":382082,"h":447618}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `Interop.Sys.Fcntl`; }
                        }, $cls, ($v) => $cls.$_Fcntl = $v);
                    }
                    static $_MemoryMappedProtections;
                    static get MemoryMappedProtections()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryMappedProtections ??= $asm.$nstr("$sim.Interop.Sys.MemoryMappedProtections", ($self) => class MemoryMappedProtections extends $.$spc.System.Enum
                        {
                            static PROT_NONE = 0;
                            static PROT_READ = 1;
                            static PROT_WRITE = 2;
                            static PROT_EXEC = 4;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "PROT_NONE": 0n,
                                    "PROT_READ": 1n,
                                    "PROT_WRITE": 2n,
                                    "PROT_EXEC": 4n
                                };
                            }
                            static $h = 840834;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":840834,"n":"PROT_NONE","d":840834,"h":4295808130,"f":33},{"t":840834,"n":"PROT_READ","d":840834,"h":8590775426,"f":33},{"t":840834,"n":"PROT_WRITE","d":840834,"h":12885742722,"f":33},{"t":840834,"n":"PROT_EXEC","d":840834,"h":17180710018,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":840834,"h":21475677314,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":382082,"h":840834,"a":[{"t":47644673,"c":4342611969}]}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryMappedProtections`; }
                        }, $cls, ($v) => $cls.$_MemoryMappedProtections = $v);
                    }
                    static $_MemoryMappedFlags;
                    static get MemoryMappedFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryMappedFlags ??= $asm.$nstr("$sim.Interop.Sys.MemoryMappedFlags", ($self) => class MemoryMappedFlags extends $.$spc.System.Enum
                        {
                            static MAP_SHARED = 1;
                            static MAP_PRIVATE = 2;
                            static MAP_ANONYMOUS = 16;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "MAP_SHARED": 1n,
                                    "MAP_PRIVATE": 2n,
                                    "MAP_ANONYMOUS": 16n
                                };
                            }
                            static $h = 775298;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":775298,"n":"MAP_SHARED","d":775298,"h":4295742594,"f":33},{"t":775298,"n":"MAP_PRIVATE","d":775298,"h":8590709890,"f":33},{"t":775298,"n":"MAP_ANONYMOUS","d":775298,"h":12885677186,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":775298,"h":17180644482,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":382082,"h":775298,"a":[{"t":47644673,"c":4342611969}]}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryMappedFlags`; }
                        }, $cls, ($v) => $cls.$_MemoryMappedFlags = $v);
                    }
                    static $_MemoryMappedSyncFlags;
                    static get MemoryMappedSyncFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryMappedSyncFlags ??= $asm.$nstr("$sim.Interop.Sys.MemoryMappedSyncFlags", ($self) => class MemoryMappedSyncFlags extends $.$spc.System.Enum
                        {
                            static MS_ASYNC = 1;
                            static MS_SYNC = 2;
                            static MS_INVALIDATE = 16;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "MS_ASYNC": 1n,
                                    "MS_SYNC": 2n,
                                    "MS_INVALIDATE": 16n
                                };
                            }
                            static $h = 906370;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":906370,"n":"MS_ASYNC","d":906370,"h":4295873666,"f":33},{"t":906370,"n":"MS_SYNC","d":906370,"h":8590840962,"f":33},{"t":906370,"n":"MS_INVALIDATE","d":906370,"h":12885808258,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":906370,"h":17180775554,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":382082,"h":906370,"a":[{"t":47644673,"c":4342611969}]}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryMappedSyncFlags`; }
                        }, $cls, ($v) => $cls.$_MemoryMappedSyncFlags = $v);
                    }
                    static $_OpenFlags;
                    static get OpenFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_OpenFlags ??= $asm.$nstr("$sim.Interop.Sys.OpenFlags", ($self) => class OpenFlags extends $.$spc.System.Enum
                        {
                            static O_RDONLY = 0;
                            static O_WRONLY = 1;
                            static O_RDWR = 2;
                            static O_CLOEXEC = 16;
                            static O_CREAT = 32;
                            static O_EXCL = 64;
                            static O_TRUNC = 128;
                            static O_SYNC = 256;
                            static O_NOFOLLOW = 512;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "O_RDONLY": 0n,
                                    "O_WRONLY": 1n,
                                    "O_RDWR": 2n,
                                    "O_CLOEXEC": 16n,
                                    "O_CREAT": 32n,
                                    "O_EXCL": 64n,
                                    "O_TRUNC": 128n,
                                    "O_SYNC": 256n,
                                    "O_NOFOLLOW": 512n
                                };
                            }
                            static $h = 971906;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":971906,"n":"O_RDONLY","d":971906,"h":4295939202,"f":33},{"t":971906,"n":"O_WRONLY","d":971906,"h":8590906498,"f":33},{"t":971906,"n":"O_RDWR","d":971906,"h":12885873794,"f":33},{"t":971906,"n":"O_CLOEXEC","d":971906,"h":17180841090,"f":33},{"t":971906,"n":"O_CREAT","d":971906,"h":21475808386,"f":33},{"t":971906,"n":"O_EXCL","d":971906,"h":25770775682,"f":33},{"t":971906,"n":"O_TRUNC","d":971906,"h":30065742978,"f":33},{"t":971906,"n":"O_SYNC","d":971906,"h":34360710274,"f":33},{"t":971906,"n":"O_NOFOLLOW","d":971906,"h":38655677570,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":971906,"h":42950644866,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":382082,"h":971906,"a":[{"t":47644673,"c":4342611969}]}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.OpenFlags`; }
                        }, $cls, ($v) => $cls.$_OpenFlags = $v);
                    }
                    static $_FileStatus;
                    static get FileStatus()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_FileStatus ??= $asm.$nstr("$sim.Interop.Sys.FileStatus", ($self) => class FileStatus extends $.$spc.System.ValueType
                        {
                            /*FileStatusFlags*/  get Flags() { return this.$getField(0, $.$sim.Interop.Sys.FileStatusFlags); }
                            /*FileStatusFlags*/  set Flags(value) { this.$setField(0, $.$sim.Interop.Sys.FileStatusFlags, value); }
                            /*int*/  get Mode() { return this.$getField(4, $.$spc.System.Int32); }
                            /*int*/  set Mode(value) { this.$setField(4, $.$spc.System.Int32, value); }
                            /*uint*/  get Uid() { return this.$getField(8, $.$spc.System.UInt32); }
                            /*uint*/  set Uid(value) { this.$setField(8, $.$spc.System.UInt32, value); }
                            /*uint*/  get Gid() { return this.$getField(12, $.$spc.System.UInt32); }
                            /*uint*/  set Gid(value) { this.$setField(12, $.$spc.System.UInt32, value); }
                            /*long*/  get Size() { return this.$getField(16, $.$spc.System.Int64); }
                            /*long*/  set Size(value) { this.$setField(16, $.$spc.System.Int64, value); }
                            /*long*/  get ATime() { return this.$getField(24, $.$spc.System.Int64); }
                            /*long*/  set ATime(value) { this.$setField(24, $.$spc.System.Int64, value); }
                            /*long*/  get ATimeNsec() { return this.$getField(32, $.$spc.System.Int64); }
                            /*long*/  set ATimeNsec(value) { this.$setField(32, $.$spc.System.Int64, value); }
                            /*long*/  get MTime() { return this.$getField(40, $.$spc.System.Int64); }
                            /*long*/  set MTime(value) { this.$setField(40, $.$spc.System.Int64, value); }
                            /*long*/  get MTimeNsec() { return this.$getField(48, $.$spc.System.Int64); }
                            /*long*/  set MTimeNsec(value) { this.$setField(48, $.$spc.System.Int64, value); }
                            /*long*/  get CTime() { return this.$getField(56, $.$spc.System.Int64); }
                            /*long*/  set CTime(value) { this.$setField(56, $.$spc.System.Int64, value); }
                            /*long*/  get CTimeNsec() { return this.$getField(64, $.$spc.System.Int64); }
                            /*long*/  set CTimeNsec(value) { this.$setField(64, $.$spc.System.Int64, value); }
                            /*long*/  get BirthTime() { return this.$getField(72, $.$spc.System.Int64); }
                            /*long*/  set BirthTime(value) { this.$setField(72, $.$spc.System.Int64, value); }
                            /*long*/  get BirthTimeNsec() { return this.$getField(80, $.$spc.System.Int64); }
                            /*long*/  set BirthTimeNsec(value) { this.$setField(80, $.$spc.System.Int64, value); }
                            /*long*/  get Dev() { return this.$getField(88, $.$spc.System.Int64); }
                            /*long*/  set Dev(value) { this.$setField(88, $.$spc.System.Int64, value); }
                            /*long*/  get RDev() { return this.$getField(96, $.$spc.System.Int64); }
                            /*long*/  set RDev(value) { this.$setField(96, $.$spc.System.Int64, value); }
                            /*long*/  get Ino() { return this.$getField(104, $.$spc.System.Int64); }
                            /*long*/  set Ino(value) { this.$setField(104, $.$spc.System.Int64, value); }
                            /*uint*/  get UserFlags() { return this.$getField(112, $.$spc.System.UInt32); }
                            /*uint*/  set UserFlags(value) { this.$setField(112, $.$spc.System.UInt32, value); }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy.Flags = this.Flags;
                                copy.Mode = this.Mode;
                                copy.Uid = this.Uid;
                                copy.Gid = this.Gid;
                                copy.Size = this.Size;
                                copy.ATime = this.ATime;
                                copy.ATimeNsec = this.ATimeNsec;
                                copy.MTime = this.MTime;
                                copy.MTimeNsec = this.MTimeNsec;
                                copy.CTime = this.CTime;
                                copy.CTimeNsec = this.CTimeNsec;
                                copy.BirthTime = this.BirthTime;
                                copy.BirthTimeNsec = this.BirthTimeNsec;
                                copy.Dev = this.Dev;
                                copy.RDev = this.RDev;
                                copy.Ino = this.Ino;
                                copy.UserFlags = this.UserFlags;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this.Flags = 0;
                                this.Mode = 0;
                                this.Uid = 0;
                                this.Gid = 0;
                                this.Size = 0n;
                                this.ATime = 0n;
                                this.ATimeNsec = 0n;
                                this.MTime = 0n;
                                this.MTimeNsec = 0n;
                                this.CTime = 0n;
                                this.CTimeNsec = 0n;
                                this.BirthTime = 0n;
                                this.BirthTimeNsec = 0n;
                                this.Dev = 0n;
                                this.RDev = 0n;
                                this.Ino = 0n;
                                this.UserFlags = 0;
                            }
                            static $h = 513154;
                            static $z = 116;
                            static $f = 0b10100010000001010000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":578690,"n":"Flags","d":513154,"h":4295480450,"f":8},{"t":655361,"n":"Mode","d":513154,"h":8590447746,"f":8},{"t":720897,"n":"Uid","d":513154,"h":12885415042,"f":8},{"t":720897,"n":"Gid","d":513154,"h":17180382338,"f":8},{"t":917505,"n":"Size","d":513154,"h":21475349634,"f":8},{"t":917505,"n":"ATime","d":513154,"h":25770316930,"f":8},{"t":917505,"n":"ATimeNsec","d":513154,"h":30065284226,"f":8},{"t":917505,"n":"MTime","d":513154,"h":34360251522,"f":8},{"t":917505,"n":"MTimeNsec","d":513154,"h":38655218818,"f":8},{"t":917505,"n":"CTime","d":513154,"h":42950186114,"f":8},{"t":917505,"n":"CTimeNsec","d":513154,"h":47245153410,"f":8},{"t":917505,"n":"BirthTime","d":513154,"h":51540120706,"f":8},{"t":917505,"n":"BirthTimeNsec","d":513154,"h":55835088002,"f":8},{"t":917505,"n":"Dev","d":513154,"h":60130055298,"f":8},{"t":917505,"n":"RDev","d":513154,"h":64425022594,"f":8},{"t":917505,"n":"Ino","d":513154,"h":68719989890,"f":8},{"t":720897,"n":"UserFlags","d":513154,"h":73014957186,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":513154,"h":77309924482,"f":1}],"d":382082,"h":513154,"a":[{"t":109903873,"c":4404871169,"a":[{"v":0,"t":105381889}]}]}; }
                            static get $b() { return $.$spc.System.ValueType; }
                            static get $fullName() { return `Interop.Sys.FileStatus`; }
                        }, $cls, ($v) => $cls.$_FileStatus = $v);
                    }
                    static $_FileTypes;
                    static get FileTypes()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_FileTypes ??= $asm.$ncls("$sim.Interop.Sys.FileTypes", ($self) => class FileTypes
                        {
                            /*int*/ static S_IFMT = 61440;
                            /*int*/ static S_IFIFO = 4096;
                            /*int*/ static S_IFCHR = 8192;
                            /*int*/ static S_IFDIR = 16384;
                            /*int*/ static S_IFBLK = 24576;
                            /*int*/ static S_IFREG = 32768;
                            /*int*/ static S_IFLNK = 40960;
                            /*int*/ static S_IFSOCK = 49152;
                            static $h = 644226;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"S_IFMT","d":644226,"h":4295611522,"f":40},{"t":655361,"n":"S_IFIFO","d":644226,"h":8590578818,"f":40},{"t":655361,"n":"S_IFCHR","d":644226,"h":12885546114,"f":40},{"t":655361,"n":"S_IFDIR","d":644226,"h":17180513410,"f":40},{"t":655361,"n":"S_IFBLK","d":644226,"h":21475480706,"f":40},{"t":655361,"n":"S_IFREG","d":644226,"h":25770448002,"f":40},{"t":655361,"n":"S_IFLNK","d":644226,"h":30065415298,"f":40},{"t":655361,"n":"S_IFSOCK","d":644226,"h":34360382594,"f":40}],"d":382082,"h":644226}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `Interop.Sys.FileTypes`; }
                        }, $cls, ($v) => $cls.$_FileTypes = $v);
                    }
                    static $_FileStatusFlags;
                    static get FileStatusFlags()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_FileStatusFlags ??= $asm.$nstr("$sim.Interop.Sys.FileStatusFlags", ($self) => class FileStatusFlags extends $.$spc.System.Enum
                        {
                            static None = 0;
                            static HasBirthTime = 1;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "None": 0n,
                                    "HasBirthTime": 1n
                                };
                            }
                            static $h = 578690;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":578690,"n":"None","d":578690,"h":4295545986,"f":33},{"t":578690,"n":"HasBirthTime","d":578690,"h":8590513282,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":578690,"h":12885480578,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":382082,"h":578690,"a":[{"t":47644673,"c":4342611969}]}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.FileStatusFlags`; }
                        }, $cls, ($v) => $cls.$_FileStatusFlags = $v);
                    }
                    static $_SysConfName;
                    static get SysConfName()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_SysConfName ??= $asm.$nstr("$sim.Interop.Sys.SysConfName", ($self) => class SysConfName extends $.$spc.System.Enum
                        {
                            static _SC_CLK_TCK = 1;
                            static _SC_PAGESIZE = 2;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "_SC_CLK_TCK": 1n,
                                    "_SC_PAGESIZE": 2n
                                };
                            }
                            static $h = 1037442;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1037442,"n":"_SC_CLK_TCK","d":1037442,"h":4296004738,"f":33},{"t":1037442,"n":"_SC_PAGESIZE","d":1037442,"h":8590972034,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1037442,"h":12885939330,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":382082,"h":1037442}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.SysConfName`; }
                        }, $cls, ($v) => $cls.$_SysConfName = $v);
                    }
                    static $_MemoryAdvice;
                    static get MemoryAdvice()
                    {
                        let $cls = $.$sim.Interop.Sys;
                        return $cls.$_MemoryAdvice ??= $asm.$nstr("$sim.Interop.Sys.MemoryAdvice", ($self) => class MemoryAdvice extends $.$spc.System.Enum
                        {
                            static MADV_DONTFORK = 1;
                            static $map;
                            static get Map()
                            {
                                return this.$map ??= 
                                {
                                    "MADV_DONTFORK": 1n
                                };
                            }
                            static $h = 709762;
                            static $z = 4;
                            static $f = 0b110000011010001000;
                            static $k = 4;
                            static get $eut() { return $.$spc.System.Int32; }
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":709762,"n":"MADV_DONTFORK","d":709762,"h":4295677058,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":709762,"h":8590644354,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":382082,"h":709762}; }
                            static get $b() { return $.$spc.System.Enum; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                            static get $fullName() { return `Interop.Sys.MemoryAdvice`; }
                        }, $cls, ($v) => $cls.$_MemoryAdvice = $v);
                    }
                    /*sbyte*/ static s_memfdSupported = 0;
                    static /*bool */ get IsMemfdSupported()
                    {
                        /*sbyte*/ let memfdSupported = $.$sim.Interop.Sys.s_memfdSupported;
                        if (memfdSupported === 0)
                        {
                            $.$spc.System.Threading.Interlocked.CompareExchange$4($.$ref(() => $.$sim.Interop.Sys.s_memfdSupported, ($v) => $.$sim.Interop.Sys.s_memfdSupported = $v, $.$spc.System.SByte), $.$cast(($.$sim.Interop.Sys.MemfdSupportedImpl() === 1 ? 1 : -1), $.$spc.System.SByte), 0);
                            memfdSupported = $.$sim.Interop.Sys.s_memfdSupported;
                        }
                        return memfdSupported > 0;
                    }
                    static /*Error */ ConvertErrorPlatformToPal(/*int*/ platformErrno)
                    {
                        return $.$cast(platformErrno, $.$sim.Interop.Error);
                    }
                    static /*int */ ConvertErrorPalToPlatform(/*Error*/ error)
                    {
                        return error;
                    }
                    static /*byte* */ StrErrorR(/*int*/ platformErrno, /*byte**/ buffer, /*int*/ bufferSize)
                    {
                        /*RefOrPointer<byte>*/ let ptr = buffer;
                        $.$spc.System.String.TryCopyTo.call("Error", new ($.$spc.System.Span$$($.$spc.System.Char))().$ctor$4($.$cast(buffer, $.$typePointer($.$spc.System.Void)), bufferSize));
                        return buffer;
                    }
                    static /*int */ FTruncate(/*SafeFileHandle*/ fd, /*long*/ length)
                    {
                        return 0;
                    }
                    static /*IntPtr */ MMap(/*IntPtr*/ addr, /*ulong*/ len, /*MemoryMappedProtections*/ prot, /*MemoryMappedFlags*/ flags, /*SafeFileHandle*/ fd, /*long*/ offset)
                    {
                        return $.$spc.System.IntPtr.Zero;
                    }
                    static /*IntPtr */ MMap$1(/*IntPtr*/ addr, /*ulong*/ len, /*MemoryMappedProtections*/ prot, /*MemoryMappedFlags*/ flags, /*IntPtr*/ fd, /*long*/ offset)
                    {
                        return $.$spc.System.IntPtr.Zero;
                    }
                    static /*int */ MUnmap(/*IntPtr*/ addr, /*ulong*/ len)
                    {
                        return 0;
                    }
                    static /*SafeFileHandle */ Open(/*string*/ filename, /*OpenFlags*/ flags, /*int*/ mode)
                    {
                        return new $.$spc.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$5();
                    }
                    static /*int */ FStat(/*SafeHandle*/ fd, /*out FileStatus*/ output)
                    {
                        output.$v = $.$default($.$sim.Interop.Sys.FileStatus);
                        return -1;
                    }
                    static /*int */ Stat(/*string*/ path, /*out FileStatus*/ output)
                    {
                        output.$v = $.$default($.$sim.Interop.Sys.FileStatus);
                        return -1;
                    }
                    static /*int */ LStat(/*string*/ path, /*out FileStatus*/ output)
                    {
                        output.$v = $.$default($.$sim.Interop.Sys.FileStatus);
                        return -1;
                    }
                    static /*long */ SysConf(/*SysConfName*/ name)
                    {
                        return BigInt(-1);
                    }
                    static /*int */ Unlink(/*string*/ pathname)
                    {
                        return -1;
                    }
                    static /*int */ Close(/*IntPtr*/ fd)
                    {
                        return 0;
                    }
                    static /*int */ MAdvise(/*IntPtr*/ addr, /*ulong*/ length, /*MemoryAdvice*/ advice)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*SafeFileHandle */ MemfdCreate(/*string*/ name, /*int*/ isReadonly)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*int */ MemfdSupportedImpl()
                    {
                        return 0;
                    }
                    static /*int */ MSync(/*IntPtr*/ addr, /*ulong*/ len, /*MemoryMappedSyncFlags*/ flags)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*SafeFileHandle */ ShmOpen(/*string*/ name, /*OpenFlags*/ flags, /*int*/ mode)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static /*int */ ShmUnlink(/*string*/ name)
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static $h = 382082;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":150324237442,"f":40},"n":"IsMemfdSupported","d":382082,"h":146029270146,"f":40}],"m":[{"r":185474,"n":"GetLastError","d":382082,"h":4295349378,"f":40},{"r":251010,"n":"GetLastErrorInfo","d":382082,"h":8590316674,"f":40},{"r":1310721,"p":[{"n":"platformErrno","p":655361}],"n":"StrError","d":382082,"h":12885283970,"f":40},{"r":185474,"p":[{"n":"platformErrno","p":655361}],"n":"ConvertErrorPlatformToPal","d":382082,"h":17180251266,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ConvertErrorPlatformToPal","t":1310721}]},{"t":109969409,"c":4404936705}]},{"r":655361,"p":[{"n":"error","p":185474}],"n":"ConvertErrorPalToPlatform","d":382082,"h":21475218562,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ConvertErrorPalToPlatform","t":1310721}]},{"t":109969409,"c":4404936705}]},{"r":0,"p":[{"n":"platformErrno","p":655361},{"n":"buffer","p":0},{"n":"bufferSize","p":655361}],"n":"StrErrorR","d":382082,"h":25770185858,"f":34,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_StrErrorR","t":1310721}]}]},{"r":655361,"p":[{"n":"fd","p":786433}],"n":"Close","d":382082,"h":30065153154,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Close","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":786433,"p":[{"n":"addr","p":786433},{"n":"len","p":983041},{"n":"prot","p":840834},{"n":"flags","p":775298},{"n":"fd","p":7143425},{"n":"offset","p":917505}],"n":"MMap","d":382082,"h":47245022338,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MMap","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":786433,"p":[{"n":"addr","p":786433},{"n":"len","p":983041},{"n":"prot","p":840834},{"n":"flags","p":775298},{"n":"fd","p":786433},{"n":"offset","p":917505}],"n":"MMap","o":"@$1","d":382082,"h":51539989634,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MMap","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"addr","p":786433},{"n":"len","p":983041}],"n":"MUnmap","d":382082,"h":55834956930,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MUnmap","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"addr","p":786433},{"n":"len","p":983041},{"n":"flags","p":906370}],"n":"MSync","d":382082,"h":64424891522,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MSync","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":7143425,"p":[{"n":"filename","p":1310721},{"n":"flags","p":971906},{"n":"mode","p":655361}],"n":"Open","d":382082,"h":68719858818,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Open","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":109576193},{"n":"output","p":513154,"f":2}],"n":"FStat","d":382082,"h":90194695298,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FStat","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"path","p":1310721},{"n":"output","p":513154,"f":2}],"n":"Stat","d":382082,"h":94489662594,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Stat","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"path","p":1310721},{"n":"output","p":513154,"f":2}],"n":"LStat","d":382082,"h":98784629890,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_LStat","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":917505,"p":[{"n":"name","p":1037442}],"n":"SysConf","d":382082,"h":107374564482,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_SysConf","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"fd","p":7143425},{"n":"length","p":917505}],"n":"FTruncate","d":382082,"h":111669531778,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_FTruncate","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"addr","p":786433},{"n":"length","p":983041},{"n":"advice","p":709762}],"n":"MAdvise","d":382082,"h":115964499074,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MAdvise","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":7143425,"p":[{"n":"name","p":1310721},{"n":"flags","p":971906},{"n":"mode","p":655361}],"n":"ShmOpen","d":382082,"h":124554433666,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ShmOpen","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"name","p":1310721}],"n":"ShmUnlink","d":382082,"h":128849400962,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ShmUnlink","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":7143425,"p":[{"n":"name","p":1310721},{"n":"isReadonly","p":655361}],"n":"MemfdCreate","d":382082,"h":133144368258,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_MemfdCreate","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"n":"MemfdSupportedImpl","d":382082,"h":137439335554,"f":34,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_IsMemfdSupported","t":1310721},{"n":"SetLastError","v":true,"t":262145}]}]},{"r":655361,"p":[{"n":"pathname","p":1310721}],"n":"Unlink","d":382082,"h":154619204738,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_Unlink","t":1310721},{"n":"StringMarshalling","v":1,"t":109838337},{"n":"SetLastError","v":true,"t":262145}]}]}],"l":[{"t":327681,"n":"s_memfdSupported","d":382082,"h":141734302850,"f":34}],"j":[447618,840834,775298,906370,971906,513154,644226,578690,1037442,709762],"d":119938,"h":382082}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Sys`; }
                }, $cls, ($v) => $cls.$_Sys = $v);
            }
            static /*void */ ThrowExceptionForIoErrno(/*ErrorInfo*/ errorInfo, /*string?*/ path, /*bool*/ isDirError)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(errorInfo.Error !== 0/*Error.SUCCESS*/, "errorInfo.Error != Error.SUCCESS");
                $.$spc.System.Diagnostics.Debug.Assert$1(errorInfo.Error !== 65563/*Error.EINTR*/, "EINTR errors should be handled by the native shim and never bubble up to managed code");
                throw $.$sim.Interop.GetExceptionForIoErrno(errorInfo.Clone(), path, isDirError);
            }
            static /*void */ CheckIo(/*Error*/ error, /*string?*/ path, /*bool*/ isDirError)
            {
                if (error !== 0/*Interop.Error.SUCCESS*/)
                {
                    $.$sim.Interop.ThrowExceptionForIoErrno($.$sim.InteropErrorExtensions.Info(error), path, isDirError);
                }
            }
            static /*long */ CheckIo$1(/*long*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                if (result < 0n)
                {
                    $.$sim.Interop.ThrowExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), path, isDirError);
                }
                return result;
            }
            static /*void */ ThrowIOExceptionForLastError()
            {
                $.$sim.Interop.ThrowExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
            }
            static /*int */ CheckIo$2(/*int*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                $.$sim.Interop.CheckIo$1($.$cast(result, $.$spc.System.Int64), path, isDirError);
                return result;
            }
            static /*IntPtr */ CheckIo$3(/*IntPtr*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                $.$sim.Interop.CheckIo$1($.$cast(result, $.$spc.System.Int64), path, isDirError);
                return result;
            }
            static /*TSafeHandle */ CheckIo$4(TSafeHandle, /*TSafeHandle*/ handle, /*string?*/ path, /*bool*/ isDirError)
            {
                if (handle.IsInvalid)
                {
                    /*Exception*/ let e = $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), path, isDirError);
                    $.$dsp(handle, TSafeHandle, ($t) => $t.Dispose,);
                    throw e;
                }
                return handle;
            }
            static /*Exception */ GetExceptionForIoErrno(/*ErrorInfo*/ errorInfo, /*string?*/ path, /*bool*/ isDirError)
            {
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    let $switch1 = $switchJumpState1 ?? (errorInfo.Error);
                    switch($switch1)
                    {
                        case 65581/*Error.ENOENT*/:
                        if (!isDirError && (path === null || ParentDirectoryExists(path)))
                        {
                            return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.IO.FileNotFoundException().$ctor$17($.$sim.System.SR.Format($.$sim.System.SR.IO_FileNotFound_FileName, path), path) : new $.$spc.System.IO.FileNotFoundException().$ctor$15($.$sim.System.SR.IO_FileNotFound);
                        }
                        $switchJumpState1 = 65593/*Error.ENOTDIR*/; /*goto case Error.ENOTDIR*/
                        continue $switchJumpStart1;
                        case 65593/*Error.ENOTDIR*/:
                        return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.IO.DirectoryNotFoundException().$ctor$15($.$sim.System.SR.Format($.$sim.System.SR.IO_PathNotFound_Path, path)) : new $.$spc.System.IO.DirectoryNotFoundException().$ctor$15($.$sim.System.SR.IO_PathNotFound_NoPathName);
                        case 65538/*Error.EACCES*/:
                        case 65544/*Error.EBADF*/:
                        case 65602/*Error.EPERM*/:
                        /*Exception*/ let inner = $.$sim.Interop.GetIOException(errorInfo.Clone(), null);
                        return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.UnauthorizedAccessException().$ctor$11($.$sim.System.SR.Format($.$sim.System.SR.UnauthorizedAccess_IODenied_Path, path), inner) : new $.$spc.System.UnauthorizedAccessException().$ctor$11($.$sim.System.SR.UnauthorizedAccess_IODenied_NoPathName, inner);
                        case 65573/*Error.ENAMETOOLONG*/:
                        return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.IO.PathTooLongException().$ctor$15($.$sim.System.SR.Format($.$sim.System.SR.IO_PathTooLong_Path, path)) : new $.$spc.System.IO.PathTooLongException().$ctor$15($.$sim.System.SR.IO_PathTooLong);
                        case 65542/*Error.EWOULDBLOCK*/:
                        return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.IO.IOException().$ctor$11($.$sim.System.SR.Format($.$sim.System.SR.IO_SharingViolation_File, path), errorInfo.RawErrno) : new $.$spc.System.IO.IOException().$ctor$11($.$sim.System.SR.IO_SharingViolation_NoFileName, errorInfo.RawErrno);
                        case 65547/*Error.ECANCELED*/:
                        return new $.$spc.System.OperationCanceledException().$ctor$9();
                        case 65558/*Error.EFBIG*/:
                        return new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("value", $.$sim.System.SR.ArgumentOutOfRange_FileLengthTooBig);
                        case 65556/*Error.EEXIST*/:
                        if (!$.$spc.System.String.IsNullOrEmpty(path))
                        {
                            return new $.$spc.System.IO.IOException().$ctor$11($.$sim.System.SR.Format($.$sim.System.SR.IO_FileExists_Name, path), errorInfo.RawErrno);
                        }
                        $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                        continue $switchJumpStart1;
                        default:
                        return $.$sim.Interop.GetIOException(errorInfo.Clone(), path);
                        /*static bool*/  function ParentDirectoryExists(/*string*/ fullPath)
                        {
                            /*string?*/ let parentPath = $.$spc.System.IO.Path.GetDirectoryName($.$spc.System.IO.Path.TrimEndingDirectorySeparator(fullPath));
                            return $.$spc.System.IO.Directory.Exists(parentPath);
                        }
                    }
                    break;
                }
            }
            static /*Exception */ GetIOException(/*Interop.ErrorInfo*/ errorInfo, /*string?*/ path)
            {
                /*string*/ let msg = errorInfo.GetErrorMessage();
                return new $.$spc.System.IO.IOException().$ctor$11($.$spc.System.String.IsNullOrEmpty(path) ? msg : `${msg} : '${path}'`, errorInfo.RawErrno);
            }
            static $h = 119938;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"errorInfo","p":251010},{"n":"path","p":1310721},{"n":"isDirError","p":262145}],"n":"ThrowExceptionForIoErrno","d":119938,"h":21474956418,"f":34},{"r":65537,"p":[{"n":"error","p":185474},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"CheckIo","d":119938,"h":25769923714,"f":40},{"r":917505,"p":[{"n":"result","p":917505},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"CheckIo","o":"@$1","d":119938,"h":30064891010,"f":40},{"r":65537,"n":"ThrowIOExceptionForLastError","d":119938,"h":34359858306,"f":40},{"r":655361,"p":[{"n":"result","p":655361},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"CheckIo","o":"@$2","d":119938,"h":38654825602,"f":40},{"r":786433,"p":[{"n":"result","p":786433},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"CheckIo","o":"@$3","d":119938,"h":42949792898,"f":40},{"r":42953277440,"p":[{"n":"handle","p":42953277440},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"g":["TSafeHandle"],"n":"CheckIo","o":"@$4","d":119938,"h":47244760194,"f":131112},{"r":47185921,"p":[{"n":"errorInfo","p":251010},{"n":"path","p":1310721,"f":65},{"n":"isDirError","p":262145,"f":65,"v":false}],"n":"GetExceptionForIoErrno","d":119938,"h":51539727490,"f":40},{"r":47185921,"p":[{"n":"errorInfo","p":251010},{"n":"path","p":1310721,"f":65}],"n":"GetIOException","d":119938,"h":55834694786,"f":40}],"j":[316546,185474,251010,382082],"h":119938}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        
        $asm.$cls("$sim.InteropErrorExtensions", ($self) => class InteropErrorExtensions
        {
            static /*Interop.ErrorInfo */ Info(/*this Interop.Error*/ error)
            {
                return new $.$sim.Interop.ErrorInfo().$ctor$3(error);
            }
            static $h = 1102978;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":251010,"p":[{"n":"error","p":185474}],"n":"Info","d":1102978,"h":4296070274,"f":33}],"h":1102978}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `InteropErrorExtensions`; }
        });
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedFile", ($self) => class MemoryMappedFile extends $.$spc.System.Object
        {
            /*SafeMemoryMappedFileHandle*/ _handle = null;
            /*bool*/ _leaveOpen = false;
            /*SafeFileHandle?*/ _fileHandle = null;
            /*int*/ static DefaultSize = 0;
            $ctor$1(/*SafeMemoryMappedFileHandle*/ handle)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(handle !== null, "handle != null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(!handle.IsClosed, "!handle.IsClosed");
                    $.$spc.System.Diagnostics.Debug.Assert$1(!handle.IsInvalid, "!handle.IsInvalid");
                    this._handle = handle;
                    this._leaveOpen = true;
                }
                return this;
            }
            $ctor$2(/*SafeMemoryMappedFileHandle*/ handle, /*SafeFileHandle*/ fileHandle, /*bool*/ leaveOpen)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(handle !== null, "handle != null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(!handle.IsClosed, "!handle.IsClosed");
                    $.$spc.System.Diagnostics.Debug.Assert$1(!handle.IsInvalid, "!handle.IsInvalid");
                    $.$spc.System.Diagnostics.Debug.Assert$1(fileHandle !== null, "fileHandle != null");
                    this._handle = handle;
                    this._fileHandle = fileHandle;
                    this._leaveOpen = leaveOpen;
                }
                return this;
            }
            static /*MemoryMappedFile */ OpenExisting(/*string*/ mapName)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenExisting$2(mapName, 6/*MemoryMappedFileRights.ReadWrite*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ OpenExisting$1(/*string*/ mapName, /*MemoryMappedFileRights*/ desiredAccessRights)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenExisting$2(mapName, desiredAccessRights, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ OpenExisting$2(/*string*/ mapName, /*MemoryMappedFileRights*/ desiredAccessRights, /*HandleInheritability*/ inheritability)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(mapName, "mapName");
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("inheritability");
                }
                if ((desiredAccessRights & ~((983055/*MemoryMappedFileRights.FullControl*/ | 16777216/*MemoryMappedFileRights.AccessSystemSecurity*/))) !== 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("desiredAccessRights");
                }
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenCore$1(mapName, inheritability, desiredAccessRights, false);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$1(handle);
            }
            static /*MemoryMappedFile */ CreateFromFile(/*string*/ path)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$4(path, 3/*FileMode.Open*/, null, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            static /*MemoryMappedFile */ CreateFromFile$1(/*string*/ path, /*FileMode*/ mode)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$4(path, mode, null, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            static /*MemoryMappedFile */ CreateFromFile$2(/*string*/ path, /*FileMode*/ mode, /*string?*/ mapName)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$4(path, mode, mapName, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            static /*MemoryMappedFile */ CreateFromFile$3(/*string*/ path, /*FileMode*/ mode, /*string?*/ mapName, /*long*/ capacity)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateFromFile$4(path, mode, mapName, capacity, 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            static /*MemoryMappedFile */ CreateFromFile$4(/*string*/ path, /*FileMode*/ mode, /*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(path, "path");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.ValidateCreateFile(mapName, capacity, access);
                if (mode === 6/*FileMode.Append*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFAppendModeNotAllowed, "mode");
                }
                if (mode === 5/*FileMode.Truncate*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFTruncateModeNotAllowed, "mode");
                }
                /*bool*/ let existed = (() =>
                {
                    if (mode === 3/*FileMode.Open*/)
                    {
                        return true;
                    }
                    if (mode === 1/*FileMode.CreateNew*/)
                    {
                        return false;
                    }
                    return $.$spc.System.IO.File.Exists(path);
                })();
                /*SafeFileHandle*/ let fileHandle = $.$spc.System.IO.File.OpenHandle(path, mode, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GetFileAccess(access), 1/*FileShare.Read*/, 0/*FileOptions.None*/, 0n);
                /*long*/ let fileSize = 0n;
                if (!((mode === 1/*FileMode.CreateNew*/) || (mode === 2/*FileMode.Create*/)))
                {
                    try
                    {
                        fileSize = $.$spc.System.IO.RandomAccess.GetLength(fileHandle);
                    }
                    catch($e)
                    {
                        fileHandle.Dispose();
                        throw $e;
                    }
                }
                if (capacity === 0n && fileSize === 0n)
                {
                    $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CleanupFile(fileHandle, existed, path);
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sim.System.SR.Argument_EmptyFile);
                }
                if (capacity === BigInt(0/*DefaultSize*/))
                {
                    capacity = fileSize;
                }
                /*SafeMemoryMappedFileHandle?*/ let handle;
                try
                {
                    handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(fileHandle, mapName, 0/*HandleInheritability.None*/, access, 0/*MemoryMappedFileOptions.None*/, capacity, fileSize);
                }
                catch($e)
                {
                    $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CleanupFile(fileHandle, existed, path);
                    throw $e;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(handle !== null, "handle != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(!handle.IsInvalid, "!handle.IsInvalid");
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$2(handle, fileHandle, false);
            }
            static /*MemoryMappedFile */ CreateFromFile$5(/*SafeFileHandle*/ fileHandle, /*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*HandleInheritability*/ inheritability, /*bool*/ leaveOpen)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(fileHandle, "fileHandle");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.ValidateCreateFile(mapName, capacity, access);
                /*long*/ let fileSize = $.$spc.System.IO.RandomAccess.GetLength(fileHandle);
                if (capacity === 0n && fileSize === 0n)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sim.System.SR.Argument_EmptyFile);
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("inheritability");
                }
                if (capacity === BigInt(0/*DefaultSize*/))
                {
                    capacity = fileSize;
                }
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(fileHandle, mapName, inheritability, access, 0/*MemoryMappedFileOptions.None*/, capacity, fileSize);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$2(handle, fileHandle, leaveOpen);
            }
            static /*MemoryMappedFile */ CreateFromFile$6(/*FileStream*/ fileStream, /*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*HandleInheritability*/ inheritability, /*bool*/ leaveOpen)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(fileStream, "fileStream");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.ValidateCreateFile(mapName, capacity, access);
                /*long*/ let fileSize = fileStream.Length;
                if (capacity === 0n && fileSize === 0n)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sim.System.SR.Argument_EmptyFile);
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("inheritability");
                }
                fileStream.Flush();
                if (capacity === BigInt(0/*DefaultSize*/))
                {
                    capacity = fileSize;
                }
                /*SafeFileHandle*/ let fileHandle = fileStream.SafeFileHandle;
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(fileHandle, mapName, inheritability, access, 0/*MemoryMappedFileOptions.None*/, capacity, fileSize);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$2(handle, fileHandle, leaveOpen);
            }
            static /*MemoryMappedFile */ CreateNew(/*string?*/ mapName, /*long*/ capacity)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNew$2(mapName, capacity, 0/*MemoryMappedFileAccess.ReadWrite*/, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ CreateNew$1(/*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNew$2(mapName, capacity, access, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ CreateNew$2(/*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*HandleInheritability*/ inheritability)
            {
                if ($.$spc.System.String.op_Inequality(mapName, null) && mapName.length === 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sim.System.SR.Argument_MapNameEmptyString);
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int64, capacity, "capacity");
                if ($.$spc.System.IntPtr.Size === 4 && capacity > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("capacity", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("access");
                }
                if (access === 2/*MemoryMappedFileAccess.Write*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFWriteAccessNotAllowed, "access");
                }
                if ((options & ~((67108864/*MemoryMappedFileOptions.DelayAllocatePages*/))) !== 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("options");
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("inheritability");
                }
                /*SafeMemoryMappedFileHandle*/ let handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(null, mapName, inheritability, access, options, capacity, BigInt(-1));
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$1(handle);
            }
            static /*MemoryMappedFile */ CreateOrOpen(/*string*/ mapName, /*long*/ capacity)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateOrOpen$2(mapName, capacity, 0/*MemoryMappedFileAccess.ReadWrite*/, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ CreateOrOpen$1(/*string*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateOrOpen$2(mapName, capacity, access, 0/*MemoryMappedFileOptions.None*/, 0/*HandleInheritability.None*/);
            }
            static /*MemoryMappedFile */ CreateOrOpen$2(/*string*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*HandleInheritability*/ inheritability)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(mapName, "mapName");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int64, capacity, "capacity");
                if ($.$spc.System.IntPtr.Size === 4 && capacity > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("capacity", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("access");
                }
                if ((options & ~((67108864/*MemoryMappedFileOptions.DelayAllocatePages*/))) !== 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("options");
                }
                if (inheritability < 0/*HandleInheritability.None*/ || inheritability > 1/*HandleInheritability.Inheritable*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("inheritability");
                }
                /*SafeMemoryMappedFileHandle*/ let handle;
                if (access === 2/*MemoryMappedFileAccess.Write*/)
                {
                    handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.OpenCore(mapName, inheritability, access, true);
                }
                else 
                {
                    handle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateOrOpenCore(mapName, inheritability, access, options, capacity);
                }
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile().$ctor$1(handle);
            }
            /*MemoryMappedViewStream */ CreateViewStream()
            {
                return this.CreateViewStream$2(0n, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            /*MemoryMappedViewStream */ CreateViewStream$1(/*long*/ offset, /*long*/ size)
            {
                return this.CreateViewStream$2(offset, size, 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            /*MemoryMappedViewStream */ CreateViewStream$2(/*long*/ offset, /*long*/ size, /*MemoryMappedFileAccess*/ access)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int64, offset, "offset");
                if (size < 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("size", $.$sim.System.SR.ArgumentOutOfRange_PositiveOrDefaultSizeRequired);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("access");
                }
                if ($.$spc.System.IntPtr.Size === 4 && size > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("size", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                /*MemoryMappedView*/ let view = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.CreateView(this._handle, access, offset, size);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedViewStream().$ctor$8(view);
            }
            /*MemoryMappedViewAccessor */ CreateViewAccessor()
            {
                return this.CreateViewAccessor$2(0n, BigInt(0/*DefaultSize*/), 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            /*MemoryMappedViewAccessor */ CreateViewAccessor$1(/*long*/ offset, /*long*/ size)
            {
                return this.CreateViewAccessor$2(offset, size, 0/*MemoryMappedFileAccess.ReadWrite*/);
            }
            /*MemoryMappedViewAccessor */ CreateViewAccessor$2(/*long*/ offset, /*long*/ size, /*MemoryMappedFileAccess*/ access)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int64, offset, "offset");
                if (size < 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("size", $.$sim.System.SR.ArgumentOutOfRange_PositiveOrDefaultSizeRequired);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("access");
                }
                if ($.$spc.System.IntPtr.Size === 4 && size > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("size", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                /*MemoryMappedView*/ let view = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.CreateView(this._handle, access, offset, size);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedViewAccessor().$ctor$4(view);
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    if (!this._handle.IsClosed)
                    {
                        this._handle.Dispose();
                    }
                }
                finally
                {
                    {
                        if (!this._leaveOpen)
                        {
                            this._fileHandle?.Dispose();
                        }
                    }
                }
            }
            /*SafeMemoryMappedFileHandle */ get SafeMemoryMappedFileHandle()
            {
                return this._handle;
            }
            static /*FileAccess */ GetFileAccess(/*MemoryMappedFileAccess*/ access)
            {
                switch(access)
                {
                    case 1/*MemoryMappedFileAccess.Read*/:
                    case 4/*MemoryMappedFileAccess.ReadExecute*/:
                    return 1/*FileAccess.Read*/;
                    case 0/*MemoryMappedFileAccess.ReadWrite*/:
                    case 3/*MemoryMappedFileAccess.CopyOnWrite*/:
                    case 5/*MemoryMappedFileAccess.ReadWriteExecute*/:
                    return 3/*FileAccess.ReadWrite*/;
                    default:
                    $.$spc.System.Diagnostics.Debug.Assert$1(access === 2/*MemoryMappedFileAccess.Write*/, "access == MemoryMappedFileAccess.Write");
                    return 2/*FileAccess.Write*/;
                }
            }
            static /*void */ CleanupFile(/*SafeFileHandle*/ fileHandle, /*bool*/ existed, /*string*/ path)
            {
                fileHandle.Dispose();
                if (!existed)
                {
                    $.$spc.System.IO.File.Delete(path);
                }
            }
            static /*void */ ValidateCreateFile(/*string?*/ mapName, /*long*/ capacity, /*MemoryMappedFileAccess*/ access)
            {
                if ($.$spc.System.String.op_Inequality(mapName, null) && mapName.length === 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sim.System.SR.Argument_MapNameEmptyString);
                }
                if (capacity < 0n)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("capacity", $.$sim.System.SR.ArgumentOutOfRange_PositiveOrDefaultCapacityRequired);
                }
                if (access < 0/*MemoryMappedFileAccess.ReadWrite*/ || access > 5/*MemoryMappedFileAccess.ReadWriteExecute*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("access");
                }
                if (access === 2/*MemoryMappedFileAccess.Write*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFWriteAccessNotAllowed, "access");
                }
            }
            static /*void */ VerifyMemoryMappedFileAccess(/*MemoryMappedFileAccess*/ access, /*long*/ capacity, /*SafeFileHandle?*/ fileHandle, /*long*/ fileSize, /*out bool*/ isRegularFile)
            {
                isRegularFile.$v = !(fileHandle === null) && (fileSize > 0n || IsRegularFile(fileHandle));
                if (isRegularFile.$v)
                {
                    if (access === 1/*MemoryMappedFileAccess.Read*/ && capacity > fileSize)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$sim.System.SR.Argument_ReadAccessWithLargeCapacity);
                    }
                    if (fileSize > capacity)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("capacity", $.$sim.System.SR.ArgumentOutOfRange_CapacityGEFileSizeRequired);
                    }
                    if (access === 2/*MemoryMappedFileAccess.Write*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$sim.System.SR.Argument_NewMMFWriteAccessNotAllowed, "access");
                    }
                }
                /*static bool*/  function IsRegularFile(/*SafeFileHandle*/ fileHandle)
                {
                    /*Interop.Sys.FileStatus*/ let status;
                    $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.FStat(fileHandle, $.$ref(() => status, ($v) => status = $v, $.$sim.Interop.Sys.FileStatus)), null, false);
                    return (status.Mode & 32768/*Interop.Sys.FileTypes.S_IFREG*/) !== 0;
                }
            }
            static /*SafeMemoryMappedFileHandle */ CreateCore(/*SafeFileHandle?*/ fileHandle, /*string?*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*long*/ capacity, /*long*/ fileSize)
            {
                /*bool*/ let isRegularFile;
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.VerifyMemoryMappedFileAccess(access, capacity, fileHandle, fileSize, $.$ref(() => isRegularFile, ($v) => isRegularFile = $v, $.$spc.System.Boolean));
                if ($.$spc.System.String.op_Inequality(mapName, null))
                {
                    throw $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNamedMapsNotSupportedException();
                }
                /*bool*/ let ownsFileStream = false;
                if (fileHandle !== null)
                {
                    if (isRegularFile && fileSize >= 0n && capacity > fileSize)
                    {
                        try
                        {
                            $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.FTruncate(fileHandle, capacity), null, false);
                        }
                        catch(exc)
                        {
                            throw new $.$spc.System.IO.IOException().$ctor$12(exc.Message, exc);
                        }
                    }
                }
                else 
                {
                    /*Interop.Sys.MemoryMappedProtections*/ let protections = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(access, false);
                    if ((protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) !== 0 && capacity > 0n)
                    {
                        ownsFileStream = true;
                        fileHandle = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObject(protections, capacity, inheritability);
                    }
                }
                return new $.$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedFileHandle().$ctor$5(fileHandle, ownsFileStream, inheritability, access, options, capacity);
            }
            static /*SafeMemoryMappedFileHandle */ CreateOrOpenCore(/*string*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*long*/ capacity)
            {
                return $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateCore(null, mapName, inheritability, access, options, capacity, BigInt(-1));
            }
            static /*SafeMemoryMappedFileHandle */ OpenCore(/*string*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*bool*/ createOrOpen)
            {
                throw $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNamedMapsNotSupportedException();
            }
            static /*SafeMemoryMappedFileHandle */ OpenCore$1(/*string*/ mapName, /*HandleInheritability*/ inheritability, /*MemoryMappedFileRights*/ rights, /*bool*/ createOrOpen)
            {
                throw $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateNamedMapsNotSupportedException();
            }
            static /*PlatformNotSupportedException */ CreateNamedMapsNotSupportedException()
            {
                return new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$sim.System.SR.PlatformNotSupported_NamedMaps);
            }
            static /*FileAccess */ TranslateProtectionsToFileAccess(/*Interop.Sys.MemoryMappedProtections*/ protections)
            {
                return (protections & (1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/)) !== 0 ? 3/*FileAccess.ReadWrite*/ : (protections & (2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/)) !== 0 ? 2/*FileAccess.Write*/ : 1/*FileAccess.Read*/;
            }
            static /*SafeFileHandle */ CreateSharedBackingObject(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                return $.$sim.Interop.Sys.IsMemfdSupported ? $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObjectUsingMemoryMemfdCreate(protections, capacity, inheritability) : $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObjectUsingMemoryShmOpen(protections, capacity, inheritability) ?? $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.CreateSharedBackingObjectUsingFile(protections, capacity, inheritability);
            }
            static /*SafeFileHandle? */ CreateSharedBackingObjectUsingMemoryShmOpen(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                /*Interop.Sys.OpenFlags*/ let flags = (protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) !== 0 ? 2/*Interop.Sys.OpenFlags.O_RDWR*/ : 0/*Interop.Sys.OpenFlags.O_RDONLY*/;
                flags |= 32/*Interop.Sys.OpenFlags.O_CREAT*/ | 64/*Interop.Sys.OpenFlags.O_EXCL*/;
                /*var*/ let perms = 0/*UnixFileMode.None*/;
                if ((protections & 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/) !== 0)
                {
                    perms |= 256/*UnixFileMode.UserRead*/;
                }
                if ((protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) !== 0)
                {
                    perms |= 128/*UnixFileMode.UserWrite*/;
                }
                if ((protections & 4/*Interop.Sys.MemoryMappedProtections.PROT_EXEC*/) !== 0)
                {
                    perms |= 64/*UnixFileMode.UserExecute*/;
                }
                /*string*/ let mapName;
                /*SafeFileHandle*/ let fd;
                do
                {
                    mapName = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GenerateMapName();
                    fd = $.$sim.Interop.Sys.ShmOpen(mapName, flags, perms);
                    if (fd.IsInvalid)
                    {
                        /*Interop.ErrorInfo*/ let errorInfo = $.$sim.Interop.Sys.GetLastErrorInfo();
                        fd.Dispose();
                        if (errorInfo.Error === 65597/*Interop.Error.ENOTSUP*/)
                        {
                            return null;
                        }
                        else if (errorInfo.Error === 65573/*Interop.Error.ENAMETOOLONG*/)
                        {
                            $.$spc.System.Diagnostics.Debug.Fail(`shm_open failed with ENAMETOOLONG for ${$.$spc.System.Text.Encoding.UTF8.GetByteCount$1(mapName)} byte long name.`);
                            return null;
                        }
                        else if (errorInfo.Error !== 65556/*Interop.Error.EEXIST*/)
                        {
                            throw $.$sim.Interop.GetExceptionForIoErrno(errorInfo.Clone(), null, false);
                        }
                    }
                }
                while(fd.IsInvalid);
                try
                {
                    $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.ShmUnlink(mapName), null, false);
                    $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.FTruncate(fd, capacity), null, false);
                    if (inheritability === 1/*HandleInheritability.Inheritable*/ && $.$sim.Interop.Sys.Fcntl.SetFD(fd, 0) === -1)
                    {
                        throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                    }
                    return fd;
                }
                catch($e)
                {
                    fd.Dispose();
                    throw $e;
                }
            }
            static /*string */ GenerateMapName()
            {
                /*int*/ let MaxNameLength = 30;
                /*string*/ let NamePrefix = "/dotnet_";
                return $.$spc.System.String.Create$8($.$spc.System.Int32, MaxNameLength, 0, new ($.$spc.System.Buffers.SpanAction$$$($.$spc.System.Char, $.$spc.System.Int32))().$ctor(this,  (/*span*/ span, /*state*/ state) =>
                {
                    /*Span<char>*/ let guid = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 32, null);
                    /*int*/ let charsWritten;
                    $.$spc.System.Guid.NewGuid().TryFormat(guid, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), $.$spc.System.String.op_Implicit("N"));
                    $.$spc.System.Diagnostics.Debug.Assert$1(charsWritten === 32, "charsWritten == 32");
                    $.$spc.System.String.CopyTo$1.call(NamePrefix, span);
                    guid.Slice$1(0, ((MaxNameLength - NamePrefix.length) | 0)).CopyTo(span.Slice(NamePrefix.length));
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Text.Encoding.UTF8.GetByteCount$5($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(span)) <= MaxNameLength, "Encoding.UTF8.GetByteCount(span) <= MaxNameLength");
                }));
            }
            static /*SafeFileHandle */ CreateSharedBackingObjectUsingMemoryMemfdCreate(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                /*int*/ let isReadonly = ((protections & 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/) !== 0 && (protections & 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/) === 0) ? 1 : 0;
                /*SafeFileHandle*/ let fd = $.$sim.Interop.Sys.MemfdCreate($.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GenerateMapName(), isReadonly);
                if (fd.IsInvalid)
                {
                    /*Interop.ErrorInfo*/ let errorInfo = $.$sim.Interop.Sys.GetLastErrorInfo();
                    fd.Dispose();
                    throw $.$sim.Interop.GetExceptionForIoErrno(errorInfo.Clone(), null, false);
                }
                try
                {
                    $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.FTruncate(fd, capacity), null, false);
                    if (inheritability === 1/*HandleInheritability.Inheritable*/ && $.$sim.Interop.Sys.Fcntl.SetFD(fd, 0) === -1)
                    {
                        throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                    }
                    return fd;
                }
                catch($e)
                {
                    fd.Dispose();
                    throw $e;
                }
            }
            static /*SafeFileHandle */ CreateSharedBackingObjectUsingFile(/*Interop.Sys.MemoryMappedProtections*/ protections, /*long*/ capacity, /*HandleInheritability*/ inheritability)
            {
                /*string*/ let path = $.$spc.System.IO.Path.Combine($.$spc.System.IO.Path.GetTempPath(), $.$spc.System.Guid.NewGuid().ToString$1("N"));
                /*FileShare*/ let share = inheritability === 0/*HandleInheritability.None*/ ? 3/*FileShare.ReadWrite*/ : 3/*FileShare.ReadWrite*/ | 16/*FileShare.Inheritable*/;
                /*SafeFileHandle*/ let fileHandle = $.$spc.System.IO.File.OpenHandle(path, 1/*FileMode.CreateNew*/, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.TranslateProtectionsToFileAccess(protections), share, 0, 0n);
                try
                {
                    $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.Unlink(path), null, false);
                    $.$sim.Interop.CheckIo$2($.$sim.Interop.Sys.FTruncate(fileHandle, capacity), path, false);
                }
                catch($e)
                {
                    fileHandle.Dispose();
                    throw $e;
                }
                return fileHandle;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1299586;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1168514,"g":{"r":0,"d":0,"h":137440253058,"f":1},"n":"SafeMemoryMappedFileHandle","d":1299586,"h":133145285762,"f":1}],"m":[{"r":1299586,"p":[{"n":"mapName","p":1310721}],"n":"OpenExisting","d":1299586,"h":30066070658,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1299586,"p":[{"n":"mapName","p":1310721},{"n":"desiredAccessRights","p":1496194}],"n":"OpenExisting","o":"@$1","d":1299586,"h":34361037954,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1299586,"p":[{"n":"mapName","p":1310721},{"n":"desiredAccessRights","p":1496194},{"n":"inheritability","p":60555265}],"n":"OpenExisting","o":"@$2","d":1299586,"h":38656005250,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1299586,"p":[{"n":"path","p":1310721}],"n":"CreateFromFile","d":1299586,"h":42950972546,"f":33},{"r":1299586,"p":[{"n":"path","p":1310721},{"n":"mode","p":59965441}],"n":"CreateFromFile","o":"@$1","d":1299586,"h":47245939842,"f":33},{"r":1299586,"p":[{"n":"path","p":1310721},{"n":"mode","p":59965441},{"n":"mapName","p":1310721}],"n":"CreateFromFile","o":"@$2","d":1299586,"h":51540907138,"f":33},{"r":1299586,"p":[{"n":"path","p":1310721},{"n":"mode","p":59965441},{"n":"mapName","p":1310721},{"n":"capacity","p":917505}],"n":"CreateFromFile","o":"@$3","d":1299586,"h":55835874434,"f":33},{"r":1299586,"p":[{"n":"path","p":1310721},{"n":"mode","p":59965441},{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1365122}],"n":"CreateFromFile","o":"@$4","d":1299586,"h":60130841730,"f":33},{"r":1299586,"p":[{"n":"fileHandle","p":7143425},{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1365122},{"n":"inheritability","p":60555265},{"n":"leaveOpen","p":262145}],"n":"CreateFromFile","o":"@$5","d":1299586,"h":64425809026,"f":33},{"r":1299586,"p":[{"n":"fileStream","p":60293121},{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1365122},{"n":"inheritability","p":60555265},{"n":"leaveOpen","p":262145}],"n":"CreateFromFile","o":"@$6","d":1299586,"h":68720776322,"f":33},{"r":1299586,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505}],"n":"CreateNew","d":1299586,"h":73015743618,"f":33},{"r":1299586,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1365122}],"n":"CreateNew","o":"@$1","d":1299586,"h":77310710914,"f":33},{"r":1299586,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1365122},{"n":"options","p":1430658},{"n":"inheritability","p":60555265}],"n":"CreateNew","o":"@$2","d":1299586,"h":81605678210,"f":33},{"r":1299586,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505}],"n":"CreateOrOpen","d":1299586,"h":85900645506,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1299586,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1365122}],"n":"CreateOrOpen","o":"@$1","d":1299586,"h":90195612802,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1299586,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1365122},{"n":"options","p":1430658},{"n":"inheritability","p":60555265}],"n":"CreateOrOpen","o":"@$2","d":1299586,"h":94490580098,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1692802,"n":"CreateViewStream","d":1299586,"h":98785547394,"f":1},{"r":1692802,"p":[{"n":"offset","p":917505},{"n":"size","p":917505}],"n":"CreateViewStream","o":"@$1","d":1299586,"h":103080514690,"f":1},{"r":1692802,"p":[{"n":"offset","p":917505},{"n":"size","p":917505},{"n":"access","p":1365122}],"n":"CreateViewStream","o":"@$2","d":1299586,"h":107375481986,"f":1},{"r":1627266,"n":"CreateViewAccessor","d":1299586,"h":111670449282,"f":1},{"r":1627266,"p":[{"n":"offset","p":917505},{"n":"size","p":917505}],"n":"CreateViewAccessor","o":"@$1","d":1299586,"h":115965416578,"f":1},{"r":1627266,"p":[{"n":"offset","p":917505},{"n":"size","p":917505},{"n":"access","p":1365122}],"n":"CreateViewAccessor","o":"@$2","d":1299586,"h":120260383874,"f":1},{"r":65537,"n":"Dispose","d":1299586,"h":124555351170,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1299586,"h":128850318466,"f":132},{"r":59703297,"p":[{"n":"access","p":1365122}],"n":"GetFileAccess","d":1299586,"h":141735220354,"f":40},{"r":65537,"p":[{"n":"fileHandle","p":7143425},{"n":"existed","p":262145},{"n":"path","p":1310721}],"n":"CleanupFile","d":1299586,"h":146030187650,"f":34},{"r":65537,"p":[{"n":"mapName","p":1310721},{"n":"capacity","p":917505},{"n":"access","p":1365122}],"n":"ValidateCreateFile","d":1299586,"h":150325154946,"f":34},{"r":65537,"p":[{"n":"access","p":1365122},{"n":"capacity","p":917505},{"n":"fileHandle","p":7143425},{"n":"fileSize","p":917505},{"n":"isRegularFile","p":262145,"f":2}],"n":"VerifyMemoryMappedFileAccess","d":1299586,"h":154620122242,"f":34},{"r":1168514,"p":[{"n":"fileHandle","p":7143425},{"n":"mapName","p":1310721},{"n":"inheritability","p":60555265},{"n":"access","p":1365122},{"n":"options","p":1430658},{"n":"capacity","p":917505},{"n":"fileSize","p":917505}],"n":"CreateCore","d":1299586,"h":158915089538,"f":34},{"r":1168514,"p":[{"n":"mapName","p":1310721},{"n":"inheritability","p":60555265},{"n":"access","p":1365122},{"n":"options","p":1430658},{"n":"capacity","p":917505}],"n":"CreateOrOpenCore","d":1299586,"h":163210056834,"f":34},{"r":1168514,"p":[{"n":"mapName","p":1310721},{"n":"inheritability","p":60555265},{"n":"access","p":1365122},{"n":"createOrOpen","p":262145}],"n":"OpenCore","d":1299586,"h":167505024130,"f":34},{"r":1168514,"p":[{"n":"mapName","p":1310721},{"n":"inheritability","p":60555265},{"n":"rights","p":1496194},{"n":"createOrOpen","p":262145}],"n":"OpenCore","o":"@$1","d":1299586,"h":171799991426,"f":34},{"r":72220673,"n":"CreateNamedMapsNotSupportedException","d":1299586,"h":176094958722,"f":34},{"r":59703297,"p":[{"n":"protections","p":840834}],"n":"TranslateProtectionsToFileAccess","d":1299586,"h":180389926018,"f":34},{"r":7143425,"p":[{"n":"protections","p":840834},{"n":"capacity","p":917505},{"n":"inheritability","p":60555265}],"n":"CreateSharedBackingObject","d":1299586,"h":184684893314,"f":34},{"r":7143425,"p":[{"n":"protections","p":840834},{"n":"capacity","p":917505},{"n":"inheritability","p":60555265}],"n":"CreateSharedBackingObjectUsingMemoryShmOpen","d":1299586,"h":188979860610,"f":34},{"r":1310721,"n":"GenerateMapName","d":1299586,"h":193274827906,"f":34},{"r":7143425,"p":[{"n":"protections","p":840834},{"n":"capacity","p":917505},{"n":"inheritability","p":60555265}],"n":"CreateSharedBackingObjectUsingMemoryMemfdCreate","d":1299586,"h":197569795202,"f":34},{"r":7143425,"p":[{"n":"protections","p":840834},{"n":"capacity","p":917505},{"n":"inheritability","p":60555265}],"n":"CreateSharedBackingObjectUsingFile","d":1299586,"h":201864762498,"f":34}],"l":[{"t":1168514,"n":"_handle","d":1299586,"h":4296266882,"f":2},{"t":262145,"n":"_leaveOpen","d":1299586,"h":8591234178,"f":2},{"t":7143425,"n":"_fileHandle","d":1299586,"h":12886201474,"f":2},{"t":655361,"n":"DefaultSize","d":1299586,"h":17181168770,"f":40}],"c":[{"p":[{"n":"handle","p":1168514}],"n":".ctor","o":"$ctor$1","d":1299586,"h":21476136066,"f":2},{"p":[{"n":"handle","p":1168514},{"n":"fileHandle","p":7143425},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$2","d":1299586,"h":25771103362,"f":2}],"i":[57475073],"h":1299586}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFile`; }
        });
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedView", ($self) => class MemoryMappedView extends $.$spc.System.Object
        {
            /*SafeMemoryMappedViewHandle*/ _viewHandle = null;
            /*long*/ _pointerOffset = 0n;
            /*long*/ _size = 0n;
            /*MemoryMappedFileAccess*/ _access = 0;
            $ctor$1(/*SafeMemoryMappedViewHandle*/ viewHandle, /*long*/ pointerOffset, /*long*/ size, /*MemoryMappedFileAccess*/ access)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(viewHandle !== null, "viewHandle != null");
                    this._viewHandle = viewHandle;
                    this._pointerOffset = pointerOffset;
                    this._size = size;
                    this._access = access;
                }
                return this;
            }
            /*SafeMemoryMappedViewHandle */ get ViewHandle()
            {
                return this._viewHandle;
            }
            /*long */ get PointerOffset()
            {
                return this._pointerOffset;
            }
            /*long */ get Size()
            {
                return this._size;
            }
            /*MemoryMappedFileAccess */ get Access()
            {
                return this._access;
            }
            /*void */ Dispose()
            {
                if (!this._viewHandle.IsClosed)
                {
                    this._viewHandle.Dispose();
                }
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*bool */ get IsClosed()
            {
                return this._viewHandle.IsClosed;
            }
            static /*void */ ValidateSizeAndOffset(/*long*/ size, /*long*/ offset, /*long*/ allocationGranularity, /*out ulong*/ newSize, /*out long*/ extraMemNeeded, /*out long*/ newOffset)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(size >= 0n, "size >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(offset >= 0n, "offset >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(allocationGranularity > 0n, "allocationGranularity > 0");
                extraMemNeeded.$v = offset % allocationGranularity;
                newOffset.$v = offset - extraMemNeeded.$v;
                newSize.$v = (size !== BigInt(0/*MemoryMappedFile.DefaultSize*/)) ? $.$cast(size, $.$spc.System.UInt64) + $.$cast(extraMemNeeded.$v, $.$spc.System.UInt64) : 0n;
                if ($.$spc.System.IntPtr.Size === 4 && newSize.$v > BigInt(4294967295/*uint.MaxValue*/))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("size", $.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
            }
            static /*MemoryMappedView */ CreateView(/*SafeMemoryMappedFileHandle*/ memMappedFileHandle, /*MemoryMappedFileAccess*/ access, /*long*/ requestedOffset, /*long*/ requestedSize)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int64, requestedOffset, memMappedFileHandle._capacity, "offset");
                if (requestedSize > 8192000000000n)
                {
                    throw new $.$spc.System.IO.IOException().$ctor$10($.$sim.System.SR.ArgumentOutOfRange_CapacityLargerThanLogicalAddressSpaceNotAllowed);
                }
                if (requestedOffset + requestedSize > memMappedFileHandle._capacity)
                {
                    throw new $.$spc.System.UnauthorizedAccessException().$ctor$9();
                }
                $.$spc.System.ObjectDisposedException.ThrowIf(memMappedFileHandle.IsClosed, memMappedFileHandle);
                if (requestedSize === BigInt(0/*MemoryMappedFile.DefaultSize*/))
                {
                    requestedSize = memMappedFileHandle._capacity - requestedOffset;
                }
                /*ulong*/ let nativeSize;
                /*long*/ let extraMemNeeded, nativeOffset;
                /*long*/ let pageSize = $.$sim.Interop.Sys.SysConf(2/*Interop.Sys.SysConfName._SC_PAGESIZE*/);
                $.$spc.System.Diagnostics.Debug.Assert$1(pageSize > 0n, "pageSize > 0");
                $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.ValidateSizeAndOffset(requestedSize, requestedOffset, pageSize, $.$ref(() => nativeSize, ($v) => nativeSize = $v, $.$spc.System.UInt64), $.$ref(() => extraMemNeeded, ($v) => extraMemNeeded = $v, $.$spc.System.Int64), $.$ref(() => nativeOffset, ($v) => nativeOffset = $v, $.$spc.System.Int64));
                /*Interop.Sys.MemoryMappedFlags*/ let flags = (memMappedFileHandle._access === 3/*MemoryMappedFileAccess.CopyOnWrite*/ || access === 3/*MemoryMappedFileAccess.CopyOnWrite*/) ? 2/*Interop.Sys.MemoryMappedFlags.MAP_PRIVATE*/ : 1/*Interop.Sys.MemoryMappedFlags.MAP_SHARED*/;
                /*SafeFileHandle*/ let fd;
                if (memMappedFileHandle._fileStreamHandle !== null)
                {
                    fd = memMappedFileHandle._fileStreamHandle;
                    $.$spc.System.Diagnostics.Debug.Assert$1(!fd.IsInvalid, "!fd.IsInvalid");
                }
                else 
                {
                    fd = new $.$spc.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$4(new $.$spc.System.IntPtr().$ctor$2(-1), false);
                    flags |= 16/*Interop.Sys.MemoryMappedFlags.MAP_ANONYMOUS*/;
                }
                /*Interop.Sys.MemoryMappedProtections*/ let viewProtForVerification = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(access, true);
                /*Interop.Sys.MemoryMappedProtections*/ let mapProtForVerification = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(memMappedFileHandle._access, true);
                if ((viewProtForVerification & mapProtForVerification) !== viewProtForVerification)
                {
                    throw new $.$spc.System.UnauthorizedAccessException().$ctor$9();
                }
                /*Interop.Sys.MemoryMappedProtections*/ let viewProtForCreation = $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.GetProtections(access, false);
                /*IntPtr*/ let addr;
                if (nativeSize > 0n)
                {
                    addr = $.$sim.Interop.Sys.MMap($.$spc.System.IntPtr.Zero, nativeSize, viewProtForCreation, flags, fd, nativeOffset);
                }
                else 
                {
                    addr = $.$sim.Interop.Sys.MMap($.$spc.System.IntPtr.Zero, 1n, viewProtForCreation, flags | 16/*Interop.Sys.MemoryMappedFlags.MAP_ANONYMOUS*/, new $.$spc.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$4(new $.$spc.System.IntPtr().$ctor$2(-1), false), 0n);
                    requestedSize = 0n;
                    extraMemNeeded = 0n;
                }
                if (addr === $.$spc.System.IntPtr.Zero)
                {
                    throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                }
                if (memMappedFileHandle._inheritability === 0/*HandleInheritability.None*/)
                {
                    $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView.DisableForkingIfPossible(addr, nativeSize);
                }
                /*var*/ let viewHandle = new $.$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle().$ctor$6(addr, true);
                viewHandle.Initialize(nativeSize);
                return new $.$sim.System.IO.MemoryMappedFiles.MemoryMappedView().$ctor$1(viewHandle, extraMemNeeded, requestedSize, access);
            }
            /*void */ Flush(/*UIntPtr*/ capacity)
            {
                if (capacity === $.$spc.System.UIntPtr.Zero)
                {
                    return;
                }
                /*byte**/ let ptr = null;
                try
                {
                    this._viewHandle.AcquirePointer($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$typePointer($.$spc.System.Byte), () => ptr, ($v) => ptr = $v, null));
                    /*int*/ let result = $.$sim.Interop.Sys.MSync($.$cast(ptr, $.$spc.System.IntPtr), $.$cast(capacity, $.$spc.System.UInt64), 2/*Interop.Sys.MemoryMappedSyncFlags.MS_SYNC*/ | 16/*Interop.Sys.MemoryMappedSyncFlags.MS_INVALIDATE*/);
                    if (result < 0)
                    {
                        throw $.$sim.Interop.GetExceptionForIoErrno($.$sim.Interop.Sys.GetLastErrorInfo(), null, false);
                    }
                }
                finally
                {
                    {
                        if (ptr !== null)
                        {
                            this._viewHandle.ReleasePointer();
                        }
                    }
                }
            }
            static /*void */ DisableForkingIfPossible(/*IntPtr*/ addr, /*ulong*/ length)
            {
                if (length > 0n)
                {
                    $.$sim.Interop.Sys.MAdvise(addr, length, 1/*Interop.Sys.MemoryAdvice.MADV_DONTFORK*/);
                }
            }
            /*long*/ static MaxProcessAddressSpace = 8192000000000n;
            static /*Interop.Sys.MemoryMappedProtections */ GetProtections(/*MemoryMappedFileAccess*/ access, /*bool*/ forVerification)
            {
                switch(access)
                {
                    default:
                    case 1/*MemoryMappedFileAccess.Read*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/;
                    case 2/*MemoryMappedFileAccess.Write*/:
                    return 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/;
                    case 0/*MemoryMappedFileAccess.ReadWrite*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/;
                    case 4/*MemoryMappedFileAccess.ReadExecute*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 4/*Interop.Sys.MemoryMappedProtections.PROT_EXEC*/;
                    case 5/*MemoryMappedFileAccess.ReadWriteExecute*/:
                    return 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/ | 4/*Interop.Sys.MemoryMappedProtections.PROT_EXEC*/;
                    case 3/*MemoryMappedFileAccess.CopyOnWrite*/:
                    return forVerification ? 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ : 1/*Interop.Sys.MemoryMappedProtections.PROT_READ*/ | 2/*Interop.Sys.MemoryMappedProtections.PROT_WRITE*/;
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1561730;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1234050,"g":{"r":0,"d":0,"h":30066332802,"f":1},"n":"ViewHandle","d":1561730,"h":25771365506,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":38656267394,"f":1},"n":"PointerOffset","d":1561730,"h":34361300098,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":47246201986,"f":1},"n":"Size","d":1561730,"h":42951234690,"f":1},{"p":1365122,"g":{"r":0,"d":0,"h":55836136578,"f":1},"n":"Access","d":1561730,"h":51541169282,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68721038466,"f":1},"n":"IsClosed","d":1561730,"h":64426071170,"f":1}],"m":[{"r":65537,"n":"Dispose","d":1561730,"h":60131103874,"f":1},{"r":65537,"p":[{"n":"size","p":917505},{"n":"offset","p":917505},{"n":"allocationGranularity","p":917505},{"n":"newSize","p":983041,"f":2},{"n":"extraMemNeeded","p":917505,"f":2},{"n":"newOffset","p":917505,"f":2}],"n":"ValidateSizeAndOffset","d":1561730,"h":73016005762,"f":34},{"r":1561730,"p":[{"n":"memMappedFileHandle","p":1168514},{"n":"access","p":1365122},{"n":"requestedOffset","p":917505},{"n":"requestedSize","p":917505}],"n":"CreateView","d":1561730,"h":77310973058,"f":33},{"r":65537,"p":[{"n":"capacity","p":851969}],"n":"Flush","d":1561730,"h":81605940354,"f":1},{"r":65537,"p":[{"n":"addr","p":786433},{"n":"length","p":983041}],"n":"DisableForkingIfPossible","d":1561730,"h":85900907650,"f":34},{"r":840834,"p":[{"n":"access","p":1365122},{"n":"forVerification","p":262145}],"n":"GetProtections","d":1561730,"h":94490842242,"f":40}],"l":[{"t":1234050,"n":"_viewHandle","d":1561730,"h":4296529026,"f":2},{"t":917505,"n":"_pointerOffset","d":1561730,"h":8591496322,"f":2},{"t":917505,"n":"_size","d":1561730,"h":12886463618,"f":2},{"t":1365122,"n":"_access","d":1561730,"h":17181430914,"f":2},{"t":917505,"n":"MaxProcessAddressSpace","d":1561730,"h":90195874946,"f":34}],"c":[{"p":[{"n":"viewHandle","p":1234050},{"n":"pointerOffset","p":917505},{"n":"size","p":917505},{"n":"access","p":1365122}],"n":".ctor","o":"$ctor$1","d":1561730,"h":21476398210,"f":2}],"i":[57475073],"h":1561730}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedView`; }
        });
        
        $asm.$str("$sim.System.IO.MemoryMappedFiles.MemoryMappedFileOptions", ($self) => class MemoryMappedFileOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static DelayAllocatePages = 67108864;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "DelayAllocatePages": 67108864n
                };
            }
            static $h = 1430658;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1430658,"n":"None","d":1430658,"h":4296397954,"f":33},{"t":1430658,"n":"DelayAllocatePages","d":1430658,"h":8591365250,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1430658,"h":12886332546,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1430658,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFileOptions`; }
        });
        
        $asm.$str("$sim.System.IO.MemoryMappedFiles.MemoryMappedFileAccess", ($self) => class MemoryMappedFileAccess extends $.$spc.System.Enum
        {
            static ReadWrite = 0;
            static Read = 1;
            static Write = 2;
            static CopyOnWrite = 3;
            static ReadExecute = 4;
            static ReadWriteExecute = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ReadWrite": 0n,
                    "Read": 1n,
                    "Write": 2n,
                    "CopyOnWrite": 3n,
                    "ReadExecute": 4n,
                    "ReadWriteExecute": 5n
                };
            }
            static $h = 1365122;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1365122,"n":"ReadWrite","d":1365122,"h":4296332418,"f":33},{"t":1365122,"n":"Read","d":1365122,"h":8591299714,"f":33},{"t":1365122,"n":"Write","d":1365122,"h":12886267010,"f":33},{"t":1365122,"n":"CopyOnWrite","d":1365122,"h":17181234306,"f":33},{"t":1365122,"n":"ReadExecute","d":1365122,"h":21476201602,"f":33},{"t":1365122,"n":"ReadWriteExecute","d":1365122,"h":25771168898,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1365122,"h":30066136194,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1365122}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFileAccess`; }
        });
        
        $asm.$str("$sim.System.IO.MemoryMappedFiles.MemoryMappedFileRights", ($self) => class MemoryMappedFileRights extends $.$spc.System.Enum
        {
            static CopyOnWrite = 1;
            static Write = 2;
            static Read = 4;
            static Execute = 8;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static ReadWrite = 6;
            static ReadExecute = 12;
            static ReadWriteExecute = 14;
            static FullControl = 983055;
            static AccessSystemSecurity = 16777216;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "CopyOnWrite": 1n,
                    "Write": 2n,
                    "Read": 4n,
                    "Execute": 8n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "ReadWrite": 6n,
                    "ReadExecute": 12n,
                    "ReadWriteExecute": 14n,
                    "FullControl": 983055n,
                    "AccessSystemSecurity": 16777216n
                };
            }
            static $h = 1496194;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1496194,"n":"CopyOnWrite","d":1496194,"h":4296463490,"f":33},{"t":1496194,"n":"Write","d":1496194,"h":8591430786,"f":33},{"t":1496194,"n":"Read","d":1496194,"h":12886398082,"f":33},{"t":1496194,"n":"Execute","d":1496194,"h":17181365378,"f":33},{"t":1496194,"n":"Delete","d":1496194,"h":21476332674,"f":33},{"t":1496194,"n":"ReadPermissions","d":1496194,"h":25771299970,"f":33},{"t":1496194,"n":"ChangePermissions","d":1496194,"h":30066267266,"f":33},{"t":1496194,"n":"TakeOwnership","d":1496194,"h":34361234562,"f":33},{"t":1496194,"n":"ReadWrite","d":1496194,"h":38656201858,"f":33},{"t":1496194,"n":"ReadExecute","d":1496194,"h":42951169154,"f":33},{"t":1496194,"n":"ReadWriteExecute","d":1496194,"h":47246136450,"f":33},{"t":1496194,"n":"FullControl","d":1496194,"h":51541103746,"f":33},{"t":1496194,"n":"AccessSystemSecurity","d":1496194,"h":55836071042,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1496194,"h":60131038338,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1496194,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedFileRights`; }
        });
        
        $asm.$cls("$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedFileHandle", ($self) => class SafeMemoryMappedFileHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(true);
                {
                }
                return this;
            }
            /*SafeFileHandle?*/ _fileStreamHandle = null;
            /*bool*/ _ownsFileHandle = false;
            /*HandleInheritability*/ _inheritability = 0;
            /*MemoryMappedFileAccess*/ _access = 0;
            /*MemoryMappedFileOptions*/ _options = 0;
            /*long*/ _capacity = 0n;
            $ctor$5(/*SafeFileHandle?*/ fileHandle, /*bool*/ ownsFileHandle, /*HandleInheritability*/ inheritability, /*MemoryMappedFileAccess*/ access, /*MemoryMappedFileOptions*/ options, /*long*/ capacity)
            {
                super.$ctor$3(true);
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!ownsFileHandle || fileHandle !== null, "We can only own a FileStream we're actually given.");
                    this._ownsFileHandle = ownsFileHandle;
                    this._inheritability = inheritability;
                    this._access = access;
                    this._options = options;
                    this._capacity = capacity;
                    /*IntPtr*/ let handlePtr;
                    if (fileHandle !== null)
                    {
                        /*bool*/ let ignored = false;
                        fileHandle.DangerousAddRef($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => ignored, ($v) => ignored = $v, null));
                        this._fileStreamHandle = fileHandle;
                        handlePtr = fileHandle.DangerousGetHandle();
                    }
                    else 
                    {
                        handlePtr = $.$spc.System.IntPtr.MaxValue;
                    }
                    this.SetHandle(handlePtr);
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                if (this._fileStreamHandle !== null)
                {
                    this.SetHandle((-1));
                    if (this._ownsFileHandle)
                    {
                        this._fileStreamHandle.Dispose();
                    }
                    this._fileStreamHandle.DangerousRelease();
                    this._fileStreamHandle = null;
                }
                return true;
            }
            /*bool */ get IsInvalid()
            {
                return $.$cast(this.handle, $.$spc.System.Int64) <= 0n;
            }
            static $h = 1168514;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"p":[{"p":262145,"g":{"r":0,"d":0,"h":47245808770,"f":32769},"n":"IsInvalid","d":1168514,"h":42950841474,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":1168514,"h":38655874178,"f":32772}],"l":[{"t":7143425,"n":"_fileStreamHandle","d":1168514,"h":8591103106,"f":8},{"t":262145,"n":"_ownsFileHandle","d":1168514,"h":12886070402,"f":8},{"t":60555265,"n":"_inheritability","d":1168514,"h":17181037698,"f":8},{"t":1365122,"n":"_access","d":1168514,"h":21476004994,"f":8},{"t":1430658,"n":"_options","d":1168514,"h":25770972290,"f":8},{"t":917505,"n":"_capacity","d":1168514,"h":30065939586,"f":8}],"c":[{"n":".ctor","o":"$ctor$4","d":1168514,"h":4296135810,"f":1},{"p":[{"n":"fileHandle","p":7143425},{"n":"ownsFileHandle","p":262145},{"n":"inheritability","p":60555265},{"n":"access","p":1365122},{"n":"options","p":1430658},{"n":"capacity","p":917505}],"n":".ctor","o":"$ctor$5","d":1168514,"h":34360906882,"f":8}],"i":[57475073],"h":1168514}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeMemoryMappedFileHandle`; }
        });
        
        $asm.$cls("$sim.Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle", ($self) => class SafeMemoryMappedViewHandle extends $.$spc.System.Runtime.InteropServices.SafeBuffer
        {
            $ctor$5()
            {
                super.$ctor$4(true);
                {
                }
                return this;
            }
            $ctor$6(/*IntPtr*/ handle, /*bool*/ ownsHandle)
            {
                super.$ctor$4(ownsHandle);
                {
                    super.SetHandle(handle);
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                /*IntPtr*/ let addr = this.handle;
                this.handle = new $.$spc.System.IntPtr().$ctor$2(-1);
                return $.$sim.Interop.Sys.MUnmap(addr, super.ByteLength) === 0;
            }
            static $h = 1234050;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":109510657,"m":[{"r":262145,"n":"ReleaseHandle","d":1234050,"h":12886135938,"f":32772}],"c":[{"n":".ctor","o":"$ctor$5","d":1234050,"h":4296201346,"f":1},{"p":[{"n":"handle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$6","d":1234050,"h":8591168642,"f":8}],"i":[57475073],"h":1234050}; }
            static get $b() { return $.$spc.System.Runtime.InteropServices.SafeBuffer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeMemoryMappedViewHandle`; }
        });
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedViewAccessor", ($self) => class MemoryMappedViewAccessor extends $.$spc.System.IO.UnmanagedMemoryAccessor
        {
            /*MemoryMappedView*/ _view = null;
            $ctor$4(/*MemoryMappedView*/ view)
            {
                super.$ctor$1();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(view !== null, "view is null");
                    this._view = view;
                    this.Initialize(this._view.ViewHandle, this._view.PointerOffset, this._view.Size, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GetFileAccess(this._view.Access));
                }
                return this;
            }
            /*SafeMemoryMappedViewHandle */ get SafeMemoryMappedViewHandle()
            {
                return this._view.ViewHandle;
            }
            /*long */ get PointerOffset()
            {
                return this._view.PointerOffset;
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                try
                {
                    if (disposing && !this._view.IsClosed && this.CanWrite)
                    {
                        this.Flush();
                    }
                }
                finally
                {
                    {
                        try
                        {
                            this._view.Dispose();
                        }
                        finally
                        {
                            {
                                super.Dispose(disposing);
                            }
                        }
                    }
                }
            }
            /*void */ Flush()
            {
                if (!this.IsOpen)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15("MemoryMappedViewAccessor", $.$sim.System.SR.ObjectDisposed_ViewAccessorClosed);
                }
                this._view.Flush($.$cast(this.Capacity, $.$spc.System.UIntPtr));
            }
            static $h = 1627266;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":63307777,"p":[{"p":1234050,"g":{"r":0,"d":0,"h":17181496450,"f":1},"n":"SafeMemoryMappedViewHandle","d":1627266,"h":12886529154,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":25771431042,"f":1},"n":"PointerOffset","d":1627266,"h":21476463746,"f":1}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":1627266,"h":30066398338,"f":32772},{"r":65537,"n":"Flush","d":1627266,"h":34361365634,"f":1}],"l":[{"t":1561730,"n":"_view","d":1627266,"h":4296594562,"f":2}],"c":[{"p":[{"n":"view","p":1561730}],"n":".ctor","o":"$ctor$4","d":1627266,"h":8591561858,"f":8}],"i":[57475073],"h":1627266}; }
            static get $b() { return $.$spc.System.IO.UnmanagedMemoryAccessor; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedViewAccessor`; }
        });
        
        $asm.$cls("$sim.System.IO.MemoryMappedFiles.MemoryMappedViewStream", ($self) => class MemoryMappedViewStream extends $.$spc.System.IO.UnmanagedMemoryStream
        {
            /*MemoryMappedView*/ _view = null;
            $ctor$8(/*MemoryMappedView*/ view)
            {
                super.$ctor$3();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(view !== null, "view is null");
                    this._view = view;
                    this.Initialize(this._view.ViewHandle, this._view.PointerOffset, this._view.Size, $.$sim.System.IO.MemoryMappedFiles.MemoryMappedFile.GetFileAccess(this._view.Access));
                }
                return this;
            }
            /*SafeMemoryMappedViewHandle */ get SafeMemoryMappedViewHandle()
            {
                return this._view.ViewHandle;
            }
            /*long */ get PointerOffset()
            {
                return this._view.PointerOffset;
            }
            /*void */ SetLength(/*long*/ value)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int64, value, "value");
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$sim.System.SR.NotSupported_MMViewStreamsFixedLength);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                try
                {
                    if (disposing && !this._view.IsClosed && this.CanWrite)
                    {
                        this.Flush();
                    }
                }
                finally
                {
                    {
                        try
                        {
                            this._view.Dispose();
                        }
                        finally
                        {
                            {
                                super.Dispose$1(disposing);
                            }
                        }
                    }
                }
            }
            /*void */ Flush()
            {
                if (!this.CanSeek)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15(null, $.$sim.System.SR.ObjectDisposed_StreamIsClosed);
                }
                this._view.Flush($.$cast(this.Capacity, $.$spc.System.UIntPtr));
            }
            static $h = 1692802;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":63373313,"p":[{"p":1234050,"g":{"r":0,"d":0,"h":17181561986,"f":1},"n":"SafeMemoryMappedViewHandle","d":1692802,"h":12886594690,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":25771496578,"f":1},"n":"PointerOffset","d":1692802,"h":21476529282,"f":1}],"m":[{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1692802,"h":30066463874,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1692802,"h":34361431170,"f":32772},{"r":65537,"n":"Flush","d":1692802,"h":38656398466,"f":32769}],"l":[{"t":1561730,"n":"_view","d":1692802,"h":4296660098,"f":2}],"c":[{"p":[{"n":"view","p":1561730}],"n":".ctor","o":"$ctor$8","d":1692802,"h":8591627394,"f":8}],"i":[57475073,56885249],"h":1692802}; }
            static get $b() { return $.$spc.System.IO.UnmanagedMemoryStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.MemoryMappedFiles.MemoryMappedViewStream`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices"))