
//--TRIMMABLE-BOUNDARY-START(81)
(async function () {
(function ($global, $, $$, $sc, $sm, $spu, $sr, $st, $sttp) {
    "use strict";
    let _;
    let $leioLh;
    let $OiwHmc;
    let $VOxWFf;
    let $JNCuJg;
    let $aZoNFh;
    let $dlQdyc;
    let $LejFni;
    let $tkhwKe;
    let $cslFTj;
    
    
    
	$.$asm(
    "NetJs.System.IO.Pipelines", 
    {
  "h": 81,
  "f": "System.IO.Pipelines",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "System.IO.Pipelines.Tests, PublicKey=00240000048000009400000006020000002400005253413100040000010001004b86c4cb78549b34bab61a3b1800e23bfeb5b3ec390074041536a7e3cbd97f5f04cf0f857155a8928eaa29ebfd11cfbbad3ba70efea7bda3226c6a8d370a4cd303f714486b6ebc225985a638471e6ef571cc92a4613c00b8fa65d61ccee0cbe5f36330c9a01f4183559f1bef24cc2917c6d913e3a541333a1d05d9bed22b38cb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.IO.Pipelines",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.IO.Pipelines",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(458833)
        $asm.$cls(`$sipl.SIP.IDuplexPipe`, ($self) => class IDuplexPipe
        {
            static $h = 458833;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475295313),
    {
      "p": 1376337,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590393425,
        "f": 50331905
      },
      "n": "Input",
      "o": "SIP$IDuplexPipe$Input",
      "d": 458833,
      "h": 21475295313,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475295313),
//--TRIMMABLE-BOUNDARY-START(25770262609),
    {
      "p": 1572945,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180328017,
        "f": 50331905
      },
      "n": "Output",
      "o": "SIP$IDuplexPipe$Output",
      "d": 458833,
      "h": 25770262609,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25770262609)
  ],
  "h": 458833
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.IDuplexPipe`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}IDuplexPipe`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458833)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507409)
        $asm.$cls(`$sipl.SIP.PipeScheduler`, ($self) => class PipeScheduler extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38656213073)
            /*ThreadPoolScheduler*/ static s_threadPoolScheduler = null;
            //--TRIMMABLE-BOUNDARY-END(38656213073)
            
            //--TRIMMABLE-BOUNDARY-START(34361245777)
            /*InlineScheduler*/ static s_inlineScheduler = null;
            //--TRIMMABLE-BOUNDARY-END(34361245777)
            
            //--TRIMMABLE-BOUNDARY-START(47246147665)
            static /*PipeScheduler */ get ThreadPool()
            {
                return $.$sipl.SIP.PipeScheduler.s_threadPoolScheduler;
            }
            //--TRIMMABLE-BOUNDARY-END(47246147665)
            
            //--TRIMMABLE-BOUNDARY-START(30066278481)
            static /*PipeScheduler */ get Inline()
            {
                return $.$sipl.SIP.PipeScheduler.s_inlineScheduler;
            }
            //--TRIMMABLE-BOUNDARY-END(30066278481)
            
            //--TRIMMABLE-BOUNDARY-START(51541114961)
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541114961);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Schedule(action, state);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541114961)
            
            //--TRIMMABLE-BOUNDARY-START(8591442001)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591442001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591442001)
            
            //--TRIMMABLE-BOUNDARY-START(8591442001)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591442001)
            
            //--TRIMMABLE-BOUNDARY-START(4296474705)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296474705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(38656213073)
                    this.s_threadPoolScheduler = new $.$sipl.SIP.ThreadPoolScheduler().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(38656213073)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34361245777)
                    this.s_inlineScheduler = new $.$sipl.SIP.InlineScheduler().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(34361245777)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296474705)
            
            static $h = 1507409;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246147665),
    {
      "p": 1507409,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771311185,
        "f": 50331681
      },
      "n": "ThreadPool",
      "d": 1507409,
      "h": 47246147665,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(47246147665),
//--TRIMMABLE-BOUNDARY-START(30066278481),
    {
      "p": 1507409,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181376593,
        "f": 50331681
      },
      "n": "Inline",
      "d": 1507409,
      "h": 30066278481,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30066278481)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951180369),
    {
      "r": 65537,
      "p": [
        {
          "n": "action",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "Schedule",
      "d": 1507409,
      "h": 42951180369,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42951180369),
//--TRIMMABLE-BOUNDARY-START(51541114961),
    {
      "r": 65537,
      "p": [
        {
          "n": "action",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "UnsafeSchedule",
      "d": 1507409,
      "h": 51541114961,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(51541114961)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656213073),
    {
      "t": 2228305,
      "n": "s_threadPoolScheduler",
      "d": 1507409,
      "h": 38656213073,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38656213073),
//--TRIMMABLE-BOUNDARY-START(34361245777),
    {
      "t": 524369,
      "n": "s_inlineScheduler",
      "d": 1507409,
      "h": 34361245777,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34361245777)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591442001),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507409,
      "h": 8591442001,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591442001)
  ],
  "h": 1507409
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeScheduler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeScheduler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507409)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376337)
        $asm.$cls(`$sipl.SIP.PipeReader`, ($self) => class PipeReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296343633)
            /*PipeReaderStream?*/ _stream = null;
            //--TRIMMABLE-BOUNDARY-END(4296343633)
            
            //--TRIMMABLE-BOUNDARY-START(68720853073)
            /*ValueTask<ReadResult> */ ReadAtLeastAsync(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720853073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (minimumSize < 0)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentOutOfRangeException(0/*ExceptionArgument.minimumSize*/);
                }
                return this.ReadAtLeastAsyncCore(minimumSize, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(68720853073)
            
            //--TRIMMABLE-BOUNDARY-START(73015820369)
            /*ValueTask<ReadResult> *//*async*/  ReadAtLeastAsyncCore(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult), $.$sipl.SIP.ReadResult, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015820369);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    while(true)
                    {
                        let $t1, $r1;
                        /*ReadResult*/ let result = ($t1 = this.ReadAsync(cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        /*ReadOnlySequence<byte>*/ let buffer = result.Buffer;
                        if (buffer.Length >= BigInt(minimumSize) || result.IsCompleted || result.IsCanceled)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, result);
                        }
                        this.AdvanceTo(buffer.Start, buffer.End);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73015820369)
            
            //--TRIMMABLE-BOUNDARY-START(21476212817)
            /*Stream */ AsStream(/*bool*/ leaveOpen)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476212817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._stream === null)
                {
                    this._stream = new $.$sipl.SIP.PipeReaderStream().$ctor$3(this, leaveOpen);
                }
                else if (leaveOpen)
                {
                    this._stream.LeaveOpen = leaveOpen;
                }
                return this._stream;
            }
            //--TRIMMABLE-BOUNDARY-END(21476212817)
            
            //--TRIMMABLE-BOUNDARY-START(34361114705)
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361114705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    this.Complete(exception);
                    return new $.$$.STT.ValueTask();
                }
                catch(ex)
                {
                    return new $.$$.STT.ValueTask().$ctor$5($.$$.STT.Task.FromException(ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361114705)
            
            //--TRIMMABLE-BOUNDARY-START(60130918481)
            /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130918481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60130918481)
            
            //--TRIMMABLE-BOUNDARY-START(55835951185)
            static /*PipeReader */ Create$1(/*Stream*/ stream, /*StreamPipeReaderOptions?*/ readerOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835951185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sipl.SIP.StreamPipeReader().$ctor$2(stream, readerOptions ?? $.$sipl.SIP.StreamPipeReaderOptions.s_default);
            }
            //--TRIMMABLE-BOUNDARY-END(55835951185)
            
            //--TRIMMABLE-BOUNDARY-START(51540983889)
            static /*PipeReader */ Create(/*ReadOnlySequence<byte>*/ sequence)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540983889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sipl.SIP.SequencePipeReader().$ctor$2(sequence);
            }
            //--TRIMMABLE-BOUNDARY-END(51540983889)
            
            //--TRIMMABLE-BOUNDARY-START(38656082001)
            /*Task */ CopyToAsync(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656082001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination === null)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.STT.Task.FromCanceled$1(cancellationToken);
                }
                return this.CopyToAsyncCore($.$sipl.SIP.PipeWriter, destination, new ($.$$.S.Func$$$$$($.$sipl.SIP.PipeWriter, $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult)))().$ctor(this,  (/**/ destination, /*memory*/ memory, /**/ cancellationToken) =>
                {
                    return destination.WriteAsync(memory, cancellationToken);
                }, $leioLh ??= {"r":$.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult).$h,"p":[{"n":"destination","p":1572945},{"n":"memory","p":$.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h},{"n":"cancellationToken","p":170852353}],"n":"","d":1376337,"h":0,"f":17825794}), cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(38656082001)
            
            //--TRIMMABLE-BOUNDARY-START(42951049297)
            /*Task */ CopyToAsync$1(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951049297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination === null)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.STT.Task.FromCanceled$1(cancellationToken);
                }
                return this.CopyToAsyncCore($.$$.SI.Stream, destination, new ($.$$.S.Func$$$$$($.$$.SI.Stream, $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult)))().$ctor(this,  (/*destination*/ destination, /*memory*/ memory, /*cancellationToken*/ cancellationToken) =>
                {
                    /*ValueTask*/ let task = destination.WriteAsync$2(memory, cancellationToken);
                    if (task.IsCompletedSuccessfully)
                    {
                        task.GetAwaiter().GetResult();
                        return new ($.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult))().$ctor$6(new $.$sipl.SIP.FlushResult().$ctor$3(false, false));
                    }
                    /*static ValueTask<FlushResult>*/ /*async*/  function Awaited(/*ValueTask*/ writeTask)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult), $.$sipl.SIP.FlushResult, async ($asnycContext) => 
                        {
                            let $t2, $r2;
                            ($t2 = writeTask.ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            return $.$$.N.AsyncResolver.Result($asnycContext, new $.$sipl.SIP.FlushResult().$ctor$3(false, false));
                        });
                    }
                    return Awaited(task);
                }, $OiwHmc ??= {"r":$.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult).$h,"p":[{"n":"destination","p":95748097},{"n":"memory","p":$.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h},{"n":"cancellationToken","p":170852353}],"n":"","d":1376337,"h":0,"f":17825794}), cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(42951049297)
            
            //--TRIMMABLE-BOUNDARY-START(47246016593)
            /*Task *//*async*/  CopyToAsyncCore(TStream, /*TStream*/ destination, /*Func<TStream, ReadOnlyMemory<byte>, CancellationToken, ValueTask<FlushResult>>*/ writeAsync, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246016593);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    while(true)
                    {
                        let $t3, $r3;
                        /*ReadResult*/ let result = ($t3 = this.ReadAsync(cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        /*ReadOnlySequence<byte>*/ let buffer = result.Buffer;
                        /*SequencePosition*/ let position = buffer.Start;
                        /*SequencePosition*/ let consumed = position;
                        try
                        {
                            /*ReadOnlyMemory<byte>*/ let memory;
                            if (result.IsCanceled)
                            {
                                $.$sipl.SIP.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                            }
                            while(buffer.TryGet($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sm.S.SequencePosition, () => position, ($v) => position = $v, null, true), $.$ref(() => memory, ($v) => memory = $v, $.$$.S.ReadOnlyMemory$$($.$$.S.Byte)), true))
                            {
                                if (memory.IsEmpty)
                                {
                                    consumed = position;
                                }
                                else 
                                {
                                    let $t6, $r6;
                                    /*FlushResult*/ let flushResult = ($t6 = writeAsync.Invoke(destination, memory, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                    if (flushResult.IsCanceled)
                                    {
                                        $.$sipl.SIP.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                                    }
                                    consumed = position;
                                    if (flushResult.IsCompleted)
                                    {
                                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                                    }
                                }
                            }
                            consumed = buffer.End;
                            if (result.IsCompleted)
                            {
                                break;
                            }
                        }
                        finally
                        {
                            {
                                this.AdvanceTo$1(consumed);
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(47246016593)
            
            //--TRIMMABLE-BOUNDARY-START(8591310929)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591310929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591310929)
            
            //--TRIMMABLE-BOUNDARY-START(8591310929)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591310929)
            
            static $h = 1376337;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(77310787665),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": 1704017,
          "f": 2
        }
      ],
      "n": "TryRead",
      "d": 1376337,
      "h": 77310787665,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(77310787665),
//--TRIMMABLE-BOUNDARY-START(64425885777),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "d": 1376337,
      "h": 64425885777,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(64425885777),
//--TRIMMABLE-BOUNDARY-START(68720853073),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult).$h,
      "p": [
        {
          "n": "minimumSize",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAtLeastAsync",
      "d": 1376337,
      "h": 68720853073,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720853073),
//--TRIMMABLE-BOUNDARY-START(73015820369),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult).$h,
      "p": [
        {
          "n": "minimumSize",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAtLeastAsyncCore",
      "d": 1376337,
      "h": 73015820369,
      "f": 16781444
    },
//--TRIMMABLE-BOUNDARY-END(73015820369),
//--TRIMMABLE-BOUNDARY-START(17181245521),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumed",
          "p": 1179656
        }
      ],
      "n": "AdvanceTo",
      "o": "@$1",
      "d": 1376337,
      "h": 17181245521,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181245521),
//--TRIMMABLE-BOUNDARY-START(12886278225),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumed",
          "p": 1179656
        },
        {
          "n": "examined",
          "p": 1179656
        }
      ],
      "n": "AdvanceTo",
      "d": 1376337,
      "h": 12886278225,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886278225),
//--TRIMMABLE-BOUNDARY-START(21476212817),
    {
      "r": 95748097,
      "p": [
        {
          "n": "leaveOpen",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "AsStream",
      "d": 1376337,
      "h": 21476212817,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21476212817),
//--TRIMMABLE-BOUNDARY-START(25771180113),
    {
      "r": 65537,
      "n": "CancelPendingRead",
      "d": 1376337,
      "h": 25771180113,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25771180113),
//--TRIMMABLE-BOUNDARY-START(30066147409),
    {
      "r": 65537,
      "p": [
        {
          "n": "exception",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "Complete",
      "d": 1376337,
      "h": 30066147409,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30066147409),
//--TRIMMABLE-BOUNDARY-START(34361114705),
    {
      "r": 181338113,
      "p": [
        {
          "n": "exception",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "CompleteAsync",
      "d": 1376337,
      "h": 34361114705,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34361114705),
//--TRIMMABLE-BOUNDARY-START(60130918481),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$$($.$$.S.Exception, $.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "OnWriterCompleted",
      "d": 1376337,
      "h": 60130918481,
      "f": 16777345,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "OnWriterCompleted has been deprecated and may not be invoked on all implementations of PipeReader.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130918481),
//--TRIMMABLE-BOUNDARY-START(55835951185),
    {
      "r": 1376337,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "readerOptions",
          "p": 2031697,
          "f": 65
        }
      ],
      "n": "Create",
      "o": "@$1",
      "d": 1376337,
      "h": 55835951185,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835951185),
//--TRIMMABLE-BOUNDARY-START(51540983889),
    {
      "r": 1376337,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h
        }
      ],
      "n": "Create",
      "d": 1376337,
      "h": 51540983889,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540983889),
//--TRIMMABLE-BOUNDARY-START(38656082001),
    {
      "r": 178454529,
      "p": [
        {
          "n": "destination",
          "p": 1572945
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "CopyToAsync",
      "d": 1376337,
      "h": 38656082001,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(38656082001),
//--TRIMMABLE-BOUNDARY-START(42951049297),
    {
      "r": 178454529,
      "p": [
        {
          "n": "destination",
          "p": 95748097
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "CopyToAsync",
      "o": "@$1",
      "d": 1376337,
      "h": 42951049297,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42951049297),
//--TRIMMABLE-BOUNDARY-START(47246016593),
    {
      "r": 178454529,
      "p": [
        {
          "n": "destination",
          "p": (TStream) => TStream.$h
        },
        {
          "n": "writeAsync",
          "p": (TStream) => $.$$.S.Func$$$$$(TStream, $.$$.S.ReadOnlyMemory$$($.$$.S.Byte), $.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult)).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "g": [
        "TStream"
      ],
      "n": "CopyToAsyncCore",
      "d": 1376337,
      "h": 47246016593,
      "f": 16912386
    },
//--TRIMMABLE-BOUNDARY-END(47246016593)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296343633),
    {
      "t": 1441873,
      "n": "_stream",
      "d": 1376337,
      "h": 4296343633,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296343633)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591310929),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376337,
      "h": 8591310929,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591310929)
  ],
  "h": 1376337
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376337)
        
        

        //--TRIMMABLE-BOUNDARY-START(1704017)
        $asm.$str(`$sipl.SIP.ReadResult`, ($self) => class ReadResult extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296671313)
            /*ReadOnlySequence<byte>*/ _resultBuffer;
            //--TRIMMABLE-BOUNDARY-END(4296671313)
            
            //--TRIMMABLE-BOUNDARY-START(8591638609)
            /*ResultFlags*/ _resultFlags = 0;
            //--TRIMMABLE-BOUNDARY-END(8591638609)
            
            //--TRIMMABLE-BOUNDARY-START(17181573201)
            $ctor$3(/*ReadOnlySequence<byte>*/ buffer, /*bool*/ isCanceled, /*bool*/ isCompleted)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181573201);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._resultBuffer = buffer;
                    this._resultFlags = 0/*ResultFlags.None*/;
                    if (isCompleted)
                    {
                        this._resultFlags |= 2/*ResultFlags.Completed*/;
                    }
                    if (isCanceled)
                    {
                        this._resultFlags |= 1/*ResultFlags.Canceled*/;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181573201)
            
            //--TRIMMABLE-BOUNDARY-START(21476540497)
            /*ReadOnlySequence<byte> */ get Buffer()
            {
                return this._resultBuffer;
            }
            //--TRIMMABLE-BOUNDARY-END(21476540497)
            
            //--TRIMMABLE-BOUNDARY-START(51541311569)
            /*bool */ get IsCanceled()
            {
                return (this._resultFlags & 1/*ResultFlags.Canceled*/) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(51541311569)
            
            //--TRIMMABLE-BOUNDARY-START(55836278865)
            /*bool */ get IsCompleted()
            {
                return (this._resultFlags & 2/*ResultFlags.Completed*/) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(55836278865)
            
            //--TRIMMABLE-BOUNDARY-START(12886605905)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886605905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886605905)
            
            //--TRIMMABLE-BOUNDARY-START(12886605905)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886605905)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resultBuffer = this._resultBuffer.$clone();
                copy._resultFlags = this._resultFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296671313)
                this._resultBuffer = $.$default($.$sm.SB.ReadOnlySequence$$($.$$.S.Byte));
                //--TRIMMABLE-BOUNDARY-END(4296671313)
                
            }
            static $h = 1704017;
            static $z = 17;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476540497),
    {
      "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066475089,
        "f": 50331649
      },
      "n": "Buffer",
      "d": 1704017,
      "h": 21476540497,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476540497),
//--TRIMMABLE-BOUNDARY-START(51541311569),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656409681,
        "f": 50331649
      },
      "n": "IsCanceled",
      "d": 1704017,
      "h": 51541311569,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541311569),
//--TRIMMABLE-BOUNDARY-START(55836278865),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246344273,
        "f": 50331649
      },
      "n": "IsCompleted",
      "d": 1704017,
      "h": 55836278865,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836278865)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296671313),
    {
      "t": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h,
      "n": "_resultBuffer",
      "d": 1704017,
      "h": 4296671313,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4296671313),
//--TRIMMABLE-BOUNDARY-START(8591638609),
    {
      "t": 1769553,
      "n": "_resultFlags",
      "d": 1704017,
      "h": 8591638609,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8591638609)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181573201),
    {
      "p": [
        {
          "n": "buffer",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h
        },
        {
          "n": "isCanceled",
          "p": 262145
        },
        {
          "n": "isCompleted",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1704017,
      "h": 17181573201,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181573201),
//--TRIMMABLE-BOUNDARY-START(12886605905),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1704017,
      "h": 12886605905,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886605905)
  ],
  "h": 1704017
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.ReadResult`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}ReadResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704017)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572945)
        $asm.$cls(`$sipl.SIP.PipeWriter`, ($self) => class PipeWriter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296540241)
            /*PipeWriterStream?*/ _stream = null;
            //--TRIMMABLE-BOUNDARY-END(4296540241)
            
            //--TRIMMABLE-BOUNDARY-START(34361311313)
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361311313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    this.Complete(exception);
                    return new $.$$.STT.ValueTask();
                }
                catch(ex)
                {
                    return new $.$$.STT.ValueTask().$ctor$5($.$$.STT.Task.FromException(ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361311313)
            
            //--TRIMMABLE-BOUNDARY-START(25771376721)
            /*bool */ get CanGetUnflushedBytes()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(25771376721)
            
            //--TRIMMABLE-BOUNDARY-START(77310984273)
            /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310984273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(77310984273)
            
            //--TRIMMABLE-BOUNDARY-START(17181442129)
            /*Stream */ AsStream(/*bool*/ leaveOpen)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181442129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._stream === null)
                {
                    this._stream = new $.$sipl.SIP.PipeWriterStream().$ctor$3(this, leaveOpen);
                }
                else if (leaveOpen)
                {
                    this._stream.LeaveOpen = leaveOpen;
                }
                return this._stream;
            }
            //--TRIMMABLE-BOUNDARY-END(17181442129)
            
            //--TRIMMABLE-BOUNDARY-START(42951245905)
            static /*PipeWriter */ Create(/*Stream*/ stream, /*StreamPipeWriterOptions?*/ writerOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951245905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sipl.SIP.StreamPipeWriter().$ctor$2(stream, writerOptions ?? $.$sipl.SIP.StreamPipeWriterOptions.s_default);
            }
            //--TRIMMABLE-BOUNDARY-END(42951245905)
            
            //--TRIMMABLE-BOUNDARY-START(85900918865)
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900918865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sm.SB.BuffersExtensions.Write($.$$.S.Byte, this, source.Span);
                return this.FlushAsync(cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(85900918865)
            
            //--TRIMMABLE-BOUNDARY-START(38656278609)
            /*Task *//*async*/  CopyFromAsync(/*Stream*/ source, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656278609);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    while(true)
                    {
                        let $t1, $r1;
                        let $t2, $r2;
                        /*Memory<byte>*/ let buffer = this.GetMemory(0);
                        /*int*/ let read = ($t1 = source.ReadAsync$2(buffer, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        if (read === 0)
                        {
                            break;
                        }
                        this.Advance(read);
                        /*FlushResult*/ let result = ($t2 = this.FlushAsync(cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        if (result.IsCanceled)
                        {
                            $.$sipl.SIP.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                        }
                        if (result.IsCompleted)
                        {
                            break;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38656278609)
            
            //--TRIMMABLE-BOUNDARY-START(81605951569)
            /*long */ get UnflushedBytes()
            {
                throw $.$sipl.SIP.ThrowHelper.CreateNotSupportedException_UnflushedBytes();
            }
            //--TRIMMABLE-BOUNDARY-END(81605951569)
            
            //--TRIMMABLE-BOUNDARY-START(4295294984)
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.Advance(int)
            SB$IBufferWriter$$$Advance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295294984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Advance(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295294984)
            
            //--TRIMMABLE-BOUNDARY-START(8590262280)
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.GetMemory(int)
            SB$IBufferWriter$$$GetMemory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetMemory(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590262280)
            
            //--TRIMMABLE-BOUNDARY-START(12885229576)
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.GetSpan(int)
            SB$IBufferWriter$$$GetSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetSpan(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885229576)
            
            //--TRIMMABLE-BOUNDARY-START(8591507537)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591507537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591507537)
            
            //--TRIMMABLE-BOUNDARY-START(8591507537)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591507537)
            
            static $h = 1572945;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771376721),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836147793,
        "f": 50331777
      },
      "n": "CanGetUnflushedBytes",
      "d": 1572945,
      "h": 25771376721,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(25771376721),
//--TRIMMABLE-BOUNDARY-START(81605951569),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426082385,
        "f": 50331777
      },
      "n": "UnflushedBytes",
      "d": 1572945,
      "h": 81605951569,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(81605951569)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066344017),
    {
      "r": 65537,
      "p": [
        {
          "n": "exception",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "Complete",
      "d": 1572945,
      "h": 30066344017,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30066344017),
//--TRIMMABLE-BOUNDARY-START(34361311313),
    {
      "r": 181338113,
      "p": [
        {
          "n": "exception",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "CompleteAsync",
      "d": 1572945,
      "h": 34361311313,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34361311313),
//--TRIMMABLE-BOUNDARY-START(21476409425),
    {
      "r": 65537,
      "n": "CancelPendingFlush",
      "d": 1572945,
      "h": 21476409425,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21476409425),
//--TRIMMABLE-BOUNDARY-START(77310984273),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$$($.$$.S.Exception, $.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "OnReaderCompleted",
      "d": 1572945,
      "h": 77310984273,
      "f": 16777345,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "OnReaderCompleted has been deprecated and may not be invoked on all implementations of PipeWriter.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310984273),
//--TRIMMABLE-BOUNDARY-START(47246213201),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "FlushAsync",
      "d": 1572945,
      "h": 47246213201,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47246213201),
//--TRIMMABLE-BOUNDARY-START(12886474833),
    {
      "r": 65537,
      "p": [
        {
          "n": "bytes",
          "p": 655361
        }
      ],
      "n": "Advance",
      "d": 1572945,
      "h": 12886474833,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886474833),
//--TRIMMABLE-BOUNDARY-START(68721049681),
    {
      "r": $.$$.S.Memory$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetMemory",
      "d": 1572945,
      "h": 68721049681,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(68721049681),
//--TRIMMABLE-BOUNDARY-START(73016016977),
    {
      "r": $.$$.S.Span$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetSpan",
      "d": 1572945,
      "h": 73016016977,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(73016016977),
//--TRIMMABLE-BOUNDARY-START(17181442129),
    {
      "r": 95748097,
      "p": [
        {
          "n": "leaveOpen",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "AsStream",
      "d": 1572945,
      "h": 17181442129,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181442129),
//--TRIMMABLE-BOUNDARY-START(42951245905),
    {
      "r": 1572945,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "writerOptions",
          "p": 2162769,
          "f": 65
        }
      ],
      "n": "Create",
      "d": 1572945,
      "h": 42951245905,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951245905),
//--TRIMMABLE-BOUNDARY-START(85900918865),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "d": 1572945,
      "h": 85900918865,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85900918865),
//--TRIMMABLE-BOUNDARY-START(38656278609),
    {
      "r": 178454529,
      "p": [
        {
          "n": "source",
          "p": 95748097
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "CopyFromAsync",
      "d": 1572945,
      "h": 38656278609,
      "f": 16781456
    },
//--TRIMMABLE-BOUNDARY-END(38656278609)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296540241),
    {
      "t": 1638481,
      "n": "_stream",
      "d": 1572945,
      "h": 4296540241,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296540241)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591507537),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1572945,
      "h": 8591507537,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591507537)
  ],
  "h": 1572945
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.SB.IBufferWriter$$($.$$.S.Byte) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeWriter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572945)
        
        

        //--TRIMMABLE-BOUNDARY-START(393297)
        $asm.$str(`$sipl.SIP.FlushResult`, ($self) => class FlushResult extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295360593)
            /*ResultFlags*/ _resultFlags = 0;
            //--TRIMMABLE-BOUNDARY-END(4295360593)
            
            //--TRIMMABLE-BOUNDARY-START(12885295185)
            $ctor$3(/*bool*/ isCanceled, /*bool*/ isCompleted)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295185);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._resultFlags = 0/*ResultFlags.None*/;
                    if (isCanceled)
                    {
                        this._resultFlags |= 1/*ResultFlags.Canceled*/;
                    }
                    if (isCompleted)
                    {
                        this._resultFlags |= 2/*ResultFlags.Completed*/;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885295185)
            
            //--TRIMMABLE-BOUNDARY-START(34360131665)
            /*bool */ get IsCanceled()
            {
                return (this._resultFlags & 1/*ResultFlags.Canceled*/) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(34360131665)
            
            //--TRIMMABLE-BOUNDARY-START(38655098961)
            /*bool */ get IsCompleted()
            {
                return (this._resultFlags & 2/*ResultFlags.Completed*/) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(38655098961)
            
            //--TRIMMABLE-BOUNDARY-START(8590327889)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327889)
            
            //--TRIMMABLE-BOUNDARY-START(8590327889)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590327889)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resultFlags = this._resultFlags;
                return copy;
            }
            static $h = 393297;
            static $z = 1;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360131665),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475229777,
        "f": 50331649
      },
      "n": "IsCanceled",
      "d": 393297,
      "h": 34360131665,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360131665),
//--TRIMMABLE-BOUNDARY-START(38655098961),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065164369,
        "f": 50331649
      },
      "n": "IsCompleted",
      "d": 393297,
      "h": 38655098961,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655098961)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295360593),
    {
      "t": 1769553,
      "n": "_resultFlags",
      "d": 393297,
      "h": 4295360593,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295360593)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885295185),
    {
      "p": [
        {
          "n": "isCanceled",
          "p": 262145
        },
        {
          "n": "isCompleted",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393297,
      "h": 12885295185,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295185),
//--TRIMMABLE-BOUNDARY-START(8590327889),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393297,
      "h": 8590327889,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327889)
  ],
  "h": 393297
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.FlushResult`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}FlushResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393297)
        
        

        //--TRIMMABLE-BOUNDARY-START(589905)
        $asm.$cls(`$sipl.SIP.Pipe`, ($self) => class Pipe extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(655441)
            static $_DefaultPipeReader;
            static get DefaultPipeReader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sipl.SIP.Pipe;
                return $cls.$_DefaultPipeReader ??= $asm.$ncls(`$sipl.SIP.Pipe.DefaultPipeReader`, ($self) => class DefaultPipeReader extends $.$sipl.SIP.PipeReader
                {
                    //--TRIMMABLE-BOUNDARY-START(4295622737)
                    /*Pipe*/ _pipe = null;
                    //--TRIMMABLE-BOUNDARY-END(4295622737)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590590033)
                    $ctor$2(/*Pipe*/ pipe)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590590033);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._pipe = pipe;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590590033)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835230289)
                    /*bool */ TryRead(/*out ReadResult*/ result)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(55835230289);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.TryRead(result);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835230289)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245295697)
                    /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(47245295697);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.ReadAsync(cancellationToken);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245295697)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540262993)
                    /*ValueTask<ReadResult> */ ReadAtLeastAsyncCore(/*int*/ minimumBytes, /*CancellationToken*/ cancellationToken)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(51540262993);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.ReadAtLeastAsync(minimumBytes, cancellationToken);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540262993)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180524625)
                    /*void */ AdvanceTo$1(/*SequencePosition*/ consumed)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180524625);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.AdvanceReader$1($.$ref(() => consumed, ));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180524625)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557329)
                    /*void */ AdvanceTo(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885557329);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.AdvanceReader($.$ref(() => consumed, ), $.$ref(() => examined, ));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885557329)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475491921)
                    /*void */ CancelPendingRead()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475491921);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.CancelPendingRead();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475491921)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770459217)
                    /*void */ Complete(/*Exception?*/ exception)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770459217);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.CompleteReader(exception);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770459217)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950328401)
                    /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(42950328401);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.OnWriterCompleted(callback, state);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950328401)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360393809)
                    /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34360393809);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.GetReadAsyncStatus();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360393809)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065426513)
                    /*ReadResult */ GetResult(/*short*/ token)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065426513);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.GetReadAsyncResult();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065426513)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655361105)
                    /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38655361105);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.OnReadAsyncCompleted(continuation, state, flags);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655361105)
                    
                    //--TRIMMABLE-BOUNDARY-START(8767799297)
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.GetStatus(short)
                    STTS$IValueTaskSource$$$GetStatus()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8767799297);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetStatus(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8767799297)
                    
                    //--TRIMMABLE-BOUNDARY-START(13062766593)
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
                    STTS$IValueTaskSource$$$OnCompleted()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(13062766593);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.OnCompleted(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(13062766593)
                    
                    //--TRIMMABLE-BOUNDARY-START(4472832001)
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.GetResult(short)
                    STTS$IValueTaskSource$$$GetResult()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4472832001);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetResult(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4472832001)
                    
                    static $h = 655441;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$sipl.SIP.PipeReader; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835230289),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": 1704017,
          "f": 2
        }
      ],
      "n": "TryRead",
      "d": 655441,
      "h": 55835230289,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835230289),
//--TRIMMABLE-BOUNDARY-START(47245295697),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "d": 655441,
      "h": 47245295697,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245295697),
//--TRIMMABLE-BOUNDARY-START(51540262993),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult).$h,
      "p": [
        {
          "n": "minimumBytes",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAtLeastAsyncCore",
      "d": 655441,
      "h": 51540262993,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540262993),
//--TRIMMABLE-BOUNDARY-START(17180524625),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumed",
          "p": 1179656
        }
      ],
      "n": "AdvanceTo",
      "o": "@$1",
      "d": 655441,
      "h": 17180524625,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180524625),
//--TRIMMABLE-BOUNDARY-START(12885557329),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumed",
          "p": 1179656
        },
        {
          "n": "examined",
          "p": 1179656
        }
      ],
      "n": "AdvanceTo",
      "d": 655441,
      "h": 12885557329,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885557329),
//--TRIMMABLE-BOUNDARY-START(21475491921),
    {
      "r": 65537,
      "n": "CancelPendingRead",
      "d": 655441,
      "h": 21475491921,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475491921),
//--TRIMMABLE-BOUNDARY-START(25770459217),
    {
      "r": 65537,
      "p": [
        {
          "n": "exception",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "Complete",
      "d": 655441,
      "h": 25770459217,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770459217),
//--TRIMMABLE-BOUNDARY-START(42950328401),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$$($.$$.S.Exception, $.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "OnWriterCompleted",
      "d": 655441,
      "h": 42950328401,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950328401),
//--TRIMMABLE-BOUNDARY-START(34360393809),
    {
      "r": 178126849,
      "p": [
        {
          "n": "token",
          "p": 524289
        }
      ],
      "n": "GetStatus",
      "d": 655441,
      "h": 34360393809,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360393809),
//--TRIMMABLE-BOUNDARY-START(30065426513),
    {
      "r": 1704017,
      "p": [
        {
          "n": "token",
          "p": 524289
        }
      ],
      "n": "GetResult",
      "d": 655441,
      "h": 30065426513,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065426513),
//--TRIMMABLE-BOUNDARY-START(38655361105),
    {
      "r": 65537,
      "p": [
        {
          "n": "continuation",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "token",
          "p": 524289
        },
        {
          "n": "flags",
          "p": 178061313
        }
      ],
      "n": "OnCompleted",
      "d": 655441,
      "h": 38655361105,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655361105)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622737),
    {
      "t": 589905,
      "n": "_pipe",
      "d": 655441,
      "h": 4295622737,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622737)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590590033),
    {
      "p": [
        {
          "n": "pipe",
          "p": 589905
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655441,
      "h": 8590590033,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590590033)
  ],
  "d": 589905,
  "h": 655441
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.STTS.IValueTaskSource$$($.$sipl.SIP.ReadResult) ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.Pipe+DefaultPipeReader`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}Pipe${separator}DefaultPipeReader`; }
                }, $cls, ($v) => $cls.$_DefaultPipeReader = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655441)
            
            //--TRIMMABLE-BOUNDARY-START(720977)
            static $_DefaultPipeWriter;
            static get DefaultPipeWriter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sipl.SIP.Pipe;
                return $cls.$_DefaultPipeWriter ??= $asm.$ncls(`$sipl.SIP.Pipe.DefaultPipeWriter`, ($self) => class DefaultPipeWriter extends $.$sipl.SIP.PipeWriter
                {
                    //--TRIMMABLE-BOUNDARY-START(4295688273)
                    /*Pipe*/ _pipe = null;
                    //--TRIMMABLE-BOUNDARY-END(4295688273)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590655569)
                    $ctor$2(/*Pipe*/ pipe)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590655569);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._pipe = pipe;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590655569)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770524753)
                    /*void */ Complete(/*Exception?*/ exception)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770524753);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.CompleteWriter(exception);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770524753)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180590161)
                    /*void */ CancelPendingFlush()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180590161);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.CancelPendingFlush();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180590161)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475557457)
                    /*bool */ get CanGetUnflushedBytes()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475557457)
                    
                    //--TRIMMABLE-BOUNDARY-START(73015165009)
                    /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(73015165009);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.OnReaderCompleted(callback, state);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(73015165009)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065492049)
                    /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065492049);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.FlushAsync(cancellationToken);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065492049)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885622865)
                    /*void */ Advance(/*int*/ bytes)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885622865);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.Advance(bytes);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885622865)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540328529)
                    /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(51540328529);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.GetMemory(sizeHint);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540328529)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130263121)
                    /*Span<byte> */ GetSpan(/*int*/ sizeHint)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(60130263121);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.GetSpan(sizeHint);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130263121)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425230417)
                    /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(64425230417);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.GetFlushAsyncStatus();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425230417)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835295825)
                    /*FlushResult */ GetResult(/*short*/ token)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(55835295825);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.GetFlushAsyncResult();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835295825)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720197713)
                    /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(68720197713);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._pipe.OnFlushAsyncCompleted(continuation, state, flags);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720197713)
                    
                    //--TRIMMABLE-BOUNDARY-START(77310132305)
                    /*long */ get UnflushedBytes()
                    {
                        return this._pipe.GetUnflushedBytes();
                    }
                    //--TRIMMABLE-BOUNDARY-END(77310132305)
                    
                    //--TRIMMABLE-BOUNDARY-START(81605099601)
                    /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81605099601);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._pipe.WriteAsync(source, cancellationToken);
                    }
                    //--TRIMMABLE-BOUNDARY-END(81605099601)
                    
                    //--TRIMMABLE-BOUNDARY-START(8767799297)
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.GetStatus(short)
                    STTS$IValueTaskSource$$$GetStatus()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8767799297);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetStatus(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8767799297)
                    
                    //--TRIMMABLE-BOUNDARY-START(13062766593)
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
                    STTS$IValueTaskSource$$$OnCompleted()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(13062766593);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.OnCompleted(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(13062766593)
                    
                    //--TRIMMABLE-BOUNDARY-START(4472832001)
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.GetResult(short)
                    STTS$IValueTaskSource$$$GetResult()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4472832001);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetResult(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4472832001)
                    
                    static $h = 720977;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$sipl.SIP.PipeWriter; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475557457),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655426641,
        "f": 50364417
      },
      "n": "CanGetUnflushedBytes",
      "d": 720977,
      "h": 21475557457,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475557457),
//--TRIMMABLE-BOUNDARY-START(77310132305),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245361233,
        "f": 50364417
      },
      "n": "UnflushedBytes",
      "d": 720977,
      "h": 77310132305,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77310132305)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770524753),
    {
      "r": 65537,
      "p": [
        {
          "n": "exception",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "Complete",
      "d": 720977,
      "h": 25770524753,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770524753),
//--TRIMMABLE-BOUNDARY-START(17180590161),
    {
      "r": 65537,
      "n": "CancelPendingFlush",
      "d": 720977,
      "h": 17180590161,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180590161),
//--TRIMMABLE-BOUNDARY-START(73015165009),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$$($.$$.S.Exception, $.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "OnReaderCompleted",
      "d": 720977,
      "h": 73015165009,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015165009),
//--TRIMMABLE-BOUNDARY-START(30065492049),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "FlushAsync",
      "d": 720977,
      "h": 30065492049,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065492049),
//--TRIMMABLE-BOUNDARY-START(12885622865),
    {
      "r": 65537,
      "p": [
        {
          "n": "bytes",
          "p": 655361
        }
      ],
      "n": "Advance",
      "d": 720977,
      "h": 12885622865,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885622865),
//--TRIMMABLE-BOUNDARY-START(51540328529),
    {
      "r": $.$$.S.Memory$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetMemory",
      "d": 720977,
      "h": 51540328529,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540328529),
//--TRIMMABLE-BOUNDARY-START(60130263121),
    {
      "r": $.$$.S.Span$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetSpan",
      "d": 720977,
      "h": 60130263121,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130263121),
//--TRIMMABLE-BOUNDARY-START(64425230417),
    {
      "r": 178126849,
      "p": [
        {
          "n": "token",
          "p": 524289
        }
      ],
      "n": "GetStatus",
      "d": 720977,
      "h": 64425230417,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425230417),
//--TRIMMABLE-BOUNDARY-START(55835295825),
    {
      "r": 393297,
      "p": [
        {
          "n": "token",
          "p": 524289
        }
      ],
      "n": "GetResult",
      "d": 720977,
      "h": 55835295825,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835295825),
//--TRIMMABLE-BOUNDARY-START(68720197713),
    {
      "r": 65537,
      "p": [
        {
          "n": "continuation",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "token",
          "p": 524289
        },
        {
          "n": "flags",
          "p": 178061313
        }
      ],
      "n": "OnCompleted",
      "d": 720977,
      "h": 68720197713,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720197713),
//--TRIMMABLE-BOUNDARY-START(81605099601),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "d": 720977,
      "h": 81605099601,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605099601)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688273),
    {
      "t": 589905,
      "n": "_pipe",
      "d": 720977,
      "h": 4295688273,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688273)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590655569),
    {
      "p": [
        {
          "n": "pipe",
          "p": 589905
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720977,
      "h": 8590655569,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590655569)
  ],
  "d": 589905,
  "h": 720977
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sm.SB.IBufferWriter$$($.$$.S.Byte), $.$$.STTS.IValueTaskSource$$($.$sipl.SIP.FlushResult) ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.Pipe+DefaultPipeWriter`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}Pipe${separator}DefaultPipeWriter`; }
                }, $cls, ($v) => $cls.$_DefaultPipeWriter = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(720977)
            
            //--TRIMMABLE-BOUNDARY-START(408022483025)
            /*Action<object?>*/ static s_signalReaderAwaitable = null;
            //--TRIMMABLE-BOUNDARY-END(408022483025)
            
            //--TRIMMABLE-BOUNDARY-START(412317450321)
            /*Action<object?>*/ static s_signalWriterAwaitable = null;
            //--TRIMMABLE-BOUNDARY-END(412317450321)
            
            //--TRIMMABLE-BOUNDARY-START(399432548433)
            /*Action<object?>*/ static s_invokeCompletionCallbacks = null;
            //--TRIMMABLE-BOUNDARY-END(399432548433)
            
            //--TRIMMABLE-BOUNDARY-START(395137581137)
            /*ContextCallback*/ static s_executionContextRawCallback = null;
            //--TRIMMABLE-BOUNDARY-END(395137581137)
            
            //--TRIMMABLE-BOUNDARY-START(420907384913)
            /*SendOrPostCallback*/ static s_syncContextExecutionContextCallback = null;
            //--TRIMMABLE-BOUNDARY-END(420907384913)
            
            //--TRIMMABLE-BOUNDARY-START(416612417617)
            /*SendOrPostCallback*/ static s_syncContextExecuteWithoutExecutionContextCallback = null;
            //--TRIMMABLE-BOUNDARY-END(416612417617)
            
            //--TRIMMABLE-BOUNDARY-START(403727515729)
            /*Action<object?>*/ static s_scheduleWithExecutionContextCallback = null;
            //--TRIMMABLE-BOUNDARY-END(403727515729)
            
            //--TRIMMABLE-BOUNDARY-START(4295557201)
            /*BufferSegmentStack*/ _bufferSegmentPool;
            //--TRIMMABLE-BOUNDARY-END(4295557201)
            
            //--TRIMMABLE-BOUNDARY-START(30065360977)
            /*DefaultPipeReader*/ _reader = null;
            //--TRIMMABLE-BOUNDARY-END(30065360977)
            
            //--TRIMMABLE-BOUNDARY-START(73015033937)
            /*DefaultPipeWriter*/ _writer = null;
            //--TRIMMABLE-BOUNDARY-END(73015033937)
            
            //--TRIMMABLE-BOUNDARY-START(25770393681)
            /*PipeOptions*/ _options = null;
            //--TRIMMABLE-BOUNDARY-END(25770393681)
            
            //--TRIMMABLE-BOUNDARY-START(60130132049)
            /*object*/ _sync = null;
            //--TRIMMABLE-BOUNDARY-END(60130132049)
            
            //--TRIMMABLE-BOUNDARY-START(446677188689)
            /*bool */ get UseSynchronizationContext()
            {
                return this._options.UseSynchronizationContext;
            }
            //--TRIMMABLE-BOUNDARY-END(446677188689)
            
            //--TRIMMABLE-BOUNDARY-START(322123137105)
            /*int */ get MinimumSegmentSize()
            {
                return this._options.MinimumSegmentSize;
            }
            //--TRIMMABLE-BOUNDARY-END(322123137105)
            
            //--TRIMMABLE-BOUNDARY-START(343597973585)
            /*long */ get PauseWriterThreshold()
            {
                return this._options.PauseWriterThreshold;
            }
            //--TRIMMABLE-BOUNDARY-END(343597973585)
            
            //--TRIMMABLE-BOUNDARY-START(386547646545)
            /*long */ get ResumeWriterThreshold()
            {
                return this._options.ResumeWriterThreshold;
            }
            //--TRIMMABLE-BOUNDARY-END(386547646545)
            
            //--TRIMMABLE-BOUNDARY-START(369367777361)
            /*PipeScheduler */ get ReaderScheduler()
            {
                return this._options.ReaderScheduler;
            }
            //--TRIMMABLE-BOUNDARY-END(369367777361)
            
            //--TRIMMABLE-BOUNDARY-START(468152025169)
            /*PipeScheduler */ get WriterScheduler()
            {
                return this._options.WriterScheduler;
            }
            //--TRIMMABLE-BOUNDARY-END(468152025169)
            
            //--TRIMMABLE-BOUNDARY-START(433792286801)
            /*object */ get SyncObj()
            {
                return this._sync;
            }
            //--TRIMMABLE-BOUNDARY-END(433792286801)
            
            //--TRIMMABLE-BOUNDARY-START(64425099345)
            /*long*/ _unconsumedBytes = 0n;
            //--TRIMMABLE-BOUNDARY-END(64425099345)
            
            //--TRIMMABLE-BOUNDARY-START(68720066641)
            /*long*/ _unflushedBytes = 0n;
            //--TRIMMABLE-BOUNDARY-END(68720066641)
            
            //--TRIMMABLE-BOUNDARY-START(34360328273)
            /*PipeAwaitable*/ _readerAwaitable;
            //--TRIMMABLE-BOUNDARY-END(34360328273)
            
            //--TRIMMABLE-BOUNDARY-START(77310001233)
            /*PipeAwaitable*/ _writerAwaitable;
            //--TRIMMABLE-BOUNDARY-END(77310001233)
            
            //--TRIMMABLE-BOUNDARY-START(81604968529)
            /*PipeCompletion*/ _writerCompletion;
            //--TRIMMABLE-BOUNDARY-END(81604968529)
            
            //--TRIMMABLE-BOUNDARY-START(38655295569)
            /*PipeCompletion*/ _readerCompletion;
            //--TRIMMABLE-BOUNDARY-END(38655295569)
            
            //--TRIMMABLE-BOUNDARY-START(12885491793)
            /*long*/ _lastExaminedIndex = -1n;
            //--TRIMMABLE-BOUNDARY-END(12885491793)
            
            //--TRIMMABLE-BOUNDARY-START(42950262865)
            /*BufferSegment?*/ _readHead = null;
            //--TRIMMABLE-BOUNDARY-END(42950262865)
            
            //--TRIMMABLE-BOUNDARY-START(47245230161)
            /*int*/ _readHeadIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(47245230161)
            
            //--TRIMMABLE-BOUNDARY-START(8590524497)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(8590524497)
            
            //--TRIMMABLE-BOUNDARY-START(51540197457)
            /*BufferSegment?*/ _readTail = null;
            //--TRIMMABLE-BOUNDARY-END(51540197457)
            
            //--TRIMMABLE-BOUNDARY-START(55835164753)
            /*int*/ _readTailIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(55835164753)
            
            //--TRIMMABLE-BOUNDARY-START(17180459089)
            /*int*/ _minimumReadBytes = 0;
            //--TRIMMABLE-BOUNDARY-END(17180459089)
            
            //--TRIMMABLE-BOUNDARY-START(85899935825)
            /*BufferSegment?*/ _writingHead = null;
            //--TRIMMABLE-BOUNDARY-END(85899935825)
            
            //--TRIMMABLE-BOUNDARY-START(94489870417)
            /*Memory<byte>*/ _writingHeadMemory;
            //--TRIMMABLE-BOUNDARY-END(94489870417)
            
            //--TRIMMABLE-BOUNDARY-START(90194903121)
            /*int*/ _writingHeadBytesBuffered = 0;
            //--TRIMMABLE-BOUNDARY-END(90194903121)
            
            //--TRIMMABLE-BOUNDARY-START(21475426385)
            /*PipeOperationState*/ _operationState;
            //--TRIMMABLE-BOUNDARY-END(21475426385)
            
            //--TRIMMABLE-BOUNDARY-START(317828169809)
            /*long */ get Length()
            {
                return this._unconsumedBytes;
            }
            //--TRIMMABLE-BOUNDARY-END(317828169809)
            
            //--TRIMMABLE-BOUNDARY-START(103079805009)
            $ctor$1()
            {
                this.$ctor$2($.$sipl.SIP.PipeOptions.Default);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079805009);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(103079805009)
            
            //--TRIMMABLE-BOUNDARY-START(107374772305)
            $ctor$2(/*PipeOptions*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374772305);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (options === null)
                    {
                        $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this._bufferSegmentPool = new $.$sipl.SIP.BufferSegmentStack().$ctor$3(options.InitialSegmentPoolSize);
                    this._operationState = new $.$sipl.SIP.PipeOperationState();
                    this._readerCompletion = new $.$sipl.SIP.PipeCompletion();
                    this._writerCompletion = new $.$sipl.SIP.PipeCompletion();
                    this._options = options;
                    this._readerAwaitable = new $.$sipl.SIP.PipeAwaitable().$ctor$3(false, this.UseSynchronizationContext);
                    this._writerAwaitable = new $.$sipl.SIP.PipeAwaitable().$ctor$3(true, this.UseSynchronizationContext);
                    this._reader = new $.$sipl.SIP.Pipe.DefaultPipeReader().$ctor$2(this);
                    this._writer = new $.$sipl.SIP.Pipe.DefaultPipeWriter().$ctor$2(this);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(107374772305)
            
            //--TRIMMABLE-BOUNDARY-START(382252679249)
            /*void */ ResetState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252679249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._readerCompletion.Reset();
                this._writerCompletion.Reset();
                this._readerAwaitable = new $.$sipl.SIP.PipeAwaitable().$ctor$3(false, this.UseSynchronizationContext);
                this._writerAwaitable = new $.$sipl.SIP.PipeAwaitable().$ctor$3(true, this.UseSynchronizationContext);
                this._readTailIndex = 0;
                this._readHeadIndex = 0;
                this._lastExaminedIndex = BigInt(-1);
                this._unflushedBytes = 0n;
                this._unconsumedBytes = 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(382252679249)
            
            //--TRIMMABLE-BOUNDARY-START(287763398737)
            /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763398737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateWriteHeadIfNeeded(sizeHint);
                return this._writingHeadMemory;
            }
            //--TRIMMABLE-BOUNDARY-END(287763398737)
            
            //--TRIMMABLE-BOUNDARY-START(309238235217)
            /*Span<byte> */ GetSpan(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238235217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateWriteHeadIfNeeded(sizeHint);
                return this._writingHeadMemory.Span;
            }
            //--TRIMMABLE-BOUNDARY-END(309238235217)
            
            //--TRIMMABLE-BOUNDARY-START(137439543377)
            /*void */ AllocateWriteHeadIfNeeded(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439543377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._operationState.IsWritingActive || this._writingHeadMemory.Length === 0 || this._writingHeadMemory.Length < sizeHint)
                {
                    this.AllocateWriteHeadSynchronized(sizeHint);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439543377)
            
            //--TRIMMABLE-BOUNDARY-START(141734510673)
            /*void */ AllocateWriteHeadSynchronized(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734510673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        this._operationState.BeginWrite();
                        if (this._writingHead === null)
                        {
                            /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                            this._writingHead = this._readHead = this._readTail = newSegment;
                            this._lastExaminedIndex = 0n;
                        }
                        else 
                        {
                            /*int*/ let bytesLeftInBuffer = this._writingHeadMemory.Length;
                            if (bytesLeftInBuffer === 0 || bytesLeftInBuffer < sizeHint)
                            {
                                if (this._writingHeadBytesBuffered > 0)
                                {
                                    this._writingHead.End += this._writingHeadBytesBuffered;
                                    this._writingHeadBytesBuffered = 0;
                                }
                                if (this._writingHead.Length === 0)
                                {
                                    this._writingHead.ResetMemory();
                                    this.RentMemory(this._writingHead, sizeHint);
                                }
                                else 
                                {
                                    /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                                    this._writingHead.SetNext(newSegment);
                                    this._writingHead = newSegment;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734510673)
            
            //--TRIMMABLE-BOUNDARY-START(133144576081)
            /*BufferSegment */ AllocateSegment(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144576081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*BufferSegment*/ let newSegment = this.CreateSegmentUnsynchronized();
                this.RentMemory(newSegment, sizeHint);
                return newSegment;
            }
            //--TRIMMABLE-BOUNDARY-END(133144576081)
            
            //--TRIMMABLE-BOUNDARY-START(373662744657)
            /*void */ RentMemory(/*BufferSegment*/ segment, /*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662744657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(segment.MemoryOwner === null, "segment.MemoryOwner is null");
                $.$$.SD.Debug.Assert$4(sizeHint >= 0, "sizeHint >= 0");
                /*MemoryPool<byte>?*/ let pool = null;
                /*int*/ let maxSize = -1;
                if (!this._options.IsDefaultSharedMemoryPool)
                {
                    pool = this._options.Pool;
                    maxSize = pool.MaxBufferSize;
                }
                if (sizeHint <= maxSize)
                {
                    segment.SetOwnedMemory(pool.Rent(this.GetSegmentSize(sizeHint, maxSize)));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(sizeHint, 2147483647);
                    segment.SetOwnedMemory$1($.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(sizeToRequest));
                }
                this._writingHeadMemory = segment.AvailableMemory;
            }
            //--TRIMMABLE-BOUNDARY-END(373662744657)
            
            //--TRIMMABLE-BOUNDARY-START(304943267921)
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943267921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                sizeHint = $.$$.S.Math.Max$4(this.MinimumSegmentSize, sizeHint);
                /*int*/ let adjustedToMaximumSize = $.$$.S.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            //--TRIMMABLE-BOUNDARY-END(304943267921)
            
            //--TRIMMABLE-BOUNDARY-START(171799281745)
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799281745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.SIP.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.SIP.BufferSegment().$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(171799281745)
            
            //--TRIMMABLE-BOUNDARY-START(390842613841)
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842613841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(segment !== this._readHead, "Returning _readHead segment that's in use!");
                $.$$.SD.Debug.Assert$4(segment !== this._readTail, "Returning _readTail segment that's in use!");
                $.$$.SD.Debug.Assert$4(segment !== this._writingHead, "Returning _writingHead segment that's in use!");
                if (this._bufferSegmentPool.Count < this._options.MaxSegmentPoolSize)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(390842613841)
            
            //--TRIMMABLE-BOUNDARY-START(154619412561)
            /*bool */ CommitUnsynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619412561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._operationState.EndWrite();
                if (this._unflushedBytes === 0n)
                {
                    return false;
                }
                $.$$.SD.Debug.Assert$4(this._writingHead !== null, "_writingHead != null");
                this._writingHead.End += this._writingHeadBytesBuffered;
                this._readTail = this._writingHead;
                this._readTailIndex = this._writingHead.End;
                /*long*/ let oldLength = this._unconsumedBytes;
                this._unconsumedBytes += this._unflushedBytes;
                /*bool*/ let resumeReader = true;
                if (this._unconsumedBytes < BigInt(this._minimumReadBytes))
                {
                    resumeReader = false;
                }
                else if (this.PauseWriterThreshold > 0n && oldLength < this.PauseWriterThreshold && this._unconsumedBytes >= this.PauseWriterThreshold && !this._readerCompletion.IsCompleted)
                {
                    this._writerAwaitable.SetUncompleted();
                }
                this._unflushedBytes = 0n;
                this._writingHeadBytesBuffered = 0;
                return resumeReader;
            }
            //--TRIMMABLE-BOUNDARY-END(154619412561)
            
            //--TRIMMABLE-BOUNDARY-START(111669739601)
            /*void */ Advance(/*int*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669739601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        if ((bytes >>> 0) > (this._writingHeadMemory.Length >>> 0))
                        {
                            $.$sipl.SIP.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.bytes*/);
                        }
                        if (this._readerCompletion.IsCompleted)
                        {
                            return;
                        }
                        this.AdvanceCore(bytes);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669739601)
            
            //--TRIMMABLE-BOUNDARY-START(115964706897)
            /*void */ AdvanceCore(/*int*/ bytesWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._unflushedBytes += BigInt(bytesWritten);
                this._writingHeadBytesBuffered += bytesWritten;
                this._writingHeadMemory = this._writingHeadMemory.Slice$1(bytesWritten);
            }
            //--TRIMMABLE-BOUNDARY-END(115964706897)
            
            //--TRIMMABLE-BOUNDARY-START(184684183633)
            /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684183633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult))().$ctor$5($.$$.STT.Task.FromCanceled$3($.$sipl.SIP.FlushResult, cancellationToken));
                }
                /*CompletionData*/ let completionData;
                /*ValueTask<FlushResult>*/ let result;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        this.PrepareFlushUnsynchronized($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.SIP.CompletionData), $.$ref(() => result, ($v) => result = $v, $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult)), cancellationToken);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.SIP.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(184684183633)
            
            //--TRIMMABLE-BOUNDARY-START(347892940881)
            /*void */ PrepareFlushUnsynchronized(/*out CompletionData*/ completionData, /*out ValueTask<FlushResult>*/ result, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892940881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let completeReader = this.CommitUnsynchronized();
                this._writerAwaitable.BeginOperation(cancellationToken, $.$sipl.SIP.Pipe.s_signalWriterAwaitable, this);
                if (this._writerAwaitable.IsCompleted)
                {
                    /*FlushResult*/ let flushResult = new $.$sipl.SIP.FlushResult();
                    this.GetFlushResult($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sipl.SIP.FlushResult, () => flushResult, ($v) => flushResult = $v, null, true));
                    result.$v = new ($.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult))().$ctor$6($.$clone(flushResult));
                }
                else 
                {
                    result.$v = new ($.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult))().$ctor$4(this._writer, 0);
                }
                if (completeReader)
                {
                    this._readerAwaitable.Complete(completionData);
                }
                else 
                {
                    completionData.$v = new $.$sipl.SIP.CompletionData();
                }
                $.$$.SD.Debug.Assert$4(this._writerAwaitable.IsCompleted || this._readerAwaitable.IsCompleted, "_writerAwaitable.IsCompleted || _readerAwaitable.IsCompleted");
            }
            //--TRIMMABLE-BOUNDARY-END(347892940881)
            
            //--TRIMMABLE-BOUNDARY-START(167504314449)
            /*void */ CompleteWriter(/*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504314449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CompletionData*/ let completionData;
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                /*bool*/ let readerCompleted;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        this.CommitUnsynchronized();
                        completionCallbacks = this._writerCompletion.TryComplete(exception);
                        this._readerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.SIP.CompletionData));
                        readerCompleted = this._readerCompletion.IsCompleted;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                if (readerCompleted)
                {
                    this.CompletePipe();
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.SIP.Pipe.ScheduleCallbacks(this.ReaderScheduler, completionCallbacks);
                }
                $.$sipl.SIP.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            //--TRIMMABLE-BOUNDARY-END(167504314449)
            
            //--TRIMMABLE-BOUNDARY-START(124554641489)
            /*void */ AdvanceReader$1(/*in SequencePosition*/ consumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554641489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AdvanceReader(consumed, consumed);
            }
            //--TRIMMABLE-BOUNDARY-END(124554641489)
            
            //--TRIMMABLE-BOUNDARY-START(120259674193)
            /*void */ AdvanceReader(/*in SequencePosition*/ consumed, /*in SequencePosition*/ examined)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259674193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                this.AdvanceReader$2($.$cast(consumed.$v.GetObject(), $.$sipl.SIP.BufferSegment), consumed.$v.GetInteger(), $.$cast(examined.$v.GetObject(), $.$sipl.SIP.BufferSegment), examined.$v.GetInteger());
            }
            //--TRIMMABLE-BOUNDARY-END(120259674193)
            
            //--TRIMMABLE-BOUNDARY-START(128849608785)
            /*void */ AdvanceReader$2(/*BufferSegment?*/ consumedSegment, /*int*/ consumedIndex, /*BufferSegment?*/ examinedSegment, /*int*/ examinedIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849608785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (consumedSegment !== null && examinedSegment !== null && $.$sipl.SIP.BufferSegment.GetLength$1(consumedSegment, consumedIndex, examinedSegment, examinedIndex) < 0n)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition();
                }
                /*BufferSegment?*/ let returnStart = null;
                /*BufferSegment?*/ let returnEnd = null;
                /*CompletionData*/ let completionData = new $.$sipl.SIP.CompletionData();
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        /*var*/ let examinedEverything = false;
                        if (examinedSegment === this._readTail)
                        {
                            examinedEverything = examinedIndex === this._readTailIndex;
                        }
                        if (examinedSegment !== null && this._lastExaminedIndex >= 0n)
                        {
                            /*long*/ let examinedBytes = $.$sipl.SIP.BufferSegment.GetLength(this._lastExaminedIndex, examinedSegment, examinedIndex);
                            /*long*/ let oldLength = this._unconsumedBytes;
                            this._unconsumedBytes -= examinedBytes;
                            this._lastExaminedIndex = BigInt.asIntN(64, examinedSegment.RunningIndex + BigInt(examinedIndex));
                            $.$$.SD.Debug.Assert$4(this._unconsumedBytes >= 0n, "Length has gone negative");
                            $.$$.SD.Debug.Assert$4(this.ResumeWriterThreshold >= 1n, "ResumeWriterThreshold is less than 1");
                            if (oldLength >= this.ResumeWriterThreshold && this._unconsumedBytes < this.ResumeWriterThreshold)
                            {
                                $.$$.SD.Debug.Assert$4(examinedBytes > 0n, "examinedBytes > 0");
                                this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.SIP.CompletionData));
                            }
                        }
                        if (consumedSegment !== null)
                        {
                            if (this._readHead === null)
                            {
                                $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_AdvanceToInvalidCursor();
                                return;
                            }
                            returnStart = this._readHead;
                            returnEnd = consumedSegment;
                            /*void*/  function MoveReturnEndToNextBlock()
                            {
                                /*BufferSegment?*/ let nextBlock = returnEnd.NextSegment;
                                if (this._readTail === returnEnd)
                                {
                                    this._readTail = nextBlock;
                                    this._readTailIndex = 0;
                                }
                                this._readHead = nextBlock;
                                this._readHeadIndex = 0;
                                returnEnd = nextBlock;
                            }
                            if (consumedIndex === returnEnd.Length)
                            {
                                if (this._writingHead !== returnEnd)
                                {
                                    MoveReturnEndToNextBlock.call(this);
                                }
                                else if (this._writingHeadBytesBuffered === 0 && !this._operationState.IsWritingActive)
                                {
                                    this._writingHead = null;
                                    this._writingHeadMemory = new ($.$$.S.Memory$$($.$$.S.Byte))();
                                    MoveReturnEndToNextBlock.call(this);
                                }
                                else 
                                {
                                    this._readHead = consumedSegment;
                                    this._readHeadIndex = consumedIndex;
                                }
                            }
                            else 
                            {
                                this._readHead = consumedSegment;
                                this._readHeadIndex = consumedIndex;
                            }
                        }
                        if (examinedEverything && !this._writerCompletion.IsCompleted)
                        {
                            $.$$.SD.Debug.Assert$4(this._writerAwaitable.IsCompleted, "PipeWriter.FlushAsync isn't completed and will deadlock");
                            this._readerAwaitable.SetUncompleted();
                        }
                        while(returnStart !== null && returnStart !== returnEnd)
                        {
                            /*BufferSegment?*/ let next = returnStart.NextSegment;
                            returnStart.Reset();
                            this.ReturnSegmentUnsynchronized(returnStart);
                            returnStart = next;
                        }
                        this._operationState.EndRead();
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.SIP.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            //--TRIMMABLE-BOUNDARY-END(128849608785)
            
            //--TRIMMABLE-BOUNDARY-START(163209347153)
            /*void */ CompleteReader(/*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209347153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                /*CompletionData*/ let completionData;
                /*bool*/ let writerCompleted;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        if (this._operationState.IsReadingActive)
                        {
                            this._operationState.EndRead();
                        }
                        completionCallbacks = this._readerCompletion.TryComplete(exception);
                        this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.SIP.CompletionData));
                        writerCompleted = this._writerCompletion.IsCompleted;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                if (writerCompleted)
                {
                    this.CompletePipe();
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.SIP.Pipe.ScheduleCallbacks(this.WriterScheduler, completionCallbacks);
                }
                $.$sipl.SIP.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            //--TRIMMABLE-BOUNDARY-END(163209347153)
            
            //--TRIMMABLE-BOUNDARY-START(339303006289)
            /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303006289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (callback === null)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.callback*/);
                }
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        completionCallbacks = this._writerCompletion.AddCallback(callback, state);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.SIP.Pipe.ScheduleCallbacks(this.ReaderScheduler, completionCallbacks);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(339303006289)
            
            //--TRIMMABLE-BOUNDARY-START(150324445265)
            /*void */ CancelPendingRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324445265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CompletionData*/ let completionData;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        this._readerAwaitable.Cancel($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.SIP.CompletionData));
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.SIP.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            //--TRIMMABLE-BOUNDARY-END(150324445265)
            
            //--TRIMMABLE-BOUNDARY-START(146029477969)
            /*void */ CancelPendingFlush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029477969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CompletionData*/ let completionData;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        this._writerAwaitable.Cancel($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.SIP.CompletionData));
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.SIP.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            //--TRIMMABLE-BOUNDARY-END(146029477969)
            
            //--TRIMMABLE-BOUNDARY-START(335008038993)
            /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008038993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (callback === null)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.callback*/);
                }
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        completionCallbacks = this._readerCompletion.AddCallback(callback, state);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.SIP.Pipe.ScheduleCallbacks(this.WriterScheduler, completionCallbacks);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(335008038993)
            
            //--TRIMMABLE-BOUNDARY-START(356482875473)
            /*ValueTask<ReadResult> */ ReadAtLeastAsync(/*int*/ minimumBytes, /*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482875473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                if (token.IsCancellationRequested)
                {
                    return new ($.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult))().$ctor$5($.$$.STT.Task.FromCanceled$3($.$sipl.SIP.ReadResult, token));
                }
                /*CompletionData*/ let completionData = new $.$sipl.SIP.CompletionData();
                /*ValueTask<ReadResult>*/ let result;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        this._readerAwaitable.BeginOperation(token, $.$sipl.SIP.Pipe.s_signalReaderAwaitable, this);
                        if (this._readerAwaitable.IsCompleted)
                        {
                            /*ReadResult*/ let readResult;
                            this.GetReadResult($.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.SIP.ReadResult));
                            if (this._unconsumedBytes >= BigInt(minimumBytes) || readResult.IsCanceled || readResult.IsCompleted)
                            {
                                return new ($.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult))().$ctor$6(readResult);
                            }
                            this._readerAwaitable.SetUncompleted();
                            this._operationState.EndRead();
                            this._readerAwaitable.BeginOperation(token, $.$sipl.SIP.Pipe.s_signalReaderAwaitable, this);
                        }
                        if (!this._writerAwaitable.IsCompleted)
                        {
                            this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.SIP.CompletionData));
                        }
                        this._minimumReadBytes = minimumBytes;
                        result = new ($.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult))().$ctor$4(this._reader, 0);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.SIP.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, undefined, $.$sipl.SIP.CompletionData));
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(356482875473)
            
            //--TRIMMABLE-BOUNDARY-START(352187908177)
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187908177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                if (token.IsCancellationRequested)
                {
                    return new ($.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult))().$ctor$5($.$$.STT.Task.FromCanceled$3($.$sipl.SIP.ReadResult, token));
                }
                /*ValueTask<ReadResult>*/ let result;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        this._readerAwaitable.BeginOperation(token, $.$sipl.SIP.Pipe.s_signalReaderAwaitable, this);
                        if (this._readerAwaitable.IsCompleted)
                        {
                            /*ReadResult*/ let readResult;
                            this.GetReadResult($.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.SIP.ReadResult));
                            result = new ($.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult))().$ctor$6(readResult);
                        }
                        else 
                        {
                            result = new ($.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult))().$ctor$4(this._reader, 0);
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(352187908177)
            
            //--TRIMMABLE-BOUNDARY-START(438087254097)
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438087254097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        if (this._readerCompletion.IsCompleted)
                        {
                            $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                        }
                        if (this._unconsumedBytes > 0n || this._readerAwaitable.IsCompleted)
                        {
                            this.GetReadResult(result);
                            return true;
                        }
                        if (this._readerAwaitable.IsRunning)
                        {
                            $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                        }
                        this._operationState.BeginReadTentative();
                        result.$v = new $.$sipl.SIP.ReadResult();
                        return false;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(438087254097)
            
            //--TRIMMABLE-BOUNDARY-START(425202352209)
            static /*void */ ScheduleCallbacks(/*PipeScheduler*/ scheduler, /*PipeCompletionCallbacks*/ completionCallbacks)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202352209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(completionCallbacks !== null, "completionCallbacks != null");
                scheduler.UnsafeSchedule($.$sipl.SIP.Pipe.s_invokeCompletionCallbacks, completionCallbacks);
            }
            //--TRIMMABLE-BOUNDARY-END(425202352209)
            
            //--TRIMMABLE-BOUNDARY-START(442382221393)
            static /*void */ TrySchedule(/*PipeScheduler*/ scheduler, /*in CompletionData*/ completionData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442382221393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Action<object?>*/ let completion = completionData.$v.Completion;
                if (completion === null)
                {
                    return;
                }
                if (completionData.$v.SynchronizationContext === null && completionData.$v.ExecutionContext === null)
                {
                    scheduler.UnsafeSchedule(completion, completionData.$v.CompletionState);
                }
                else 
                {
                    $.$sipl.SIP.Pipe.ScheduleWithContext(scheduler, completionData);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(442382221393)
            
            //--TRIMMABLE-BOUNDARY-START(429497319505)
            static /*void */ ScheduleWithContext(/*PipeScheduler*/ scheduler, /*in CompletionData*/ completionData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429497319505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(completionData.$v.SynchronizationContext !== null || completionData.$v.ExecutionContext !== null, "completionData.SynchronizationContext != null || completionData.ExecutionContext != null");
                if (completionData.$v.SynchronizationContext === null)
                {
                    scheduler.UnsafeSchedule($.$sipl.SIP.Pipe.s_scheduleWithExecutionContextCallback, completionData.$v);
                }
                else 
                {
                    if (completionData.$v.ExecutionContext === null)
                    {
                        completionData.$v.SynchronizationContext.Post($.$sipl.SIP.Pipe.s_syncContextExecuteWithoutExecutionContextCallback, completionData.$v);
                    }
                    else 
                    {
                        completionData.$v.SynchronizationContext.Post($.$sipl.SIP.Pipe.s_syncContextExecutionContextCallback, completionData.$v);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(429497319505)
            
            //--TRIMMABLE-BOUNDARY-START(180389216337)
            static /*void */ ExecuteWithoutExecutionContext(/*object*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389216337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CompletionData*/ let completionData = $.$cast(state, $.$sipl.SIP.CompletionData);
                completionData.Completion.Invoke(completionData.CompletionState);
            }
            //--TRIMMABLE-BOUNDARY-END(180389216337)
            
            //--TRIMMABLE-BOUNDARY-START(176094249041)
            static /*void */ ExecuteWithExecutionContext(/*object*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094249041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CompletionData*/ let completionData = $.$cast(state, $.$sipl.SIP.CompletionData);
                $.$$.SD.Debug.Assert$4(completionData.ExecutionContext !== null, "completionData.ExecutionContext != null");
                $.$$.ST$1.ExecutionContext.Run(completionData.ExecutionContext, $.$sipl.SIP.Pipe.s_executionContextRawCallback, state);
            }
            //--TRIMMABLE-BOUNDARY-END(176094249041)
            
            //--TRIMMABLE-BOUNDARY-START(158914379857)
            /*void */ CompletePipe()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914379857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        this._disposed = true;
                        /*BufferSegment?*/ let segment = this._readHead ?? this._readTail;
                        while(segment !== null)
                        {
                            /*BufferSegment*/ let returnSegment = segment;
                            segment = segment.NextSegment;
                            returnSegment.Reset();
                        }
                        this._writingHead = null;
                        this._writingHeadMemory = new ($.$$.S.Memory$$($.$$.S.Byte))();
                        this._readHead = null;
                        this._readTail = null;
                        this._lastExaminedIndex = BigInt(-1);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914379857)
            
            //--TRIMMABLE-BOUNDARY-START(296353333329)
            /*ValueTaskSourceStatus */ GetReadAsyncStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353333329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readerAwaitable.IsCompleted)
                {
                    if (this._writerCompletion.IsFaulted)
                    {
                        return 2/*ValueTaskSourceStatus.Faulted*/;
                    }
                    return 1/*ValueTaskSourceStatus.Succeeded*/;
                }
                return 0/*ValueTaskSourceStatus.Pending*/;
            }
            //--TRIMMABLE-BOUNDARY-END(296353333329)
            
            //--TRIMMABLE-BOUNDARY-START(330713071697)
            /*void */ OnReadAsyncCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713071697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CompletionData*/ let completionData;
                /*bool*/ let doubleCompletion;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        this._readerAwaitable.OnCompleted(continuation, state, flags, $.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.SIP.CompletionData), $.$ref(() => doubleCompletion, ($v) => doubleCompletion = $v, $.$$.S.Boolean));
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                if (doubleCompletion)
                {
                    this.Writer.Complete($.$sipl.SIP.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation());
                }
                $.$sipl.SIP.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            //--TRIMMABLE-BOUNDARY-END(330713071697)
            
            //--TRIMMABLE-BOUNDARY-START(292058366033)
            /*ReadResult */ GetReadAsyncResult()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058366033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadResult*/ let result;
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = new $.$$.ST$1.CancellationTokenRegistration();
                /*CancellationToken*/ let cancellationToken = new $.$$.ST$1.CancellationToken();
                try
                {
                    //lock(SyncObj)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                        {
                            if (!this._readerAwaitable.IsCompleted)
                            {
                                $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_GetResultNotCompleted();
                            }
                            cancellationTokenRegistration = this._readerAwaitable.ReleaseCancellationTokenRegistration($.$ref(() => cancellationToken, ($v) => cancellationToken = $v, $.$$.ST$1.CancellationToken));
                            this.GetReadResult($.$ref(() => result, ($v) => result = $v, $.$sipl.SIP.ReadResult));
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this.SyncObj)
                    }
                }
                finally
                {
                    {
                        cancellationTokenRegistration.Dispose();
                    }
                }
                if (result.IsCanceled)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(292058366033)
            
            //--TRIMMABLE-BOUNDARY-START(300648300625)
            /*void */ GetReadResult(/*out ReadResult*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648300625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let isCompleted = this._writerCompletion.IsCompletedOrThrow();
                /*bool*/ let isCanceled = this._readerAwaitable.ObserveCancellation();
                /*BufferSegment?*/ let head = this._readHead;
                if (head !== null)
                {
                    $.$$.SD.Debug.Assert$4(this._readTail !== null, "_readTail != null");
                    /*var*/ let readOnlySequence = new ($.$sm.SB.ReadOnlySequence$$($.$$.S.Byte))().$ctor$3(head, this._readHeadIndex, this._readTail, this._readTailIndex);
                    result.$v = new $.$sipl.SIP.ReadResult().$ctor$3(readOnlySequence, isCanceled, isCompleted);
                }
                else 
                {
                    result.$v = new $.$sipl.SIP.ReadResult().$ctor$3(new ($.$sm.SB.ReadOnlySequence$$($.$$.S.Byte))(), isCanceled, isCompleted);
                }
                if (isCanceled)
                {
                    this._operationState.BeginReadTentative();
                }
                else 
                {
                    this._operationState.BeginRead();
                }
                this._minimumReadBytes = 0;
            }
            //--TRIMMABLE-BOUNDARY-END(300648300625)
            
            //--TRIMMABLE-BOUNDARY-START(279173464145)
            /*ValueTaskSourceStatus */ GetFlushAsyncStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173464145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._writerAwaitable.IsCompleted)
                {
                    if (this._readerCompletion.IsFaulted)
                    {
                        return 2/*ValueTaskSourceStatus.Faulted*/;
                    }
                    return 1/*ValueTaskSourceStatus.Succeeded*/;
                }
                return 0/*ValueTaskSourceStatus.Pending*/;
            }
            //--TRIMMABLE-BOUNDARY-END(279173464145)
            
            //--TRIMMABLE-BOUNDARY-START(274878496849)
            /*FlushResult */ GetFlushAsyncResult()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878496849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*FlushResult*/ let result = new $.$sipl.SIP.FlushResult();
                /*CancellationToken*/ let cancellationToken = new $.$$.ST$1.CancellationToken();
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = new $.$$.ST$1.CancellationTokenRegistration();
                try
                {
                    //lock(SyncObj)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                        {
                            if (!this._writerAwaitable.IsCompleted)
                            {
                                $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_GetResultNotCompleted();
                            }
                            this.GetFlushResult($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sipl.SIP.FlushResult, () => result, ($v) => result = $v, null, true));
                            cancellationTokenRegistration = this._writerAwaitable.ReleaseCancellationTokenRegistration($.$ref(() => cancellationToken, ($v) => cancellationToken = $v, $.$$.ST$1.CancellationToken));
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this.SyncObj)
                    }
                }
                finally
                {
                    {
                        cancellationTokenRegistration.Dispose();
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(274878496849)
            
            //--TRIMMABLE-BOUNDARY-START(313533202513)
            /*long */ GetUnflushedBytes()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(313533202513);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._unflushedBytes;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(313533202513)
            
            //--TRIMMABLE-BOUNDARY-START(283468431441)
            /*void */ GetFlushResult(/*ref FlushResult*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468431441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._writerAwaitable.ObserveCancellation())
                {
                    result.$v._resultFlags |= 1/*ResultFlags.Canceled*/;
                }
                if (this._readerCompletion.IsCompletedOrThrow())
                {
                    result.$v._resultFlags |= 2/*ResultFlags.Completed*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(283468431441)
            
            //--TRIMMABLE-BOUNDARY-START(450972155985)
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450972155985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (this._readerCompletion.IsCompletedOrThrow())
                {
                    return new ($.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult))().$ctor$6(new $.$sipl.SIP.FlushResult().$ctor$3(false, true));
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult))().$ctor$5($.$$.STT.Task.FromCanceled$3($.$sipl.SIP.FlushResult, cancellationToken));
                }
                /*CompletionData*/ let completionData;
                /*ValueTask<FlushResult>*/ let result;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        this.AllocateWriteHeadIfNeeded(0);
                        if (source.Length <= this._writingHeadMemory.Length)
                        {
                            source.CopyTo(this._writingHeadMemory);
                            this.AdvanceCore(source.Length);
                        }
                        else 
                        {
                            this.WriteMultiSegment(source.Span);
                        }
                        this.PrepareFlushUnsynchronized($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.SIP.CompletionData), $.$ref(() => result, ($v) => result = $v, $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult)), cancellationToken);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.SIP.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(450972155985)
            
            //--TRIMMABLE-BOUNDARY-START(455267123281)
            /*void */ WriteMultiSegment(/*ReadOnlySpan<byte>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455267123281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._writingHead !== null, "_writingHead != null");
                /*Span<byte>*/ let destination = this._writingHeadMemory.Span;
                while(true)
                {
                    /*int*/ let writable = $.$$.S.Math.Min$4(destination.Length, source.Length);
                    source.Slice(0, writable).CopyTo(destination);
                    source = source.Slice$1(writable);
                    this.AdvanceCore(writable);
                    if (source.Length === 0)
                    {
                        break;
                    }
                    this._writingHead.End += this._writingHeadBytesBuffered;
                    this._writingHeadBytesBuffered = 0;
                    /*BufferSegment*/ let newSegment = this.AllocateSegment(0);
                    this._writingHead.SetNext(newSegment);
                    this._writingHead = newSegment;
                    destination = this._writingHeadMemory.Span;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(455267123281)
            
            //--TRIMMABLE-BOUNDARY-START(326418104401)
            /*void */ OnFlushAsyncCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418104401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CompletionData*/ let completionData;
                /*bool*/ let doubleCompletion;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        this._writerAwaitable.OnCompleted(continuation, state, flags, $.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.SIP.CompletionData), $.$ref(() => doubleCompletion, ($v) => doubleCompletion = $v, $.$$.S.Boolean));
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                if (doubleCompletion)
                {
                    this.Reader.Complete($.$sipl.SIP.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation());
                }
                $.$sipl.SIP.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            //--TRIMMABLE-BOUNDARY-END(326418104401)
            
            //--TRIMMABLE-BOUNDARY-START(365072810065)
            /*void */ ReaderCancellationRequested()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072810065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CompletionData*/ let completionData;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        this._readerAwaitable.CancellationTokenFired($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.SIP.CompletionData));
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.SIP.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            //--TRIMMABLE-BOUNDARY-END(365072810065)
            
            //--TRIMMABLE-BOUNDARY-START(463857057873)
            /*void */ WriterCancellationRequested()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463857057873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CompletionData*/ let completionData;
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        this._writerAwaitable.CancellationTokenFired($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.SIP.CompletionData));
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.SIP.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            //--TRIMMABLE-BOUNDARY-END(463857057873)
            
            //--TRIMMABLE-BOUNDARY-START(360777842769)
            /*PipeReader */ get Reader()
            {
                return this._reader;
            }
            //--TRIMMABLE-BOUNDARY-END(360777842769)
            
            //--TRIMMABLE-BOUNDARY-START(459562090577)
            /*PipeWriter */ get Writer()
            {
                return this._writer;
            }
            //--TRIMMABLE-BOUNDARY-END(459562090577)
            
            //--TRIMMABLE-BOUNDARY-START(377957711953)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957711953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(SyncObj)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.SyncObj)
                    {
                        if (!this._disposed)
                        {
                            $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_ResetIncompleteReaderWriter();
                        }
                        this._disposed = false;
                        this.ResetState();
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.SyncObj)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(377957711953)
            
            //--TRIMMABLE-BOUNDARY-START(103079805009)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(103079805009)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295557201)
                this._bufferSegmentPool = $.$default($.$sipl.SIP.BufferSegmentStack);
                //--TRIMMABLE-BOUNDARY-END(4295557201)
                
                //--TRIMMABLE-BOUNDARY-START(60130132049)
                this._sync = new $.$$.S.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(60130132049)
                
                //--TRIMMABLE-BOUNDARY-START(34360328273)
                this._readerAwaitable = $.$default($.$sipl.SIP.PipeAwaitable);
                //--TRIMMABLE-BOUNDARY-END(34360328273)
                
                //--TRIMMABLE-BOUNDARY-START(77310001233)
                this._writerAwaitable = $.$default($.$sipl.SIP.PipeAwaitable);
                //--TRIMMABLE-BOUNDARY-END(77310001233)
                
                //--TRIMMABLE-BOUNDARY-START(81604968529)
                this._writerCompletion = $.$default($.$sipl.SIP.PipeCompletion);
                //--TRIMMABLE-BOUNDARY-END(81604968529)
                
                //--TRIMMABLE-BOUNDARY-START(38655295569)
                this._readerCompletion = $.$default($.$sipl.SIP.PipeCompletion);
                //--TRIMMABLE-BOUNDARY-END(38655295569)
                
                //--TRIMMABLE-BOUNDARY-START(94489870417)
                this._writingHeadMemory = $.$default($.$$.S.Memory$$($.$$.S.Byte));
                //--TRIMMABLE-BOUNDARY-END(94489870417)
                
                //--TRIMMABLE-BOUNDARY-START(21475426385)
                this._operationState = $.$default($.$sipl.SIP.PipeOperationState);
                //--TRIMMABLE-BOUNDARY-END(21475426385)
                
            }
            //--TRIMMABLE-BOUNDARY-START(98784837713)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784837713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(408022483025)
                    this.s_signalReaderAwaitable = new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.SIP.Pipe)).ReaderCancellationRequested();
                    }, $LejFni ??= {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":589905,"h":0,"f":17825794});
                    //--TRIMMABLE-BOUNDARY-END(408022483025)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412317450321)
                    this.s_signalWriterAwaitable = new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.SIP.Pipe)).WriterCancellationRequested();
                    }, $tkhwKe ??= {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":589905,"h":0,"f":17825794});
                    //--TRIMMABLE-BOUNDARY-END(412317450321)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432548433)
                    this.s_invokeCompletionCallbacks = new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.SIP.PipeCompletionCallbacks)).Execute();
                    }, $cslFTj ??= {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":589905,"h":0,"f":17825794});
                    //--TRIMMABLE-BOUNDARY-END(399432548433)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137581137)
                    this.s_executionContextRawCallback = new $.$$.ST$1.ContextCallback().$ctor($.$sipl.SIP.Pipe, $.$sipl.SIP.Pipe.ExecuteWithoutExecutionContext);
                    //--TRIMMABLE-BOUNDARY-END(395137581137)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420907384913)
                    this.s_syncContextExecutionContextCallback = new $.$$.ST$1.SendOrPostCallback().$ctor($.$sipl.SIP.Pipe, $.$sipl.SIP.Pipe.ExecuteWithExecutionContext);
                    //--TRIMMABLE-BOUNDARY-END(420907384913)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416612417617)
                    this.s_syncContextExecuteWithoutExecutionContextCallback = new $.$$.ST$1.SendOrPostCallback().$ctor($.$sipl.SIP.Pipe, $.$sipl.SIP.Pipe.ExecuteWithoutExecutionContext);
                    //--TRIMMABLE-BOUNDARY-END(416612417617)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403727515729)
                    this.s_scheduleWithExecutionContextCallback = new ($.$$.S.Action$$($.$$.S.Object))().$ctor($.$sipl.SIP.Pipe, $.$sipl.SIP.Pipe.ExecuteWithExecutionContext);
                    //--TRIMMABLE-BOUNDARY-END(403727515729)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784837713)
            
            static $h = 589905;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(446677188689),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253403660369,
        "f": 50331650
      },
      "n": "UseSynchronizationContext",
      "d": 589905,
      "h": 446677188689,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(446677188689),
//--TRIMMABLE-BOUNDARY-START(322123137105),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864052817,
        "f": 50331650
      },
      "n": "MinimumSegmentSize",
      "d": 589905,
      "h": 322123137105,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(322123137105),
//--TRIMMABLE-BOUNDARY-START(343597973585),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210453987409,
        "f": 50331650
      },
      "n": "PauseWriterThreshold",
      "d": 589905,
      "h": 343597973585,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(343597973585),
//--TRIMMABLE-BOUNDARY-START(386547646545),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223791185,
        "f": 50331650
      },
      "n": "ResumeWriterThreshold",
      "d": 589905,
      "h": 386547646545,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(386547646545),
//--TRIMMABLE-BOUNDARY-START(369367777361),
    {
      "p": 1507409,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227633856593,
        "f": 50331650
      },
      "n": "ReaderScheduler",
      "d": 589905,
      "h": 369367777361,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(369367777361),
//--TRIMMABLE-BOUNDARY-START(468152025169),
    {
      "p": 1507409,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270583529553,
        "f": 50331650
      },
      "n": "WriterScheduler",
      "d": 589905,
      "h": 468152025169,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(468152025169),
//--TRIMMABLE-BOUNDARY-START(433792286801),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813725777,
        "f": 50331650
      },
      "n": "SyncObj",
      "d": 589905,
      "h": 433792286801,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(433792286801),
//--TRIMMABLE-BOUNDARY-START(317828169809),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274118225,
        "f": 50331656
      },
      "n": "Length",
      "d": 589905,
      "h": 317828169809,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(317828169809),
//--TRIMMABLE-BOUNDARY-START(360777842769),
    {
      "p": 1376337,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219043922001,
        "f": 50331649
      },
      "n": "Reader",
      "d": 589905,
      "h": 360777842769,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(360777842769),
//--TRIMMABLE-BOUNDARY-START(459562090577),
    {
      "p": 1572945,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261993594961,
        "f": 50331649
      },
      "n": "Writer",
      "d": 589905,
      "h": 459562090577,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(459562090577)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(382252679249),
    {
      "r": 65537,
      "n": "ResetState",
      "d": 589905,
      "h": 382252679249,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(382252679249),
//--TRIMMABLE-BOUNDARY-START(287763398737),
    {
      "r": $.$$.S.Memory$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361
        }
      ],
      "n": "GetMemory",
      "d": 589905,
      "h": 287763398737,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(287763398737),
//--TRIMMABLE-BOUNDARY-START(309238235217),
    {
      "r": $.$$.S.Span$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361
        }
      ],
      "n": "GetSpan",
      "d": 589905,
      "h": 309238235217,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(309238235217),
//--TRIMMABLE-BOUNDARY-START(137439543377),
    {
      "r": 65537,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361
        }
      ],
      "n": "AllocateWriteHeadIfNeeded",
      "d": 589905,
      "h": 137439543377,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137439543377),
//--TRIMMABLE-BOUNDARY-START(141734510673),
    {
      "r": 65537,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361
        }
      ],
      "n": "AllocateWriteHeadSynchronized",
      "d": 589905,
      "h": 141734510673,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141734510673),
//--TRIMMABLE-BOUNDARY-START(133144576081),
    {
      "r": 65617,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361
        }
      ],
      "n": "AllocateSegment",
      "d": 589905,
      "h": 133144576081,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133144576081),
//--TRIMMABLE-BOUNDARY-START(373662744657),
    {
      "r": 65537,
      "p": [
        {
          "n": "segment",
          "p": 65617
        },
        {
          "n": "sizeHint",
          "p": 655361
        }
      ],
      "n": "RentMemory",
      "d": 589905,
      "h": 373662744657,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(373662744657),
//--TRIMMABLE-BOUNDARY-START(304943267921),
    {
      "r": 655361,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361
        },
        {
          "n": "maxBufferSize",
          "p": 655361,
          "f": 65,
          "v": 2147483647
        }
      ],
      "n": "GetSegmentSize",
      "d": 589905,
      "h": 304943267921,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(304943267921),
//--TRIMMABLE-BOUNDARY-START(171799281745),
    {
      "r": 65617,
      "n": "CreateSegmentUnsynchronized",
      "d": 589905,
      "h": 171799281745,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171799281745),
//--TRIMMABLE-BOUNDARY-START(390842613841),
    {
      "r": 65537,
      "p": [
        {
          "n": "segment",
          "p": 65617
        }
      ],
      "n": "ReturnSegmentUnsynchronized",
      "d": 589905,
      "h": 390842613841,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(390842613841),
//--TRIMMABLE-BOUNDARY-START(154619412561),
    {
      "r": 262145,
      "n": "CommitUnsynchronized",
      "d": 589905,
      "h": 154619412561,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(154619412561),
//--TRIMMABLE-BOUNDARY-START(111669739601),
    {
      "r": 65537,
      "p": [
        {
          "n": "bytes",
          "p": 655361
        }
      ],
      "n": "Advance",
      "d": 589905,
      "h": 111669739601,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(111669739601),
//--TRIMMABLE-BOUNDARY-START(115964706897),
    {
      "r": 65537,
      "p": [
        {
          "n": "bytesWritten",
          "p": 655361
        }
      ],
      "n": "AdvanceCore",
      "d": 589905,
      "h": 115964706897,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115964706897),
//--TRIMMABLE-BOUNDARY-START(184684183633),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "FlushAsync",
      "d": 589905,
      "h": 184684183633,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(184684183633),
//--TRIMMABLE-BOUNDARY-START(347892940881),
    {
      "r": 65537,
      "p": [
        {
          "n": "completionData",
          "p": 262225,
          "f": 2
        },
        {
          "n": "result",
          "p": $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult).$h,
          "f": 2
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "PrepareFlushUnsynchronized",
      "d": 589905,
      "h": 347892940881,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(347892940881),
//--TRIMMABLE-BOUNDARY-START(167504314449),
    {
      "r": 65537,
      "p": [
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "CompleteWriter",
      "d": 589905,
      "h": 167504314449,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(167504314449),
//--TRIMMABLE-BOUNDARY-START(124554641489),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumed",
          "p": 1179656,
          "f": 8
        }
      ],
      "n": "AdvanceReader",
      "o": "@$1",
      "d": 589905,
      "h": 124554641489,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(124554641489),
//--TRIMMABLE-BOUNDARY-START(120259674193),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumed",
          "p": 1179656,
          "f": 8
        },
        {
          "n": "examined",
          "p": 1179656,
          "f": 8
        }
      ],
      "n": "AdvanceReader",
      "d": 589905,
      "h": 120259674193,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(120259674193),
//--TRIMMABLE-BOUNDARY-START(128849608785),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumedSegment",
          "p": 65617
        },
        {
          "n": "consumedIndex",
          "p": 655361
        },
        {
          "n": "examinedSegment",
          "p": 65617
        },
        {
          "n": "examinedIndex",
          "p": 655361
        }
      ],
      "n": "AdvanceReader",
      "o": "@$2",
      "d": 589905,
      "h": 128849608785,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128849608785),
//--TRIMMABLE-BOUNDARY-START(163209347153),
    {
      "r": 65537,
      "p": [
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "CompleteReader",
      "d": 589905,
      "h": 163209347153,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(163209347153),
//--TRIMMABLE-BOUNDARY-START(339303006289),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$$($.$$.S.Exception, $.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "OnWriterCompleted",
      "d": 589905,
      "h": 339303006289,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(339303006289),
//--TRIMMABLE-BOUNDARY-START(150324445265),
    {
      "r": 65537,
      "n": "CancelPendingRead",
      "d": 589905,
      "h": 150324445265,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(150324445265),
//--TRIMMABLE-BOUNDARY-START(146029477969),
    {
      "r": 65537,
      "n": "CancelPendingFlush",
      "d": 589905,
      "h": 146029477969,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(146029477969),
//--TRIMMABLE-BOUNDARY-START(335008038993),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$$($.$$.S.Exception, $.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "OnReaderCompleted",
      "d": 589905,
      "h": 335008038993,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(335008038993),
//--TRIMMABLE-BOUNDARY-START(356482875473),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult).$h,
      "p": [
        {
          "n": "minimumBytes",
          "p": 655361
        },
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "ReadAtLeastAsync",
      "d": 589905,
      "h": 356482875473,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(356482875473),
//--TRIMMABLE-BOUNDARY-START(352187908177),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult).$h,
      "p": [
        {
          "n": "token",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "d": 589905,
      "h": 352187908177,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(352187908177),
//--TRIMMABLE-BOUNDARY-START(438087254097),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": 1704017,
          "f": 2
        }
      ],
      "n": "TryRead",
      "d": 589905,
      "h": 438087254097,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(438087254097),
//--TRIMMABLE-BOUNDARY-START(425202352209),
    {
      "r": 65537,
      "p": [
        {
          "n": "scheduler",
          "p": 1507409
        },
        {
          "n": "completionCallbacks",
          "p": 1114193
        }
      ],
      "n": "ScheduleCallbacks",
      "d": 589905,
      "h": 425202352209,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(425202352209),
//--TRIMMABLE-BOUNDARY-START(442382221393),
    {
      "r": 65537,
      "p": [
        {
          "n": "scheduler",
          "p": 1507409
        },
        {
          "n": "completionData",
          "p": 262225,
          "f": 8
        }
      ],
      "n": "TrySchedule",
      "d": 589905,
      "h": 442382221393,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(442382221393),
//--TRIMMABLE-BOUNDARY-START(429497319505),
    {
      "r": 65537,
      "p": [
        {
          "n": "scheduler",
          "p": 1507409
        },
        {
          "n": "completionData",
          "p": 262225,
          "f": 8
        }
      ],
      "n": "ScheduleWithContext",
      "d": 589905,
      "h": 429497319505,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(429497319505),
//--TRIMMABLE-BOUNDARY-START(180389216337),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "ExecuteWithoutExecutionContext",
      "d": 589905,
      "h": 180389216337,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(180389216337),
//--TRIMMABLE-BOUNDARY-START(176094249041),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "ExecuteWithExecutionContext",
      "d": 589905,
      "h": 176094249041,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(176094249041),
//--TRIMMABLE-BOUNDARY-START(158914379857),
    {
      "r": 65537,
      "n": "CompletePipe",
      "d": 589905,
      "h": 158914379857,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158914379857),
//--TRIMMABLE-BOUNDARY-START(296353333329),
    {
      "r": 178126849,
      "n": "GetReadAsyncStatus",
      "d": 589905,
      "h": 296353333329,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(296353333329),
//--TRIMMABLE-BOUNDARY-START(330713071697),
    {
      "r": 65537,
      "p": [
        {
          "n": "continuation",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "flags",
          "p": 178061313
        }
      ],
      "n": "OnReadAsyncCompleted",
      "d": 589905,
      "h": 330713071697,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(330713071697),
//--TRIMMABLE-BOUNDARY-START(292058366033),
    {
      "r": 1704017,
      "n": "GetReadAsyncResult",
      "d": 589905,
      "h": 292058366033,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(292058366033),
//--TRIMMABLE-BOUNDARY-START(300648300625),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 1704017,
          "f": 2
        }
      ],
      "n": "GetReadResult",
      "d": 589905,
      "h": 300648300625,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(300648300625),
//--TRIMMABLE-BOUNDARY-START(279173464145),
    {
      "r": 178126849,
      "n": "GetFlushAsyncStatus",
      "d": 589905,
      "h": 279173464145,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(279173464145),
//--TRIMMABLE-BOUNDARY-START(274878496849),
    {
      "r": 393297,
      "n": "GetFlushAsyncResult",
      "d": 589905,
      "h": 274878496849,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(274878496849),
//--TRIMMABLE-BOUNDARY-START(313533202513),
    {
      "r": 917505,
      "n": "GetUnflushedBytes",
      "d": 589905,
      "h": 313533202513,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(313533202513),
//--TRIMMABLE-BOUNDARY-START(283468431441),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 393297,
          "f": 4
        }
      ],
      "n": "GetFlushResult",
      "d": 589905,
      "h": 283468431441,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(283468431441),
//--TRIMMABLE-BOUNDARY-START(450972155985),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "d": 589905,
      "h": 450972155985,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(450972155985),
//--TRIMMABLE-BOUNDARY-START(455267123281),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "WriteMultiSegment",
      "d": 589905,
      "h": 455267123281,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(455267123281),
//--TRIMMABLE-BOUNDARY-START(326418104401),
    {
      "r": 65537,
      "p": [
        {
          "n": "continuation",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "flags",
          "p": 178061313
        }
      ],
      "n": "OnFlushAsyncCompleted",
      "d": 589905,
      "h": 326418104401,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(326418104401),
//--TRIMMABLE-BOUNDARY-START(365072810065),
    {
      "r": 65537,
      "n": "ReaderCancellationRequested",
      "d": 589905,
      "h": 365072810065,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(365072810065),
//--TRIMMABLE-BOUNDARY-START(463857057873),
    {
      "r": 65537,
      "n": "WriterCancellationRequested",
      "d": 589905,
      "h": 463857057873,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(463857057873),
//--TRIMMABLE-BOUNDARY-START(377957711953),
    {
      "r": 65537,
      "n": "Reset",
      "d": 589905,
      "h": 377957711953,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(377957711953)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(408022483025),
    {
      "t": $.$$.S.Action$$($.$$.S.Object).$h,
      "n": "s_signalReaderAwaitable",
      "d": 589905,
      "h": 408022483025,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(408022483025),
//--TRIMMABLE-BOUNDARY-START(412317450321),
    {
      "t": $.$$.S.Action$$($.$$.S.Object).$h,
      "n": "s_signalWriterAwaitable",
      "d": 589905,
      "h": 412317450321,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(412317450321),
//--TRIMMABLE-BOUNDARY-START(399432548433),
    {
      "t": $.$$.S.Action$$($.$$.S.Object).$h,
      "n": "s_invokeCompletionCallbacks",
      "d": 589905,
      "h": 399432548433,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(399432548433),
//--TRIMMABLE-BOUNDARY-START(395137581137),
    {
      "t": 171507713,
      "n": "s_executionContextRawCallback",
      "d": 589905,
      "h": 395137581137,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(395137581137),
//--TRIMMABLE-BOUNDARY-START(420907384913),
    {
      "t": 175767553,
      "n": "s_syncContextExecutionContextCallback",
      "d": 589905,
      "h": 420907384913,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(420907384913),
//--TRIMMABLE-BOUNDARY-START(416612417617),
    {
      "t": 175767553,
      "n": "s_syncContextExecuteWithoutExecutionContextCallback",
      "d": 589905,
      "h": 416612417617,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(416612417617),
//--TRIMMABLE-BOUNDARY-START(403727515729),
    {
      "t": $.$$.S.Action$$($.$$.S.Object).$h,
      "n": "s_scheduleWithExecutionContextCallback",
      "d": 589905,
      "h": 403727515729,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(403727515729),
//--TRIMMABLE-BOUNDARY-START(4295557201),
    {
      "t": 131153,
      "n": "_bufferSegmentPool",
      "d": 589905,
      "h": 4295557201,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557201),
//--TRIMMABLE-BOUNDARY-START(30065360977),
    {
      "t": 655441,
      "n": "_reader",
      "d": 589905,
      "h": 30065360977,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065360977),
//--TRIMMABLE-BOUNDARY-START(73015033937),
    {
      "t": 720977,
      "n": "_writer",
      "d": 589905,
      "h": 73015033937,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015033937),
//--TRIMMABLE-BOUNDARY-START(25770393681),
    {
      "t": 1310801,
      "n": "_options",
      "d": 589905,
      "h": 25770393681,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770393681),
//--TRIMMABLE-BOUNDARY-START(60130132049),
    {
      "t": 131073,
      "n": "_sync",
      "d": 589905,
      "h": 60130132049,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60130132049),
//--TRIMMABLE-BOUNDARY-START(64425099345),
    {
      "t": 917505,
      "n": "_unconsumedBytes",
      "d": 589905,
      "h": 64425099345,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64425099345),
//--TRIMMABLE-BOUNDARY-START(68720066641),
    {
      "t": 917505,
      "n": "_unflushedBytes",
      "d": 589905,
      "h": 68720066641,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68720066641),
//--TRIMMABLE-BOUNDARY-START(34360328273),
    {
      "t": 786513,
      "n": "_readerAwaitable",
      "d": 589905,
      "h": 34360328273,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360328273),
//--TRIMMABLE-BOUNDARY-START(77310001233),
    {
      "t": 786513,
      "n": "_writerAwaitable",
      "d": 589905,
      "h": 77310001233,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77310001233),
//--TRIMMABLE-BOUNDARY-START(81604968529),
    {
      "t": 983121,
      "n": "_writerCompletion",
      "d": 589905,
      "h": 81604968529,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81604968529),
//--TRIMMABLE-BOUNDARY-START(38655295569),
    {
      "t": 983121,
      "n": "_readerCompletion",
      "d": 589905,
      "h": 38655295569,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655295569),
//--TRIMMABLE-BOUNDARY-START(12885491793),
    {
      "t": 917505,
      "n": "_lastExaminedIndex",
      "d": 589905,
      "h": 12885491793,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885491793),
//--TRIMMABLE-BOUNDARY-START(42950262865),
    {
      "t": 65617,
      "n": "_readHead",
      "d": 589905,
      "h": 42950262865,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950262865),
//--TRIMMABLE-BOUNDARY-START(47245230161),
    {
      "t": 655361,
      "n": "_readHeadIndex",
      "d": 589905,
      "h": 47245230161,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245230161),
//--TRIMMABLE-BOUNDARY-START(8590524497),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 589905,
      "h": 8590524497,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524497),
//--TRIMMABLE-BOUNDARY-START(51540197457),
    {
      "t": 65617,
      "n": "_readTail",
      "d": 589905,
      "h": 51540197457,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540197457),
//--TRIMMABLE-BOUNDARY-START(55835164753),
    {
      "t": 655361,
      "n": "_readTailIndex",
      "d": 589905,
      "h": 55835164753,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835164753),
//--TRIMMABLE-BOUNDARY-START(17180459089),
    {
      "t": 655361,
      "n": "_minimumReadBytes",
      "d": 589905,
      "h": 17180459089,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180459089),
//--TRIMMABLE-BOUNDARY-START(85899935825),
    {
      "t": 65617,
      "n": "_writingHead",
      "d": 589905,
      "h": 85899935825,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85899935825),
//--TRIMMABLE-BOUNDARY-START(94489870417),
    {
      "t": $.$$.S.Memory$$($.$$.S.Byte).$h,
      "n": "_writingHeadMemory",
      "d": 589905,
      "h": 94489870417,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(94489870417),
//--TRIMMABLE-BOUNDARY-START(90194903121),
    {
      "t": 655361,
      "n": "_writingHeadBytesBuffered",
      "d": 589905,
      "h": 90194903121,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(90194903121),
//--TRIMMABLE-BOUNDARY-START(21475426385),
    {
      "t": 1179729,
      "n": "_operationState",
      "d": 589905,
      "h": 21475426385,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475426385)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(103079805009),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589905,
      "h": 103079805009,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079805009),
//--TRIMMABLE-BOUNDARY-START(107374772305),
    {
      "p": [
        {
          "n": "options",
          "p": 1310801
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589905,
      "h": 107374772305,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374772305)
  ],
  "h": 589905
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sipl.SIP.Pipe.DefaultPipeReader, $.$sipl.SIP.Pipe.DefaultPipeWriter ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.Pipe`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}Pipe`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589905)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900625)
        $asm.$cls(`$sipl.SIP.StreamPipeExtensions`, ($self) => class StreamPipeExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4296867921)
            static /*Task */ CopyToAsync(/*this Stream*/ source, /*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296867921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (source === null)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.source*/);
                }
                if (destination === null)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.STT.Task.FromCanceled$1(cancellationToken);
                }
                return destination.CopyFromAsync(source, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(4296867921)
            
            static $h = 1900625;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296867921),
    {
      "r": 178454529,
      "p": [
        {
          "n": "source",
          "p": 95748097
        },
        {
          "n": "destination",
          "p": 1572945
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "CopyToAsync",
      "d": 1900625,
      "h": 4296867921,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296867921)
  ],
  "h": 1900625
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.StreamPipeExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}StreamPipeExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900625)
        
        

        //--TRIMMABLE-BOUNDARY-START(2359377)
        $asm.$cls(`$sipl.SI.StreamHelpers`, ($self) => class StreamHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(4297326673)
            static /*void */ ValidateCopyToArgs(/*Stream*/ source, /*Stream*/ destination, /*int*/ bufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297326673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(destination, "destination");
                if (bufferSize <= 0)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("bufferSize", $.$box(bufferSize, $.$$.S.Int32), $.$sipl.S.SR.ArgumentOutOfRange_NeedPosNum);
                }
                /*bool*/ let sourceCanRead = source.CanRead;
                if (!sourceCanRead && !source.CanWrite)
                {
                    throw new $.$$.S.ObjectDisposedException().$ctor$16(null, $.$sipl.S.SR.ObjectDisposed_StreamClosed);
                }
                /*bool*/ let destinationCanWrite = destination.CanWrite;
                if (!destinationCanWrite && !destination.CanRead)
                {
                    throw new $.$$.S.ObjectDisposedException().$ctor$16("destination", $.$sipl.S.SR.ObjectDisposed_StreamClosed);
                }
                if (!sourceCanRead)
                {
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$sipl.S.SR.NotSupported_UnreadableStream);
                }
                if (!destinationCanWrite)
                {
                    throw new $.$$.S.NotSupportedException().$ctor$12($.$sipl.S.SR.NotSupported_UnwritableStream);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297326673)
            
            static $h = 2359377;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297326673),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 95748097
        },
        {
          "n": "destination",
          "p": 95748097
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": "ValidateCopyToArgs",
      "d": 2359377,
      "h": 4297326673,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297326673)
  ],
  "h": 2359377
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.StreamHelpers`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}StreamHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359377)
        
        

        //--TRIMMABLE-BOUNDARY-START(2293841)
        $asm.$cls(`$sipl.SIP.ThrowHelper`, ($self) => class ThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(77311705169)
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311705169);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateArgumentOutOfRangeException(argument);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77311705169)
            
            //--TRIMMABLE-BOUNDARY-START(8592228433)
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592228433);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.ArgumentOutOfRangeException().$ctor$20($.$$.S.Enum.ToStringT($.$sipl.SIP.ExceptionArgument, $.$$.S.UInt32, argument));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592228433)
            
            //--TRIMMABLE-BOUNDARY-START(73016737873)
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73016737873);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateArgumentNullException(argument);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73016737873)
            
            //--TRIMMABLE-BOUNDARY-START(4297261137)
            static /*ArgumentNullException */ CreateArgumentNullException(/*ExceptionArgument*/ argument)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297261137);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.ArgumentNullException().$ctor$19($.$$.S.Enum.ToStringT($.$sipl.SIP.ExceptionArgument, $.$$.S.UInt32, argument));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297261137)
            
            //--TRIMMABLE-BOUNDARY-START(85901639761)
            static /*void */ ThrowInvalidOperationException_AlreadyReading()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85901639761);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateInvalidOperationException_AlreadyReading();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85901639761)
            
            //--TRIMMABLE-BOUNDARY-START(17182163025)
            static /*InvalidOperationException */ CreateInvalidOperationException_AlreadyReading()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182163025);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.InvalidOperationException().$ctor$12($.$sipl.S.SR.ReadingIsInProgress);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182163025)
            
            //--TRIMMABLE-BOUNDARY-START(115966410833)
            static /*void */ ThrowInvalidOperationException_NoReadToComplete()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115966410833);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateInvalidOperationException_NoReadToComplete();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115966410833)
            
            //--TRIMMABLE-BOUNDARY-START(47246934097)
            static /*InvalidOperationException */ CreateInvalidOperationException_NoReadToComplete()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246934097);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.InvalidOperationException().$ctor$12($.$sipl.S.SR.NoReadingOperationToComplete);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47246934097)
            
            //--TRIMMABLE-BOUNDARY-START(107376476241)
            static /*void */ ThrowInvalidOperationException_NoConcurrentOperation()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107376476241);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107376476241)
            
            //--TRIMMABLE-BOUNDARY-START(38656999505)
            static /*InvalidOperationException */ CreateInvalidOperationException_NoConcurrentOperation()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656999505);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.InvalidOperationException().$ctor$12($.$sipl.S.SR.ConcurrentOperationsNotSupported);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656999505)
            
            //--TRIMMABLE-BOUNDARY-START(90196607057)
            static /*void */ ThrowInvalidOperationException_GetResultNotCompleted()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90196607057);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateInvalidOperationException_GetResultNotCompleted();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90196607057)
            
            //--TRIMMABLE-BOUNDARY-START(21477130321)
            static /*InvalidOperationException */ CreateInvalidOperationException_GetResultNotCompleted()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477130321);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.InvalidOperationException().$ctor$12($.$sipl.S.SR.GetResultBeforeCompleted);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477130321)
            
            //--TRIMMABLE-BOUNDARY-START(120261378129)
            static /*void */ ThrowInvalidOperationException_NoWritingAllowed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120261378129);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateInvalidOperationException_NoWritingAllowed();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120261378129)
            
            //--TRIMMABLE-BOUNDARY-START(51541901393)
            static /*InvalidOperationException */ CreateInvalidOperationException_NoWritingAllowed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541901393);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.InvalidOperationException().$ctor$12($.$sipl.S.SR.WritingAfterCompleted);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541901393)
            
            //--TRIMMABLE-BOUNDARY-START(111671443537)
            static /*void */ ThrowInvalidOperationException_NoReadingAllowed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111671443537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateInvalidOperationException_NoReadingAllowed();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111671443537)
            
            //--TRIMMABLE-BOUNDARY-START(42951966801)
            static /*InvalidOperationException */ CreateInvalidOperationException_NoReadingAllowed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951966801);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.InvalidOperationException().$ctor$12($.$sipl.S.SR.ReadingAfterCompleted);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951966801)
            
            //--TRIMMABLE-BOUNDARY-START(98786541649)
            static /*void */ ThrowInvalidOperationException_InvalidExaminedPosition()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98786541649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateInvalidOperationException_InvalidExaminedPosition();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98786541649)
            
            //--TRIMMABLE-BOUNDARY-START(30067064913)
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidExaminedPosition()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067064913);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.InvalidOperationException().$ctor$12($.$sipl.S.SR.InvalidExaminedPosition);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30067064913)
            
            //--TRIMMABLE-BOUNDARY-START(94491574353)
            static /*void */ ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94491574353);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateInvalidOperationException_InvalidExaminedOrConsumedPosition();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94491574353)
            
            //--TRIMMABLE-BOUNDARY-START(25772097617)
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidExaminedOrConsumedPosition()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772097617);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.InvalidOperationException().$ctor$12($.$sipl.S.SR.InvalidExaminedOrConsumedPosition);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772097617)
            
            //--TRIMMABLE-BOUNDARY-START(81606672465)
            static /*void */ ThrowInvalidOperationException_AdvanceToInvalidCursor()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81606672465);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateInvalidOperationException_AdvanceToInvalidCursor();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81606672465)
            
            //--TRIMMABLE-BOUNDARY-START(12887195729)
            static /*InvalidOperationException */ CreateInvalidOperationException_AdvanceToInvalidCursor()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887195729);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.InvalidOperationException().$ctor$12($.$sipl.S.SR.AdvanceToInvalidCursor);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887195729)
            
            //--TRIMMABLE-BOUNDARY-START(124556345425)
            static /*void */ ThrowInvalidOperationException_ResetIncompleteReaderWriter()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124556345425);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateInvalidOperationException_ResetIncompleteReaderWriter();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124556345425)
            
            //--TRIMMABLE-BOUNDARY-START(55836868689)
            static /*InvalidOperationException */ CreateInvalidOperationException_ResetIncompleteReaderWriter()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836868689);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.InvalidOperationException().$ctor$12($.$sipl.S.SR.ReaderAndWriterHasToBeCompleted);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836868689)
            
            //--TRIMMABLE-BOUNDARY-START(137441247313)
            static /*void */ ThrowOperationCanceledException_ReadCanceled()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137441247313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateOperationCanceledException_ReadCanceled();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137441247313)
            
            //--TRIMMABLE-BOUNDARY-START(68721770577)
            static /*OperationCanceledException */ CreateOperationCanceledException_ReadCanceled()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721770577);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.OperationCanceledException().$ctor$14($.$sipl.S.SR.ReadCanceledOnPipeReader);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721770577)
            
            //--TRIMMABLE-BOUNDARY-START(133146280017)
            static /*void */ ThrowOperationCanceledException_FlushCanceled()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133146280017);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateOperationCanceledException_FlushCanceled();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133146280017)
            
            //--TRIMMABLE-BOUNDARY-START(64426803281)
            static /*OperationCanceledException */ CreateOperationCanceledException_FlushCanceled()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426803281);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.OperationCanceledException().$ctor$14($.$sipl.S.SR.FlushCanceledOnPipeWriter);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426803281)
            
            //--TRIMMABLE-BOUNDARY-START(103081508945)
            static /*void */ ThrowInvalidOperationException_InvalidZeroByteRead()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103081508945);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateInvalidOperationException_InvalidZeroByteRead();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103081508945)
            
            //--TRIMMABLE-BOUNDARY-START(34362032209)
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidZeroByteRead()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362032209);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.InvalidOperationException().$ctor$12($.$sipl.S.SR.InvalidZeroByteRead);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34362032209)
            
            //--TRIMMABLE-BOUNDARY-START(128851312721)
            static /*void */ ThrowNotSupported_UnflushedBytes()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128851312721);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sipl.SIP.ThrowHelper.CreateNotSupportedException_UnflushedBytes();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128851312721)
            
            //--TRIMMABLE-BOUNDARY-START(60131835985)
            static /*NotSupportedException */ CreateNotSupportedException_UnflushedBytes()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131835985);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.S.NotSupportedException().$ctor$12($.$sipl.S.SR.UnflushedBytesNotSupported);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131835985)
            
            static $h = 2293841;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(77311705169),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 327761
        }
      ],
      "n": "ThrowArgumentOutOfRangeException",
      "d": 2293841,
      "h": 77311705169,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(77311705169),
//--TRIMMABLE-BOUNDARY-START(8592228433),
    {
      "r": 45088769,
      "p": [
        {
          "n": "argument",
          "p": 327761
        }
      ],
      "n": "CreateArgumentOutOfRangeException",
      "d": 2293841,
      "h": 8592228433,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8592228433),
//--TRIMMABLE-BOUNDARY-START(73016737873),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 327761
        }
      ],
      "n": "ThrowArgumentNullException",
      "d": 2293841,
      "h": 73016737873,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(73016737873),
//--TRIMMABLE-BOUNDARY-START(4297261137),
    {
      "r": 45023233,
      "p": [
        {
          "n": "argument",
          "p": 327761
        }
      ],
      "n": "CreateArgumentNullException",
      "d": 2293841,
      "h": 4297261137,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4297261137),
//--TRIMMABLE-BOUNDARY-START(85901639761),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_AlreadyReading",
      "d": 2293841,
      "h": 85901639761,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85901639761),
//--TRIMMABLE-BOUNDARY-START(17182163025),
    {
      "r": 91815937,
      "n": "CreateInvalidOperationException_AlreadyReading",
      "d": 2293841,
      "h": 17182163025,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182163025),
//--TRIMMABLE-BOUNDARY-START(115966410833),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_NoReadToComplete",
      "d": 2293841,
      "h": 115966410833,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115966410833),
//--TRIMMABLE-BOUNDARY-START(47246934097),
    {
      "r": 91815937,
      "n": "CreateInvalidOperationException_NoReadToComplete",
      "d": 2293841,
      "h": 47246934097,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47246934097),
//--TRIMMABLE-BOUNDARY-START(107376476241),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_NoConcurrentOperation",
      "d": 2293841,
      "h": 107376476241,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(107376476241),
//--TRIMMABLE-BOUNDARY-START(38656999505),
    {
      "r": 91815937,
      "n": "CreateInvalidOperationException_NoConcurrentOperation",
      "d": 2293841,
      "h": 38656999505,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656999505),
//--TRIMMABLE-BOUNDARY-START(90196607057),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_GetResultNotCompleted",
      "d": 2293841,
      "h": 90196607057,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90196607057),
//--TRIMMABLE-BOUNDARY-START(21477130321),
    {
      "r": 91815937,
      "n": "CreateInvalidOperationException_GetResultNotCompleted",
      "d": 2293841,
      "h": 21477130321,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477130321),
//--TRIMMABLE-BOUNDARY-START(120261378129),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_NoWritingAllowed",
      "d": 2293841,
      "h": 120261378129,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120261378129),
//--TRIMMABLE-BOUNDARY-START(51541901393),
    {
      "r": 91815937,
      "n": "CreateInvalidOperationException_NoWritingAllowed",
      "d": 2293841,
      "h": 51541901393,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51541901393),
//--TRIMMABLE-BOUNDARY-START(111671443537),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_NoReadingAllowed",
      "d": 2293841,
      "h": 111671443537,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111671443537),
//--TRIMMABLE-BOUNDARY-START(42951966801),
    {
      "r": 91815937,
      "n": "CreateInvalidOperationException_NoReadingAllowed",
      "d": 2293841,
      "h": 42951966801,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951966801),
//--TRIMMABLE-BOUNDARY-START(98786541649),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_InvalidExaminedPosition",
      "d": 2293841,
      "h": 98786541649,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98786541649),
//--TRIMMABLE-BOUNDARY-START(30067064913),
    {
      "r": 91815937,
      "n": "CreateInvalidOperationException_InvalidExaminedPosition",
      "d": 2293841,
      "h": 30067064913,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067064913),
//--TRIMMABLE-BOUNDARY-START(94491574353),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition",
      "d": 2293841,
      "h": 94491574353,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94491574353),
//--TRIMMABLE-BOUNDARY-START(25772097617),
    {
      "r": 91815937,
      "n": "CreateInvalidOperationException_InvalidExaminedOrConsumedPosition",
      "d": 2293841,
      "h": 25772097617,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772097617),
//--TRIMMABLE-BOUNDARY-START(81606672465),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_AdvanceToInvalidCursor",
      "d": 2293841,
      "h": 81606672465,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81606672465),
//--TRIMMABLE-BOUNDARY-START(12887195729),
    {
      "r": 91815937,
      "n": "CreateInvalidOperationException_AdvanceToInvalidCursor",
      "d": 2293841,
      "h": 12887195729,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887195729),
//--TRIMMABLE-BOUNDARY-START(124556345425),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_ResetIncompleteReaderWriter",
      "d": 2293841,
      "h": 124556345425,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124556345425),
//--TRIMMABLE-BOUNDARY-START(55836868689),
    {
      "r": 91815937,
      "n": "CreateInvalidOperationException_ResetIncompleteReaderWriter",
      "d": 2293841,
      "h": 55836868689,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55836868689),
//--TRIMMABLE-BOUNDARY-START(137441247313),
    {
      "r": 65537,
      "n": "ThrowOperationCanceledException_ReadCanceled",
      "d": 2293841,
      "h": 137441247313,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(137441247313),
//--TRIMMABLE-BOUNDARY-START(68721770577),
    {
      "r": 104660993,
      "n": "CreateOperationCanceledException_ReadCanceled",
      "d": 2293841,
      "h": 68721770577,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68721770577),
//--TRIMMABLE-BOUNDARY-START(133146280017),
    {
      "r": 65537,
      "n": "ThrowOperationCanceledException_FlushCanceled",
      "d": 2293841,
      "h": 133146280017,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(133146280017),
//--TRIMMABLE-BOUNDARY-START(64426803281),
    {
      "r": 104660993,
      "n": "CreateOperationCanceledException_FlushCanceled",
      "d": 2293841,
      "h": 64426803281,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64426803281),
//--TRIMMABLE-BOUNDARY-START(103081508945),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_InvalidZeroByteRead",
      "d": 2293841,
      "h": 103081508945,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(103081508945),
//--TRIMMABLE-BOUNDARY-START(34362032209),
    {
      "r": 91815937,
      "n": "CreateInvalidOperationException_InvalidZeroByteRead",
      "d": 2293841,
      "h": 34362032209,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34362032209),
//--TRIMMABLE-BOUNDARY-START(128851312721),
    {
      "r": 65537,
      "n": "ThrowNotSupported_UnflushedBytes",
      "d": 2293841,
      "h": 128851312721,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128851312721),
//--TRIMMABLE-BOUNDARY-START(60131835985),
    {
      "r": 100401153,
      "n": "CreateNotSupportedException_UnflushedBytes",
      "d": 2293841,
      "h": 60131835985,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60131835985)
  ],
  "h": 2293841
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.ThrowHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}ThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293841)
        
        

        //--TRIMMABLE-BOUNDARY-START(2424913)
        $asm.$cls(`$sipl.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(309240070225)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(309240070225)
            
            //--TRIMMABLE-BOUNDARY-START(300650135633)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(300650135633)
            
            //--TRIMMABLE-BOUNDARY-START(304945102929)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750789713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$sipl.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.IO.Pipelines", $.$sipl.S.SR.$type.Assembly);
                    $.$sipl.S.SR.s_resourceManager = temp;
                }
                return $.$sipl.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(304945102929)
            
            //--TRIMMABLE-BOUNDARY-START(21477261393)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491705425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sipl.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124972113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sipl.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21477261393)
            
            //--TRIMMABLE-BOUNDARY-START(8592359505)
            static /*string */ get AdvanceToInvalidCursor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721901649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The PipeReader has already advanced past the provided position.";
            }
            //--TRIMMABLE-BOUNDARY-END(8592359505)
            
            //--TRIMMABLE-BOUNDARY-START(12887326801)
            static /*string */ get ArgumentOutOfRange_NeedPosNum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311836241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Positive number required.";
            }
            //--TRIMMABLE-BOUNDARY-END(12887326801)
            
            //--TRIMMABLE-BOUNDARY-START(17182294097)
            static /*string */ get ConcurrentOperationsNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901770833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Concurrent reads or writes are not supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(17182294097)
            
            //--TRIMMABLE-BOUNDARY-START(25772228689)
            static /*string */ get FlushCanceledOnPipeWriter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081640017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Flush was canceled on underlying PipeWriter.";
            }
            //--TRIMMABLE-BOUNDARY-END(25772228689)
            
            //--TRIMMABLE-BOUNDARY-START(244815560785)
            static /*string */ get GetResultBeforeCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671574609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Can't GetResult unless awaiter is completed.";
            }
            //--TRIMMABLE-BOUNDARY-END(244815560785)
            
            //--TRIMMABLE-BOUNDARY-START(253405495377)
            static /*string */ get InvalidExaminedOrConsumedPosition()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261509201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The examined position must be greater than or equal to the consumed position.";
            }
            //--TRIMMABLE-BOUNDARY-END(253405495377)
            
            //--TRIMMABLE-BOUNDARY-START(257700462673)
            static /*string */ get InvalidExaminedPosition()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851443793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The examined position cannot be less than the previously examined position.";
            }
            //--TRIMMABLE-BOUNDARY-END(257700462673)
            
            //--TRIMMABLE-BOUNDARY-START(261995429969)
            static /*string */ get InvalidZeroByteRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441378385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The PipeReader returned 0 bytes when the ReadResult was not completed or canceled.";
            }
            //--TRIMMABLE-BOUNDARY-END(261995429969)
            
            //--TRIMMABLE-BOUNDARY-START(279175299153)
            static /*string */ get ObjectDisposed_StreamClosed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801116753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot access a closed stream.";
            }
            //--TRIMMABLE-BOUNDARY-END(279175299153)
            
            //--TRIMMABLE-BOUNDARY-START(266290397265)
            static /*string */ get NoReadingOperationToComplete()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031312977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No reading operation to complete.";
            }
            //--TRIMMABLE-BOUNDARY-END(266290397265)
            
            //--TRIMMABLE-BOUNDARY-START(270585364561)
            static /*string */ get NotSupported_UnreadableStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621247569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stream does not support reading.";
            }
            //--TRIMMABLE-BOUNDARY-END(270585364561)
            
            //--TRIMMABLE-BOUNDARY-START(274880331857)
            static /*string */ get NotSupported_UnwritableStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211182161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stream does not support writing.";
            }
            //--TRIMMABLE-BOUNDARY-END(274880331857)
            
            //--TRIMMABLE-BOUNDARY-START(283470266449)
            static /*string */ get ReadCanceledOnPipeReader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391051345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Read was canceled on underlying PipeReader.";
            }
            //--TRIMMABLE-BOUNDARY-END(283470266449)
            
            //--TRIMMABLE-BOUNDARY-START(287765233745)
            static /*string */ get ReaderAndWriterHasToBeCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980985937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Both reader and writer has to be completed to be able to reset the pipe.";
            }
            //--TRIMMABLE-BOUNDARY-END(287765233745)
            
            //--TRIMMABLE-BOUNDARY-START(292060201041)
            static /*string */ get ReadingAfterCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570920529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Reading is not allowed after reader was completed.";
            }
            //--TRIMMABLE-BOUNDARY-END(292060201041)
            
            //--TRIMMABLE-BOUNDARY-START(296355168337)
            static /*string */ get ReadingIsInProgress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160855121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Reading is already in progress.";
            }
            //--TRIMMABLE-BOUNDARY-END(296355168337)
            
            //--TRIMMABLE-BOUNDARY-START(335009874001)
            static /*string */ get WritingAfterCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930658897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Writing is not allowed after writer was completed.";
            }
            //--TRIMMABLE-BOUNDARY-END(335009874001)
            
            //--TRIMMABLE-BOUNDARY-START(326419939409)
            static /*string */ get UnflushedBytesNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340724305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "UnflushedBytes is not supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(326419939409)
            
            //--TRIMMABLE-BOUNDARY-START(313535037521)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(313535037521)
            
            //--TRIMMABLE-BOUNDARY-START(249110528081)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(249110528081);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249110528081)
            
            //--TRIMMABLE-BOUNDARY-START(330714906705)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(330714906705);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sipl.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(330714906705)
            
            //--TRIMMABLE-BOUNDARY-START(240520593489)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520593489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sipl.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sipl.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(240520593489)
            
            //--TRIMMABLE-BOUNDARY-START(236225626193)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225626193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sipl.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(236225626193)
            
            //--TRIMMABLE-BOUNDARY-START(55836999761)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836999761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sipl.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(55836999761)
            
            //--TRIMMABLE-BOUNDARY-START(51542032465)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542032465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sipl.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(51542032465)
            
            //--TRIMMABLE-BOUNDARY-START(47247065169)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247065169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sipl.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(47247065169)
            
            //--TRIMMABLE-BOUNDARY-START(60131967057)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131967057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sipl.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(60131967057)
            
            //--TRIMMABLE-BOUNDARY-START(38657130577)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657130577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sipl.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38657130577)
            
            //--TRIMMABLE-BOUNDARY-START(34362163281)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362163281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sipl.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34362163281)
            
            //--TRIMMABLE-BOUNDARY-START(30067195985)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067195985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sipl.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30067195985)
            
            //--TRIMMABLE-BOUNDARY-START(42952097873)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952097873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sipl.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42952097873)
            
            //--TRIMMABLE-BOUNDARY-START(4297392209)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297392209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(313535037521)
                    this.s_usingResourceKeys = $.$sipl.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(313535037521)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297392209)
            
            static $h = 2424913;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2424913
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424913)
        
        

        //--TRIMMABLE-BOUNDARY-START(2031697)
        $asm.$cls(`$sipl.SIP.StreamPipeReaderOptions`, ($self) => class StreamPipeReaderOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51541639249)
            /*int*/ static DefaultBufferSize = 4096;
            //--TRIMMABLE-BOUNDARY-END(51541639249)
            
            //--TRIMMABLE-BOUNDARY-START(55836606545)
            /*int*/ static DefaultMaxBufferSize = 2097152;
            //--TRIMMABLE-BOUNDARY-END(55836606545)
            
            //--TRIMMABLE-BOUNDARY-START(60131573841)
            /*int*/ static DefaultMinimumReadSize = 1024;
            //--TRIMMABLE-BOUNDARY-END(60131573841)
            
            //--TRIMMABLE-BOUNDARY-START(146030919761)
            /*StreamPipeReaderOptions*/ static s_default = null;
            //--TRIMMABLE-BOUNDARY-END(146030919761)
            
            //--TRIMMABLE-BOUNDARY-START(42951704657)
            $ctor$2(/*MemoryPool<byte>?*/ pool, /*int*/ bufferSize, /*int*/ minimumReadSize, /*bool*/ leaveOpen)
            {
                this.$ctor$1(pool, bufferSize, minimumReadSize, leaveOpen, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951704657);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951704657)
            
            //--TRIMMABLE-BOUNDARY-START(38656737361)
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*int*/ bufferSize, /*int*/ minimumReadSize, /*bool*/ leaveOpen, /*bool*/ useZeroByteReads)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656737361);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Pool = pool ?? $.$sm.SB.MemoryPool$$($.$$.S.Byte).Shared;
                    this.IsDefaultSharedMemoryPool = this.Pool === $.$sm.SB.MemoryPool$$($.$$.S.Byte).Shared;
                    this.BufferSize = bufferSize === -1 ? 4096/*DefaultBufferSize*/ : bufferSize <= 0 ? (() =>
                    {
        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("bufferSize")            })() : bufferSize;
                    this.MinimumReadSize = minimumReadSize === -1 ? 1024/*DefaultMinimumReadSize*/ : minimumReadSize <= 0 ? (() =>
                    {
        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("minimumReadSize")            })() : minimumReadSize;
                    this.LeaveOpen = leaveOpen;
                    this.UseZeroByteReads = useZeroByteReads;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656737361)
            
            //--TRIMMABLE-BOUNDARY-START(47246671953)
            /*int*/ BufferSize = 0;
            //--TRIMMABLE-BOUNDARY-END(47246671953)
            
            //--TRIMMABLE-BOUNDARY-START(133146017873)
            /*int*/ MaxBufferSize = 0;
            //--TRIMMABLE-BOUNDARY-END(133146017873)
            
            //--TRIMMABLE-BOUNDARY-START(137440985169)
            /*int*/ MinimumReadSize = 0;
            //--TRIMMABLE-BOUNDARY-END(137440985169)
            
            //--TRIMMABLE-BOUNDARY-START(141735952465)
            /*MemoryPool<byte>*/ Pool = null;
            //--TRIMMABLE-BOUNDARY-END(141735952465)
            
            //--TRIMMABLE-BOUNDARY-START(128851050577)
            /*bool*/ LeaveOpen = false;
            //--TRIMMABLE-BOUNDARY-END(128851050577)
            
            //--TRIMMABLE-BOUNDARY-START(150325887057)
            /*bool*/ UseZeroByteReads = false;
            //--TRIMMABLE-BOUNDARY-END(150325887057)
            
            //--TRIMMABLE-BOUNDARY-START(124556083281)
            /*bool*/ IsDefaultSharedMemoryPool = false;
            //--TRIMMABLE-BOUNDARY-END(124556083281)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(133146017873)
                this.MaxBufferSize = 2097152;
                //--TRIMMABLE-BOUNDARY-END(133146017873)
                
            }
            //--TRIMMABLE-BOUNDARY-START(34361770065)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361770065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(146030919761)
                    this.s_default = new $.$sipl.SIP.StreamPipeReaderOptions().$ctor$1(null, -1, -1, false, false);
                    //--TRIMMABLE-BOUNDARY-END(146030919761)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361770065)
            
            static $h = 2031697;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246671953),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721508433,
        "f": 50331649
      },
      "n": "BufferSize",
      "d": 2031697,
      "h": 47246671953,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246671953),
//--TRIMMABLE-BOUNDARY-START(133146017873),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491312209,
        "f": 50331656
      },
      "n": "MaxBufferSize",
      "d": 2031697,
      "h": 133146017873,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(133146017873),
//--TRIMMABLE-BOUNDARY-START(137440985169),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081246801,
        "f": 50331649
      },
      "n": "MinimumReadSize",
      "d": 2031697,
      "h": 137440985169,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137440985169),
//--TRIMMABLE-BOUNDARY-START(141735952465),
    {
      "p": $.$sm.SB.MemoryPool$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671181393,
        "f": 50331649
      },
      "n": "Pool",
      "d": 2031697,
      "h": 141735952465,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141735952465),
//--TRIMMABLE-BOUNDARY-START(128851050577),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901377617,
        "f": 50331649
      },
      "n": "LeaveOpen",
      "d": 2031697,
      "h": 128851050577,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128851050577),
//--TRIMMABLE-BOUNDARY-START(150325887057),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261115985,
        "f": 50331649
      },
      "n": "UseZeroByteReads",
      "d": 2031697,
      "h": 150325887057,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150325887057),
//--TRIMMABLE-BOUNDARY-START(124556083281),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311443025,
        "f": 50331656
      },
      "n": "IsDefaultSharedMemoryPool",
      "d": 2031697,
      "h": 124556083281,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(124556083281)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51541639249),
    {
      "t": 655361,
      "n": "DefaultBufferSize",
      "d": 2031697,
      "h": 51541639249,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51541639249),
//--TRIMMABLE-BOUNDARY-START(55836606545),
    {
      "t": 655361,
      "n": "DefaultMaxBufferSize",
      "d": 2031697,
      "h": 55836606545,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55836606545),
//--TRIMMABLE-BOUNDARY-START(60131573841),
    {
      "t": 655361,
      "n": "DefaultMinimumReadSize",
      "d": 2031697,
      "h": 60131573841,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60131573841),
//--TRIMMABLE-BOUNDARY-START(146030919761),
    {
      "t": 2031697,
      "n": "s_default",
      "d": 2031697,
      "h": 146030919761,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146030919761)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42951704657),
    {
      "p": [
        {
          "n": "pool",
          "p": $.$sm.SB.MemoryPool$$($.$$.S.Byte).$h
        },
        {
          "n": "bufferSize",
          "p": 655361
        },
        {
          "n": "minimumReadSize",
          "p": 655361
        },
        {
          "n": "leaveOpen",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2031697,
      "h": 42951704657,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951704657),
//--TRIMMABLE-BOUNDARY-START(38656737361),
    {
      "p": [
        {
          "n": "pool",
          "p": $.$sm.SB.MemoryPool$$($.$$.S.Byte).$h,
          "f": 65
        },
        {
          "n": "bufferSize",
          "p": 655361,
          "f": 65,
          "v": -1
        },
        {
          "n": "minimumReadSize",
          "p": 655361,
          "f": 65,
          "v": -1
        },
        {
          "n": "leaveOpen",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "useZeroByteReads",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2031697,
      "h": 38656737361,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656737361)
  ],
  "h": 2031697
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.StreamPipeReaderOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}StreamPipeReaderOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031697)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114193)
        $asm.$cls(`$sipl.SIP.PipeCompletionCallbacks`, ($self) => class PipeCompletionCallbacks extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296081489)
            /*List<PipeCompletionCallback>*/ _callbacks = null;
            //--TRIMMABLE-BOUNDARY-END(4296081489)
            
            //--TRIMMABLE-BOUNDARY-START(8591048785)
            /*Exception?*/ _exception = null;
            //--TRIMMABLE-BOUNDARY-END(8591048785)
            
            //--TRIMMABLE-BOUNDARY-START(12886016081)
            $ctor$1(/*List<PipeCompletionCallback>*/ callbacks, /*ExceptionDispatchInfo?*/ edi)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886016081);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._callbacks = callbacks;
                    this._exception = (edi?.SourceException ?? null);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886016081)
            
            //--TRIMMABLE-BOUNDARY-START(17180983377)
            /*void */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180983377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let count = this._callbacks.Count;
                if (count === 0)
                {
                    return;
                }
                /*List<Exception>?*/ let exceptions = null;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*var*/ let callback = this._callbacks.get_Item(i);
                    this.Execute$1(callback, $.$ref(() => exceptions, ($v) => exceptions = $v, $.$$.SCG.List$$($.$$.S.Exception)));
                }
                if (exceptions !== null)
                {
                    throw new $.$$.S.AggregateException().$ctor$6(exceptions);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180983377)
            
            //--TRIMMABLE-BOUNDARY-START(21475950673)
            /*void */ Execute$1(/*PipeCompletionCallback*/ callback, /*ref List<Exception>?*/ exceptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475950673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    callback.Callback.Invoke(this._exception, callback.State);
                }
                catch(ex)
                {
                    exceptions.$v ??= new ($.$$.SCG.List$$($.$$.S.Exception))().$ctor$1();
                    exceptions.$v.Add(ex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475950673)
            
            static $h = 1114193;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180983377),
    {
      "r": 65537,
      "n": "Execute",
      "d": 1114193,
      "h": 17180983377,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180983377),
//--TRIMMABLE-BOUNDARY-START(21475950673),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": 1048657
        },
        {
          "n": "exceptions",
          "p": $.$$.SCG.List$$($.$$.S.Exception).$h,
          "f": 4
        }
      ],
      "n": "Execute",
      "o": "@$1",
      "d": 1114193,
      "h": 21475950673,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475950673)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081489),
    {
      "t": $.$$.SCG.List$$($.$sipl.SIP.PipeCompletionCallback).$h,
      "n": "_callbacks",
      "d": 1114193,
      "h": 4296081489,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081489),
//--TRIMMABLE-BOUNDARY-START(8591048785),
    {
      "t": 80805889,
      "n": "_exception",
      "d": 1114193,
      "h": 8591048785,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591048785)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886016081),
    {
      "p": [
        {
          "n": "callbacks",
          "p": $.$$.SCG.List$$($.$sipl.SIP.PipeCompletionCallback).$h
        },
        {
          "n": "edi",
          "p": 135790593
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114193,
      "h": 12886016081,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016081)
  ],
  "h": 1114193
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeCompletionCallbacks`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeCompletionCallbacks`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114193)
        
        

        //--TRIMMABLE-BOUNDARY-START(2162769)
        $asm.$cls(`$sipl.SIP.StreamPipeWriterOptions`, ($self) => class StreamPipeWriterOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25771966545)
            /*int*/ static DefaultMinimumBufferSize = 4096;
            //--TRIMMABLE-BOUNDARY-END(25771966545)
            
            //--TRIMMABLE-BOUNDARY-START(68721639505)
            /*StreamPipeWriterOptions*/ static s_default = null;
            //--TRIMMABLE-BOUNDARY-END(68721639505)
            
            //--TRIMMABLE-BOUNDARY-START(21476999249)
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*int*/ minimumBufferSize, /*bool*/ leaveOpen)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476999249);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Pool = pool ?? $.$sm.SB.MemoryPool$$($.$$.S.Byte).Shared;
                    this.MinimumBufferSize = minimumBufferSize === -1 ? 4096/*DefaultMinimumBufferSize*/ : minimumBufferSize <= 0 ? (() =>
                    {
        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("minimumBufferSize")            })() : minimumBufferSize;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476999249)
            
            //--TRIMMABLE-BOUNDARY-START(60131704913)
            /*int*/ MinimumBufferSize = 0;
            //--TRIMMABLE-BOUNDARY-END(60131704913)
            
            //--TRIMMABLE-BOUNDARY-START(64426672209)
            /*MemoryPool<byte>*/ Pool = null;
            //--TRIMMABLE-BOUNDARY-END(64426672209)
            
            //--TRIMMABLE-BOUNDARY-START(55836737617)
            /*bool*/ LeaveOpen = false;
            //--TRIMMABLE-BOUNDARY-END(55836737617)
            
            //--TRIMMABLE-BOUNDARY-START(17182031953)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182031953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(68721639505)
                    this.s_default = new $.$sipl.SIP.StreamPipeWriterOptions().$ctor$1(null, -1, false);
                    //--TRIMMABLE-BOUNDARY-END(68721639505)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182031953)
            
            static $h = 2162769;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60131704913),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951835729,
        "f": 50331649
      },
      "n": "MinimumBufferSize",
      "d": 2162769,
      "h": 60131704913,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131704913),
//--TRIMMABLE-BOUNDARY-START(64426672209),
    {
      "p": $.$sm.SB.MemoryPool$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541770321,
        "f": 50331649
      },
      "n": "Pool",
      "d": 2162769,
      "h": 64426672209,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426672209),
//--TRIMMABLE-BOUNDARY-START(55836737617),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361901137,
        "f": 50331649
      },
      "n": "LeaveOpen",
      "d": 2162769,
      "h": 55836737617,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836737617)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771966545),
    {
      "t": 655361,
      "n": "DefaultMinimumBufferSize",
      "d": 2162769,
      "h": 25771966545,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25771966545),
//--TRIMMABLE-BOUNDARY-START(68721639505),
    {
      "t": 2162769,
      "n": "s_default",
      "d": 2162769,
      "h": 68721639505,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68721639505)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476999249),
    {
      "p": [
        {
          "n": "pool",
          "p": $.$sm.SB.MemoryPool$$($.$$.S.Byte).$h,
          "f": 65
        },
        {
          "n": "minimumBufferSize",
          "p": 655361,
          "f": 65,
          "v": -1
        },
        {
          "n": "leaveOpen",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162769,
      "h": 21476999249,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476999249)
  ],
  "h": 2162769
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.StreamPipeWriterOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}StreamPipeWriterOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162769)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310801)
        $asm.$cls(`$sipl.SIP.PipeOptions`, ($self) => class PipeOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64425820241)
            /*int*/ static DefaultMinimumSegmentSize = 4096;
            //--TRIMMABLE-BOUNDARY-END(64425820241)
            
            //--TRIMMABLE-BOUNDARY-START(60130852945)
            /*PipeOptions*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(60130852945)
            
            //--TRIMMABLE-BOUNDARY-START(55835885649)
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*PipeScheduler?*/ readerScheduler, /*PipeScheduler?*/ writerScheduler, /*long*/ pauseWriterThreshold, /*long*/ resumeWriterThreshold, /*int*/ minimumSegmentSize, /*bool*/ useSynchronizationContext)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835885649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MinimumSegmentSize = minimumSegmentSize === -1 ? 4096/*DefaultMinimumSegmentSize*/ : minimumSegmentSize;
                    this.InitialSegmentPoolSize = 4;
                    this.MaxSegmentPoolSize = 256;
                    /*int*/ let DefaultPauseWriterThreshold = 65536;
                    /*int*/ let DefaultResumeWriterThreshold = $.trunc(DefaultPauseWriterThreshold / 2);
                    if (pauseWriterThreshold === BigInt(-1))
                    {
                        pauseWriterThreshold = BigInt(DefaultPauseWriterThreshold);
                    }
                    else if (pauseWriterThreshold < 0n)
                    {
                        $.$sipl.SIP.ThrowHelper.ThrowArgumentOutOfRangeException(4/*ExceptionArgument.pauseWriterThreshold*/);
                    }
                    if (resumeWriterThreshold === BigInt(-1))
                    {
                        resumeWriterThreshold = BigInt(DefaultResumeWriterThreshold);
                    }
                    else if (resumeWriterThreshold === 0n)
                    {
                        resumeWriterThreshold = 1n;
                    }
                    if (resumeWriterThreshold < 0n || (pauseWriterThreshold > 0n && resumeWriterThreshold > pauseWriterThreshold))
                    {
                        $.$sipl.SIP.ThrowHelper.ThrowArgumentOutOfRangeException(5/*ExceptionArgument.resumeWriterThreshold*/);
                    }
                    this.Pool = pool ?? $.$sm.SB.MemoryPool$$($.$$.S.Byte).Shared;
                    this.IsDefaultSharedMemoryPool = this.Pool === $.$sm.SB.MemoryPool$$($.$$.S.Byte).Shared;
                    this.ReaderScheduler = readerScheduler ?? $.$sipl.SIP.PipeScheduler.ThreadPool;
                    this.WriterScheduler = writerScheduler ?? $.$sipl.SIP.PipeScheduler.ThreadPool;
                    this.PauseWriterThreshold = pauseWriterThreshold;
                    this.ResumeWriterThreshold = resumeWriterThreshold;
                    this.UseSynchronizationContext = useSynchronizationContext;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835885649)
            
            //--TRIMMABLE-BOUNDARY-START(197569806417)
            /*bool*/ UseSynchronizationContext = false;
            //--TRIMMABLE-BOUNDARY-END(197569806417)
            
            //--TRIMMABLE-BOUNDARY-START(180389937233)
            /*long*/ PauseWriterThreshold = 0n;
            //--TRIMMABLE-BOUNDARY-END(180389937233)
            
            //--TRIMMABLE-BOUNDARY-START(193274839121)
            /*long*/ ResumeWriterThreshold = 0n;
            //--TRIMMABLE-BOUNDARY-END(193274839121)
            
            //--TRIMMABLE-BOUNDARY-START(176094969937)
            /*int*/ MinimumSegmentSize = 0;
            //--TRIMMABLE-BOUNDARY-END(176094969937)
            
            //--TRIMMABLE-BOUNDARY-START(201864773713)
            /*PipeScheduler*/ WriterScheduler = null;
            //--TRIMMABLE-BOUNDARY-END(201864773713)
            
            //--TRIMMABLE-BOUNDARY-START(188979871825)
            /*PipeScheduler*/ ReaderScheduler = null;
            //--TRIMMABLE-BOUNDARY-END(188979871825)
            
            //--TRIMMABLE-BOUNDARY-START(184684904529)
            /*MemoryPool<byte>*/ Pool = null;
            //--TRIMMABLE-BOUNDARY-END(184684904529)
            
            //--TRIMMABLE-BOUNDARY-START(167505035345)
            /*bool*/ IsDefaultSharedMemoryPool = false;
            //--TRIMMABLE-BOUNDARY-END(167505035345)
            
            //--TRIMMABLE-BOUNDARY-START(163210068049)
            /*int*/ InitialSegmentPoolSize = 0;
            //--TRIMMABLE-BOUNDARY-END(163210068049)
            
            //--TRIMMABLE-BOUNDARY-START(171800002641)
            /*int*/ MaxSegmentPoolSize = 0;
            //--TRIMMABLE-BOUNDARY-END(171800002641)
            
            //--TRIMMABLE-BOUNDARY-START(51540918353)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540918353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(60130852945)
                    this.Default = new $.$sipl.SIP.PipeOptions().$ctor$1(null, null, null, -1n, -1n, -1, true);
                    //--TRIMMABLE-BOUNDARY-END(60130852945)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540918353)
            
            static $h = 1310801;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130852945),
    {
      "p": 1310801,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015754833,
        "f": 50331681
      },
      "n": "Default",
      "d": 1310801,
      "h": 60130852945,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(60130852945),
//--TRIMMABLE-BOUNDARY-START(197569806417),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325166161,
        "f": 50331649
      },
      "n": "UseSynchronizationContext",
      "d": 1310801,
      "h": 197569806417,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569806417),
//--TRIMMABLE-BOUNDARY-START(180389937233),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965427793,
        "f": 50331649
      },
      "n": "PauseWriterThreshold",
      "d": 1310801,
      "h": 180389937233,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180389937233),
//--TRIMMABLE-BOUNDARY-START(193274839121),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735231569,
        "f": 50331649
      },
      "n": "ResumeWriterThreshold",
      "d": 1310801,
      "h": 193274839121,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274839121),
//--TRIMMABLE-BOUNDARY-START(176094969937),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375493201,
        "f": 50331649
      },
      "n": "MinimumSegmentSize",
      "d": 1310801,
      "h": 176094969937,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176094969937),
//--TRIMMABLE-BOUNDARY-START(201864773713),
    {
      "p": 1507409,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915100753,
        "f": 50331649
      },
      "n": "WriterScheduler",
      "d": 1310801,
      "h": 201864773713,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864773713),
//--TRIMMABLE-BOUNDARY-START(188979871825),
    {
      "p": 1507409,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145296977,
        "f": 50331649
      },
      "n": "ReaderScheduler",
      "d": 1310801,
      "h": 188979871825,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188979871825),
//--TRIMMABLE-BOUNDARY-START(184684904529),
    {
      "p": $.$sm.SB.MemoryPool$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555362385,
        "f": 50331649
      },
      "n": "Pool",
      "d": 1310801,
      "h": 184684904529,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184684904529),
//--TRIMMABLE-BOUNDARY-START(167505035345),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195624017,
        "f": 50331656
      },
      "n": "IsDefaultSharedMemoryPool",
      "d": 1310801,
      "h": 167505035345,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(167505035345),
//--TRIMMABLE-BOUNDARY-START(163210068049),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605689425,
        "f": 50331656
      },
      "n": "InitialSegmentPoolSize",
      "d": 1310801,
      "h": 163210068049,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(163210068049),
//--TRIMMABLE-BOUNDARY-START(171800002641),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785558609,
        "f": 50331656
      },
      "n": "MaxSegmentPoolSize",
      "d": 1310801,
      "h": 171800002641,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(171800002641)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64425820241),
    {
      "t": 655361,
      "n": "DefaultMinimumSegmentSize",
      "d": 1310801,
      "h": 64425820241,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64425820241)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835885649),
    {
      "p": [
        {
          "n": "pool",
          "p": $.$sm.SB.MemoryPool$$($.$$.S.Byte).$h,
          "f": 65
        },
        {
          "n": "readerScheduler",
          "p": 1507409,
          "f": 65
        },
        {
          "n": "writerScheduler",
          "p": 1507409,
          "f": 65
        },
        {
          "n": "pauseWriterThreshold",
          "p": 917505,
          "f": 65,
          "v": -1
        },
        {
          "n": "resumeWriterThreshold",
          "p": 917505,
          "f": 65,
          "v": -1
        },
        {
          "n": "minimumSegmentSize",
          "p": 655361,
          "f": 65,
          "v": -1
        },
        {
          "n": "useSynchronizationContext",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310801,
      "h": 55835885649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835885649)
  ],
  "h": 1310801
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310801)
        
        

        //--TRIMMABLE-BOUNDARY-START(524369)
        $asm.$cls(`$sipl.SIP.InlineScheduler`, ($self) => class InlineScheduler extends $.$sipl.SIP.PipeScheduler
        {
            //--TRIMMABLE-BOUNDARY-START(8590458961)
            /*void */ Schedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590458961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                action.Invoke(state);
            }
            //--TRIMMABLE-BOUNDARY-END(8590458961)
            
            //--TRIMMABLE-BOUNDARY-START(12885426257)
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885426257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                action.Invoke(state);
            }
            //--TRIMMABLE-BOUNDARY-END(12885426257)
            
            //--TRIMMABLE-BOUNDARY-START(4295491665)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491665)
            
            //--TRIMMABLE-BOUNDARY-START(4295491665)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295491665)
            
            static $h = 524369;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sipl.SIP.PipeScheduler; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590458961),
    {
      "r": 65537,
      "p": [
        {
          "n": "action",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "Schedule",
      "d": 524369,
      "h": 8590458961,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590458961),
//--TRIMMABLE-BOUNDARY-START(12885426257),
    {
      "r": 65537,
      "p": [
        {
          "n": "action",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "UnsafeSchedule",
      "d": 524369,
      "h": 12885426257,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(12885426257)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491665),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524369,
      "h": 4295491665,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491665)
  ],
  "h": 524369
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.InlineScheduler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}InlineScheduler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524369)
        
        

        //--TRIMMABLE-BOUNDARY-START(262225)
        $asm.$str(`$sipl.SIP.CompletionData`, ($self) => class CompletionData extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(30065033297)
            /*Action<object?>*/ Completion = null;
            //--TRIMMABLE-BOUNDARY-END(30065033297)
            
            //--TRIMMABLE-BOUNDARY-START(34360000593)
            /*object?*/ CompletionState = null;
            //--TRIMMABLE-BOUNDARY-END(34360000593)
            
            //--TRIMMABLE-BOUNDARY-START(38654967889)
            /*ExecutionContext?*/ ExecutionContext = null;
            //--TRIMMABLE-BOUNDARY-END(38654967889)
            
            //--TRIMMABLE-BOUNDARY-START(77309673553)
            /*SynchronizationContext?*/ SynchronizationContext = null;
            //--TRIMMABLE-BOUNDARY-END(77309673553)
            
            //--TRIMMABLE-BOUNDARY-START(25770066001)
            $ctor$3(/*Action<object?>*/ completion, /*object?*/ completionState, /*ExecutionContext?*/ executionContext, /*SynchronizationContext?*/ synchronizationContext)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770066001);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Completion = completion;
                    this.CompletionState = completionState;
                    this.ExecutionContext = executionContext;
                    this.SynchronizationContext = synchronizationContext;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770066001)
            
            //--TRIMMABLE-BOUNDARY-START(21475098705)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098705)
            
            //--TRIMMABLE-BOUNDARY-START(21475098705)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21475098705)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Completion = this.Completion;
                copy.CompletionState = this.CompletionState;
                copy.ExecutionContext = this.ExecutionContext;
                copy.SynchronizationContext = this.SynchronizationContext;
                return copy;
            }
            static $h = 262225;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065033297),
    {
      "p": $.$$.S.Action$$($.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244902481,
        "f": 50331649
      },
      "n": "Completion",
      "d": 262225,
      "h": 30065033297,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065033297),
//--TRIMMABLE-BOUNDARY-START(34360000593),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834837073,
        "f": 50331649
      },
      "n": "CompletionState",
      "d": 262225,
      "h": 34360000593,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360000593),
//--TRIMMABLE-BOUNDARY-START(38654967889),
    {
      "p": 171835393,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424771665,
        "f": 50331649
      },
      "n": "ExecutionContext",
      "d": 262225,
      "h": 38654967889,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654967889),
//--TRIMMABLE-BOUNDARY-START(77309673553),
    {
      "p": 176095233,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014706257,
        "f": 50331649
      },
      "n": "SynchronizationContext",
      "d": 262225,
      "h": 77309673553,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309673553)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770066001),
    {
      "p": [
        {
          "n": "completion",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "completionState",
          "p": 131073
        },
        {
          "n": "executionContext",
          "p": 171835393
        },
        {
          "n": "synchronizationContext",
          "p": 176095233
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262225,
      "h": 25770066001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770066001),
//--TRIMMABLE-BOUNDARY-START(21475098705),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262225,
      "h": 21475098705,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475098705)
  ],
  "h": 262225
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.CompletionData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}CompletionData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262225)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048657)
        $asm.$str(`$sipl.SIP.PipeCompletionCallback`, ($self) => class PipeCompletionCallback extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12885950545)
            /*Action<Exception?, object?>*/ Callback = null;
            //--TRIMMABLE-BOUNDARY-END(12885950545)
            
            //--TRIMMABLE-BOUNDARY-START(17180917841)
            /*object?*/ State = null;
            //--TRIMMABLE-BOUNDARY-END(17180917841)
            
            //--TRIMMABLE-BOUNDARY-START(8590983249)
            $ctor$3(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590983249);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Callback = callback;
                    this.State = state;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590983249)
            
            //--TRIMMABLE-BOUNDARY-START(4296015953)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296015953)
            
            //--TRIMMABLE-BOUNDARY-START(4296015953)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296015953)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Callback = this.Callback;
                copy.State = this.State;
                return copy;
            }
            static $h = 1048657;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885950545),
    {
      "t": $.$$.S.Action$$$($.$$.S.Exception, $.$$.S.Object).$h,
      "n": "Callback",
      "d": 1048657,
      "h": 12885950545,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12885950545),
//--TRIMMABLE-BOUNDARY-START(17180917841),
    {
      "t": 131073,
      "n": "State",
      "d": 1048657,
      "h": 17180917841,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17180917841)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590983249),
    {
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$$($.$$.S.Exception, $.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1048657,
      "h": 8590983249,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590983249),
//--TRIMMABLE-BOUNDARY-START(4296015953),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048657,
      "h": 4296015953,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015953)
  ],
  "h": 1048657
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeCompletionCallback`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeCompletionCallback`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048657)
        
        

        //--TRIMMABLE-BOUNDARY-START(2228305)
        $asm.$cls(`$sipl.SIP.ThreadPoolScheduler`, ($self) => class ThreadPoolScheduler extends $.$sipl.SIP.PipeScheduler
        {
            //--TRIMMABLE-BOUNDARY-START(8592162897)
            /*void */ Schedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592162897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.ST$1.ThreadPool.QueueUserWorkItem$2($.$$.S.Object, action, state, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8592162897)
            
            //--TRIMMABLE-BOUNDARY-START(12887130193)
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887130193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.ST$1.ThreadPool.UnsafeQueueUserWorkItem$2($.$$.S.Object, action, state, false);
            }
            //--TRIMMABLE-BOUNDARY-END(12887130193)
            
            //--TRIMMABLE-BOUNDARY-START(4297195601)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297195601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297195601)
            
            //--TRIMMABLE-BOUNDARY-START(4297195601)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4297195601)
            
            static $h = 2228305;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sipl.SIP.PipeScheduler; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592162897),
    {
      "r": 65537,
      "p": [
        {
          "n": "action",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "Schedule",
      "d": 2228305,
      "h": 8592162897,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8592162897),
//--TRIMMABLE-BOUNDARY-START(12887130193),
    {
      "r": 65537,
      "p": [
        {
          "n": "action",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "UnsafeSchedule",
      "d": 2228305,
      "h": 12887130193,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(12887130193)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297195601),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2228305,
      "h": 4297195601,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297195601)
  ],
  "h": 2228305
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.ThreadPoolScheduler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}ThreadPoolScheduler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228305)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835089)
        $asm.$cls(`$sipl.SIP.SequencePipeReader`, ($self) => class SequencePipeReader extends $.$sipl.SIP.PipeReader
        {
            //--TRIMMABLE-BOUNDARY-START(12886736977)
            /*ReadOnlySequence<byte>*/ _sequence;
            //--TRIMMABLE-BOUNDARY-END(12886736977)
            
            //--TRIMMABLE-BOUNDARY-START(8591769681)
            /*bool*/ _isReaderCompleted = false;
            //--TRIMMABLE-BOUNDARY-END(8591769681)
            
            //--TRIMMABLE-BOUNDARY-START(4296802385)
            /*int*/ _cancelNext = 0;
            //--TRIMMABLE-BOUNDARY-END(4296802385)
            
            //--TRIMMABLE-BOUNDARY-START(17181704273)
            $ctor$2(/*ReadOnlySequence<byte>*/ sequence)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181704273);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._sequence = sequence;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181704273)
            
            //--TRIMMABLE-BOUNDARY-START(25771638865)
            /*void */ AdvanceTo$1(/*SequencePosition*/ consumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771638865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AdvanceTo(consumed, consumed);
            }
            //--TRIMMABLE-BOUNDARY-END(25771638865)
            
            //--TRIMMABLE-BOUNDARY-START(21476671569)
            /*void */ AdvanceTo(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476671569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfCompleted();
                if (consumed.Equals$2(this._sequence.End))
                {
                    this._sequence = $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).Empty;
                    return;
                }
                this._sequence = this._sequence.Slice$8(consumed);
            }
            //--TRIMMABLE-BOUNDARY-END(21476671569)
            
            //--TRIMMABLE-BOUNDARY-START(30066606161)
            /*void */ CancelPendingRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066606161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.ST$1.Interlocked.Exchange$3($.$ref(() => this._cancelNext, ($v) => this._cancelNext = $v, $.$$.S.Int32), 1);
            }
            //--TRIMMABLE-BOUNDARY-END(30066606161)
            
            //--TRIMMABLE-BOUNDARY-START(34361573457)
            /*void */ Complete(/*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361573457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isReaderCompleted)
                {
                    return;
                }
                this._isReaderCompleted = true;
                this._sequence = $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(34361573457)
            
            //--TRIMMABLE-BOUNDARY-START(38656540753)
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                /*ReadResult*/ let result;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656540753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.TryRead($.$ref(() => result, ($v) => result = $v, $.$sipl.SIP.ReadResult)))
                {
                    return new ($.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult))().$ctor$6(result);
                }
                result = new $.$sipl.SIP.ReadResult().$ctor$3($.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).Empty, false, true);
                return new ($.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult))().$ctor$6(result);
            }
            //--TRIMMABLE-BOUNDARY-END(38656540753)
            
            //--TRIMMABLE-BOUNDARY-START(47246475345)
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246475345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfCompleted();
                /*bool*/ let isCancellationRequested = $.$$.ST$1.Interlocked.Exchange$3($.$ref(() => this._cancelNext, ($v) => this._cancelNext = $v, $.$$.S.Int32), 0) === 1;
                if (isCancellationRequested || this._sequence.Length > 0n)
                {
                    result.$v = new $.$sipl.SIP.ReadResult().$ctor$3(this._sequence, isCancellationRequested, true);
                    return true;
                }
                result.$v = new $.$sipl.SIP.ReadResult();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(47246475345)
            
            //--TRIMMABLE-BOUNDARY-START(42951508049)
            /*void */ ThrowIfCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951508049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isReaderCompleted)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951508049)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12886736977)
                this._sequence = $.$default($.$sm.SB.ReadOnlySequence$$($.$$.S.Byte));
                //--TRIMMABLE-BOUNDARY-END(12886736977)
                
            }
            static $h = 1835089;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sipl.SIP.PipeReader; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771638865),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumed",
          "p": 1179656
        }
      ],
      "n": "AdvanceTo",
      "o": "@$1",
      "d": 1835089,
      "h": 25771638865,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771638865),
//--TRIMMABLE-BOUNDARY-START(21476671569),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumed",
          "p": 1179656
        },
        {
          "n": "examined",
          "p": 1179656
        }
      ],
      "n": "AdvanceTo",
      "d": 1835089,
      "h": 21476671569,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476671569),
//--TRIMMABLE-BOUNDARY-START(30066606161),
    {
      "r": 65537,
      "n": "CancelPendingRead",
      "d": 1835089,
      "h": 30066606161,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066606161),
//--TRIMMABLE-BOUNDARY-START(34361573457),
    {
      "r": 65537,
      "p": [
        {
          "n": "exception",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "Complete",
      "d": 1835089,
      "h": 34361573457,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361573457),
//--TRIMMABLE-BOUNDARY-START(38656540753),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "d": 1835089,
      "h": 38656540753,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656540753),
//--TRIMMABLE-BOUNDARY-START(47246475345),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": 1704017,
          "f": 2
        }
      ],
      "n": "TryRead",
      "d": 1835089,
      "h": 47246475345,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246475345),
//--TRIMMABLE-BOUNDARY-START(42951508049),
    {
      "r": 65537,
      "n": "ThrowIfCompleted",
      "d": 1835089,
      "h": 42951508049,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42951508049)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886736977),
    {
      "t": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h,
      "n": "_sequence",
      "d": 1835089,
      "h": 12886736977,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886736977),
//--TRIMMABLE-BOUNDARY-START(8591769681),
    {
      "t": 262145,
      "n": "_isReaderCompleted",
      "d": 1835089,
      "h": 8591769681,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591769681),
//--TRIMMABLE-BOUNDARY-START(4296802385),
    {
      "t": 655361,
      "n": "_cancelNext",
      "d": 1835089,
      "h": 4296802385,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296802385)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181704273),
    {
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1835089,
      "h": 17181704273,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181704273)
  ],
  "h": 1835089
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.SequencePipeReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}SequencePipeReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835089)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179729)
        $asm.$str(`$sipl.SIP.PipeOperationState`, ($self) => class PipeOperationState extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296147025)
            /*State*/ _state = 0;
            //--TRIMMABLE-BOUNDARY-END(4296147025)
            
            //--TRIMMABLE-BOUNDARY-START(12886081617)
            /*void */ BeginRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this._state & 1/*State.Reading*/) === 1/*State.Reading*/)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                }
                this._state |= 1/*State.Reading*/;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081617)
            
            //--TRIMMABLE-BOUNDARY-START(17181048913)
            /*void */ BeginReadTentative()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181048913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this._state & 1/*State.Reading*/) === 1/*State.Reading*/)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                }
                this._state |= 2/*State.ReadingTentative*/;
            }
            //--TRIMMABLE-BOUNDARY-END(17181048913)
            
            //--TRIMMABLE-BOUNDARY-START(25770983505)
            /*void */ EndRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770983505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this._state & 1/*State.Reading*/) !== 1/*State.Reading*/ && (this._state & 2/*State.ReadingTentative*/) !== 2/*State.ReadingTentative*/)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_NoReadToComplete();
                }
                this._state &= ~(1/*State.Reading*/ | 2/*State.ReadingTentative*/);
            }
            //--TRIMMABLE-BOUNDARY-END(25770983505)
            
            //--TRIMMABLE-BOUNDARY-START(21476016209)
            /*void */ BeginWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._state |= 4/*State.Writing*/;
            }
            //--TRIMMABLE-BOUNDARY-END(21476016209)
            
            //--TRIMMABLE-BOUNDARY-START(30065950801)
            /*void */ EndWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065950801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._state &= ~4/*State.Writing*/;
            }
            //--TRIMMABLE-BOUNDARY-END(30065950801)
            
            //--TRIMMABLE-BOUNDARY-START(55835754577)
            /*bool */ get IsWritingActive()
            {
                return (this._state & 4/*State.Writing*/) === 4/*State.Writing*/;
            }
            //--TRIMMABLE-BOUNDARY-END(55835754577)
            
            //--TRIMMABLE-BOUNDARY-START(51540787281)
            /*bool */ get IsReadingActive()
            {
                return (this._state & 1/*State.Reading*/) === 1/*State.Reading*/;
            }
            //--TRIMMABLE-BOUNDARY-END(51540787281)
            
            //--TRIMMABLE-BOUNDARY-START(1245265)
            static $_State;
            static get State()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1245265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sipl.SIP.PipeOperationState;
                return $cls.$_State ??= $asm.$nstr(`$sipl.SIP.PipeOperationState.State`, ($self) => class State extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
                {
                    static Reading = 1;
                    static ReadingTentative = 2;
                    static Writing = 4;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(1245265);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "Reading": 1n,
                            "ReadingTentative": 2n,
                            "Writing": 4n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4296212561)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296212561);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296212561)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296212561)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296212561)
                    
                    static $h = 1245265;
                    static $z = 1;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Byte; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591179857),
    {
      "t": 1245265,
      "n": "Reading",
      "d": 1245265,
      "h": 8591179857,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591179857),
//--TRIMMABLE-BOUNDARY-START(12886147153),
    {
      "t": 1245265,
      "n": "ReadingTentative",
      "d": 1245265,
      "h": 12886147153,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886147153),
//--TRIMMABLE-BOUNDARY-START(17181114449),
    {
      "t": 1245265,
      "n": "Writing",
      "d": 1245265,
      "h": 17181114449,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181114449)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212561),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1245265,
      "h": 4296212561,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212561)
  ],
  "d": 1179729,
  "h": 1245265,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeOperationState+State`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeOperationState${separator}State`; }
                }, $cls, ($v) => $cls.$_State = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1245265)
            
            //--TRIMMABLE-BOUNDARY-START(8591114321)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114321)
            
            //--TRIMMABLE-BOUNDARY-START(8591114321)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8591114321)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._state = this._state;
                return copy;
            }
            static $h = 1179729;
            static $z = 1;
            static $f = 0b10000000000001010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835754577),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245819985,
        "f": 50331649
      },
      "n": "IsWritingActive",
      "d": 1179729,
      "h": 55835754577,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835754577),
//--TRIMMABLE-BOUNDARY-START(51540787281),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655885393,
        "f": 50331649
      },
      "n": "IsReadingActive",
      "d": 1179729,
      "h": 51540787281,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540787281)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886081617),
    {
      "r": 65537,
      "n": "BeginRead",
      "d": 1179729,
      "h": 12886081617,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886081617),
//--TRIMMABLE-BOUNDARY-START(17181048913),
    {
      "r": 65537,
      "n": "BeginReadTentative",
      "d": 1179729,
      "h": 17181048913,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048913),
//--TRIMMABLE-BOUNDARY-START(25770983505),
    {
      "r": 65537,
      "n": "EndRead",
      "d": 1179729,
      "h": 25770983505,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770983505),
//--TRIMMABLE-BOUNDARY-START(21476016209),
    {
      "r": 65537,
      "n": "BeginWrite",
      "d": 1179729,
      "h": 21476016209,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476016209),
//--TRIMMABLE-BOUNDARY-START(30065950801),
    {
      "r": 65537,
      "n": "EndWrite",
      "d": 1179729,
      "h": 30065950801,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065950801)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296147025),
    {
      "t": 1245265,
      "n": "_state",
      "d": 1179729,
      "h": 4296147025,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147025)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591114321),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179729,
      "h": 8591114321,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591114321)
  ],
  "h": 1179729,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "State = {_state}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sipl.SIP.PipeOperationState.State ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeOperationState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeOperationState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179729)
        
        

        //--TRIMMABLE-BOUNDARY-START(983121)
        $asm.$str(`$sipl.SIP.PipeCompletion`, ($self) => class PipeCompletion extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(64425492561)
            /*object*/ static s_completedSuccessfully = null;
            //--TRIMMABLE-BOUNDARY-END(64425492561)
            
            //--TRIMMABLE-BOUNDARY-START(8590917713)
            /*object?*/ _state = null;
            //--TRIMMABLE-BOUNDARY-END(8590917713)
            
            //--TRIMMABLE-BOUNDARY-START(4295950417)
            /*List<PipeCompletionCallback>?*/ _callbacks = null;
            //--TRIMMABLE-BOUNDARY-END(4295950417)
            
            //--TRIMMABLE-BOUNDARY-START(47245623377)
            /*bool */ get IsCompleted()
            {
                return this._state !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(47245623377)
            
            //--TRIMMABLE-BOUNDARY-START(55835557969)
            /*bool */ get IsFaulted()
            {
                return $.$is(this._state, $.$$.SRE$1.ExceptionDispatchInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(55835557969)
            
            //--TRIMMABLE-BOUNDARY-START(73015427153)
            /*PipeCompletionCallbacks? */ TryComplete(/*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015427153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._state === null)
                {
                    if (exception !== null)
                    {
                        this._state = $.$$.SRE$1.ExceptionDispatchInfo.Capture(exception);
                    }
                    else 
                    {
                        this._state = $.$sipl.SIP.PipeCompletion.s_completedSuccessfully;
                    }
                }
                return this.GetCallbacks();
            }
            //--TRIMMABLE-BOUNDARY-END(73015427153)
            
            //--TRIMMABLE-BOUNDARY-START(21475819601)
            /*PipeCompletionCallbacks? */ AddCallback(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._callbacks ??= new ($.$$.SCG.List$$($.$sipl.SIP.PipeCompletionCallback))().$ctor$1();
                this._callbacks.Add(new $.$sipl.SIP.PipeCompletionCallback().$ctor$3(callback, state));
                if (this.IsCompleted)
                {
                    return this.GetCallbacks();
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(21475819601)
            
            //--TRIMMABLE-BOUNDARY-START(51540590673)
            /*bool */ IsCompletedOrThrow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540590673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsCompleted)
                {
                    return false;
                }
                let edi;
                if ($.$is(this._state, $.$$.SRE$1.ExceptionDispatchInfo, { set $v($v){ edi = $v; } }))
                {
                    edi.Throw();
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(51540590673)
            
            //--TRIMMABLE-BOUNDARY-START(42950656081)
            /*PipeCompletionCallbacks? */ GetCallbacks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this.IsCompleted, "IsCompleted");
                /*var*/ let callbacks = this._callbacks;
                if (callbacks === null)
                {
                    return null;
                }
                this._callbacks = null;
                return new $.$sipl.SIP.PipeCompletionCallbacks().$ctor$1(callbacks, $.$as(this._state, $.$$.SRE$1.ExceptionDispatchInfo));
            }
            //--TRIMMABLE-BOUNDARY-END(42950656081)
            
            //--TRIMMABLE-BOUNDARY-START(60130525265)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130525265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this.IsCompleted, "IsCompleted");
                $.$$.SD.Debug.Assert$4(this._callbacks === null, "_callbacks == null");
                this._state = null;
            }
            //--TRIMMABLE-BOUNDARY-END(60130525265)
            
            //--TRIMMABLE-BOUNDARY-START(68720459857)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720459857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN("IsCompleted")}: ${$.$strNN(this.IsCompleted)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(68720459857)
            
            //--TRIMMABLE-BOUNDARY-START(17180852305)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180852305)
            
            //--TRIMMABLE-BOUNDARY-START(17180852305)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180852305)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._state = this._state;
                copy._callbacks = this._callbacks;
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(12885885009)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885885009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(64425492561)
                    this.s_completedSuccessfully = new $.$$.S.Object().$ctor();
                    //--TRIMMABLE-BOUNDARY-END(64425492561)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885885009)
            
            static $h = 983121;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245623377),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065754193,
        "f": 50331649
      },
      "n": "IsCompleted",
      "d": 983121,
      "h": 47245623377,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245623377),
//--TRIMMABLE-BOUNDARY-START(55835557969),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655688785,
        "f": 50331649
      },
      "n": "IsFaulted",
      "d": 983121,
      "h": 55835557969,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835557969)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015427153),
    {
      "r": 1114193,
      "p": [
        {
          "n": "exception",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "TryComplete",
      "d": 983121,
      "h": 73015427153,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015427153),
//--TRIMMABLE-BOUNDARY-START(21475819601),
    {
      "r": 1114193,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$$($.$$.S.Exception, $.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "AddCallback",
      "d": 983121,
      "h": 21475819601,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475819601),
//--TRIMMABLE-BOUNDARY-START(51540590673),
    {
      "r": 262145,
      "n": "IsCompletedOrThrow",
      "d": 983121,
      "h": 51540590673,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540590673),
//--TRIMMABLE-BOUNDARY-START(42950656081),
    {
      "r": 1114193,
      "n": "GetCallbacks",
      "d": 983121,
      "h": 42950656081,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950656081),
//--TRIMMABLE-BOUNDARY-START(60130525265),
    {
      "r": 65537,
      "n": "Reset",
      "d": 983121,
      "h": 60130525265,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130525265),
//--TRIMMABLE-BOUNDARY-START(68720459857),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 983121,
      "h": 68720459857,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720459857)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64425492561),
    {
      "t": 131073,
      "n": "s_completedSuccessfully",
      "d": 983121,
      "h": 64425492561,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64425492561),
//--TRIMMABLE-BOUNDARY-START(8590917713),
    {
      "t": 131073,
      "n": "_state",
      "d": 983121,
      "h": 8590917713,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590917713),
//--TRIMMABLE-BOUNDARY-START(4295950417),
    {
      "t": $.$$.SCG.List$$($.$sipl.SIP.PipeCompletionCallback).$h,
      "n": "_callbacks",
      "d": 983121,
      "h": 4295950417,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950417)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180852305),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983121,
      "h": 17180852305,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180852305)
  ],
  "h": 983121,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "IsCompleted = {IsCompleted}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeCompletion`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeCompletion`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983121)
        
        

        //--TRIMMABLE-BOUNDARY-START(786513)
        $asm.$str(`$sipl.SIP.PipeAwaitable`, ($self) => class PipeAwaitable extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295753809)
            /*AwaitableState*/ _awaitableState = 0;
            //--TRIMMABLE-BOUNDARY-END(4295753809)
            
            //--TRIMMABLE-BOUNDARY-START(12885688401)
            /*Action<object?>?*/ _completion = null;
            //--TRIMMABLE-BOUNDARY-END(12885688401)
            
            //--TRIMMABLE-BOUNDARY-START(17180655697)
            /*object?*/ _completionState = null;
            //--TRIMMABLE-BOUNDARY-END(17180655697)
            
            //--TRIMMABLE-BOUNDARY-START(21475622993)
            /*SchedulingContext?*/ _schedulingContext = null;
            //--TRIMMABLE-BOUNDARY-END(21475622993)
            
            //--TRIMMABLE-BOUNDARY-START(8590721105)
            /*CancellationTokenRegistration*/ _cancellationTokenRegistration;
            //--TRIMMABLE-BOUNDARY-END(8590721105)
            
            //--TRIMMABLE-BOUNDARY-START(42950459473)
            /*CancellationToken */ get CancellationToken()
            {
                return this._cancellationTokenRegistration.Token;
            }
            //--TRIMMABLE-BOUNDARY-END(42950459473)
            
            //--TRIMMABLE-BOUNDARY-START(30065557585)
            $ctor$3(/*bool*/ completed, /*bool*/ useSynchronizationContext)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065557585);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._awaitableState = (completed ? 1/*AwaitableState.Completed*/ : 0/*AwaitableState.None*/) | (useSynchronizationContext ? 8/*AwaitableState.UseSynchronizationContext*/ : 0/*AwaitableState.None*/);
                    this._completion = null;
                    this._completionState = null;
                    this._cancellationTokenRegistration = new $.$$.ST$1.CancellationTokenRegistration();
                    this._schedulingContext = null;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065557585)
            
            //--TRIMMABLE-BOUNDARY-START(85900132433)
            /*bool */ get IsCompleted()
            {
                return (this._awaitableState & (1/*AwaitableState.Completed*/ | 4/*AwaitableState.Canceled*/)) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(85900132433)
            
            //--TRIMMABLE-BOUNDARY-START(90195099729)
            /*bool */ get IsRunning()
            {
                return (this._awaitableState & 2/*AwaitableState.Running*/) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(90195099729)
            
            //--TRIMMABLE-BOUNDARY-START(34360524881)
            /*void */ BeginOperation(/*CancellationToken*/ cancellationToken, /*Action<object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (cancellationToken.CanBeCanceled && !this.IsCompleted)
                {
                    /*var*/ let previousAwaitableState = this._awaitableState;
                    this._cancellationTokenRegistration = cancellationToken.UnsafeRegister$1(callback, state);
                    if ($.$$.ST$1.CancellationTokenRegistration.op_Equality(this._cancellationTokenRegistration, $.$default($.$$.ST$1.CancellationTokenRegistration)))
                    {
                        $.$$.SD.Debug.Assert$4(previousAwaitableState === this._awaitableState, "The awaitable state changed!");
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                }
                this._awaitableState |= 2/*AwaitableState.Running*/;
            }
            //--TRIMMABLE-BOUNDARY-END(34360524881)
            
            //--TRIMMABLE-BOUNDARY-START(51540394065)
            /*void */ Complete(/*out CompletionData*/ completionData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540394065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ExtractCompletion(completionData);
                this._awaitableState |= 1/*AwaitableState.Completed*/;
            }
            //--TRIMMABLE-BOUNDARY-END(51540394065)
            
            //--TRIMMABLE-BOUNDARY-START(55835361361)
            /*void */ ExtractCompletion(/*out CompletionData*/ completionData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835361361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Action<object?>?*/ let currentCompletion = this._completion;
                /*object?*/ let currentState = this._completionState;
                /*SchedulingContext?*/ let schedulingContext = this._schedulingContext;
                /*ExecutionContext?*/ let executionContext = (schedulingContext?.ExecutionContext ?? null);
                /*SynchronizationContext?*/ let synchronizationContext = (schedulingContext?.SynchronizationContext ?? null);
                this._completion = null;
                this._completionState = null;
                this._schedulingContext = null;
                completionData.$v = currentCompletion !== null ? new $.$sipl.SIP.CompletionData().$ctor$3(currentCompletion, currentState, executionContext, synchronizationContext) : new $.$sipl.SIP.CompletionData();
            }
            //--TRIMMABLE-BOUNDARY-END(55835361361)
            
            //--TRIMMABLE-BOUNDARY-START(107374968913)
            /*void */ SetUncompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374968913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._completion === null, "_completion == null");
                $.$$.SD.Debug.Assert$4(this._completionState === null, "_completionState == null");
                $.$$.SD.Debug.Assert$4(this._schedulingContext === null, "_schedulingContext == null");
                this._awaitableState &= ~1/*AwaitableState.Completed*/;
            }
            //--TRIMMABLE-BOUNDARY-END(107374968913)
            
            //--TRIMMABLE-BOUNDARY-START(98785034321)
            /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags, /*out CompletionData*/ completionData, /*out bool*/ doubleCompletion)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785034321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                completionData.$v = new $.$sipl.SIP.CompletionData();
                doubleCompletion.$v = !(this._completion === null);
                if (this.IsCompleted || doubleCompletion.$v)
                {
                    completionData.$v = new $.$sipl.SIP.CompletionData().$ctor$3(continuation, state, (this._schedulingContext?.ExecutionContext ?? null), (this._schedulingContext?.SynchronizationContext ?? null));
                    return;
                }
                this._completion = continuation;
                this._completionState = state;
                if ((this._awaitableState & 8/*AwaitableState.UseSynchronizationContext*/) !== 0 && (flags & 1/*ValueTaskSourceOnCompletedFlags.UseSchedulingContext*/) !== 0)
                {
                    /*SynchronizationContext?*/ let sc = $.$$.ST$1.SynchronizationContext.Current;
                    if (sc !== null && $.$$.S.Object.GetType.call(sc) !== $.$$.ST$1.SynchronizationContext.$type)
                    {
                        this._schedulingContext ??= new $.$sipl.SIP.PipeAwaitable.SchedulingContext().$ctor$1();
                        this._schedulingContext.SynchronizationContext = sc;
                    }
                }
                if ((flags & 2/*ValueTaskSourceOnCompletedFlags.FlowExecutionContext*/) !== 0)
                {
                    this._schedulingContext ??= new $.$sipl.SIP.PipeAwaitable.SchedulingContext().$ctor$1();
                    this._schedulingContext.ExecutionContext = $.$$.ST$1.ExecutionContext.Capture();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785034321)
            
            //--TRIMMABLE-BOUNDARY-START(38655492177)
            /*void */ Cancel(/*out CompletionData*/ completionData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655492177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ExtractCompletion(completionData);
                this._awaitableState |= 4/*AwaitableState.Canceled*/;
            }
            //--TRIMMABLE-BOUNDARY-END(38655492177)
            
            //--TRIMMABLE-BOUNDARY-START(47245426769)
            /*void */ CancellationTokenFired(/*out CompletionData*/ completionData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CancellationToken.IsCancellationRequested)
                {
                    this.Cancel(completionData);
                }
                else 
                {
                    completionData.$v = new $.$sipl.SIP.CompletionData();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245426769)
            
            //--TRIMMABLE-BOUNDARY-START(94490067025)
            /*bool */ ObserveCancellation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490067025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let isCanceled = (this._awaitableState & 4/*AwaitableState.Canceled*/) === 4/*AwaitableState.Canceled*/;
                this._awaitableState &= ~(4/*AwaitableState.Canceled*/ | 2/*AwaitableState.Running*/);
                return isCanceled;
            }
            //--TRIMMABLE-BOUNDARY-END(94490067025)
            
            //--TRIMMABLE-BOUNDARY-START(103080001617)
            /*CancellationTokenRegistration */ ReleaseCancellationTokenRegistration(/*out CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080001617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                cancellationToken.$v = this.CancellationToken;
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = this._cancellationTokenRegistration;
                this._cancellationTokenRegistration = new $.$$.ST$1.CancellationTokenRegistration();
                return cancellationTokenRegistration;
            }
            //--TRIMMABLE-BOUNDARY-END(103080001617)
            
            //--TRIMMABLE-BOUNDARY-START(852049)
            static $_AwaitableState;
            static get AwaitableState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(852049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sipl.SIP.PipeAwaitable;
                return $cls.$_AwaitableState ??= $asm.$nstr(`$sipl.SIP.PipeAwaitable.AwaitableState`, ($self) => class AwaitableState extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static None = 0;
                    static Completed = 1;
                    static Running = 2;
                    static Canceled = 4;
                    static UseSynchronizationContext = 8;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(852049);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "Completed": 1n,
                            "Running": 2n,
                            "Canceled": 4n,
                            "UseSynchronizationContext": 8n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4295819345)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295819345);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295819345)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295819345)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295819345)
                    
                    static $h = 852049;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180721233),
    {
      "t": 852049,
      "n": "None",
      "d": 852049,
      "h": 17180721233,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180721233),
//--TRIMMABLE-BOUNDARY-START(12885753937),
    {
      "t": 852049,
      "n": "Completed",
      "d": 852049,
      "h": 12885753937,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885753937),
//--TRIMMABLE-BOUNDARY-START(21475688529),
    {
      "t": 852049,
      "n": "Running",
      "d": 852049,
      "h": 21475688529,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475688529),
//--TRIMMABLE-BOUNDARY-START(8590786641),
    {
      "t": 852049,
      "n": "Canceled",
      "d": 852049,
      "h": 8590786641,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590786641),
//--TRIMMABLE-BOUNDARY-START(25770655825),
    {
      "t": 852049,
      "n": "UseSynchronizationContext",
      "d": 852049,
      "h": 25770655825,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770655825)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819345),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 852049,
      "h": 4295819345,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819345)
  ],
  "d": 786513,
  "h": 852049,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeAwaitable+AwaitableState`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeAwaitable${separator}AwaitableState`; }
                }, $cls, ($v) => $cls.$_AwaitableState = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(852049)
            
            //--TRIMMABLE-BOUNDARY-START(917585)
            static $_SchedulingContext;
            static get SchedulingContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(917585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sipl.SIP.PipeAwaitable;
                return $cls.$_SchedulingContext ??= $asm.$ncls(`$sipl.SIP.PipeAwaitable.SchedulingContext`, ($self) => class SchedulingContext extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(55835492433)
                    /*SynchronizationContext?*/ SynchronizationContext = null;
                    //--TRIMMABLE-BOUNDARY-END(55835492433)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180786769)
                    /*ExecutionContext?*/ ExecutionContext = null;
                    //--TRIMMABLE-BOUNDARY-END(17180786769)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885819473)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885819473);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885819473)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885819473)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885819473)
                    
                    static $h = 917585;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835492433),
    {
      "p": 176095233,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360655953,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540525137,
        "f": 83886081
      },
      "n": "SynchronizationContext",
      "d": 917585,
      "h": 55835492433,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835492433),
//--TRIMMABLE-BOUNDARY-START(17180786769),
    {
      "p": 171835393,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770721361,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950590545,
        "f": 83886081
      },
      "n": "ExecutionContext",
      "d": 917585,
      "h": 17180786769,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180786769)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885819473),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917585,
      "h": 12885819473,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885819473)
  ],
  "d": 786513,
  "h": 917585
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeAwaitable+SchedulingContext`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeAwaitable${separator}SchedulingContext`; }
                }, $cls, ($v) => $cls.$_SchedulingContext = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917585)
            
            //--TRIMMABLE-BOUNDARY-START(25770590289)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590289)
            
            //--TRIMMABLE-BOUNDARY-START(25770590289)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(25770590289)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._awaitableState = this._awaitableState;
                copy._completion = this._completion;
                copy._completionState = this._completionState;
                copy._schedulingContext = this._schedulingContext;
                copy._cancellationTokenRegistration = this._cancellationTokenRegistration.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590721105)
                this._cancellationTokenRegistration = $.$default($.$$.ST$1.CancellationTokenRegistration);
                //--TRIMMABLE-BOUNDARY-END(8590721105)
                
            }
            static $h = 786513;
            static $z = 28;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950459473),
    {
      "p": 170852353,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425295953,
        "f": 50331650
      },
      "n": "CancellationToken",
      "d": 786513,
      "h": 42950459473,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(42950459473),
//--TRIMMABLE-BOUNDARY-START(85900132433),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015230545,
        "f": 50331649
      },
      "n": "IsCompleted",
      "d": 786513,
      "h": 85900132433,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900132433),
//--TRIMMABLE-BOUNDARY-START(90195099729),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605165137,
        "f": 50331649
      },
      "n": "IsRunning",
      "d": 786513,
      "h": 90195099729,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195099729)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360524881),
    {
      "r": 65537,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginOperation",
      "d": 786513,
      "h": 34360524881,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360524881),
//--TRIMMABLE-BOUNDARY-START(51540394065),
    {
      "r": 65537,
      "p": [
        {
          "n": "completionData",
          "p": 262225,
          "f": 2
        }
      ],
      "n": "Complete",
      "d": 786513,
      "h": 51540394065,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540394065),
//--TRIMMABLE-BOUNDARY-START(55835361361),
    {
      "r": 65537,
      "p": [
        {
          "n": "completionData",
          "p": 262225,
          "f": 2
        }
      ],
      "n": "ExtractCompletion",
      "d": 786513,
      "h": 55835361361,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55835361361),
//--TRIMMABLE-BOUNDARY-START(107374968913),
    {
      "r": 65537,
      "n": "SetUncompleted",
      "d": 786513,
      "h": 107374968913,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374968913),
//--TRIMMABLE-BOUNDARY-START(98785034321),
    {
      "r": 65537,
      "p": [
        {
          "n": "continuation",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "flags",
          "p": 178061313
        },
        {
          "n": "completionData",
          "p": 262225,
          "f": 2
        },
        {
          "n": "doubleCompletion",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "OnCompleted",
      "d": 786513,
      "h": 98785034321,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785034321),
//--TRIMMABLE-BOUNDARY-START(38655492177),
    {
      "r": 65537,
      "p": [
        {
          "n": "completionData",
          "p": 262225,
          "f": 2
        }
      ],
      "n": "Cancel",
      "d": 786513,
      "h": 38655492177,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655492177),
//--TRIMMABLE-BOUNDARY-START(47245426769),
    {
      "r": 65537,
      "p": [
        {
          "n": "completionData",
          "p": 262225,
          "f": 2
        }
      ],
      "n": "CancellationTokenFired",
      "d": 786513,
      "h": 47245426769,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245426769),
//--TRIMMABLE-BOUNDARY-START(94490067025),
    {
      "r": 262145,
      "n": "ObserveCancellation",
      "d": 786513,
      "h": 94490067025,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490067025),
//--TRIMMABLE-BOUNDARY-START(103080001617),
    {
      "r": 170917889,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 2
        }
      ],
      "n": "ReleaseCancellationTokenRegistration",
      "d": 786513,
      "h": 103080001617,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103080001617)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295753809),
    {
      "t": 852049,
      "n": "_awaitableState",
      "d": 786513,
      "h": 4295753809,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753809),
//--TRIMMABLE-BOUNDARY-START(12885688401),
    {
      "t": $.$$.S.Action$$($.$$.S.Object).$h,
      "n": "_completion",
      "d": 786513,
      "h": 12885688401,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688401),
//--TRIMMABLE-BOUNDARY-START(17180655697),
    {
      "t": 131073,
      "n": "_completionState",
      "d": 786513,
      "h": 17180655697,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180655697),
//--TRIMMABLE-BOUNDARY-START(21475622993),
    {
      "t": 917585,
      "n": "_schedulingContext",
      "d": 786513,
      "h": 21475622993,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475622993),
//--TRIMMABLE-BOUNDARY-START(8590721105),
    {
      "t": 170917889,
      "n": "_cancellationTokenRegistration",
      "d": 786513,
      "h": 8590721105,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721105)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065557585),
    {
      "p": [
        {
          "n": "completed",
          "p": 262145
        },
        {
          "n": "useSynchronizationContext",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786513,
      "h": 30065557585,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065557585),
//--TRIMMABLE-BOUNDARY-START(25770590289),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786513,
      "h": 25770590289,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590289)
  ],
  "h": 786513,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "CanceledState = {_awaitableState}, IsCompleted = {IsCompleted}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sipl.SIP.PipeAwaitable.AwaitableState, $.$sipl.SIP.PipeAwaitable.SchedulingContext ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeAwaitable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeAwaitable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786513)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966161)
        $asm.$cls(`$sipl.SIP.StreamPipeReader`, ($self) => class StreamPipeReader extends $.$sipl.SIP.PipeReader
        {
            //--TRIMMABLE-BOUNDARY-START(197570461777)
            /*int*/ static InitialSegmentPoolSize = 4;
            //--TRIMMABLE-BOUNDARY-END(197570461777)
            
            //--TRIMMABLE-BOUNDARY-START(219045298257)
            /*int*/ static MaxSegmentPoolSize = 256;
            //--TRIMMABLE-BOUNDARY-END(219045298257)
            
            //--TRIMMABLE-BOUNDARY-START(17181835345)
            /*CancellationTokenSource?*/ _internalTokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(17181835345)
            
            //--TRIMMABLE-BOUNDARY-START(21476802641)
            /*bool*/ _isReaderCompleted = false;
            //--TRIMMABLE-BOUNDARY-END(21476802641)
            
            //--TRIMMABLE-BOUNDARY-START(34361704529)
            /*BufferSegment?*/ _readHead = null;
            //--TRIMMABLE-BOUNDARY-END(34361704529)
            
            //--TRIMMABLE-BOUNDARY-START(38656671825)
            /*int*/ _readIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(38656671825)
            
            //--TRIMMABLE-BOUNDARY-START(42951639121)
            /*BufferSegment?*/ _readTail = null;
            //--TRIMMABLE-BOUNDARY-END(42951639121)
            
            //--TRIMMABLE-BOUNDARY-START(4296933457)
            /*long*/ _bufferedBytes = 0n;
            //--TRIMMABLE-BOUNDARY-END(4296933457)
            
            //--TRIMMABLE-BOUNDARY-START(12886868049)
            /*bool*/ _examinedEverything = false;
            //--TRIMMABLE-BOUNDARY-END(12886868049)
            
            //--TRIMMABLE-BOUNDARY-START(25771769937)
            /*object*/ _lock = null;
            //--TRIMMABLE-BOUNDARY-END(25771769937)
            
            //--TRIMMABLE-BOUNDARY-START(8591900753)
            /*BufferSegmentStack*/ _bufferSegmentPool;
            //--TRIMMABLE-BOUNDARY-END(8591900753)
            
            //--TRIMMABLE-BOUNDARY-START(30066737233)
            /*StreamPipeReaderOptions*/ _options = null;
            //--TRIMMABLE-BOUNDARY-END(30066737233)
            
            //--TRIMMABLE-BOUNDARY-START(51541573713)
            $ctor$2(/*Stream*/ readingStream, /*StreamPipeReaderOptions*/ options)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541573713);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (readingStream === null)
                    {
                        $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(10/*ExceptionArgument.readingStream*/);
                    }
                    if (options === null)
                    {
                        $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this.InnerStream = readingStream;
                    this._options = options;
                    this._bufferSegmentPool = new $.$sipl.SIP.BufferSegmentStack().$ctor$3(4/*InitialSegmentPoolSize*/);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51541573713)
            
            //--TRIMMABLE-BOUNDARY-START(210455363665)
            /*bool */ get LeaveOpen()
            {
                return this._options.LeaveOpen;
            }
            //--TRIMMABLE-BOUNDARY-END(210455363665)
            
            //--TRIMMABLE-BOUNDARY-START(261994971217)
            /*bool */ get UseZeroByteReads()
            {
                return this._options.UseZeroByteReads;
            }
            //--TRIMMABLE-BOUNDARY-END(261994971217)
            
            //--TRIMMABLE-BOUNDARY-START(77311377489)
            /*int */ get BufferSize()
            {
                return this._options.BufferSize;
            }
            //--TRIMMABLE-BOUNDARY-END(77311377489)
            
            //--TRIMMABLE-BOUNDARY-START(214750330961)
            /*int */ get MaxBufferSize()
            {
                return this._options.MaxBufferSize;
            }
            //--TRIMMABLE-BOUNDARY-END(214750330961)
            
            //--TRIMMABLE-BOUNDARY-START(223340265553)
            /*int */ get MinimumReadThreshold()
            {
                return this._options.MinimumReadSize;
            }
            //--TRIMMABLE-BOUNDARY-END(223340265553)
            
            //--TRIMMABLE-BOUNDARY-START(227635232849)
            /*MemoryPool<byte> */ get Pool()
            {
                return this._options.Pool;
            }
            //--TRIMMABLE-BOUNDARY-END(227635232849)
            
            //--TRIMMABLE-BOUNDARY-START(201865429073)
            /*Stream*/ InnerStream = null;
            //--TRIMMABLE-BOUNDARY-END(201865429073)
            
            //--TRIMMABLE-BOUNDARY-START(64426475601)
            /*void */ AdvanceTo$1(/*SequencePosition*/ consumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426475601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AdvanceTo(consumed, consumed);
            }
            //--TRIMMABLE-BOUNDARY-END(64426475601)
            
            //--TRIMMABLE-BOUNDARY-START(206160396369)
            /*CancellationTokenSource */ get InternalTokenSource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735886929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_lock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lock)
                    {
                        return this._internalTokenSource ??= new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lock)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206160396369)
            
            //--TRIMMABLE-BOUNDARY-START(60131508305)
            /*void */ AdvanceTo(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131508305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfCompleted();
                this.AdvanceTo$2($.$cast(consumed.GetObject(), $.$sipl.SIP.BufferSegment), consumed.GetInteger(), $.$cast(examined.GetObject(), $.$sipl.SIP.BufferSegment), examined.GetInteger());
            }
            //--TRIMMABLE-BOUNDARY-END(60131508305)
            
            //--TRIMMABLE-BOUNDARY-START(55836541009)
            /*void */ AdvanceTo$2(/*BufferSegment?*/ consumedSegment, /*int*/ consumedIndex, /*BufferSegment?*/ examinedSegment, /*int*/ examinedIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836541009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (consumedSegment === null || examinedSegment === null)
                {
                    return;
                }
                if (this._readHead === null)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_AdvanceToInvalidCursor();
                }
                /*BufferSegment*/ let returnStart = this._readHead;
                /*BufferSegment?*/ let returnEnd = consumedSegment;
                /*long*/ let consumedBytes = $.$sipl.SIP.BufferSegment.GetLength$1(returnStart, this._readIndex, consumedSegment, consumedIndex);
                this._bufferedBytes -= consumedBytes;
                $.$$.SD.Debug.Assert$4(this._bufferedBytes >= 0n, "_bufferedBytes >= 0");
                this._examinedEverything = false;
                if (examinedSegment === this._readTail)
                {
                    this._examinedEverything = examinedIndex === this._readTail.End;
                }
                if (this._bufferedBytes === 0n)
                {
                    returnEnd = null;
                    this._readHead = null;
                    this._readTail = null;
                    this._readIndex = 0;
                }
                else if (consumedIndex === returnEnd.Length)
                {
                    /*BufferSegment?*/ let nextBlock = returnEnd.NextSegment;
                    this._readHead = nextBlock;
                    this._readIndex = 0;
                    returnEnd = nextBlock;
                }
                else 
                {
                    this._readHead = consumedSegment;
                    this._readIndex = consumedIndex;
                }
                while(returnStart !== returnEnd)
                {
                    /*BufferSegment*/ let next = returnStart.NextSegment;
                    this.ReturnSegmentUnsynchronized(returnStart);
                    returnStart = next;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836541009)
            
            //--TRIMMABLE-BOUNDARY-START(85901312081)
            /*void */ CancelPendingRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901312081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.InternalTokenSource.Cancel();
            }
            //--TRIMMABLE-BOUNDARY-END(85901312081)
            
            //--TRIMMABLE-BOUNDARY-START(94491246673)
            /*void */ Complete(/*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491246673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.CompleteAndGetNeedsDispose())
                {
                    this.InnerStream.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94491246673)
            
            //--TRIMMABLE-BOUNDARY-START(103081181265)
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103081181265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CompleteAndGetNeedsDispose() ? this.InnerStream.DisposeAsync() : new $.$$.STT.ValueTask();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103081181265)
            
            //--TRIMMABLE-BOUNDARY-START(98786213969)
            /*bool */ CompleteAndGetNeedsDispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786213969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isReaderCompleted)
                {
                    return false;
                }
                this._isReaderCompleted = true;
                /*BufferSegment?*/ let segment = this._readHead;
                while(segment !== null)
                {
                    /*BufferSegment*/ let returnSegment = segment;
                    segment = segment.NextSegment;
                    returnSegment.Reset();
                }
                return !this.LeaveOpen;
            }
            //--TRIMMABLE-BOUNDARY-END(98786213969)
            
            //--TRIMMABLE-BOUNDARY-START(231930200145)
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930200145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadInternalAsync(null, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(231930200145)
            
            //--TRIMMABLE-BOUNDARY-START(236225167441)
            /*ValueTask<ReadResult> */ ReadAtLeastAsyncCore(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225167441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadInternalAsync(minimumSize, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(236225167441)
            
            //--TRIMMABLE-BOUNDARY-START(240520134737)
            /*ValueTask<ReadResult> */ ReadInternalAsync(/*int?*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                /*ReadResult*/ let readResult;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520134737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfCompleted();
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult))().$ctor$5($.$$.STT.Task.FromCanceled$3($.$sipl.SIP.ReadResult, cancellationToken));
                }
                /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                if (this.TryReadInternal(tokenSource, $.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.SIP.ReadResult)))
                {
                    if (minimumSize === null || $.$$.S.Int64.op_GreaterThanOrEqual$1(readResult.Buffer.Length, minimumSize) || readResult.IsCompleted || readResult.IsCanceled)
                    {
                        return new ($.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult))().$ctor$6(readResult);
                    }
                }
                return Core(this, minimumSize, tokenSource, cancellationToken);
                /*static ValueTask<ReadResult>*/ /*async*/  function Core(/*StreamPipeReader*/ reader, /*int?*/ minimumSize, /*CancellationTokenSource*/ tokenSource, /*CancellationToken*/ cancellationToken)
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult), $.$sipl.SIP.ReadResult, async ($asnycContext) => 
                    {
                        /*CancellationTokenRegistration*/ let reg = new $.$$.ST$1.CancellationTokenRegistration();
                        if (cancellationToken.CanBeCanceled)
                        {
                            reg = cancellationToken.UnsafeRegister$1(new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/**/ state) =>
                            {
                                return ($.$cast(state, $.$sipl.SIP.StreamPipeReader)).Cancel();
                            }, $VOxWFf ??= {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":1966161,"h":0,"f":17825794}), reader);
                        }
                        let $disposable2 = null;
                        try
                        {
                            $disposable2 = reg;
                            /*var*/ let isCanceled = false;
                            /*bool*/ let isCompleted = false;
                            try
                            {
                                if (reader.UseZeroByteReads && reader._bufferedBytes === 0n)
                                {
                                    let $t3, $r3;
                                    ($t3 = reader.InnerStream.ReadAsync$2($.$$.S.Memory$$($.$$.S.Byte).Empty, tokenSource.Token).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                }
                                do
                                {
                                    let $t4, $r4;
                                    reader.AllocateReadTail(minimumSize);
                                    /*Memory<byte>*/ let buffer = reader._readTail.AvailableMemory.Slice$1(reader._readTail.End);
                                    /*int*/ let length = ($t4 = reader.InnerStream.ReadAsync$2(buffer, tokenSource.Token).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                                    $.$$.SD.Debug.Assert$4(((length + reader._readTail.End) | 0) <= reader._readTail.AvailableMemory.Length, "length + reader._readTail.End <= reader._readTail.AvailableMemory.Length");
                                    reader._readTail.End += length;
                                    reader._bufferedBytes += BigInt(length);
                                    if (length === 0)
                                    {
                                        isCompleted = true;
                                        break;
                                    }
                                }
                                while(minimumSize !== null && $.$$.S.Int64.op_LessThan$1(reader._bufferedBytes, minimumSize));
                            }
                            catch(ex)
                            {
                                reader.ClearCancellationToken();
                                if (cancellationToken.IsCancellationRequested)
                                {
                                    throw new $.$$.S.OperationCanceledException().$ctor$11(ex.Message, ex, cancellationToken);
                                }
                                else if (tokenSource.IsCancellationRequested)
                                {
                                    isCanceled = true;
                                }
                                else 
                                {
                                    throw ex;
                                }
                            }
                            return $.$$.N.AsyncResolver.Result($asnycContext, new $.$sipl.SIP.ReadResult().$ctor$3(reader.GetCurrentReadOnlySequence(), isCanceled, isCompleted));
                        }
                        finally
                        {
                            $disposable2?.S$IDisposable$Dispose();
                        }
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(240520134737)
            
            //--TRIMMABLE-BOUNDARY-START(107376148561)
            /*Task *//*async*/  CopyToAsync(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107376148561);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfCompleted();
                    /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                    if (tokenSource.IsCancellationRequested)
                    {
                        $.$sipl.SIP.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                    }
                    /*CancellationTokenRegistration*/ let reg = new $.$$.ST$1.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister$1(new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.SIP.StreamPipeReader)).Cancel();
                        }, $JNCuJg ??= {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":1966161,"h":0,"f":17825794}), this);
                    }
                    let $disposable5 = null;
                    try
                    {
                        $disposable5 = reg;
                        try
                        {
                            let $t7, $r7;
                            /*BufferSegment?*/ let segment = this._readHead;
                            /*int*/ let segmentIndex = this._readIndex;
                            try
                            {
                                while(segment !== null)
                                {
                                    let $t6, $r6;
                                    /*FlushResult*/ let flushResult = ($t6 = destination.WriteAsync(segment.Memory.Slice$1(segmentIndex), tokenSource.Token).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                    if (flushResult.IsCanceled)
                                    {
                                        $.$sipl.SIP.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                                    }
                                    segment = segment.NextSegment;
                                    segmentIndex = 0;
                                    if (flushResult.IsCompleted)
                                    {
                                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                                    }
                                }
                            }
                            finally
                            {
                                {
                                    if (segment !== null)
                                    {
                                        this.AdvanceTo$2(segment, segment.End, segment, segment.End);
                                    }
                                }
                            }
                            ($t7 = $.$sipl.SIP.StreamPipeExtensions.CopyToAsync(this.InnerStream, destination, tokenSource.Token).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                        }
                        catch($e)
                        {
                            this.ClearCancellationToken();
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable5?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107376148561)
            
            //--TRIMMABLE-BOUNDARY-START(111671115857)
            /*Task *//*async*/  CopyToAsync$1(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111671115857);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfCompleted();
                    /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                    if (tokenSource.IsCancellationRequested)
                    {
                        $.$sipl.SIP.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                    }
                    /*CancellationTokenRegistration*/ let reg = new $.$$.ST$1.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister$1(new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.SIP.StreamPipeReader)).Cancel();
                        }, $aZoNFh ??= {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":1966161,"h":0,"f":17825794}), this);
                    }
                    let $disposable8 = null;
                    try
                    {
                        $disposable8 = reg;
                        try
                        {
                            let $t10, $r10;
                            /*BufferSegment?*/ let segment = this._readHead;
                            /*int*/ let segmentIndex = this._readIndex;
                            try
                            {
                                while(segment !== null)
                                {
                                    let $t9, $r9;
                                    ($t9 = destination.WriteAsync$2(segment.Memory.Slice$1(segmentIndex), tokenSource.Token).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                                    segment = segment.NextSegment;
                                    segmentIndex = 0;
                                }
                            }
                            finally
                            {
                                {
                                    if (segment !== null)
                                    {
                                        this.AdvanceTo$2(segment, segment.End, segment, segment.End);
                                    }
                                }
                            }
                            ($t10 = this.InnerStream.CopyToAsync$2(destination, tokenSource.Token).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                        }
                        catch($e)
                        {
                            this.ClearCancellationToken();
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable8?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111671115857)
            
            //--TRIMMABLE-BOUNDARY-START(90196279377)
            /*void */ ClearCancellationToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196279377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_lock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lock)
                    {
                        this._internalTokenSource = null;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lock)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90196279377)
            
            //--TRIMMABLE-BOUNDARY-START(249110069329)
            /*void */ ThrowIfCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249110069329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isReaderCompleted)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249110069329)
            
            //--TRIMMABLE-BOUNDARY-START(253405036625)
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405036625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfCompleted();
                return this.TryReadInternal(this.InternalTokenSource, result);
            }
            //--TRIMMABLE-BOUNDARY-END(253405036625)
            
            //--TRIMMABLE-BOUNDARY-START(257700003921)
            /*bool */ TryReadInternal(/*CancellationTokenSource*/ source, /*out ReadResult*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700003921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let isCancellationRequested = source.IsCancellationRequested;
                if (isCancellationRequested || (this._bufferedBytes > 0n && !this._examinedEverything))
                {
                    if (isCancellationRequested)
                    {
                        this.ClearCancellationToken();
                    }
                    /*ReadOnlySequence<byte>*/ let buffer = this.GetCurrentReadOnlySequence();
                    result.$v = new $.$sipl.SIP.ReadResult().$ctor$3(buffer, isCancellationRequested, false);
                    return true;
                }
                result.$v = new $.$sipl.SIP.ReadResult();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(257700003921)
            
            //--TRIMMABLE-BOUNDARY-START(188980527185)
            /*ReadOnlySequence<byte> */ GetCurrentReadOnlySequence()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980527185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._readHead === null ? new ($.$sm.SB.ReadOnlySequence$$($.$$.S.Byte))() : new ($.$sm.SB.ReadOnlySequence$$($.$$.S.Byte))().$ctor$3(this._readHead, this._readIndex, this._readTail, this._readTail.End);
            }
            //--TRIMMABLE-BOUNDARY-END(188980527185)
            
            //--TRIMMABLE-BOUNDARY-START(68721442897)
            /*void */ AllocateReadTail(/*int?*/ minimumSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721442897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readHead === null)
                {
                    $.$$.SD.Debug.Assert$4(this._readTail === null, "_readTail == null");
                    this._readHead = this.AllocateSegment(minimumSize);
                    this._readTail = this._readHead;
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4(this._readTail !== null, "_readTail != null");
                    if (this._readTail.WritableBytes < this.MinimumReadThreshold)
                    {
                        /*BufferSegment*/ let nextSegment = this.AllocateSegment(minimumSize);
                        this._readTail.SetNext(nextSegment);
                        this._readTail = nextSegment;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721442897)
            
            //--TRIMMABLE-BOUNDARY-START(73016410193)
            /*BufferSegment */ AllocateSegment(/*int?*/ minimumSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016410193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*BufferSegment*/ let nextSegment = this.CreateSegmentUnsynchronized();
                /*var*/ let bufferSize = minimumSize ?? this.BufferSize;
                /*int*/ let maxSize = !this._options.IsDefaultSharedMemoryPool ? this._options.Pool.MaxBufferSize : -1;
                if (bufferSize <= maxSize)
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(bufferSize, maxSize);
                    nextSegment.SetOwnedMemory(this._options.Pool.Rent(sizeToRequest));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(bufferSize, this.MaxBufferSize);
                    nextSegment.SetOwnedMemory$1($.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(sizeToRequest));
                }
                return nextSegment;
            }
            //--TRIMMABLE-BOUNDARY-END(73016410193)
            
            //--TRIMMABLE-BOUNDARY-START(193275494481)
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275494481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                sizeHint = $.$$.S.Math.Max$4(this.BufferSize, sizeHint);
                /*int*/ let adjustedToMaximumSize = $.$$.S.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            //--TRIMMABLE-BOUNDARY-END(193275494481)
            
            //--TRIMMABLE-BOUNDARY-START(115966083153)
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966083153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.SIP.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.SIP.BufferSegment().$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(115966083153)
            
            //--TRIMMABLE-BOUNDARY-START(244815102033)
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815102033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(segment !== this._readHead, "Returning _readHead segment that's in use!");
                $.$$.SD.Debug.Assert$4(segment !== this._readTail, "Returning _readTail segment that's in use!");
                segment.Reset();
                if (this._bufferSegmentPool.Count < 256/*MaxSegmentPoolSize*/)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244815102033)
            
            //--TRIMMABLE-BOUNDARY-START(81606344785)
            /*void */ Cancel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606344785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.InternalTokenSource.Cancel();
            }
            //--TRIMMABLE-BOUNDARY-END(81606344785)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25771769937)
                this._lock = new $.$$.S.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(25771769937)
                
                //--TRIMMABLE-BOUNDARY-START(8591900753)
                this._bufferSegmentPool = $.$default($.$sipl.SIP.BufferSegmentStack);
                //--TRIMMABLE-BOUNDARY-END(8591900753)
                
            }
            static $h = 1966161;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sipl.SIP.PipeReader; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(210455363665),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325821521,
        "f": 50331650
      },
      "n": "LeaveOpen",
      "d": 1966161,
      "h": 210455363665,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(210455363665),
//--TRIMMABLE-BOUNDARY-START(261994971217),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184685559889,
        "f": 50331650
      },
      "n": "UseZeroByteReads",
      "d": 1966161,
      "h": 261994971217,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(261994971217),
//--TRIMMABLE-BOUNDARY-START(77311377489),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124556017745,
        "f": 50331650
      },
      "n": "BufferSize",
      "d": 1966161,
      "h": 77311377489,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(77311377489),
//--TRIMMABLE-BOUNDARY-START(214750330961),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915756113,
        "f": 50331650
      },
      "n": "MaxBufferSize",
      "d": 1966161,
      "h": 214750330961,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(214750330961),
//--TRIMMABLE-BOUNDARY-START(223340265553),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505690705,
        "f": 50331650
      },
      "n": "MinimumReadThreshold",
      "d": 1966161,
      "h": 223340265553,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(223340265553),
//--TRIMMABLE-BOUNDARY-START(227635232849),
    {
      "p": $.$sm.SB.MemoryPool$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095625297,
        "f": 50331650
      },
      "n": "Pool",
      "d": 1966161,
      "h": 227635232849,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(227635232849),
//--TRIMMABLE-BOUNDARY-START(201865429073),
    {
      "p": 95748097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145952337,
        "f": 50331649
      },
      "n": "InnerStream",
      "d": 1966161,
      "h": 201865429073,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201865429073),
//--TRIMMABLE-BOUNDARY-START(206160396369),
    {
      "p": 170983425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735886929,
        "f": 50331650
      },
      "n": "InternalTokenSource",
      "d": 1966161,
      "h": 206160396369,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(206160396369)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64426475601),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumed",
          "p": 1179656
        }
      ],
      "n": "AdvanceTo",
      "o": "@$1",
      "d": 1966161,
      "h": 64426475601,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64426475601),
//--TRIMMABLE-BOUNDARY-START(60131508305),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumed",
          "p": 1179656
        },
        {
          "n": "examined",
          "p": 1179656
        }
      ],
      "n": "AdvanceTo",
      "d": 1966161,
      "h": 60131508305,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60131508305),
//--TRIMMABLE-BOUNDARY-START(55836541009),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumedSegment",
          "p": 65617
        },
        {
          "n": "consumedIndex",
          "p": 655361
        },
        {
          "n": "examinedSegment",
          "p": 65617
        },
        {
          "n": "examinedIndex",
          "p": 655361
        }
      ],
      "n": "AdvanceTo",
      "o": "@$2",
      "d": 1966161,
      "h": 55836541009,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55836541009),
//--TRIMMABLE-BOUNDARY-START(85901312081),
    {
      "r": 65537,
      "n": "CancelPendingRead",
      "d": 1966161,
      "h": 85901312081,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901312081),
//--TRIMMABLE-BOUNDARY-START(94491246673),
    {
      "r": 65537,
      "p": [
        {
          "n": "exception",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "Complete",
      "d": 1966161,
      "h": 94491246673,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94491246673),
//--TRIMMABLE-BOUNDARY-START(103081181265),
    {
      "r": 181338113,
      "p": [
        {
          "n": "exception",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "CompleteAsync",
      "d": 1966161,
      "h": 103081181265,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103081181265),
//--TRIMMABLE-BOUNDARY-START(98786213969),
    {
      "r": 262145,
      "n": "CompleteAndGetNeedsDispose",
      "d": 1966161,
      "h": 98786213969,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98786213969),
//--TRIMMABLE-BOUNDARY-START(231930200145),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "d": 1966161,
      "h": 231930200145,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(231930200145),
//--TRIMMABLE-BOUNDARY-START(236225167441),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult).$h,
      "p": [
        {
          "n": "minimumSize",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAtLeastAsyncCore",
      "d": 1966161,
      "h": 236225167441,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(236225167441),
//--TRIMMABLE-BOUNDARY-START(240520134737),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.ReadResult).$h,
      "p": [
        {
          "n": "minimumSize",
          "p": $.$typeNullable($.$$.S.Int32).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadInternalAsync",
      "d": 1966161,
      "h": 240520134737,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(240520134737),
//--TRIMMABLE-BOUNDARY-START(107376148561),
    {
      "r": 178454529,
      "p": [
        {
          "n": "destination",
          "p": 1572945
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "CopyToAsync",
      "d": 1966161,
      "h": 107376148561,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(107376148561),
//--TRIMMABLE-BOUNDARY-START(111671115857),
    {
      "r": 178454529,
      "p": [
        {
          "n": "destination",
          "p": 95748097
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "CopyToAsync",
      "o": "@$1",
      "d": 1966161,
      "h": 111671115857,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(111671115857),
//--TRIMMABLE-BOUNDARY-START(90196279377),
    {
      "r": 65537,
      "n": "ClearCancellationToken",
      "d": 1966161,
      "h": 90196279377,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90196279377),
//--TRIMMABLE-BOUNDARY-START(249110069329),
    {
      "r": 65537,
      "n": "ThrowIfCompleted",
      "d": 1966161,
      "h": 249110069329,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(249110069329),
//--TRIMMABLE-BOUNDARY-START(253405036625),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": 1704017,
          "f": 2
        }
      ],
      "n": "TryRead",
      "d": 1966161,
      "h": 253405036625,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(253405036625),
//--TRIMMABLE-BOUNDARY-START(257700003921),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": 170983425
        },
        {
          "n": "result",
          "p": 1704017,
          "f": 2
        }
      ],
      "n": "TryReadInternal",
      "d": 1966161,
      "h": 257700003921,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(257700003921),
//--TRIMMABLE-BOUNDARY-START(188980527185),
    {
      "r": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h,
      "n": "GetCurrentReadOnlySequence",
      "d": 1966161,
      "h": 188980527185,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(188980527185),
//--TRIMMABLE-BOUNDARY-START(68721442897),
    {
      "r": 65537,
      "p": [
        {
          "n": "minimumSize",
          "p": $.$typeNullable($.$$.S.Int32).$h,
          "f": 65
        }
      ],
      "n": "AllocateReadTail",
      "d": 1966161,
      "h": 68721442897,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68721442897),
//--TRIMMABLE-BOUNDARY-START(73016410193),
    {
      "r": 65617,
      "p": [
        {
          "n": "minimumSize",
          "p": $.$typeNullable($.$$.S.Int32).$h,
          "f": 65
        }
      ],
      "n": "AllocateSegment",
      "d": 1966161,
      "h": 73016410193,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73016410193),
//--TRIMMABLE-BOUNDARY-START(193275494481),
    {
      "r": 655361,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361
        },
        {
          "n": "maxBufferSize",
          "p": 655361
        }
      ],
      "n": "GetSegmentSize",
      "d": 1966161,
      "h": 193275494481,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193275494481),
//--TRIMMABLE-BOUNDARY-START(115966083153),
    {
      "r": 65617,
      "n": "CreateSegmentUnsynchronized",
      "d": 1966161,
      "h": 115966083153,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115966083153),
//--TRIMMABLE-BOUNDARY-START(244815102033),
    {
      "r": 65537,
      "p": [
        {
          "n": "segment",
          "p": 65617
        }
      ],
      "n": "ReturnSegmentUnsynchronized",
      "d": 1966161,
      "h": 244815102033,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(244815102033),
//--TRIMMABLE-BOUNDARY-START(81606344785),
    {
      "r": 65537,
      "n": "Cancel",
      "d": 1966161,
      "h": 81606344785,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81606344785)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(197570461777),
    {
      "t": 655361,
      "n": "InitialSegmentPoolSize",
      "d": 1966161,
      "h": 197570461777,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197570461777),
//--TRIMMABLE-BOUNDARY-START(219045298257),
    {
      "t": 655361,
      "n": "MaxSegmentPoolSize",
      "d": 1966161,
      "h": 219045298257,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219045298257),
//--TRIMMABLE-BOUNDARY-START(17181835345),
    {
      "t": 170983425,
      "n": "_internalTokenSource",
      "d": 1966161,
      "h": 17181835345,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181835345),
//--TRIMMABLE-BOUNDARY-START(21476802641),
    {
      "t": 262145,
      "n": "_isReaderCompleted",
      "d": 1966161,
      "h": 21476802641,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476802641),
//--TRIMMABLE-BOUNDARY-START(34361704529),
    {
      "t": 65617,
      "n": "_readHead",
      "d": 1966161,
      "h": 34361704529,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361704529),
//--TRIMMABLE-BOUNDARY-START(38656671825),
    {
      "t": 655361,
      "n": "_readIndex",
      "d": 1966161,
      "h": 38656671825,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656671825),
//--TRIMMABLE-BOUNDARY-START(42951639121),
    {
      "t": 65617,
      "n": "_readTail",
      "d": 1966161,
      "h": 42951639121,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42951639121),
//--TRIMMABLE-BOUNDARY-START(4296933457),
    {
      "t": 917505,
      "n": "_bufferedBytes",
      "d": 1966161,
      "h": 4296933457,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296933457),
//--TRIMMABLE-BOUNDARY-START(12886868049),
    {
      "t": 262145,
      "n": "_examinedEverything",
      "d": 1966161,
      "h": 12886868049,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886868049),
//--TRIMMABLE-BOUNDARY-START(25771769937),
    {
      "t": 131073,
      "n": "_lock",
      "d": 1966161,
      "h": 25771769937,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771769937),
//--TRIMMABLE-BOUNDARY-START(8591900753),
    {
      "t": 131153,
      "n": "_bufferSegmentPool",
      "d": 1966161,
      "h": 8591900753,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591900753),
//--TRIMMABLE-BOUNDARY-START(30066737233),
    {
      "t": 2031697,
      "n": "_options",
      "d": 1966161,
      "h": 30066737233,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066737233)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51541573713),
    {
      "p": [
        {
          "n": "readingStream",
          "p": 95748097
        },
        {
          "n": "options",
          "p": 2031697
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1966161,
      "h": 51541573713,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541573713)
  ],
  "h": 1966161
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.StreamPipeReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}StreamPipeReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966161)
        
        

        //--TRIMMABLE-BOUNDARY-START(131153)
        $asm.$str(`$sipl.SIP.BufferSegmentStack`, ($self) => class BufferSegmentStack extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295098449)
            /*SegmentAsValueType[]*/ _array = null;
            //--TRIMMABLE-BOUNDARY-END(4295098449)
            
            //--TRIMMABLE-BOUNDARY-START(8590065745)
            /*int*/ _size = 0;
            //--TRIMMABLE-BOUNDARY-END(8590065745)
            
            //--TRIMMABLE-BOUNDARY-START(17180000337)
            $ctor$3(/*int*/ size)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180000337);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._array = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sipl.SIP.BufferSegmentStack.SegmentAsValueType), null, [size], null);
                    this._size = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180000337)
            
            //--TRIMMABLE-BOUNDARY-START(21474967633)
            /*int */ get Count()
            {
                return this._size;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967633)
            
            //--TRIMMABLE-BOUNDARY-START(42949804113)
            /*bool */ TryPop(/*out BufferSegment?*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let size = ((this._size - 1) | 0);
                /*SegmentAsValueType[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    result.$v = null;
                    return false;
                }
                this._size = size;
                result.$v = $.$sipl.SIP.BufferSegmentStack.SegmentAsValueType.op_Implicit($.$$.System.Array.$ReadT1.call(array, size));
                $.$$.System.Array.$WriteT1.call(array, new $.$sipl.SIP.BufferSegmentStack.SegmentAsValueType(), size);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(42949804113)
            
            //--TRIMMABLE-BOUNDARY-START(34359869521)
            /*void */ Push(/*BufferSegment*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let size = this._size;
                /*SegmentAsValueType[]*/ let array = this._array;
                if ((size >>> 0) < (array.length >>> 0))
                {
                    $.$$.System.Array.$WriteT1.call(array, $.$sipl.SIP.BufferSegmentStack.SegmentAsValueType.op_Implicit$1(item), size);
                    this._size = ((size + 1) | 0);
                }
                else 
                {
                    this.PushWithResize(item);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359869521)
            
            //--TRIMMABLE-BOUNDARY-START(38654836817)
            /*void */ PushWithResize(/*BufferSegment*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.Array.Resize($.$sipl.SIP.BufferSegmentStack.SegmentAsValueType, $.$ref(() => this._array, ($v) => this._array = $v, $.$typeArray($.$sipl.SIP.BufferSegmentStack.SegmentAsValueType)), ((2 * this._array.length) | 0));
                $.$$.System.Array.$WriteT1.call(this._array, $.$sipl.SIP.BufferSegmentStack.SegmentAsValueType.op_Implicit$1(item), this._size);
                this._size++;
            }
            //--TRIMMABLE-BOUNDARY-END(38654836817)
            
            //--TRIMMABLE-BOUNDARY-START(196689)
            static $_SegmentAsValueType;
            static get SegmentAsValueType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sipl.SIP.BufferSegmentStack;
                return $cls.$_SegmentAsValueType ??= $asm.$nstr(`$sipl.SIP.BufferSegmentStack.SegmentAsValueType`, ($self) => class SegmentAsValueType extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295163985)
                    /*BufferSegment*/ _value = null;
                    //--TRIMMABLE-BOUNDARY-END(4295163985)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885098577)
                    $ctor$3(/*BufferSegment*/ value)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885098577);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885098577)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475033169)
                    static /*SegmentAsValueType */ op_Implicit$1(/*BufferSegment*/ s)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475033169);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$sipl.SIP.BufferSegmentStack.SegmentAsValueType().$ctor$3(s);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475033169)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180065873)
                    static /*BufferSegment */ op_Implicit(/*SegmentAsValueType*/ s)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180065873);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return s._value;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180065873)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590131281)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590131281);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590131281)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590131281)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590131281)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._value = this._value;
                        return copy;
                    }
                    static $h = 196689;
                    static $z = 4;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295163985),
    {
      "t": 65617,
      "n": "_value",
      "d": 196689,
      "h": 4295163985,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295163985)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885098577),
    {
      "p": [
        {
          "n": "value",
          "p": 65617
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196689,
      "h": 12885098577,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885098577),
//--TRIMMABLE-BOUNDARY-START(8590131281),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196689,
      "h": 8590131281,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131281)
  ],
  "d": 131153,
  "h": 196689
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.BufferSegmentStack+SegmentAsValueType`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}BufferSegmentStack${separator}SegmentAsValueType`; }
                }, $cls, ($v) => $cls.$_SegmentAsValueType = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196689)
            
            //--TRIMMABLE-BOUNDARY-START(12885033041)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885033041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033041)
            
            //--TRIMMABLE-BOUNDARY-START(12885033041)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885033041)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._array = this._array;
                copy._size = this._size;
                return copy;
            }
            static $h = 131153;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474967633),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064902225,
        "f": 50331649
      },
      "n": "Count",
      "d": 131153,
      "h": 21474967633,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474967633)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42949804113),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": 65617,
          "f": 2
        }
      ],
      "n": "TryPop",
      "d": 131153,
      "h": 42949804113,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949804113),
//--TRIMMABLE-BOUNDARY-START(34359869521),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": 65617
        }
      ],
      "n": "Push",
      "d": 131153,
      "h": 34359869521,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359869521),
//--TRIMMABLE-BOUNDARY-START(38654836817),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": 65617
        }
      ],
      "n": "PushWithResize",
      "d": 131153,
      "h": 38654836817,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38654836817)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098449),
    {
      "t": $.$typeArray($.$sipl.SIP.BufferSegmentStack.SegmentAsValueType).$h,
      "n": "_array",
      "d": 131153,
      "h": 4295098449,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098449),
//--TRIMMABLE-BOUNDARY-START(8590065745),
    {
      "t": 655361,
      "n": "_size",
      "d": 131153,
      "h": 8590065745,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065745)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180000337),
    {
      "p": [
        {
          "n": "size",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131153,
      "h": 17180000337,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180000337),
//--TRIMMABLE-BOUNDARY-START(12885033041),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131153,
      "h": 12885033041,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885033041)
  ],
  "h": 131153
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sipl.SIP.BufferSegmentStack.SegmentAsValueType ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.BufferSegmentStack`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}BufferSegmentStack`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131153)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638481)
        $asm.$cls(`$sipl.SIP.PipeWriterStream`, ($self) => class PipeWriterStream extends $.$$.SI.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(4296605777)
            /*PipeWriter*/ _pipeWriter = null;
            //--TRIMMABLE-BOUNDARY-END(4296605777)
            
            //--TRIMMABLE-BOUNDARY-START(12886540369)
            $ctor$3(/*PipeWriter*/ pipeWriter, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886540369);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(pipeWriter !== null, "pipeWriter != null");
                    this._pipeWriter = pipeWriter;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886540369)
            
            //--TRIMMABLE-BOUNDARY-START(34361376849)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361376849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.LeaveOpen)
                {
                    this._pipeWriter.Complete(null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361376849)
            
            //--TRIMMABLE-BOUNDARY-START(38656344145)
            /*ValueTask */ DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656344145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.LeaveOpen)
                {
                    return this._pipeWriter.CompleteAsync(null);
                }
                return new $.$$.STT.ValueTask();
            }
            //--TRIMMABLE-BOUNDARY-END(38656344145)
            
            //--TRIMMABLE-BOUNDARY-START(111670788177)
            /*bool*/ LeaveOpen = false;
            //--TRIMMABLE-BOUNDARY-END(111670788177)
            
            //--TRIMMABLE-BOUNDARY-START(21476474961)
            /*bool */ get CanRead()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(21476474961)
            
            //--TRIMMABLE-BOUNDARY-START(25771442257)
            /*bool */ get CanSeek()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(25771442257)
            
            //--TRIMMABLE-BOUNDARY-START(30066409553)
            /*bool */ get CanWrite()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(30066409553)
            
            //--TRIMMABLE-BOUNDARY-START(115965755473)
            /*long */ get Length()
            {
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(115965755473)
            
            //--TRIMMABLE-BOUNDARY-START(120260722769)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080853585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030526545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(120260722769)
            
            //--TRIMMABLE-BOUNDARY-START(47246278737)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246278737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.FlushAsync().GetAwaiter().GetResult();
            }
            //--TRIMMABLE-BOUNDARY-END(47246278737)
            
            //--TRIMMABLE-BOUNDARY-START(124555690065)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124555690065);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124555690065)
            
            //--TRIMMABLE-BOUNDARY-START(128850657361)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128850657361);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128850657361)
            
            //--TRIMMABLE-BOUNDARY-START(150325493841)
            /*void */ SetLength(/*long*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150325493841);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150325493841)
            
            //--TRIMMABLE-BOUNDARY-START(17181507665)
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181507665);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.TaskToAsyncResult.Begin(this.WriteAsync(buffer, offset, count, new $.$$.ST$1.CancellationToken()), callback, state);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181507665)
            
            //--TRIMMABLE-BOUNDARY-START(42951311441)
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951311441);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.TaskToAsyncResult.End(asyncResult);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951311441)
            
            //--TRIMMABLE-BOUNDARY-START(154620461137)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154620461137);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.WriteAsync$1(buffer, offset, count).GetAwaiter().GetResult();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154620461137)
            
            //--TRIMMABLE-BOUNDARY-START(158915428433)
            /*Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915428433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (buffer === null)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.WriteAsync(new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))().$ctor$4(buffer, offset, count), cancellationToken);
                return $.$sipl.SIP.PipeWriterStream.GetFlushResultAsTask(valueTask);
            }
            //--TRIMMABLE-BOUNDARY-END(158915428433)
            
            //--TRIMMABLE-BOUNDARY-START(163210395729)
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210395729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.WriteAsync(buffer, cancellationToken);
                return new $.$$.STT.ValueTask().$ctor$5($.$sipl.SIP.PipeWriterStream.GetFlushResultAsTask(valueTask));
            }
            //--TRIMMABLE-BOUNDARY-END(163210395729)
            
            //--TRIMMABLE-BOUNDARY-START(51541246033)
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541246033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.FlushAsync(cancellationToken);
                return $.$sipl.SIP.PipeWriterStream.GetFlushResultAsTask(valueTask);
            }
            //--TRIMMABLE-BOUNDARY-END(51541246033)
            
            //--TRIMMABLE-BOUNDARY-START(107375820881)
            static /*Task */ GetFlushResultAsTask(/*ValueTask<FlushResult>*/ valueTask)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375820881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (valueTask.IsCompletedSuccessfully)
                {
                    /*FlushResult*/ let result = valueTask.Result;
                    if (result.IsCanceled)
                    {
                        $.$sipl.SIP.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                    }
                    return $.$$.STT.Task.CompletedTask;
                }
                /*static Task*/ /*async*/  function AwaitTask(/*ValueTask<FlushResult>*/ valueTask)
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $t1, $r1;
                        /*FlushResult*/ let result = ($t1 = valueTask.ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        if (result.IsCanceled)
                        {
                            $.$sipl.SIP.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                        }
                    });
                }
                return AwaitTask(valueTask);
            }
            //--TRIMMABLE-BOUNDARY-END(107375820881)
            
            static $h = 1638481;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.Stream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111670788177),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900984401,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440591953,
        "f": 83886088
      },
      "n": "LeaveOpen",
      "d": 1638481,
      "h": 111670788177,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(111670788177),
//--TRIMMABLE-BOUNDARY-START(21476474961),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131180625,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 1638481,
      "h": 21476474961,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476474961),
//--TRIMMABLE-BOUNDARY-START(25771442257),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721115217,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 1638481,
      "h": 25771442257,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25771442257),
//--TRIMMABLE-BOUNDARY-START(30066409553),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311049809,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 1638481,
      "h": 30066409553,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30066409553),
//--TRIMMABLE-BOUNDARY-START(115965755473),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490918993,
        "f": 50364417
      },
      "n": "Length",
      "d": 1638481,
      "h": 115965755473,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115965755473),
//--TRIMMABLE-BOUNDARY-START(120260722769),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080853585,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146030526545,
        "f": 83918849
      },
      "n": "Position",
      "d": 1638481,
      "h": 120260722769,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(120260722769)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361376849),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 1638481,
      "h": 34361376849,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34361376849),
//--TRIMMABLE-BOUNDARY-START(38656344145),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 1638481,
      "h": 38656344145,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656344145),
//--TRIMMABLE-BOUNDARY-START(47246278737),
    {
      "r": 65537,
      "n": "Flush",
      "d": 1638481,
      "h": 47246278737,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246278737),
//--TRIMMABLE-BOUNDARY-START(124555690065),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 1638481,
      "h": 124555690065,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124555690065),
//--TRIMMABLE-BOUNDARY-START(128850657361),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 1638481,
      "h": 128850657361,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128850657361),
//--TRIMMABLE-BOUNDARY-START(150325493841),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 1638481,
      "h": 150325493841,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150325493841),
//--TRIMMABLE-BOUNDARY-START(17181507665),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginWrite",
      "d": 1638481,
      "h": 17181507665,
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(17181507665),
//--TRIMMABLE-BOUNDARY-START(42951311441),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndWrite",
      "d": 1638481,
      "h": 42951311441,
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(42951311441),
//--TRIMMABLE-BOUNDARY-START(154620461137),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 1638481,
      "h": 154620461137,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154620461137),
//--TRIMMABLE-BOUNDARY-START(158915428433),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "d": 1638481,
      "h": 158915428433,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158915428433),
//--TRIMMABLE-BOUNDARY-START(163210395729),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 1638481,
      "h": 163210395729,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163210395729),
//--TRIMMABLE-BOUNDARY-START(51541246033),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 1638481,
      "h": 51541246033,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541246033),
//--TRIMMABLE-BOUNDARY-START(107375820881),
    {
      "r": 178454529,
      "p": [
        {
          "n": "valueTask",
          "p": $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult).$h
        }
      ],
      "n": "GetFlushResultAsTask",
      "d": 1638481,
      "h": 107375820881,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107375820881)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296605777),
    {
      "t": 1572945,
      "n": "_pipeWriter",
      "d": 1638481,
      "h": 4296605777,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296605777)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886540369),
    {
      "p": [
        {
          "n": "pipeWriter",
          "p": 1572945
        },
        {
          "n": "leaveOpen",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638481,
      "h": 12886540369,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886540369)
  ],
  "h": 1638481
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeWriterStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeWriterStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638481)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441873)
        $asm.$cls(`$sipl.SIP.PipeReaderStream`, ($self) => class PipeReaderStream extends $.$$.SI.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(4296409169)
            /*PipeReader*/ _pipeReader = null;
            //--TRIMMABLE-BOUNDARY-END(4296409169)
            
            //--TRIMMABLE-BOUNDARY-START(12886343761)
            $ctor$3(/*PipeReader*/ pipeReader, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886343761);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(pipeReader !== null, "pipeReader != null");
                    this._pipeReader = pipeReader;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886343761)
            
            //--TRIMMABLE-BOUNDARY-START(38656147537)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656147537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.LeaveOpen)
                {
                    this._pipeReader.Complete(null);
                }
                super.Dispose$1(disposing);
            }
            //--TRIMMABLE-BOUNDARY-END(38656147537)
            
            //--TRIMMABLE-BOUNDARY-START(21476278353)
            /*bool */ get CanRead()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(21476278353)
            
            //--TRIMMABLE-BOUNDARY-START(25771245649)
            /*bool */ get CanSeek()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(25771245649)
            
            //--TRIMMABLE-BOUNDARY-START(30066212945)
            /*bool */ get CanWrite()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(30066212945)
            
            //--TRIMMABLE-BOUNDARY-START(111670591569)
            /*long */ get Length()
            {
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(111670591569)
            
            //--TRIMMABLE-BOUNDARY-START(115965558865)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785689681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505166417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(115965558865)
            
            //--TRIMMABLE-BOUNDARY-START(107375624273)
            /*bool*/ LeaveOpen = false;
            //--TRIMMABLE-BOUNDARY-END(107375624273)
            
            //--TRIMMABLE-BOUNDARY-START(47246082129)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246082129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47246082129)
            
            //--TRIMMABLE-BOUNDARY-START(120260526161)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260526161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (buffer === null)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                return this.ReadInternal(new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$6(buffer, offset, count));
            }
            //--TRIMMABLE-BOUNDARY-END(120260526161)
            
            //--TRIMMABLE-BOUNDARY-START(141735362641)
            /*int */ ReadByte()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735362641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Span<byte>*/ let oneByte = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Byte, 1, null);
                return this.ReadInternal(oneByte) === 0 ? -1 : oneByte._reference.GetAt(0);
            }
            //--TRIMMABLE-BOUNDARY-END(141735362641)
            
            //--TRIMMABLE-BOUNDARY-START(146030329937)
            /*int */ ReadInternal(/*Span<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030329937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ValueTask<ReadResult>*/ let vt = this._pipeReader.ReadAsync(new $.$$.ST$1.CancellationToken());
                /*ReadResult*/ let result = vt.IsCompletedSuccessfully ? vt.Result : vt.AsTask().GetAwaiter$1().GetResult();
                return this.HandleReadResult(result, buffer);
            }
            //--TRIMMABLE-BOUNDARY-END(146030329937)
            
            //--TRIMMABLE-BOUNDARY-START(150325297233)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150325297233);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150325297233)
            
            //--TRIMMABLE-BOUNDARY-START(171800133713)
            /*void */ SetLength(/*long*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171800133713);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171800133713)
            
            //--TRIMMABLE-BOUNDARY-START(176095101009)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176095101009);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176095101009)
            
            //--TRIMMABLE-BOUNDARY-START(17181311057)
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181311057);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.TaskToAsyncResult.Begin(this.ReadAsync(buffer, offset, count, new $.$$.ST$1.CancellationToken()), callback, state);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181311057)
            
            //--TRIMMABLE-BOUNDARY-START(42951114833)
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951114833);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.TaskToAsyncResult.End$1($.$$.S.Int32, asyncResult);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951114833)
            
            //--TRIMMABLE-BOUNDARY-START(128850460753)
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850460753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (buffer === null)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                return this.ReadAsyncInternal(new ($.$$.S.Memory$$($.$$.S.Byte))().$ctor$6(buffer, offset, count), cancellationToken).AsTask();
            }
            //--TRIMMABLE-BOUNDARY-END(128850460753)
            
            //--TRIMMABLE-BOUNDARY-START(124555493457)
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555493457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadInternal(buffer);
            }
            //--TRIMMABLE-BOUNDARY-END(124555493457)
            
            //--TRIMMABLE-BOUNDARY-START(133145428049)
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145428049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadAsyncInternal(buffer, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(133145428049)
            
            //--TRIMMABLE-BOUNDARY-START(137440395345)
            /*ValueTask<int> *//*async*/  ReadAsyncInternal(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Int32), $.$$.S.Int32, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137440395345);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*ReadResult*/ let result = ($t1 = this._pipeReader.ReadAsync(cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, this.HandleReadResult(result, buffer.Span));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(137440395345)
            
            //--TRIMMABLE-BOUNDARY-START(103080656977)
            /*int */ HandleReadResult(/*ReadResult*/ result, /*Span<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080656977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (result.IsCanceled)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                }
                /*ReadOnlySequence<byte>*/ let sequence = result.Buffer;
                /*long*/ let bufferLength = sequence.Length;
                /*SequencePosition*/ let consumed = sequence.Start;
                try
                {
                    if (bufferLength !== 0n)
                    {
                        /*int*/ let actual = $.$cast($.$$.S.Math.Min$5(bufferLength, BigInt(buffer.Length)), $.$$.S.Int32);
                        /*ReadOnlySequence<byte>*/ let slice = BigInt(actual) === bufferLength ? sequence : sequence.Slice(0, actual);
                        consumed = slice.End;
                        $.$sm.SB.BuffersExtensions.CopyTo($.$$.S.Byte, $.$ref(() => slice, ), buffer);
                        return actual;
                    }
                    if (result.IsCompleted)
                    {
                        return 0;
                    }
                }
                finally
                {
                    {
                        this._pipeReader.AdvanceTo$1(consumed);
                    }
                }
                $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_InvalidZeroByteRead();
                return 0;
            }
            //--TRIMMABLE-BOUNDARY-END(103080656977)
            
            //--TRIMMABLE-BOUNDARY-START(34361180241)
            /*Task */ CopyToAsync(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361180241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sipl.SI.StreamHelpers.ValidateCopyToArgs(this, destination, bufferSize);
                return this._pipeReader.CopyToAsync$1(destination, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(34361180241)
            
            static $h = 1441873;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.Stream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476278353),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836016721,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 1441873,
      "h": 21476278353,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21476278353),
//--TRIMMABLE-BOUNDARY-START(25771245649),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425951313,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 1441873,
      "h": 25771245649,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25771245649),
//--TRIMMABLE-BOUNDARY-START(30066212945),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015885905,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 1441873,
      "h": 30066212945,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30066212945),
//--TRIMMABLE-BOUNDARY-START(111670591569),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195755089,
        "f": 50364417
      },
      "n": "Length",
      "d": 1441873,
      "h": 111670591569,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(111670591569),
//--TRIMMABLE-BOUNDARY-START(115965558865),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785689681,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505166417,
        "f": 83918849
      },
      "n": "Position",
      "d": 1441873,
      "h": 115965558865,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115965558865),
//--TRIMMABLE-BOUNDARY-START(107375624273),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605820497,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915231825,
        "f": 83886088
      },
      "n": "LeaveOpen",
      "d": 1441873,
      "h": 107375624273,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(107375624273)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38656147537),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 1441873,
      "h": 38656147537,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38656147537),
//--TRIMMABLE-BOUNDARY-START(47246082129),
    {
      "r": 65537,
      "n": "Flush",
      "d": 1441873,
      "h": 47246082129,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246082129),
//--TRIMMABLE-BOUNDARY-START(120260526161),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 1441873,
      "h": 120260526161,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120260526161),
//--TRIMMABLE-BOUNDARY-START(141735362641),
    {
      "r": 655361,
      "n": "ReadByte",
      "d": 1441873,
      "h": 141735362641,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(141735362641),
//--TRIMMABLE-BOUNDARY-START(146030329937),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "ReadInternal",
      "d": 1441873,
      "h": 146030329937,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(146030329937),
//--TRIMMABLE-BOUNDARY-START(150325297233),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 1441873,
      "h": 150325297233,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150325297233),
//--TRIMMABLE-BOUNDARY-START(171800133713),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 1441873,
      "h": 171800133713,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171800133713),
//--TRIMMABLE-BOUNDARY-START(176095101009),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 1441873,
      "h": 176095101009,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176095101009),
//--TRIMMABLE-BOUNDARY-START(17181311057),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginRead",
      "d": 1441873,
      "h": 17181311057,
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(17181311057),
//--TRIMMABLE-BOUNDARY-START(42951114833),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndRead",
      "d": 1441873,
      "h": 42951114833,
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(42951114833),
//--TRIMMABLE-BOUNDARY-START(128850460753),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "d": 1441873,
      "h": 128850460753,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128850460753),
//--TRIMMABLE-BOUNDARY-START(124555493457),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 1441873,
      "h": 124555493457,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124555493457),
//--TRIMMABLE-BOUNDARY-START(133145428049),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 1441873,
      "h": 133145428049,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133145428049),
//--TRIMMABLE-BOUNDARY-START(137440395345),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsyncInternal",
      "d": 1441873,
      "h": 137440395345,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(137440395345),
//--TRIMMABLE-BOUNDARY-START(103080656977),
    {
      "r": 655361,
      "p": [
        {
          "n": "result",
          "p": 1704017
        },
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "HandleReadResult",
      "d": 1441873,
      "h": 103080656977,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103080656977),
//--TRIMMABLE-BOUNDARY-START(34361180241),
    {
      "r": 178454529,
      "p": [
        {
          "n": "destination",
          "p": 95748097
        },
        {
          "n": "bufferSize",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CopyToAsync",
      "d": 1441873,
      "h": 34361180241,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361180241)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296409169),
    {
      "t": 1376337,
      "n": "_pipeReader",
      "d": 1441873,
      "h": 4296409169,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296409169)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886343761),
    {
      "p": [
        {
          "n": "pipeReader",
          "p": 1376337
        },
        {
          "n": "leaveOpen",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1441873,
      "h": 12886343761,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886343761)
  ],
  "h": 1441873
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.PipeReaderStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}PipeReaderStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441873)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769553)
        $asm.$str(`$sipl.SIP.ResultFlags`, ($self) => class ResultFlags extends $.$$.S.Enum$$$($self, $.$$.S.Byte)
        {
            static None = 0;
            static Canceled = 1;
            static Completed = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1769553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Canceled": 1n,
                    "Completed": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296736849)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296736849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296736849)
            
            //--TRIMMABLE-BOUNDARY-START(4296736849)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296736849)
            
            static $h = 1769553;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 393217,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181638737),
    {
      "t": 1769553,
      "n": "None",
      "d": 1769553,
      "h": 17181638737,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181638737),
//--TRIMMABLE-BOUNDARY-START(8591704145),
    {
      "t": 1769553,
      "n": "Canceled",
      "d": 1769553,
      "h": 8591704145,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591704145),
//--TRIMMABLE-BOUNDARY-START(12886671441),
    {
      "t": 1769553,
      "n": "Completed",
      "d": 1769553,
      "h": 12886671441,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886671441)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296736849),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1769553,
      "h": 4296736849,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296736849)
  ],
  "h": 1769553,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.ResultFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}ResultFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769553)
        
        

        //--TRIMMABLE-BOUNDARY-START(327761)
        $asm.$str(`$sipl.SIP.ExceptionArgument`, ($self) => class ExceptionArgument extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static minimumSize = 0;
            static bytes = 1;
            static callback = 2;
            static options = 3;
            static pauseWriterThreshold = 4;
            static resumeWriterThreshold = 5;
            static sizeHint = 6;
            static destination = 7;
            static buffer = 8;
            static source = 9;
            static readingStream = 10;
            static writingStream = 11;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "minimumSize": 0n,
                    "bytes": 1n,
                    "callback": 2n,
                    "options": 3n,
                    "pauseWriterThreshold": 4n,
                    "resumeWriterThreshold": 5n,
                    "sizeHint": 6n,
                    "destination": 7n,
                    "buffer": 8n,
                    "source": 9n,
                    "readingStream": 10n,
                    "writingStream": 11n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295295057)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295057)
            
            //--TRIMMABLE-BOUNDARY-START(4295295057)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295295057)
            
            static $h = 327761;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770131537),
    {
      "t": 327761,
      "n": "minimumSize",
      "d": 327761,
      "h": 25770131537,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770131537),
//--TRIMMABLE-BOUNDARY-START(12885229649),
    {
      "t": 327761,
      "n": "bytes",
      "d": 327761,
      "h": 12885229649,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885229649),
//--TRIMMABLE-BOUNDARY-START(17180196945),
    {
      "t": 327761,
      "n": "callback",
      "d": 327761,
      "h": 17180196945,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180196945),
//--TRIMMABLE-BOUNDARY-START(30065098833),
    {
      "t": 327761,
      "n": "options",
      "d": 327761,
      "h": 30065098833,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065098833),
//--TRIMMABLE-BOUNDARY-START(34360066129),
    {
      "t": 327761,
      "n": "pauseWriterThreshold",
      "d": 327761,
      "h": 34360066129,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360066129),
//--TRIMMABLE-BOUNDARY-START(42950000721),
    {
      "t": 327761,
      "n": "resumeWriterThreshold",
      "d": 327761,
      "h": 42950000721,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950000721),
//--TRIMMABLE-BOUNDARY-START(47244968017),
    {
      "t": 327761,
      "n": "sizeHint",
      "d": 327761,
      "h": 47244968017,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47244968017),
//--TRIMMABLE-BOUNDARY-START(21475164241),
    {
      "t": 327761,
      "n": "destination",
      "d": 327761,
      "h": 21475164241,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475164241),
//--TRIMMABLE-BOUNDARY-START(8590262353),
    {
      "t": 327761,
      "n": "buffer",
      "d": 327761,
      "h": 8590262353,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590262353),
//--TRIMMABLE-BOUNDARY-START(51539935313),
    {
      "t": 327761,
      "n": "source",
      "d": 327761,
      "h": 51539935313,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539935313),
//--TRIMMABLE-BOUNDARY-START(38655033425),
    {
      "t": 327761,
      "n": "readingStream",
      "d": 327761,
      "h": 38655033425,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655033425),
//--TRIMMABLE-BOUNDARY-START(55834902609),
    {
      "t": 327761,
      "n": "writingStream",
      "d": 327761,
      "h": 55834902609,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834902609)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295057),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327761,
      "h": 4295295057,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295057)
  ],
  "h": 327761
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.ExceptionArgument`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}ExceptionArgument`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327761)
        
        

        //--TRIMMABLE-BOUNDARY-START(65617)
        $asm.$cls(`$sipl.SIP.BufferSegment`, ($self) => class BufferSegment extends $.$sm.SB.ReadOnlySequenceSegment$$($.$$.S.Byte)
        {
            //--TRIMMABLE-BOUNDARY-START(12884967505)
            /*IMemoryOwner<byte>?*/ _memoryOwner = null;
            //--TRIMMABLE-BOUNDARY-END(12884967505)
            
            //--TRIMMABLE-BOUNDARY-START(4295032913)
            /*byte[]?*/ _array = null;
            //--TRIMMABLE-BOUNDARY-END(4295032913)
            
            //--TRIMMABLE-BOUNDARY-START(17179934801)
            /*BufferSegment?*/ _next = null;
            //--TRIMMABLE-BOUNDARY-END(17179934801)
            
            //--TRIMMABLE-BOUNDARY-START(8590000209)
            /*int*/ _end = 0;
            //--TRIMMABLE-BOUNDARY-END(8590000209)
            
            //--TRIMMABLE-BOUNDARY-START(34359803985)
            /*int */ get End()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._end;
            }
            /*int */ set End(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144051793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(value <= this.AvailableMemory.Length, "value <= AvailableMemory.Length");
                this._end = value;
                this.Memory = $.$$.S.Memory$$($.$$.S.Byte).op_Implicit(this.AvailableMemory.Slice(0, value));
            }
            //--TRIMMABLE-BOUNDARY-END(34359803985)
            
            //--TRIMMABLE-BOUNDARY-START(107374248017)
            /*BufferSegment? */ get NextSegment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309476945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._next;
            }
            /*BufferSegment? */ set NextSegment(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141733986385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Next = value;
                this._next = value;
            }
            //--TRIMMABLE-BOUNDARY-END(107374248017)
            
            //--TRIMMABLE-BOUNDARY-START(150323920977)
            /*void */ SetOwnedMemory(/*IMemoryOwner<byte>*/ memoryOwner)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150323920977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._memoryOwner = memoryOwner;
                this.AvailableMemory = memoryOwner.SB$IMemoryOwner$$$Memory;
            }
            //--TRIMMABLE-BOUNDARY-END(150323920977)
            
            //--TRIMMABLE-BOUNDARY-START(154618888273)
            /*void */ SetOwnedMemory$1(/*byte[]*/ arrayPoolBuffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154618888273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._array = arrayPoolBuffer;
                this.AvailableMemory = $.$$.S.Memory$$($.$$.S.Byte).op_Implicit$2(arrayPoolBuffer);
            }
            //--TRIMMABLE-BOUNDARY-END(154618888273)
            
            //--TRIMMABLE-BOUNDARY-START(111669215313)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669215313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ResetMemory();
                this.Next = null;
                this.RunningIndex = 0n;
                this._next = null;
            }
            //--TRIMMABLE-BOUNDARY-END(111669215313)
            
            //--TRIMMABLE-BOUNDARY-START(115964182609)
            /*void */ ResetMemory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964182609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IMemoryOwner<byte>?*/ let memoryOwner = this._memoryOwner;
                if (memoryOwner !== null)
                {
                    this._memoryOwner = null;
                    memoryOwner.S$IDisposable$Dispose();
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4(this._array !== null, "_array != null");
                    $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(this._array, false);
                    this._array = null;
                }
                this.Memory = new ($.$$.S.ReadOnlyMemory$$($.$$.S.Byte))();
                this._end = 0;
                this.AvailableMemory = new ($.$$.S.Memory$$($.$$.S.Byte))();
            }
            //--TRIMMABLE-BOUNDARY-END(115964182609)
            
            //--TRIMMABLE-BOUNDARY-START(103079280721)
            /*object? */ get MemoryOwner()
            {
                return $.$cast(this._memoryOwner, $.$$.S.Object) ?? this._array;
            }
            //--TRIMMABLE-BOUNDARY-END(103079280721)
            
            //--TRIMMABLE-BOUNDARY-START(30064836689)
            /*Memory<byte>*/ AvailableMemory;
            //--TRIMMABLE-BOUNDARY-END(30064836689)
            
            //--TRIMMABLE-BOUNDARY-START(98784313425)
            /*int */ get Length()
            {
                return this.End;
            }
            //--TRIMMABLE-BOUNDARY-END(98784313425)
            
            //--TRIMMABLE-BOUNDARY-START(158913855569)
            /*int */ get WritableBytes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899411537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ((this.AvailableMemory.Length - this.End) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(158913855569)
            
            //--TRIMMABLE-BOUNDARY-START(146028953681)
            /*void */ SetNext(/*BufferSegment*/ segment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146028953681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(segment !== null, "segment != null");
                $.$$.SD.Debug.Assert$4(this.Next === null, "Next == null");
                this.NextSegment = segment;
                segment = this;
                while(segment.Next !== null)
                {
                    $.$$.SD.Debug.Assert$4(segment.NextSegment !== null, "segment.NextSegment != null");
                    segment.NextSegment.RunningIndex = BigInt.asIntN(64, segment.RunningIndex + BigInt(segment.Length));
                    segment = segment.NextSegment;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146028953681)
            
            //--TRIMMABLE-BOUNDARY-START(94489346129)
            static /*long */ GetLength$1(/*BufferSegment*/ startSegment, /*int*/ startIndex, /*BufferSegment*/ endSegment, /*int*/ endIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489346129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return BigInt.asIntN(64, (BigInt.asIntN(64, endSegment.RunningIndex + BigInt((endIndex >>> 0)))) - (BigInt.asIntN(64, startSegment.RunningIndex + BigInt((startIndex >>> 0)))));
            }
            //--TRIMMABLE-BOUNDARY-END(94489346129)
            
            //--TRIMMABLE-BOUNDARY-START(90194378833)
            static /*long */ GetLength(/*long*/ startPosition, /*BufferSegment*/ endSegment, /*int*/ endIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194378833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return BigInt.asIntN(64, (BigInt.asIntN(64, endSegment.RunningIndex + BigInt((endIndex >>> 0)))) - startPosition);
            }
            //--TRIMMABLE-BOUNDARY-END(90194378833)
            
            //--TRIMMABLE-BOUNDARY-START(25769869393)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869393)
            
            //--TRIMMABLE-BOUNDARY-START(25769869393)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(25769869393)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(30064836689)
                this.AvailableMemory = $.$default($.$$.S.Memory$$($.$$.S.Byte));
                //--TRIMMABLE-BOUNDARY-END(30064836689)
                
            }
            static $h = 65617;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sm.SB.ReadOnlySequenceSegment$$($.$$.S.Byte); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359803985),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539673169,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144051793,
        "f": 83886081
      },
      "n": "End",
      "d": 65617,
      "h": 34359803985,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359803985),
//--TRIMMABLE-BOUNDARY-START(107374248017),
    {
      "p": 65617,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309476945,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141733986385,
        "f": 83886081
      },
      "n": "NextSegment",
      "d": 65617,
      "h": 107374248017,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374248017),
//--TRIMMABLE-BOUNDARY-START(103079280721),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719542353,
        "f": 50331656
      },
      "n": "MemoryOwner",
      "d": 65617,
      "h": 103079280721,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(103079280721),
//--TRIMMABLE-BOUNDARY-START(30064836689),
    {
      "p": $.$$.S.Memory$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949738577,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554117201,
        "f": 83886082
      },
      "n": "AvailableMemory",
      "d": 65617,
      "h": 30064836689,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064836689),
//--TRIMMABLE-BOUNDARY-START(98784313425),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129607761,
        "f": 50331649
      },
      "n": "Length",
      "d": 65617,
      "h": 98784313425,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784313425),
//--TRIMMABLE-BOUNDARY-START(158913855569),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899411537,
        "f": 50331649
      },
      "n": "WritableBytes",
      "d": 65617,
      "h": 158913855569,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158913855569)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(150323920977),
    {
      "r": 65537,
      "p": [
        {
          "n": "memoryOwner",
          "p": $.$$.SB.IMemoryOwner$$($.$$.S.Byte).$h
        }
      ],
      "n": "SetOwnedMemory",
      "d": 65617,
      "h": 150323920977,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150323920977),
//--TRIMMABLE-BOUNDARY-START(154618888273),
    {
      "r": 65537,
      "p": [
        {
          "n": "arrayPoolBuffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "SetOwnedMemory",
      "o": "@$1",
      "d": 65617,
      "h": 154618888273,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154618888273),
//--TRIMMABLE-BOUNDARY-START(111669215313),
    {
      "r": 65537,
      "n": "Reset",
      "d": 65617,
      "h": 111669215313,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669215313),
//--TRIMMABLE-BOUNDARY-START(115964182609),
    {
      "r": 65537,
      "n": "ResetMemory",
      "d": 65617,
      "h": 115964182609,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964182609),
//--TRIMMABLE-BOUNDARY-START(146028953681),
    {
      "r": 65537,
      "p": [
        {
          "n": "segment",
          "p": 65617
        }
      ],
      "n": "SetNext",
      "d": 65617,
      "h": 146028953681,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146028953681),
//--TRIMMABLE-BOUNDARY-START(94489346129),
    {
      "r": 917505,
      "p": [
        {
          "n": "startSegment",
          "p": 65617
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endSegment",
          "p": 65617
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "GetLength",
      "o": "@$1",
      "d": 65617,
      "h": 94489346129,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(94489346129),
//--TRIMMABLE-BOUNDARY-START(90194378833),
    {
      "r": 917505,
      "p": [
        {
          "n": "startPosition",
          "p": 917505
        },
        {
          "n": "endSegment",
          "p": 65617
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "GetLength",
      "d": 65617,
      "h": 90194378833,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(90194378833)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12884967505),
    {
      "t": $.$$.SB.IMemoryOwner$$($.$$.S.Byte).$h,
      "n": "_memoryOwner",
      "d": 65617,
      "h": 12884967505,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12884967505),
//--TRIMMABLE-BOUNDARY-START(4295032913),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_array",
      "d": 65617,
      "h": 4295032913,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032913),
//--TRIMMABLE-BOUNDARY-START(17179934801),
    {
      "t": 65617,
      "n": "_next",
      "d": 65617,
      "h": 17179934801,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17179934801),
//--TRIMMABLE-BOUNDARY-START(8590000209),
    {
      "t": 655361,
      "n": "_end",
      "d": 65617,
      "h": 8590000209,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590000209)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25769869393),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65617,
      "h": 25769869393,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769869393)
  ],
  "h": 65617
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.BufferSegment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}BufferSegment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65617)
        
        

        //--TRIMMABLE-BOUNDARY-START(2097233)
        $asm.$cls(`$sipl.SIP.StreamPipeWriter`, ($self) => class StreamPipeWriter extends $.$sipl.SIP.PipeWriter
        {
            //--TRIMMABLE-BOUNDARY-START(167505821777)
            /*int*/ static InitialSegmentPoolSize = 4;
            //--TRIMMABLE-BOUNDARY-END(167505821777)
            
            //--TRIMMABLE-BOUNDARY-START(180390723665)
            /*int*/ static MaxSegmentPoolSize = 256;
            //--TRIMMABLE-BOUNDARY-END(180390723665)
            
            //--TRIMMABLE-BOUNDARY-START(38656802897)
            /*int*/ _minimumBufferSize = 0;
            //--TRIMMABLE-BOUNDARY-END(38656802897)
            
            //--TRIMMABLE-BOUNDARY-START(12886999121)
            /*BufferSegment?*/ _head = null;
            //--TRIMMABLE-BOUNDARY-END(12886999121)
            
            //--TRIMMABLE-BOUNDARY-START(47246737489)
            /*BufferSegment?*/ _tail = null;
            //--TRIMMABLE-BOUNDARY-END(47246737489)
            
            //--TRIMMABLE-BOUNDARY-START(55836672081)
            /*Memory<byte>*/ _tailMemory;
            //--TRIMMABLE-BOUNDARY-END(55836672081)
            
            //--TRIMMABLE-BOUNDARY-START(51541704785)
            /*int*/ _tailBytesBuffered = 0;
            //--TRIMMABLE-BOUNDARY-END(51541704785)
            
            //--TRIMMABLE-BOUNDARY-START(8592031825)
            /*long*/ _bytesBuffered = 0n;
            //--TRIMMABLE-BOUNDARY-END(8592031825)
            
            //--TRIMMABLE-BOUNDARY-START(42951770193)
            /*MemoryPool<byte>?*/ _pool = null;
            //--TRIMMABLE-BOUNDARY-END(42951770193)
            
            //--TRIMMABLE-BOUNDARY-START(34361835601)
            /*int*/ _maxPooledBufferSize = 0;
            //--TRIMMABLE-BOUNDARY-END(34361835601)
            
            //--TRIMMABLE-BOUNDARY-START(17181966417)
            /*CancellationTokenSource?*/ _internalTokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(17181966417)
            
            //--TRIMMABLE-BOUNDARY-START(21476933713)
            /*bool*/ _isCompleted = false;
            //--TRIMMABLE-BOUNDARY-END(21476933713)
            
            //--TRIMMABLE-BOUNDARY-START(30066868305)
            /*object*/ _lockObject = null;
            //--TRIMMABLE-BOUNDARY-END(30066868305)
            
            //--TRIMMABLE-BOUNDARY-START(4297064529)
            /*BufferSegmentStack*/ _bufferSegmentPool;
            //--TRIMMABLE-BOUNDARY-END(4297064529)
            
            //--TRIMMABLE-BOUNDARY-START(25771901009)
            /*bool*/ _leaveOpen = false;
            //--TRIMMABLE-BOUNDARY-END(25771901009)
            
            //--TRIMMABLE-BOUNDARY-START(176095756369)
            /*CancellationTokenSource */ get InternalTokenSource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736018001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_lockObject)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                    {
                        return this._internalTokenSource ??= new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._lockObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176095756369)
            
            //--TRIMMABLE-BOUNDARY-START(64426606673)
            $ctor$2(/*Stream*/ writingStream, /*StreamPipeWriterOptions*/ options)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64426606673);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (writingStream === null)
                    {
                        $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(11/*ExceptionArgument.writingStream*/);
                    }
                    if (options === null)
                    {
                        $.$sipl.SIP.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this.InnerStream = writingStream;
                    this._minimumBufferSize = options.MinimumBufferSize;
                    this._pool = options.Pool === $.$sm.SB.MemoryPool$$($.$$.S.Byte).Shared ? null : options.Pool;
                    this._maxPooledBufferSize = (this._pool?.MaxBufferSize ?? null) ?? -1;
                    this._bufferSegmentPool = new $.$sipl.SIP.BufferSegmentStack().$ctor$3(4/*InitialSegmentPoolSize*/);
                    this._leaveOpen = options.LeaveOpen;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64426606673)
            
            //--TRIMMABLE-BOUNDARY-START(171800789073)
            /*Stream*/ InnerStream = null;
            //--TRIMMABLE-BOUNDARY-END(171800789073)
            
            //--TRIMMABLE-BOUNDARY-START(68721573969)
            /*void */ Advance(/*int*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721573969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((bytes >>> 0) > (this._tailMemory.Length >>> 0))
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.bytes*/);
                }
                this._tailBytesBuffered += bytes;
                this._bytesBuffered += BigInt(bytes);
                this._tailMemory = this._tailMemory.Slice$1(bytes);
            }
            //--TRIMMABLE-BOUNDARY-END(68721573969)
            
            //--TRIMMABLE-BOUNDARY-START(154620919889)
            /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620919889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isCompleted)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateMemory(sizeHint);
                return this._tailMemory;
            }
            //--TRIMMABLE-BOUNDARY-END(154620919889)
            
            //--TRIMMABLE-BOUNDARY-START(163210854481)
            /*Span<byte> */ GetSpan(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210854481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isCompleted)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.SIP.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateMemory(sizeHint);
                return this._tailMemory.Span;
            }
            //--TRIMMABLE-BOUNDARY-END(163210854481)
            
            //--TRIMMABLE-BOUNDARY-START(73016541265)
            /*void */ AllocateMemory(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016541265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._head === null)
                {
                    /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                    this._head = this._tail = newSegment;
                    this._tailBytesBuffered = 0;
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4(this._tail !== null, "_tail != null");
                    /*int*/ let bytesLeftInBuffer = this._tailMemory.Length;
                    if (bytesLeftInBuffer === 0 || bytesLeftInBuffer < sizeHint)
                    {
                        if (this._tailBytesBuffered > 0)
                        {
                            this._tail.End += this._tailBytesBuffered;
                            this._tailBytesBuffered = 0;
                        }
                        /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                        this._tail.SetNext(newSegment);
                        this._tail = newSegment;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73016541265)
            
            //--TRIMMABLE-BOUNDARY-START(77311508561)
            /*BufferSegment */ AllocateSegment(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311508561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(sizeHint >= 0, "sizeHint >= 0");
                /*BufferSegment*/ let newSegment = this.CreateSegmentUnsynchronized();
                /*int*/ let maxSize = this._maxPooledBufferSize;
                if (sizeHint <= maxSize)
                {
                    newSegment.SetOwnedMemory(this._pool.Rent(this.GetSegmentSize(sizeHint, maxSize)));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(sizeHint, 2147483647);
                    newSegment.SetOwnedMemory$1($.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(sizeToRequest));
                }
                this._tailMemory = newSegment.AvailableMemory;
                return newSegment;
            }
            //--TRIMMABLE-BOUNDARY-END(77311508561)
            
            //--TRIMMABLE-BOUNDARY-START(158915887185)
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915887185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                sizeHint = $.$$.S.Math.Max$4(this._minimumBufferSize, sizeHint);
                /*var*/ let adjustedToMaximumSize = $.$$.S.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            //--TRIMMABLE-BOUNDARY-END(158915887185)
            
            //--TRIMMABLE-BOUNDARY-START(103081312337)
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081312337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.SIP.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.SIP.BufferSegment().$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(103081312337)
            
            //--TRIMMABLE-BOUNDARY-START(184685690961)
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685690961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                segment.Reset();
                if (this._bufferSegmentPool.Count < 256/*MaxSegmentPoolSize*/)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184685690961)
            
            //--TRIMMABLE-BOUNDARY-START(85901443153)
            /*void */ CancelPendingFlush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901443153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Cancel();
            }
            //--TRIMMABLE-BOUNDARY-END(85901443153)
            
            //--TRIMMABLE-BOUNDARY-START(90196410449)
            /*bool */ get CanGetUnflushedBytes()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(90196410449)
            
            //--TRIMMABLE-BOUNDARY-START(94491377745)
            /*void */ Complete(/*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491377745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isCompleted)
                {
                    return;
                }
                this._isCompleted = true;
                try
                {
                    this.FlushInternal(exception === null);
                }
                finally
                {
                    {
                        this._internalTokenSource?.Dispose();
                        if (!this._leaveOpen)
                        {
                            this.InnerStream.Dispose();
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94491377745)
            
            //--TRIMMABLE-BOUNDARY-START(98786345041)
            /*ValueTask *//*async*/  CompleteAsync(/*Exception?*/ exception)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98786345041);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._isCompleted)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    this._isCompleted = true;
                    try
                    {
                        let $t2, $r2;
                        ($t2 = this.FlushAsyncInternal(exception === null, $.$$.S.Memory$$($.$$.S.Byte).op_Implicit($.$$.S.Memory$$($.$$.S.Byte).Empty), new $.$$.ST$1.CancellationToken()).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    finally
                    {
                        {
                            this._internalTokenSource?.Dispose();
                            if (!this._leaveOpen)
                            {
                                let $t3, $r3;
                                ($t3 = this.InnerStream.DisposeAsync().ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(98786345041)
            
            //--TRIMMABLE-BOUNDARY-START(107376279633)
            /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376279633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._bytesBuffered === 0n)
                {
                    return new ($.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult))().$ctor$6(new $.$sipl.SIP.FlushResult().$ctor$3(false, false));
                }
                return this.FlushAsyncInternal(true, $.$$.S.Memory$$($.$$.S.Byte).op_Implicit($.$$.S.Memory$$($.$$.S.Byte).Empty), cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(107376279633)
            
            //--TRIMMABLE-BOUNDARY-START(188980658257)
            /*long */ get UnflushedBytes()
            {
                return this._bytesBuffered;
            }
            //--TRIMMABLE-BOUNDARY-END(188980658257)
            
            //--TRIMMABLE-BOUNDARY-START(193275625553)
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275625553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.FlushAsyncInternal(true, source, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(193275625553)
            
            //--TRIMMABLE-BOUNDARY-START(81606475857)
            /*void */ Cancel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606475857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.InternalTokenSource.Cancel();
            }
            //--TRIMMABLE-BOUNDARY-END(81606475857)
            
            //--TRIMMABLE-BOUNDARY-START(111671246929)
            /*ValueTask<FlushResult> *//*async*/  FlushAsyncInternal(/*bool*/ writeToStream, /*ReadOnlyMemory<byte>*/ data, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult), $.$sipl.SIP.FlushResult, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111671246929);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*CancellationTokenRegistration*/ let reg = new $.$$.ST$1.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister$1(new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.SIP.StreamPipeWriter)).Cancel();
                        }, $dlQdyc ??= {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":2097233,"h":0,"f":17825794}), this);
                    }
                    if (this._tailBytesBuffered > 0)
                    {
                        $.$$.SD.Debug.Assert$4(this._tail !== null, "_tail != null");
                        this._tail.End += this._tailBytesBuffered;
                        this._tailBytesBuffered = 0;
                    }
                    let $disposable4 = null;
                    try
                    {
                        $disposable4 = reg;
                        /*CancellationToken*/ let localToken = this.InternalTokenSource.Token;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._head;
                            while(segment !== null)
                            {
                                /*BufferSegment*/ let returnSegment = segment;
                                segment = segment.NextSegment;
                                if (returnSegment.Length > 0 && writeToStream)
                                {
                                    let $t5, $r5;
                                    ($t5 = this.InnerStream.WriteAsync$2(returnSegment.Memory, localToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                                }
                                this.ReturnSegmentUnsynchronized(returnSegment);
                                this._head = segment;
                            }
                            if (writeToStream)
                            {
                                if (data.Length > 0)
                                {
                                    let $t6, $r6;
                                    ($t6 = this.InnerStream.WriteAsync$2(data, localToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                }
                                if (this._bytesBuffered > 0n || data.Length > 0)
                                {
                                    let $t7, $r7;
                                    ($t7 = this.InnerStream.FlushAsync$1(localToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                                }
                            }
                            this._head = null;
                            this._tail = null;
                            this._tailMemory = new ($.$$.S.Memory$$($.$$.S.Byte))();
                            this._bytesBuffered = 0n;
                            return $.$$.N.AsyncResolver.Result($asnycContext, new $.$sipl.SIP.FlushResult().$ctor$3(false, false));
                        }
                        catch($e)
                        {
                            //lock(_lockObject)
                            try
                            {
                                $.$$.ST$1.Monitor.Enter$1(this._lockObject)
                                {
                                    this._internalTokenSource = null;
                                }
                            }
                            finally
                            {
                                $.$$.ST$1.Monitor.Exit(this._lockObject)
                            }
                            if (localToken.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext, new $.$sipl.SIP.FlushResult().$ctor$3(true, false));
                            }
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable4?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111671246929)
            
            //--TRIMMABLE-BOUNDARY-START(115966214225)
            /*void */ FlushInternal(/*bool*/ writeToStream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966214225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._tailBytesBuffered > 0)
                {
                    $.$$.SD.Debug.Assert$4(this._tail !== null, "_tail != null");
                    this._tail.End += this._tailBytesBuffered;
                    this._tailBytesBuffered = 0;
                }
                /*BufferSegment?*/ let segment = this._head;
                while(segment !== null)
                {
                    /*BufferSegment*/ let returnSegment = segment;
                    segment = segment.NextSegment;
                    if (returnSegment.Length > 0 && writeToStream)
                    {
                        this.InnerStream.Write$1(returnSegment.Memory.Span);
                    }
                    this.ReturnSegmentUnsynchronized(returnSegment);
                    this._head = segment;
                }
                if (this._bytesBuffered > 0n && writeToStream)
                {
                    this.InnerStream.Flush();
                }
                this._head = null;
                this._tail = null;
                this._tailMemory = new ($.$$.S.Memory$$($.$$.S.Byte))();
                this._bytesBuffered = 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(115966214225)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(55836672081)
                this._tailMemory = $.$default($.$$.S.Memory$$($.$$.S.Byte));
                //--TRIMMABLE-BOUNDARY-END(55836672081)
                
                //--TRIMMABLE-BOUNDARY-START(30066868305)
                this._lockObject = new $.$$.S.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(30066868305)
                
                //--TRIMMABLE-BOUNDARY-START(4297064529)
                this._bufferSegmentPool = $.$default($.$sipl.SIP.BufferSegmentStack);
                //--TRIMMABLE-BOUNDARY-END(4297064529)
                
            }
            static $h = 2097233;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sipl.SIP.PipeWriter; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(176095756369),
    {
      "p": 170983425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141736018001,
        "f": 50331650
      },
      "n": "InternalTokenSource",
      "d": 2097233,
      "h": 176095756369,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(176095756369),
//--TRIMMABLE-BOUNDARY-START(171800789073),
    {
      "p": 95748097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133146083409,
        "f": 50331649
      },
      "n": "InnerStream",
      "d": 2097233,
      "h": 171800789073,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171800789073),
//--TRIMMABLE-BOUNDARY-START(90196410449),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124556148817,
        "f": 50364417
      },
      "n": "CanGetUnflushedBytes",
      "d": 2097233,
      "h": 90196410449,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90196410449),
//--TRIMMABLE-BOUNDARY-START(188980658257),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325952593,
        "f": 50364417
      },
      "n": "UnflushedBytes",
      "d": 2097233,
      "h": 188980658257,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(188980658257)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68721573969),
    {
      "r": 65537,
      "p": [
        {
          "n": "bytes",
          "p": 655361
        }
      ],
      "n": "Advance",
      "d": 2097233,
      "h": 68721573969,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68721573969),
//--TRIMMABLE-BOUNDARY-START(154620919889),
    {
      "r": $.$$.S.Memory$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetMemory",
      "d": 2097233,
      "h": 154620919889,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154620919889),
//--TRIMMABLE-BOUNDARY-START(163210854481),
    {
      "r": $.$$.S.Span$$($.$$.S.Byte).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetSpan",
      "d": 2097233,
      "h": 163210854481,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163210854481),
//--TRIMMABLE-BOUNDARY-START(73016541265),
    {
      "r": 65537,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361
        }
      ],
      "n": "AllocateMemory",
      "d": 2097233,
      "h": 73016541265,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73016541265),
//--TRIMMABLE-BOUNDARY-START(77311508561),
    {
      "r": 65617,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361
        }
      ],
      "n": "AllocateSegment",
      "d": 2097233,
      "h": 77311508561,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77311508561),
//--TRIMMABLE-BOUNDARY-START(158915887185),
    {
      "r": 655361,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361
        },
        {
          "n": "maxBufferSize",
          "p": 655361,
          "f": 65,
          "v": 2147483647
        }
      ],
      "n": "GetSegmentSize",
      "d": 2097233,
      "h": 158915887185,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158915887185),
//--TRIMMABLE-BOUNDARY-START(103081312337),
    {
      "r": 65617,
      "n": "CreateSegmentUnsynchronized",
      "d": 2097233,
      "h": 103081312337,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103081312337),
//--TRIMMABLE-BOUNDARY-START(184685690961),
    {
      "r": 65537,
      "p": [
        {
          "n": "segment",
          "p": 65617
        }
      ],
      "n": "ReturnSegmentUnsynchronized",
      "d": 2097233,
      "h": 184685690961,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(184685690961),
//--TRIMMABLE-BOUNDARY-START(85901443153),
    {
      "r": 65537,
      "n": "CancelPendingFlush",
      "d": 2097233,
      "h": 85901443153,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901443153),
//--TRIMMABLE-BOUNDARY-START(94491377745),
    {
      "r": 65537,
      "p": [
        {
          "n": "exception",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "Complete",
      "d": 2097233,
      "h": 94491377745,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94491377745),
//--TRIMMABLE-BOUNDARY-START(98786345041),
    {
      "r": 181338113,
      "p": [
        {
          "n": "exception",
          "p": 80805889,
          "f": 65
        }
      ],
      "n": "CompleteAsync",
      "d": 2097233,
      "h": 98786345041,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(98786345041),
//--TRIMMABLE-BOUNDARY-START(107376279633),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "FlushAsync",
      "d": 2097233,
      "h": 107376279633,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107376279633),
//--TRIMMABLE-BOUNDARY-START(193275625553),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult).$h,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "d": 2097233,
      "h": 193275625553,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193275625553),
//--TRIMMABLE-BOUNDARY-START(81606475857),
    {
      "r": 65537,
      "n": "Cancel",
      "d": 2097233,
      "h": 81606475857,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81606475857),
//--TRIMMABLE-BOUNDARY-START(111671246929),
    {
      "r": $.$$.STT.ValueTask$$($.$sipl.SIP.FlushResult).$h,
      "p": [
        {
          "n": "writeToStream",
          "p": 262145
        },
        {
          "n": "data",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "FlushAsyncInternal",
      "d": 2097233,
      "h": 111671246929,
      "f": 16781314,
      "a": [
        {
          "t": 124649473,
          "c": 8714584065,
          "a": [
            {
              "v": 132382721,
              "t": 188547073
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111671246929),
//--TRIMMABLE-BOUNDARY-START(115966214225),
    {
      "r": 65537,
      "p": [
        {
          "n": "writeToStream",
          "p": 262145
        }
      ],
      "n": "FlushInternal",
      "d": 2097233,
      "h": 115966214225,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115966214225)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(167505821777),
    {
      "t": 655361,
      "n": "InitialSegmentPoolSize",
      "d": 2097233,
      "h": 167505821777,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167505821777),
//--TRIMMABLE-BOUNDARY-START(180390723665),
    {
      "t": 655361,
      "n": "MaxSegmentPoolSize",
      "d": 2097233,
      "h": 180390723665,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180390723665),
//--TRIMMABLE-BOUNDARY-START(38656802897),
    {
      "t": 655361,
      "n": "_minimumBufferSize",
      "d": 2097233,
      "h": 38656802897,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656802897),
//--TRIMMABLE-BOUNDARY-START(12886999121),
    {
      "t": 65617,
      "n": "_head",
      "d": 2097233,
      "h": 12886999121,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886999121),
//--TRIMMABLE-BOUNDARY-START(47246737489),
    {
      "t": 65617,
      "n": "_tail",
      "d": 2097233,
      "h": 47246737489,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47246737489),
//--TRIMMABLE-BOUNDARY-START(55836672081),
    {
      "t": $.$$.S.Memory$$($.$$.S.Byte).$h,
      "n": "_tailMemory",
      "d": 2097233,
      "h": 55836672081,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55836672081),
//--TRIMMABLE-BOUNDARY-START(51541704785),
    {
      "t": 655361,
      "n": "_tailBytesBuffered",
      "d": 2097233,
      "h": 51541704785,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51541704785),
//--TRIMMABLE-BOUNDARY-START(8592031825),
    {
      "t": 917505,
      "n": "_bytesBuffered",
      "d": 2097233,
      "h": 8592031825,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592031825),
//--TRIMMABLE-BOUNDARY-START(42951770193),
    {
      "t": $.$sm.SB.MemoryPool$$($.$$.S.Byte).$h,
      "n": "_pool",
      "d": 2097233,
      "h": 42951770193,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42951770193),
//--TRIMMABLE-BOUNDARY-START(34361835601),
    {
      "t": 655361,
      "n": "_maxPooledBufferSize",
      "d": 2097233,
      "h": 34361835601,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361835601),
//--TRIMMABLE-BOUNDARY-START(17181966417),
    {
      "t": 170983425,
      "n": "_internalTokenSource",
      "d": 2097233,
      "h": 17181966417,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181966417),
//--TRIMMABLE-BOUNDARY-START(21476933713),
    {
      "t": 262145,
      "n": "_isCompleted",
      "d": 2097233,
      "h": 21476933713,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476933713),
//--TRIMMABLE-BOUNDARY-START(30066868305),
    {
      "t": 131073,
      "n": "_lockObject",
      "d": 2097233,
      "h": 30066868305,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066868305),
//--TRIMMABLE-BOUNDARY-START(4297064529),
    {
      "t": 131153,
      "n": "_bufferSegmentPool",
      "d": 2097233,
      "h": 4297064529,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297064529),
//--TRIMMABLE-BOUNDARY-START(25771901009),
    {
      "t": 262145,
      "n": "_leaveOpen",
      "d": 2097233,
      "h": 25771901009,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771901009)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(64426606673),
    {
      "p": [
        {
          "n": "writingStream",
          "p": 95748097
        },
        {
          "n": "options",
          "p": 2162769
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2097233,
      "h": 64426606673,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426606673)
  ],
  "h": 2097233
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.SB.IBufferWriter$$($.$$.S.Byte) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipelines.StreamPipeWriter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipelines${separator}StreamPipeWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097233)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading", "NetJs.System.Threading.ThreadPool"));
})();
//--TRIMMABLE-BOUNDARY-END(81)
