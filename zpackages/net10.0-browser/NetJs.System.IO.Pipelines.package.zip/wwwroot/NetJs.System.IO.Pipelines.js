
(function ($global, $, $$, $sc, $sm, $spu, $sr, $st, $sttp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Pipelines", 
    {"h":36842,"f":"System.IO.Pipelines","v":"1.0.35.0","a":[{"t":92274689,"c":4387241985,"a":[{"v":"System.IO.Pipelines.Tests, PublicKey=00240000048000009400000006020000002400005253413100040000010001004b86c4cb78549b34bab61a3b1800e23bfeb5b3ec390074041536a7e3cbd97f5f04cf0f857155a8928eaa29ebfd11cfbbad3ba70efea7bda3226c6a8d370a4cd303f714486b6ebc225985a638471e6ef571cc92a4613c00b8fa65d61ccee0cbe5f36330c9a01f4183559f1bef24cc2917c6d913e3a541333a1d05d9bed22b38cb","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Pipelines","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Pipelines","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sipl.System.IO.Pipelines.IDuplexPipe", ($self) => class IDuplexPipe
        {
            static $h = 495594;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1413098,"g":{"r":0,"d":0,"h":8590430186,"f":50331905},"n":"Input","o":"System$IO$Pipelines$IDuplexPipe$Input","d":495594,"h":4295462890,"f":2097409},{"p":1609706,"g":{"r":0,"d":0,"h":17180364778,"f":50331905},"n":"Output","o":"System$IO$Pipelines$IDuplexPipe$Output","d":495594,"h":12885397482,"f":2097409}],"h":495594}; }
            static get $fullName() { return `System.IO.Pipelines.IDuplexPipe`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeReader", ($self) => class PipeReader extends $.$$.System.Object
        {
            /*PipeReaderStream?*/ _stream = null;
            /*ValueTask<ReadResult> */ ReadAtLeastAsync(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                if (minimumSize < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(0/*ExceptionArgument.minimumSize*/);
                }
                return this.ReadAtLeastAsyncCore(minimumSize, cancellationToken);
            }
            /*ValueTask<ReadResult> *//*async*/  ReadAtLeastAsyncCore(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult), $.$sipl.System.IO.Pipelines.ReadResult, async () => 
                {
                    while(true)
                    {
                        /*ReadResult*/ let result = await this.ReadAsync(cancellationToken).ConfigureAwait(false);
                        /*ReadOnlySequence<byte>*/ let buffer = result.Buffer;
                        if (buffer.Length >= BigInt(minimumSize) || result.IsCompleted || result.IsCanceled)
                        {
                            return result;
                        }
                        this.AdvanceTo(buffer.Start, buffer.End);
                    }
                });
            }
            /*Stream */ AsStream(/*bool*/ leaveOpen)
            {
                if (this._stream === null)
                {
                    this._stream = new $.$sipl.System.IO.Pipelines.PipeReaderStream().$ctor$3(this, leaveOpen);
                }
                else if (leaveOpen)
                {
                    this._stream.LeaveOpen = leaveOpen;
                }
                return this._stream;
            }
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                try
                {
                    this.Complete(exception);
                    return new $.$$.System.Threading.Tasks.ValueTask();
                }
                catch(ex)
                {
                    return new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$$.System.Threading.Tasks.Task.FromException(ex));
                }
            }
            /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
            }
            static /*PipeReader */ Create(/*Stream*/ stream, /*StreamPipeReaderOptions?*/ readerOptions)
            {
                return new $.$sipl.System.IO.Pipelines.StreamPipeReader().$ctor$2(stream, readerOptions ?? $.$sipl.System.IO.Pipelines.StreamPipeReaderOptions.s_default);
            }
            static /*PipeReader */ Create$1(/*ReadOnlySequence<byte>*/ sequence)
            {
                return new $.$sipl.System.IO.Pipelines.SequencePipeReader().$ctor$2(sequence);
            }
            /*Task */ CopyToAsync$1(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return this.CopyToAsyncCore($.$sipl.System.IO.Pipelines.PipeWriter, destination, new ($.$$.System.Func$$$$$($.$sipl.System.IO.Pipelines.PipeWriter, $.$$.System.ReadOnlyMemory$$($.$$.System.Byte), $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)))().$ctor(this,  (/*destination*/ destination, /*memory*/ memory, /**/ cancellationToken) =>
                {
                    return destination.WriteAsync(memory, cancellationToken);
                }, {"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"destination","p":1609706},{"n":"memory","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121}],"n":"","d":1413098,"h":0,"f":17825794}), cancellationToken);
            }
            /*Task */ CopyToAsync(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return this.CopyToAsyncCore($.$$.System.IO.Stream, destination, new ($.$$.System.Func$$$$$($.$$.System.IO.Stream, $.$$.System.ReadOnlyMemory$$($.$$.System.Byte), $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)))().$ctor(this,  (/*destination*/ destination, /*memory*/ memory, /*cancellationToken*/ cancellationToken) =>
                {
                    /*ValueTask*/ let task = destination.WriteAsync$2(memory, cancellationToken);
                    if (task.IsCompletedSuccessfully)
                    {
                        task.GetAwaiter().GetResult();
                        return new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$6(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$3(false, false));
                    }
                    /*static ValueTask<FlushResult>*/ /*async*/  function Awaited(/*ValueTask*/ writeTask)
                    {
                        return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult), $.$sipl.System.IO.Pipelines.FlushResult, async () => 
                        {
                            await writeTask.ConfigureAwait(false);
                            return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$3(false, false);
                        });
                    }
                    return Awaited(task);
                }, {"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"destination","p":62193665},{"n":"memory","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121}],"n":"","d":1413098,"h":0,"f":17825794}), cancellationToken);
            }
            /*Task *//*async*/  CopyToAsyncCore(TStream, /*TStream*/ destination, /*Func<TStream, ReadOnlyMemory<byte>, CancellationToken, ValueTask<FlushResult>>*/ writeAsync, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    while(true)
                    {
                        /*ReadResult*/ let result = await this.ReadAsync(cancellationToken).ConfigureAwait(false);
                        /*ReadOnlySequence<byte>*/ let buffer = result.Buffer;
                        /*SequencePosition*/ let position = buffer.Start;
                        /*SequencePosition*/ let consumed = position;
                        try
                        {
                            if (result.IsCanceled)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                            }
                            /*ReadOnlyMemory<byte>*/ let memory;
                            while(buffer.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => position, ($v) => position = $v, null), $.$ref(() => memory, ($v) => memory = $v, $.$$.System.ReadOnlyMemory$$($.$$.System.Byte)), true))
                            {
                                if (memory.IsEmpty)
                                {
                                    consumed = position;
                                }
                                else 
                                {
                                    /*FlushResult*/ let flushResult = await writeAsync.Invoke(destination, memory, cancellationToken).ConfigureAwait(false);
                                    if (flushResult.IsCanceled)
                                    {
                                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                                    }
                                    consumed = position;
                                    if (flushResult.IsCompleted)
                                    {
                                        return;
                                    }
                                }
                            }
                            consumed = buffer.End;
                            if (result.IsCompleted)
                            {
                                break;
                            }
                        }
                        finally
                        {
                            {
                                this.AdvanceTo$1(consumed);
                            }
                        }
                    }
                });
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1413098;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"result","p":1740778,"f":2}],"n":"TryRead","d":1413098,"h":8591347690,"f":16777473},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","d":1413098,"h":12886314986,"f":16777473},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAtLeastAsync","d":1413098,"h":17181282282,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAtLeastAsyncCore","d":1413098,"h":21476249578,"f":16781444},{"r":65537,"p":[{"n":"consumed","p":1220103}],"n":"AdvanceTo","o":"@$1","d":1413098,"h":25771216874,"f":16777473},{"r":65537,"p":[{"n":"consumed","p":1220103},{"n":"examined","p":1220103}],"n":"AdvanceTo","d":1413098,"h":30066184170,"f":16777473},{"r":62193665,"p":[{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":"AsStream","d":1413098,"h":34361151466,"f":16777345},{"r":65537,"n":"CancelPendingRead","d":1413098,"h":38656118762,"f":16777473},{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":1413098,"h":42951086058,"f":16777473},{"r":135987201,"p":[{"n":"exception","p":47251457,"f":65}],"n":"CompleteAsync","d":1413098,"h":47246053354,"f":16777345},{"r":65537,"p":[{"n":"callback","p":$.$$.System.Action$$$($.$$.System.Exception, $.$$.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":1413098,"h":51541020650,"f":16777345,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"OnWriterCompleted has been deprecated and may not be invoked on all implementations of PipeReader.","t":1310721}]}]},{"r":1413098,"p":[{"n":"stream","p":62193665},{"n":"readerOptions","p":2068458,"f":65}],"n":"Create","d":1413098,"h":55835987946,"f":16777249},{"r":1413098,"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h}],"n":"Create","o":"@$1","d":1413098,"h":60130955242,"f":16777249},{"r":133169153,"p":[{"n":"destination","p":1609706},{"n":"cancellationToken","p":125829121,"f":65}],"n":"CopyToAsync","o":"@$1","d":1413098,"h":64425922538,"f":16777345},{"r":133169153,"p":[{"n":"destination","p":62193665},{"n":"cancellationToken","p":125829121,"f":65}],"n":"CopyToAsync","d":1413098,"h":68720889834,"f":16777345},{"r":133169153,"p":[{"n":"destination","p":(TStream) => TStream.$h},{"n":"writeAsync","p":(TStream) => $.$$.System.Func$$$$$(TStream, $.$$.System.ReadOnlyMemory$$($.$$.System.Byte), $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)).$h},{"n":"cancellationToken","p":125829121}],"g":["TStream"],"n":"CopyToAsyncCore","d":1413098,"h":73015857130,"f":16912386}],"l":[{"t":1478634,"n":"_stream","d":1413098,"h":4296380394,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1413098,"h":77310824426,"f":16777220}],"h":1413098}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeReader`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeScheduler", ($self) => class PipeScheduler extends $.$$.System.Object
        {
            /*ThreadPoolScheduler*/ static s_threadPoolScheduler = null;
            /*InlineScheduler*/ static s_inlineScheduler = null;
            static /*PipeScheduler */ get ThreadPool()
            {
                return $.$sipl.System.IO.Pipelines.PipeScheduler.s_threadPoolScheduler;
            }
            static /*PipeScheduler */ get Inline()
            {
                return $.$sipl.System.IO.Pipelines.PipeScheduler.s_inlineScheduler;
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                return this.Schedule(action, state);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_threadPoolScheduler = new $.$sipl.System.IO.Pipelines.ThreadPoolScheduler().$ctor$2();
                }
                {
                    this.s_inlineScheduler = new $.$sipl.System.IO.Pipelines.InlineScheduler().$ctor$2();
                }
            }
            static $h = 1544170;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1544170,"g":{"r":0,"d":0,"h":17181413354,"f":50331681},"n":"ThreadPool","d":1544170,"h":12886446058,"f":2097185},{"p":1544170,"g":{"r":0,"d":0,"h":25771347946,"f":50331681},"n":"Inline","d":1544170,"h":21476380650,"f":2097185}],"m":[{"r":65537,"p":[{"n":"action","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":1544170,"h":30066315242,"f":16777473},{"r":65537,"p":[{"n":"action","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":1544170,"h":34361282538,"f":16777352}],"l":[{"t":2265066,"n":"s_threadPoolScheduler","d":1544170,"h":4296511466,"f":4194338},{"t":561130,"n":"s_inlineScheduler","d":1544170,"h":8591478762,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":1544170,"h":38656249834,"f":16777220}],"h":1544170}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeScheduler`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeWriter", ($self) => class PipeWriter extends $.$$.System.Object
        {
            /*PipeWriterStream?*/ _stream = null;
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                try
                {
                    this.Complete(exception);
                    return new $.$$.System.Threading.Tasks.ValueTask();
                }
                catch(ex)
                {
                    return new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$$.System.Threading.Tasks.Task.FromException(ex));
                }
            }
            /*bool */ get CanGetUnflushedBytes()
            {
                return false;
            }
            /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
            }
            /*Stream */ AsStream(/*bool*/ leaveOpen)
            {
                if (this._stream === null)
                {
                    this._stream = new $.$sipl.System.IO.Pipelines.PipeWriterStream().$ctor$3(this, leaveOpen);
                }
                else if (leaveOpen)
                {
                    this._stream.LeaveOpen = leaveOpen;
                }
                return this._stream;
            }
            static /*PipeWriter */ Create(/*Stream*/ stream, /*StreamPipeWriterOptions?*/ writerOptions)
            {
                return new $.$sipl.System.IO.Pipelines.StreamPipeWriter().$ctor$2(stream, writerOptions ?? $.$sipl.System.IO.Pipelines.StreamPipeWriterOptions.s_default);
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                $.$sm.System.Buffers.BuffersExtensions.Write($.$$.System.Byte, this, source.Span);
                return this.FlushAsync(cancellationToken);
            }
            /*Task *//*async*/  CopyFromAsync(/*Stream*/ source, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    while(true)
                    {
                        /*Memory<byte>*/ let buffer = this.GetMemory(0);
                        /*int*/ let read = await source.ReadAsync$2(buffer, cancellationToken).ConfigureAwait(false);
                        if (read === 0)
                        {
                            break;
                        }
                        this.Advance(read);
                        /*FlushResult*/ let result = await this.FlushAsync(cancellationToken).ConfigureAwait(false);
                        if (result.IsCanceled)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                        }
                        if (result.IsCompleted)
                        {
                            break;
                        }
                    }
                });
            }
            /*long */ get UnflushedBytes()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateNotSupportedException_UnflushedBytes();
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.Advance(int)
            System$Buffers$IBufferWriter$$$Advance()
            {
                return this.Advance(...arguments);
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.GetMemory(int)
            System$Buffers$IBufferWriter$$$GetMemory()
            {
                return this.GetMemory(...arguments);
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.GetSpan(int)
            System$Buffers$IBufferWriter$$$GetSpan()
            {
                return this.GetSpan(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1609706;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771413482,"f":50331777},"n":"CanGetUnflushedBytes","d":1609706,"h":21476446186,"f":2097281},{"p":917505,"g":{"r":0,"d":0,"h":73016053738,"f":50331777},"n":"UnflushedBytes","d":1609706,"h":68721086442,"f":2097281}],"m":[{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":1609706,"h":8591544298,"f":16777473},{"r":135987201,"p":[{"n":"exception","p":47251457,"f":65}],"n":"CompleteAsync","d":1609706,"h":12886511594,"f":16777345},{"r":65537,"n":"CancelPendingFlush","d":1609706,"h":17181478890,"f":16777473},{"r":65537,"p":[{"n":"callback","p":$.$$.System.Action$$$($.$$.System.Exception, $.$$.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":1609706,"h":30066380778,"f":16777345,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"OnReaderCompleted has been deprecated and may not be invoked on all implementations of PipeWriter.","t":1310721}]}]},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"FlushAsync","d":1609706,"h":34361348074,"f":16777473},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":1609706,"h":38656315370,"f":16777473},{"r":$.$$.System.Memory$$($.$$.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":1609706,"h":42951282666,"f":16777473},{"r":$.$$.System.Span$$($.$$.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":1609706,"h":47246249962,"f":16777473},{"r":62193665,"p":[{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":"AsStream","d":1609706,"h":51541217258,"f":16777345},{"r":1609706,"p":[{"n":"stream","p":62193665},{"n":"writerOptions","p":2199530,"f":65}],"n":"Create","d":1609706,"h":55836184554,"f":16777249},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","d":1609706,"h":60131151850,"f":16777345},{"r":133169153,"p":[{"n":"source","p":62193665},{"n":"cancellationToken","p":125829121,"f":65}],"n":"CopyFromAsync","d":1609706,"h":64426119146,"f":16781456}],"l":[{"t":1675242,"n":"_stream","d":1609706,"h":4296577002,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1609706,"h":77311021034,"f":16777220}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h],"h":1609706}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte) ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeWriter`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.Pipe", ($self) => class Pipe extends $.$$.System.Object
        {
            static $_DefaultPipeReader;
            static get DefaultPipeReader()
            {
                let $cls = $.$sipl.System.IO.Pipelines.Pipe;
                return $cls.$_DefaultPipeReader ??= $asm.$ncls("$sipl.System.IO.Pipelines.Pipe.DefaultPipeReader", ($self) => class DefaultPipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
                {
                    /*Pipe*/ _pipe = null;
                    $ctor$2(/*Pipe*/ pipe)
                    {
                        super.$ctor$1();
                        {
                            this._pipe = pipe;
                        }
                        return this;
                    }
                    /*bool */ TryRead(/*out ReadResult*/ result)
                    {
                        return this._pipe.TryRead(result);
                    }
                    /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.ReadAsync(cancellationToken);
                    }
                    /*ValueTask<ReadResult> */ ReadAtLeastAsyncCore(/*int*/ minimumBytes, /*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.ReadAtLeastAsync(minimumBytes, cancellationToken);
                    }
                    /*void */ AdvanceTo$1(/*SequencePosition*/ consumed)
                    {
                        return this._pipe.AdvanceReader$2($.$ref(() => consumed, ));
                    }
                    /*void */ AdvanceTo(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
                    {
                        return this._pipe.AdvanceReader$1($.$ref(() => consumed, ), $.$ref(() => examined, ));
                    }
                    /*void */ CancelPendingRead()
                    {
                        return this._pipe.CancelPendingRead();
                    }
                    /*void */ Complete(/*Exception?*/ exception)
                    {
                        return this._pipe.CompleteReader(exception);
                    }
                    /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
                    {
                        return this._pipe.OnWriterCompleted(callback, state);
                    }
                    /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
                    {
                        return this._pipe.GetReadAsyncStatus();
                    }
                    /*ReadResult */ GetResult(/*short*/ token)
                    {
                        return this._pipe.GetReadAsyncResult();
                    }
                    /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
                    {
                        return this._pipe.OnReadAsyncCompleted(continuation, state, flags);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.GetStatus(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetStatus()
                    {
                        return this.GetStatus(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$OnCompleted()
                    {
                        return this.OnCompleted(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.GetResult(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetResult()
                    {
                        return this.GetResult(...arguments);
                    }
                    static $h = 692202;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1413098,"m":[{"r":262145,"p":[{"n":"result","p":1740778,"f":2}],"n":"TryRead","d":692202,"h":12885594090,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","d":692202,"h":17180561386,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumBytes","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAtLeastAsyncCore","d":692202,"h":21475528682,"f":16809988},{"r":65537,"p":[{"n":"consumed","p":1220103}],"n":"AdvanceTo","o":"@$1","d":692202,"h":25770495978,"f":16809985},{"r":65537,"p":[{"n":"consumed","p":1220103},{"n":"examined","p":1220103}],"n":"AdvanceTo","d":692202,"h":30065463274,"f":16809985},{"r":65537,"n":"CancelPendingRead","d":692202,"h":34360430570,"f":16809985},{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":692202,"h":38655397866,"f":16809985},{"r":65537,"p":[{"n":"callback","p":$.$$.System.Action$$$($.$$.System.Exception, $.$$.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":692202,"h":42950365162,"f":16809985},{"r":132907009,"p":[{"n":"token","p":524289}],"n":"GetStatus","d":692202,"h":47245332458,"f":16777217},{"r":1740778,"p":[{"n":"token","p":524289}],"n":"GetResult","d":692202,"h":51540299754,"f":16777217},{"r":65537,"p":[{"n":"continuation","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073},{"n":"token","p":524289},{"n":"flags","p":132841473}],"n":"OnCompleted","d":692202,"h":55835267050,"f":16777217}],"l":[{"t":626666,"n":"_pipe","d":692202,"h":4295659498,"f":4194306}],"c":[{"p":[{"n":"pipe","p":626666}],"n":".ctor","o":"$ctor$2","d":692202,"h":8590626794,"f":16777217}],"i":[$.$$.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.ReadResult).$h],"d":626666,"h":692202}; }
                    static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.ReadResult) ]; }
                    static get $fullName() { return `System.IO.Pipelines.Pipe.DefaultPipeReader`; }
                }, $cls, ($v) => $cls.$_DefaultPipeReader = $v);
            }
            static $_DefaultPipeWriter;
            static get DefaultPipeWriter()
            {
                let $cls = $.$sipl.System.IO.Pipelines.Pipe;
                return $cls.$_DefaultPipeWriter ??= $asm.$ncls("$sipl.System.IO.Pipelines.Pipe.DefaultPipeWriter", ($self) => class DefaultPipeWriter extends $.$sipl.System.IO.Pipelines.PipeWriter
                {
                    /*Pipe*/ _pipe = null;
                    $ctor$2(/*Pipe*/ pipe)
                    {
                        super.$ctor$1();
                        {
                            this._pipe = pipe;
                        }
                        return this;
                    }
                    /*void */ Complete(/*Exception?*/ exception)
                    {
                        return this._pipe.CompleteWriter(exception);
                    }
                    /*void */ CancelPendingFlush()
                    {
                        return this._pipe.CancelPendingFlush();
                    }
                    /*bool */ get CanGetUnflushedBytes()
                    {
                        return true;
                    }
                    /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
                    {
                        return this._pipe.OnReaderCompleted(callback, state);
                    }
                    /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.FlushAsync(cancellationToken);
                    }
                    /*void */ Advance(/*int*/ bytes)
                    {
                        return this._pipe.Advance(bytes);
                    }
                    /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
                    {
                        return this._pipe.GetMemory(sizeHint);
                    }
                    /*Span<byte> */ GetSpan(/*int*/ sizeHint)
                    {
                        return this._pipe.GetSpan(sizeHint);
                    }
                    /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
                    {
                        return this._pipe.GetFlushAsyncStatus();
                    }
                    /*FlushResult */ GetResult(/*short*/ token)
                    {
                        return this._pipe.GetFlushAsyncResult();
                    }
                    /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
                    {
                        return this._pipe.OnFlushAsyncCompleted(continuation, state, flags);
                    }
                    /*long */ get UnflushedBytes()
                    {
                        return this._pipe.GetUnflushedBytes();
                    }
                    /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.WriteAsync(source, cancellationToken);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.GetStatus(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetStatus()
                    {
                        return this.GetStatus(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$OnCompleted()
                    {
                        return this.OnCompleted(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.GetResult(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetResult()
                    {
                        return this.GetResult(...arguments);
                    }
                    static $h = 757738;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1609706,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770561514,"f":50364417},"n":"CanGetUnflushedBytes","d":757738,"h":21475594218,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":68720234474,"f":50364417},"n":"UnflushedBytes","d":757738,"h":64425267178,"f":2129921}],"m":[{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":757738,"h":12885659626,"f":16809985},{"r":65537,"n":"CancelPendingFlush","d":757738,"h":17180626922,"f":16809985},{"r":65537,"p":[{"n":"callback","p":$.$$.System.Action$$$($.$$.System.Exception, $.$$.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":757738,"h":30065528810,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"FlushAsync","d":757738,"h":34360496106,"f":16809985},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":757738,"h":38655463402,"f":16809985},{"r":$.$$.System.Memory$$($.$$.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":757738,"h":42950430698,"f":16809985},{"r":$.$$.System.Span$$($.$$.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":757738,"h":47245397994,"f":16809985},{"r":132907009,"p":[{"n":"token","p":524289}],"n":"GetStatus","d":757738,"h":51540365290,"f":16777217},{"r":430058,"p":[{"n":"token","p":524289}],"n":"GetResult","d":757738,"h":55835332586,"f":16777217},{"r":65537,"p":[{"n":"continuation","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073},{"n":"token","p":524289},{"n":"flags","p":132841473}],"n":"OnCompleted","d":757738,"h":60130299882,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","d":757738,"h":73015201770,"f":16809985}],"l":[{"t":626666,"n":"_pipe","d":757738,"h":4295725034,"f":4194306}],"c":[{"p":[{"n":"pipe","p":626666}],"n":".ctor","o":"$ctor$2","d":757738,"h":8590692330,"f":16777217}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h,$.$$.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.FlushResult).$h],"d":626666,"h":757738}; }
                    static get $b() { return $.$sipl.System.IO.Pipelines.PipeWriter; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte), $.$$.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.FlushResult) ]; }
                    static get $fullName() { return `System.IO.Pipelines.Pipe.DefaultPipeWriter`; }
                }, $cls, ($v) => $cls.$_DefaultPipeWriter = $v);
            }
            /*Action<object?>*/ static s_signalReaderAwaitable = null;
            /*Action<object?>*/ static s_signalWriterAwaitable = null;
            /*Action<object?>*/ static s_invokeCompletionCallbacks = null;
            /*ContextCallback*/ static s_executionContextRawCallback = null;
            /*SendOrPostCallback*/ static s_syncContextExecutionContextCallback = null;
            /*SendOrPostCallback*/ static s_syncContextExecuteWithoutExecutionContextCallback = null;
            /*Action<object?>*/ static s_scheduleWithExecutionContextCallback = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*DefaultPipeReader*/ _reader = null;
            /*DefaultPipeWriter*/ _writer = null;
            /*PipeOptions*/ _options = null;
            /*object*/ _sync = null;
            /*bool */ get UseSynchronizationContext()
            {
                return this._options.UseSynchronizationContext;
            }
            /*int */ get MinimumSegmentSize()
            {
                return this._options.MinimumSegmentSize;
            }
            /*long */ get PauseWriterThreshold()
            {
                return this._options.PauseWriterThreshold;
            }
            /*long */ get ResumeWriterThreshold()
            {
                return this._options.ResumeWriterThreshold;
            }
            /*PipeScheduler */ get ReaderScheduler()
            {
                return this._options.ReaderScheduler;
            }
            /*PipeScheduler */ get WriterScheduler()
            {
                return this._options.WriterScheduler;
            }
            /*object */ get SyncObj()
            {
                return this._sync;
            }
            /*long*/ _unconsumedBytes = 0n;
            /*long*/ _unflushedBytes = 0n;
            /*PipeAwaitable*/ _readerAwaitable;
            /*PipeAwaitable*/ _writerAwaitable;
            /*PipeCompletion*/ _writerCompletion;
            /*PipeCompletion*/ _readerCompletion;
            /*long*/ _lastExaminedIndex = -1n;
            /*BufferSegment?*/ _readHead = null;
            /*int*/ _readHeadIndex = 0;
            /*bool*/ _disposed = false;
            /*BufferSegment?*/ _readTail = null;
            /*int*/ _readTailIndex = 0;
            /*int*/ _minimumReadBytes = 0;
            /*BufferSegment?*/ _writingHead = null;
            /*Memory<byte>*/ _writingHeadMemory;
            /*int*/ _writingHeadBytesBuffered = 0;
            /*PipeOperationState*/ _operationState;
            /*long */ get Length()
            {
                return this._unconsumedBytes;
            }
            $ctor$1()
            {
                this.$ctor$2($.$sipl.System.IO.Pipelines.PipeOptions.Default);
                {
                }
                return this;
            }
            $ctor$2(/*PipeOptions*/ options)
            {
                super.$ctor();
                {
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$3(options.InitialSegmentPoolSize);
                    this._operationState = new $.$sipl.System.IO.Pipelines.PipeOperationState();
                    this._readerCompletion = new $.$sipl.System.IO.Pipelines.PipeCompletion();
                    this._writerCompletion = new $.$sipl.System.IO.Pipelines.PipeCompletion();
                    this._options = options;
                    this._readerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$3(false, this.UseSynchronizationContext);
                    this._writerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$3(true, this.UseSynchronizationContext);
                    this._reader = new $.$sipl.System.IO.Pipelines.Pipe.DefaultPipeReader().$ctor$2(this);
                    this._writer = new $.$sipl.System.IO.Pipelines.Pipe.DefaultPipeWriter().$ctor$2(this);
                }
                return this;
            }
            /*void */ ResetState()
            {
                this._readerCompletion.Reset();
                this._writerCompletion.Reset();
                this._readerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$3(false, this.UseSynchronizationContext);
                this._writerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$3(true, this.UseSynchronizationContext);
                this._readTailIndex = 0;
                this._readHeadIndex = 0;
                this._lastExaminedIndex = BigInt(-1);
                this._unflushedBytes = 0n;
                this._unconsumedBytes = 0n;
            }
            /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateWriteHeadIfNeeded(sizeHint);
                return this._writingHeadMemory;
            }
            /*Span<byte> */ GetSpan(/*int*/ sizeHint)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateWriteHeadIfNeeded(sizeHint);
                return this._writingHeadMemory.Span;
            }
            /*void */ AllocateWriteHeadIfNeeded(/*int*/ sizeHint)
            {
                if (!this._operationState.IsWritingActive || this._writingHeadMemory.Length === 0 || this._writingHeadMemory.Length < sizeHint)
                {
                    this.AllocateWriteHeadSynchronized(sizeHint);
                }
            }
            /*void */ AllocateWriteHeadSynchronized(/*int*/ sizeHint)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        this._operationState.BeginWrite();
                        if (this._writingHead === null)
                        {
                            /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                            this._writingHead = this._readHead = this._readTail = newSegment;
                            this._lastExaminedIndex = 0n;
                        }
                        else 
                        {
                            /*int*/ let bytesLeftInBuffer = this._writingHeadMemory.Length;
                            if (bytesLeftInBuffer === 0 || bytesLeftInBuffer < sizeHint)
                            {
                                if (this._writingHeadBytesBuffered > 0)
                                {
                                    this._writingHead.End += this._writingHeadBytesBuffered;
                                    this._writingHeadBytesBuffered = 0;
                                }
                                if (this._writingHead.Length === 0)
                                {
                                    this._writingHead.ResetMemory();
                                    this.RentMemory(this._writingHead, sizeHint);
                                }
                                else 
                                {
                                    /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                                    this._writingHead.SetNext(newSegment);
                                    this._writingHead = newSegment;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*BufferSegment */ AllocateSegment(/*int*/ sizeHint)
            {
                /*BufferSegment*/ let newSegment = this.CreateSegmentUnsynchronized();
                this.RentMemory(newSegment, sizeHint);
                return newSegment;
            }
            /*void */ RentMemory(/*BufferSegment*/ segment, /*int*/ sizeHint)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(segment.MemoryOwner === null, "segment.MemoryOwner is null");
                $.$$.System.Diagnostics.Debug.Assert$2(sizeHint >= 0, "sizeHint >= 0");
                /*MemoryPool<byte>?*/ let pool = null;
                /*int*/ let maxSize = -1;
                if (!this._options.IsDefaultSharedMemoryPool)
                {
                    pool = this._options.Pool;
                    maxSize = pool.MaxBufferSize;
                }
                if (sizeHint <= maxSize)
                {
                    segment.SetOwnedMemory(pool.Rent(this.GetSegmentSize(sizeHint, maxSize)));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(sizeHint, 2147483647);
                    segment.SetOwnedMemory$1($.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(sizeToRequest));
                }
                this._writingHeadMemory = segment.AvailableMemory;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$$.System.Math.Max$4(this.MinimumSegmentSize, sizeHint);
                /*int*/ let adjustedToMaximumSize = $.$$.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(segment !== this._readHead, "Returning _readHead segment that's in use!");
                $.$$.System.Diagnostics.Debug.Assert$2(segment !== this._readTail, "Returning _readTail segment that's in use!");
                $.$$.System.Diagnostics.Debug.Assert$2(segment !== this._writingHead, "Returning _writingHead segment that's in use!");
                if (this._bufferSegmentPool.Count < this._options.MaxSegmentPoolSize)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*bool */ CommitUnsynchronized()
            {
                this._operationState.EndWrite();
                if (this._unflushedBytes === 0n)
                {
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._writingHead !== null, "_writingHead != null");
                this._writingHead.End += this._writingHeadBytesBuffered;
                this._readTail = this._writingHead;
                this._readTailIndex = this._writingHead.End;
                /*long*/ let oldLength = this._unconsumedBytes;
                this._unconsumedBytes += this._unflushedBytes;
                /*bool*/ let resumeReader = true;
                if (this._unconsumedBytes < BigInt(this._minimumReadBytes))
                {
                    resumeReader = false;
                }
                else if (this.PauseWriterThreshold > 0n && oldLength < this.PauseWriterThreshold && this._unconsumedBytes >= this.PauseWriterThreshold && !this._readerCompletion.IsCompleted)
                {
                    this._writerAwaitable.SetUncompleted();
                }
                this._unflushedBytes = 0n;
                this._writingHeadBytesBuffered = 0;
                return resumeReader;
            }
            /*void */ Advance(/*int*/ bytes)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        if ((bytes >>> 0) > (this._writingHeadMemory.Length >>> 0))
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.bytes*/);
                        }
                        if (this._readerCompletion.IsCompleted)
                        {
                            return;
                        }
                        this.AdvanceCore(bytes);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*void */ AdvanceCore(/*int*/ bytesWritten)
            {
                this._unflushedBytes += BigInt(bytesWritten);
                this._writingHeadBytesBuffered += bytesWritten;
                this._writingHeadMemory = this._writingHeadMemory.Slice$1(bytesWritten);
            }
            /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3($.$sipl.System.IO.Pipelines.FlushResult, cancellationToken));
                }
                /*CompletionData*/ let completionData;
                /*ValueTask<FlushResult>*/ let result;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        this.PrepareFlushUnsynchronized($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => result, ($v) => result = $v, $.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)), cancellationToken);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
                return result;
            }
            /*void */ PrepareFlushUnsynchronized(/*out CompletionData*/ completionData, /*out ValueTask<FlushResult>*/ result, /*CancellationToken*/ cancellationToken)
            {
                /*var*/ let completeReader = this.CommitUnsynchronized();
                this._writerAwaitable.BeginOperation(cancellationToken, $.$sipl.System.IO.Pipelines.Pipe.s_signalWriterAwaitable, this);
                if (this._writerAwaitable.IsCompleted)
                {
                    /*FlushResult*/ let flushResult = new $.$sipl.System.IO.Pipelines.FlushResult();
                    this.GetFlushResult($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sipl.System.IO.Pipelines.FlushResult, () => flushResult, ($v) => flushResult = $v, null));
                    result.$v = new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$6(flushResult.Clone());
                }
                else 
                {
                    result.$v = new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$4(this._writer, 0);
                }
                if (completeReader)
                {
                    this._readerAwaitable.Complete(completionData);
                }
                else 
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._writerAwaitable.IsCompleted || this._readerAwaitable.IsCompleted, "_writerAwaitable.IsCompleted || _readerAwaitable.IsCompleted");
            }
            /*void */ CompleteWriter(/*Exception?*/ exception)
            {
                /*CompletionData*/ let completionData;
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                /*bool*/ let readerCompleted;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        this.CommitUnsynchronized();
                        completionCallbacks = this._writerCompletion.TryComplete(exception);
                        this._readerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        readerCompleted = this._readerCompletion.IsCompleted;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (readerCompleted)
                {
                    this.CompletePipe();
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.ReaderScheduler, completionCallbacks);
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ AdvanceReader$2(/*in SequencePosition*/ consumed)
            {
                this.AdvanceReader$1(consumed, consumed);
            }
            /*void */ AdvanceReader$1(/*in SequencePosition*/ consumed, /*in SequencePosition*/ examined)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                this.AdvanceReader($.$cast(consumed.$v.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), consumed.$v.GetInteger(), $.$cast(examined.$v.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), examined.$v.GetInteger());
            }
            /*void */ AdvanceReader(/*BufferSegment?*/ consumedSegment, /*int*/ consumedIndex, /*BufferSegment?*/ examinedSegment, /*int*/ examinedIndex)
            {
                if (consumedSegment !== null && examinedSegment !== null && $.$sipl.System.IO.Pipelines.BufferSegment.GetLength$1(consumedSegment, consumedIndex, examinedSegment, examinedIndex) < 0n)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition();
                }
                /*BufferSegment?*/ let returnStart = null;
                /*BufferSegment?*/ let returnEnd = null;
                /*CompletionData*/ let completionData = new $.$sipl.System.IO.Pipelines.CompletionData();
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        /*var*/ let examinedEverything = false;
                        if (examinedSegment === this._readTail)
                        {
                            examinedEverything = examinedIndex === this._readTailIndex;
                        }
                        if (examinedSegment !== null && this._lastExaminedIndex >= 0n)
                        {
                            /*long*/ let examinedBytes = $.$sipl.System.IO.Pipelines.BufferSegment.GetLength(this._lastExaminedIndex, examinedSegment, examinedIndex);
                            /*long*/ let oldLength = this._unconsumedBytes;
                            this._unconsumedBytes -= examinedBytes;
                            this._lastExaminedIndex = examinedSegment.RunningIndex + BigInt(examinedIndex);
                            $.$$.System.Diagnostics.Debug.Assert$2(this._unconsumedBytes >= 0n, "Length has gone negative");
                            $.$$.System.Diagnostics.Debug.Assert$2(this.ResumeWriterThreshold >= 1n, "ResumeWriterThreshold is less than 1");
                            if (oldLength >= this.ResumeWriterThreshold && this._unconsumedBytes < this.ResumeWriterThreshold)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(examinedBytes > 0n, "examinedBytes > 0");
                                this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                            }
                        }
                        if (consumedSegment !== null)
                        {
                            if (this._readHead === null)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AdvanceToInvalidCursor();
                                return;
                            }
                            returnStart = this._readHead;
                            returnEnd = consumedSegment;
                            /*void*/  function MoveReturnEndToNextBlock()
                            {
                                /*BufferSegment?*/ let nextBlock = returnEnd.NextSegment;
                                if (this._readTail === returnEnd)
                                {
                                    this._readTail = nextBlock;
                                    this._readTailIndex = 0;
                                }
                                this._readHead = nextBlock;
                                this._readHeadIndex = 0;
                                returnEnd = nextBlock;
                            }
                            if (consumedIndex === returnEnd.Length)
                            {
                                if (this._writingHead !== returnEnd)
                                {
                                    MoveReturnEndToNextBlock.call(this);
                                }
                                else if (this._writingHeadBytesBuffered === 0 && !this._operationState.IsWritingActive)
                                {
                                    this._writingHead = null;
                                    this._writingHeadMemory = new ($.$$.System.Memory$$($.$$.System.Byte))();
                                    MoveReturnEndToNextBlock.call(this);
                                }
                                else 
                                {
                                    this._readHead = consumedSegment;
                                    this._readHeadIndex = consumedIndex;
                                }
                            }
                            else 
                            {
                                this._readHead = consumedSegment;
                                this._readHeadIndex = consumedIndex;
                            }
                        }
                        if (examinedEverything && !this._writerCompletion.IsCompleted)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this._writerAwaitable.IsCompleted, "PipeWriter.FlushAsync isn't completed and will deadlock");
                            this._readerAwaitable.SetUncompleted();
                        }
                        while(returnStart !== null && returnStart !== returnEnd)
                        {
                            /*BufferSegment?*/ let next = returnStart.NextSegment;
                            returnStart.Reset();
                            this.ReturnSegmentUnsynchronized(returnStart);
                            returnStart = next;
                        }
                        this._operationState.EndRead();
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ CompleteReader(/*Exception?*/ exception)
            {
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                /*CompletionData*/ let completionData;
                /*bool*/ let writerCompleted;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        if (this._operationState.IsReadingActive)
                        {
                            this._operationState.EndRead();
                        }
                        completionCallbacks = this._readerCompletion.TryComplete(exception);
                        this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        writerCompleted = this._writerCompletion.IsCompleted;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (writerCompleted)
                {
                    this.CompletePipe();
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.WriterScheduler, completionCallbacks);
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                if (callback === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.callback*/);
                }
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        completionCallbacks = this._writerCompletion.AddCallback(callback, state);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.ReaderScheduler, completionCallbacks);
                }
            }
            /*void */ CancelPendingRead()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        this._readerAwaitable.Cancel($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ CancelPendingFlush()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        this._writerAwaitable.Cancel($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                if (callback === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.callback*/);
                }
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        completionCallbacks = this._readerCompletion.AddCallback(callback, state);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.WriterScheduler, completionCallbacks);
                }
            }
            /*ValueTask<ReadResult> */ ReadAtLeastAsync(/*int*/ minimumBytes, /*CancellationToken*/ token)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                if (token.IsCancellationRequested)
                {
                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3($.$sipl.System.IO.Pipelines.ReadResult, token));
                }
                /*CompletionData*/ let completionData = new $.$sipl.System.IO.Pipelines.CompletionData();
                /*ValueTask<ReadResult>*/ let result;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        if (this._readerAwaitable.IsCompleted)
                        {
                            /*ReadResult*/ let readResult;
                            this.GetReadResult($.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                            if (this._unconsumedBytes >= BigInt(minimumBytes) || readResult.IsCanceled || readResult.IsCompleted)
                            {
                                return new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$6(readResult);
                            }
                            this._readerAwaitable.SetUncompleted();
                            this._operationState.EndRead();
                            this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        }
                        if (!this._writerAwaitable.IsCompleted)
                        {
                            this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        }
                        this._minimumReadBytes = minimumBytes;
                        result = new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$4(this._reader, 0);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, undefined, $.$sipl.System.IO.Pipelines.CompletionData));
                return result;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ token)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                if (token.IsCancellationRequested)
                {
                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3($.$sipl.System.IO.Pipelines.ReadResult, token));
                }
                /*ValueTask<ReadResult>*/ let result;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        if (this._readerAwaitable.IsCompleted)
                        {
                            /*ReadResult*/ let readResult;
                            this.GetReadResult($.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                            result = new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$6(readResult);
                        }
                        else 
                        {
                            result = new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$4(this._reader, 0);
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                return result;
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        if (this._readerCompletion.IsCompleted)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                        }
                        if (this._unconsumedBytes > 0n || this._readerAwaitable.IsCompleted)
                        {
                            this.GetReadResult(result);
                            return true;
                        }
                        if (this._readerAwaitable.IsRunning)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                        }
                        this._operationState.BeginReadTentative();
                        result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                        return false;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            static /*void */ ScheduleCallbacks(/*PipeScheduler*/ scheduler, /*PipeCompletionCallbacks*/ completionCallbacks)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(completionCallbacks !== null, "completionCallbacks != null");
                scheduler.UnsafeSchedule($.$sipl.System.IO.Pipelines.Pipe.s_invokeCompletionCallbacks, completionCallbacks);
            }
            static /*void */ TrySchedule(/*PipeScheduler*/ scheduler, /*in CompletionData*/ completionData)
            {
                /*Action<object?>*/ let completion = completionData.$v.Completion;
                if (completion === null)
                {
                    return;
                }
                if (completionData.$v.SynchronizationContext === null && completionData.$v.ExecutionContext === null)
                {
                    scheduler.UnsafeSchedule(completion, completionData.$v.CompletionState);
                }
                else 
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleWithContext(scheduler, completionData);
                }
            }
            static /*void */ ScheduleWithContext(/*PipeScheduler*/ scheduler, /*in CompletionData*/ completionData)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(completionData.$v.SynchronizationContext !== null || completionData.$v.ExecutionContext !== null, "completionData.SynchronizationContext != null || completionData.ExecutionContext != null");
                if (completionData.$v.SynchronizationContext === null)
                {
                    scheduler.UnsafeSchedule($.$sipl.System.IO.Pipelines.Pipe.s_scheduleWithExecutionContextCallback, completionData.$v);
                }
                else 
                {
                    if (completionData.$v.ExecutionContext === null)
                    {
                        completionData.$v.SynchronizationContext.Post($.$sipl.System.IO.Pipelines.Pipe.s_syncContextExecuteWithoutExecutionContextCallback, completionData.$v);
                    }
                    else 
                    {
                        completionData.$v.SynchronizationContext.Post($.$sipl.System.IO.Pipelines.Pipe.s_syncContextExecutionContextCallback, completionData.$v);
                    }
                }
            }
            static /*void */ ExecuteWithoutExecutionContext(/*object*/ state)
            {
                /*CompletionData*/ let completionData = $.$cast(state, $.$sipl.System.IO.Pipelines.CompletionData);
                completionData.Completion.Invoke(completionData.CompletionState);
            }
            static /*void */ ExecuteWithExecutionContext(/*object*/ state)
            {
                /*CompletionData*/ let completionData = $.$cast(state, $.$sipl.System.IO.Pipelines.CompletionData);
                $.$$.System.Diagnostics.Debug.Assert$2(completionData.ExecutionContext !== null, "completionData.ExecutionContext != null");
                $.$$.System.Threading.ExecutionContext.Run(completionData.ExecutionContext, $.$sipl.System.IO.Pipelines.Pipe.s_executionContextRawCallback, state);
            }
            /*void */ CompletePipe()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        this._disposed = true;
                        /*BufferSegment?*/ let segment = this._readHead ?? this._readTail;
                        while(segment !== null)
                        {
                            /*BufferSegment*/ let returnSegment = segment;
                            segment = segment.NextSegment;
                            returnSegment.Reset();
                        }
                        this._writingHead = null;
                        this._writingHeadMemory = new ($.$$.System.Memory$$($.$$.System.Byte))();
                        this._readHead = null;
                        this._readTail = null;
                        this._lastExaminedIndex = BigInt(-1);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*ValueTaskSourceStatus */ GetReadAsyncStatus()
            {
                if (this._readerAwaitable.IsCompleted)
                {
                    if (this._writerCompletion.IsFaulted)
                    {
                        return 2/*ValueTaskSourceStatus.Faulted*/;
                    }
                    return 1/*ValueTaskSourceStatus.Succeeded*/;
                }
                return 0/*ValueTaskSourceStatus.Pending*/;
            }
            /*void */ OnReadAsyncCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                /*CompletionData*/ let completionData;
                /*bool*/ let doubleCompletion;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        this._readerAwaitable.OnCompleted(continuation, state, flags, $.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => doubleCompletion, ($v) => doubleCompletion = $v, $.$$.System.Boolean));
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (doubleCompletion)
                {
                    this.Writer.Complete($.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation());
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*ReadResult */ GetReadAsyncResult()
            {
                /*ReadResult*/ let result;
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = new $.$$.System.Threading.CancellationTokenRegistration();
                /*CancellationToken*/ let cancellationToken = new $.$$.System.Threading.CancellationToken();
                try
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                        {
                            if (!this._readerAwaitable.IsCompleted)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_GetResultNotCompleted();
                            }
                            cancellationTokenRegistration = this._readerAwaitable.ReleaseCancellationTokenRegistration($.$ref(() => cancellationToken, ($v) => cancellationToken = $v, $.$$.System.Threading.CancellationToken));
                            this.GetReadResult($.$ref(() => result, ($v) => result = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                    }
                }
                finally
                {
                    {
                        cancellationTokenRegistration.Dispose();
                    }
                }
                if (result.IsCanceled)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                }
                return result;
            }
            /*void */ GetReadResult(/*out ReadResult*/ result)
            {
                /*bool*/ let isCompleted = this._writerCompletion.IsCompletedOrThrow();
                /*bool*/ let isCanceled = this._readerAwaitable.ObserveCancellation();
                /*BufferSegment?*/ let head = this._readHead;
                if (head !== null)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._readTail !== null, "_readTail != null");
                    /*var*/ let readOnlySequence = new ($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte))().$ctor$7(head, this._readHeadIndex, this._readTail, this._readTailIndex);
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$3(readOnlySequence, isCanceled, isCompleted);
                }
                else 
                {
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$3(new ($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte))(), isCanceled, isCompleted);
                }
                if (isCanceled)
                {
                    this._operationState.BeginReadTentative();
                }
                else 
                {
                    this._operationState.BeginRead();
                }
                this._minimumReadBytes = 0;
            }
            /*ValueTaskSourceStatus */ GetFlushAsyncStatus()
            {
                if (this._writerAwaitable.IsCompleted)
                {
                    if (this._readerCompletion.IsFaulted)
                    {
                        return 2/*ValueTaskSourceStatus.Faulted*/;
                    }
                    return 1/*ValueTaskSourceStatus.Succeeded*/;
                }
                return 0/*ValueTaskSourceStatus.Pending*/;
            }
            /*FlushResult */ GetFlushAsyncResult()
            {
                /*FlushResult*/ let result = new $.$sipl.System.IO.Pipelines.FlushResult();
                /*CancellationToken*/ let cancellationToken = new $.$$.System.Threading.CancellationToken();
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = new $.$$.System.Threading.CancellationTokenRegistration();
                try
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                        {
                            if (!this._writerAwaitable.IsCompleted)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_GetResultNotCompleted();
                            }
                            this.GetFlushResult($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sipl.System.IO.Pipelines.FlushResult, () => result, ($v) => result = $v, null));
                            cancellationTokenRegistration = this._writerAwaitable.ReleaseCancellationTokenRegistration($.$ref(() => cancellationToken, ($v) => cancellationToken = $v, $.$$.System.Threading.CancellationToken));
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                    }
                }
                finally
                {
                    {
                        cancellationTokenRegistration.Dispose();
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                }
                return result;
            }
            /*long */ GetUnflushedBytes()
            {
                return this._unflushedBytes;
            }
            /*void */ GetFlushResult(/*ref FlushResult*/ result)
            {
                if (this._writerAwaitable.ObserveCancellation())
                {
                    result.$v._resultFlags |= 1/*ResultFlags.Canceled*/;
                }
                if (this._readerCompletion.IsCompletedOrThrow())
                {
                    result.$v._resultFlags |= 2/*ResultFlags.Completed*/;
                }
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (this._readerCompletion.IsCompletedOrThrow())
                {
                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$6(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$3(false, true));
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3($.$sipl.System.IO.Pipelines.FlushResult, cancellationToken));
                }
                /*CompletionData*/ let completionData;
                /*ValueTask<FlushResult>*/ let result;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        this.AllocateWriteHeadIfNeeded(0);
                        if (source.Length <= this._writingHeadMemory.Length)
                        {
                            source.CopyTo(this._writingHeadMemory);
                            this.AdvanceCore(source.Length);
                        }
                        else 
                        {
                            this.WriteMultiSegment(source.Span);
                        }
                        this.PrepareFlushUnsynchronized($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => result, ($v) => result = $v, $.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)), cancellationToken);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
                return result;
            }
            /*void */ WriteMultiSegment(/*ReadOnlySpan<byte>*/ source)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._writingHead !== null, "_writingHead != null");
                /*Span<byte>*/ let destination = this._writingHeadMemory.Span;
                while(true)
                {
                    /*int*/ let writable = $.$$.System.Math.Min$4(destination.Length, source.Length);
                    source.Slice(0, writable).CopyTo(destination);
                    source = source.Slice$1(writable);
                    this.AdvanceCore(writable);
                    if (source.Length === 0)
                    {
                        break;
                    }
                    this._writingHead.End += this._writingHeadBytesBuffered;
                    this._writingHeadBytesBuffered = 0;
                    /*BufferSegment*/ let newSegment = this.AllocateSegment(0);
                    this._writingHead.SetNext(newSegment);
                    this._writingHead = newSegment;
                    destination = this._writingHeadMemory.Span;
                }
            }
            /*void */ OnFlushAsyncCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                /*CompletionData*/ let completionData;
                /*bool*/ let doubleCompletion;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        this._writerAwaitable.OnCompleted(continuation, state, flags, $.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => doubleCompletion, ($v) => doubleCompletion = $v, $.$$.System.Boolean));
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (doubleCompletion)
                {
                    this.Reader.Complete($.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation());
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ ReaderCancellationRequested()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        this._readerAwaitable.CancellationTokenFired($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ WriterCancellationRequested()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        this._writerAwaitable.CancellationTokenFired($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*PipeReader */ get Reader()
            {
                return this._reader;
            }
            /*PipeWriter */ get Writer()
            {
                return this._writer;
            }
            /*void */ Reset()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncObj)
                    {
                        if (!this._disposed)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_ResetIncompleteReaderWriter();
                        }
                        this._disposed = false;
                        this.ResetState();
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
                this._sync = new $.$$.System.Object().$ctor();
                this._readerAwaitable = $.$default($.$sipl.System.IO.Pipelines.PipeAwaitable);
                this._writerAwaitable = $.$default($.$sipl.System.IO.Pipelines.PipeAwaitable);
                this._writerCompletion = $.$default($.$sipl.System.IO.Pipelines.PipeCompletion);
                this._readerCompletion = $.$default($.$sipl.System.IO.Pipelines.PipeCompletion);
                this._writingHeadMemory = $.$default($.$$.System.Memory$$($.$$.System.Byte));
                this._operationState = $.$default($.$sipl.System.IO.Pipelines.PipeOperationState);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_signalReaderAwaitable = new ($.$$.System.Action$$($.$$.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.Pipe)).ReaderCancellationRequested();
                    }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":626666,"h":0,"f":17825794});
                }
                {
                    this.s_signalWriterAwaitable = new ($.$$.System.Action$$($.$$.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.Pipe)).WriterCancellationRequested();
                    }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":626666,"h":0,"f":17825794});
                }
                {
                    this.s_invokeCompletionCallbacks = new ($.$$.System.Action$$($.$$.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.PipeCompletionCallbacks)).Execute();
                    }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":626666,"h":0,"f":17825794});
                }
                {
                    this.s_executionContextRawCallback = new $.$$.System.Threading.ContextCallback().$ctor($.$sipl.System.IO.Pipelines.Pipe, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithoutExecutionContext);
                }
                {
                    this.s_syncContextExecutionContextCallback = new $.$$.System.Threading.SendOrPostCallback().$ctor($.$sipl.System.IO.Pipelines.Pipe, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithExecutionContext);
                }
                {
                    this.s_syncContextExecuteWithoutExecutionContextCallback = new $.$$.System.Threading.SendOrPostCallback().$ctor($.$sipl.System.IO.Pipelines.Pipe, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithoutExecutionContext);
                }
                {
                    this.s_scheduleWithExecutionContextCallback = new ($.$$.System.Action$$($.$$.System.Object))().$ctor($.$sipl.System.IO.Pipelines.Pipe, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithExecutionContext);
                }
            }
            static $h = 626666;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":68720103402,"f":50331650},"n":"UseSynchronizationContext","d":626666,"h":64425136106,"f":2097154},{"p":655361,"g":{"r":0,"d":0,"h":77310037994,"f":50331650},"n":"MinimumSegmentSize","d":626666,"h":73015070698,"f":2097154},{"p":917505,"g":{"r":0,"d":0,"h":85899972586,"f":50331650},"n":"PauseWriterThreshold","d":626666,"h":81605005290,"f":2097154},{"p":917505,"g":{"r":0,"d":0,"h":94489907178,"f":50331650},"n":"ResumeWriterThreshold","d":626666,"h":90194939882,"f":2097154},{"p":1544170,"g":{"r":0,"d":0,"h":103079841770,"f":50331650},"n":"ReaderScheduler","d":626666,"h":98784874474,"f":2097154},{"p":1544170,"g":{"r":0,"d":0,"h":111669776362,"f":50331650},"n":"WriterScheduler","d":626666,"h":107374809066,"f":2097154},{"p":131073,"g":{"r":0,"d":0,"h":120259710954,"f":50331650},"n":"SyncObj","d":626666,"h":115964743658,"f":2097154},{"p":917505,"g":{"r":0,"d":0,"h":201864089578,"f":50331656},"n":"Length","d":626666,"h":197569122282,"f":2097160},{"p":1413098,"g":{"r":0,"d":0,"h":416612454378,"f":50331649},"n":"Reader","d":626666,"h":412317487082,"f":2097153},{"p":1609706,"g":{"r":0,"d":0,"h":425202388970,"f":50331649},"n":"Writer","d":626666,"h":420907421674,"f":2097153}],"m":[{"r":65537,"n":"ResetState","d":626666,"h":214748991466,"f":16777218},{"r":$.$$.System.Memory$$($.$$.System.Byte).$h,"p":[{"n":"sizeHint","p":655361}],"n":"GetMemory","d":626666,"h":219043958762,"f":16777224},{"r":$.$$.System.Span$$($.$$.System.Byte).$h,"p":[{"n":"sizeHint","p":655361}],"n":"GetSpan","d":626666,"h":223338926058,"f":16777224},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateWriteHeadIfNeeded","d":626666,"h":227633893354,"f":16777218},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateWriteHeadSynchronized","d":626666,"h":231928860650,"f":16777218},{"r":102378,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateSegment","d":626666,"h":236223827946,"f":16777218},{"r":65537,"p":[{"n":"segment","p":102378},{"n":"sizeHint","p":655361}],"n":"RentMemory","d":626666,"h":240518795242,"f":16777218},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361,"f":65,"v":2147483647}],"n":"GetSegmentSize","d":626666,"h":244813762538,"f":16777218},{"r":102378,"n":"CreateSegmentUnsynchronized","d":626666,"h":249108729834,"f":16777218},{"r":65537,"p":[{"n":"segment","p":102378}],"n":"ReturnSegmentUnsynchronized","d":626666,"h":253403697130,"f":16777218},{"r":262145,"n":"CommitUnsynchronized","d":626666,"h":257698664426,"f":16777224},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":626666,"h":261993631722,"f":16777224},{"r":65537,"p":[{"n":"bytesWritten","p":655361}],"n":"AdvanceCore","d":626666,"h":266288599018,"f":16777218},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125829121}],"n":"FlushAsync","d":626666,"h":270583566314,"f":16777224},{"r":65537,"p":[{"n":"completionData","p":298986,"f":2},{"n":"result","p":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"f":2},{"n":"cancellationToken","p":125829121}],"n":"PrepareFlushUnsynchronized","d":626666,"h":274878533610,"f":16777218},{"r":65537,"p":[{"n":"exception","p":47251457}],"n":"CompleteWriter","d":626666,"h":279173500906,"f":16777224},{"r":65537,"p":[{"n":"consumed","p":1220103,"f":8}],"n":"AdvanceReader","o":"@$2","d":626666,"h":283468468202,"f":16777224},{"r":65537,"p":[{"n":"consumed","p":1220103,"f":8},{"n":"examined","p":1220103,"f":8}],"n":"AdvanceReader","o":"@$1","d":626666,"h":287763435498,"f":16777224},{"r":65537,"p":[{"n":"consumedSegment","p":102378},{"n":"consumedIndex","p":655361},{"n":"examinedSegment","p":102378},{"n":"examinedIndex","p":655361}],"n":"AdvanceReader","d":626666,"h":292058402794,"f":16777218},{"r":65537,"p":[{"n":"exception","p":47251457}],"n":"CompleteReader","d":626666,"h":296353370090,"f":16777224},{"r":65537,"p":[{"n":"callback","p":$.$$.System.Action$$$($.$$.System.Exception, $.$$.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":626666,"h":300648337386,"f":16777224},{"r":65537,"n":"CancelPendingRead","d":626666,"h":304943304682,"f":16777224},{"r":65537,"n":"CancelPendingFlush","d":626666,"h":309238271978,"f":16777224},{"r":65537,"p":[{"n":"callback","p":$.$$.System.Action$$$($.$$.System.Exception, $.$$.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":626666,"h":313533239274,"f":16777224},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumBytes","p":655361},{"n":"token","p":125829121}],"n":"ReadAtLeastAsync","d":626666,"h":317828206570,"f":16777224},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"token","p":125829121}],"n":"ReadAsync","d":626666,"h":322123173866,"f":16777224},{"r":262145,"p":[{"n":"result","p":1740778,"f":2}],"n":"TryRead","d":626666,"h":326418141162,"f":16777224},{"r":65537,"p":[{"n":"scheduler","p":1544170},{"n":"completionCallbacks","p":1150954}],"n":"ScheduleCallbacks","d":626666,"h":330713108458,"f":16777250},{"r":65537,"p":[{"n":"scheduler","p":1544170},{"n":"completionData","p":298986,"f":8}],"n":"TrySchedule","d":626666,"h":335008075754,"f":16777250},{"r":65537,"p":[{"n":"scheduler","p":1544170},{"n":"completionData","p":298986,"f":8}],"n":"ScheduleWithContext","d":626666,"h":339303043050,"f":16777250},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ExecuteWithoutExecutionContext","d":626666,"h":343598010346,"f":16777250},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ExecuteWithExecutionContext","d":626666,"h":347892977642,"f":16777250},{"r":65537,"n":"CompletePipe","d":626666,"h":352187944938,"f":16777218},{"r":132907009,"n":"GetReadAsyncStatus","d":626666,"h":356482912234,"f":16777224},{"r":65537,"p":[{"n":"continuation","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132841473}],"n":"OnReadAsyncCompleted","d":626666,"h":360777879530,"f":16777224},{"r":1740778,"n":"GetReadAsyncResult","d":626666,"h":365072846826,"f":16777224},{"r":65537,"p":[{"n":"result","p":1740778,"f":2}],"n":"GetReadResult","d":626666,"h":369367814122,"f":16777218},{"r":132907009,"n":"GetFlushAsyncStatus","d":626666,"h":373662781418,"f":16777224},{"r":430058,"n":"GetFlushAsyncResult","d":626666,"h":377957748714,"f":16777224},{"r":917505,"n":"GetUnflushedBytes","d":626666,"h":382252716010,"f":16777224},{"r":65537,"p":[{"n":"result","p":430058,"f":4}],"n":"GetFlushResult","d":626666,"h":386547683306,"f":16777218},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121}],"n":"WriteAsync","d":626666,"h":390842650602,"f":16777224},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"WriteMultiSegment","d":626666,"h":395137617898,"f":16777218},{"r":65537,"p":[{"n":"continuation","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132841473}],"n":"OnFlushAsyncCompleted","d":626666,"h":399432585194,"f":16777224},{"r":65537,"n":"ReaderCancellationRequested","d":626666,"h":403727552490,"f":16777218},{"r":65537,"n":"WriterCancellationRequested","d":626666,"h":408022519786,"f":16777218},{"r":65537,"n":"Reset","d":626666,"h":429497356266,"f":16777217}],"l":[{"t":$.$$.System.Action$$($.$$.System.Object).$h,"n":"s_signalReaderAwaitable","d":626666,"h":12885528554,"f":4194338},{"t":$.$$.System.Action$$($.$$.System.Object).$h,"n":"s_signalWriterAwaitable","d":626666,"h":17180495850,"f":4194338},{"t":$.$$.System.Action$$($.$$.System.Object).$h,"n":"s_invokeCompletionCallbacks","d":626666,"h":21475463146,"f":4194338},{"t":126484481,"n":"s_executionContextRawCallback","d":626666,"h":25770430442,"f":4194338},{"t":130744321,"n":"s_syncContextExecutionContextCallback","d":626666,"h":30065397738,"f":4194338},{"t":130744321,"n":"s_syncContextExecuteWithoutExecutionContextCallback","d":626666,"h":34360365034,"f":4194338},{"t":$.$$.System.Action$$($.$$.System.Object).$h,"n":"s_scheduleWithExecutionContextCallback","d":626666,"h":38655332330,"f":4194338},{"t":167914,"n":"_bufferSegmentPool","d":626666,"h":42950299626,"f":4194306},{"t":692202,"n":"_reader","d":626666,"h":47245266922,"f":4194306},{"t":757738,"n":"_writer","d":626666,"h":51540234218,"f":4194306},{"t":1347562,"n":"_options","d":626666,"h":55835201514,"f":4194306},{"t":131073,"n":"_sync","d":626666,"h":60130168810,"f":4194306},{"t":917505,"n":"_unconsumedBytes","d":626666,"h":124554678250,"f":4194306},{"t":917505,"n":"_unflushedBytes","d":626666,"h":128849645546,"f":4194306},{"t":823274,"n":"_readerAwaitable","d":626666,"h":133144612842,"f":4194306},{"t":823274,"n":"_writerAwaitable","d":626666,"h":137439580138,"f":4194306},{"t":1019882,"n":"_writerCompletion","d":626666,"h":141734547434,"f":4194306},{"t":1019882,"n":"_readerCompletion","d":626666,"h":146029514730,"f":4194306},{"t":917505,"n":"_lastExaminedIndex","d":626666,"h":150324482026,"f":4194306},{"t":102378,"n":"_readHead","d":626666,"h":154619449322,"f":4194306},{"t":655361,"n":"_readHeadIndex","d":626666,"h":158914416618,"f":4194306},{"t":262145,"n":"_disposed","d":626666,"h":163209383914,"f":4194306},{"t":102378,"n":"_readTail","d":626666,"h":167504351210,"f":4194306},{"t":655361,"n":"_readTailIndex","d":626666,"h":171799318506,"f":4194306},{"t":655361,"n":"_minimumReadBytes","d":626666,"h":176094285802,"f":4194306},{"t":102378,"n":"_writingHead","d":626666,"h":180389253098,"f":4194306},{"t":$.$$.System.Memory$$($.$$.System.Byte).$h,"n":"_writingHeadMemory","d":626666,"h":184684220394,"f":4194306},{"t":655361,"n":"_writingHeadBytesBuffered","d":626666,"h":188979187690,"f":4194306},{"t":1216490,"n":"_operationState","d":626666,"h":193274154986,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":626666,"h":206159056874,"f":16777217},{"p":[{"n":"options","p":1347562}],"n":".ctor","o":"$ctor$2","d":626666,"h":210454024170,"f":16777217}],"j":[692202,757738],"h":626666}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.Pipe`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeOptions", ($self) => class PipeOptions extends $.$$.System.Object
        {
            /*int*/ static DefaultMinimumSegmentSize = 4096;
            /*PipeOptions*/ static Default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*PipeScheduler?*/ readerScheduler, /*PipeScheduler?*/ writerScheduler, /*long*/ pauseWriterThreshold, /*long*/ resumeWriterThreshold, /*int*/ minimumSegmentSize, /*bool*/ useSynchronizationContext)
            {
                super.$ctor();
                {
                    this.MinimumSegmentSize = minimumSegmentSize === -1 ? 4096/*DefaultMinimumSegmentSize*/ : minimumSegmentSize;
                    this.InitialSegmentPoolSize = 4;
                    this.MaxSegmentPoolSize = 256;
                    /*int*/ let DefaultPauseWriterThreshold = 65536;
                    /*int*/ let DefaultResumeWriterThreshold = $.trunc(DefaultPauseWriterThreshold / 2);
                    if (pauseWriterThreshold === BigInt(-1))
                    {
                        pauseWriterThreshold = BigInt(DefaultPauseWriterThreshold);
                    }
                    else if (pauseWriterThreshold < 0n)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(4/*ExceptionArgument.pauseWriterThreshold*/);
                    }
                    if (resumeWriterThreshold === BigInt(-1))
                    {
                        resumeWriterThreshold = BigInt(DefaultResumeWriterThreshold);
                    }
                    else if (resumeWriterThreshold === 0n)
                    {
                        resumeWriterThreshold = 1n;
                    }
                    if (resumeWriterThreshold < 0n || (pauseWriterThreshold > 0n && resumeWriterThreshold > pauseWriterThreshold))
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(5/*ExceptionArgument.resumeWriterThreshold*/);
                    }
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).Shared;
                    this.IsDefaultSharedMemoryPool = this.Pool === $.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).Shared;
                    this.ReaderScheduler = readerScheduler ?? $.$sipl.System.IO.Pipelines.PipeScheduler.ThreadPool;
                    this.WriterScheduler = writerScheduler ?? $.$sipl.System.IO.Pipelines.PipeScheduler.ThreadPool;
                    this.PauseWriterThreshold = pauseWriterThreshold;
                    this.ResumeWriterThreshold = resumeWriterThreshold;
                    this.UseSynchronizationContext = useSynchronizationContext;
                }
                return this;
            }
            /*bool*/ UseSynchronizationContext = false;
            /*long*/ PauseWriterThreshold = 0n;
            /*long*/ ResumeWriterThreshold = 0n;
            /*int*/ MinimumSegmentSize = 0;
            /*PipeScheduler*/ WriterScheduler = null;
            /*PipeScheduler*/ ReaderScheduler = null;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ IsDefaultSharedMemoryPool = false;
            /*int*/ InitialSegmentPoolSize = 0;
            /*int*/ MaxSegmentPoolSize = 0;
            //default member initializer
            constructor()
            {
                super();
                this.UseSynchronizationContext = false;
                this.IsDefaultSharedMemoryPool = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$sipl.System.IO.Pipelines.PipeOptions().$ctor$1(null, null, null, -1n, -1n, -1, true);
                }
            }
            static $h = 1347562;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1347562,"g":{"r":0,"d":0,"h":17181216746,"f":50331681},"n":"Default","d":1347562,"h":12886249450,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":34361085930,"f":50331649},"n":"UseSynchronizationContext","d":1347562,"h":30066118634,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":47245987818,"f":50331649},"n":"PauseWriterThreshold","d":1347562,"h":42951020522,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":60130889706,"f":50331649},"n":"ResumeWriterThreshold","d":1347562,"h":55835922410,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":73015791594,"f":50331649},"n":"MinimumSegmentSize","d":1347562,"h":68720824298,"f":2097153},{"p":1544170,"g":{"r":0,"d":0,"h":85900693482,"f":50331649},"n":"WriterScheduler","d":1347562,"h":81605726186,"f":2097153},{"p":1544170,"g":{"r":0,"d":0,"h":98785595370,"f":50331649},"n":"ReaderScheduler","d":1347562,"h":94490628074,"f":2097153},{"p":$.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":111670497258,"f":50331649},"n":"Pool","d":1347562,"h":107375529962,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":124555399146,"f":50331656},"n":"IsDefaultSharedMemoryPool","d":1347562,"h":120260431850,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":137440301034,"f":50331656},"n":"InitialSegmentPoolSize","d":1347562,"h":133145333738,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":150325202922,"f":50331656},"n":"MaxSegmentPoolSize","d":1347562,"h":146030235626,"f":2097160}],"l":[{"t":655361,"n":"DefaultMinimumSegmentSize","d":1347562,"h":4296314858,"f":4194338}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).$h,"f":65},{"n":"readerScheduler","p":1544170,"f":65},{"n":"writerScheduler","p":1544170,"f":65},{"n":"pauseWriterThreshold","p":917505,"f":65,"v":-1},{"n":"resumeWriterThreshold","p":917505,"f":65,"v":-1},{"n":"minimumSegmentSize","p":655361,"f":65,"v":-1},{"n":"useSynchronizationContext","p":262145,"f":65,"v":true}],"n":".ctor","o":"$ctor$1","d":1347562,"h":21476184042,"f":16777217}],"h":1347562}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeOptions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeCompletionCallbacks", ($self) => class PipeCompletionCallbacks extends $.$$.System.Object
        {
            /*List<PipeCompletionCallback>*/ _callbacks = null;
            /*Exception?*/ _exception = null;
            $ctor$1(/*List<PipeCompletionCallback>*/ callbacks, /*ExceptionDispatchInfo?*/ edi)
            {
                super.$ctor();
                {
                    this._callbacks = callbacks;
                    this._exception = (edi?.SourceException ?? null);
                }
                return this;
            }
            /*void */ Execute()
            {
                /*var*/ let count = this._callbacks.Count;
                if (count === 0)
                {
                    return;
                }
                /*List<Exception>?*/ let exceptions = null;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*var*/ let callback = this._callbacks.get_Item(i);
                    this.Execute$1(callback, $.$ref(() => exceptions, ($v) => exceptions = $v, $.$$.System.Collections.Generic.List$$($.$$.System.Exception)));
                }
                if (exceptions !== null)
                {
                    throw new $.$$.System.AggregateException().$ctor$6(exceptions);
                }
            }
            /*void */ Execute$1(/*PipeCompletionCallback*/ callback, /*ref List<Exception>?*/ exceptions)
            {
                try
                {
                    callback.Callback.Invoke(this._exception, callback.State);
                }
                catch(ex)
                {
                    exceptions.$v ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Exception))().$ctor$1();
                    exceptions.$v.Add(ex);
                }
            }
            static $h = 1150954;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","d":1150954,"h":17181020138,"f":16777217},{"r":65537,"p":[{"n":"callback","p":1085418},{"n":"exceptions","p":$.$$.System.Collections.Generic.List$$($.$$.System.Exception).$h,"f":4}],"n":"Execute","o":"@$1","d":1150954,"h":21475987434,"f":16777218}],"l":[{"t":$.$$.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h,"n":"_callbacks","d":1150954,"h":4296118250,"f":4194306},{"t":47251457,"n":"_exception","d":1150954,"h":8591085546,"f":4194306}],"c":[{"p":[{"n":"callbacks","p":$.$$.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h},{"n":"edi","p":97386497}],"n":".ctor","o":"$ctor$1","d":1150954,"h":12886052842,"f":16777217}],"h":1150954}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletionCallbacks`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeExtensions", ($self) => class StreamPipeExtensions
        {
            static /*Task */ CopyToAsync(/*this Stream*/ source, /*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (source === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.source*/);
                }
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                return destination.CopyFromAsync(source, cancellationToken);
            }
            static $h = 1937386;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133169153,"p":[{"n":"source","p":62193665},{"n":"destination","p":1609706},{"n":"cancellationToken","p":125829121,"f":65}],"n":"CopyToAsync","d":1937386,"h":4296904682,"f":16777249}],"h":1937386}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeExtensions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeReaderOptions", ($self) => class StreamPipeReaderOptions extends $.$$.System.Object
        {
            /*int*/ static DefaultBufferSize = 4096;
            /*int*/ static DefaultMaxBufferSize = 2097152;
            /*int*/ static DefaultMinimumReadSize = 1024;
            /*StreamPipeReaderOptions*/ static s_default = null;
            $ctor$2(/*MemoryPool<byte>?*/ pool, /*int*/ bufferSize, /*int*/ minimumReadSize, /*bool*/ leaveOpen)
            {
                this.$ctor$1(null, -1, -1, false, false);
                {
                }
                return this;
            }
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*int*/ bufferSize, /*int*/ minimumReadSize, /*bool*/ leaveOpen, /*bool*/ useZeroByteReads)
            {
                super.$ctor();
                {
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).Shared;
                    this.IsDefaultSharedMemoryPool = this.Pool === $.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).Shared;
                    this.BufferSize = bufferSize === -1 ? 4096/*DefaultBufferSize*/ : bufferSize <= 0 ? (() =>
                    {
        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("bufferSize")            })() : bufferSize;
                    this.MinimumReadSize = minimumReadSize === -1 ? 1024/*DefaultMinimumReadSize*/ : minimumReadSize <= 0 ? (() =>
                    {
        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("minimumReadSize")            })() : minimumReadSize;
                    this.LeaveOpen = leaveOpen;
                    this.UseZeroByteReads = useZeroByteReads;
                }
                return this;
            }
            /*int*/ BufferSize = 0;
            /*int*/ MaxBufferSize = 0;
            /*int*/ MinimumReadSize = 0;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ LeaveOpen = false;
            /*bool*/ UseZeroByteReads = false;
            /*bool*/ IsDefaultSharedMemoryPool = false;
            //default member initializer
            constructor()
            {
                super();
                this.MaxBufferSize = 2097152;
                this.LeaveOpen = false;
                this.UseZeroByteReads = false;
                this.IsDefaultSharedMemoryPool = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_default = new $.$sipl.System.IO.Pipelines.StreamPipeReaderOptions().$ctor$1(null, -1, -1, false, false);
                }
            }
            static $h = 2068458;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":38656774122,"f":50331649},"n":"BufferSize","d":2068458,"h":34361806826,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":51541676010,"f":50331656},"n":"MaxBufferSize","d":2068458,"h":47246708714,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":64426577898,"f":50331649},"n":"MinimumReadSize","d":2068458,"h":60131610602,"f":2097153},{"p":$.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":77311479786,"f":50331649},"n":"Pool","d":2068458,"h":73016512490,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":90196381674,"f":50331649},"n":"LeaveOpen","d":2068458,"h":85901414378,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":103081283562,"f":50331649},"n":"UseZeroByteReads","d":2068458,"h":98786316266,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":115966185450,"f":50331656},"n":"IsDefaultSharedMemoryPool","d":2068458,"h":111671218154,"f":2097160}],"l":[{"t":655361,"n":"DefaultBufferSize","d":2068458,"h":4297035754,"f":4194338},{"t":655361,"n":"DefaultMaxBufferSize","d":2068458,"h":8592003050,"f":4194344},{"t":655361,"n":"DefaultMinimumReadSize","d":2068458,"h":12886970346,"f":4194338},{"t":2068458,"n":"s_default","d":2068458,"h":17181937642,"f":4194344}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).$h},{"n":"bufferSize","p":655361},{"n":"minimumReadSize","p":655361},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$2","d":2068458,"h":21476904938,"f":16777217},{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).$h,"f":65},{"n":"bufferSize","p":655361,"f":65,"v":-1},{"n":"minimumReadSize","p":655361,"f":65,"v":-1},{"n":"leaveOpen","p":262145,"f":65,"v":false},{"n":"useZeroByteReads","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$1","d":2068458,"h":25771872234,"f":16777217}],"h":2068458}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeReaderOptions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeWriterOptions", ($self) => class StreamPipeWriterOptions extends $.$$.System.Object
        {
            /*int*/ static DefaultMinimumBufferSize = 4096;
            /*StreamPipeWriterOptions*/ static s_default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*int*/ minimumBufferSize, /*bool*/ leaveOpen)
            {
                super.$ctor();
                {
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).Shared;
                    this.MinimumBufferSize = minimumBufferSize === -1 ? 4096/*DefaultMinimumBufferSize*/ : minimumBufferSize <= 0 ? (() =>
                    {
        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("minimumBufferSize")            })() : minimumBufferSize;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*int*/ MinimumBufferSize = 0;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ LeaveOpen = false;
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_default = new $.$sipl.System.IO.Pipelines.StreamPipeWriterOptions().$ctor$1(null, -1, false);
                }
            }
            static $h = 2199530;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25772003306,"f":50331649},"n":"MinimumBufferSize","d":2199530,"h":21477036010,"f":2097153},{"p":$.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":38656905194,"f":50331649},"n":"Pool","d":2199530,"h":34361937898,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":51541807082,"f":50331649},"n":"LeaveOpen","d":2199530,"h":47246839786,"f":2097153}],"l":[{"t":655361,"n":"DefaultMinimumBufferSize","d":2199530,"h":4297166826,"f":4194338},{"t":2199530,"n":"s_default","d":2199530,"h":8592134122,"f":4194344}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).$h,"f":65},{"n":"minimumBufferSize","p":655361,"f":65,"v":-1},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$1","d":2199530,"h":12887101418,"f":16777217}],"h":2199530}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeWriterOptions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateArgumentOutOfRangeException(argument);
            }
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                return new $.$$.System.ArgumentOutOfRangeException().$ctor$20($.$$.System.Enum.ToStringT($.$sipl.System.IO.Pipelines.ExceptionArgument, $.$$.System.UInt32, argument));
            }
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateArgumentNullException(argument);
            }
            static /*ArgumentNullException */ CreateArgumentNullException(/*ExceptionArgument*/ argument)
            {
                return new $.$$.System.ArgumentNullException().$ctor$19($.$$.System.Enum.ToStringT($.$sipl.System.IO.Pipelines.ExceptionArgument, $.$$.System.UInt32, argument));
            }
            static /*void */ ThrowInvalidOperationException_AlreadyReading()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_AlreadyReading();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_AlreadyReading()
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$sipl.System.SR.ReadingIsInProgress);
            }
            static /*void */ ThrowInvalidOperationException_NoReadToComplete()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoReadToComplete();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoReadToComplete()
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$sipl.System.SR.NoReadingOperationToComplete);
            }
            static /*void */ ThrowInvalidOperationException_NoConcurrentOperation()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoConcurrentOperation()
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$sipl.System.SR.ConcurrentOperationsNotSupported);
            }
            static /*void */ ThrowInvalidOperationException_GetResultNotCompleted()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_GetResultNotCompleted();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_GetResultNotCompleted()
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$sipl.System.SR.GetResultBeforeCompleted);
            }
            static /*void */ ThrowInvalidOperationException_NoWritingAllowed()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoWritingAllowed();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoWritingAllowed()
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$sipl.System.SR.WritingAfterCompleted);
            }
            static /*void */ ThrowInvalidOperationException_NoReadingAllowed()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoReadingAllowed();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoReadingAllowed()
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$sipl.System.SR.ReadingAfterCompleted);
            }
            static /*void */ ThrowInvalidOperationException_InvalidExaminedPosition()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidExaminedPosition();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidExaminedPosition()
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$sipl.System.SR.InvalidExaminedPosition);
            }
            static /*void */ ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidExaminedOrConsumedPosition();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidExaminedOrConsumedPosition()
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$sipl.System.SR.InvalidExaminedOrConsumedPosition);
            }
            static /*void */ ThrowInvalidOperationException_AdvanceToInvalidCursor()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_AdvanceToInvalidCursor();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_AdvanceToInvalidCursor()
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$sipl.System.SR.AdvanceToInvalidCursor);
            }
            static /*void */ ThrowInvalidOperationException_ResetIncompleteReaderWriter()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_ResetIncompleteReaderWriter();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_ResetIncompleteReaderWriter()
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$sipl.System.SR.ReaderAndWriterHasToBeCompleted);
            }
            static /*void */ ThrowOperationCanceledException_ReadCanceled()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateOperationCanceledException_ReadCanceled();
            }
            static /*OperationCanceledException */ CreateOperationCanceledException_ReadCanceled()
            {
                return new $.$$.System.OperationCanceledException().$ctor$14($.$sipl.System.SR.ReadCanceledOnPipeReader);
            }
            static /*void */ ThrowOperationCanceledException_FlushCanceled()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateOperationCanceledException_FlushCanceled();
            }
            static /*OperationCanceledException */ CreateOperationCanceledException_FlushCanceled()
            {
                return new $.$$.System.OperationCanceledException().$ctor$14($.$sipl.System.SR.FlushCanceledOnPipeWriter);
            }
            static /*void */ ThrowInvalidOperationException_InvalidZeroByteRead()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidZeroByteRead();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidZeroByteRead()
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$sipl.System.SR.InvalidZeroByteRead);
            }
            static /*void */ ThrowNotSupported_UnflushedBytes()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateNotSupportedException_UnflushedBytes();
            }
            static /*NotSupportedException */ CreateNotSupportedException_UnflushedBytes()
            {
                return new $.$$.System.NotSupportedException().$ctor$12($.$sipl.System.SR.UnflushedBytesNotSupported);
            }
            static $h = 2330602;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":364522}],"n":"ThrowArgumentOutOfRangeException","d":2330602,"h":4297297898,"f":16777256},{"r":13631489,"p":[{"n":"argument","p":364522}],"n":"CreateArgumentOutOfRangeException","d":2330602,"h":8592265194,"f":16777250},{"r":65537,"p":[{"n":"argument","p":364522}],"n":"ThrowArgumentNullException","d":2330602,"h":12887232490,"f":16777256},{"r":13565953,"p":[{"n":"argument","p":364522}],"n":"CreateArgumentNullException","d":2330602,"h":17182199786,"f":16777250},{"r":65537,"n":"ThrowInvalidOperationException_AlreadyReading","d":2330602,"h":21477167082,"f":16777249},{"r":58261505,"n":"CreateInvalidOperationException_AlreadyReading","d":2330602,"h":25772134378,"f":16777249},{"r":65537,"n":"ThrowInvalidOperationException_NoReadToComplete","d":2330602,"h":30067101674,"f":16777249},{"r":58261505,"n":"CreateInvalidOperationException_NoReadToComplete","d":2330602,"h":34362068970,"f":16777249},{"r":65537,"n":"ThrowInvalidOperationException_NoConcurrentOperation","d":2330602,"h":38657036266,"f":16777249},{"r":58261505,"n":"CreateInvalidOperationException_NoConcurrentOperation","d":2330602,"h":42952003562,"f":16777249},{"r":65537,"n":"ThrowInvalidOperationException_GetResultNotCompleted","d":2330602,"h":47246970858,"f":16777249},{"r":58261505,"n":"CreateInvalidOperationException_GetResultNotCompleted","d":2330602,"h":51541938154,"f":16777249},{"r":65537,"n":"ThrowInvalidOperationException_NoWritingAllowed","d":2330602,"h":55836905450,"f":16777249},{"r":58261505,"n":"CreateInvalidOperationException_NoWritingAllowed","d":2330602,"h":60131872746,"f":16777249},{"r":65537,"n":"ThrowInvalidOperationException_NoReadingAllowed","d":2330602,"h":64426840042,"f":16777249},{"r":58261505,"n":"CreateInvalidOperationException_NoReadingAllowed","d":2330602,"h":68721807338,"f":16777249},{"r":65537,"n":"ThrowInvalidOperationException_InvalidExaminedPosition","d":2330602,"h":73016774634,"f":16777249},{"r":58261505,"n":"CreateInvalidOperationException_InvalidExaminedPosition","d":2330602,"h":77311741930,"f":16777249},{"r":65537,"n":"ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition","d":2330602,"h":81606709226,"f":16777249},{"r":58261505,"n":"CreateInvalidOperationException_InvalidExaminedOrConsumedPosition","d":2330602,"h":85901676522,"f":16777249},{"r":65537,"n":"ThrowInvalidOperationException_AdvanceToInvalidCursor","d":2330602,"h":90196643818,"f":16777249},{"r":58261505,"n":"CreateInvalidOperationException_AdvanceToInvalidCursor","d":2330602,"h":94491611114,"f":16777249},{"r":65537,"n":"ThrowInvalidOperationException_ResetIncompleteReaderWriter","d":2330602,"h":98786578410,"f":16777249},{"r":58261505,"n":"CreateInvalidOperationException_ResetIncompleteReaderWriter","d":2330602,"h":103081545706,"f":16777249},{"r":65537,"n":"ThrowOperationCanceledException_ReadCanceled","d":2330602,"h":107376513002,"f":16777249},{"r":71106561,"n":"CreateOperationCanceledException_ReadCanceled","d":2330602,"h":111671480298,"f":16777249},{"r":65537,"n":"ThrowOperationCanceledException_FlushCanceled","d":2330602,"h":115966447594,"f":16777249},{"r":71106561,"n":"CreateOperationCanceledException_FlushCanceled","d":2330602,"h":120261414890,"f":16777249},{"r":65537,"n":"ThrowInvalidOperationException_InvalidZeroByteRead","d":2330602,"h":124556382186,"f":16777249},{"r":58261505,"n":"CreateInvalidOperationException_InvalidZeroByteRead","d":2330602,"h":128851349482,"f":16777249},{"r":65537,"n":"ThrowNotSupported_UnflushedBytes","d":2330602,"h":133146316778,"f":16777249},{"r":66781185,"n":"CreateNotSupportedException_UnflushedBytes","d":2330602,"h":137441284074,"f":16777249}],"h":2330602}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.ThrowHelper`; }
        });
        
        $asm.$cls("$sipl.System.SR", ($self) => class SR
        {
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sipl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sipl.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sipl.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sipl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sipl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$sipl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.IO.Pipelines", $.$sipl.System.SR.$type.Assembly);
                    $.$sipl.System.SR.s_resourceManager = temp;
                }
                return $.$sipl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sipl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sipl.System.SR.resourceCulture = value;
            }
            static /*string */ get AdvanceToInvalidCursor()
            {
                return "The PipeReader has already advanced past the provided position.";
            }
            static /*string */ get ArgumentOutOfRange_NeedPosNum()
            {
                return "Positive number required.";
            }
            static /*string */ get ConcurrentOperationsNotSupported()
            {
                return "Concurrent reads or writes are not supported.";
            }
            static /*string */ get FlushCanceledOnPipeWriter()
            {
                return "Flush was canceled on underlying PipeWriter.";
            }
            static /*string */ get GetResultBeforeCompleted()
            {
                return "Can't GetResult unless awaiter is completed.";
            }
            static /*string */ get InvalidExaminedOrConsumedPosition()
            {
                return "The examined position must be greater than or equal to the consumed position.";
            }
            static /*string */ get InvalidExaminedPosition()
            {
                return "The examined position cannot be less than the previously examined position.";
            }
            static /*string */ get InvalidZeroByteRead()
            {
                return "The PipeReader returned 0 bytes when the ReadResult was not completed or canceled.";
            }
            static /*string */ get ObjectDisposed_StreamClosed()
            {
                return "Cannot access a closed stream.";
            }
            static /*string */ get NoReadingOperationToComplete()
            {
                return "No reading operation to complete.";
            }
            static /*string */ get NotSupported_UnreadableStream()
            {
                return "Stream does not support reading.";
            }
            static /*string */ get NotSupported_UnwritableStream()
            {
                return "Stream does not support writing.";
            }
            static /*string */ get ReadCanceledOnPipeReader()
            {
                return "Read was canceled on underlying PipeReader.";
            }
            static /*string */ get ReaderAndWriterHasToBeCompleted()
            {
                return "Both reader and writer has to be completed to be able to reset the pipe.";
            }
            static /*string */ get ReadingAfterCompleted()
            {
                return "Reading is not allowed after reader was completed.";
            }
            static /*string */ get ReadingIsInProgress()
            {
                return "Reading is already in progress.";
            }
            static /*string */ get WritingAfterCompleted()
            {
                return "Writing is not allowed after writer was completed.";
            }
            static /*string */ get UnflushedBytesNotSupported()
            {
                return "UnflushedBytes is not supported.";
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sipl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2461674;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2461674}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sipl.System.IO.StreamHelpers", ($self) => class StreamHelpers
        {
            static /*void */ ValidateCopyToArgs(/*Stream*/ source, /*Stream*/ destination, /*int*/ bufferSize)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(destination, "destination");
                if (bufferSize <= 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("bufferSize", $.$box(bufferSize, $.$$.System.Int32), $.$sipl.System.SR.ArgumentOutOfRange_NeedPosNum);
                }
                /*bool*/ let sourceCanRead = source.CanRead;
                if (!sourceCanRead && !source.CanWrite)
                {
                    throw new $.$$.System.ObjectDisposedException().$ctor$16(null, $.$sipl.System.SR.ObjectDisposed_StreamClosed);
                }
                /*bool*/ let destinationCanWrite = destination.CanWrite;
                if (!destinationCanWrite && !destination.CanRead)
                {
                    throw new $.$$.System.ObjectDisposedException().$ctor$16("destination", $.$sipl.System.SR.ObjectDisposed_StreamClosed);
                }
                if (!sourceCanRead)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$sipl.System.SR.NotSupported_UnreadableStream);
                }
                if (!destinationCanWrite)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$sipl.System.SR.NotSupported_UnwritableStream);
                }
            }
            static $h = 2396138;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"source","p":62193665},{"n":"destination","p":62193665},{"n":"bufferSize","p":655361}],"n":"ValidateCopyToArgs","d":2396138,"h":4297363434,"f":16777249}],"h":2396138}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.StreamHelpers`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.CompletionData", ($self) => class CompletionData extends $.$$.System.ValueType
        {
            /*Action<object?>*/ Completion = null;
            /*object?*/ CompletionState = null;
            /*ExecutionContext?*/ ExecutionContext = null;
            /*SynchronizationContext?*/ SynchronizationContext = null;
            $ctor$3(/*Action<object?>*/ completion, /*object?*/ completionState, /*ExecutionContext?*/ executionContext, /*SynchronizationContext?*/ synchronizationContext)
            {
                super.$ctor$1();
                {
                    this.Completion = completion;
                    this.CompletionState = completionState;
                    this.ExecutionContext = executionContext;
                    this.SynchronizationContext = synchronizationContext;
                }
                return this;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Completion = this.Completion;
                copy.CompletionState = this.CompletionState;
                copy.ExecutionContext = this.ExecutionContext;
                copy.SynchronizationContext = this.SynchronizationContext;
                return copy;
            }
            static $h = 298986;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$$.System.Action$$($.$$.System.Object).$h,"g":{"r":0,"d":0,"h":12885200874,"f":50331649},"n":"Completion","d":298986,"h":8590233578,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":25770102762,"f":50331649},"n":"CompletionState","d":298986,"h":21475135466,"f":2097153},{"p":126812161,"g":{"r":0,"d":0,"h":38655004650,"f":50331649},"n":"ExecutionContext","d":298986,"h":34360037354,"f":2097153},{"p":131006465,"g":{"r":0,"d":0,"h":51539906538,"f":50331649},"n":"SynchronizationContext","d":298986,"h":47244939242,"f":2097153}],"c":[{"p":[{"n":"completion","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"completionState","p":131073},{"n":"executionContext","p":126812161},{"n":"synchronizationContext","p":131006465}],"n":".ctor","o":"$ctor$3","d":298986,"h":55834873834,"f":16777217},{"n":".ctor","o":"$ctor$2","d":298986,"h":60129841130,"f":16777217}],"h":298986}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.CompletionData`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.FlushResult", ($self) => class FlushResult extends $.$$.System.ValueType
        {
            /*ResultFlags*/  get _resultFlags() { return this.$getField(0, $.$sipl.System.IO.Pipelines.ResultFlags); }
            /*ResultFlags*/  set _resultFlags(value) { this.$setField(0, $.$sipl.System.IO.Pipelines.ResultFlags, value); }
            $ctor$3(/*bool*/ isCanceled, /*bool*/ isCompleted)
            {
                super.$ctor$1();
                {
                    this._resultFlags = 0/*ResultFlags.None*/;
                    if (isCanceled)
                    {
                        this._resultFlags |= 1/*ResultFlags.Canceled*/;
                    }
                    if (isCompleted)
                    {
                        this._resultFlags |= 2/*ResultFlags.Completed*/;
                    }
                }
                return this;
            }
            /*bool */ get IsCanceled()
            {
                return (this._resultFlags & 1/*ResultFlags.Canceled*/) !== 0;
            }
            /*bool */ get IsCompleted()
            {
                return (this._resultFlags & 2/*ResultFlags.Completed*/) !== 0;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resultFlags = this._resultFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resultFlags = 0;
            }
            static $h = 430058;
            static $z = 1;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180299242,"f":50331649},"n":"IsCanceled","d":430058,"h":12885331946,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":25770233834,"f":50331649},"n":"IsCompleted","d":430058,"h":21475266538,"f":2097153}],"l":[{"t":1806314,"n":"_resultFlags","d":430058,"h":4295397354,"f":4194312}],"c":[{"p":[{"n":"isCanceled","p":262145},{"n":"isCompleted","p":262145}],"n":".ctor","o":"$ctor$3","d":430058,"h":8590364650,"f":16777217},{"n":".ctor","o":"$ctor$2","d":430058,"h":30065201130,"f":16777217}],"h":430058}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.FlushResult`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.InlineScheduler", ($self) => class InlineScheduler extends $.$sipl.System.IO.Pipelines.PipeScheduler
        {
            /*void */ Schedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                action.Invoke(state);
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                action.Invoke(state);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 561130;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1544170,"m":[{"r":65537,"p":[{"n":"action","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":561130,"h":4295528426,"f":16809985},{"r":65537,"p":[{"n":"action","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":561130,"h":8590495722,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$2","d":561130,"h":12885463018,"f":16777217}],"h":561130}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeScheduler; }
            static get $fullName() { return `System.IO.Pipelines.InlineScheduler`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeCompletionCallback", ($self) => class PipeCompletionCallback extends $.$$.System.ValueType
        {
            /*Action<Exception?, object?>*/  get Callback() { return this.$getField(0, 4); }
            /*Action<Exception?, object?>*/  set Callback(value) { this.$setField(0, 4, value); }
            /*object?*/  get State() { return this.$getField(4, 4); }
            /*object?*/  set State(value) { this.$setField(4, 4, value); }
            $ctor$3(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                super.$ctor$1();
                {
                    this.Callback = callback;
                    this.State = state;
                }
                return this;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Callback = this.Callback;
                copy.State = this.State;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Callback = null;
                this.State = null;
            }
            static $h = 1085418;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":$.$$.System.Action$$$($.$$.System.Exception, $.$$.System.Object).$h,"n":"Callback","d":1085418,"h":4296052714,"f":4194305},{"t":131073,"n":"State","d":1085418,"h":8591020010,"f":4194305}],"c":[{"p":[{"n":"callback","p":$.$$.System.Action$$$($.$$.System.Exception, $.$$.System.Object).$h},{"n":"state","p":131073}],"n":".ctor","o":"$ctor$3","d":1085418,"h":12885987306,"f":16777217},{"n":".ctor","o":"$ctor$2","d":1085418,"h":17180954602,"f":16777217}],"h":1085418}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletionCallback`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.BufferSegmentStack", ($self) => class BufferSegmentStack extends $.$$.System.ValueType
        {
            /*SegmentAsValueType[]*/  get _array() { return this.$getField(0, 4); }
            /*SegmentAsValueType[]*/  set _array(value) { this.$setField(0, 4, value); }
            /*int*/  get _size() { return this.$getField(4, 4); }
            /*int*/  set _size(value) { this.$setField(4, 4, value); }
            $ctor$3(/*int*/ size)
            {
                super.$ctor$1();
                {
                    this._array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType), null, [size], null);
                    this._size = 0;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._size;
            }
            /*bool */ TryPop(/*out BufferSegment?*/ result)
            {
                /*int*/ let size = ((this._size - 1) | 0);
                /*SegmentAsValueType[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    result.$v = null;
                    return false;
                }
                this._size = size;
                result.$v = $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit($.$$.System.Array.$ReadT1.call(array, size));
                $.$$.System.Array.$WriteT1.call(array, new $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType(), size);
                return true;
            }
            /*void */ Push(/*BufferSegment*/ item)
            {
                /*int*/ let size = this._size;
                /*SegmentAsValueType[]*/ let array = this._array;
                if ((size >>> 0) < (array.length >>> 0))
                {
                    $.$$.System.Array.$WriteT1.call(array, $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit$1(item), size);
                    this._size = ((size + 1) | 0);
                }
                else 
                {
                    this.PushWithResize(item);
                }
            }
            /*void */ PushWithResize(/*BufferSegment*/ item)
            {
                $.$$.System.Array.Resize($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType, $.$ref(() => this._array, ($v) => this._array = $v, $.$typeArray($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType)), ((2 * this._array.length) | 0));
                $.$$.System.Array.$WriteT1.call(this._array, $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit$1(item), this._size);
                this._size++;
            }
            static $_SegmentAsValueType;
            static get SegmentAsValueType()
            {
                let $cls = $.$sipl.System.IO.Pipelines.BufferSegmentStack;
                return $cls.$_SegmentAsValueType ??= $asm.$nstr("$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType", ($self) => class SegmentAsValueType extends $.$$.System.ValueType
                {
                    /*BufferSegment*/  get _value() { return this.$getField(0, 4); }
                    /*BufferSegment*/  set _value(value) { this.$setField(0, 4, value); }
                    $ctor$3(/*BufferSegment*/ value)
                    {
                        super.$ctor$1();
                        this._value = value;
                        return this;
                    }
                    static /*SegmentAsValueType */ op_Implicit$1(/*BufferSegment*/ s)
                    {
                        return new $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType().$ctor$3(s);
                    }
                    static /*BufferSegment */ op_Implicit(/*SegmentAsValueType*/ s)
                    {
                        return s._value;
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._value = this._value;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._value = null;
                    }
                    static $h = 233450;
                    static $z = 4;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":102378,"n":"_value","d":233450,"h":4295200746,"f":4194306}],"c":[{"p":[{"n":"value","p":102378}],"n":".ctor","o":"$ctor$3","d":233450,"h":8590168042,"f":16777218},{"n":".ctor","o":"$ctor$2","d":233450,"h":21475069930,"f":16777217}],"d":167914,"h":233450}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType`; }
                }, $cls, ($v) => $cls.$_SegmentAsValueType = $v);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._array = this._array;
                copy._size = this._size;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._array = null;
                this._size = 0;
            }
            static $h = 167914;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21475004394,"f":50331649},"n":"Count","d":167914,"h":17180037098,"f":2097153}],"m":[{"r":262145,"p":[{"n":"result","p":102378,"f":2}],"n":"TryPop","d":167914,"h":25769971690,"f":16777217},{"r":65537,"p":[{"n":"item","p":102378}],"n":"Push","d":167914,"h":30064938986,"f":16777217},{"r":65537,"p":[{"n":"item","p":102378}],"n":"PushWithResize","d":167914,"h":34359906282,"f":16777218}],"l":[{"t":$.$typeArray($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType).$h,"n":"_array","d":167914,"h":4295135210,"f":4194306},{"t":655361,"n":"_size","d":167914,"h":8590102506,"f":4194306}],"c":[{"p":[{"n":"size","p":655361}],"n":".ctor","o":"$ctor$3","d":167914,"h":12885069802,"f":16777217},{"n":".ctor","o":"$ctor$2","d":167914,"h":42949840874,"f":16777217}],"j":[233450],"h":167914}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.BufferSegmentStack`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeAwaitable", ($self) => class PipeAwaitable extends $.$$.System.ValueType
        {
            /*AwaitableState*/  get _awaitableState() { return this.$getField(0, 4); }
            /*AwaitableState*/  set _awaitableState(value) { this.$setField(0, 4, value); }
            /*Action<object?>?*/  get _completion() { return this.$getField(4, 4); }
            /*Action<object?>?*/  set _completion(value) { this.$setField(4, 4, value); }
            /*object?*/  get _completionState() { return this.$getField(8, 4); }
            /*object?*/  set _completionState(value) { this.$setField(8, 4, value); }
            /*SchedulingContext?*/  get _schedulingContext() { return this.$getField(12, 4); }
            /*SchedulingContext?*/  set _schedulingContext(value) { this.$setField(12, 4, value); }
            /*CancellationTokenRegistration*/  get _cancellationTokenRegistration() { return this.$getField(16, 12); }
            /*CancellationTokenRegistration*/  set _cancellationTokenRegistration(value) { this.$setField(16, 12, value); }
            /*CancellationToken */ get CancellationToken()
            {
                return this._cancellationTokenRegistration.Token;
            }
            $ctor$3(/*bool*/ completed, /*bool*/ useSynchronizationContext)
            {
                super.$ctor$1();
                {
                    this._awaitableState = (completed ? 1/*AwaitableState.Completed*/ : 0/*AwaitableState.None*/) | (useSynchronizationContext ? 8/*AwaitableState.UseSynchronizationContext*/ : 0/*AwaitableState.None*/);
                    this._completion = null;
                    this._completionState = null;
                    this._cancellationTokenRegistration = new $.$$.System.Threading.CancellationTokenRegistration();
                    this._schedulingContext = null;
                }
                return this;
            }
            /*bool */ get IsCompleted()
            {
                return (this._awaitableState & (1/*AwaitableState.Completed*/ | 4/*AwaitableState.Canceled*/)) !== 0;
            }
            /*bool */ get IsRunning()
            {
                return (this._awaitableState & 2/*AwaitableState.Running*/) !== 0;
            }
            /*void */ BeginOperation(/*CancellationToken*/ cancellationToken, /*Action<object?>*/ callback, /*object?*/ state)
            {
                if (cancellationToken.CanBeCanceled && !this.IsCompleted)
                {
                    /*var*/ let previousAwaitableState = this._awaitableState;
                    this._cancellationTokenRegistration = cancellationToken.UnsafeRegister$1(callback, state);
                    if ($.$$.System.Threading.CancellationTokenRegistration.op_Equality(this._cancellationTokenRegistration, $.$default($.$$.System.Threading.CancellationTokenRegistration)))
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(previousAwaitableState === this._awaitableState, "The awaitable state changed!");
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                }
                this._awaitableState |= 2/*AwaitableState.Running*/;
            }
            /*void */ Complete(/*out CompletionData*/ completionData)
            {
                this.ExtractCompletion(completionData);
                this._awaitableState |= 1/*AwaitableState.Completed*/;
            }
            /*void */ ExtractCompletion(/*out CompletionData*/ completionData)
            {
                /*Action<object?>?*/ let currentCompletion = this._completion;
                /*object?*/ let currentState = this._completionState;
                /*SchedulingContext?*/ let schedulingContext = this._schedulingContext;
                /*ExecutionContext?*/ let executionContext = (schedulingContext?.ExecutionContext ?? null);
                /*SynchronizationContext?*/ let synchronizationContext = (schedulingContext?.SynchronizationContext ?? null);
                this._completion = null;
                this._completionState = null;
                this._schedulingContext = null;
                completionData.$v = currentCompletion !== null ? new $.$sipl.System.IO.Pipelines.CompletionData().$ctor$3(currentCompletion, currentState, executionContext, synchronizationContext) : new $.$sipl.System.IO.Pipelines.CompletionData();
            }
            /*void */ SetUncompleted()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._completion === null, "_completion == null");
                $.$$.System.Diagnostics.Debug.Assert$2(this._completionState === null, "_completionState == null");
                $.$$.System.Diagnostics.Debug.Assert$2(this._schedulingContext === null, "_schedulingContext == null");
                this._awaitableState &= ~1/*AwaitableState.Completed*/;
            }
            /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags, /*out CompletionData*/ completionData, /*out bool*/ doubleCompletion)
            {
                completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                doubleCompletion.$v = !(this._completion === null);
                if (this.IsCompleted || doubleCompletion.$v)
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData().$ctor$3(continuation, state, (this._schedulingContext?.ExecutionContext ?? null), (this._schedulingContext?.SynchronizationContext ?? null));
                    return;
                }
                this._completion = continuation;
                this._completionState = state;
                if ((this._awaitableState & 8/*AwaitableState.UseSynchronizationContext*/) !== 0 && (flags & 1/*ValueTaskSourceOnCompletedFlags.UseSchedulingContext*/) !== 0)
                {
                    /*SynchronizationContext?*/ let sc = $.$$.System.Threading.SynchronizationContext.Current;
                    if (sc !== null && $.$$.System.Type.op_Inequality$1($.$$.System.Object.GetType.call(sc), $.$$.System.Threading.SynchronizationContext.$type))
                    {
                        this._schedulingContext ??= new $.$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext().$ctor$1();
                        this._schedulingContext.SynchronizationContext = sc;
                    }
                }
                if ((flags & 2/*ValueTaskSourceOnCompletedFlags.FlowExecutionContext*/) !== 0)
                {
                    this._schedulingContext ??= new $.$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext().$ctor$1();
                    this._schedulingContext.ExecutionContext = $.$$.System.Threading.ExecutionContext.Capture();
                }
            }
            /*void */ Cancel(/*out CompletionData*/ completionData)
            {
                this.ExtractCompletion(completionData);
                this._awaitableState |= 4/*AwaitableState.Canceled*/;
            }
            /*void */ CancellationTokenFired(/*out CompletionData*/ completionData)
            {
                if (this.CancellationToken.IsCancellationRequested)
                {
                    this.Cancel(completionData);
                }
                else 
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                }
            }
            /*bool */ ObserveCancellation()
            {
                /*bool*/ let isCanceled = (this._awaitableState & 4/*AwaitableState.Canceled*/) === 4/*AwaitableState.Canceled*/;
                this._awaitableState &= ~(4/*AwaitableState.Canceled*/ | 2/*AwaitableState.Running*/);
                return isCanceled;
            }
            /*CancellationTokenRegistration */ ReleaseCancellationTokenRegistration(/*out CancellationToken*/ cancellationToken)
            {
                cancellationToken.$v = this.CancellationToken;
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = this._cancellationTokenRegistration;
                this._cancellationTokenRegistration = new $.$$.System.Threading.CancellationTokenRegistration();
                return cancellationTokenRegistration;
            }
            static $_AwaitableState;
            static get AwaitableState()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeAwaitable;
                return $cls.$_AwaitableState ??= $asm.$nstr("$sipl.System.IO.Pipelines.PipeAwaitable.AwaitableState", ($self) => class AwaitableState extends $.$$.System.Enum
                {
                    static None = 0;
                    static Completed = 1;
                    static Running = 2;
                    static Canceled = 4;
                    static UseSynchronizationContext = 8;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "Completed": 1n,
                            "Running": 2n,
                            "Canceled": 4n,
                            "UseSynchronizationContext": 8n
                        };
                    }
                    static $h = 888810;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":888810,"n":"None","d":888810,"h":4295856106,"f":4194337},{"t":888810,"n":"Completed","d":888810,"h":8590823402,"f":4194337},{"t":888810,"n":"Running","d":888810,"h":12885790698,"f":4194337},{"t":888810,"n":"Canceled","d":888810,"h":17180757994,"f":4194337},{"t":888810,"n":"UseSynchronizationContext","d":888810,"h":21475725290,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":888810,"h":25770692586,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":823274,"h":888810,"a":[{"t":47710209,"c":4342677505}]}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Pipelines.PipeAwaitable.AwaitableState`; }
                }, $cls, ($v) => $cls.$_AwaitableState = $v);
            }
            static $_SchedulingContext;
            static get SchedulingContext()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeAwaitable;
                return $cls.$_SchedulingContext ??= $asm.$ncls("$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext", ($self) => class SchedulingContext extends $.$$.System.Object
                {
                    /*SynchronizationContext?*/ SynchronizationContext = null;
                    /*ExecutionContext?*/ ExecutionContext = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 954346;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131006465,"g":{"r":0,"d":0,"h":12885856234,"f":50331649},"s":{"r":0,"d":0,"h":17180823530,"f":83886081},"n":"SynchronizationContext","d":954346,"h":8590888938,"f":2097153},{"p":126812161,"g":{"r":0,"d":0,"h":30065725418,"f":50331649},"s":{"r":0,"d":0,"h":34360692714,"f":83886081},"n":"ExecutionContext","d":954346,"h":25770758122,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":954346,"h":38655660010,"f":16777217}],"d":823274,"h":954346}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.IO.Pipelines.PipeAwaitable.SchedulingContext`; }
                }, $cls, ($v) => $cls.$_SchedulingContext = $v);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._awaitableState = this._awaitableState;
                copy._completion = this._completion;
                copy._completionState = this._completionState;
                copy._schedulingContext = this._schedulingContext;
                copy._cancellationTokenRegistration = this._cancellationTokenRegistration.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._awaitableState = 0;
                this._completion = null;
                this._completionState = null;
                this._schedulingContext = null;
                this._cancellationTokenRegistration = $.$default($.$$.System.Threading.CancellationTokenRegistration);
            }
            static $h = 823274;
            static $z = 28;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":125829121,"g":{"r":0,"d":0,"h":30065594346,"f":50331650},"n":"CancellationToken","d":823274,"h":25770627050,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":42950496234,"f":50331649},"n":"IsCompleted","d":823274,"h":38655528938,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":51540430826,"f":50331649},"n":"IsRunning","d":823274,"h":47245463530,"f":2097153}],"m":[{"r":65537,"p":[{"n":"cancellationToken","p":125829121},{"n":"callback","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073}],"n":"BeginOperation","d":823274,"h":55835398122,"f":16777217},{"r":65537,"p":[{"n":"completionData","p":298986,"f":2}],"n":"Complete","d":823274,"h":60130365418,"f":16777217},{"r":65537,"p":[{"n":"completionData","p":298986,"f":2}],"n":"ExtractCompletion","d":823274,"h":64425332714,"f":16777218},{"r":65537,"n":"SetUncompleted","d":823274,"h":68720300010,"f":16777217},{"r":65537,"p":[{"n":"continuation","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132841473},{"n":"completionData","p":298986,"f":2},{"n":"doubleCompletion","p":262145,"f":2}],"n":"OnCompleted","d":823274,"h":73015267306,"f":16777217},{"r":65537,"p":[{"n":"completionData","p":298986,"f":2}],"n":"Cancel","d":823274,"h":77310234602,"f":16777217},{"r":65537,"p":[{"n":"completionData","p":298986,"f":2}],"n":"CancellationTokenFired","d":823274,"h":81605201898,"f":16777217},{"r":262145,"n":"ObserveCancellation","d":823274,"h":85900169194,"f":16777217},{"r":125894657,"p":[{"n":"cancellationToken","p":125829121,"f":2}],"n":"ReleaseCancellationTokenRegistration","d":823274,"h":90195136490,"f":16777217}],"l":[{"t":888810,"n":"_awaitableState","d":823274,"h":4295790570,"f":4194306},{"t":$.$$.System.Action$$($.$$.System.Object).$h,"n":"_completion","d":823274,"h":8590757866,"f":4194306},{"t":131073,"n":"_completionState","d":823274,"h":12885725162,"f":4194306},{"t":954346,"n":"_schedulingContext","d":823274,"h":17180692458,"f":4194306},{"t":125894657,"n":"_cancellationTokenRegistration","d":823274,"h":21475659754,"f":4194306}],"c":[{"p":[{"n":"completed","p":262145},{"n":"useSynchronizationContext","p":262145}],"n":".ctor","o":"$ctor$3","d":823274,"h":34360561642,"f":16777217},{"n":".ctor","o":"$ctor$2","d":823274,"h":103080038378,"f":16777217}],"j":[888810,954346],"h":823274,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"CanceledState = {_awaitableState}, IsCompleted = {IsCompleted}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeAwaitable`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ReadResult", ($self) => class ReadResult extends $.$$.System.ValueType
        {
            /*ReadOnlySequence<byte>*/  get _resultBuffer() { return this.$getField(0, 16); }
            /*ReadOnlySequence<byte>*/  set _resultBuffer(value) { this.$setField(0, 16, value); }
            /*ResultFlags*/  get _resultFlags() { return this.$getField(16, 1); }
            /*ResultFlags*/  set _resultFlags(value) { this.$setField(16, 1, value); }
            $ctor$3(/*ReadOnlySequence<byte>*/ buffer, /*bool*/ isCanceled, /*bool*/ isCompleted)
            {
                super.$ctor$1();
                {
                    this._resultBuffer = buffer;
                    this._resultFlags = 0/*ResultFlags.None*/;
                    if (isCompleted)
                    {
                        this._resultFlags |= 2/*ResultFlags.Completed*/;
                    }
                    if (isCanceled)
                    {
                        this._resultFlags |= 1/*ResultFlags.Canceled*/;
                    }
                }
                return this;
            }
            /*ReadOnlySequence<byte> */ get Buffer()
            {
                return this._resultBuffer;
            }
            /*bool */ get IsCanceled()
            {
                return (this._resultFlags & 1/*ResultFlags.Canceled*/) !== 0;
            }
            /*bool */ get IsCompleted()
            {
                return (this._resultFlags & 2/*ResultFlags.Completed*/) !== 0;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resultBuffer = this._resultBuffer.Clone();
                copy._resultFlags = this._resultFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resultBuffer = $.$default($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte));
                this._resultFlags = 0;
            }
            static $h = 1740778;
            static $z = 17;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":21476577258,"f":50331649},"n":"Buffer","d":1740778,"h":17181609962,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":30066511850,"f":50331649},"n":"IsCanceled","d":1740778,"h":25771544554,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":38656446442,"f":50331649},"n":"IsCompleted","d":1740778,"h":34361479146,"f":2097153}],"l":[{"t":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,"n":"_resultBuffer","d":1740778,"h":4296708074,"f":4194312},{"t":1806314,"n":"_resultFlags","d":1740778,"h":8591675370,"f":4194312}],"c":[{"p":[{"n":"buffer","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h},{"n":"isCanceled","p":262145},{"n":"isCompleted","p":262145}],"n":".ctor","o":"$ctor$3","d":1740778,"h":12886642666,"f":16777217},{"n":".ctor","o":"$ctor$2","d":1740778,"h":42951413738,"f":16777217}],"h":1740778}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.ReadResult`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.SequencePipeReader", ($self) => class SequencePipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
        {
            /*ReadOnlySequence<byte>*/ _sequence;
            /*bool*/ _isReaderCompleted = false;
            /*int*/ _cancelNext = 0;
            $ctor$2(/*ReadOnlySequence<byte>*/ sequence)
            {
                super.$ctor$1();
                {
                    this._sequence = sequence;
                }
                return this;
            }
            /*void */ AdvanceTo$1(/*SequencePosition*/ consumed)
            {
                this.AdvanceTo(consumed, consumed);
            }
            /*void */ AdvanceTo(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
            {
                this.ThrowIfCompleted();
                if (consumed.Equals$2(this._sequence.End))
                {
                    this._sequence = $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).Empty;
                    return;
                }
                this._sequence = this._sequence.Slice$8(consumed);
            }
            /*void */ CancelPendingRead()
            {
                $.$$.System.Threading.Interlocked.Exchange$3($.$ref(() => this._cancelNext, ($v) => this._cancelNext = $v, $.$$.System.Int32), 1);
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this._isReaderCompleted)
                {
                    return;
                }
                this._isReaderCompleted = true;
                this._sequence = $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).Empty;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                /*ReadResult*/ let result;
                if (this.TryRead($.$ref(() => result, ($v) => result = $v, $.$sipl.System.IO.Pipelines.ReadResult)))
                {
                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$6(result);
                }
                result = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$3($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).Empty, false, true);
                return new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$6(result);
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                this.ThrowIfCompleted();
                /*bool*/ let isCancellationRequested = $.$$.System.Threading.Interlocked.Exchange$3($.$ref(() => this._cancelNext, ($v) => this._cancelNext = $v, $.$$.System.Int32), 0) === 1;
                if (isCancellationRequested || this._sequence.Length > 0n)
                {
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$3(this._sequence, isCancellationRequested, true);
                    return true;
                }
                result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                return false;
            }
            /*void */ ThrowIfCompleted()
            {
                if (this._isReaderCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._sequence = $.$default($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte));
            }
            static $h = 1871850;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1413098,"m":[{"r":65537,"p":[{"n":"consumed","p":1220103}],"n":"AdvanceTo","o":"@$1","d":1871850,"h":21476708330,"f":16809985},{"r":65537,"p":[{"n":"consumed","p":1220103},{"n":"examined","p":1220103}],"n":"AdvanceTo","d":1871850,"h":25771675626,"f":16809985},{"r":65537,"n":"CancelPendingRead","d":1871850,"h":30066642922,"f":16809985},{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":1871850,"h":34361610218,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","d":1871850,"h":38656577514,"f":16809985},{"r":262145,"p":[{"n":"result","p":1740778,"f":2}],"n":"TryRead","d":1871850,"h":42951544810,"f":16809985},{"r":65537,"n":"ThrowIfCompleted","d":1871850,"h":47246512106,"f":16777218}],"l":[{"t":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,"n":"_sequence","d":1871850,"h":4296839146,"f":4194306},{"t":262145,"n":"_isReaderCompleted","d":1871850,"h":8591806442,"f":4194306},{"t":655361,"n":"_cancelNext","d":1871850,"h":12886773738,"f":4194306}],"c":[{"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$2","d":1871850,"h":17181741034,"f":16777217}],"h":1871850}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
            static get $fullName() { return `System.IO.Pipelines.SequencePipeReader`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeOperationState", ($self) => class PipeOperationState extends $.$$.System.ValueType
        {
            /*State*/  get _state() { return this.$getField(0, $.$sipl.System.IO.Pipelines.PipeOperationState.State); }
            /*State*/  set _state(value) { this.$setField(0, $.$sipl.System.IO.Pipelines.PipeOperationState.State, value); }
            /*void */ BeginRead()
            {
                if ((this._state & 1/*State.Reading*/) === 1/*State.Reading*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                }
                this._state |= 1/*State.Reading*/;
            }
            /*void */ BeginReadTentative()
            {
                if ((this._state & 1/*State.Reading*/) === 1/*State.Reading*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                }
                this._state |= 2/*State.ReadingTentative*/;
            }
            /*void */ EndRead()
            {
                if ((this._state & 1/*State.Reading*/) !== 1/*State.Reading*/ && (this._state & 2/*State.ReadingTentative*/) !== 2/*State.ReadingTentative*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadToComplete();
                }
                this._state &= ~(1/*State.Reading*/ | 2/*State.ReadingTentative*/);
            }
            /*void */ BeginWrite()
            {
                this._state |= 4/*State.Writing*/;
            }
            /*void */ EndWrite()
            {
                this._state &= ~4/*State.Writing*/;
            }
            /*bool */ get IsWritingActive()
            {
                return (this._state & 4/*State.Writing*/) === 4/*State.Writing*/;
            }
            /*bool */ get IsReadingActive()
            {
                return (this._state & 1/*State.Reading*/) === 1/*State.Reading*/;
            }
            static $_State;
            static get State()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeOperationState;
                return $cls.$_State ??= $asm.$nstr("$sipl.System.IO.Pipelines.PipeOperationState.State", ($self) => class State extends $.$$.System.Enum
                {
                    static Reading = 1;
                    static ReadingTentative = 2;
                    static Writing = 4;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Reading": 1n,
                            "ReadingTentative": 2n,
                            "Writing": 4n
                        };
                    }
                    static $h = 1282026;
                    static $z = 1;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Byte; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":1282026,"n":"Reading","d":1282026,"h":4296249322,"f":4194337},{"t":1282026,"n":"ReadingTentative","d":1282026,"h":8591216618,"f":4194337},{"t":1282026,"n":"Writing","d":1282026,"h":12886183914,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1282026,"h":17181151210,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":1216490,"h":1282026,"a":[{"t":47710209,"c":4342677505}]}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Pipelines.PipeOperationState.State`; }
                }, $cls, ($v) => $cls.$_State = $v);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._state = this._state;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = 0;
            }
            static $h = 1216490;
            static $z = 1;
            static $f = 0b10000000000001010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360954858,"f":50331649},"n":"IsWritingActive","d":1216490,"h":30065987562,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":42950889450,"f":50331649},"n":"IsReadingActive","d":1216490,"h":38655922154,"f":2097153}],"m":[{"r":65537,"n":"BeginRead","d":1216490,"h":8591151082,"f":16777217},{"r":65537,"n":"BeginReadTentative","d":1216490,"h":12886118378,"f":16777217},{"r":65537,"n":"EndRead","d":1216490,"h":17181085674,"f":16777217},{"r":65537,"n":"BeginWrite","d":1216490,"h":21476052970,"f":16777217},{"r":65537,"n":"EndWrite","d":1216490,"h":25771020266,"f":16777217}],"l":[{"t":1282026,"n":"_state","d":1216490,"h":4296183786,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":1216490,"h":51540824042,"f":16777217}],"j":[1282026],"h":1216490,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"State = {_state}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeOperationState`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.ThreadPoolScheduler", ($self) => class ThreadPoolScheduler extends $.$sipl.System.IO.Pipelines.PipeScheduler
        {
            /*void */ Schedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                $.$$.System.Threading.ThreadPool.QueueUserWorkItem$2($.$$.System.Object, action, state, false);
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                $.$$.System.Threading.ThreadPool.UnsafeQueueUserWorkItem$2($.$$.System.Object, action, state, false);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2265066;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1544170,"m":[{"r":65537,"p":[{"n":"action","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":2265066,"h":4297232362,"f":16809985},{"r":65537,"p":[{"n":"action","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":2265066,"h":8592199658,"f":16809992}],"c":[{"n":".ctor","o":"$ctor$2","d":2265066,"h":12887166954,"f":16777217}],"h":2265066}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeScheduler; }
            static get $fullName() { return `System.IO.Pipelines.ThreadPoolScheduler`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeReader", ($self) => class StreamPipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
        {
            /*int*/ static InitialSegmentPoolSize = 4;
            /*int*/ static MaxSegmentPoolSize = 256;
            /*CancellationTokenSource?*/ _internalTokenSource = null;
            /*bool*/ _isReaderCompleted = false;
            /*BufferSegment?*/ _readHead = null;
            /*int*/ _readIndex = 0;
            /*BufferSegment?*/ _readTail = null;
            /*long*/ _bufferedBytes = 0n;
            /*bool*/ _examinedEverything = false;
            /*object*/ _lock = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*StreamPipeReaderOptions*/ _options = null;
            $ctor$2(/*Stream*/ readingStream, /*StreamPipeReaderOptions*/ options)
            {
                super.$ctor$1();
                {
                    if (readingStream === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(10/*ExceptionArgument.readingStream*/);
                    }
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this.InnerStream = readingStream;
                    this._options = options;
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$3(4/*InitialSegmentPoolSize*/);
                }
                return this;
            }
            /*bool */ get LeaveOpen()
            {
                return this._options.LeaveOpen;
            }
            /*bool */ get UseZeroByteReads()
            {
                return this._options.UseZeroByteReads;
            }
            /*int */ get BufferSize()
            {
                return this._options.BufferSize;
            }
            /*int */ get MaxBufferSize()
            {
                return this._options.MaxBufferSize;
            }
            /*int */ get MinimumReadThreshold()
            {
                return this._options.MinimumReadSize;
            }
            /*MemoryPool<byte> */ get Pool()
            {
                return this._options.Pool;
            }
            /*Stream*/ InnerStream = null;
            /*void */ AdvanceTo$1(/*SequencePosition*/ consumed)
            {
                this.AdvanceTo(consumed, consumed);
            }
            /*CancellationTokenSource */ get InternalTokenSource()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._lock)
                    {
                        return this._internalTokenSource ??= new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._lock)
                }
            }
            /*void */ AdvanceTo(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
            {
                this.ThrowIfCompleted();
                this.AdvanceTo$2($.$cast(consumed.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), consumed.GetInteger(), $.$cast(examined.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), examined.GetInteger());
            }
            /*void */ AdvanceTo$2(/*BufferSegment?*/ consumedSegment, /*int*/ consumedIndex, /*BufferSegment?*/ examinedSegment, /*int*/ examinedIndex)
            {
                if (consumedSegment === null || examinedSegment === null)
                {
                    return;
                }
                if (this._readHead === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AdvanceToInvalidCursor();
                }
                /*BufferSegment*/ let returnStart = this._readHead;
                /*BufferSegment?*/ let returnEnd = consumedSegment;
                /*long*/ let consumedBytes = $.$sipl.System.IO.Pipelines.BufferSegment.GetLength$1(returnStart, this._readIndex, consumedSegment, consumedIndex);
                this._bufferedBytes -= consumedBytes;
                $.$$.System.Diagnostics.Debug.Assert$2(this._bufferedBytes >= 0n, "_bufferedBytes >= 0");
                this._examinedEverything = false;
                if (examinedSegment === this._readTail)
                {
                    this._examinedEverything = examinedIndex === this._readTail.End;
                }
                if (this._bufferedBytes === 0n)
                {
                    returnEnd = null;
                    this._readHead = null;
                    this._readTail = null;
                    this._readIndex = 0;
                }
                else if (consumedIndex === returnEnd.Length)
                {
                    /*BufferSegment?*/ let nextBlock = returnEnd.NextSegment;
                    this._readHead = nextBlock;
                    this._readIndex = 0;
                    returnEnd = nextBlock;
                }
                else 
                {
                    this._readHead = consumedSegment;
                    this._readIndex = consumedIndex;
                }
                while(returnStart !== returnEnd)
                {
                    /*BufferSegment*/ let next = returnStart.NextSegment;
                    this.ReturnSegmentUnsynchronized(returnStart);
                    returnStart = next;
                }
            }
            /*void */ CancelPendingRead()
            {
                this.InternalTokenSource.Cancel();
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this.CompleteAndGetNeedsDispose())
                {
                    this.InnerStream.Dispose();
                }
            }
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                return this.CompleteAndGetNeedsDispose() ? this.InnerStream.DisposeAsync() : new $.$$.System.Threading.Tasks.ValueTask();
            }
            /*bool */ CompleteAndGetNeedsDispose()
            {
                if (this._isReaderCompleted)
                {
                    return false;
                }
                this._isReaderCompleted = true;
                /*BufferSegment?*/ let segment = this._readHead;
                while(segment !== null)
                {
                    /*BufferSegment*/ let returnSegment = segment;
                    segment = segment.NextSegment;
                    returnSegment.Reset();
                }
                return !this.LeaveOpen;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                return this.ReadInternalAsync(null, cancellationToken);
            }
            /*ValueTask<ReadResult> */ ReadAtLeastAsyncCore(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadInternalAsync(minimumSize, cancellationToken);
            }
            /*ValueTask<ReadResult> */ ReadInternalAsync(/*int?*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfCompleted();
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$5($.$$.System.Threading.Tasks.Task.FromCanceled$3($.$sipl.System.IO.Pipelines.ReadResult, cancellationToken));
                }
                /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                /*ReadResult*/ let readResult;
                if (this.TryReadInternal(tokenSource, $.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult)))
                {
                    if (minimumSize === null || readResult.Buffer.Length >= minimumSize || readResult.IsCompleted || readResult.IsCanceled)
                    {
                        return new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$6(readResult);
                    }
                }
                return Core(this, minimumSize, tokenSource, cancellationToken);
                /*static ValueTask<ReadResult>*/ /*async*/  function Core(/*StreamPipeReader*/ reader, /*int?*/ minimumSize, /*CancellationTokenSource*/ tokenSource, /*CancellationToken*/ cancellationToken)
                {
                    return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult), $.$sipl.System.IO.Pipelines.ReadResult, async () => 
                    {
                        /*CancellationTokenRegistration*/ let reg = new $.$$.System.Threading.CancellationTokenRegistration();
                        if (cancellationToken.CanBeCanceled)
                        {
                            reg = cancellationToken.UnsafeRegister$1(new ($.$$.System.Action$$($.$$.System.Object))().$ctor(this,  (/*state*/ state) =>
                            {
                                return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                            }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":2002922,"h":0,"f":17825794}), reader);
                        }
                        let $disposable2 = null;
                        try
                        {
                            $disposable2 = reg;
                            /*var*/ let isCanceled = false;
                            /*bool*/ let isCompleted = false;
                            try
                            {
                                if (reader.UseZeroByteReads && reader._bufferedBytes === 0n)
                                {
                                    await reader.InnerStream.ReadAsync$2($.$$.System.Memory$$($.$$.System.Byte).Empty, tokenSource.Token).ConfigureAwait(false);
                                }
                                do
                                {
                                    reader.AllocateReadTail(minimumSize);
                                    /*Memory<byte>*/ let buffer = reader._readTail.AvailableMemory.Slice$1(reader._readTail.End);
                                    /*int*/ let length = await reader.InnerStream.ReadAsync$2(buffer, tokenSource.Token).ConfigureAwait(false);
                                    $.$$.System.Diagnostics.Debug.Assert$2(((length + reader._readTail.End) | 0) <= reader._readTail.AvailableMemory.Length, "length + reader._readTail.End <= reader._readTail.AvailableMemory.Length");
                                    reader._readTail.End += length;
                                    reader._bufferedBytes += BigInt(length);
                                    if (length === 0)
                                    {
                                        isCompleted = true;
                                        break;
                                    }
                                }
                                while(minimumSize !== null && reader._bufferedBytes < minimumSize);
                            }
                            catch(ex)
                            {
                                reader.ClearCancellationToken();
                                if (cancellationToken.IsCancellationRequested)
                                {
                                    throw new $.$$.System.OperationCanceledException().$ctor$11(ex.Message, ex, cancellationToken);
                                }
                                else if (tokenSource.IsCancellationRequested)
                                {
                                    isCanceled = true;
                                }
                                else 
                                {
                                    throw ex;
                                }
                            }
                            return new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$3(reader.GetCurrentReadOnlySequence(), isCanceled, isCompleted);
                        }
                        finally
                        {
                            $disposable2?.System$IDisposable$Dispose();
                        }
                    });
                }
            }
            /*Task *//*async*/  CopyToAsync$1(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    this.ThrowIfCompleted();
                    /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                    if (tokenSource.IsCancellationRequested)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                    }
                    /*CancellationTokenRegistration*/ let reg = new $.$$.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister$1(new ($.$$.System.Action$$($.$$.System.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                        }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":2002922,"h":0,"f":17825794}), this);
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._readHead;
                            /*int*/ let segmentIndex = this._readIndex;
                            try
                            {
                                while(segment !== null)
                                {
                                    /*FlushResult*/ let flushResult = await destination.WriteAsync(segment.Memory.Slice$1(segmentIndex), tokenSource.Token).ConfigureAwait(false);
                                    if (flushResult.IsCanceled)
                                    {
                                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                                    }
                                    segment = segment.NextSegment;
                                    segmentIndex = 0;
                                    if (flushResult.IsCompleted)
                                    {
                                        return;
                                    }
                                }
                            }
                            finally
                            {
                                {
                                    if (segment !== null)
                                    {
                                        this.AdvanceTo$2(segment, segment.End, segment, segment.End);
                                    }
                                }
                            }
                            await $.$sipl.System.IO.Pipelines.StreamPipeExtensions.CopyToAsync(this.InnerStream, destination, tokenSource.Token).ConfigureAwait(false);
                        }
                        catch($e)
                        {
                            this.ClearCancellationToken();
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*Task *//*async*/  CopyToAsync(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    this.ThrowIfCompleted();
                    /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                    if (tokenSource.IsCancellationRequested)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                    }
                    /*CancellationTokenRegistration*/ let reg = new $.$$.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister$1(new ($.$$.System.Action$$($.$$.System.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                        }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":2002922,"h":0,"f":17825794}), this);
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._readHead;
                            /*int*/ let segmentIndex = this._readIndex;
                            try
                            {
                                while(segment !== null)
                                {
                                    await destination.WriteAsync$2(segment.Memory.Slice$1(segmentIndex), tokenSource.Token).ConfigureAwait(false);
                                    segment = segment.NextSegment;
                                    segmentIndex = 0;
                                }
                            }
                            finally
                            {
                                {
                                    if (segment !== null)
                                    {
                                        this.AdvanceTo$2(segment, segment.End, segment, segment.End);
                                    }
                                }
                            }
                            await this.InnerStream.CopyToAsync$2(destination, tokenSource.Token).ConfigureAwait(false);
                        }
                        catch($e)
                        {
                            this.ClearCancellationToken();
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*void */ ClearCancellationToken()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._lock)
                    {
                        this._internalTokenSource = null;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._lock)
                }
            }
            /*void */ ThrowIfCompleted()
            {
                if (this._isReaderCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                this.ThrowIfCompleted();
                return this.TryReadInternal(this.InternalTokenSource, result);
            }
            /*bool */ TryReadInternal(/*CancellationTokenSource*/ source, /*out ReadResult*/ result)
            {
                /*bool*/ let isCancellationRequested = source.IsCancellationRequested;
                if (isCancellationRequested || (this._bufferedBytes > 0n && !this._examinedEverything))
                {
                    if (isCancellationRequested)
                    {
                        this.ClearCancellationToken();
                    }
                    /*ReadOnlySequence<byte>*/ let buffer = this.GetCurrentReadOnlySequence();
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$3(buffer, isCancellationRequested, false);
                    return true;
                }
                result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                return false;
            }
            /*ReadOnlySequence<byte> */ GetCurrentReadOnlySequence()
            {
                return this._readHead === null ? new ($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte))() : new ($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte))().$ctor$7(this._readHead, this._readIndex, this._readTail, this._readTail.End);
            }
            /*void */ AllocateReadTail(/*int?*/ minimumSize)
            {
                if (this._readHead === null)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._readTail === null, "_readTail == null");
                    this._readHead = this.AllocateSegment(minimumSize);
                    this._readTail = this._readHead;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._readTail !== null, "_readTail != null");
                    if (this._readTail.WritableBytes < this.MinimumReadThreshold)
                    {
                        /*BufferSegment*/ let nextSegment = this.AllocateSegment(minimumSize);
                        this._readTail.SetNext(nextSegment);
                        this._readTail = nextSegment;
                    }
                }
            }
            /*BufferSegment */ AllocateSegment(/*int?*/ minimumSize)
            {
                /*BufferSegment*/ let nextSegment = this.CreateSegmentUnsynchronized();
                /*var*/ let bufferSize = minimumSize ?? this.BufferSize;
                /*int*/ let maxSize = !this._options.IsDefaultSharedMemoryPool ? this._options.Pool.MaxBufferSize : -1;
                if (bufferSize <= maxSize)
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(bufferSize, maxSize);
                    nextSegment.SetOwnedMemory(this._options.Pool.Rent(sizeToRequest));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(bufferSize, this.MaxBufferSize);
                    nextSegment.SetOwnedMemory$1($.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(sizeToRequest));
                }
                return nextSegment;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$$.System.Math.Max$4(this.BufferSize, sizeHint);
                /*int*/ let adjustedToMaximumSize = $.$$.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(segment !== this._readHead, "Returning _readHead segment that's in use!");
                $.$$.System.Diagnostics.Debug.Assert$2(segment !== this._readTail, "Returning _readTail segment that's in use!");
                segment.Reset();
                if (this._bufferSegmentPool.Count < 256/*MaxSegmentPoolSize*/)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*void */ Cancel()
            {
                this.InternalTokenSource.Cancel();
            }
            //default member initializer
            constructor()
            {
                super();
                this._lock = new $.$$.System.Object().$ctor();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
            }
            static $h = 2002922;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1413098,"p":[{"p":262145,"g":{"r":0,"d":0,"h":64426512362,"f":50331650},"n":"LeaveOpen","d":2002922,"h":60131545066,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":73016446954,"f":50331650},"n":"UseZeroByteReads","d":2002922,"h":68721479658,"f":2097154},{"p":655361,"g":{"r":0,"d":0,"h":81606381546,"f":50331650},"n":"BufferSize","d":2002922,"h":77311414250,"f":2097154},{"p":655361,"g":{"r":0,"d":0,"h":90196316138,"f":50331650},"n":"MaxBufferSize","d":2002922,"h":85901348842,"f":2097154},{"p":655361,"g":{"r":0,"d":0,"h":98786250730,"f":50331650},"n":"MinimumReadThreshold","d":2002922,"h":94491283434,"f":2097154},{"p":$.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":107376185322,"f":50331650},"n":"Pool","d":2002922,"h":103081218026,"f":2097154},{"p":62193665,"g":{"r":0,"d":0,"h":120261087210,"f":50331649},"n":"InnerStream","d":2002922,"h":115966119914,"f":2097153},{"p":125960193,"g":{"r":0,"d":0,"h":133145989098,"f":50331650},"n":"InternalTokenSource","d":2002922,"h":128851021802,"f":2097154}],"m":[{"r":65537,"p":[{"n":"consumed","p":1220103}],"n":"AdvanceTo","o":"@$1","d":2002922,"h":124556054506,"f":16809985},{"r":65537,"p":[{"n":"consumed","p":1220103},{"n":"examined","p":1220103}],"n":"AdvanceTo","d":2002922,"h":137440956394,"f":16809985},{"r":65537,"p":[{"n":"consumedSegment","p":102378},{"n":"consumedIndex","p":655361},{"n":"examinedSegment","p":102378},{"n":"examinedIndex","p":655361}],"n":"AdvanceTo","o":"@$2","d":2002922,"h":141735923690,"f":16777218},{"r":65537,"n":"CancelPendingRead","d":2002922,"h":146030890986,"f":16809985},{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":2002922,"h":150325858282,"f":16809985},{"r":135987201,"p":[{"n":"exception","p":47251457,"f":65}],"n":"CompleteAsync","d":2002922,"h":154620825578,"f":16809985},{"r":262145,"n":"CompleteAndGetNeedsDispose","d":2002922,"h":158915792874,"f":16777218},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","d":2002922,"h":163210760170,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAtLeastAsyncCore","d":2002922,"h":167505727466,"f":16809988},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":$.$typeNullable($.$$.System.Int32).$h},{"n":"cancellationToken","p":125829121}],"n":"ReadInternalAsync","d":2002922,"h":171800694762,"f":16777218},{"r":133169153,"p":[{"n":"destination","p":1609706},{"n":"cancellationToken","p":125829121,"f":65}],"n":"CopyToAsync","o":"@$1","d":2002922,"h":176095662058,"f":16814081},{"r":133169153,"p":[{"n":"destination","p":62193665},{"n":"cancellationToken","p":125829121,"f":65}],"n":"CopyToAsync","d":2002922,"h":180390629354,"f":16814081},{"r":65537,"n":"ClearCancellationToken","d":2002922,"h":184685596650,"f":16777218},{"r":65537,"n":"ThrowIfCompleted","d":2002922,"h":188980563946,"f":16777218},{"r":262145,"p":[{"n":"result","p":1740778,"f":2}],"n":"TryRead","d":2002922,"h":193275531242,"f":16809985},{"r":262145,"p":[{"n":"source","p":125960193},{"n":"result","p":1740778,"f":2}],"n":"TryReadInternal","d":2002922,"h":197570498538,"f":16777218},{"r":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,"n":"GetCurrentReadOnlySequence","d":2002922,"h":201865465834,"f":16777218},{"r":65537,"p":[{"n":"minimumSize","p":$.$typeNullable($.$$.System.Int32).$h,"f":65}],"n":"AllocateReadTail","d":2002922,"h":206160433130,"f":16777218},{"r":102378,"p":[{"n":"minimumSize","p":$.$typeNullable($.$$.System.Int32).$h,"f":65}],"n":"AllocateSegment","d":2002922,"h":210455400426,"f":16777218},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361}],"n":"GetSegmentSize","d":2002922,"h":214750367722,"f":16777218},{"r":102378,"n":"CreateSegmentUnsynchronized","d":2002922,"h":219045335018,"f":16777218},{"r":65537,"p":[{"n":"segment","p":102378}],"n":"ReturnSegmentUnsynchronized","d":2002922,"h":223340302314,"f":16777218},{"r":65537,"n":"Cancel","d":2002922,"h":227635269610,"f":16777218}],"l":[{"t":655361,"n":"InitialSegmentPoolSize","d":2002922,"h":4296970218,"f":4194344},{"t":655361,"n":"MaxSegmentPoolSize","d":2002922,"h":8591937514,"f":4194344},{"t":125960193,"n":"_internalTokenSource","d":2002922,"h":12886904810,"f":4194306},{"t":262145,"n":"_isReaderCompleted","d":2002922,"h":17181872106,"f":4194306},{"t":102378,"n":"_readHead","d":2002922,"h":21476839402,"f":4194306},{"t":655361,"n":"_readIndex","d":2002922,"h":25771806698,"f":4194306},{"t":102378,"n":"_readTail","d":2002922,"h":30066773994,"f":4194306},{"t":917505,"n":"_bufferedBytes","d":2002922,"h":34361741290,"f":4194306},{"t":262145,"n":"_examinedEverything","d":2002922,"h":38656708586,"f":4194306},{"t":131073,"n":"_lock","d":2002922,"h":42951675882,"f":4194306},{"t":167914,"n":"_bufferSegmentPool","d":2002922,"h":47246643178,"f":4194306},{"t":2068458,"n":"_options","d":2002922,"h":51541610474,"f":4194306}],"c":[{"p":[{"n":"readingStream","p":62193665},{"n":"options","p":2068458}],"n":".ctor","o":"$ctor$2","d":2002922,"h":55836577770,"f":16777217}],"h":2002922}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeReader`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeCompletion", ($self) => class PipeCompletion extends $.$$.System.ValueType
        {
            /*object*/ static s_completedSuccessfully = null;
            /*object?*/  get _state() { return this.$getField(0, 4); }
            /*object?*/  set _state(value) { this.$setField(0, 4, value); }
            /*List<PipeCompletionCallback>?*/  get _callbacks() { return this.$getField(4, 4); }
            /*List<PipeCompletionCallback>?*/  set _callbacks(value) { this.$setField(4, 4, value); }
            /*bool */ get IsCompleted()
            {
                return this._state !== null;
            }
            /*bool */ get IsFaulted()
            {
                return $.$is(this._state, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo);
            }
            /*PipeCompletionCallbacks? */ TryComplete(/*Exception?*/ exception)
            {
                if (this._state === null)
                {
                    if (exception !== null)
                    {
                        this._state = $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exception);
                    }
                    else 
                    {
                        this._state = $.$sipl.System.IO.Pipelines.PipeCompletion.s_completedSuccessfully;
                    }
                }
                return this.GetCallbacks();
            }
            /*PipeCompletionCallbacks? */ AddCallback(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                this._callbacks ??= new ($.$$.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback))().$ctor$1();
                this._callbacks.Add(new $.$sipl.System.IO.Pipelines.PipeCompletionCallback().$ctor$3(callback, state));
                if (this.IsCompleted)
                {
                    return this.GetCallbacks();
                }
                return null;
            }
            /*bool */ IsCompletedOrThrow()
            {
                if (!this.IsCompleted)
                {
                    return false;
                }
                let edi;
                if ($.$is(this._state, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo, { set $v(v){ edi = v; } }))
                {
                    edi.Throw();
                }
                return true;
            }
            /*PipeCompletionCallbacks? */ GetCallbacks()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.IsCompleted, "IsCompleted");
                /*var*/ let callbacks = this._callbacks;
                if (callbacks === null)
                {
                    return null;
                }
                this._callbacks = null;
                return new $.$sipl.System.IO.Pipelines.PipeCompletionCallbacks().$ctor$1(callbacks, $.$as(this._state, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo));
            }
            /*void */ Reset()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.IsCompleted, "IsCompleted");
                $.$$.System.Diagnostics.Debug.Assert$2(this._callbacks === null, "_callbacks == null");
                this._state = null;
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `${"IsCompleted"}: ${this.IsCompleted}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sipl.System.IO.Pipelines.PipeCompletion.ToString.apply(this, arguments); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._state = this._state;
                copy._callbacks = this._callbacks;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = null;
                this._callbacks = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_completedSuccessfully = new $.$$.System.Object().$ctor();
                }
            }
            static $h = 1019882;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475856362,"f":50331649},"n":"IsCompleted","d":1019882,"h":17180889066,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":30065790954,"f":50331649},"n":"IsFaulted","d":1019882,"h":25770823658,"f":2097153}],"m":[{"r":1150954,"p":[{"n":"exception","p":47251457,"f":65}],"n":"TryComplete","d":1019882,"h":34360758250,"f":16777217},{"r":1150954,"p":[{"n":"callback","p":$.$$.System.Action$$$($.$$.System.Exception, $.$$.System.Object).$h},{"n":"state","p":131073}],"n":"AddCallback","d":1019882,"h":38655725546,"f":16777217},{"r":262145,"n":"IsCompletedOrThrow","d":1019882,"h":42950692842,"f":16777217},{"r":1150954,"n":"GetCallbacks","d":1019882,"h":47245660138,"f":16777218},{"r":65537,"n":"Reset","d":1019882,"h":51540627434,"f":16777217},{"r":1310721,"n":"ToString","d":1019882,"h":55835594730,"f":16809985}],"l":[{"t":131073,"n":"s_completedSuccessfully","d":1019882,"h":4295987178,"f":4194338},{"t":131073,"n":"_state","d":1019882,"h":8590954474,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h,"n":"_callbacks","d":1019882,"h":12885921770,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":1019882,"h":60130562026,"f":16777217}],"h":1019882,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"IsCompleted = {IsCompleted}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletion`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeWriterStream", ($self) => class PipeWriterStream extends $.$$.System.IO.Stream
        {
            /*PipeWriter*/ _pipeWriter = null;
            $ctor$3(/*PipeWriter*/ pipeWriter, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(pipeWriter !== null, "pipeWriter != null");
                    this._pipeWriter = pipeWriter;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this.LeaveOpen)
                {
                    this._pipeWriter.Complete(null);
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                if (!this.LeaveOpen)
                {
                    return this._pipeWriter.CompleteAsync(null);
                }
                return new $.$$.System.Threading.Tasks.ValueTask();
            }
            /*bool*/ LeaveOpen = false;
            /*bool */ get CanRead()
            {
                return false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return true;
            }
            /*long */ get Length()
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*long */ get Position()
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ Flush()
            {
                this.FlushAsync().GetAwaiter().GetResult();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                return $.$$.System.Threading.Tasks.TaskToAsyncResult.Begin(this.WriteAsync(buffer, offset, count, new $.$$.System.Threading.CancellationToken()), callback, state);
            }
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                return $.$$.System.Threading.Tasks.TaskToAsyncResult.End(asyncResult);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                return this.WriteAsync$1(buffer, offset, count).GetAwaiter().GetResult();
            }
            /*Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.WriteAsync(new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))().$ctor$4(buffer, offset, count), cancellationToken);
                return $.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.WriteAsync(buffer, cancellationToken);
                return new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask));
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.FlushAsync(cancellationToken);
                return $.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask);
            }
            static /*Task */ GetFlushResultAsTask(/*ValueTask<FlushResult>*/ valueTask)
            {
                if (valueTask.IsCompletedSuccessfully)
                {
                    /*FlushResult*/ let result = valueTask.Result;
                    if (result.IsCanceled)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                    }
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                /*static Task*/ /*async*/  function AwaitTask(/*ValueTask<FlushResult>*/ valueTask)
                {
                    return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                    {
                        /*FlushResult*/ let result = await valueTask.ConfigureAwait(false);
                        if (result.IsCanceled)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                        }
                    });
                }
                return AwaitTask(valueTask);
            }
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            static $h = 1675242;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066446314,"f":50331656},"s":{"r":0,"d":0,"h":34361413610,"f":83886088},"n":"LeaveOpen","d":1675242,"h":25771479018,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":42951348202,"f":50364417},"n":"CanRead","d":1675242,"h":38656380906,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":51541282794,"f":50364417},"n":"CanSeek","d":1675242,"h":47246315498,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":60131217386,"f":50364417},"n":"CanWrite","d":1675242,"h":55836250090,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":68721151978,"f":50364417},"n":"Length","d":1675242,"h":64426184682,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":77311086570,"f":50364417},"s":{"r":0,"d":0,"h":81606053866,"f":83918849},"n":"Position","d":1675242,"h":73016119274,"f":2129921}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1675242,"h":12886577130,"f":16809988},{"r":135987201,"n":"DisposeAsync","d":1675242,"h":17181544426,"f":16809985},{"r":65537,"n":"Flush","d":1675242,"h":85901021162,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1675242,"h":90195988458,"f":16809985},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1675242,"h":94490955754,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1675242,"h":98785923050,"f":16809985},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginWrite","d":1675242,"h":103080890346,"f":16875521},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":1675242,"h":107375857642,"f":16875521},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1675242,"h":111670824938,"f":16809985},{"r":133169153,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"WriteAsync","d":1675242,"h":115965792234,"f":16809985},{"r":135987201,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","o":"@$2","d":1675242,"h":120260759530,"f":16809985},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"FlushAsync","o":"@$1","d":1675242,"h":124555726826,"f":16809985},{"r":133169153,"p":[{"n":"valueTask","p":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h}],"n":"GetFlushResultAsTask","d":1675242,"h":128850694122,"f":16777250}],"l":[{"t":1609706,"n":"_pipeWriter","d":1675242,"h":4296642538,"f":4194306}],"c":[{"p":[{"n":"pipeWriter","p":1609706},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":1675242,"h":8591609834,"f":16777217}],"i":[57540609,56950785],"h":1675242}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeWriterStream`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeReaderStream", ($self) => class PipeReaderStream extends $.$$.System.IO.Stream
        {
            /*PipeReader*/ _pipeReader = null;
            $ctor$3(/*PipeReader*/ pipeReader, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(pipeReader !== null, "pipeReader != null");
                    this._pipeReader = pipeReader;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this.LeaveOpen)
                {
                    this._pipeReader.Complete(null);
                }
                super.Dispose$1(disposing);
            }
            /*bool */ get CanRead()
            {
                return true;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*long */ get Length()
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*long */ get Position()
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*bool*/ LeaveOpen = false;
            /*void */ Flush()
            {
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                return this.ReadInternal(new ($.$$.System.Span$$($.$$.System.Byte))().$ctor$3(buffer, offset, count));
            }
            /*int */ ReadByte()
            {
                /*Span<byte>*/ let oneByte = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 1, null);
                return this.ReadInternal(oneByte) === 0 ? -1 : oneByte.get_Item(0).$v;
            }
            /*int */ ReadInternal(/*Span<byte>*/ buffer)
            {
                /*ValueTask<ReadResult>*/ let vt = this._pipeReader.ReadAsync(new $.$$.System.Threading.CancellationToken());
                /*ReadResult*/ let result = vt.IsCompletedSuccessfully ? vt.Result : vt.AsTask().GetAwaiter$1().GetResult();
                return this.HandleReadResult(result, buffer);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                return $.$$.System.Threading.Tasks.TaskToAsyncResult.Begin(this.ReadAsync(buffer, offset, count, new $.$$.System.Threading.CancellationToken()), callback, state);
            }
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                return $.$$.System.Threading.Tasks.TaskToAsyncResult.End$1($.$$.System.Int32, asyncResult);
            }
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                return this.ReadAsyncInternal(new ($.$$.System.Memory$$($.$$.System.Byte))().$ctor$5(buffer, offset, count), cancellationToken).AsTask();
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                return this.ReadInternal(buffer);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadAsyncInternal(buffer, cancellationToken);
            }
            /*ValueTask<int> *//*async*/  ReadAsyncInternal(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    /*ReadResult*/ let result = await this._pipeReader.ReadAsync(cancellationToken).ConfigureAwait(false);
                    return this.HandleReadResult(result, buffer.Span);
                });
            }
            /*int */ HandleReadResult(/*ReadResult*/ result, /*Span<byte>*/ buffer)
            {
                if (result.IsCanceled)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                }
                /*ReadOnlySequence<byte>*/ let sequence = result.Buffer;
                /*long*/ let bufferLength = sequence.Length;
                /*SequencePosition*/ let consumed = sequence.Start;
                try
                {
                    if (bufferLength !== 0n)
                    {
                        /*int*/ let actual = $.$cast($.$$.System.Math.Min$5(bufferLength, BigInt(buffer.Length)), $.$$.System.Int32);
                        /*ReadOnlySequence<byte>*/ let slice = BigInt(actual) === bufferLength ? sequence : sequence.Slice(0, actual);
                        consumed = slice.End;
                        $.$sm.System.Buffers.BuffersExtensions.CopyTo($.$$.System.Byte, $.$ref(() => slice, ), buffer);
                        return actual;
                    }
                    if (result.IsCompleted)
                    {
                        return 0;
                    }
                }
                finally
                {
                    {
                        this._pipeReader.AdvanceTo$1(consumed);
                    }
                }
                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_InvalidZeroByteRead();
                return 0;
            }
            /*Task */ CopyToAsync(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                $.$sipl.System.IO.StreamHelpers.ValidateCopyToArgs(this, destination, bufferSize);
                return this._pipeReader.CopyToAsync(destination, cancellationToken);
            }
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            static $h = 1478634;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476315114,"f":50364417},"n":"CanRead","d":1478634,"h":17181347818,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":30066249706,"f":50364417},"n":"CanSeek","d":1478634,"h":25771282410,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":38656184298,"f":50364417},"n":"CanWrite","d":1478634,"h":34361217002,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":47246118890,"f":50364417},"n":"Length","d":1478634,"h":42951151594,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":55836053482,"f":50364417},"s":{"r":0,"d":0,"h":60131020778,"f":83918849},"n":"Position","d":1478634,"h":51541086186,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":73015922666,"f":50331656},"s":{"r":0,"d":0,"h":77310889962,"f":83886088},"n":"LeaveOpen","d":1478634,"h":68720955370,"f":2097160}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1478634,"h":12886380522,"f":16809988},{"r":65537,"n":"Flush","d":1478634,"h":81605857258,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1478634,"h":85900824554,"f":16809985},{"r":655361,"n":"ReadByte","d":1478634,"h":90195791850,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"ReadInternal","d":1478634,"h":94490759146,"f":16777218},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1478634,"h":98785726442,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1478634,"h":103080693738,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1478634,"h":107375661034,"f":16809985},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginRead","d":1478634,"h":111670628330,"f":16875521},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":1478634,"h":115965595626,"f":16875521},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","d":1478634,"h":120260562922,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"Read","o":"@$1","d":1478634,"h":124555530218,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","o":"@$2","d":1478634,"h":128850497514,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121}],"n":"ReadAsyncInternal","d":1478634,"h":133145464810,"f":16781314},{"r":655361,"p":[{"n":"result","p":1740778},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"HandleReadResult","d":1478634,"h":137440432106,"f":16777218},{"r":133169153,"p":[{"n":"destination","p":62193665},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125829121}],"n":"CopyToAsync","d":1478634,"h":141735399402,"f":16809985}],"l":[{"t":1413098,"n":"_pipeReader","d":1478634,"h":4296445930,"f":4194306}],"c":[{"p":[{"n":"pipeReader","p":1413098},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":1478634,"h":8591413226,"f":16777217}],"i":[57540609,56950785],"h":1478634}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeReaderStream`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ResultFlags", ($self) => class ResultFlags extends $.$$.System.Enum
        {
            static None = 0;
            static Canceled = 1;
            static Completed = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Canceled": 1n,
                    "Completed": 2n
                };
            }
            static $h = 1806314;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":1806314,"n":"None","d":1806314,"h":4296773610,"f":4194337},{"t":1806314,"n":"Canceled","d":1806314,"h":8591740906,"f":4194337},{"t":1806314,"n":"Completed","d":1806314,"h":12886708202,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1806314,"h":17181675498,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1806314,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipelines.ResultFlags`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ExceptionArgument", ($self) => class ExceptionArgument extends $.$$.System.Enum
        {
            static minimumSize = 0;
            static bytes = 1;
            static callback = 2;
            static options = 3;
            static pauseWriterThreshold = 4;
            static resumeWriterThreshold = 5;
            static sizeHint = 6;
            static destination = 7;
            static buffer = 8;
            static source = 9;
            static readingStream = 10;
            static writingStream = 11;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "minimumSize": 0n,
                    "bytes": 1n,
                    "callback": 2n,
                    "options": 3n,
                    "pauseWriterThreshold": 4n,
                    "resumeWriterThreshold": 5n,
                    "sizeHint": 6n,
                    "destination": 7n,
                    "buffer": 8n,
                    "source": 9n,
                    "readingStream": 10n,
                    "writingStream": 11n
                };
            }
            static $h = 364522;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":364522,"n":"minimumSize","d":364522,"h":4295331818,"f":4194337},{"t":364522,"n":"bytes","d":364522,"h":8590299114,"f":4194337},{"t":364522,"n":"callback","d":364522,"h":12885266410,"f":4194337},{"t":364522,"n":"options","d":364522,"h":17180233706,"f":4194337},{"t":364522,"n":"pauseWriterThreshold","d":364522,"h":21475201002,"f":4194337},{"t":364522,"n":"resumeWriterThreshold","d":364522,"h":25770168298,"f":4194337},{"t":364522,"n":"sizeHint","d":364522,"h":30065135594,"f":4194337},{"t":364522,"n":"destination","d":364522,"h":34360102890,"f":4194337},{"t":364522,"n":"buffer","d":364522,"h":38655070186,"f":4194337},{"t":364522,"n":"source","d":364522,"h":42950037482,"f":4194337},{"t":364522,"n":"readingStream","d":364522,"h":47245004778,"f":4194337},{"t":364522,"n":"writingStream","d":364522,"h":51539972074,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":364522,"h":55834939370,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":364522}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipelines.ExceptionArgument`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.BufferSegment", ($self) => class BufferSegment extends $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$$.System.Byte)
        {
            /*IMemoryOwner<byte>?*/ _memoryOwner = null;
            /*byte[]?*/ _array = null;
            /*BufferSegment?*/ _next = null;
            /*int*/ _end = 0;
            /*int */ get End()
            {
                return this._end;
            }
            /*int */ set End(value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(value <= this.AvailableMemory.Length, "value <= AvailableMemory.Length");
                this._end = value;
                this.Memory = $.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2(this.AvailableMemory.Slice(0, value));
            }
            /*BufferSegment? */ get NextSegment()
            {
                return this._next;
            }
            /*BufferSegment? */ set NextSegment(value)
            {
                this.Next = value;
                this._next = value;
            }
            /*void */ SetOwnedMemory(/*IMemoryOwner<byte>*/ memoryOwner)
            {
                this._memoryOwner = memoryOwner;
                this.AvailableMemory = memoryOwner.System$Buffers$IMemoryOwner$$$Memory;
            }
            /*void */ SetOwnedMemory$1(/*byte[]*/ arrayPoolBuffer)
            {
                this._array = arrayPoolBuffer;
                this.AvailableMemory = $.$$.System.Memory$$($.$$.System.Byte).op_Implicit$1(arrayPoolBuffer);
            }
            /*void */ Reset()
            {
                this.ResetMemory();
                this.Next = null;
                this.RunningIndex = 0n;
                this._next = null;
            }
            /*void */ ResetMemory()
            {
                /*IMemoryOwner<byte>?*/ let memoryOwner = this._memoryOwner;
                if (memoryOwner !== null)
                {
                    this._memoryOwner = null;
                    memoryOwner.System$IDisposable$Dispose();
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._array !== null, "_array != null");
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(this._array, false);
                    this._array = null;
                }
                this.Memory = new ($.$$.System.ReadOnlyMemory$$($.$$.System.Byte))();
                this._end = 0;
                this.AvailableMemory = new ($.$$.System.Memory$$($.$$.System.Byte))();
            }
            /*object? */ get MemoryOwner()
            {
                return $.$cast(this._memoryOwner, $.$$.System.Object) ?? this._array;
            }
            /*Memory<byte>*/ AvailableMemory;
            /*int */ get Length()
            {
                return this.End;
            }
            /*int */ get WritableBytes()
            {
                return ((this.AvailableMemory.Length - this.End) | 0);
            }
            /*void */ SetNext(/*BufferSegment*/ segment)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(segment !== null, "segment != null");
                $.$$.System.Diagnostics.Debug.Assert$2(this.Next === null, "Next == null");
                this.NextSegment = segment;
                segment = this;
                while(segment.Next !== null)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(segment.NextSegment !== null, "segment.NextSegment != null");
                    segment.NextSegment.RunningIndex = segment.RunningIndex + BigInt(segment.Length);
                    segment = segment.NextSegment;
                }
            }
            static /*long */ GetLength$1(/*BufferSegment*/ startSegment, /*int*/ startIndex, /*BufferSegment*/ endSegment, /*int*/ endIndex)
            {
                return (endSegment.RunningIndex + BigInt((endIndex >>> 0))) - (startSegment.RunningIndex + BigInt((startIndex >>> 0)));
            }
            static /*long */ GetLength(/*long*/ startPosition, /*BufferSegment*/ endSegment, /*int*/ endIndex)
            {
                return (endSegment.RunningIndex + BigInt((endIndex >>> 0))) - startPosition;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.AvailableMemory = $.$default($.$$.System.Memory$$($.$$.System.Byte));
            }
            static $h = 102378;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":655361,"g":{"r":0,"d":0,"h":25769906154,"f":50331649},"s":{"r":0,"d":0,"h":30064873450,"f":83886081},"n":"End","d":102378,"h":21474938858,"f":2097153},{"p":102378,"g":{"r":0,"d":0,"h":38654808042,"f":50331649},"s":{"r":0,"d":0,"h":42949775338,"f":83886081},"n":"NextSegment","d":102378,"h":34359840746,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":68719579114,"f":50331656},"n":"MemoryOwner","d":102378,"h":64424611818,"f":2097160},{"p":$.$$.System.Memory$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":81604481002,"f":50331649},"s":{"r":0,"d":0,"h":85899448298,"f":83886082},"n":"AvailableMemory","d":102378,"h":77309513706,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":94489382890,"f":50331649},"n":"Length","d":102378,"h":90194415594,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":103079317482,"f":50331649},"n":"WritableBytes","d":102378,"h":98784350186,"f":2097153}],"m":[{"r":65537,"p":[{"n":"memoryOwner","p":$.$$.System.Buffers.IMemoryOwner$$($.$$.System.Byte).$h}],"n":"SetOwnedMemory","d":102378,"h":47244742634,"f":16777217},{"r":65537,"p":[{"n":"arrayPoolBuffer","p":$.$typeArray($.$$.System.Byte).$h}],"n":"SetOwnedMemory","o":"@$1","d":102378,"h":51539709930,"f":16777217},{"r":65537,"n":"Reset","d":102378,"h":55834677226,"f":16777217},{"r":65537,"n":"ResetMemory","d":102378,"h":60129644522,"f":16777217},{"r":65537,"p":[{"n":"segment","p":102378}],"n":"SetNext","d":102378,"h":107374284778,"f":16777217},{"r":917505,"p":[{"n":"startSegment","p":102378},{"n":"startIndex","p":655361},{"n":"endSegment","p":102378},{"n":"endIndex","p":655361}],"n":"GetLength","o":"@$1","d":102378,"h":111669252074,"f":16777256},{"r":917505,"p":[{"n":"startPosition","p":917505},{"n":"endSegment","p":102378},{"n":"endIndex","p":655361}],"n":"GetLength","d":102378,"h":115964219370,"f":16777256}],"l":[{"t":$.$$.System.Buffers.IMemoryOwner$$($.$$.System.Byte).$h,"n":"_memoryOwner","d":102378,"h":4295069674,"f":4194306},{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_array","d":102378,"h":8590036970,"f":4194306},{"t":102378,"n":"_next","d":102378,"h":12885004266,"f":4194306},{"t":655361,"n":"_end","d":102378,"h":17179971562,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":102378,"h":120259186666,"f":16777217}],"h":102378}; }
            static get $b() { return $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$$.System.Byte); }
            static get $fullName() { return `System.IO.Pipelines.BufferSegment`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeWriter", ($self) => class StreamPipeWriter extends $.$sipl.System.IO.Pipelines.PipeWriter
        {
            /*int*/ static InitialSegmentPoolSize = 4;
            /*int*/ static MaxSegmentPoolSize = 256;
            /*int*/ _minimumBufferSize = 0;
            /*BufferSegment?*/ _head = null;
            /*BufferSegment?*/ _tail = null;
            /*Memory<byte>*/ _tailMemory;
            /*int*/ _tailBytesBuffered = 0;
            /*long*/ _bytesBuffered = 0n;
            /*MemoryPool<byte>?*/ _pool = null;
            /*int*/ _maxPooledBufferSize = 0;
            /*CancellationTokenSource?*/ _internalTokenSource = null;
            /*bool*/ _isCompleted = false;
            /*object*/ _lockObject = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*bool*/ _leaveOpen = false;
            /*CancellationTokenSource */ get InternalTokenSource()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._lockObject)
                    {
                        return this._internalTokenSource ??= new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._lockObject)
                }
            }
            $ctor$2(/*Stream*/ writingStream, /*StreamPipeWriterOptions*/ options)
            {
                super.$ctor$1();
                {
                    if (writingStream === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(11/*ExceptionArgument.writingStream*/);
                    }
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this.InnerStream = writingStream;
                    this._minimumBufferSize = options.MinimumBufferSize;
                    this._pool = options.Pool === $.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).Shared ? null : options.Pool;
                    this._maxPooledBufferSize = (this._pool?.MaxBufferSize ?? null) ?? -1;
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$3(4/*InitialSegmentPoolSize*/);
                    this._leaveOpen = options.LeaveOpen;
                }
                return this;
            }
            /*Stream*/ InnerStream = null;
            /*void */ Advance(/*int*/ bytes)
            {
                if ((bytes >>> 0) > (this._tailMemory.Length >>> 0))
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.bytes*/);
                }
                this._tailBytesBuffered += bytes;
                this._bytesBuffered += BigInt(bytes);
                this._tailMemory = this._tailMemory.Slice$1(bytes);
            }
            /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
            {
                if (this._isCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateMemory(sizeHint);
                return this._tailMemory;
            }
            /*Span<byte> */ GetSpan(/*int*/ sizeHint)
            {
                if (this._isCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateMemory(sizeHint);
                return this._tailMemory.Span;
            }
            /*void */ AllocateMemory(/*int*/ sizeHint)
            {
                if (this._head === null)
                {
                    /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                    this._head = this._tail = newSegment;
                    this._tailBytesBuffered = 0;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._tail !== null, "_tail != null");
                    /*int*/ let bytesLeftInBuffer = this._tailMemory.Length;
                    if (bytesLeftInBuffer === 0 || bytesLeftInBuffer < sizeHint)
                    {
                        if (this._tailBytesBuffered > 0)
                        {
                            this._tail.End += this._tailBytesBuffered;
                            this._tailBytesBuffered = 0;
                        }
                        /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                        this._tail.SetNext(newSegment);
                        this._tail = newSegment;
                    }
                }
            }
            /*BufferSegment */ AllocateSegment(/*int*/ sizeHint)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(sizeHint >= 0, "sizeHint >= 0");
                /*BufferSegment*/ let newSegment = this.CreateSegmentUnsynchronized();
                /*int*/ let maxSize = this._maxPooledBufferSize;
                if (sizeHint <= maxSize)
                {
                    newSegment.SetOwnedMemory(this._pool.Rent(this.GetSegmentSize(sizeHint, maxSize)));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(sizeHint, 2147483647);
                    newSegment.SetOwnedMemory$1($.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(sizeToRequest));
                }
                this._tailMemory = newSegment.AvailableMemory;
                return newSegment;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$$.System.Math.Max$4(this._minimumBufferSize, sizeHint);
                /*var*/ let adjustedToMaximumSize = $.$$.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                segment.Reset();
                if (this._bufferSegmentPool.Count < 256/*MaxSegmentPoolSize*/)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*void */ CancelPendingFlush()
            {
                this.Cancel();
            }
            /*bool */ get CanGetUnflushedBytes()
            {
                return true;
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this._isCompleted)
                {
                    return;
                }
                this._isCompleted = true;
                try
                {
                    this.FlushInternal(exception === null);
                }
                finally
                {
                    {
                        this._internalTokenSource?.Dispose();
                        if (!this._leaveOpen)
                        {
                            this.InnerStream.Dispose();
                        }
                    }
                }
            }
            /*ValueTask *//*async*/  CompleteAsync(/*Exception?*/ exception)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    if (this._isCompleted)
                    {
                        return;
                    }
                    this._isCompleted = true;
                    try
                    {
                        await this.FlushAsyncInternal(exception === null, $.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.Memory$$($.$$.System.Byte).Empty), new $.$$.System.Threading.CancellationToken()).ConfigureAwait(false);
                    }
                    finally
                    {
                        {
                            this._internalTokenSource?.Dispose();
                            if (!this._leaveOpen)
                            {
                                await this.InnerStream.DisposeAsync().ConfigureAwait(false);
                            }
                        }
                    }
                });
            }
            /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
            {
                if (this._bytesBuffered === 0n)
                {
                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$6(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$3(false, false));
                }
                return this.FlushAsyncInternal(true, $.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.Memory$$($.$$.System.Byte).Empty), new $.$$.System.Threading.CancellationToken());
            }
            /*long */ get UnflushedBytes()
            {
                return this._bytesBuffered;
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                return this.FlushAsyncInternal(true, source, new $.$$.System.Threading.CancellationToken());
            }
            /*void */ Cancel()
            {
                this.InternalTokenSource.Cancel();
            }
            /*ValueTask<FlushResult> *//*async*/  FlushAsyncInternal(/*bool*/ writeToStream, /*ReadOnlyMemory<byte>*/ data, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult), $.$sipl.System.IO.Pipelines.FlushResult, async () => 
                {
                    /*CancellationTokenRegistration*/ let reg = new $.$$.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister$1(new ($.$$.System.Action$$($.$$.System.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeWriter)).Cancel();
                        }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":2133994,"h":0,"f":17825794}), this);
                    }
                    if (this._tailBytesBuffered > 0)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._tail !== null, "_tail != null");
                        this._tail.End += this._tailBytesBuffered;
                        this._tailBytesBuffered = 0;
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        /*CancellationToken*/ let localToken = this.InternalTokenSource.Token;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._head;
                            while(segment !== null)
                            {
                                /*BufferSegment*/ let returnSegment = segment;
                                segment = segment.NextSegment;
                                if (returnSegment.Length > 0 && writeToStream)
                                {
                                    await this.InnerStream.WriteAsync$2(returnSegment.Memory, localToken).ConfigureAwait(false);
                                }
                                this.ReturnSegmentUnsynchronized(returnSegment);
                                this._head = segment;
                            }
                            if (writeToStream)
                            {
                                if (data.Length > 0)
                                {
                                    await this.InnerStream.WriteAsync$2(data, localToken).ConfigureAwait(false);
                                }
                                if (this._bytesBuffered > 0n || data.Length > 0)
                                {
                                    await this.InnerStream.FlushAsync$1(localToken).ConfigureAwait(false);
                                }
                            }
                            this._head = null;
                            this._tail = null;
                            this._tailMemory = new ($.$$.System.Memory$$($.$$.System.Byte))();
                            this._bytesBuffered = 0n;
                            return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$3(false, false);
                        }
                        catch($e)
                        {
                            //lock
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter$1(this._lockObject)
                                {
                                    this._internalTokenSource = null;
                                }
                            }
                            finally
                            {
                                $.$$.System.Threading.Monitor.Exit(this._lockObject)
                            }
                            if (localToken.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
                            {
                                return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$3(true, false);
                            }
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*void */ FlushInternal(/*bool*/ writeToStream)
            {
                if (this._tailBytesBuffered > 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._tail !== null, "_tail != null");
                    this._tail.End += this._tailBytesBuffered;
                    this._tailBytesBuffered = 0;
                }
                /*BufferSegment?*/ let segment = this._head;
                while(segment !== null)
                {
                    /*BufferSegment*/ let returnSegment = segment;
                    segment = segment.NextSegment;
                    if (returnSegment.Length > 0 && writeToStream)
                    {
                        this.InnerStream.Write$1(returnSegment.Memory.Span);
                    }
                    this.ReturnSegmentUnsynchronized(returnSegment);
                    this._head = segment;
                }
                if (this._bytesBuffered > 0n && writeToStream)
                {
                    this.InnerStream.Flush();
                }
                this._head = null;
                this._tail = null;
                this._tailMemory = new ($.$$.System.Memory$$($.$$.System.Byte))();
                this._bytesBuffered = 0n;
            }
            //default member initializer
            constructor()
            {
                super();
                this._tailMemory = $.$default($.$$.System.Memory$$($.$$.System.Byte));
                this._lockObject = new $.$$.System.Object().$ctor();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
            }
            static $h = 2133994;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1609706,"p":[{"p":125960193,"g":{"r":0,"d":0,"h":73016578026,"f":50331650},"n":"InternalTokenSource","d":2133994,"h":68721610730,"f":2097154},{"p":62193665,"g":{"r":0,"d":0,"h":90196447210,"f":50331649},"n":"InnerStream","d":2133994,"h":85901479914,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":137441087466,"f":50364417},"n":"CanGetUnflushedBytes","d":2133994,"h":133146120170,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":158915923946,"f":50364417},"n":"UnflushedBytes","d":2133994,"h":154620956650,"f":2129921}],"m":[{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":2133994,"h":94491414506,"f":16809985},{"r":$.$$.System.Memory$$($.$$.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":2133994,"h":98786381802,"f":16809985},{"r":$.$$.System.Span$$($.$$.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":2133994,"h":103081349098,"f":16809985},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateMemory","d":2133994,"h":107376316394,"f":16777218},{"r":102378,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateSegment","d":2133994,"h":111671283690,"f":16777218},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361,"f":65,"v":2147483647}],"n":"GetSegmentSize","d":2133994,"h":115966250986,"f":16777218},{"r":102378,"n":"CreateSegmentUnsynchronized","d":2133994,"h":120261218282,"f":16777218},{"r":65537,"p":[{"n":"segment","p":102378}],"n":"ReturnSegmentUnsynchronized","d":2133994,"h":124556185578,"f":16777218},{"r":65537,"n":"CancelPendingFlush","d":2133994,"h":128851152874,"f":16809985},{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":2133994,"h":141736054762,"f":16809985},{"r":135987201,"p":[{"n":"exception","p":47251457,"f":65}],"n":"CompleteAsync","d":2133994,"h":146031022058,"f":16814081},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"FlushAsync","d":2133994,"h":150325989354,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","d":2133994,"h":163210891242,"f":16809985},{"r":65537,"n":"Cancel","d":2133994,"h":167505858538,"f":16777218},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"writeToStream","p":262145},{"n":"data","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"FlushAsyncInternal","d":2133994,"h":171800825834,"f":16781314,"a":[{"t":86507521,"c":4381474817,"a":[{"v":$.$$.System.Runtime.CompilerServices.PoolingAsyncValueTaskMethodBuilder$$().$h,"t":142475265}]}]},{"r":65537,"p":[{"n":"writeToStream","p":262145}],"n":"FlushInternal","d":2133994,"h":176095793130,"f":16777218}],"l":[{"t":655361,"n":"InitialSegmentPoolSize","d":2133994,"h":4297101290,"f":4194344},{"t":655361,"n":"MaxSegmentPoolSize","d":2133994,"h":8592068586,"f":4194344},{"t":655361,"n":"_minimumBufferSize","d":2133994,"h":12887035882,"f":4194306},{"t":102378,"n":"_head","d":2133994,"h":17182003178,"f":4194306},{"t":102378,"n":"_tail","d":2133994,"h":21476970474,"f":4194306},{"t":$.$$.System.Memory$$($.$$.System.Byte).$h,"n":"_tailMemory","d":2133994,"h":25771937770,"f":4194306},{"t":655361,"n":"_tailBytesBuffered","d":2133994,"h":30066905066,"f":4194306},{"t":917505,"n":"_bytesBuffered","d":2133994,"h":34361872362,"f":4194306},{"t":$.$sm.System.Buffers.MemoryPool$$($.$$.System.Byte).$h,"n":"_pool","d":2133994,"h":38656839658,"f":4194306},{"t":655361,"n":"_maxPooledBufferSize","d":2133994,"h":42951806954,"f":4194306},{"t":125960193,"n":"_internalTokenSource","d":2133994,"h":47246774250,"f":4194306},{"t":262145,"n":"_isCompleted","d":2133994,"h":51541741546,"f":4194306},{"t":131073,"n":"_lockObject","d":2133994,"h":55836708842,"f":4194306},{"t":167914,"n":"_bufferSegmentPool","d":2133994,"h":60131676138,"f":4194306},{"t":262145,"n":"_leaveOpen","d":2133994,"h":64426643434,"f":4194306}],"c":[{"p":[{"n":"writingStream","p":62193665},{"n":"options","p":2199530}],"n":".ctor","o":"$ctor$2","d":2133994,"h":77311545322,"f":16777217}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h],"h":2133994}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeWriter; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte) ]; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeWriter`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading", "NetJs.System.Threading.ThreadPool"))