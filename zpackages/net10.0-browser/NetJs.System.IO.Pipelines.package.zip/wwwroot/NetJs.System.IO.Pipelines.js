
(function ($global, $, $spc, $sc, $sm, $spu, $sr, $st, $sttp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Pipelines", 
    {"h":64673,"f":"System.IO.Pipelines","v":"1.0.35.0","a":[{"t":92405761,"c":4387373057,"a":[{"v":"System.IO.Pipelines.Tests, PublicKey=00240000048000009400000006020000002400005253413100040000010001004b86c4cb78549b34bab61a3b1800e23bfeb5b3ec390074041536a7e3cbd97f5f04cf0f857155a8928eaa29ebfd11cfbbad3ba70efea7bda3226c6a8d370a4cd303f714486b6ebc225985a638471e6ef571cc92a4613c00b8fa65d61ccee0cbe5f36330c9a01f4183559f1bef24cc2917c6d913e3a541333a1d05d9bed22b38cb","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Pipelines","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Pipelines","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sipl.System.IO.Pipelines.IDuplexPipe", ($self) => class IDuplexPipe
        {
            static $h = 523425;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1440929,"g":{"r":0,"d":0,"h":8590458017,"f":257},"n":"Input","o":"System$IO$Pipelines$IDuplexPipe$Input","d":523425,"h":4295490721,"f":257},{"p":1637537,"g":{"r":0,"d":0,"h":17180392609,"f":257},"n":"Output","o":"System$IO$Pipelines$IDuplexPipe$Output","d":523425,"h":12885425313,"f":257}],"h":523425}; }
            static get $fullName() { return `System.IO.Pipelines.IDuplexPipe`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeScheduler", ($self) => class PipeScheduler extends $.$spc.System.Object
        {
            /*ThreadPoolScheduler*/ static s_threadPoolScheduler = null;
            /*InlineScheduler*/ static s_inlineScheduler = null;
            static /*PipeScheduler */ get ThreadPool()
            {
                return $.$sipl.System.IO.Pipelines.PipeScheduler.s_threadPoolScheduler;
            }
            static /*PipeScheduler */ get Inline()
            {
                return $.$sipl.System.IO.Pipelines.PipeScheduler.s_inlineScheduler;
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                return this.Schedule(action, state);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_threadPoolScheduler = new $.$sipl.System.IO.Pipelines.ThreadPoolScheduler().$ctor$2();
                }
                {
                    this.s_inlineScheduler = new $.$sipl.System.IO.Pipelines.InlineScheduler().$ctor$2();
                }
            }
            static $h = 1572001;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1572001,"g":{"r":0,"d":0,"h":17181441185,"f":33},"n":"ThreadPool","d":1572001,"h":12886473889,"f":33},{"p":1572001,"g":{"r":0,"d":0,"h":25771375777,"f":33},"n":"Inline","d":1572001,"h":21476408481,"f":33}],"m":[{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":1572001,"h":30066343073,"f":257},{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":1572001,"h":34361310369,"f":136}],"l":[{"t":2292897,"n":"s_threadPoolScheduler","d":1572001,"h":4296539297,"f":34},{"t":588961,"n":"s_inlineScheduler","d":1572001,"h":8591506593,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":1572001,"h":38656277665,"f":4}],"h":1572001}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeScheduler`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeReader", ($self) => class PipeReader extends $.$spc.System.Object
        {
            /*PipeReaderStream?*/ _stream = null;
            /*ValueTask<ReadResult> */ ReadAtLeastAsync(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                if (minimumSize < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(0/*ExceptionArgument.minimumSize*/);
                }
                return this.ReadAtLeastAsyncCore(minimumSize, cancellationToken);
            }
            /*ValueTask<ReadResult> *//*async*/  ReadAtLeastAsyncCore(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult), $.$sipl.System.IO.Pipelines.ReadResult, async () => 
                {
                    while(true)
                    {
                        /*ReadResult*/ let result = await this.ReadAsync(cancellationToken).ConfigureAwait(false);
                        /*ReadOnlySequence<byte>*/ let buffer = result.Buffer;
                        if (buffer.Length >= BigInt(minimumSize) || result.IsCompleted || result.IsCanceled)
                        {
                            return result;
                        }
                        this.AdvanceTo$1(buffer.Start, buffer.End);
                    }
                });
            }
            /*Stream */ AsStream(/*bool*/ leaveOpen)
            {
                if (this._stream === null)
                {
                    this._stream = new $.$sipl.System.IO.Pipelines.PipeReaderStream().$ctor$3(this, leaveOpen);
                }
                else if (leaveOpen)
                {
                    this._stream.LeaveOpen = leaveOpen;
                }
                return this._stream;
            }
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                try
                {
                    this.Complete(exception);
                    return new $.$spc.System.Threading.Tasks.ValueTask();
                }
                catch(ex)
                {
                    return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException(ex));
                }
            }
            /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
            }
            static /*PipeReader */ Create(/*Stream*/ stream, /*StreamPipeReaderOptions?*/ readerOptions)
            {
                return new $.$sipl.System.IO.Pipelines.StreamPipeReader().$ctor$2(stream, readerOptions ?? $.$sipl.System.IO.Pipelines.StreamPipeReaderOptions.s_default);
            }
            static /*PipeReader */ Create$1(/*ReadOnlySequence<byte>*/ sequence)
            {
                return new $.$sipl.System.IO.Pipelines.SequencePipeReader().$ctor$2(sequence);
            }
            /*Task */ CopyToAsync(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this.CopyToAsyncCore($.$sipl.System.IO.Pipelines.PipeWriter, destination, new ($.$spc.System.Func$$$$$($.$sipl.System.IO.Pipelines.PipeWriter, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)))().$ctor(this,  (/*destination*/ destination, /*memory*/ memory, /*cancellationToken*/ cancellationToken) =>
                {
                    return destination.WriteAsync(memory, cancellationToken);
                }, {"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"destination","p":1637537},{"n":"memory","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"","d":1440929,"h":0,"f":1048578}), cancellationToken);
            }
            /*Task */ CopyToAsync$1(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this.CopyToAsyncCore($.$spc.System.IO.Stream, destination, new ($.$spc.System.Func$$$$$($.$spc.System.IO.Stream, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)))().$ctor(this,  (/*destination*/ destination, /*memory*/ memory, /*cancellationToken*/ cancellationToken) =>
                {
                    /*ValueTask*/ let task = destination.WriteAsync$2(memory, cancellationToken);
                    if (task.IsCompletedSuccessfully)
                    {
                        task.GetAwaiter().GetResult();
                        return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false));
                    }
                    /*static ValueTask<FlushResult>*/ /*async*/  function Awaited(/*ValueTask*/ writeTask)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult), $.$sipl.System.IO.Pipelines.FlushResult, async () => 
                        {
                            await writeTask.ConfigureAwait(false);
                            return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false);
                        });
                    }
                    return Awaited(task);
                }, {"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"destination","p":62193665},{"n":"memory","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"","d":1440929,"h":0,"f":1048578}), cancellationToken);
            }
            /*Task *//*async*/  CopyToAsyncCore(TStream, /*TStream*/ destination, /*Func<TStream, ReadOnlyMemory<byte>, CancellationToken, ValueTask<FlushResult>>*/ writeAsync, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    while(true)
                    {
                        /*ReadResult*/ let result = await this.ReadAsync(cancellationToken).ConfigureAwait(false);
                        /*ReadOnlySequence<byte>*/ let buffer = result.Buffer;
                        /*SequencePosition*/ let position = buffer.Start;
                        /*SequencePosition*/ let consumed = position;
                        try
                        {
                            if (result.IsCanceled)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                            }
                            /*ReadOnlyMemory<byte>*/ let memory;
                            while(buffer.TryGet($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => position, ($v) => position = $v, null), $.$ref(() => memory, ($v) => memory = $v, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte)), true))
                            {
                                if (memory.IsEmpty)
                                {
                                    consumed = position;
                                }
                                else 
                                {
                                    /*FlushResult*/ let flushResult = await writeAsync.Invoke(destination, memory, cancellationToken).ConfigureAwait(false);
                                    if (flushResult.IsCanceled)
                                    {
                                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                                    }
                                    consumed = position;
                                    if (flushResult.IsCompleted)
                                    {
                                        return;
                                    }
                                }
                            }
                            consumed = buffer.End;
                            if (result.IsCompleted)
                            {
                                break;
                            }
                        }
                        finally
                        {
                            {
                                this.AdvanceTo(consumed);
                            }
                        }
                    }
                });
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1440929;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"result","p":1768609,"f":2}],"n":"TryRead","d":1440929,"h":8591375521,"f":257},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":1440929,"h":12886342817,"f":257},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAtLeastAsync","d":1440929,"h":17181310113,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAtLeastAsyncCore","d":1440929,"h":21476277409,"f":4228},{"r":65537,"p":[{"n":"consumed","p":1244122}],"n":"AdvanceTo","d":1440929,"h":25771244705,"f":257},{"r":65537,"p":[{"n":"consumed","p":1244122},{"n":"examined","p":1244122}],"n":"AdvanceTo","o":"@$1","d":1440929,"h":30066212001,"f":257},{"r":62193665,"p":[{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":"AsStream","d":1440929,"h":34361179297,"f":129},{"r":65537,"n":"CancelPendingRead","d":1440929,"h":38656146593,"f":257},{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":1440929,"h":42951113889,"f":257},{"r":136118273,"p":[{"n":"exception","p":47251457,"f":65}],"n":"CompleteAsync","d":1440929,"h":47246081185,"f":129},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":1440929,"h":51541048481,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"OnWriterCompleted has been deprecated and may not be invoked on all implementations of PipeReader.","t":1310721}]}]},{"r":1440929,"p":[{"n":"stream","p":62193665},{"n":"readerOptions","p":2096289,"f":65}],"n":"Create","d":1440929,"h":55836015777,"f":33},{"r":1440929,"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h}],"n":"Create","o":"@$1","d":1440929,"h":60130983073,"f":33},{"r":133300225,"p":[{"n":"destination","p":1637537},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","d":1440929,"h":64425950369,"f":129},{"r":133300225,"p":[{"n":"destination","p":62193665},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","o":"@$1","d":1440929,"h":68720917665,"f":129},{"r":133300225,"p":[{"n":"destination","p":(TStream) => TStream.$h},{"n":"writeAsync","p":(TStream) => $.$spc.System.Func$$$$$(TStream, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)).$h},{"n":"cancellationToken","p":125960193}],"g":["TStream"],"n":"CopyToAsyncCore","d":1440929,"h":73015884961,"f":135170}],"l":[{"t":1506465,"n":"_stream","d":1440929,"h":4296408225,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1440929,"h":77310852257,"f":4}],"h":1440929}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeReader`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeWriter", ($self) => class PipeWriter extends $.$spc.System.Object
        {
            /*PipeWriterStream?*/ _stream = null;
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                try
                {
                    this.Complete(exception);
                    return new $.$spc.System.Threading.Tasks.ValueTask();
                }
                catch(ex)
                {
                    return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException(ex));
                }
            }
            /*bool */ get CanGetUnflushedBytes()
            {
                return false;
            }
            /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
            }
            /*Stream */ AsStream(/*bool*/ leaveOpen)
            {
                if (this._stream === null)
                {
                    this._stream = new $.$sipl.System.IO.Pipelines.PipeWriterStream().$ctor$3(this, leaveOpen);
                }
                else if (leaveOpen)
                {
                    this._stream.LeaveOpen = leaveOpen;
                }
                return this._stream;
            }
            static /*PipeWriter */ Create(/*Stream*/ stream, /*StreamPipeWriterOptions?*/ writerOptions)
            {
                return new $.$sipl.System.IO.Pipelines.StreamPipeWriter().$ctor$2(stream, writerOptions ?? $.$sipl.System.IO.Pipelines.StreamPipeWriterOptions.s_default);
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                $.$sm.System.Buffers.BuffersExtensions.Write($.$spc.System.Byte, this, source.Span);
                return this.FlushAsync(cancellationToken);
            }
            /*Task *//*async*/  CopyFromAsync(/*Stream*/ source, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    while(true)
                    {
                        /*Memory<byte>*/ let buffer = this.GetMemory(0);
                        /*int*/ let read = await source.ReadAsync$2(buffer, cancellationToken).ConfigureAwait(false);
                        if (read === 0)
                        {
                            break;
                        }
                        this.Advance(read);
                        /*FlushResult*/ let result = await this.FlushAsync(cancellationToken).ConfigureAwait(false);
                        if (result.IsCanceled)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                        }
                        if (result.IsCompleted)
                        {
                            break;
                        }
                    }
                });
            }
            /*long */ get UnflushedBytes()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateNotSupportedException_UnflushedBytes();
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.Advance(int)
            System$Buffers$IBufferWriter$$$Advance()
            {
                return this.Advance(...arguments);
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.GetMemory(int)
            System$Buffers$IBufferWriter$$$GetMemory()
            {
                return this.GetMemory(...arguments);
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.GetSpan(int)
            System$Buffers$IBufferWriter$$$GetSpan()
            {
                return this.GetSpan(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1637537;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771441313,"f":129},"n":"CanGetUnflushedBytes","d":1637537,"h":21476474017,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":73016081569,"f":129},"n":"UnflushedBytes","d":1637537,"h":68721114273,"f":129}],"m":[{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":1637537,"h":8591572129,"f":257},{"r":136118273,"p":[{"n":"exception","p":47251457,"f":65}],"n":"CompleteAsync","d":1637537,"h":12886539425,"f":129},{"r":65537,"n":"CancelPendingFlush","d":1637537,"h":17181506721,"f":257},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":1637537,"h":30066408609,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"OnReaderCompleted has been deprecated and may not be invoked on all implementations of PipeWriter.","t":1310721}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","d":1637537,"h":34361375905,"f":257},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":1637537,"h":38656343201,"f":257},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":1637537,"h":42951310497,"f":257},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":1637537,"h":47246277793,"f":257},{"r":62193665,"p":[{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":"AsStream","d":1637537,"h":51541245089,"f":129},{"r":1637537,"p":[{"n":"stream","p":62193665},{"n":"writerOptions","p":2227361,"f":65}],"n":"Create","d":1637537,"h":55836212385,"f":33},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","d":1637537,"h":60131179681,"f":129},{"r":133300225,"p":[{"n":"source","p":62193665},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyFromAsync","d":1637537,"h":64426146977,"f":4240}],"l":[{"t":1703073,"n":"_stream","d":1637537,"h":4296604833,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1637537,"h":77311048865,"f":4}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h],"h":1637537}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte) ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeWriter`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.Pipe", ($self) => class Pipe extends $.$spc.System.Object
        {
            static $_DefaultPipeReader;
            static get DefaultPipeReader()
            {
                let $cls = $.$sipl.System.IO.Pipelines.Pipe;
                return $cls.$_DefaultPipeReader ??= $asm.$ncls("$sipl.System.IO.Pipelines.Pipe.DefaultPipeReader", ($self) => class DefaultPipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
                {
                    /*Pipe*/ _pipe = null;
                    $ctor$2(/*Pipe*/ pipe)
                    {
                        super.$ctor$1();
                        {
                            this._pipe = pipe;
                        }
                        return this;
                    }
                    /*bool */ TryRead(/*out ReadResult*/ result)
                    {
                        return this._pipe.TryRead(result);
                    }
                    /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.ReadAsync(cancellationToken);
                    }
                    /*ValueTask<ReadResult> */ ReadAtLeastAsyncCore(/*int*/ minimumBytes, /*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.ReadAtLeastAsync(minimumBytes, cancellationToken);
                    }
                    /*void */ AdvanceTo(/*SequencePosition*/ consumed)
                    {
                        return this._pipe.AdvanceReader($.$ref(() => consumed, ));
                    }
                    /*void */ AdvanceTo$1(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
                    {
                        return this._pipe.AdvanceReader$1($.$ref(() => consumed, ), $.$ref(() => examined, ));
                    }
                    /*void */ CancelPendingRead()
                    {
                        return this._pipe.CancelPendingRead();
                    }
                    /*void */ Complete(/*Exception?*/ exception)
                    {
                        return this._pipe.CompleteReader(exception);
                    }
                    /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
                    {
                        return this._pipe.OnWriterCompleted(callback, state);
                    }
                    /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
                    {
                        return this._pipe.GetReadAsyncStatus();
                    }
                    /*ReadResult */ GetResult(/*short*/ token)
                    {
                        return this._pipe.GetReadAsyncResult();
                    }
                    /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
                    {
                        return this._pipe.OnReadAsyncCompleted(continuation, state, flags);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.GetStatus(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetStatus()
                    {
                        return this.GetStatus(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$OnCompleted()
                    {
                        return this.OnCompleted(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.GetResult(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetResult()
                    {
                        return this.GetResult(...arguments);
                    }
                    static $h = 720033;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1440929,"m":[{"r":262145,"p":[{"n":"result","p":1768609,"f":2}],"n":"TryRead","d":720033,"h":12885621921,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":720033,"h":17180589217,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumBytes","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAtLeastAsyncCore","d":720033,"h":21475556513,"f":32772},{"r":65537,"p":[{"n":"consumed","p":1244122}],"n":"AdvanceTo","d":720033,"h":25770523809,"f":32769},{"r":65537,"p":[{"n":"consumed","p":1244122},{"n":"examined","p":1244122}],"n":"AdvanceTo","o":"@$1","d":720033,"h":30065491105,"f":32769},{"r":65537,"n":"CancelPendingRead","d":720033,"h":34360458401,"f":32769},{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":720033,"h":38655425697,"f":32769},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":720033,"h":42950392993,"f":32769},{"r":133038081,"p":[{"n":"token","p":524289}],"n":"GetStatus","d":720033,"h":47245360289,"f":1},{"r":1768609,"p":[{"n":"token","p":524289}],"n":"GetResult","d":720033,"h":51540327585,"f":1},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"token","p":524289},{"n":"flags","p":132972545}],"n":"OnCompleted","d":720033,"h":55835294881,"f":1}],"l":[{"t":654497,"n":"_pipe","d":720033,"h":4295687329,"f":2}],"c":[{"p":[{"n":"pipe","p":654497}],"n":".ctor","o":"$ctor$2","d":720033,"h":8590654625,"f":1}],"i":[$.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.ReadResult).$h],"d":654497,"h":720033}; }
                    static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.ReadResult) ]; }
                    static get $fullName() { return `System.IO.Pipelines.Pipe.DefaultPipeReader`; }
                }, $cls, ($v) => $cls.$_DefaultPipeReader = $v);
            }
            static $_DefaultPipeWriter;
            static get DefaultPipeWriter()
            {
                let $cls = $.$sipl.System.IO.Pipelines.Pipe;
                return $cls.$_DefaultPipeWriter ??= $asm.$ncls("$sipl.System.IO.Pipelines.Pipe.DefaultPipeWriter", ($self) => class DefaultPipeWriter extends $.$sipl.System.IO.Pipelines.PipeWriter
                {
                    /*Pipe*/ _pipe = null;
                    $ctor$2(/*Pipe*/ pipe)
                    {
                        super.$ctor$1();
                        {
                            this._pipe = pipe;
                        }
                        return this;
                    }
                    /*void */ Complete(/*Exception?*/ exception)
                    {
                        return this._pipe.CompleteWriter(exception);
                    }
                    /*void */ CancelPendingFlush()
                    {
                        return this._pipe.CancelPendingFlush();
                    }
                    /*bool */ get CanGetUnflushedBytes()
                    {
                        return true;
                    }
                    /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
                    {
                        return this._pipe.OnReaderCompleted(callback, state);
                    }
                    /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.FlushAsync(cancellationToken);
                    }
                    /*void */ Advance(/*int*/ bytes)
                    {
                        return this._pipe.Advance(bytes);
                    }
                    /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
                    {
                        return this._pipe.GetMemory(sizeHint);
                    }
                    /*Span<byte> */ GetSpan(/*int*/ sizeHint)
                    {
                        return this._pipe.GetSpan(sizeHint);
                    }
                    /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
                    {
                        return this._pipe.GetFlushAsyncStatus();
                    }
                    /*FlushResult */ GetResult(/*short*/ token)
                    {
                        return this._pipe.GetFlushAsyncResult();
                    }
                    /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
                    {
                        return this._pipe.OnFlushAsyncCompleted(continuation, state, flags);
                    }
                    /*long */ get UnflushedBytes()
                    {
                        return this._pipe.GetUnflushedBytes();
                    }
                    /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.WriteAsync(source, cancellationToken);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.GetStatus(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetStatus()
                    {
                        return this.GetStatus(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$OnCompleted()
                    {
                        return this.OnCompleted(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.GetResult(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetResult()
                    {
                        return this.GetResult(...arguments);
                    }
                    static $h = 785569;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1637537,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770589345,"f":32769},"n":"CanGetUnflushedBytes","d":785569,"h":21475622049,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68720262305,"f":32769},"n":"UnflushedBytes","d":785569,"h":64425295009,"f":32769}],"m":[{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":785569,"h":12885687457,"f":32769},{"r":65537,"n":"CancelPendingFlush","d":785569,"h":17180654753,"f":32769},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":785569,"h":30065556641,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","d":785569,"h":34360523937,"f":32769},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":785569,"h":38655491233,"f":32769},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":785569,"h":42950458529,"f":32769},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":785569,"h":47245425825,"f":32769},{"r":133038081,"p":[{"n":"token","p":524289}],"n":"GetStatus","d":785569,"h":51540393121,"f":1},{"r":457889,"p":[{"n":"token","p":524289}],"n":"GetResult","d":785569,"h":55835360417,"f":1},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"token","p":524289},{"n":"flags","p":132972545}],"n":"OnCompleted","d":785569,"h":60130327713,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","d":785569,"h":73015229601,"f":32769}],"l":[{"t":654497,"n":"_pipe","d":785569,"h":4295752865,"f":2}],"c":[{"p":[{"n":"pipe","p":654497}],"n":".ctor","o":"$ctor$2","d":785569,"h":8590720161,"f":1}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h,$.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.FlushResult).$h],"d":654497,"h":785569}; }
                    static get $b() { return $.$sipl.System.IO.Pipelines.PipeWriter; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte), $.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.FlushResult) ]; }
                    static get $fullName() { return `System.IO.Pipelines.Pipe.DefaultPipeWriter`; }
                }, $cls, ($v) => $cls.$_DefaultPipeWriter = $v);
            }
            /*Action<object?>*/ static s_signalReaderAwaitable = null;
            /*Action<object?>*/ static s_signalWriterAwaitable = null;
            /*Action<object?>*/ static s_invokeCompletionCallbacks = null;
            /*ContextCallback*/ static s_executionContextRawCallback = null;
            /*SendOrPostCallback*/ static s_syncContextExecutionContextCallback = null;
            /*SendOrPostCallback*/ static s_syncContextExecuteWithoutExecutionContextCallback = null;
            /*Action<object?>*/ static s_scheduleWithExecutionContextCallback = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*DefaultPipeReader*/ _reader = null;
            /*DefaultPipeWriter*/ _writer = null;
            /*PipeOptions*/ _options = null;
            /*object*/ _sync = null;
            /*bool */ get UseSynchronizationContext()
            {
                return this._options.UseSynchronizationContext;
            }
            /*int */ get MinimumSegmentSize()
            {
                return this._options.MinimumSegmentSize;
            }
            /*long */ get PauseWriterThreshold()
            {
                return this._options.PauseWriterThreshold;
            }
            /*long */ get ResumeWriterThreshold()
            {
                return this._options.ResumeWriterThreshold;
            }
            /*PipeScheduler */ get ReaderScheduler()
            {
                return this._options.ReaderScheduler;
            }
            /*PipeScheduler */ get WriterScheduler()
            {
                return this._options.WriterScheduler;
            }
            /*object */ get SyncObj()
            {
                return this._sync;
            }
            /*long*/ _unconsumedBytes = 0n;
            /*long*/ _unflushedBytes = 0n;
            /*PipeAwaitable*/ _readerAwaitable;
            /*PipeAwaitable*/ _writerAwaitable;
            /*PipeCompletion*/ _writerCompletion;
            /*PipeCompletion*/ _readerCompletion;
            /*long*/ _lastExaminedIndex = -1n;
            /*BufferSegment?*/ _readHead = null;
            /*int*/ _readHeadIndex = 0;
            /*bool*/ _disposed = false;
            /*BufferSegment?*/ _readTail = null;
            /*int*/ _readTailIndex = 0;
            /*int*/ _minimumReadBytes = 0;
            /*BufferSegment?*/ _writingHead = null;
            /*Memory<byte>*/ _writingHeadMemory;
            /*int*/ _writingHeadBytesBuffered = 0;
            /*PipeOperationState*/ _operationState;
            /*long */ get Length()
            {
                return this._unconsumedBytes;
            }
            $ctor$1()
            {
                this.$ctor$2($.$sipl.System.IO.Pipelines.PipeOptions.Default);
                {
                }
                return this;
            }
            $ctor$2(/*PipeOptions*/ options)
            {
                super.$ctor();
                {
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$2(options.InitialSegmentPoolSize);
                    this._operationState = new $.$sipl.System.IO.Pipelines.PipeOperationState();
                    this._readerCompletion = new $.$sipl.System.IO.Pipelines.PipeCompletion();
                    this._writerCompletion = new $.$sipl.System.IO.Pipelines.PipeCompletion();
                    this._options = options;
                    this._readerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(false, this.UseSynchronizationContext);
                    this._writerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(true, this.UseSynchronizationContext);
                    this._reader = new $.$sipl.System.IO.Pipelines.Pipe.DefaultPipeReader().$ctor$2(this);
                    this._writer = new $.$sipl.System.IO.Pipelines.Pipe.DefaultPipeWriter().$ctor$2(this);
                }
                return this;
            }
            /*void */ ResetState()
            {
                this._readerCompletion.Reset();
                this._writerCompletion.Reset();
                this._readerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(false, this.UseSynchronizationContext);
                this._writerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(true, this.UseSynchronizationContext);
                this._readTailIndex = 0;
                this._readHeadIndex = 0;
                this._lastExaminedIndex = BigInt(-1);
                this._unflushedBytes = 0n;
                this._unconsumedBytes = 0n;
            }
            /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateWriteHeadIfNeeded(sizeHint);
                return this._writingHeadMemory;
            }
            /*Span<byte> */ GetSpan(/*int*/ sizeHint)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateWriteHeadIfNeeded(sizeHint);
                return this._writingHeadMemory.Span;
            }
            /*void */ AllocateWriteHeadIfNeeded(/*int*/ sizeHint)
            {
                if (!this._operationState.IsWritingActive || this._writingHeadMemory.Length === 0 || this._writingHeadMemory.Length < sizeHint)
                {
                    this.AllocateWriteHeadSynchronized(sizeHint);
                }
            }
            /*void */ AllocateWriteHeadSynchronized(/*int*/ sizeHint)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._operationState.BeginWrite();
                        if (this._writingHead === null)
                        {
                            /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                            this._writingHead = this._readHead = this._readTail = newSegment;
                            this._lastExaminedIndex = 0n;
                        }
                        else 
                        {
                            /*int*/ let bytesLeftInBuffer = this._writingHeadMemory.Length;
                            if (bytesLeftInBuffer === 0 || bytesLeftInBuffer < sizeHint)
                            {
                                if (this._writingHeadBytesBuffered > 0)
                                {
                                    this._writingHead.End += this._writingHeadBytesBuffered;
                                    this._writingHeadBytesBuffered = 0;
                                }
                                if (this._writingHead.Length === 0)
                                {
                                    this._writingHead.ResetMemory();
                                    this.RentMemory(this._writingHead, sizeHint);
                                }
                                else 
                                {
                                    /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                                    this._writingHead.SetNext(newSegment);
                                    this._writingHead = newSegment;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*BufferSegment */ AllocateSegment(/*int*/ sizeHint)
            {
                /*BufferSegment*/ let newSegment = this.CreateSegmentUnsynchronized();
                this.RentMemory(newSegment, sizeHint);
                return newSegment;
            }
            /*void */ RentMemory(/*BufferSegment*/ segment, /*int*/ sizeHint)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment.MemoryOwner === null, "segment.MemoryOwner is null");
                $.$spc.System.Diagnostics.Debug.Assert$1(sizeHint >= 0, "sizeHint >= 0");
                /*MemoryPool<byte>?*/ let pool = null;
                /*int*/ let maxSize = -1;
                if (!this._options.IsDefaultSharedMemoryPool)
                {
                    pool = this._options.Pool;
                    maxSize = pool.MaxBufferSize;
                }
                if (sizeHint <= maxSize)
                {
                    segment.SetOwnedMemory(pool.Rent(this.GetSegmentSize(sizeHint, maxSize)));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(sizeHint, 2147483647);
                    segment.SetOwnedMemory$1($.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(sizeToRequest));
                }
                this._writingHeadMemory = segment.AvailableMemory;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$spc.System.Math.Max$4(this.MinimumSegmentSize, sizeHint);
                /*int*/ let adjustedToMaximumSize = $.$spc.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readHead, "Returning _readHead segment that's in use!");
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readTail, "Returning _readTail segment that's in use!");
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._writingHead, "Returning _writingHead segment that's in use!");
                if (this._bufferSegmentPool.Count < this._options.MaxSegmentPoolSize)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*bool */ CommitUnsynchronized()
            {
                this._operationState.EndWrite();
                if (this._unflushedBytes === 0n)
                {
                    return false;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writingHead !== null, "_writingHead != null");
                this._writingHead.End += this._writingHeadBytesBuffered;
                this._readTail = this._writingHead;
                this._readTailIndex = this._writingHead.End;
                /*long*/ let oldLength = this._unconsumedBytes;
                this._unconsumedBytes += this._unflushedBytes;
                /*bool*/ let resumeReader = true;
                if (this._unconsumedBytes < BigInt(this._minimumReadBytes))
                {
                    resumeReader = false;
                }
                else if (this.PauseWriterThreshold > 0n && oldLength < this.PauseWriterThreshold && this._unconsumedBytes >= this.PauseWriterThreshold && !this._readerCompletion.IsCompleted)
                {
                    this._writerAwaitable.SetUncompleted();
                }
                this._unflushedBytes = 0n;
                this._writingHeadBytesBuffered = 0;
                return resumeReader;
            }
            /*void */ Advance(/*int*/ bytes)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if ((bytes >>> 0) > (this._writingHeadMemory.Length >>> 0))
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.bytes*/);
                        }
                        if (this._readerCompletion.IsCompleted)
                        {
                            return;
                        }
                        this.AdvanceCore(bytes);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*void */ AdvanceCore(/*int*/ bytesWritten)
            {
                this._unflushedBytes += BigInt(bytesWritten);
                this._writingHeadBytesBuffered += bytesWritten;
                this._writingHeadMemory = this._writingHeadMemory.Slice(bytesWritten);
            }
            /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.FlushResult, cancellationToken));
                }
                /*CompletionData*/ let completionData;
                /*ValueTask<FlushResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this.PrepareFlushUnsynchronized($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => result, ($v) => result = $v, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)), cancellationToken);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
                return result;
            }
            /*void */ PrepareFlushUnsynchronized(/*out CompletionData*/ completionData, /*out ValueTask<FlushResult>*/ result, /*CancellationToken*/ cancellationToken)
            {
                /*var*/ let completeReader = this.CommitUnsynchronized();
                this._writerAwaitable.BeginOperation(cancellationToken, $.$sipl.System.IO.Pipelines.Pipe.s_signalWriterAwaitable, this);
                if (this._writerAwaitable.IsCompleted)
                {
                    /*FlushResult*/ let flushResult = new $.$sipl.System.IO.Pipelines.FlushResult();
                    this.GetFlushResult($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sipl.System.IO.Pipelines.FlushResult, () => flushResult, ($v) => flushResult = $v, null));
                    result.$v = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(flushResult.Clone());
                }
                else 
                {
                    result.$v = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$4(this._writer, 0);
                }
                if (completeReader)
                {
                    this._readerAwaitable.Complete(completionData);
                }
                else 
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writerAwaitable.IsCompleted || this._readerAwaitable.IsCompleted, "_writerAwaitable.IsCompleted || _readerAwaitable.IsCompleted");
            }
            /*void */ CompleteWriter(/*Exception?*/ exception)
            {
                /*CompletionData*/ let completionData;
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                /*bool*/ let readerCompleted;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this.CommitUnsynchronized();
                        completionCallbacks = this._writerCompletion.TryComplete(exception);
                        this._readerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        readerCompleted = this._readerCompletion.IsCompleted;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (readerCompleted)
                {
                    this.CompletePipe();
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.ReaderScheduler, completionCallbacks);
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ AdvanceReader(/*in SequencePosition*/ consumed)
            {
                this.AdvanceReader$1(consumed, consumed);
            }
            /*void */ AdvanceReader$1(/*in SequencePosition*/ consumed, /*in SequencePosition*/ examined)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                this.AdvanceReader$2($.$cast(consumed.$v.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), consumed.$v.GetInteger(), $.$cast(examined.$v.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), examined.$v.GetInteger());
            }
            /*void */ AdvanceReader$2(/*BufferSegment?*/ consumedSegment, /*int*/ consumedIndex, /*BufferSegment?*/ examinedSegment, /*int*/ examinedIndex)
            {
                if (consumedSegment !== null && examinedSegment !== null && $.$sipl.System.IO.Pipelines.BufferSegment.GetLength(consumedSegment, consumedIndex, examinedSegment, examinedIndex) < 0n)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition();
                }
                /*BufferSegment?*/ let returnStart = null;
                /*BufferSegment?*/ let returnEnd = null;
                /*CompletionData*/ let completionData = new $.$sipl.System.IO.Pipelines.CompletionData();
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        /*var*/ let examinedEverything = false;
                        if (examinedSegment === this._readTail)
                        {
                            examinedEverything = examinedIndex === this._readTailIndex;
                        }
                        if (examinedSegment !== null && this._lastExaminedIndex >= 0n)
                        {
                            /*long*/ let examinedBytes = $.$sipl.System.IO.Pipelines.BufferSegment.GetLength$1(this._lastExaminedIndex, examinedSegment, examinedIndex);
                            /*long*/ let oldLength = this._unconsumedBytes;
                            this._unconsumedBytes -= examinedBytes;
                            this._lastExaminedIndex = examinedSegment.RunningIndex + BigInt(examinedIndex);
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._unconsumedBytes >= 0n, "Length has gone negative");
                            $.$spc.System.Diagnostics.Debug.Assert$1(this.ResumeWriterThreshold >= 1n, "ResumeWriterThreshold is less than 1");
                            if (oldLength >= this.ResumeWriterThreshold && this._unconsumedBytes < this.ResumeWriterThreshold)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(examinedBytes > 0n, "examinedBytes > 0");
                                this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                            }
                        }
                        if (consumedSegment !== null)
                        {
                            if (this._readHead === null)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AdvanceToInvalidCursor();
                                return;
                            }
                            returnStart = this._readHead;
                            returnEnd = consumedSegment;
                            /*void*/  function MoveReturnEndToNextBlock()
                            {
                                /*BufferSegment?*/ let nextBlock = returnEnd.NextSegment;
                                if (this._readTail === returnEnd)
                                {
                                    this._readTail = nextBlock;
                                    this._readTailIndex = 0;
                                }
                                this._readHead = nextBlock;
                                this._readHeadIndex = 0;
                                returnEnd = nextBlock;
                            }
                            if (consumedIndex === returnEnd.Length)
                            {
                                if (this._writingHead !== returnEnd)
                                {
                                    MoveReturnEndToNextBlock.call(this);
                                }
                                else if (this._writingHeadBytesBuffered === 0 && !this._operationState.IsWritingActive)
                                {
                                    this._writingHead = null;
                                    this._writingHeadMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                                    MoveReturnEndToNextBlock.call(this);
                                }
                                else 
                                {
                                    this._readHead = consumedSegment;
                                    this._readHeadIndex = consumedIndex;
                                }
                            }
                            else 
                            {
                                this._readHead = consumedSegment;
                                this._readHeadIndex = consumedIndex;
                            }
                        }
                        if (examinedEverything && !this._writerCompletion.IsCompleted)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._writerAwaitable.IsCompleted, "PipeWriter.FlushAsync isn't completed and will deadlock");
                            this._readerAwaitable.SetUncompleted();
                        }
                        while(returnStart !== null && returnStart !== returnEnd)
                        {
                            /*BufferSegment?*/ let next = returnStart.NextSegment;
                            returnStart.Reset();
                            this.ReturnSegmentUnsynchronized(returnStart);
                            returnStart = next;
                        }
                        this._operationState.EndRead();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ CompleteReader(/*Exception?*/ exception)
            {
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                /*CompletionData*/ let completionData;
                /*bool*/ let writerCompleted;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (this._operationState.IsReadingActive)
                        {
                            this._operationState.EndRead();
                        }
                        completionCallbacks = this._readerCompletion.TryComplete(exception);
                        this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        writerCompleted = this._writerCompletion.IsCompleted;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (writerCompleted)
                {
                    this.CompletePipe();
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.WriterScheduler, completionCallbacks);
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                if (callback === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.callback*/);
                }
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        completionCallbacks = this._writerCompletion.AddCallback(callback, state);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.ReaderScheduler, completionCallbacks);
                }
            }
            /*void */ CancelPendingRead()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.Cancel($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ CancelPendingFlush()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._writerAwaitable.Cancel($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                if (callback === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.callback*/);
                }
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        completionCallbacks = this._readerCompletion.AddCallback(callback, state);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.WriterScheduler, completionCallbacks);
                }
            }
            /*ValueTask<ReadResult> */ ReadAtLeastAsync(/*int*/ minimumBytes, /*CancellationToken*/ token)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                if (token.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.ReadResult, token));
                }
                /*CompletionData*/ let completionData = new $.$sipl.System.IO.Pipelines.CompletionData();
                /*ValueTask<ReadResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        if (this._readerAwaitable.IsCompleted)
                        {
                            /*ReadResult*/ let readResult;
                            this.GetReadResult($.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                            if (this._unconsumedBytes >= BigInt(minimumBytes) || readResult.IsCanceled || readResult.IsCompleted)
                            {
                                return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(readResult);
                            }
                            this._readerAwaitable.SetUncompleted();
                            this._operationState.EndRead();
                            this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        }
                        if (!this._writerAwaitable.IsCompleted)
                        {
                            this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        }
                        this._minimumReadBytes = minimumBytes;
                        result = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$4(this._reader, 0);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, undefined, $.$sipl.System.IO.Pipelines.CompletionData));
                return result;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ token)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                if (token.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.ReadResult, token));
                }
                /*ValueTask<ReadResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        if (this._readerAwaitable.IsCompleted)
                        {
                            /*ReadResult*/ let readResult;
                            this.GetReadResult($.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                            result = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(readResult);
                        }
                        else 
                        {
                            result = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$4(this._reader, 0);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                return result;
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (this._readerCompletion.IsCompleted)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                        }
                        if (this._unconsumedBytes > 0n || this._readerAwaitable.IsCompleted)
                        {
                            this.GetReadResult(result);
                            return true;
                        }
                        if (this._readerAwaitable.IsRunning)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                        }
                        this._operationState.BeginReadTentative();
                        result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                        return false;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            static /*void */ ScheduleCallbacks(/*PipeScheduler*/ scheduler, /*PipeCompletionCallbacks*/ completionCallbacks)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(completionCallbacks !== null, "completionCallbacks != null");
                scheduler.UnsafeSchedule($.$sipl.System.IO.Pipelines.Pipe.s_invokeCompletionCallbacks, completionCallbacks);
            }
            static /*void */ TrySchedule(/*PipeScheduler*/ scheduler, /*in CompletionData*/ completionData)
            {
                /*Action<object?>*/ let completion = completionData.$v.Completion;
                if (completion === null)
                {
                    return;
                }
                if (completionData.$v.SynchronizationContext === null && completionData.$v.ExecutionContext === null)
                {
                    scheduler.UnsafeSchedule(completion, completionData.$v.CompletionState);
                }
                else 
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleWithContext(scheduler, completionData);
                }
            }
            static /*void */ ScheduleWithContext(/*PipeScheduler*/ scheduler, /*in CompletionData*/ completionData)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(completionData.$v.SynchronizationContext !== null || completionData.$v.ExecutionContext !== null, "completionData.SynchronizationContext != null || completionData.ExecutionContext != null");
                if (completionData.$v.SynchronizationContext === null)
                {
                    scheduler.UnsafeSchedule($.$sipl.System.IO.Pipelines.Pipe.s_scheduleWithExecutionContextCallback, completionData.$v);
                }
                else 
                {
                    if (completionData.$v.ExecutionContext === null)
                    {
                        completionData.$v.SynchronizationContext.Post($.$sipl.System.IO.Pipelines.Pipe.s_syncContextExecuteWithoutExecutionContextCallback, completionData.$v);
                    }
                    else 
                    {
                        completionData.$v.SynchronizationContext.Post($.$sipl.System.IO.Pipelines.Pipe.s_syncContextExecutionContextCallback, completionData.$v);
                    }
                }
            }
            static /*void */ ExecuteWithoutExecutionContext(/*object*/ state)
            {
                /*CompletionData*/ let completionData = $.$cast(state, $.$sipl.System.IO.Pipelines.CompletionData);
                completionData.Completion.Invoke(completionData.CompletionState);
            }
            static /*void */ ExecuteWithExecutionContext(/*object*/ state)
            {
                /*CompletionData*/ let completionData = $.$cast(state, $.$sipl.System.IO.Pipelines.CompletionData);
                $.$spc.System.Diagnostics.Debug.Assert$1(completionData.ExecutionContext !== null, "completionData.ExecutionContext != null");
                $.$spc.System.Threading.ExecutionContext.Run(completionData.ExecutionContext, $.$sipl.System.IO.Pipelines.Pipe.s_executionContextRawCallback, state);
            }
            /*void */ CompletePipe()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        this._disposed = true;
                        /*BufferSegment?*/ let segment = this._readHead ?? this._readTail;
                        while(segment !== null)
                        {
                            /*BufferSegment*/ let returnSegment = segment;
                            segment = segment.NextSegment;
                            returnSegment.Reset();
                        }
                        this._writingHead = null;
                        this._writingHeadMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                        this._readHead = null;
                        this._readTail = null;
                        this._lastExaminedIndex = BigInt(-1);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*ValueTaskSourceStatus */ GetReadAsyncStatus()
            {
                if (this._readerAwaitable.IsCompleted)
                {
                    if (this._writerCompletion.IsFaulted)
                    {
                        return 2/*ValueTaskSourceStatus.Faulted*/;
                    }
                    return 1/*ValueTaskSourceStatus.Succeeded*/;
                }
                return 0/*ValueTaskSourceStatus.Pending*/;
            }
            /*void */ OnReadAsyncCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                /*CompletionData*/ let completionData;
                /*bool*/ let doubleCompletion;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.OnCompleted(continuation, state, flags, $.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => doubleCompletion, ($v) => doubleCompletion = $v, $.$spc.System.Boolean));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (doubleCompletion)
                {
                    this.Writer.Complete($.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation());
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*ReadResult */ GetReadAsyncResult()
            {
                /*ReadResult*/ let result;
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                /*CancellationToken*/ let cancellationToken = new $.$spc.System.Threading.CancellationToken();
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                        {
                            if (!this._readerAwaitable.IsCompleted)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_GetResultNotCompleted();
                            }
                            cancellationTokenRegistration = this._readerAwaitable.ReleaseCancellationTokenRegistration($.$ref(() => cancellationToken, ($v) => cancellationToken = $v, $.$spc.System.Threading.CancellationToken));
                            this.GetReadResult($.$ref(() => result, ($v) => result = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                    }
                }
                finally
                {
                    {
                        cancellationTokenRegistration.Dispose();
                    }
                }
                if (result.IsCanceled)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                }
                return result;
            }
            /*void */ GetReadResult(/*out ReadResult*/ result)
            {
                /*bool*/ let isCompleted = this._writerCompletion.IsCompletedOrThrow();
                /*bool*/ let isCanceled = this._readerAwaitable.ObserveCancellation();
                /*BufferSegment?*/ let head = this._readHead;
                if (head !== null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readTail !== null, "_readTail != null");
                    /*var*/ let readOnlySequence = new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))().$ctor$3(head, this._readHeadIndex, this._readTail, this._readTailIndex);
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(readOnlySequence, isCanceled, isCompleted);
                }
                else 
                {
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))(), isCanceled, isCompleted);
                }
                if (isCanceled)
                {
                    this._operationState.BeginReadTentative();
                }
                else 
                {
                    this._operationState.BeginRead();
                }
                this._minimumReadBytes = 0;
            }
            /*ValueTaskSourceStatus */ GetFlushAsyncStatus()
            {
                if (this._writerAwaitable.IsCompleted)
                {
                    if (this._readerCompletion.IsFaulted)
                    {
                        return 2/*ValueTaskSourceStatus.Faulted*/;
                    }
                    return 1/*ValueTaskSourceStatus.Succeeded*/;
                }
                return 0/*ValueTaskSourceStatus.Pending*/;
            }
            /*FlushResult */ GetFlushAsyncResult()
            {
                /*FlushResult*/ let result = new $.$sipl.System.IO.Pipelines.FlushResult();
                /*CancellationToken*/ let cancellationToken = new $.$spc.System.Threading.CancellationToken();
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                        {
                            if (!this._writerAwaitable.IsCompleted)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_GetResultNotCompleted();
                            }
                            this.GetFlushResult($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sipl.System.IO.Pipelines.FlushResult, () => result, ($v) => result = $v, null));
                            cancellationTokenRegistration = this._writerAwaitable.ReleaseCancellationTokenRegistration($.$ref(() => cancellationToken, ($v) => cancellationToken = $v, $.$spc.System.Threading.CancellationToken));
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                    }
                }
                finally
                {
                    {
                        cancellationTokenRegistration.Dispose();
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                }
                return result;
            }
            /*long */ GetUnflushedBytes()
            {
                return this._unflushedBytes;
            }
            /*void */ GetFlushResult(/*ref FlushResult*/ result)
            {
                if (this._writerAwaitable.ObserveCancellation())
                {
                    result.$v._resultFlags |= 1/*ResultFlags.Canceled*/;
                }
                if (this._readerCompletion.IsCompletedOrThrow())
                {
                    result.$v._resultFlags |= 2/*ResultFlags.Completed*/;
                }
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (this._readerCompletion.IsCompletedOrThrow())
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, true));
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.FlushResult, cancellationToken));
                }
                /*CompletionData*/ let completionData;
                /*ValueTask<FlushResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this.AllocateWriteHeadIfNeeded(0);
                        if (source.Length <= this._writingHeadMemory.Length)
                        {
                            source.CopyTo(this._writingHeadMemory);
                            this.AdvanceCore(source.Length);
                        }
                        else 
                        {
                            this.WriteMultiSegment(source.Span);
                        }
                        this.PrepareFlushUnsynchronized($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => result, ($v) => result = $v, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)), cancellationToken);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
                return result;
            }
            /*void */ WriteMultiSegment(/*ReadOnlySpan<byte>*/ source)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writingHead !== null, "_writingHead != null");
                /*Span<byte>*/ let destination = this._writingHeadMemory.Span;
                while(true)
                {
                    /*int*/ let writable = $.$spc.System.Math.Min$4(destination.Length, source.Length);
                    source.Slice$1(0, writable).CopyTo(destination);
                    source = source.Slice(writable);
                    this.AdvanceCore(writable);
                    if (source.Length === 0)
                    {
                        break;
                    }
                    this._writingHead.End += this._writingHeadBytesBuffered;
                    this._writingHeadBytesBuffered = 0;
                    /*BufferSegment*/ let newSegment = this.AllocateSegment(0);
                    this._writingHead.SetNext(newSegment);
                    this._writingHead = newSegment;
                    destination = this._writingHeadMemory.Span;
                }
            }
            /*void */ OnFlushAsyncCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                /*CompletionData*/ let completionData;
                /*bool*/ let doubleCompletion;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._writerAwaitable.OnCompleted(continuation, state, flags, $.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => doubleCompletion, ($v) => doubleCompletion = $v, $.$spc.System.Boolean));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (doubleCompletion)
                {
                    this.Reader.Complete($.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation());
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ ReaderCancellationRequested()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.CancellationTokenFired($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ WriterCancellationRequested()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._writerAwaitable.CancellationTokenFired($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*PipeReader */ get Reader()
            {
                return this._reader;
            }
            /*PipeWriter */ get Writer()
            {
                return this._writer;
            }
            /*void */ Reset()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (!this._disposed)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_ResetIncompleteReaderWriter();
                        }
                        this._disposed = false;
                        this.ResetState();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
                this._sync = new $.$spc.System.Object().$ctor();
                this._readerAwaitable = $.$default($.$sipl.System.IO.Pipelines.PipeAwaitable);
                this._writerAwaitable = $.$default($.$sipl.System.IO.Pipelines.PipeAwaitable);
                this._writerCompletion = $.$default($.$sipl.System.IO.Pipelines.PipeCompletion);
                this._readerCompletion = $.$default($.$sipl.System.IO.Pipelines.PipeCompletion);
                this._writingHeadMemory = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
                this._operationState = $.$default($.$sipl.System.IO.Pipelines.PipeOperationState);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_signalReaderAwaitable = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.Pipe)).ReaderCancellationRequested();
                    }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":654497,"h":0,"f":1048578});
                }
                {
                    this.s_signalWriterAwaitable = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.Pipe)).WriterCancellationRequested();
                    }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":654497,"h":0,"f":1048578});
                }
                {
                    this.s_invokeCompletionCallbacks = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.PipeCompletionCallbacks)).Execute();
                    }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":654497,"h":0,"f":1048578});
                }
                {
                    this.s_executionContextRawCallback = new $.$spc.System.Threading.ContextCallback().$ctor($.$sipl.System.IO.Pipelines.Pipe, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithoutExecutionContext);
                }
                {
                    this.s_syncContextExecutionContextCallback = new $.$spc.System.Threading.SendOrPostCallback().$ctor($.$sipl.System.IO.Pipelines.Pipe, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithExecutionContext);
                }
                {
                    this.s_syncContextExecuteWithoutExecutionContextCallback = new $.$spc.System.Threading.SendOrPostCallback().$ctor($.$sipl.System.IO.Pipelines.Pipe, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithoutExecutionContext);
                }
                {
                    this.s_scheduleWithExecutionContextCallback = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor($.$sipl.System.IO.Pipelines.Pipe, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithExecutionContext);
                }
            }
            static $h = 654497;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":68720131233,"f":2},"n":"UseSynchronizationContext","d":654497,"h":64425163937,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":77310065825,"f":2},"n":"MinimumSegmentSize","d":654497,"h":73015098529,"f":2},{"p":917505,"g":{"r":0,"d":0,"h":85900000417,"f":2},"n":"PauseWriterThreshold","d":654497,"h":81605033121,"f":2},{"p":917505,"g":{"r":0,"d":0,"h":94489935009,"f":2},"n":"ResumeWriterThreshold","d":654497,"h":90194967713,"f":2},{"p":1572001,"g":{"r":0,"d":0,"h":103079869601,"f":2},"n":"ReaderScheduler","d":654497,"h":98784902305,"f":2},{"p":1572001,"g":{"r":0,"d":0,"h":111669804193,"f":2},"n":"WriterScheduler","d":654497,"h":107374836897,"f":2},{"p":131073,"g":{"r":0,"d":0,"h":120259738785,"f":2},"n":"SyncObj","d":654497,"h":115964771489,"f":2},{"p":917505,"g":{"r":0,"d":0,"h":201864117409,"f":8},"n":"Length","d":654497,"h":197569150113,"f":8},{"p":1440929,"g":{"r":0,"d":0,"h":416612482209,"f":1},"n":"Reader","d":654497,"h":412317514913,"f":1},{"p":1637537,"g":{"r":0,"d":0,"h":425202416801,"f":1},"n":"Writer","d":654497,"h":420907449505,"f":1}],"m":[{"r":65537,"n":"ResetState","d":654497,"h":214749019297,"f":2},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361}],"n":"GetMemory","d":654497,"h":219043986593,"f":8},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361}],"n":"GetSpan","d":654497,"h":223338953889,"f":8},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateWriteHeadIfNeeded","d":654497,"h":227633921185,"f":2},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateWriteHeadSynchronized","d":654497,"h":231928888481,"f":2},{"r":130209,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateSegment","d":654497,"h":236223855777,"f":2},{"r":65537,"p":[{"n":"segment","p":130209},{"n":"sizeHint","p":655361}],"n":"RentMemory","d":654497,"h":240518823073,"f":2},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361,"f":65,"v":2147483647}],"n":"GetSegmentSize","d":654497,"h":244813790369,"f":2},{"r":130209,"n":"CreateSegmentUnsynchronized","d":654497,"h":249108757665,"f":2},{"r":65537,"p":[{"n":"segment","p":130209}],"n":"ReturnSegmentUnsynchronized","d":654497,"h":253403724961,"f":2},{"r":262145,"n":"CommitUnsynchronized","d":654497,"h":257698692257,"f":8},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":654497,"h":261993659553,"f":8},{"r":65537,"p":[{"n":"bytesWritten","p":655361}],"n":"AdvanceCore","d":654497,"h":266288626849,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","d":654497,"h":270583594145,"f":8},{"r":65537,"p":[{"n":"completionData","p":326817,"f":2},{"n":"result","p":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"f":2},{"n":"cancellationToken","p":125960193}],"n":"PrepareFlushUnsynchronized","d":654497,"h":274878561441,"f":2},{"r":65537,"p":[{"n":"exception","p":47251457}],"n":"CompleteWriter","d":654497,"h":279173528737,"f":8},{"r":65537,"p":[{"n":"consumed","p":1244122,"f":8}],"n":"AdvanceReader","d":654497,"h":283468496033,"f":8},{"r":65537,"p":[{"n":"consumed","p":1244122,"f":8},{"n":"examined","p":1244122,"f":8}],"n":"AdvanceReader","o":"@$1","d":654497,"h":287763463329,"f":8},{"r":65537,"p":[{"n":"consumedSegment","p":130209},{"n":"consumedIndex","p":655361},{"n":"examinedSegment","p":130209},{"n":"examinedIndex","p":655361}],"n":"AdvanceReader","o":"@$2","d":654497,"h":292058430625,"f":2},{"r":65537,"p":[{"n":"exception","p":47251457}],"n":"CompleteReader","d":654497,"h":296353397921,"f":8},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":654497,"h":300648365217,"f":8},{"r":65537,"n":"CancelPendingRead","d":654497,"h":304943332513,"f":8},{"r":65537,"n":"CancelPendingFlush","d":654497,"h":309238299809,"f":8},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":654497,"h":313533267105,"f":8},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumBytes","p":655361},{"n":"token","p":125960193}],"n":"ReadAtLeastAsync","d":654497,"h":317828234401,"f":8},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"token","p":125960193}],"n":"ReadAsync","d":654497,"h":322123201697,"f":8},{"r":262145,"p":[{"n":"result","p":1768609,"f":2}],"n":"TryRead","d":654497,"h":326418168993,"f":8},{"r":65537,"p":[{"n":"scheduler","p":1572001},{"n":"completionCallbacks","p":1178785}],"n":"ScheduleCallbacks","d":654497,"h":330713136289,"f":34},{"r":65537,"p":[{"n":"scheduler","p":1572001},{"n":"completionData","p":326817,"f":8}],"n":"TrySchedule","d":654497,"h":335008103585,"f":34},{"r":65537,"p":[{"n":"scheduler","p":1572001},{"n":"completionData","p":326817,"f":8}],"n":"ScheduleWithContext","d":654497,"h":339303070881,"f":34},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ExecuteWithoutExecutionContext","d":654497,"h":343598038177,"f":34},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ExecuteWithExecutionContext","d":654497,"h":347893005473,"f":34},{"r":65537,"n":"CompletePipe","d":654497,"h":352187972769,"f":2},{"r":133038081,"n":"GetReadAsyncStatus","d":654497,"h":356482940065,"f":8},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132972545}],"n":"OnReadAsyncCompleted","d":654497,"h":360777907361,"f":8},{"r":1768609,"n":"GetReadAsyncResult","d":654497,"h":365072874657,"f":8},{"r":65537,"p":[{"n":"result","p":1768609,"f":2}],"n":"GetReadResult","d":654497,"h":369367841953,"f":2},{"r":133038081,"n":"GetFlushAsyncStatus","d":654497,"h":373662809249,"f":8},{"r":457889,"n":"GetFlushAsyncResult","d":654497,"h":377957776545,"f":8},{"r":917505,"n":"GetUnflushedBytes","d":654497,"h":382252743841,"f":8},{"r":65537,"p":[{"n":"result","p":457889,"f":4}],"n":"GetFlushResult","d":654497,"h":386547711137,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","d":654497,"h":390842678433,"f":8},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"WriteMultiSegment","d":654497,"h":395137645729,"f":2},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132972545}],"n":"OnFlushAsyncCompleted","d":654497,"h":399432613025,"f":8},{"r":65537,"n":"ReaderCancellationRequested","d":654497,"h":403727580321,"f":2},{"r":65537,"n":"WriterCancellationRequested","d":654497,"h":408022547617,"f":2},{"r":65537,"n":"Reset","d":654497,"h":429497384097,"f":1}],"l":[{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_signalReaderAwaitable","d":654497,"h":12885556385,"f":34},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_signalWriterAwaitable","d":654497,"h":17180523681,"f":34},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_invokeCompletionCallbacks","d":654497,"h":21475490977,"f":34},{"t":126615553,"n":"s_executionContextRawCallback","d":654497,"h":25770458273,"f":34},{"t":130875393,"n":"s_syncContextExecutionContextCallback","d":654497,"h":30065425569,"f":34},{"t":130875393,"n":"s_syncContextExecuteWithoutExecutionContextCallback","d":654497,"h":34360392865,"f":34},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_scheduleWithExecutionContextCallback","d":654497,"h":38655360161,"f":34},{"t":195745,"n":"_bufferSegmentPool","d":654497,"h":42950327457,"f":2},{"t":720033,"n":"_reader","d":654497,"h":47245294753,"f":2},{"t":785569,"n":"_writer","d":654497,"h":51540262049,"f":2},{"t":1375393,"n":"_options","d":654497,"h":55835229345,"f":2},{"t":131073,"n":"_sync","d":654497,"h":60130196641,"f":2},{"t":917505,"n":"_unconsumedBytes","d":654497,"h":124554706081,"f":2},{"t":917505,"n":"_unflushedBytes","d":654497,"h":128849673377,"f":2},{"t":851105,"n":"_readerAwaitable","d":654497,"h":133144640673,"f":2},{"t":851105,"n":"_writerAwaitable","d":654497,"h":137439607969,"f":2},{"t":1047713,"n":"_writerCompletion","d":654497,"h":141734575265,"f":2},{"t":1047713,"n":"_readerCompletion","d":654497,"h":146029542561,"f":2},{"t":917505,"n":"_lastExaminedIndex","d":654497,"h":150324509857,"f":2},{"t":130209,"n":"_readHead","d":654497,"h":154619477153,"f":2},{"t":655361,"n":"_readHeadIndex","d":654497,"h":158914444449,"f":2},{"t":262145,"n":"_disposed","d":654497,"h":163209411745,"f":2},{"t":130209,"n":"_readTail","d":654497,"h":167504379041,"f":2},{"t":655361,"n":"_readTailIndex","d":654497,"h":171799346337,"f":2},{"t":655361,"n":"_minimumReadBytes","d":654497,"h":176094313633,"f":2},{"t":130209,"n":"_writingHead","d":654497,"h":180389280929,"f":2},{"t":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"n":"_writingHeadMemory","d":654497,"h":184684248225,"f":2},{"t":655361,"n":"_writingHeadBytesBuffered","d":654497,"h":188979215521,"f":2},{"t":1244321,"n":"_operationState","d":654497,"h":193274182817,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":654497,"h":206159084705,"f":1},{"p":[{"n":"options","p":1375393}],"n":".ctor","o":"$ctor$2","d":654497,"h":210454052001,"f":1}],"j":[720033,785569],"h":654497}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.Pipe`; }
        });
        
        $asm.$cls("$sipl.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sipl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.IO.Pipelines", $.$sipl.System.SR.$type.Assembly);
                    $.$sipl.System.SR.s_resourceManager = temp;
                }
                return $.$sipl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sipl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sipl.System.SR.resourceCulture = value;
            }
            static /*string */ get AdvanceToInvalidCursor()
            {
                return "The PipeReader has already advanced past the provided position.";
            }
            static /*string */ get ArgumentOutOfRange_NeedPosNum()
            {
                return "Positive number required.";
            }
            static /*string */ get ConcurrentOperationsNotSupported()
            {
                return "Concurrent reads or writes are not supported.";
            }
            static /*string */ get FlushCanceledOnPipeWriter()
            {
                return "Flush was canceled on underlying PipeWriter.";
            }
            static /*string */ get GetResultBeforeCompleted()
            {
                return "Can't GetResult unless awaiter is completed.";
            }
            static /*string */ get InvalidExaminedOrConsumedPosition()
            {
                return "The examined position must be greater than or equal to the consumed position.";
            }
            static /*string */ get InvalidExaminedPosition()
            {
                return "The examined position cannot be less than the previously examined position.";
            }
            static /*string */ get InvalidZeroByteRead()
            {
                return "The PipeReader returned 0 bytes when the ReadResult was not completed or canceled.";
            }
            static /*string */ get ObjectDisposed_StreamClosed()
            {
                return "Cannot access a closed stream.";
            }
            static /*string */ get NoReadingOperationToComplete()
            {
                return "No reading operation to complete.";
            }
            static /*string */ get NotSupported_UnreadableStream()
            {
                return "Stream does not support reading.";
            }
            static /*string */ get NotSupported_UnwritableStream()
            {
                return "Stream does not support writing.";
            }
            static /*string */ get ReadCanceledOnPipeReader()
            {
                return "Read was canceled on underlying PipeReader.";
            }
            static /*string */ get ReaderAndWriterHasToBeCompleted()
            {
                return "Both reader and writer has to be completed to be able to reset the pipe.";
            }
            static /*string */ get ReadingAfterCompleted()
            {
                return "Reading is not allowed after reader was completed.";
            }
            static /*string */ get ReadingIsInProgress()
            {
                return "Reading is already in progress.";
            }
            static /*string */ get WritingAfterCompleted()
            {
                return "Writing is not allowed after writer was completed.";
            }
            static /*string */ get UnflushedBytesNotSupported()
            {
                return "UnflushedBytes is not supported.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sipl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sipl.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sipl.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sipl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sipl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sipl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2489505;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2489505}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeOptions", ($self) => class PipeOptions extends $.$spc.System.Object
        {
            /*int*/ static DefaultMinimumSegmentSize = 4096;
            /*PipeOptions*/ static Default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*PipeScheduler?*/ readerScheduler, /*PipeScheduler?*/ writerScheduler, /*long*/ pauseWriterThreshold, /*long*/ resumeWriterThreshold, /*int*/ minimumSegmentSize, /*bool*/ useSynchronizationContext)
            {
                super.$ctor();
                {
                    this.MinimumSegmentSize = minimumSegmentSize === -1 ? 4096/*DefaultMinimumSegmentSize*/ : minimumSegmentSize;
                    this.InitialSegmentPoolSize = 4;
                    this.MaxSegmentPoolSize = 256;
                    /*int*/ let DefaultPauseWriterThreshold = 65536;
                    /*int*/ let DefaultResumeWriterThreshold = $.trunc(DefaultPauseWriterThreshold / 2);
                    if (pauseWriterThreshold === BigInt(-1))
                    {
                        pauseWriterThreshold = BigInt(DefaultPauseWriterThreshold);
                    }
                    else if (pauseWriterThreshold < 0n)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(4/*ExceptionArgument.pauseWriterThreshold*/);
                    }
                    if (resumeWriterThreshold === BigInt(-1))
                    {
                        resumeWriterThreshold = BigInt(DefaultResumeWriterThreshold);
                    }
                    else if (resumeWriterThreshold === 0n)
                    {
                        resumeWriterThreshold = 1n;
                    }
                    if (resumeWriterThreshold < 0n || (pauseWriterThreshold > 0n && resumeWriterThreshold > pauseWriterThreshold))
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(5/*ExceptionArgument.resumeWriterThreshold*/);
                    }
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.IsDefaultSharedMemoryPool = this.Pool === $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.ReaderScheduler = readerScheduler ?? $.$sipl.System.IO.Pipelines.PipeScheduler.ThreadPool;
                    this.WriterScheduler = writerScheduler ?? $.$sipl.System.IO.Pipelines.PipeScheduler.ThreadPool;
                    this.PauseWriterThreshold = pauseWriterThreshold;
                    this.ResumeWriterThreshold = resumeWriterThreshold;
                    this.UseSynchronizationContext = useSynchronizationContext;
                }
                return this;
            }
            /*bool*/ UseSynchronizationContext = false;
            /*long*/ PauseWriterThreshold = 0n;
            /*long*/ ResumeWriterThreshold = 0n;
            /*int*/ MinimumSegmentSize = 0;
            /*PipeScheduler*/ WriterScheduler = null;
            /*PipeScheduler*/ ReaderScheduler = null;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ IsDefaultSharedMemoryPool = false;
            /*int*/ InitialSegmentPoolSize = 0;
            /*int*/ MaxSegmentPoolSize = 0;
            //default member initializer
            constructor()
            {
                super();
                this.UseSynchronizationContext = false;
                this.IsDefaultSharedMemoryPool = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$sipl.System.IO.Pipelines.PipeOptions().$ctor$1(null, null, null, -1n, -1n, -1, true);
                }
            }
            static $h = 1375393;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1375393,"g":{"r":0,"d":0,"h":17181244577,"f":33},"n":"Default","d":1375393,"h":12886277281,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":34361113761,"f":1},"n":"UseSynchronizationContext","d":1375393,"h":30066146465,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":47246015649,"f":1},"n":"PauseWriterThreshold","d":1375393,"h":42951048353,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":60130917537,"f":1},"n":"ResumeWriterThreshold","d":1375393,"h":55835950241,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73015819425,"f":1},"n":"MinimumSegmentSize","d":1375393,"h":68720852129,"f":1},{"p":1572001,"g":{"r":0,"d":0,"h":85900721313,"f":1},"n":"WriterScheduler","d":1375393,"h":81605754017,"f":1},{"p":1572001,"g":{"r":0,"d":0,"h":98785623201,"f":1},"n":"ReaderScheduler","d":1375393,"h":94490655905,"f":1},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":111670525089,"f":1},"n":"Pool","d":1375393,"h":107375557793,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124555426977,"f":8},"n":"IsDefaultSharedMemoryPool","d":1375393,"h":120260459681,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":137440328865,"f":8},"n":"InitialSegmentPoolSize","d":1375393,"h":133145361569,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":150325230753,"f":8},"n":"MaxSegmentPoolSize","d":1375393,"h":146030263457,"f":8}],"l":[{"t":655361,"n":"DefaultMinimumSegmentSize","d":1375393,"h":4296342689,"f":34}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"f":65},{"n":"readerScheduler","p":1572001,"f":65},{"n":"writerScheduler","p":1572001,"f":65},{"n":"pauseWriterThreshold","p":917505,"f":65,"v":-1},{"n":"resumeWriterThreshold","p":917505,"f":65,"v":-1},{"n":"minimumSegmentSize","p":655361,"f":65,"v":-1},{"n":"useSynchronizationContext","p":262145,"f":65,"v":true}],"n":".ctor","o":"$ctor$1","d":1375393,"h":21476211873,"f":1}],"h":1375393}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeOptions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeCompletionCallbacks", ($self) => class PipeCompletionCallbacks extends $.$spc.System.Object
        {
            /*List<PipeCompletionCallback>*/ _callbacks = null;
            /*Exception?*/ _exception = null;
            $ctor$1(/*List<PipeCompletionCallback>*/ callbacks, /*ExceptionDispatchInfo?*/ edi)
            {
                super.$ctor();
                {
                    this._callbacks = callbacks;
                    this._exception = (edi?.SourceException ?? null);
                }
                return this;
            }
            /*void */ Execute()
            {
                /*var*/ let count = this._callbacks.Count;
                if (count === 0)
                {
                    return;
                }
                /*List<Exception>?*/ let exceptions = null;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*var*/ let callback = this._callbacks.get_Item(i);
                    this.Execute$1(callback, $.$ref(() => exceptions, ($v) => exceptions = $v, $.$spc.System.Collections.Generic.List$$($.$spc.System.Exception)));
                }
                if (exceptions !== null)
                {
                    throw new $.$spc.System.AggregateException().$ctor$8(exceptions);
                }
            }
            /*void */ Execute$1(/*PipeCompletionCallback*/ callback, /*ref List<Exception>?*/ exceptions)
            {
                try
                {
                    callback.Callback.Invoke(this._exception, callback.State);
                }
                catch(ex)
                {
                    exceptions.$v ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Exception))().$ctor$1();
                    exceptions.$v.Add(ex);
                }
            }
            static $h = 1178785;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","d":1178785,"h":17181047969,"f":1},{"r":65537,"p":[{"n":"callback","p":1113249},{"n":"exceptions","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Exception).$h,"f":4}],"n":"Execute","o":"@$1","d":1178785,"h":21476015265,"f":2}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h,"n":"_callbacks","d":1178785,"h":4296146081,"f":2},{"t":47251457,"n":"_exception","d":1178785,"h":8591113377,"f":2}],"c":[{"p":[{"n":"callbacks","p":$.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h},{"n":"edi","p":97517569}],"n":".ctor","o":"$ctor$1","d":1178785,"h":12886080673,"f":1}],"h":1178785}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletionCallbacks`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateArgumentOutOfRangeException(argument);
            }
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                return new $.$spc.System.ArgumentOutOfRangeException().$ctor$16($.$spc.System.Enum.ToStringT($.$sipl.System.IO.Pipelines.ExceptionArgument, $.$spc.System.UInt32, argument));
            }
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateArgumentNullException(argument);
            }
            static /*ArgumentNullException */ CreateArgumentNullException(/*ExceptionArgument*/ argument)
            {
                return new $.$spc.System.ArgumentNullException().$ctor$16($.$spc.System.Enum.ToStringT($.$sipl.System.IO.Pipelines.ExceptionArgument, $.$spc.System.UInt32, argument));
            }
            static /*void */ ThrowInvalidOperationException_AlreadyReading()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_AlreadyReading();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_AlreadyReading()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ReadingIsInProgress);
            }
            static /*void */ ThrowInvalidOperationException_NoReadToComplete()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoReadToComplete();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoReadToComplete()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.NoReadingOperationToComplete);
            }
            static /*void */ ThrowInvalidOperationException_NoConcurrentOperation()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoConcurrentOperation()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ConcurrentOperationsNotSupported);
            }
            static /*void */ ThrowInvalidOperationException_GetResultNotCompleted()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_GetResultNotCompleted();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_GetResultNotCompleted()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.GetResultBeforeCompleted);
            }
            static /*void */ ThrowInvalidOperationException_NoWritingAllowed()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoWritingAllowed();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoWritingAllowed()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.WritingAfterCompleted);
            }
            static /*void */ ThrowInvalidOperationException_NoReadingAllowed()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoReadingAllowed();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoReadingAllowed()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ReadingAfterCompleted);
            }
            static /*void */ ThrowInvalidOperationException_InvalidExaminedPosition()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidExaminedPosition();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidExaminedPosition()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.InvalidExaminedPosition);
            }
            static /*void */ ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidExaminedOrConsumedPosition();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidExaminedOrConsumedPosition()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.InvalidExaminedOrConsumedPosition);
            }
            static /*void */ ThrowInvalidOperationException_AdvanceToInvalidCursor()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_AdvanceToInvalidCursor();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_AdvanceToInvalidCursor()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.AdvanceToInvalidCursor);
            }
            static /*void */ ThrowInvalidOperationException_ResetIncompleteReaderWriter()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_ResetIncompleteReaderWriter();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_ResetIncompleteReaderWriter()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ReaderAndWriterHasToBeCompleted);
            }
            static /*void */ ThrowOperationCanceledException_ReadCanceled()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateOperationCanceledException_ReadCanceled();
            }
            static /*OperationCanceledException */ CreateOperationCanceledException_ReadCanceled()
            {
                return new $.$spc.System.OperationCanceledException().$ctor$10($.$sipl.System.SR.ReadCanceledOnPipeReader);
            }
            static /*void */ ThrowOperationCanceledException_FlushCanceled()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateOperationCanceledException_FlushCanceled();
            }
            static /*OperationCanceledException */ CreateOperationCanceledException_FlushCanceled()
            {
                return new $.$spc.System.OperationCanceledException().$ctor$10($.$sipl.System.SR.FlushCanceledOnPipeWriter);
            }
            static /*void */ ThrowInvalidOperationException_InvalidZeroByteRead()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidZeroByteRead();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidZeroByteRead()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.InvalidZeroByteRead);
            }
            static /*void */ ThrowNotSupported_UnflushedBytes()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateNotSupportedException_UnflushedBytes();
            }
            static /*NotSupportedException */ CreateNotSupportedException_UnflushedBytes()
            {
                return new $.$spc.System.NotSupportedException().$ctor$10($.$sipl.System.SR.UnflushedBytesNotSupported);
            }
            static $h = 2358433;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":392353}],"n":"ThrowArgumentOutOfRangeException","d":2358433,"h":4297325729,"f":40},{"r":13565953,"p":[{"n":"argument","p":392353}],"n":"CreateArgumentOutOfRangeException","d":2358433,"h":8592293025,"f":34},{"r":65537,"p":[{"n":"argument","p":392353}],"n":"ThrowArgumentNullException","d":2358433,"h":12887260321,"f":40},{"r":13500417,"p":[{"n":"argument","p":392353}],"n":"CreateArgumentNullException","d":2358433,"h":17182227617,"f":34},{"r":65537,"n":"ThrowInvalidOperationException_AlreadyReading","d":2358433,"h":21477194913,"f":33},{"r":58261505,"n":"CreateInvalidOperationException_AlreadyReading","d":2358433,"h":25772162209,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoReadToComplete","d":2358433,"h":30067129505,"f":33},{"r":58261505,"n":"CreateInvalidOperationException_NoReadToComplete","d":2358433,"h":34362096801,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoConcurrentOperation","d":2358433,"h":38657064097,"f":33},{"r":58261505,"n":"CreateInvalidOperationException_NoConcurrentOperation","d":2358433,"h":42952031393,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_GetResultNotCompleted","d":2358433,"h":47246998689,"f":33},{"r":58261505,"n":"CreateInvalidOperationException_GetResultNotCompleted","d":2358433,"h":51541965985,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoWritingAllowed","d":2358433,"h":55836933281,"f":33},{"r":58261505,"n":"CreateInvalidOperationException_NoWritingAllowed","d":2358433,"h":60131900577,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoReadingAllowed","d":2358433,"h":64426867873,"f":33},{"r":58261505,"n":"CreateInvalidOperationException_NoReadingAllowed","d":2358433,"h":68721835169,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_InvalidExaminedPosition","d":2358433,"h":73016802465,"f":33},{"r":58261505,"n":"CreateInvalidOperationException_InvalidExaminedPosition","d":2358433,"h":77311769761,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition","d":2358433,"h":81606737057,"f":33},{"r":58261505,"n":"CreateInvalidOperationException_InvalidExaminedOrConsumedPosition","d":2358433,"h":85901704353,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_AdvanceToInvalidCursor","d":2358433,"h":90196671649,"f":33},{"r":58261505,"n":"CreateInvalidOperationException_AdvanceToInvalidCursor","d":2358433,"h":94491638945,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_ResetIncompleteReaderWriter","d":2358433,"h":98786606241,"f":33},{"r":58261505,"n":"CreateInvalidOperationException_ResetIncompleteReaderWriter","d":2358433,"h":103081573537,"f":33},{"r":65537,"n":"ThrowOperationCanceledException_ReadCanceled","d":2358433,"h":107376540833,"f":33},{"r":71106561,"n":"CreateOperationCanceledException_ReadCanceled","d":2358433,"h":111671508129,"f":33},{"r":65537,"n":"ThrowOperationCanceledException_FlushCanceled","d":2358433,"h":115966475425,"f":33},{"r":71106561,"n":"CreateOperationCanceledException_FlushCanceled","d":2358433,"h":120261442721,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_InvalidZeroByteRead","d":2358433,"h":124556410017,"f":33},{"r":58261505,"n":"CreateInvalidOperationException_InvalidZeroByteRead","d":2358433,"h":128851377313,"f":33},{"r":65537,"n":"ThrowNotSupported_UnflushedBytes","d":2358433,"h":133146344609,"f":33},{"r":66781185,"n":"CreateNotSupportedException_UnflushedBytes","d":2358433,"h":137441311905,"f":33}],"h":2358433}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.ThrowHelper`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeWriterOptions", ($self) => class StreamPipeWriterOptions extends $.$spc.System.Object
        {
            /*int*/ static DefaultMinimumBufferSize = 4096;
            /*StreamPipeWriterOptions*/ static s_default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*int*/ minimumBufferSize, /*bool*/ leaveOpen)
            {
                super.$ctor();
                {
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.MinimumBufferSize = minimumBufferSize === -1 ? 4096/*DefaultMinimumBufferSize*/ : minimumBufferSize <= 0 ? (() =>
                    {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("minimumBufferSize")            })() : minimumBufferSize;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*int*/ MinimumBufferSize = 0;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ LeaveOpen = false;
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_default = new $.$sipl.System.IO.Pipelines.StreamPipeWriterOptions().$ctor$1(null, -1, false);
                }
            }
            static $h = 2227361;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25772031137,"f":1},"n":"MinimumBufferSize","d":2227361,"h":21477063841,"f":1},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":38656933025,"f":1},"n":"Pool","d":2227361,"h":34361965729,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51541834913,"f":1},"n":"LeaveOpen","d":2227361,"h":47246867617,"f":1}],"l":[{"t":655361,"n":"DefaultMinimumBufferSize","d":2227361,"h":4297194657,"f":34},{"t":2227361,"n":"s_default","d":2227361,"h":8592161953,"f":40}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"f":65},{"n":"minimumBufferSize","p":655361,"f":65,"v":-1},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$1","d":2227361,"h":12887129249,"f":1}],"h":2227361}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeWriterOptions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeExtensions", ($self) => class StreamPipeExtensions
        {
            static /*Task */ CopyToAsync(/*this Stream*/ source, /*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (source === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.source*/);
                }
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return destination.CopyFromAsync(source, cancellationToken);
            }
            static $h = 1965217;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"p":[{"n":"source","p":62193665},{"n":"destination","p":1637537},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","d":1965217,"h":4296932513,"f":33}],"h":1965217}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeExtensions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeReaderOptions", ($self) => class StreamPipeReaderOptions extends $.$spc.System.Object
        {
            /*int*/ static DefaultBufferSize = 4096;
            /*int*/ static DefaultMaxBufferSize = 2097152;
            /*int*/ static DefaultMinimumReadSize = 1024;
            /*StreamPipeReaderOptions*/ static s_default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*int*/ bufferSize, /*int*/ minimumReadSize, /*bool*/ leaveOpen)
            {
                this.$ctor$2(null, -1, -1, false, false);
                {
                }
                return this;
            }
            $ctor$2(/*MemoryPool<byte>?*/ pool, /*int*/ bufferSize, /*int*/ minimumReadSize, /*bool*/ leaveOpen, /*bool*/ useZeroByteReads)
            {
                super.$ctor();
                {
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.IsDefaultSharedMemoryPool = this.Pool === $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.BufferSize = bufferSize === -1 ? 4096/*DefaultBufferSize*/ : bufferSize <= 0 ? (() =>
                    {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("bufferSize")            })() : bufferSize;
                    this.MinimumReadSize = minimumReadSize === -1 ? 1024/*DefaultMinimumReadSize*/ : minimumReadSize <= 0 ? (() =>
                    {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("minimumReadSize")            })() : minimumReadSize;
                    this.LeaveOpen = leaveOpen;
                    this.UseZeroByteReads = useZeroByteReads;
                }
                return this;
            }
            /*int*/ BufferSize = 0;
            /*int*/ MaxBufferSize = 0;
            /*int*/ MinimumReadSize = 0;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ LeaveOpen = false;
            /*bool*/ UseZeroByteReads = false;
            /*bool*/ IsDefaultSharedMemoryPool = false;
            //default member initializer
            constructor()
            {
                super();
                this.MaxBufferSize = 2097152;
                this.LeaveOpen = false;
                this.UseZeroByteReads = false;
                this.IsDefaultSharedMemoryPool = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_default = new $.$sipl.System.IO.Pipelines.StreamPipeReaderOptions().$ctor$2(null, -1, -1, false, false);
                }
            }
            static $h = 2096289;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":38656801953,"f":1},"n":"BufferSize","d":2096289,"h":34361834657,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51541703841,"f":8},"n":"MaxBufferSize","d":2096289,"h":47246736545,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":64426605729,"f":1},"n":"MinimumReadSize","d":2096289,"h":60131638433,"f":1},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":77311507617,"f":1},"n":"Pool","d":2096289,"h":73016540321,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":90196409505,"f":1},"n":"LeaveOpen","d":2096289,"h":85901442209,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":103081311393,"f":1},"n":"UseZeroByteReads","d":2096289,"h":98786344097,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115966213281,"f":8},"n":"IsDefaultSharedMemoryPool","d":2096289,"h":111671245985,"f":8}],"l":[{"t":655361,"n":"DefaultBufferSize","d":2096289,"h":4297063585,"f":34},{"t":655361,"n":"DefaultMaxBufferSize","d":2096289,"h":8592030881,"f":40},{"t":655361,"n":"DefaultMinimumReadSize","d":2096289,"h":12886998177,"f":34},{"t":2096289,"n":"s_default","d":2096289,"h":17181965473,"f":40}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h},{"n":"bufferSize","p":655361},{"n":"minimumReadSize","p":655361},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$1","d":2096289,"h":21476932769,"f":1},{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"f":65},{"n":"bufferSize","p":655361,"f":65,"v":-1},{"n":"minimumReadSize","p":655361,"f":65,"v":-1},{"n":"leaveOpen","p":262145,"f":65,"v":false},{"n":"useZeroByteReads","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$2","d":2096289,"h":25771900065,"f":1}],"h":2096289}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeReaderOptions`; }
        });
        
        $asm.$cls("$sipl.System.IO.StreamHelpers", ($self) => class StreamHelpers
        {
            static /*void */ ValidateCopyToArgs(/*Stream*/ source, /*Stream*/ destination, /*int*/ bufferSize)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(destination, "destination");
                if (bufferSize <= 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("bufferSize", $.$box(bufferSize, $.$spc.System.Int32), $.$sipl.System.SR.ArgumentOutOfRange_NeedPosNum);
                }
                /*bool*/ let sourceCanRead = source.CanRead;
                if (!sourceCanRead && !source.CanWrite)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15(null, $.$sipl.System.SR.ObjectDisposed_StreamClosed);
                }
                /*bool*/ let destinationCanWrite = destination.CanWrite;
                if (!destinationCanWrite && !destination.CanRead)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15("destination", $.$sipl.System.SR.ObjectDisposed_StreamClosed);
                }
                if (!sourceCanRead)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sipl.System.SR.NotSupported_UnreadableStream);
                }
                if (!destinationCanWrite)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sipl.System.SR.NotSupported_UnwritableStream);
                }
            }
            static $h = 2423969;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"source","p":62193665},{"n":"destination","p":62193665},{"n":"bufferSize","p":655361}],"n":"ValidateCopyToArgs","d":2423969,"h":4297391265,"f":33}],"h":2423969}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.StreamHelpers`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.InlineScheduler", ($self) => class InlineScheduler extends $.$sipl.System.IO.Pipelines.PipeScheduler
        {
            /*void */ Schedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                action.Invoke(state);
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                action.Invoke(state);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 588961;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1572001,"m":[{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":588961,"h":4295556257,"f":32769},{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":588961,"h":8590523553,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":588961,"h":12885490849,"f":1}],"h":588961}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeScheduler; }
            static get $fullName() { return `System.IO.Pipelines.InlineScheduler`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.BufferSegmentStack", ($self) => class BufferSegmentStack extends $.$spc.System.ValueType
        {
            /*SegmentAsValueType[]*/  get _array() { return this.$getField(0, 4); }
            /*SegmentAsValueType[]*/  set _array(value) { this.$setField(0, 4, value); }
            /*int*/  get _size() { return this.$getField(4, 4); }
            /*int*/  set _size(value) { this.$setField(4, 4, value); }
            $ctor$2(/*int*/ size)
            {
                super.$ctor$1();
                {
                    this._array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType), null, [size], null);
                    this._size = 0;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._size;
            }
            /*bool */ TryPop(/*out BufferSegment?*/ result)
            {
                /*int*/ let size = ((this._size - 1) | 0);
                /*SegmentAsValueType[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    result.$v = null;
                    return false;
                }
                this._size = size;
                result.$v = $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit$1($.$spc.System.Array.$ReadT1.call(array, size));
                $.$spc.System.Array.$WriteT1.call(array, new $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType(), size);
                return true;
            }
            /*void */ Push(/*BufferSegment*/ item)
            {
                /*int*/ let size = this._size;
                /*SegmentAsValueType[]*/ let array = this._array;
                if ((size >>> 0) < (array.length >>> 0))
                {
                    $.$spc.System.Array.$WriteT1.call(array, $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit(item), size);
                    this._size = ((size + 1) | 0);
                }
                else 
                {
                    this.PushWithResize(item);
                }
            }
            /*void */ PushWithResize(/*BufferSegment*/ item)
            {
                $.$spc.System.Array.Resize($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType, $.$ref(() => this._array, ($v) => this._array = $v, $.$typeArray($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType)), ((2 * this._array.length) | 0));
                $.$spc.System.Array.$WriteT1.call(this._array, $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit(item), this._size);
                this._size++;
            }
            static $_SegmentAsValueType;
            static get SegmentAsValueType()
            {
                let $cls = $.$sipl.System.IO.Pipelines.BufferSegmentStack;
                return $cls.$_SegmentAsValueType ??= $asm.$nstr("$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType", ($self) => class SegmentAsValueType extends $.$spc.System.ValueType
                {
                    /*BufferSegment*/  get _value() { return this.$getField(0, 4); }
                    /*BufferSegment*/  set _value(value) { this.$setField(0, 4, value); }
                    $ctor$2(/*BufferSegment*/ value)
                    {
                        super.$ctor$1();
                        this._value = value;
                        return this;
                    }
                    static /*SegmentAsValueType */ op_Implicit(/*BufferSegment*/ s)
                    {
                        return new $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType().$ctor$2(s);
                    }
                    static /*BufferSegment */ op_Implicit$1(/*SegmentAsValueType*/ s)
                    {
                        return s._value;
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._value = this._value;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._value = null;
                    }
                    static $h = 261281;
                    static $z = 4;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":130209,"n":"_value","d":261281,"h":4295228577,"f":2}],"c":[{"p":[{"n":"value","p":130209}],"n":".ctor","o":"$ctor$2","d":261281,"h":8590195873,"f":2},{"n":".ctor","o":"$ctor$3","d":261281,"h":21475097761,"f":1}],"d":195745,"h":261281}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType`; }
                }, $cls, ($v) => $cls.$_SegmentAsValueType = $v);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._array = this._array;
                copy._size = this._size;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._array = null;
                this._size = 0;
            }
            static $h = 195745;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21475032225,"f":1},"n":"Count","d":195745,"h":17180064929,"f":1}],"m":[{"r":262145,"p":[{"n":"result","p":130209,"f":2}],"n":"TryPop","d":195745,"h":25769999521,"f":1},{"r":65537,"p":[{"n":"item","p":130209}],"n":"Push","d":195745,"h":30064966817,"f":1},{"r":65537,"p":[{"n":"item","p":130209}],"n":"PushWithResize","d":195745,"h":34359934113,"f":2}],"l":[{"t":0,"n":"_array","d":195745,"h":4295163041,"f":2},{"t":655361,"n":"_size","d":195745,"h":8590130337,"f":2}],"c":[{"p":[{"n":"size","p":655361}],"n":".ctor","o":"$ctor$2","d":195745,"h":12885097633,"f":1},{"n":".ctor","o":"$ctor$3","d":195745,"h":42949868705,"f":1}],"j":[261281],"h":195745}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.BufferSegmentStack`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.CompletionData", ($self) => class CompletionData extends $.$spc.System.ValueType
        {
            /*Action<object?>*/ Completion = null;
            /*object?*/ CompletionState = null;
            /*ExecutionContext?*/ ExecutionContext = null;
            /*SynchronizationContext?*/ SynchronizationContext = null;
            $ctor$2(/*Action<object?>*/ completion, /*object?*/ completionState, /*ExecutionContext?*/ executionContext, /*SynchronizationContext?*/ synchronizationContext)
            {
                super.$ctor$1();
                {
                    this.Completion = completion;
                    this.CompletionState = completionState;
                    this.ExecutionContext = executionContext;
                    this.SynchronizationContext = synchronizationContext;
                }
                return this;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Completion = this.Completion;
                copy.CompletionState = this.CompletionState;
                copy.ExecutionContext = this.ExecutionContext;
                copy.SynchronizationContext = this.SynchronizationContext;
                return copy;
            }
            static $h = 326817;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.Action$$($.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":12885228705,"f":1},"n":"Completion","d":326817,"h":8590261409,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":25770130593,"f":1},"n":"CompletionState","d":326817,"h":21475163297,"f":1},{"p":126943233,"g":{"r":0,"d":0,"h":38655032481,"f":1},"n":"ExecutionContext","d":326817,"h":34360065185,"f":1},{"p":131137537,"g":{"r":0,"d":0,"h":51539934369,"f":1},"n":"SynchronizationContext","d":326817,"h":47244967073,"f":1}],"c":[{"p":[{"n":"completion","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"completionState","p":131073},{"n":"executionContext","p":126943233},{"n":"synchronizationContext","p":131137537}],"n":".ctor","o":"$ctor$2","d":326817,"h":55834901665,"f":1},{"n":".ctor","o":"$ctor$3","d":326817,"h":60129868961,"f":1}],"h":326817}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.CompletionData`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.FlushResult", ($self) => class FlushResult extends $.$spc.System.ValueType
        {
            /*ResultFlags*/  get _resultFlags() { return this.$getField(0, $.$sipl.System.IO.Pipelines.ResultFlags); }
            /*ResultFlags*/  set _resultFlags(value) { this.$setField(0, $.$sipl.System.IO.Pipelines.ResultFlags, value); }
            $ctor$2(/*bool*/ isCanceled, /*bool*/ isCompleted)
            {
                super.$ctor$1();
                {
                    this._resultFlags = 0/*ResultFlags.None*/;
                    if (isCanceled)
                    {
                        this._resultFlags |= 1/*ResultFlags.Canceled*/;
                    }
                    if (isCompleted)
                    {
                        this._resultFlags |= 2/*ResultFlags.Completed*/;
                    }
                }
                return this;
            }
            /*bool */ get IsCanceled()
            {
                return (this._resultFlags & 1/*ResultFlags.Canceled*/) !== 0;
            }
            /*bool */ get IsCompleted()
            {
                return (this._resultFlags & 2/*ResultFlags.Completed*/) !== 0;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resultFlags = this._resultFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resultFlags = 0;
            }
            static $h = 457889;
            static $z = 1;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180327073,"f":1},"n":"IsCanceled","d":457889,"h":12885359777,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770261665,"f":1},"n":"IsCompleted","d":457889,"h":21475294369,"f":1}],"l":[{"t":1834145,"n":"_resultFlags","d":457889,"h":4295425185,"f":8}],"c":[{"p":[{"n":"isCanceled","p":262145},{"n":"isCompleted","p":262145}],"n":".ctor","o":"$ctor$2","d":457889,"h":8590392481,"f":1},{"n":".ctor","o":"$ctor$3","d":457889,"h":30065228961,"f":1}],"h":457889}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.FlushResult`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeCompletion", ($self) => class PipeCompletion extends $.$spc.System.ValueType
        {
            /*object*/ static s_completedSuccessfully = null;
            /*object?*/  get _state() { return this.$getField(0, 4); }
            /*object?*/  set _state(value) { this.$setField(0, 4, value); }
            /*List<PipeCompletionCallback>?*/  get _callbacks() { return this.$getField(4, 4); }
            /*List<PipeCompletionCallback>?*/  set _callbacks(value) { this.$setField(4, 4, value); }
            /*bool */ get IsCompleted()
            {
                return this._state !== null;
            }
            /*bool */ get IsFaulted()
            {
                return $.$is(this._state, $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo);
            }
            /*PipeCompletionCallbacks? */ TryComplete(/*Exception?*/ exception)
            {
                if (this._state === null)
                {
                    if (exception !== null)
                    {
                        this._state = $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exception);
                    }
                    else 
                    {
                        this._state = $.$sipl.System.IO.Pipelines.PipeCompletion.s_completedSuccessfully;
                    }
                }
                return this.GetCallbacks();
            }
            /*PipeCompletionCallbacks? */ AddCallback(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                this._callbacks ??= new ($.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback))().$ctor$1();
                this._callbacks.Add(new $.$sipl.System.IO.Pipelines.PipeCompletionCallback().$ctor$2(callback, state));
                if (this.IsCompleted)
                {
                    return this.GetCallbacks();
                }
                return null;
            }
            /*bool */ IsCompletedOrThrow()
            {
                if (!this.IsCompleted)
                {
                    return false;
                }
                let edi;
                if ($.$is(this._state, $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo, { set $v(v){ edi = v; } }))
                {
                    edi.Throw();
                }
                return true;
            }
            /*PipeCompletionCallbacks? */ GetCallbacks()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsCompleted, "IsCompleted");
                /*var*/ let callbacks = this._callbacks;
                if (callbacks === null)
                {
                    return null;
                }
                this._callbacks = null;
                return new $.$sipl.System.IO.Pipelines.PipeCompletionCallbacks().$ctor$1(callbacks, $.$as(this._state, $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo));
            }
            /*void */ Reset()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsCompleted, "IsCompleted");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._callbacks === null, "_callbacks == null");
                this._state = null;
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `${"IsCompleted"}: ${this.IsCompleted}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sipl.System.IO.Pipelines.PipeCompletion.ToString.apply(this, arguments); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._state = this._state;
                copy._callbacks = this._callbacks;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = null;
                this._callbacks = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_completedSuccessfully = new $.$spc.System.Object().$ctor();
                }
            }
            static $h = 1047713;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475884193,"f":1},"n":"IsCompleted","d":1047713,"h":17180916897,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065818785,"f":1},"n":"IsFaulted","d":1047713,"h":25770851489,"f":1}],"m":[{"r":1178785,"p":[{"n":"exception","p":47251457,"f":65}],"n":"TryComplete","d":1047713,"h":34360786081,"f":1},{"r":1178785,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"AddCallback","d":1047713,"h":38655753377,"f":1},{"r":262145,"n":"IsCompletedOrThrow","d":1047713,"h":42950720673,"f":1},{"r":1178785,"n":"GetCallbacks","d":1047713,"h":47245687969,"f":2},{"r":65537,"n":"Reset","d":1047713,"h":51540655265,"f":1},{"r":1310721,"n":"ToString","d":1047713,"h":55835622561,"f":32769}],"l":[{"t":131073,"n":"s_completedSuccessfully","d":1047713,"h":4296015009,"f":34},{"t":131073,"n":"_state","d":1047713,"h":8590982305,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h,"n":"_callbacks","d":1047713,"h":12885949601,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1047713,"h":60130589857,"f":1}],"h":1047713,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"IsCompleted = {IsCompleted}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletion`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeCompletionCallback", ($self) => class PipeCompletionCallback extends $.$spc.System.ValueType
        {
            /*Action<Exception?, object?>*/  get Callback() { return this.$getField(0, 4); }
            /*Action<Exception?, object?>*/  set Callback(value) { this.$setField(0, 4, value); }
            /*object?*/  get State() { return this.$getField(4, 4); }
            /*object?*/  set State(value) { this.$setField(4, 4, value); }
            $ctor$2(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                super.$ctor$1();
                {
                    this.Callback = callback;
                    this.State = state;
                }
                return this;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Callback = this.Callback;
                copy.State = this.State;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Callback = null;
                this.State = null;
            }
            static $h = 1113249;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h,"n":"Callback","d":1113249,"h":4296080545,"f":1},{"t":131073,"n":"State","d":1113249,"h":8591047841,"f":1}],"c":[{"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":".ctor","o":"$ctor$2","d":1113249,"h":12886015137,"f":1},{"n":".ctor","o":"$ctor$3","d":1113249,"h":17180982433,"f":1}],"h":1113249}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletionCallback`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.SequencePipeReader", ($self) => class SequencePipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
        {
            /*ReadOnlySequence<byte>*/ _sequence;
            /*bool*/ _isReaderCompleted = false;
            /*int*/ _cancelNext = 0;
            $ctor$2(/*ReadOnlySequence<byte>*/ sequence)
            {
                super.$ctor$1();
                {
                    this._sequence = sequence;
                }
                return this;
            }
            /*void */ AdvanceTo(/*SequencePosition*/ consumed)
            {
                this.AdvanceTo$1(consumed, consumed);
            }
            /*void */ AdvanceTo$1(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
            {
                this.ThrowIfCompleted();
                if (consumed.Equals$2(this._sequence.End))
                {
                    this._sequence = $.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).Empty;
                    return;
                }
                this._sequence = this._sequence.Slice$7(consumed);
            }
            /*void */ CancelPendingRead()
            {
                $.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._cancelNext, ($v) => this._cancelNext = $v, $.$spc.System.Int32), 1);
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this._isReaderCompleted)
                {
                    return;
                }
                this._isReaderCompleted = true;
                this._sequence = $.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).Empty;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                /*ReadResult*/ let result;
                if (this.TryRead($.$ref(() => result, ($v) => result = $v, $.$sipl.System.IO.Pipelines.ReadResult)))
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(result);
                }
                result = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).Empty, false, true);
                return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(result);
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                this.ThrowIfCompleted();
                /*bool*/ let isCancellationRequested = $.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._cancelNext, ($v) => this._cancelNext = $v, $.$spc.System.Int32), 0) === 1;
                if (isCancellationRequested || this._sequence.Length > 0n)
                {
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(this._sequence, isCancellationRequested, true);
                    return true;
                }
                result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                return false;
            }
            /*void */ ThrowIfCompleted()
            {
                if (this._isReaderCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._sequence = $.$default($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte));
            }
            static $h = 1899681;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1440929,"m":[{"r":65537,"p":[{"n":"consumed","p":1244122}],"n":"AdvanceTo","d":1899681,"h":21476736161,"f":32769},{"r":65537,"p":[{"n":"consumed","p":1244122},{"n":"examined","p":1244122}],"n":"AdvanceTo","o":"@$1","d":1899681,"h":25771703457,"f":32769},{"r":65537,"n":"CancelPendingRead","d":1899681,"h":30066670753,"f":32769},{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":1899681,"h":34361638049,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":1899681,"h":38656605345,"f":32769},{"r":262145,"p":[{"n":"result","p":1768609,"f":2}],"n":"TryRead","d":1899681,"h":42951572641,"f":32769},{"r":65537,"n":"ThrowIfCompleted","d":1899681,"h":47246539937,"f":2}],"l":[{"t":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"n":"_sequence","d":1899681,"h":4296866977,"f":2},{"t":262145,"n":"_isReaderCompleted","d":1899681,"h":8591834273,"f":2},{"t":655361,"n":"_cancelNext","d":1899681,"h":12886801569,"f":2}],"c":[{"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h}],"n":".ctor","o":"$ctor$2","d":1899681,"h":17181768865,"f":1}],"h":1899681}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
            static get $fullName() { return `System.IO.Pipelines.SequencePipeReader`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.ThreadPoolScheduler", ($self) => class ThreadPoolScheduler extends $.$sipl.System.IO.Pipelines.PipeScheduler
        {
            /*void */ Schedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                $.$spc.System.Threading.ThreadPool.QueueUserWorkItem$2($.$spc.System.Object, action, state, false);
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                $.$spc.System.Threading.ThreadPool.UnsafeQueueUserWorkItem($.$spc.System.Object, action, state, false);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2292897;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1572001,"m":[{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":2292897,"h":4297260193,"f":32769},{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":2292897,"h":8592227489,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":2292897,"h":12887194785,"f":1}],"h":2292897}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeScheduler; }
            static get $fullName() { return `System.IO.Pipelines.ThreadPoolScheduler`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ReadResult", ($self) => class ReadResult extends $.$spc.System.ValueType
        {
            /*ReadOnlySequence<byte>*/  get _resultBuffer() { return this.$getField(0, 16); }
            /*ReadOnlySequence<byte>*/  set _resultBuffer(value) { this.$setField(0, 16, value); }
            /*ResultFlags*/  get _resultFlags() { return this.$getField(16, 1); }
            /*ResultFlags*/  set _resultFlags(value) { this.$setField(16, 1, value); }
            $ctor$2(/*ReadOnlySequence<byte>*/ buffer, /*bool*/ isCanceled, /*bool*/ isCompleted)
            {
                super.$ctor$1();
                {
                    this._resultBuffer = buffer;
                    this._resultFlags = 0/*ResultFlags.None*/;
                    if (isCompleted)
                    {
                        this._resultFlags |= 2/*ResultFlags.Completed*/;
                    }
                    if (isCanceled)
                    {
                        this._resultFlags |= 1/*ResultFlags.Canceled*/;
                    }
                }
                return this;
            }
            /*ReadOnlySequence<byte> */ get Buffer()
            {
                return this._resultBuffer;
            }
            /*bool */ get IsCanceled()
            {
                return (this._resultFlags & 1/*ResultFlags.Canceled*/) !== 0;
            }
            /*bool */ get IsCompleted()
            {
                return (this._resultFlags & 2/*ResultFlags.Completed*/) !== 0;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resultBuffer = this._resultBuffer.Clone();
                copy._resultFlags = this._resultFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resultBuffer = $.$default($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte));
                this._resultFlags = 0;
            }
            static $h = 1768609;
            static $z = 17;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":21476605089,"f":1},"n":"Buffer","d":1768609,"h":17181637793,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30066539681,"f":1},"n":"IsCanceled","d":1768609,"h":25771572385,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38656474273,"f":1},"n":"IsCompleted","d":1768609,"h":34361506977,"f":1}],"l":[{"t":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"n":"_resultBuffer","d":1768609,"h":4296735905,"f":8},{"t":1834145,"n":"_resultFlags","d":1768609,"h":8591703201,"f":8}],"c":[{"p":[{"n":"buffer","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h},{"n":"isCanceled","p":262145},{"n":"isCompleted","p":262145}],"n":".ctor","o":"$ctor$2","d":1768609,"h":12886670497,"f":1},{"n":".ctor","o":"$ctor$3","d":1768609,"h":42951441569,"f":1}],"h":1768609}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.ReadResult`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeOperationState", ($self) => class PipeOperationState extends $.$spc.System.ValueType
        {
            /*State*/  get _state() { return this.$getField(0, $.$sipl.System.IO.Pipelines.PipeOperationState.State); }
            /*State*/  set _state(value) { this.$setField(0, $.$sipl.System.IO.Pipelines.PipeOperationState.State, value); }
            /*void */ BeginRead()
            {
                if ((this._state & 1/*State.Reading*/) === 1/*State.Reading*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                }
                this._state |= 1/*State.Reading*/;
            }
            /*void */ BeginReadTentative()
            {
                if ((this._state & 1/*State.Reading*/) === 1/*State.Reading*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                }
                this._state |= 2/*State.ReadingTentative*/;
            }
            /*void */ EndRead()
            {
                if ((this._state & 1/*State.Reading*/) !== 1/*State.Reading*/ && (this._state & 2/*State.ReadingTentative*/) !== 2/*State.ReadingTentative*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadToComplete();
                }
                this._state &= ~(1/*State.Reading*/ | 2/*State.ReadingTentative*/);
            }
            /*void */ BeginWrite()
            {
                this._state |= 4/*State.Writing*/;
            }
            /*void */ EndWrite()
            {
                this._state &= ~4/*State.Writing*/;
            }
            /*bool */ get IsWritingActive()
            {
                return (this._state & 4/*State.Writing*/) === 4/*State.Writing*/;
            }
            /*bool */ get IsReadingActive()
            {
                return (this._state & 1/*State.Reading*/) === 1/*State.Reading*/;
            }
            static $_State;
            static get State()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeOperationState;
                return $cls.$_State ??= $asm.$nstr("$sipl.System.IO.Pipelines.PipeOperationState.State", ($self) => class State extends $.$spc.System.Enum
                {
                    static Reading = 1;
                    static ReadingTentative = 2;
                    static Writing = 4;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Reading": 1n,
                            "ReadingTentative": 2n,
                            "Writing": 4n
                        };
                    }
                    static $h = 1309857;
                    static $z = 1;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Byte; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":1309857,"n":"Reading","d":1309857,"h":4296277153,"f":33},{"t":1309857,"n":"ReadingTentative","d":1309857,"h":8591244449,"f":33},{"t":1309857,"n":"Writing","d":1309857,"h":12886211745,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1309857,"h":17181179041,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":1244321,"h":1309857,"a":[{"t":47710209,"c":4342677505}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Pipelines.PipeOperationState.State`; }
                }, $cls, ($v) => $cls.$_State = $v);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._state = this._state;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = 0;
            }
            static $h = 1244321;
            static $z = 1;
            static $f = 0b10000000000001010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360982689,"f":1},"n":"IsWritingActive","d":1244321,"h":30066015393,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950917281,"f":1},"n":"IsReadingActive","d":1244321,"h":38655949985,"f":1}],"m":[{"r":65537,"n":"BeginRead","d":1244321,"h":8591178913,"f":1},{"r":65537,"n":"BeginReadTentative","d":1244321,"h":12886146209,"f":1},{"r":65537,"n":"EndRead","d":1244321,"h":17181113505,"f":1},{"r":65537,"n":"BeginWrite","d":1244321,"h":21476080801,"f":1},{"r":65537,"n":"EndWrite","d":1244321,"h":25771048097,"f":1}],"l":[{"t":1309857,"n":"_state","d":1244321,"h":4296211617,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1244321,"h":51540851873,"f":1}],"j":[1309857],"h":1244321,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"State = {_state}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeOperationState`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeAwaitable", ($self) => class PipeAwaitable extends $.$spc.System.ValueType
        {
            /*AwaitableState*/  get _awaitableState() { return this.$getField(0, 4); }
            /*AwaitableState*/  set _awaitableState(value) { this.$setField(0, 4, value); }
            /*Action<object?>?*/  get _completion() { return this.$getField(4, 4); }
            /*Action<object?>?*/  set _completion(value) { this.$setField(4, 4, value); }
            /*object?*/  get _completionState() { return this.$getField(8, 4); }
            /*object?*/  set _completionState(value) { this.$setField(8, 4, value); }
            /*SchedulingContext?*/  get _schedulingContext() { return this.$getField(12, 4); }
            /*SchedulingContext?*/  set _schedulingContext(value) { this.$setField(12, 4, value); }
            /*CancellationTokenRegistration*/  get _cancellationTokenRegistration() { return this.$getField(16, 12); }
            /*CancellationTokenRegistration*/  set _cancellationTokenRegistration(value) { this.$setField(16, 12, value); }
            /*CancellationToken */ get CancellationToken()
            {
                return this._cancellationTokenRegistration.Token;
            }
            $ctor$2(/*bool*/ completed, /*bool*/ useSynchronizationContext)
            {
                super.$ctor$1();
                {
                    this._awaitableState = (completed ? 1/*AwaitableState.Completed*/ : 0/*AwaitableState.None*/) | (useSynchronizationContext ? 8/*AwaitableState.UseSynchronizationContext*/ : 0/*AwaitableState.None*/);
                    this._completion = null;
                    this._completionState = null;
                    this._cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                    this._schedulingContext = null;
                }
                return this;
            }
            /*bool */ get IsCompleted()
            {
                return (this._awaitableState & (1/*AwaitableState.Completed*/ | 4/*AwaitableState.Canceled*/)) !== 0;
            }
            /*bool */ get IsRunning()
            {
                return (this._awaitableState & 2/*AwaitableState.Running*/) !== 0;
            }
            /*void */ BeginOperation(/*CancellationToken*/ cancellationToken, /*Action<object?>*/ callback, /*object?*/ state)
            {
                if (cancellationToken.CanBeCanceled && !this.IsCompleted)
                {
                    /*var*/ let previousAwaitableState = this._awaitableState;
                    this._cancellationTokenRegistration = cancellationToken.UnsafeRegister(callback, state);
                    if ($.$spc.System.Threading.CancellationTokenRegistration.op_Equality(this._cancellationTokenRegistration, $.$default($.$spc.System.Threading.CancellationTokenRegistration)))
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(previousAwaitableState === this._awaitableState, "The awaitable state changed!");
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                }
                this._awaitableState |= 2/*AwaitableState.Running*/;
            }
            /*void */ Complete(/*out CompletionData*/ completionData)
            {
                this.ExtractCompletion(completionData);
                this._awaitableState |= 1/*AwaitableState.Completed*/;
            }
            /*void */ ExtractCompletion(/*out CompletionData*/ completionData)
            {
                /*Action<object?>?*/ let currentCompletion = this._completion;
                /*object?*/ let currentState = this._completionState;
                /*SchedulingContext?*/ let schedulingContext = this._schedulingContext;
                /*ExecutionContext?*/ let executionContext = (schedulingContext?.ExecutionContext ?? null);
                /*SynchronizationContext?*/ let synchronizationContext = (schedulingContext?.SynchronizationContext ?? null);
                this._completion = null;
                this._completionState = null;
                this._schedulingContext = null;
                completionData.$v = currentCompletion !== null ? new $.$sipl.System.IO.Pipelines.CompletionData().$ctor$2(currentCompletion, currentState, executionContext, synchronizationContext) : new $.$sipl.System.IO.Pipelines.CompletionData();
            }
            /*void */ SetUncompleted()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._completion === null, "_completion == null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._completionState === null, "_completionState == null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._schedulingContext === null, "_schedulingContext == null");
                this._awaitableState &= ~1/*AwaitableState.Completed*/;
            }
            /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags, /*out CompletionData*/ completionData, /*out bool*/ doubleCompletion)
            {
                completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                doubleCompletion.$v = !(this._completion === null);
                if (this.IsCompleted || doubleCompletion.$v)
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData().$ctor$2(continuation, state, (this._schedulingContext?.ExecutionContext ?? null), (this._schedulingContext?.SynchronizationContext ?? null));
                    return;
                }
                this._completion = continuation;
                this._completionState = state;
                if ((this._awaitableState & 8/*AwaitableState.UseSynchronizationContext*/) !== 0 && (flags & 1/*ValueTaskSourceOnCompletedFlags.UseSchedulingContext*/) !== 0)
                {
                    /*SynchronizationContext?*/ let sc = $.$spc.System.Threading.SynchronizationContext.Current;
                    if (sc !== null && $.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(sc), $.$spc.System.Threading.SynchronizationContext.$type))
                    {
                        this._schedulingContext ??= new $.$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext().$ctor$1();
                        this._schedulingContext.SynchronizationContext = sc;
                    }
                }
                if ((flags & 2/*ValueTaskSourceOnCompletedFlags.FlowExecutionContext*/) !== 0)
                {
                    this._schedulingContext ??= new $.$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext().$ctor$1();
                    this._schedulingContext.ExecutionContext = $.$spc.System.Threading.ExecutionContext.Capture();
                }
            }
            /*void */ Cancel(/*out CompletionData*/ completionData)
            {
                this.ExtractCompletion(completionData);
                this._awaitableState |= 4/*AwaitableState.Canceled*/;
            }
            /*void */ CancellationTokenFired(/*out CompletionData*/ completionData)
            {
                if (this.CancellationToken.IsCancellationRequested)
                {
                    this.Cancel(completionData);
                }
                else 
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                }
            }
            /*bool */ ObserveCancellation()
            {
                /*bool*/ let isCanceled = (this._awaitableState & 4/*AwaitableState.Canceled*/) === 4/*AwaitableState.Canceled*/;
                this._awaitableState &= ~(4/*AwaitableState.Canceled*/ | 2/*AwaitableState.Running*/);
                return isCanceled;
            }
            /*CancellationTokenRegistration */ ReleaseCancellationTokenRegistration(/*out CancellationToken*/ cancellationToken)
            {
                cancellationToken.$v = this.CancellationToken;
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = this._cancellationTokenRegistration;
                this._cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                return cancellationTokenRegistration;
            }
            static $_AwaitableState;
            static get AwaitableState()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeAwaitable;
                return $cls.$_AwaitableState ??= $asm.$nstr("$sipl.System.IO.Pipelines.PipeAwaitable.AwaitableState", ($self) => class AwaitableState extends $.$spc.System.Enum
                {
                    static None = 0;
                    static Completed = 1;
                    static Running = 2;
                    static Canceled = 4;
                    static UseSynchronizationContext = 8;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "Completed": 1n,
                            "Running": 2n,
                            "Canceled": 4n,
                            "UseSynchronizationContext": 8n
                        };
                    }
                    static $h = 916641;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":916641,"n":"None","d":916641,"h":4295883937,"f":33},{"t":916641,"n":"Completed","d":916641,"h":8590851233,"f":33},{"t":916641,"n":"Running","d":916641,"h":12885818529,"f":33},{"t":916641,"n":"Canceled","d":916641,"h":17180785825,"f":33},{"t":916641,"n":"UseSynchronizationContext","d":916641,"h":21475753121,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":916641,"h":25770720417,"f":1}],"i":[57278465,63832065,57737217,57409537],"d":851105,"h":916641,"a":[{"t":47710209,"c":4342677505}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Pipelines.PipeAwaitable.AwaitableState`; }
                }, $cls, ($v) => $cls.$_AwaitableState = $v);
            }
            static $_SchedulingContext;
            static get SchedulingContext()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeAwaitable;
                return $cls.$_SchedulingContext ??= $asm.$ncls("$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext", ($self) => class SchedulingContext extends $.$spc.System.Object
                {
                    /*SynchronizationContext?*/ SynchronizationContext = null;
                    /*ExecutionContext?*/ ExecutionContext = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 982177;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131137537,"g":{"r":0,"d":0,"h":12885884065,"f":1},"s":{"r":0,"d":0,"h":17180851361,"f":1},"n":"SynchronizationContext","d":982177,"h":8590916769,"f":1},{"p":126943233,"g":{"r":0,"d":0,"h":30065753249,"f":1},"s":{"r":0,"d":0,"h":34360720545,"f":1},"n":"ExecutionContext","d":982177,"h":25770785953,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":982177,"h":38655687841,"f":1}],"d":851105,"h":982177}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Pipelines.PipeAwaitable.SchedulingContext`; }
                }, $cls, ($v) => $cls.$_SchedulingContext = $v);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._awaitableState = this._awaitableState;
                copy._completion = this._completion;
                copy._completionState = this._completionState;
                copy._schedulingContext = this._schedulingContext;
                copy._cancellationTokenRegistration = this._cancellationTokenRegistration.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._awaitableState = 0;
                this._completion = null;
                this._completionState = null;
                this._schedulingContext = null;
                this._cancellationTokenRegistration = $.$default($.$spc.System.Threading.CancellationTokenRegistration);
            }
            static $h = 851105;
            static $z = 28;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":125960193,"g":{"r":0,"d":0,"h":30065622177,"f":2},"n":"CancellationToken","d":851105,"h":25770654881,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":42950524065,"f":1},"n":"IsCompleted","d":851105,"h":38655556769,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540458657,"f":1},"n":"IsRunning","d":851105,"h":47245491361,"f":1}],"m":[{"r":65537,"p":[{"n":"cancellationToken","p":125960193},{"n":"callback","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"BeginOperation","d":851105,"h":55835425953,"f":1},{"r":65537,"p":[{"n":"completionData","p":326817,"f":2}],"n":"Complete","d":851105,"h":60130393249,"f":1},{"r":65537,"p":[{"n":"completionData","p":326817,"f":2}],"n":"ExtractCompletion","d":851105,"h":64425360545,"f":2},{"r":65537,"n":"SetUncompleted","d":851105,"h":68720327841,"f":1},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132972545},{"n":"completionData","p":326817,"f":2},{"n":"doubleCompletion","p":262145,"f":2}],"n":"OnCompleted","d":851105,"h":73015295137,"f":1},{"r":65537,"p":[{"n":"completionData","p":326817,"f":2}],"n":"Cancel","d":851105,"h":77310262433,"f":1},{"r":65537,"p":[{"n":"completionData","p":326817,"f":2}],"n":"CancellationTokenFired","d":851105,"h":81605229729,"f":1},{"r":262145,"n":"ObserveCancellation","d":851105,"h":85900197025,"f":1},{"r":126025729,"p":[{"n":"cancellationToken","p":125960193,"f":2}],"n":"ReleaseCancellationTokenRegistration","d":851105,"h":90195164321,"f":1}],"l":[{"t":916641,"n":"_awaitableState","d":851105,"h":4295818401,"f":2},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"_completion","d":851105,"h":8590785697,"f":2},{"t":131073,"n":"_completionState","d":851105,"h":12885752993,"f":2},{"t":982177,"n":"_schedulingContext","d":851105,"h":17180720289,"f":2},{"t":126025729,"n":"_cancellationTokenRegistration","d":851105,"h":21475687585,"f":2}],"c":[{"p":[{"n":"completed","p":262145},{"n":"useSynchronizationContext","p":262145}],"n":".ctor","o":"$ctor$2","d":851105,"h":34360589473,"f":1},{"n":".ctor","o":"$ctor$3","d":851105,"h":103080066209,"f":1}],"j":[916641,982177],"h":851105,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"CanceledState = {_awaitableState}, IsCompleted = {IsCompleted}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeAwaitable`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeReader", ($self) => class StreamPipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
        {
            /*int*/ static InitialSegmentPoolSize = 4;
            /*int*/ static MaxSegmentPoolSize = 256;
            /*CancellationTokenSource?*/ _internalTokenSource = null;
            /*bool*/ _isReaderCompleted = false;
            /*BufferSegment?*/ _readHead = null;
            /*int*/ _readIndex = 0;
            /*BufferSegment?*/ _readTail = null;
            /*long*/ _bufferedBytes = 0n;
            /*bool*/ _examinedEverything = false;
            /*object*/ _lock = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*StreamPipeReaderOptions*/ _options = null;
            $ctor$2(/*Stream*/ readingStream, /*StreamPipeReaderOptions*/ options)
            {
                super.$ctor$1();
                {
                    if (readingStream === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(10/*ExceptionArgument.readingStream*/);
                    }
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this.InnerStream = readingStream;
                    this._options = options;
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$2(4/*InitialSegmentPoolSize*/);
                }
                return this;
            }
            /*bool */ get LeaveOpen()
            {
                return this._options.LeaveOpen;
            }
            /*bool */ get UseZeroByteReads()
            {
                return this._options.UseZeroByteReads;
            }
            /*int */ get BufferSize()
            {
                return this._options.BufferSize;
            }
            /*int */ get MaxBufferSize()
            {
                return this._options.MaxBufferSize;
            }
            /*int */ get MinimumReadThreshold()
            {
                return this._options.MinimumReadSize;
            }
            /*MemoryPool<byte> */ get Pool()
            {
                return this._options.Pool;
            }
            /*Stream*/ InnerStream = null;
            /*void */ AdvanceTo(/*SequencePosition*/ consumed)
            {
                this.AdvanceTo$1(consumed, consumed);
            }
            /*CancellationTokenSource */ get InternalTokenSource()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        return this._internalTokenSource ??= new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
            }
            /*void */ AdvanceTo$1(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
            {
                this.ThrowIfCompleted();
                this.AdvanceTo$2($.$cast(consumed.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), consumed.GetInteger(), $.$cast(examined.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), examined.GetInteger());
            }
            /*void */ AdvanceTo$2(/*BufferSegment?*/ consumedSegment, /*int*/ consumedIndex, /*BufferSegment?*/ examinedSegment, /*int*/ examinedIndex)
            {
                if (consumedSegment === null || examinedSegment === null)
                {
                    return;
                }
                if (this._readHead === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AdvanceToInvalidCursor();
                }
                /*BufferSegment*/ let returnStart = this._readHead;
                /*BufferSegment?*/ let returnEnd = consumedSegment;
                /*long*/ let consumedBytes = $.$sipl.System.IO.Pipelines.BufferSegment.GetLength(returnStart, this._readIndex, consumedSegment, consumedIndex);
                this._bufferedBytes -= consumedBytes;
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bufferedBytes >= 0n, "_bufferedBytes >= 0");
                this._examinedEverything = false;
                if (examinedSegment === this._readTail)
                {
                    this._examinedEverything = examinedIndex === this._readTail.End;
                }
                if (this._bufferedBytes === 0n)
                {
                    returnEnd = null;
                    this._readHead = null;
                    this._readTail = null;
                    this._readIndex = 0;
                }
                else if (consumedIndex === returnEnd.Length)
                {
                    /*BufferSegment?*/ let nextBlock = returnEnd.NextSegment;
                    this._readHead = nextBlock;
                    this._readIndex = 0;
                    returnEnd = nextBlock;
                }
                else 
                {
                    this._readHead = consumedSegment;
                    this._readIndex = consumedIndex;
                }
                while(returnStart !== returnEnd)
                {
                    /*BufferSegment*/ let next = returnStart.NextSegment;
                    this.ReturnSegmentUnsynchronized(returnStart);
                    returnStart = next;
                }
            }
            /*void */ CancelPendingRead()
            {
                this.InternalTokenSource.Cancel();
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this.CompleteAndGetNeedsDispose())
                {
                    this.InnerStream.Dispose();
                }
            }
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                return this.CompleteAndGetNeedsDispose() ? this.InnerStream.DisposeAsync() : new $.$spc.System.Threading.Tasks.ValueTask();
            }
            /*bool */ CompleteAndGetNeedsDispose()
            {
                if (this._isReaderCompleted)
                {
                    return false;
                }
                this._isReaderCompleted = true;
                /*BufferSegment?*/ let segment = this._readHead;
                while(segment !== null)
                {
                    /*BufferSegment*/ let returnSegment = segment;
                    segment = segment.NextSegment;
                    returnSegment.Reset();
                }
                return !this.LeaveOpen;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                return this.ReadInternalAsync(null, cancellationToken);
            }
            /*ValueTask<ReadResult> */ ReadAtLeastAsyncCore(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadInternalAsync(minimumSize, cancellationToken);
            }
            /*ValueTask<ReadResult> */ ReadInternalAsync(/*int?*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfCompleted();
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.ReadResult, cancellationToken));
                }
                /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                /*ReadResult*/ let readResult;
                if (this.TryReadInternal(tokenSource, $.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult)))
                {
                    if (minimumSize === null || readResult.Buffer.Length >= minimumSize || readResult.IsCompleted || readResult.IsCanceled)
                    {
                        return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(readResult);
                    }
                }
                return Core(this, minimumSize, tokenSource, cancellationToken);
                /*static ValueTask<ReadResult>*/ /*async*/  function Core(/*StreamPipeReader*/ reader, /*int?*/ minimumSize, /*CancellationTokenSource*/ tokenSource, /*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult), $.$sipl.System.IO.Pipelines.ReadResult, async () => 
                    {
                        /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                        if (cancellationToken.CanBeCanceled)
                        {
                            reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                            {
                                return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                            }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":2030753,"h":0,"f":1048578}), reader);
                        }
                        let $disposable2 = null;
                        try
                        {
                            $disposable2 = reg;
                            /*var*/ let isCanceled = false;
                            /*bool*/ let isCompleted = false;
                            try
                            {
                                if (reader.UseZeroByteReads && reader._bufferedBytes === 0n)
                                {
                                    await reader.InnerStream.ReadAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).Empty, tokenSource.Token).ConfigureAwait(false);
                                }
                                do
                                {
                                    reader.AllocateReadTail(minimumSize);
                                    /*Memory<byte>*/ let buffer = reader._readTail.AvailableMemory.Slice(reader._readTail.End);
                                    /*int*/ let length = await reader.InnerStream.ReadAsync$2(buffer, tokenSource.Token).ConfigureAwait(false);
                                    $.$spc.System.Diagnostics.Debug.Assert$1(((length + reader._readTail.End) | 0) <= reader._readTail.AvailableMemory.Length, "length + reader._readTail.End <= reader._readTail.AvailableMemory.Length");
                                    reader._readTail.End += length;
                                    reader._bufferedBytes += BigInt(length);
                                    if (length === 0)
                                    {
                                        isCompleted = true;
                                        break;
                                    }
                                }
                                while(minimumSize !== null && reader._bufferedBytes < minimumSize);
                            }
                            catch(ex)
                            {
                                reader.ClearCancellationToken();
                                if (cancellationToken.IsCancellationRequested)
                                {
                                    throw new $.$spc.System.OperationCanceledException().$ctor$14(ex.Message, ex, cancellationToken);
                                }
                                else if (tokenSource.IsCancellationRequested)
                                {
                                    isCanceled = true;
                                }
                                else 
                                {
                                    throw ex;
                                }
                            }
                            return new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(reader.GetCurrentReadOnlySequence(), isCanceled, isCompleted);
                        }
                        finally
                        {
                            $disposable2?.System$IDisposable$Dispose();
                        }
                    });
                }
            }
            /*Task *//*async*/  CopyToAsync(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.ThrowIfCompleted();
                    /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                    if (tokenSource.IsCancellationRequested)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                    }
                    /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                        }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":2030753,"h":0,"f":1048578}), this);
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._readHead;
                            /*int*/ let segmentIndex = this._readIndex;
                            try
                            {
                                while(segment !== null)
                                {
                                    /*FlushResult*/ let flushResult = await destination.WriteAsync(segment.Memory.Slice(segmentIndex), tokenSource.Token).ConfigureAwait(false);
                                    if (flushResult.IsCanceled)
                                    {
                                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                                    }
                                    segment = segment.NextSegment;
                                    segmentIndex = 0;
                                    if (flushResult.IsCompleted)
                                    {
                                        return;
                                    }
                                }
                            }
                            finally
                            {
                                {
                                    if (segment !== null)
                                    {
                                        this.AdvanceTo$2(segment, segment.End, segment, segment.End);
                                    }
                                }
                            }
                            await $.$sipl.System.IO.Pipelines.StreamPipeExtensions.CopyToAsync(this.InnerStream, destination, tokenSource.Token).ConfigureAwait(false);
                        }
                        catch($e)
                        {
                            this.ClearCancellationToken();
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*Task *//*async*/  CopyToAsync$1(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.ThrowIfCompleted();
                    /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                    if (tokenSource.IsCancellationRequested)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                    }
                    /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                        }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":2030753,"h":0,"f":1048578}), this);
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._readHead;
                            /*int*/ let segmentIndex = this._readIndex;
                            try
                            {
                                while(segment !== null)
                                {
                                    await destination.WriteAsync$2(segment.Memory.Slice(segmentIndex), tokenSource.Token).ConfigureAwait(false);
                                    segment = segment.NextSegment;
                                    segmentIndex = 0;
                                }
                            }
                            finally
                            {
                                {
                                    if (segment !== null)
                                    {
                                        this.AdvanceTo$2(segment, segment.End, segment, segment.End);
                                    }
                                }
                            }
                            await this.InnerStream.CopyToAsync$2(destination, tokenSource.Token).ConfigureAwait(false);
                        }
                        catch($e)
                        {
                            this.ClearCancellationToken();
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*void */ ClearCancellationToken()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        this._internalTokenSource = null;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
            }
            /*void */ ThrowIfCompleted()
            {
                if (this._isReaderCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                this.ThrowIfCompleted();
                return this.TryReadInternal(this.InternalTokenSource, result);
            }
            /*bool */ TryReadInternal(/*CancellationTokenSource*/ source, /*out ReadResult*/ result)
            {
                /*bool*/ let isCancellationRequested = source.IsCancellationRequested;
                if (isCancellationRequested || (this._bufferedBytes > 0n && !this._examinedEverything))
                {
                    if (isCancellationRequested)
                    {
                        this.ClearCancellationToken();
                    }
                    /*ReadOnlySequence<byte>*/ let buffer = this.GetCurrentReadOnlySequence();
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(buffer, isCancellationRequested, false);
                    return true;
                }
                result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                return false;
            }
            /*ReadOnlySequence<byte> */ GetCurrentReadOnlySequence()
            {
                return this._readHead === null ? new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))() : new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))().$ctor$3(this._readHead, this._readIndex, this._readTail, this._readTail.End);
            }
            /*void */ AllocateReadTail(/*int?*/ minimumSize)
            {
                if (this._readHead === null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readTail === null, "_readTail == null");
                    this._readHead = this.AllocateSegment(minimumSize);
                    this._readTail = this._readHead;
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readTail !== null, "_readTail != null");
                    if (this._readTail.WritableBytes < this.MinimumReadThreshold)
                    {
                        /*BufferSegment*/ let nextSegment = this.AllocateSegment(minimumSize);
                        this._readTail.SetNext(nextSegment);
                        this._readTail = nextSegment;
                    }
                }
            }
            /*BufferSegment */ AllocateSegment(/*int?*/ minimumSize)
            {
                /*BufferSegment*/ let nextSegment = this.CreateSegmentUnsynchronized();
                /*var*/ let bufferSize = minimumSize ?? this.BufferSize;
                /*int*/ let maxSize = !this._options.IsDefaultSharedMemoryPool ? this._options.Pool.MaxBufferSize : -1;
                if (bufferSize <= maxSize)
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(bufferSize, maxSize);
                    nextSegment.SetOwnedMemory(this._options.Pool.Rent(sizeToRequest));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(bufferSize, this.MaxBufferSize);
                    nextSegment.SetOwnedMemory$1($.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(sizeToRequest));
                }
                return nextSegment;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$spc.System.Math.Max$4(this.BufferSize, sizeHint);
                /*int*/ let adjustedToMaximumSize = $.$spc.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readHead, "Returning _readHead segment that's in use!");
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readTail, "Returning _readTail segment that's in use!");
                segment.Reset();
                if (this._bufferSegmentPool.Count < 256/*MaxSegmentPoolSize*/)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*void */ Cancel()
            {
                this.InternalTokenSource.Cancel();
            }
            //default member initializer
            constructor()
            {
                super();
                this._lock = new $.$spc.System.Object().$ctor();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
            }
            static $h = 2030753;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1440929,"p":[{"p":262145,"g":{"r":0,"d":0,"h":64426540193,"f":2},"n":"LeaveOpen","d":2030753,"h":60131572897,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":73016474785,"f":2},"n":"UseZeroByteReads","d":2030753,"h":68721507489,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":81606409377,"f":2},"n":"BufferSize","d":2030753,"h":77311442081,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":90196343969,"f":2},"n":"MaxBufferSize","d":2030753,"h":85901376673,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":98786278561,"f":2},"n":"MinimumReadThreshold","d":2030753,"h":94491311265,"f":2},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":107376213153,"f":2},"n":"Pool","d":2030753,"h":103081245857,"f":2},{"p":62193665,"g":{"r":0,"d":0,"h":120261115041,"f":1},"n":"InnerStream","d":2030753,"h":115966147745,"f":1},{"p":126091265,"g":{"r":0,"d":0,"h":133146016929,"f":2},"n":"InternalTokenSource","d":2030753,"h":128851049633,"f":2}],"m":[{"r":65537,"p":[{"n":"consumed","p":1244122}],"n":"AdvanceTo","d":2030753,"h":124556082337,"f":32769},{"r":65537,"p":[{"n":"consumed","p":1244122},{"n":"examined","p":1244122}],"n":"AdvanceTo","o":"@$1","d":2030753,"h":137440984225,"f":32769},{"r":65537,"p":[{"n":"consumedSegment","p":130209},{"n":"consumedIndex","p":655361},{"n":"examinedSegment","p":130209},{"n":"examinedIndex","p":655361}],"n":"AdvanceTo","o":"@$2","d":2030753,"h":141735951521,"f":2},{"r":65537,"n":"CancelPendingRead","d":2030753,"h":146030918817,"f":32769},{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":2030753,"h":150325886113,"f":32769},{"r":136118273,"p":[{"n":"exception","p":47251457,"f":65}],"n":"CompleteAsync","d":2030753,"h":154620853409,"f":32769},{"r":262145,"n":"CompleteAndGetNeedsDispose","d":2030753,"h":158915820705,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":2030753,"h":163210788001,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAtLeastAsyncCore","d":2030753,"h":167505755297,"f":32772},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":$.$typeNullable($.$spc.System.Int32).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadInternalAsync","d":2030753,"h":171800722593,"f":2},{"r":133300225,"p":[{"n":"destination","p":1637537},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","d":2030753,"h":176095689889,"f":36865},{"r":133300225,"p":[{"n":"destination","p":62193665},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","o":"@$1","d":2030753,"h":180390657185,"f":36865},{"r":65537,"n":"ClearCancellationToken","d":2030753,"h":184685624481,"f":2},{"r":65537,"n":"ThrowIfCompleted","d":2030753,"h":188980591777,"f":2},{"r":262145,"p":[{"n":"result","p":1768609,"f":2}],"n":"TryRead","d":2030753,"h":193275559073,"f":32769},{"r":262145,"p":[{"n":"source","p":126091265},{"n":"result","p":1768609,"f":2}],"n":"TryReadInternal","d":2030753,"h":197570526369,"f":2},{"r":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"n":"GetCurrentReadOnlySequence","d":2030753,"h":201865493665,"f":2},{"r":65537,"p":[{"n":"minimumSize","p":$.$typeNullable($.$spc.System.Int32).$h,"f":65}],"n":"AllocateReadTail","d":2030753,"h":206160460961,"f":2},{"r":130209,"p":[{"n":"minimumSize","p":$.$typeNullable($.$spc.System.Int32).$h,"f":65}],"n":"AllocateSegment","d":2030753,"h":210455428257,"f":2},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361}],"n":"GetSegmentSize","d":2030753,"h":214750395553,"f":2},{"r":130209,"n":"CreateSegmentUnsynchronized","d":2030753,"h":219045362849,"f":2},{"r":65537,"p":[{"n":"segment","p":130209}],"n":"ReturnSegmentUnsynchronized","d":2030753,"h":223340330145,"f":2},{"r":65537,"n":"Cancel","d":2030753,"h":227635297441,"f":2}],"l":[{"t":655361,"n":"InitialSegmentPoolSize","d":2030753,"h":4296998049,"f":40},{"t":655361,"n":"MaxSegmentPoolSize","d":2030753,"h":8591965345,"f":40},{"t":126091265,"n":"_internalTokenSource","d":2030753,"h":12886932641,"f":2},{"t":262145,"n":"_isReaderCompleted","d":2030753,"h":17181899937,"f":2},{"t":130209,"n":"_readHead","d":2030753,"h":21476867233,"f":2},{"t":655361,"n":"_readIndex","d":2030753,"h":25771834529,"f":2},{"t":130209,"n":"_readTail","d":2030753,"h":30066801825,"f":2},{"t":917505,"n":"_bufferedBytes","d":2030753,"h":34361769121,"f":2},{"t":262145,"n":"_examinedEverything","d":2030753,"h":38656736417,"f":2},{"t":131073,"n":"_lock","d":2030753,"h":42951703713,"f":2},{"t":195745,"n":"_bufferSegmentPool","d":2030753,"h":47246671009,"f":2},{"t":2096289,"n":"_options","d":2030753,"h":51541638305,"f":2}],"c":[{"p":[{"n":"readingStream","p":62193665},{"n":"options","p":2096289}],"n":".ctor","o":"$ctor$2","d":2030753,"h":55836605601,"f":1}],"h":2030753}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeReader`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeWriterStream", ($self) => class PipeWriterStream extends $.$spc.System.IO.Stream
        {
            /*PipeWriter*/ _pipeWriter = null;
            $ctor$3(/*PipeWriter*/ pipeWriter, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(pipeWriter !== null, "pipeWriter != null");
                    this._pipeWriter = pipeWriter;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this.LeaveOpen)
                {
                    this._pipeWriter.Complete(null);
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                if (!this.LeaveOpen)
                {
                    return this._pipeWriter.CompleteAsync(null);
                }
                return new $.$spc.System.Threading.Tasks.ValueTask();
            }
            /*bool*/ LeaveOpen = false;
            /*bool */ get CanRead()
            {
                return false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return true;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Flush()
            {
                this.FlushAsync().GetAwaiter().GetResult();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.WriteAsync$1(buffer, offset, count, new $.$spc.System.Threading.CancellationToken()), callback, state);
            }
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.End(asyncResult);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                return this.WriteAsync(buffer, offset, count).GetAwaiter().GetResult();
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.WriteAsync(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count), cancellationToken);
                return $.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.WriteAsync(buffer, cancellationToken);
                return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask));
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.FlushAsync(cancellationToken);
                return $.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask);
            }
            static /*Task */ GetFlushResultAsTask(/*ValueTask<FlushResult>*/ valueTask)
            {
                if (valueTask.IsCompletedSuccessfully)
                {
                    /*FlushResult*/ let result = valueTask.Result;
                    if (result.IsCanceled)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                    }
                    return $.$spc.System.Threading.Tasks.Task.CompletedTask;
                }
                /*static Task*/ /*async*/  function AwaitTask(/*ValueTask<FlushResult>*/ valueTask)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                    {
                        /*FlushResult*/ let result = await valueTask.ConfigureAwait(false);
                        if (result.IsCanceled)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                        }
                    });
                }
                return AwaitTask(valueTask);
            }
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            static $h = 1703073;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066474145,"f":8},"s":{"r":0,"d":0,"h":34361441441,"f":8},"n":"LeaveOpen","d":1703073,"h":25771506849,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":42951376033,"f":32769},"n":"CanRead","d":1703073,"h":38656408737,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51541310625,"f":32769},"n":"CanSeek","d":1703073,"h":47246343329,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60131245217,"f":32769},"n":"CanWrite","d":1703073,"h":55836277921,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68721179809,"f":32769},"n":"Length","d":1703073,"h":64426212513,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":77311114401,"f":32769},"s":{"r":0,"d":0,"h":81606081697,"f":32769},"n":"Position","d":1703073,"h":73016147105,"f":32769}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1703073,"h":12886604961,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1703073,"h":17181572257,"f":32769},{"r":65537,"n":"Flush","d":1703073,"h":85901048993,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1703073,"h":90196016289,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1703073,"h":94490983585,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1703073,"h":98785950881,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginWrite","d":1703073,"h":103080918177,"f":98305},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":1703073,"h":107375885473,"f":98305},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1703073,"h":111670852769,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1703073,"h":115965820065,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1703073,"h":120260787361,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1703073,"h":124555754657,"f":32769},{"r":133300225,"p":[{"n":"valueTask","p":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h}],"n":"GetFlushResultAsTask","d":1703073,"h":128850721953,"f":34}],"l":[{"t":1637537,"n":"_pipeWriter","d":1703073,"h":4296670369,"f":2}],"c":[{"p":[{"n":"pipeWriter","p":1637537},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":1703073,"h":8591637665,"f":1}],"i":[57540609,56950785],"h":1703073}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeWriterStream`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeReaderStream", ($self) => class PipeReaderStream extends $.$spc.System.IO.Stream
        {
            /*PipeReader*/ _pipeReader = null;
            $ctor$3(/*PipeReader*/ pipeReader, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(pipeReader !== null, "pipeReader != null");
                    this._pipeReader = pipeReader;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this.LeaveOpen)
                {
                    this._pipeReader.Complete(null);
                }
                super.Dispose$1(disposing);
            }
            /*bool */ get CanRead()
            {
                return true;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*bool*/ LeaveOpen = false;
            /*void */ Flush()
            {
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                return this.ReadInternal(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count));
            }
            /*int */ ReadByte()
            {
                /*Span<byte>*/ let oneByte = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 1, null);
                return this.ReadInternal(oneByte) === 0 ? -1 : oneByte.get_Item(0).$v;
            }
            /*int */ ReadInternal(/*Span<byte>*/ buffer)
            {
                /*ValueTask<ReadResult>*/ let vt = this._pipeReader.ReadAsync(new $.$spc.System.Threading.CancellationToken());
                /*ReadResult*/ let result = vt.IsCompletedSuccessfully ? vt.Result : vt.AsTask().GetAwaiter$1().GetResult();
                return this.HandleReadResult(result, buffer);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.ReadAsync$1(buffer, offset, count, new $.$spc.System.Threading.CancellationToken()), callback, state);
            }
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.End$1($.$spc.System.Int32, asyncResult);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                return this.ReadAsyncInternal(new ($.$spc.System.Memory$$($.$spc.System.Byte))().$ctor$4(buffer, offset, count), cancellationToken).AsTask();
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                return this.ReadInternal(buffer);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadAsyncInternal(buffer, cancellationToken);
            }
            /*ValueTask<int> *//*async*/  ReadAsyncInternal(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                {
                    /*ReadResult*/ let result = await this._pipeReader.ReadAsync(cancellationToken).ConfigureAwait(false);
                    return this.HandleReadResult(result, buffer.Span);
                });
            }
            /*int */ HandleReadResult(/*ReadResult*/ result, /*Span<byte>*/ buffer)
            {
                if (result.IsCanceled)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                }
                /*ReadOnlySequence<byte>*/ let sequence = result.Buffer;
                /*long*/ let bufferLength = sequence.Length;
                /*SequencePosition*/ let consumed = sequence.Start;
                try
                {
                    if (bufferLength !== 0n)
                    {
                        /*int*/ let actual = $.$cast($.$spc.System.Math.Min$5(bufferLength, BigInt(buffer.Length)), $.$spc.System.Int32);
                        /*ReadOnlySequence<byte>*/ let slice = BigInt(actual) === bufferLength ? sequence : sequence.Slice$3(0, actual);
                        consumed = slice.End;
                        $.$sm.System.Buffers.BuffersExtensions.CopyTo($.$spc.System.Byte, $.$ref(() => slice, ), buffer);
                        return actual;
                    }
                    if (result.IsCompleted)
                    {
                        return 0;
                    }
                }
                finally
                {
                    {
                        this._pipeReader.AdvanceTo(consumed);
                    }
                }
                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_InvalidZeroByteRead();
                return 0;
            }
            /*Task */ CopyToAsync$3(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                $.$sipl.System.IO.StreamHelpers.ValidateCopyToArgs(this, destination, bufferSize);
                return this._pipeReader.CopyToAsync$1(destination, cancellationToken);
            }
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            static $h = 1506465;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476342945,"f":32769},"n":"CanRead","d":1506465,"h":17181375649,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":30066277537,"f":32769},"n":"CanSeek","d":1506465,"h":25771310241,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38656212129,"f":32769},"n":"CanWrite","d":1506465,"h":34361244833,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":47246146721,"f":32769},"n":"Length","d":1506465,"h":42951179425,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":55836081313,"f":32769},"s":{"r":0,"d":0,"h":60131048609,"f":32769},"n":"Position","d":1506465,"h":51541114017,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":73015950497,"f":8},"s":{"r":0,"d":0,"h":77310917793,"f":8},"n":"LeaveOpen","d":1506465,"h":68720983201,"f":8}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1506465,"h":12886408353,"f":32772},{"r":65537,"n":"Flush","d":1506465,"h":81605885089,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1506465,"h":85900852385,"f":32769},{"r":655361,"n":"ReadByte","d":1506465,"h":90195819681,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"ReadInternal","d":1506465,"h":94490786977,"f":2},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1506465,"h":98785754273,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1506465,"h":103080721569,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1506465,"h":107375688865,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginRead","d":1506465,"h":111670656161,"f":98305},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":1506465,"h":115965623457,"f":98305},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1506465,"h":120260590753,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1506465,"h":124555558049,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1506465,"h":128850525345,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadAsyncInternal","d":1506465,"h":133145492641,"f":4098},{"r":655361,"p":[{"n":"result","p":1768609},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"HandleReadResult","d":1506465,"h":137440459937,"f":2},{"r":133300225,"p":[{"n":"destination","p":62193665},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"CopyToAsync","o":"@$3","d":1506465,"h":141735427233,"f":32769}],"l":[{"t":1440929,"n":"_pipeReader","d":1506465,"h":4296473761,"f":2}],"c":[{"p":[{"n":"pipeReader","p":1440929},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":1506465,"h":8591441057,"f":1}],"i":[57540609,56950785],"h":1506465}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeReaderStream`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ResultFlags", ($self) => class ResultFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static Canceled = 1;
            static Completed = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Canceled": 1n,
                    "Completed": 2n
                };
            }
            static $h = 1834145;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":1834145,"n":"None","d":1834145,"h":4296801441,"f":33},{"t":1834145,"n":"Canceled","d":1834145,"h":8591768737,"f":33},{"t":1834145,"n":"Completed","d":1834145,"h":12886736033,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1834145,"h":17181703329,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1834145,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipelines.ResultFlags`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ExceptionArgument", ($self) => class ExceptionArgument extends $.$spc.System.Enum
        {
            static minimumSize = 0;
            static bytes = 1;
            static callback = 2;
            static options = 3;
            static pauseWriterThreshold = 4;
            static resumeWriterThreshold = 5;
            static sizeHint = 6;
            static destination = 7;
            static buffer = 8;
            static source = 9;
            static readingStream = 10;
            static writingStream = 11;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "minimumSize": 0n,
                    "bytes": 1n,
                    "callback": 2n,
                    "options": 3n,
                    "pauseWriterThreshold": 4n,
                    "resumeWriterThreshold": 5n,
                    "sizeHint": 6n,
                    "destination": 7n,
                    "buffer": 8n,
                    "source": 9n,
                    "readingStream": 10n,
                    "writingStream": 11n
                };
            }
            static $h = 392353;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":392353,"n":"minimumSize","d":392353,"h":4295359649,"f":33},{"t":392353,"n":"bytes","d":392353,"h":8590326945,"f":33},{"t":392353,"n":"callback","d":392353,"h":12885294241,"f":33},{"t":392353,"n":"options","d":392353,"h":17180261537,"f":33},{"t":392353,"n":"pauseWriterThreshold","d":392353,"h":21475228833,"f":33},{"t":392353,"n":"resumeWriterThreshold","d":392353,"h":25770196129,"f":33},{"t":392353,"n":"sizeHint","d":392353,"h":30065163425,"f":33},{"t":392353,"n":"destination","d":392353,"h":34360130721,"f":33},{"t":392353,"n":"buffer","d":392353,"h":38655098017,"f":33},{"t":392353,"n":"source","d":392353,"h":42950065313,"f":33},{"t":392353,"n":"readingStream","d":392353,"h":47245032609,"f":33},{"t":392353,"n":"writingStream","d":392353,"h":51539999905,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":392353,"h":55834967201,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":392353}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipelines.ExceptionArgument`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.BufferSegment", ($self) => class BufferSegment extends $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$spc.System.Byte)
        {
            /*IMemoryOwner<byte>?*/ _memoryOwner = null;
            /*byte[]?*/ _array = null;
            /*BufferSegment?*/ _next = null;
            /*int*/ _end = 0;
            /*int */ get End()
            {
                return this._end;
            }
            /*int */ set End(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value <= this.AvailableMemory.Length, "value <= AvailableMemory.Length");
                this._end = value;
                this.Memory = $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2(this.AvailableMemory.Slice$1(0, value));
            }
            /*BufferSegment? */ get NextSegment()
            {
                return this._next;
            }
            /*BufferSegment? */ set NextSegment(value)
            {
                this.Next = value;
                this._next = value;
            }
            /*void */ SetOwnedMemory(/*IMemoryOwner<byte>*/ memoryOwner)
            {
                this._memoryOwner = memoryOwner;
                this.AvailableMemory = memoryOwner.System$Buffers$IMemoryOwner$$$Memory;
            }
            /*void */ SetOwnedMemory$1(/*byte[]*/ arrayPoolBuffer)
            {
                this._array = arrayPoolBuffer;
                this.AvailableMemory = $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(arrayPoolBuffer);
            }
            /*void */ Reset()
            {
                this.ResetMemory();
                this.Next = null;
                this.RunningIndex = 0n;
                this._next = null;
            }
            /*void */ ResetMemory()
            {
                /*IMemoryOwner<byte>?*/ let memoryOwner = this._memoryOwner;
                if (memoryOwner !== null)
                {
                    this._memoryOwner = null;
                    memoryOwner.System$IDisposable$Dispose();
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._array !== null, "_array != null");
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(this._array, false);
                    this._array = null;
                }
                this.Memory = new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))();
                this._end = 0;
                this.AvailableMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
            }
            /*object? */ get MemoryOwner()
            {
                return $.$cast(this._memoryOwner, $.$spc.System.Object) ?? this._array;
            }
            /*Memory<byte>*/ AvailableMemory;
            /*int */ get Length()
            {
                return this.End;
            }
            /*int */ get WritableBytes()
            {
                return ((this.AvailableMemory.Length - this.End) | 0);
            }
            /*void */ SetNext(/*BufferSegment*/ segment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== null, "segment != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this.Next === null, "Next == null");
                this.NextSegment = segment;
                segment = this;
                while(segment.Next !== null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(segment.NextSegment !== null, "segment.NextSegment != null");
                    segment.NextSegment.RunningIndex = segment.RunningIndex + BigInt(segment.Length);
                    segment = segment.NextSegment;
                }
            }
            static /*long */ GetLength(/*BufferSegment*/ startSegment, /*int*/ startIndex, /*BufferSegment*/ endSegment, /*int*/ endIndex)
            {
                return (endSegment.RunningIndex + BigInt((endIndex >>> 0))) - (startSegment.RunningIndex + BigInt((startIndex >>> 0)));
            }
            static /*long */ GetLength$1(/*long*/ startPosition, /*BufferSegment*/ endSegment, /*int*/ endIndex)
            {
                return (endSegment.RunningIndex + BigInt((endIndex >>> 0))) - startPosition;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.AvailableMemory = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
            }
            static $h = 130209;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":655361,"g":{"r":0,"d":0,"h":25769933985,"f":1},"s":{"r":0,"d":0,"h":30064901281,"f":1},"n":"End","d":130209,"h":21474966689,"f":1},{"p":130209,"g":{"r":0,"d":0,"h":38654835873,"f":1},"s":{"r":0,"d":0,"h":42949803169,"f":1},"n":"NextSegment","d":130209,"h":34359868577,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":68719606945,"f":8},"n":"MemoryOwner","d":130209,"h":64424639649,"f":8},{"p":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":81604508833,"f":1},"s":{"r":0,"d":0,"h":85899476129,"f":2},"n":"AvailableMemory","d":130209,"h":77309541537,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":94489410721,"f":1},"n":"Length","d":130209,"h":90194443425,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103079345313,"f":1},"n":"WritableBytes","d":130209,"h":98784378017,"f":1}],"m":[{"r":65537,"p":[{"n":"memoryOwner","p":$.$spc.System.Buffers.IMemoryOwner$$($.$spc.System.Byte).$h}],"n":"SetOwnedMemory","d":130209,"h":47244770465,"f":1},{"r":65537,"p":[{"n":"arrayPoolBuffer","p":0}],"n":"SetOwnedMemory","o":"@$1","d":130209,"h":51539737761,"f":1},{"r":65537,"n":"Reset","d":130209,"h":55834705057,"f":1},{"r":65537,"n":"ResetMemory","d":130209,"h":60129672353,"f":1},{"r":65537,"p":[{"n":"segment","p":130209}],"n":"SetNext","d":130209,"h":107374312609,"f":1},{"r":917505,"p":[{"n":"startSegment","p":130209},{"n":"startIndex","p":655361},{"n":"endSegment","p":130209},{"n":"endIndex","p":655361}],"n":"GetLength","d":130209,"h":111669279905,"f":40},{"r":917505,"p":[{"n":"startPosition","p":917505},{"n":"endSegment","p":130209},{"n":"endIndex","p":655361}],"n":"GetLength","o":"@$1","d":130209,"h":115964247201,"f":40}],"l":[{"t":$.$spc.System.Buffers.IMemoryOwner$$($.$spc.System.Byte).$h,"n":"_memoryOwner","d":130209,"h":4295097505,"f":2},{"t":0,"n":"_array","d":130209,"h":8590064801,"f":2},{"t":130209,"n":"_next","d":130209,"h":12885032097,"f":2},{"t":655361,"n":"_end","d":130209,"h":17179999393,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":130209,"h":120259214497,"f":1}],"h":130209}; }
            static get $b() { return $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$spc.System.Byte); }
            static get $fullName() { return `System.IO.Pipelines.BufferSegment`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeWriter", ($self) => class StreamPipeWriter extends $.$sipl.System.IO.Pipelines.PipeWriter
        {
            /*int*/ static InitialSegmentPoolSize = 4;
            /*int*/ static MaxSegmentPoolSize = 256;
            /*int*/ _minimumBufferSize = 0;
            /*BufferSegment?*/ _head = null;
            /*BufferSegment?*/ _tail = null;
            /*Memory<byte>*/ _tailMemory;
            /*int*/ _tailBytesBuffered = 0;
            /*long*/ _bytesBuffered = 0n;
            /*MemoryPool<byte>?*/ _pool = null;
            /*int*/ _maxPooledBufferSize = 0;
            /*CancellationTokenSource?*/ _internalTokenSource = null;
            /*bool*/ _isCompleted = false;
            /*object*/ _lockObject = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*bool*/ _leaveOpen = false;
            /*CancellationTokenSource */ get InternalTokenSource()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lockObject)
                    {
                        return this._internalTokenSource ??= new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lockObject)
                }
            }
            $ctor$2(/*Stream*/ writingStream, /*StreamPipeWriterOptions*/ options)
            {
                super.$ctor$1();
                {
                    if (writingStream === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(11/*ExceptionArgument.writingStream*/);
                    }
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this.InnerStream = writingStream;
                    this._minimumBufferSize = options.MinimumBufferSize;
                    this._pool = options.Pool === $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared ? null : options.Pool;
                    this._maxPooledBufferSize = (this._pool?.MaxBufferSize ?? null) ?? -1;
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$2(4/*InitialSegmentPoolSize*/);
                    this._leaveOpen = options.LeaveOpen;
                }
                return this;
            }
            /*Stream*/ InnerStream = null;
            /*void */ Advance(/*int*/ bytes)
            {
                if ((bytes >>> 0) > (this._tailMemory.Length >>> 0))
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.bytes*/);
                }
                this._tailBytesBuffered += bytes;
                this._bytesBuffered += BigInt(bytes);
                this._tailMemory = this._tailMemory.Slice(bytes);
            }
            /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
            {
                if (this._isCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateMemory(sizeHint);
                return this._tailMemory;
            }
            /*Span<byte> */ GetSpan(/*int*/ sizeHint)
            {
                if (this._isCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateMemory(sizeHint);
                return this._tailMemory.Span;
            }
            /*void */ AllocateMemory(/*int*/ sizeHint)
            {
                if (this._head === null)
                {
                    /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                    this._head = this._tail = newSegment;
                    this._tailBytesBuffered = 0;
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._tail !== null, "_tail != null");
                    /*int*/ let bytesLeftInBuffer = this._tailMemory.Length;
                    if (bytesLeftInBuffer === 0 || bytesLeftInBuffer < sizeHint)
                    {
                        if (this._tailBytesBuffered > 0)
                        {
                            this._tail.End += this._tailBytesBuffered;
                            this._tailBytesBuffered = 0;
                        }
                        /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                        this._tail.SetNext(newSegment);
                        this._tail = newSegment;
                    }
                }
            }
            /*BufferSegment */ AllocateSegment(/*int*/ sizeHint)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(sizeHint >= 0, "sizeHint >= 0");
                /*BufferSegment*/ let newSegment = this.CreateSegmentUnsynchronized();
                /*int*/ let maxSize = this._maxPooledBufferSize;
                if (sizeHint <= maxSize)
                {
                    newSegment.SetOwnedMemory(this._pool.Rent(this.GetSegmentSize(sizeHint, maxSize)));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(sizeHint, 2147483647);
                    newSegment.SetOwnedMemory$1($.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(sizeToRequest));
                }
                this._tailMemory = newSegment.AvailableMemory;
                return newSegment;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$spc.System.Math.Max$4(this._minimumBufferSize, sizeHint);
                /*var*/ let adjustedToMaximumSize = $.$spc.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                segment.Reset();
                if (this._bufferSegmentPool.Count < 256/*MaxSegmentPoolSize*/)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*void */ CancelPendingFlush()
            {
                this.Cancel();
            }
            /*bool */ get CanGetUnflushedBytes()
            {
                return true;
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this._isCompleted)
                {
                    return;
                }
                this._isCompleted = true;
                try
                {
                    this.FlushInternal(exception === null);
                }
                finally
                {
                    {
                        this._internalTokenSource?.Dispose();
                        if (!this._leaveOpen)
                        {
                            this.InnerStream.Dispose();
                        }
                    }
                }
            }
            /*ValueTask *//*async*/  CompleteAsync(/*Exception?*/ exception)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    if (this._isCompleted)
                    {
                        return;
                    }
                    this._isCompleted = true;
                    try
                    {
                        await this.FlushAsyncInternal(exception === null, $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.Memory$$($.$spc.System.Byte).Empty), new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    }
                    finally
                    {
                        {
                            this._internalTokenSource?.Dispose();
                            if (!this._leaveOpen)
                            {
                                await this.InnerStream.DisposeAsync().ConfigureAwait(false);
                            }
                        }
                    }
                });
            }
            /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
            {
                if (this._bytesBuffered === 0n)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false));
                }
                return this.FlushAsyncInternal(true, $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.Memory$$($.$spc.System.Byte).Empty), new $.$spc.System.Threading.CancellationToken());
            }
            /*long */ get UnflushedBytes()
            {
                return this._bytesBuffered;
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                return this.FlushAsyncInternal(true, source, new $.$spc.System.Threading.CancellationToken());
            }
            /*void */ Cancel()
            {
                this.InternalTokenSource.Cancel();
            }
            /*ValueTask<FlushResult> *//*async*/  FlushAsyncInternal(/*bool*/ writeToStream, /*ReadOnlyMemory<byte>*/ data, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult), $.$sipl.System.IO.Pipelines.FlushResult, async () => 
                {
                    /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeWriter)).Cancel();
                        }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":2161825,"h":0,"f":1048578}), this);
                    }
                    if (this._tailBytesBuffered > 0)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._tail !== null, "_tail != null");
                        this._tail.End += this._tailBytesBuffered;
                        this._tailBytesBuffered = 0;
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        /*CancellationToken*/ let localToken = this.InternalTokenSource.Token;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._head;
                            while(segment !== null)
                            {
                                /*BufferSegment*/ let returnSegment = segment;
                                segment = segment.NextSegment;
                                if (returnSegment.Length > 0 && writeToStream)
                                {
                                    await this.InnerStream.WriteAsync$2(returnSegment.Memory, localToken).ConfigureAwait(false);
                                }
                                this.ReturnSegmentUnsynchronized(returnSegment);
                                this._head = segment;
                            }
                            if (writeToStream)
                            {
                                if (data.Length > 0)
                                {
                                    await this.InnerStream.WriteAsync$2(data, localToken).ConfigureAwait(false);
                                }
                                if (this._bytesBuffered > 0n || data.Length > 0)
                                {
                                    await this.InnerStream.FlushAsync$1(localToken).ConfigureAwait(false);
                                }
                            }
                            this._head = null;
                            this._tail = null;
                            this._tailMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                            this._bytesBuffered = 0n;
                            return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false);
                        }
                        catch($e)
                        {
                            //lock
                            try
                            {
                                $.$spc.System.Threading.Monitor.Enter(this._lockObject)
                                {
                                    this._internalTokenSource = null;
                                }
                            }
                            finally
                            {
                                $.$spc.System.Threading.Monitor.Exit(this._lockObject)
                            }
                            if (localToken.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
                            {
                                return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(true, false);
                            }
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*void */ FlushInternal(/*bool*/ writeToStream)
            {
                if (this._tailBytesBuffered > 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._tail !== null, "_tail != null");
                    this._tail.End += this._tailBytesBuffered;
                    this._tailBytesBuffered = 0;
                }
                /*BufferSegment?*/ let segment = this._head;
                while(segment !== null)
                {
                    /*BufferSegment*/ let returnSegment = segment;
                    segment = segment.NextSegment;
                    if (returnSegment.Length > 0 && writeToStream)
                    {
                        this.InnerStream.Write$1(returnSegment.Memory.Span);
                    }
                    this.ReturnSegmentUnsynchronized(returnSegment);
                    this._head = segment;
                }
                if (this._bytesBuffered > 0n && writeToStream)
                {
                    this.InnerStream.Flush();
                }
                this._head = null;
                this._tail = null;
                this._tailMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                this._bytesBuffered = 0n;
            }
            //default member initializer
            constructor()
            {
                super();
                this._tailMemory = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
                this._lockObject = new $.$spc.System.Object().$ctor();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
            }
            static $h = 2161825;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1637537,"p":[{"p":126091265,"g":{"r":0,"d":0,"h":73016605857,"f":2},"n":"InternalTokenSource","d":2161825,"h":68721638561,"f":2},{"p":62193665,"g":{"r":0,"d":0,"h":90196475041,"f":1},"n":"InnerStream","d":2161825,"h":85901507745,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":137441115297,"f":32769},"n":"CanGetUnflushedBytes","d":2161825,"h":133146148001,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":158915951777,"f":32769},"n":"UnflushedBytes","d":2161825,"h":154620984481,"f":32769}],"m":[{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":2161825,"h":94491442337,"f":32769},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":2161825,"h":98786409633,"f":32769},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":2161825,"h":103081376929,"f":32769},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateMemory","d":2161825,"h":107376344225,"f":2},{"r":130209,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateSegment","d":2161825,"h":111671311521,"f":2},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361,"f":65,"v":2147483647}],"n":"GetSegmentSize","d":2161825,"h":115966278817,"f":2},{"r":130209,"n":"CreateSegmentUnsynchronized","d":2161825,"h":120261246113,"f":2},{"r":65537,"p":[{"n":"segment","p":130209}],"n":"ReturnSegmentUnsynchronized","d":2161825,"h":124556213409,"f":2},{"r":65537,"n":"CancelPendingFlush","d":2161825,"h":128851180705,"f":32769},{"r":65537,"p":[{"n":"exception","p":47251457,"f":65}],"n":"Complete","d":2161825,"h":141736082593,"f":32769},{"r":136118273,"p":[{"n":"exception","p":47251457,"f":65}],"n":"CompleteAsync","d":2161825,"h":146031049889,"f":36865},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","d":2161825,"h":150326017185,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","d":2161825,"h":163210919073,"f":32769},{"r":65537,"n":"Cancel","d":2161825,"h":167505886369,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"writeToStream","p":262145},{"n":"data","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsyncInternal","d":2161825,"h":171800853665,"f":4098,"a":[{"t":86638593,"c":4381605889,"a":[{"v":$.$spc.System.Runtime.CompilerServices.PoolingAsyncValueTaskMethodBuilder$$().$h,"t":142606337}]}]},{"r":65537,"p":[{"n":"writeToStream","p":262145}],"n":"FlushInternal","d":2161825,"h":176095820961,"f":2}],"l":[{"t":655361,"n":"InitialSegmentPoolSize","d":2161825,"h":4297129121,"f":40},{"t":655361,"n":"MaxSegmentPoolSize","d":2161825,"h":8592096417,"f":40},{"t":655361,"n":"_minimumBufferSize","d":2161825,"h":12887063713,"f":2},{"t":130209,"n":"_head","d":2161825,"h":17182031009,"f":2},{"t":130209,"n":"_tail","d":2161825,"h":21476998305,"f":2},{"t":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"n":"_tailMemory","d":2161825,"h":25771965601,"f":2},{"t":655361,"n":"_tailBytesBuffered","d":2161825,"h":30066932897,"f":2},{"t":917505,"n":"_bytesBuffered","d":2161825,"h":34361900193,"f":2},{"t":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"n":"_pool","d":2161825,"h":38656867489,"f":2},{"t":655361,"n":"_maxPooledBufferSize","d":2161825,"h":42951834785,"f":2},{"t":126091265,"n":"_internalTokenSource","d":2161825,"h":47246802081,"f":2},{"t":262145,"n":"_isCompleted","d":2161825,"h":51541769377,"f":2},{"t":131073,"n":"_lockObject","d":2161825,"h":55836736673,"f":2},{"t":195745,"n":"_bufferSegmentPool","d":2161825,"h":60131703969,"f":2},{"t":262145,"n":"_leaveOpen","d":2161825,"h":64426671265,"f":2}],"c":[{"p":[{"n":"writingStream","p":62193665},{"n":"options","p":2227361}],"n":".ctor","o":"$ctor$2","d":2161825,"h":77311573153,"f":1}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h],"h":2161825}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeWriter; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte) ]; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeWriter`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading", "NetJs.System.Threading.ThreadPool"))