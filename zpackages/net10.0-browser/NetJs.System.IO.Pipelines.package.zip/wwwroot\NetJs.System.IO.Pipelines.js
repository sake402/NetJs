
(function ($global, $, $spc, $sc, $sm, $spu, $st, $sttp, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Pipelines", 
    {"h":63177,"f":"System.IO.Pipelines","v":"1.0.35.0","a":[{"t":92405761,"c":4387373057,"a":[{"v":"System.IO.Pipelines.Tests, PublicKey=00240000048000009400000006020000002400005253413100040000010001004b86c4cb78549b34bab61a3b1800e23bfeb5b3ec390074041536a7e3cbd97f5f04cf0f857155a8928eaa29ebfd11cfbbad3ba70efea7bda3226c6a8d370a4cd303f714486b6ebc225985a638471e6ef571cc92a4613c00b8fa65d61ccee0cbe5f36330c9a01f4183559f1bef24cc2917c6d913e3a541333a1d05d9bed22b38cb","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Pipelines","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Pipelines","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sipl.System.IO.Pipelines.IDuplexPipe", ($self) => class IDuplexPipe
        {
            static $h = 521929;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1439433,"g":{"r":0,"d":0,"h":8590456521,"f":257},"n":"Input","o":"System$IO$Pipelines$IDuplexPipe$Input","d":521929,"h":4295489225,"f":257},{"p":1636041,"g":{"r":0,"d":0,"h":17180391113,"f":257},"n":"Output","o":"System$IO$Pipelines$IDuplexPipe$Output","d":521929,"h":12885423817,"f":257}],"h":521929}; }
            static get $fullName() { return `System.IO.Pipelines.IDuplexPipe`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeReader", ($self) => class PipeReader extends $.$spc.System.Object
        {
            /*PipeReaderStream?*/ _stream = null;
            /*ValueTask<ReadResult> */ ReadAtLeastAsync(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                if (minimumSize < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(0/*ExceptionArgument.minimumSize*/);
                }
                return this.ReadAtLeastAsyncCore(minimumSize, cancellationToken);
            }
            /*ValueTask<ReadResult> *//*async*/  ReadAtLeastAsyncCore(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult), $.$sipl.System.IO.Pipelines.ReadResult, async () => 
                {
                    while(true)
                    {
                        /*ReadResult*/ let result = await this.ReadAsync(cancellationToken).ConfigureAwait(false);
                        /*ReadOnlySequence<byte>*/ let buffer = result.Buffer;
                        if (buffer.Length >= BigInt(minimumSize) || result.IsCompleted || result.IsCanceled)
                        {
                            return result;
                        }
                        this.AdvanceTo$1(buffer.Start, buffer.End);
                    }
                });
            }
            /*Stream */ AsStream(/*bool*/ leaveOpen)
            {
                if (this._stream === null)
                {
                    this._stream = new $.$sipl.System.IO.Pipelines.PipeReaderStream().$ctor$3(this, leaveOpen);
                }
                else if (leaveOpen)
                {
                    this._stream.LeaveOpen = leaveOpen;
                }
                return this._stream;
            }
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                try
                {
                    this.Complete(exception);
                    return new $.$spc.System.Threading.Tasks.ValueTask();
                }
                catch(ex)
                {
                    return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException(ex));
                }
            }
            /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
            }
            static /*PipeReader */ Create(/*Stream*/ stream, /*StreamPipeReaderOptions?*/ readerOptions)
            {
                return new $.$sipl.System.IO.Pipelines.StreamPipeReader().$ctor$2(stream, readerOptions ?? $.$sipl.System.IO.Pipelines.StreamPipeReaderOptions.s_default);
            }
            static /*PipeReader */ Create$1(/*ReadOnlySequence<byte>*/ sequence)
            {
                return new $.$sipl.System.IO.Pipelines.SequencePipeReader().$ctor$2(sequence);
            }
            /*Task */ CopyToAsync(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this.CopyToAsyncCore($.$sipl.System.IO.Pipelines.PipeWriter, destination, new ($.$spc.System.Func$$$$$($.$sipl.System.IO.Pipelines.PipeWriter, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)))().$ctor(this,  (/*destination*/ destination, /*memory*/ memory, /**/ cancellationToken) =>
                {
                    return destination.WriteAsync(memory, cancellationToken);
                }), cancellationToken);
            }
            /*Task */ CopyToAsync$1(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this.CopyToAsyncCore($.$spc.System.IO.Stream, destination, new ($.$spc.System.Func$$$$$($.$spc.System.IO.Stream, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)))().$ctor(this,  (/**/ destination, /**/ memory, /*cancellationToken*/ cancellationToken) =>
                {
                    /*ValueTask*/ let task = destination.WriteAsync$2(memory, cancellationToken);
                    if (task.IsCompletedSuccessfully)
                    {
                        task.GetAwaiter().GetResult();
                        return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false));
                    }
                    /*static ValueTask<FlushResult>*/ /*async*/  function Awaited(/*ValueTask*/ writeTask)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult), $.$sipl.System.IO.Pipelines.FlushResult, async () => 
                        {
                            await writeTask.ConfigureAwait(false);
                            return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false);
                        });
                    }
                    return Awaited(task);
                }), cancellationToken);
            }
            /*Task *//*async*/  CopyToAsyncCore(TStream, /*TStream*/ destination, /*Func<TStream, ReadOnlyMemory<byte>, CancellationToken, ValueTask<FlushResult>>*/ writeAsync, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    while(true)
                    {
                        /*ReadResult*/ let result = await this.ReadAsync(cancellationToken).ConfigureAwait(false);
                        /*ReadOnlySequence<byte>*/ let buffer = result.Buffer;
                        /*SequencePosition*/ let position = buffer.Start;
                        /*SequencePosition*/ let consumed = position;
                        try
                        {
                            if (result.IsCanceled)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                            }
                            /*ReadOnlyMemory<byte>*/ let memory;
                            while(buffer.TryGet($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => position, ($v) => position = $v, null), $.$ref(() => memory, ($v) => memory = $v, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte)), true))
                            {
                                if (memory.IsEmpty)
                                {
                                    consumed = position;
                                }
                                else 
                                {
                                    /*FlushResult*/ let flushResult = await writeAsync.Invoke(destination, memory, cancellationToken).ConfigureAwait(false);
                                    if (flushResult.IsCanceled)
                                    {
                                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                                    }
                                    consumed = position;
                                    if (flushResult.IsCompleted)
                                    {
                                        return;
                                    }
                                }
                            }
                            consumed = buffer.End;
                            if (result.IsCompleted)
                            {
                                break;
                            }
                        }
                        finally
                        {
                            {
                                this.AdvanceTo(consumed);
                            }
                        }
                    }
                });
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1439433;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"result","p":1767113,"f":2}],"n":"TryRead","d":1439433,"h":8591374025,"f":257},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":1439433,"h":12886341321,"f":257},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAtLeastAsync","d":1439433,"h":17181308617,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAtLeastAsyncCore","d":1439433,"h":21476275913,"f":4228},{"r":65537,"p":[{"n":"consumed","p":1218810}],"n":"AdvanceTo","d":1439433,"h":25771243209,"f":257},{"r":65537,"p":[{"n":"consumed","p":1218810},{"n":"examined","p":1218810}],"n":"AdvanceTo","o":"@$1","d":1439433,"h":30066210505,"f":257},{"r":62128129,"p":[{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":"AsStream","d":1439433,"h":34361177801,"f":129},{"r":65537,"n":"CancelPendingRead","d":1439433,"h":38656145097,"f":257},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":1439433,"h":42951112393,"f":257},{"r":136118273,"p":[{"n":"exception","p":47185921,"f":65}],"n":"CompleteAsync","d":1439433,"h":47246079689,"f":129},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":1439433,"h":51541046985,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"OnWriterCompleted has been deprecated and may not be invoked on all implementations of PipeReader.","t":1310721}]}]},{"r":1439433,"p":[{"n":"stream","p":62128129},{"n":"readerOptions","p":2094793,"f":65}],"n":"Create","d":1439433,"h":55836014281,"f":33},{"r":1439433,"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h}],"n":"Create","o":"@$1","d":1439433,"h":60130981577,"f":33},{"r":133300225,"p":[{"n":"destination","p":1636041},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","d":1439433,"h":64425948873,"f":129},{"r":133300225,"p":[{"n":"destination","p":62128129},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","o":"@$1","d":1439433,"h":68720916169,"f":129},{"r":133300225,"p":[{"n":"destination","p":68723081216},{"n":"writeAsync","p":(TStream) => $.$spc.System.Func$$$$$(TStream, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)).$h},{"n":"cancellationToken","p":125960193}],"g":["TStream"],"n":"CopyToAsyncCore","d":1439433,"h":73015883465,"f":135170}],"l":[{"t":1504969,"n":"_stream","d":1439433,"h":4296406729,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1439433,"h":77310850761,"f":4}],"h":1439433}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeReader`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeScheduler", ($self) => class PipeScheduler extends $.$spc.System.Object
        {
            /*ThreadPoolScheduler*/ static s_threadPoolScheduler = null;
            /*InlineScheduler*/ static s_inlineScheduler = null;
            static /*PipeScheduler */ get ThreadPool()
            {
                return $.$sipl.System.IO.Pipelines.PipeScheduler.s_threadPoolScheduler;
            }
            static /*PipeScheduler */ get Inline()
            {
                return $.$sipl.System.IO.Pipelines.PipeScheduler.s_inlineScheduler;
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                return this.Schedule(action, state);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_threadPoolScheduler = new $.$sipl.System.IO.Pipelines.ThreadPoolScheduler().$ctor$2();
                }
                {
                    this.s_inlineScheduler = new $.$sipl.System.IO.Pipelines.InlineScheduler().$ctor$2();
                }
            }
            static $h = 1570505;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1570505,"g":{"r":0,"d":0,"h":17181439689,"f":33},"n":"ThreadPool","d":1570505,"h":12886472393,"f":33},{"p":1570505,"g":{"r":0,"d":0,"h":25771374281,"f":33},"n":"Inline","d":1570505,"h":21476406985,"f":33}],"m":[{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":1570505,"h":30066341577,"f":257},{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":1570505,"h":34361308873,"f":136}],"l":[{"t":2291401,"n":"s_threadPoolScheduler","d":1570505,"h":4296537801,"f":34},{"t":587465,"n":"s_inlineScheduler","d":1570505,"h":8591505097,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":1570505,"h":38656276169,"f":4}],"h":1570505}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeScheduler`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeWriter", ($self) => class PipeWriter extends $.$spc.System.Object
        {
            /*PipeWriterStream?*/ _stream = null;
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                try
                {
                    this.Complete(exception);
                    return new $.$spc.System.Threading.Tasks.ValueTask();
                }
                catch(ex)
                {
                    return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException(ex));
                }
            }
            /*bool */ get CanGetUnflushedBytes()
            {
                return false;
            }
            /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
            }
            /*Stream */ AsStream(/*bool*/ leaveOpen)
            {
                if (this._stream === null)
                {
                    this._stream = new $.$sipl.System.IO.Pipelines.PipeWriterStream().$ctor$3(this, leaveOpen);
                }
                else if (leaveOpen)
                {
                    this._stream.LeaveOpen = leaveOpen;
                }
                return this._stream;
            }
            static /*PipeWriter */ Create(/*Stream*/ stream, /*StreamPipeWriterOptions?*/ writerOptions)
            {
                return new $.$sipl.System.IO.Pipelines.StreamPipeWriter().$ctor$2(stream, writerOptions ?? $.$sipl.System.IO.Pipelines.StreamPipeWriterOptions.s_default);
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                $.$sm.System.Buffers.BuffersExtensions.Write($.$spc.System.Byte, this, source.Span);
                return this.FlushAsync(cancellationToken);
            }
            /*Task *//*async*/  CopyFromAsync(/*Stream*/ source, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    while(true)
                    {
                        /*Memory<byte>*/ let buffer = this.GetMemory(0);
                        /*int*/ let read = await source.ReadAsync$2(buffer, cancellationToken).ConfigureAwait(false);
                        if (read === 0)
                        {
                            break;
                        }
                        this.Advance(read);
                        /*FlushResult*/ let result = await this.FlushAsync(cancellationToken).ConfigureAwait(false);
                        if (result.IsCanceled)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                        }
                        if (result.IsCompleted)
                        {
                            break;
                        }
                    }
                });
            }
            /*long */ get UnflushedBytes()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateNotSupportedException_UnflushedBytes();
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.Advance(int)
            System$Buffers$IBufferWriter$$$Advance()
            {
                return this.Advance(...arguments);
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.GetMemory(int)
            System$Buffers$IBufferWriter$$$GetMemory()
            {
                return this.GetMemory(...arguments);
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.GetSpan(int)
            System$Buffers$IBufferWriter$$$GetSpan()
            {
                return this.GetSpan(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1636041;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771439817,"f":129},"n":"CanGetUnflushedBytes","d":1636041,"h":21476472521,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":73016080073,"f":129},"n":"UnflushedBytes","d":1636041,"h":68721112777,"f":129}],"m":[{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":1636041,"h":8591570633,"f":257},{"r":136118273,"p":[{"n":"exception","p":47185921,"f":65}],"n":"CompleteAsync","d":1636041,"h":12886537929,"f":129},{"r":65537,"n":"CancelPendingFlush","d":1636041,"h":17181505225,"f":257},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":1636041,"h":30066407113,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"OnReaderCompleted has been deprecated and may not be invoked on all implementations of PipeWriter.","t":1310721}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","d":1636041,"h":34361374409,"f":257},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":1636041,"h":38656341705,"f":257},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":1636041,"h":42951309001,"f":257},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":1636041,"h":47246276297,"f":257},{"r":62128129,"p":[{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":"AsStream","d":1636041,"h":51541243593,"f":129},{"r":1636041,"p":[{"n":"stream","p":62128129},{"n":"writerOptions","p":2225865,"f":65}],"n":"Create","d":1636041,"h":55836210889,"f":33},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","d":1636041,"h":60131178185,"f":129},{"r":133300225,"p":[{"n":"source","p":62128129},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyFromAsync","d":1636041,"h":64426145481,"f":4240}],"l":[{"t":1701577,"n":"_stream","d":1636041,"h":4296603337,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1636041,"h":77311047369,"f":4}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h],"h":1636041}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte) ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeWriter`; }
        });
        
        $asm.$cls("$sipl.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sipl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.IO.Pipelines", $.$sipl.System.SR.$type.Assembly);
                    $.$sipl.System.SR.s_resourceManager = temp;
                }
                return $.$sipl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sipl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sipl.System.SR.resourceCulture = value;
            }
            static /*string */ get AdvanceToInvalidCursor()
            {
                return "The PipeReader has already advanced past the provided position.";
            }
            static /*string */ get ArgumentOutOfRange_NeedPosNum()
            {
                return "Positive number required.";
            }
            static /*string */ get ConcurrentOperationsNotSupported()
            {
                return "Concurrent reads or writes are not supported.";
            }
            static /*string */ get FlushCanceledOnPipeWriter()
            {
                return "Flush was canceled on underlying PipeWriter.";
            }
            static /*string */ get GetResultBeforeCompleted()
            {
                return "Can't GetResult unless awaiter is completed.";
            }
            static /*string */ get InvalidExaminedOrConsumedPosition()
            {
                return "The examined position must be greater than or equal to the consumed position.";
            }
            static /*string */ get InvalidExaminedPosition()
            {
                return "The examined position cannot be less than the previously examined position.";
            }
            static /*string */ get InvalidZeroByteRead()
            {
                return "The PipeReader returned 0 bytes when the ReadResult was not completed or canceled.";
            }
            static /*string */ get ObjectDisposed_StreamClosed()
            {
                return "Cannot access a closed stream.";
            }
            static /*string */ get NoReadingOperationToComplete()
            {
                return "No reading operation to complete.";
            }
            static /*string */ get NotSupported_UnreadableStream()
            {
                return "Stream does not support reading.";
            }
            static /*string */ get NotSupported_UnwritableStream()
            {
                return "Stream does not support writing.";
            }
            static /*string */ get ReadCanceledOnPipeReader()
            {
                return "Read was canceled on underlying PipeReader.";
            }
            static /*string */ get ReaderAndWriterHasToBeCompleted()
            {
                return "Both reader and writer has to be completed to be able to reset the pipe.";
            }
            static /*string */ get ReadingAfterCompleted()
            {
                return "Reading is not allowed after reader was completed.";
            }
            static /*string */ get ReadingIsInProgress()
            {
                return "Reading is already in progress.";
            }
            static /*string */ get WritingAfterCompleted()
            {
                return "Writing is not allowed after writer was completed.";
            }
            static /*string */ get UnflushedBytesNotSupported()
            {
                return "UnflushedBytes is not supported.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sipl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sipl.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sipl.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sipl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sipl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sipl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2488009;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2488009}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.Pipe", ($self) => class Pipe extends $.$spc.System.Object
        {
            static $_DefaultPipeReader;
            static get DefaultPipeReader()
            {
                let $cls = $.$sipl.System.IO.Pipelines.Pipe;
                return $cls.$_DefaultPipeReader ??= $asm.$ncls("$sipl.System.IO.Pipelines.Pipe.DefaultPipeReader", ($self) => class DefaultPipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
                {
                    /*Pipe*/ _pipe = null;
                    $ctor$2(/*Pipe*/ pipe)
                    {
                        super.$ctor$1();
                        {
                            this._pipe = pipe;
                        }
                        return this;
                    }
                    /*bool */ TryRead(/*out ReadResult*/ result)
                    {
                        return this._pipe.TryRead(result);
                    }
                    /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.ReadAsync(cancellationToken);
                    }
                    /*ValueTask<ReadResult> */ ReadAtLeastAsyncCore(/*int*/ minimumBytes, /*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.ReadAtLeastAsync(minimumBytes, cancellationToken);
                    }
                    /*void */ AdvanceTo(/*SequencePosition*/ consumed)
                    {
                        return this._pipe.AdvanceReader($.$ref(() => consumed, ));
                    }
                    /*void */ AdvanceTo$1(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
                    {
                        return this._pipe.AdvanceReader$1($.$ref(() => consumed, ), $.$ref(() => examined, ));
                    }
                    /*void */ CancelPendingRead()
                    {
                        return this._pipe.CancelPendingRead();
                    }
                    /*void */ Complete(/*Exception?*/ exception)
                    {
                        return this._pipe.CompleteReader(exception);
                    }
                    /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
                    {
                        return this._pipe.OnWriterCompleted(callback, state);
                    }
                    /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
                    {
                        return this._pipe.GetReadAsyncStatus();
                    }
                    /*ReadResult */ GetResult(/*short*/ token)
                    {
                        return this._pipe.GetReadAsyncResult();
                    }
                    /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
                    {
                        return this._pipe.OnReadAsyncCompleted(continuation, state, flags);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.GetStatus(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetStatus()
                    {
                        return this.GetStatus(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$OnCompleted()
                    {
                        return this.OnCompleted(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.GetResult(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetResult()
                    {
                        return this.GetResult(...arguments);
                    }
                    static $h = 718537;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1439433,"m":[{"r":262145,"p":[{"n":"result","p":1767113,"f":2}],"n":"TryRead","d":718537,"h":12885620425,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":718537,"h":17180587721,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumBytes","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAtLeastAsyncCore","d":718537,"h":21475555017,"f":32772},{"r":65537,"p":[{"n":"consumed","p":1218810}],"n":"AdvanceTo","d":718537,"h":25770522313,"f":32769},{"r":65537,"p":[{"n":"consumed","p":1218810},{"n":"examined","p":1218810}],"n":"AdvanceTo","o":"@$1","d":718537,"h":30065489609,"f":32769},{"r":65537,"n":"CancelPendingRead","d":718537,"h":34360456905,"f":32769},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":718537,"h":38655424201,"f":32769},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":718537,"h":42950391497,"f":32769},{"r":133038081,"p":[{"n":"token","p":524289}],"n":"GetStatus","d":718537,"h":47245358793,"f":1},{"r":1767113,"p":[{"n":"token","p":524289}],"n":"GetResult","d":718537,"h":51540326089,"f":1},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"token","p":524289},{"n":"flags","p":132972545}],"n":"OnCompleted","d":718537,"h":55835293385,"f":1}],"l":[{"t":653001,"n":"_pipe","d":718537,"h":4295685833,"f":2}],"c":[{"p":[{"n":"pipe","p":653001}],"n":".ctor","o":"$ctor$2","d":718537,"h":8590653129,"f":1}],"i":[$.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.ReadResult).$h],"d":653001,"h":718537}; }
                    static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.ReadResult) ]; }
                    static get $fullName() { return `System.IO.Pipelines.Pipe.DefaultPipeReader`; }
                }, $cls, ($v) => $cls.$_DefaultPipeReader = $v);
            }
            static $_DefaultPipeWriter;
            static get DefaultPipeWriter()
            {
                let $cls = $.$sipl.System.IO.Pipelines.Pipe;
                return $cls.$_DefaultPipeWriter ??= $asm.$ncls("$sipl.System.IO.Pipelines.Pipe.DefaultPipeWriter", ($self) => class DefaultPipeWriter extends $.$sipl.System.IO.Pipelines.PipeWriter
                {
                    /*Pipe*/ _pipe = null;
                    $ctor$2(/*Pipe*/ pipe)
                    {
                        super.$ctor$1();
                        {
                            this._pipe = pipe;
                        }
                        return this;
                    }
                    /*void */ Complete(/*Exception?*/ exception)
                    {
                        return this._pipe.CompleteWriter(exception);
                    }
                    /*void */ CancelPendingFlush()
                    {
                        return this._pipe.CancelPendingFlush();
                    }
                    /*bool */ get CanGetUnflushedBytes()
                    {
                        return true;
                    }
                    /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
                    {
                        return this._pipe.OnReaderCompleted(callback, state);
                    }
                    /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.FlushAsync(cancellationToken);
                    }
                    /*void */ Advance(/*int*/ bytes)
                    {
                        return this._pipe.Advance(bytes);
                    }
                    /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
                    {
                        return this._pipe.GetMemory(sizeHint);
                    }
                    /*Span<byte> */ GetSpan(/*int*/ sizeHint)
                    {
                        return this._pipe.GetSpan(sizeHint);
                    }
                    /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
                    {
                        return this._pipe.GetFlushAsyncStatus();
                    }
                    /*FlushResult */ GetResult(/*short*/ token)
                    {
                        return this._pipe.GetFlushAsyncResult();
                    }
                    /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
                    {
                        return this._pipe.OnFlushAsyncCompleted(continuation, state, flags);
                    }
                    /*long */ get UnflushedBytes()
                    {
                        return this._pipe.GetUnflushedBytes();
                    }
                    /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.WriteAsync(source, cancellationToken);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.GetStatus(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetStatus()
                    {
                        return this.GetStatus(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$OnCompleted()
                    {
                        return this.OnCompleted(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.GetResult(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetResult()
                    {
                        return this.GetResult(...arguments);
                    }
                    static $h = 784073;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1636041,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770587849,"f":32769},"n":"CanGetUnflushedBytes","d":784073,"h":21475620553,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68720260809,"f":32769},"n":"UnflushedBytes","d":784073,"h":64425293513,"f":32769}],"m":[{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":784073,"h":12885685961,"f":32769},{"r":65537,"n":"CancelPendingFlush","d":784073,"h":17180653257,"f":32769},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":784073,"h":30065555145,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","d":784073,"h":34360522441,"f":32769},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":784073,"h":38655489737,"f":32769},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":784073,"h":42950457033,"f":32769},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":784073,"h":47245424329,"f":32769},{"r":133038081,"p":[{"n":"token","p":524289}],"n":"GetStatus","d":784073,"h":51540391625,"f":1},{"r":456393,"p":[{"n":"token","p":524289}],"n":"GetResult","d":784073,"h":55835358921,"f":1},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"token","p":524289},{"n":"flags","p":132972545}],"n":"OnCompleted","d":784073,"h":60130326217,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","d":784073,"h":73015228105,"f":32769}],"l":[{"t":653001,"n":"_pipe","d":784073,"h":4295751369,"f":2}],"c":[{"p":[{"n":"pipe","p":653001}],"n":".ctor","o":"$ctor$2","d":784073,"h":8590718665,"f":1}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h,$.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.FlushResult).$h],"d":653001,"h":784073}; }
                    static get $b() { return $.$sipl.System.IO.Pipelines.PipeWriter; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte), $.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.FlushResult) ]; }
                    static get $fullName() { return `System.IO.Pipelines.Pipe.DefaultPipeWriter`; }
                }, $cls, ($v) => $cls.$_DefaultPipeWriter = $v);
            }
            /*Action<object?>*/ static s_signalReaderAwaitable = null;
            /*Action<object?>*/ static s_signalWriterAwaitable = null;
            /*Action<object?>*/ static s_invokeCompletionCallbacks = null;
            /*ContextCallback*/ static s_executionContextRawCallback = null;
            /*SendOrPostCallback*/ static s_syncContextExecutionContextCallback = null;
            /*SendOrPostCallback*/ static s_syncContextExecuteWithoutExecutionContextCallback = null;
            /*Action<object?>*/ static s_scheduleWithExecutionContextCallback = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*DefaultPipeReader*/ _reader = null;
            /*DefaultPipeWriter*/ _writer = null;
            /*PipeOptions*/ _options = null;
            /*object*/ _sync = null;
            /*bool */ get UseSynchronizationContext()
            {
                return this._options.UseSynchronizationContext;
            }
            /*int */ get MinimumSegmentSize()
            {
                return this._options.MinimumSegmentSize;
            }
            /*long */ get PauseWriterThreshold()
            {
                return this._options.PauseWriterThreshold;
            }
            /*long */ get ResumeWriterThreshold()
            {
                return this._options.ResumeWriterThreshold;
            }
            /*PipeScheduler */ get ReaderScheduler()
            {
                return this._options.ReaderScheduler;
            }
            /*PipeScheduler */ get WriterScheduler()
            {
                return this._options.WriterScheduler;
            }
            /*object */ get SyncObj()
            {
                return this._sync;
            }
            /*long*/ _unconsumedBytes = 0n;
            /*long*/ _unflushedBytes = 0n;
            /*PipeAwaitable*/ _readerAwaitable;
            /*PipeAwaitable*/ _writerAwaitable;
            /*PipeCompletion*/ _writerCompletion;
            /*PipeCompletion*/ _readerCompletion;
            /*long*/ _lastExaminedIndex = -1n;
            /*BufferSegment?*/ _readHead = null;
            /*int*/ _readHeadIndex = 0;
            /*bool*/ _disposed = false;
            /*BufferSegment?*/ _readTail = null;
            /*int*/ _readTailIndex = 0;
            /*int*/ _minimumReadBytes = 0;
            /*BufferSegment?*/ _writingHead = null;
            /*Memory<byte>*/ _writingHeadMemory;
            /*int*/ _writingHeadBytesBuffered = 0;
            /*PipeOperationState*/ _operationState;
            /*long */ get Length()
            {
                return this._unconsumedBytes;
            }
            $ctor$1()
            {
                this.$ctor$2($.$sipl.System.IO.Pipelines.PipeOptions.Default);
                {
                }
                return this;
            }
            $ctor$2(/*PipeOptions*/ options)
            {
                super.$ctor();
                {
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$2(options.InitialSegmentPoolSize);
                    this._operationState = new $.$sipl.System.IO.Pipelines.PipeOperationState();
                    this._readerCompletion = new $.$sipl.System.IO.Pipelines.PipeCompletion();
                    this._writerCompletion = new $.$sipl.System.IO.Pipelines.PipeCompletion();
                    this._options = options;
                    this._readerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(false, this.UseSynchronizationContext);
                    this._writerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(true, this.UseSynchronizationContext);
                    this._reader = new $.$sipl.System.IO.Pipelines.Pipe.DefaultPipeReader().$ctor$2(this);
                    this._writer = new $.$sipl.System.IO.Pipelines.Pipe.DefaultPipeWriter().$ctor$2(this);
                }
                return this;
            }
            /*void */ ResetState()
            {
                this._readerCompletion.Reset();
                this._writerCompletion.Reset();
                this._readerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(false, this.UseSynchronizationContext);
                this._writerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(true, this.UseSynchronizationContext);
                this._readTailIndex = 0;
                this._readHeadIndex = 0;
                this._lastExaminedIndex = BigInt(-1);
                this._unflushedBytes = 0n;
                this._unconsumedBytes = 0n;
            }
            /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateWriteHeadIfNeeded(sizeHint);
                return this._writingHeadMemory;
            }
            /*Span<byte> */ GetSpan(/*int*/ sizeHint)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateWriteHeadIfNeeded(sizeHint);
                return this._writingHeadMemory.Span;
            }
            /*void */ AllocateWriteHeadIfNeeded(/*int*/ sizeHint)
            {
                if (!this._operationState.IsWritingActive || this._writingHeadMemory.Length === 0 || this._writingHeadMemory.Length < sizeHint)
                {
                    this.AllocateWriteHeadSynchronized(sizeHint);
                }
            }
            /*void */ AllocateWriteHeadSynchronized(/*int*/ sizeHint)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._operationState.BeginWrite();
                        if (this._writingHead === null)
                        {
                            /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                            this._writingHead = this._readHead = this._readTail = newSegment;
                            this._lastExaminedIndex = 0n;
                        }
                        else 
                        {
                            /*int*/ let bytesLeftInBuffer = this._writingHeadMemory.Length;
                            if (bytesLeftInBuffer === 0 || bytesLeftInBuffer < sizeHint)
                            {
                                if (this._writingHeadBytesBuffered > 0)
                                {
                                    this._writingHead.End += this._writingHeadBytesBuffered;
                                    this._writingHeadBytesBuffered = 0;
                                }
                                if (this._writingHead.Length === 0)
                                {
                                    this._writingHead.ResetMemory();
                                    this.RentMemory(this._writingHead, sizeHint);
                                }
                                else 
                                {
                                    /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                                    this._writingHead.SetNext(newSegment);
                                    this._writingHead = newSegment;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*BufferSegment */ AllocateSegment(/*int*/ sizeHint)
            {
                /*BufferSegment*/ let newSegment = this.CreateSegmentUnsynchronized();
                this.RentMemory(newSegment, sizeHint);
                return newSegment;
            }
            /*void */ RentMemory(/*BufferSegment*/ segment, /*int*/ sizeHint)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment.MemoryOwner === null, "segment.MemoryOwner is null");
                $.$spc.System.Diagnostics.Debug.Assert$1(sizeHint >= 0, "sizeHint >= 0");
                /*MemoryPool<byte>?*/ let pool = null;
                /*int*/ let maxSize = -1;
                if (!this._options.IsDefaultSharedMemoryPool)
                {
                    pool = this._options.Pool;
                    maxSize = pool.MaxBufferSize;
                }
                if (sizeHint <= maxSize)
                {
                    segment.SetOwnedMemory(pool.Rent(this.GetSegmentSize(sizeHint, maxSize)));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(sizeHint, 2147483647);
                    segment.SetOwnedMemory$1($.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(sizeToRequest));
                }
                this._writingHeadMemory = segment.AvailableMemory;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$spc.System.Math.Max$4(this.MinimumSegmentSize, sizeHint);
                /*int*/ let adjustedToMaximumSize = $.$spc.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readHead, "Returning _readHead segment that's in use!");
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readTail, "Returning _readTail segment that's in use!");
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._writingHead, "Returning _writingHead segment that's in use!");
                if (this._bufferSegmentPool.Count < this._options.MaxSegmentPoolSize)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*bool */ CommitUnsynchronized()
            {
                this._operationState.EndWrite();
                if (this._unflushedBytes === 0n)
                {
                    return false;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writingHead !== null, "_writingHead != null");
                this._writingHead.End += this._writingHeadBytesBuffered;
                this._readTail = this._writingHead;
                this._readTailIndex = this._writingHead.End;
                /*long*/ let oldLength = this._unconsumedBytes;
                this._unconsumedBytes += this._unflushedBytes;
                /*bool*/ let resumeReader = true;
                if (this._unconsumedBytes < BigInt(this._minimumReadBytes))
                {
                    resumeReader = false;
                }
                else if (this.PauseWriterThreshold > 0n && oldLength < this.PauseWriterThreshold && this._unconsumedBytes >= this.PauseWriterThreshold && !this._readerCompletion.IsCompleted)
                {
                    this._writerAwaitable.SetUncompleted();
                }
                this._unflushedBytes = 0n;
                this._writingHeadBytesBuffered = 0;
                return resumeReader;
            }
            /*void */ Advance(/*int*/ bytes)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if ((bytes >>> 0) > (this._writingHeadMemory.Length >>> 0))
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.bytes*/);
                        }
                        if (this._readerCompletion.IsCompleted)
                        {
                            return;
                        }
                        this.AdvanceCore(bytes);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*void */ AdvanceCore(/*int*/ bytesWritten)
            {
                this._unflushedBytes += BigInt(bytesWritten);
                this._writingHeadBytesBuffered += bytesWritten;
                this._writingHeadMemory = this._writingHeadMemory.Slice(bytesWritten);
            }
            /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.FlushResult, cancellationToken));
                }
                /*CompletionData*/ let completionData;
                /*ValueTask<FlushResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this.PrepareFlushUnsynchronized($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => result, ($v) => result = $v, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)), cancellationToken);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
                return result;
            }
            /*void */ PrepareFlushUnsynchronized(/*out CompletionData*/ completionData, /*out ValueTask<FlushResult>*/ result, /*CancellationToken*/ cancellationToken)
            {
                /*var*/ let completeReader = this.CommitUnsynchronized();
                this._writerAwaitable.BeginOperation(cancellationToken, $.$sipl.System.IO.Pipelines.Pipe.s_signalWriterAwaitable, this);
                if (this._writerAwaitable.IsCompleted)
                {
                    /*FlushResult*/ let flushResult = new $.$sipl.System.IO.Pipelines.FlushResult();
                    this.GetFlushResult($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sipl.System.IO.Pipelines.FlushResult, () => flushResult, ($v) => flushResult = $v, null));
                    result.$v = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(flushResult.Clone());
                }
                else 
                {
                    result.$v = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$4(this._writer, 0);
                }
                if (completeReader)
                {
                    this._readerAwaitable.Complete(completionData);
                }
                else 
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writerAwaitable.IsCompleted || this._readerAwaitable.IsCompleted, "_writerAwaitable.IsCompleted || _readerAwaitable.IsCompleted");
            }
            /*void */ CompleteWriter(/*Exception?*/ exception)
            {
                /*CompletionData*/ let completionData;
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                /*bool*/ let readerCompleted;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this.CommitUnsynchronized();
                        completionCallbacks = this._writerCompletion.TryComplete(exception);
                        this._readerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        readerCompleted = this._readerCompletion.IsCompleted;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (readerCompleted)
                {
                    this.CompletePipe();
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.ReaderScheduler, completionCallbacks);
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ AdvanceReader(/*in SequencePosition*/ consumed)
            {
                this.AdvanceReader$1(consumed, consumed);
            }
            /*void */ AdvanceReader$1(/*in SequencePosition*/ consumed, /*in SequencePosition*/ examined)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                this.AdvanceReader$2($.$cast(consumed.$v.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), consumed.$v.GetInteger(), $.$cast(examined.$v.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), examined.$v.GetInteger());
            }
            /*void */ AdvanceReader$2(/*BufferSegment?*/ consumedSegment, /*int*/ consumedIndex, /*BufferSegment?*/ examinedSegment, /*int*/ examinedIndex)
            {
                if (consumedSegment !== null && examinedSegment !== null && $.$sipl.System.IO.Pipelines.BufferSegment.GetLength(consumedSegment, consumedIndex, examinedSegment, examinedIndex) < 0n)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition();
                }
                /*BufferSegment?*/ let returnStart = null;
                /*BufferSegment?*/ let returnEnd = null;
                /*CompletionData*/ let completionData = new $.$sipl.System.IO.Pipelines.CompletionData();
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        /*var*/ let examinedEverything = false;
                        if (examinedSegment === this._readTail)
                        {
                            examinedEverything = examinedIndex === this._readTailIndex;
                        }
                        if (examinedSegment !== null && this._lastExaminedIndex >= 0n)
                        {
                            /*long*/ let examinedBytes = $.$sipl.System.IO.Pipelines.BufferSegment.GetLength$1(this._lastExaminedIndex, examinedSegment, examinedIndex);
                            /*long*/ let oldLength = this._unconsumedBytes;
                            this._unconsumedBytes -= examinedBytes;
                            this._lastExaminedIndex = examinedSegment.RunningIndex + BigInt(examinedIndex);
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._unconsumedBytes >= 0n, "Length has gone negative");
                            $.$spc.System.Diagnostics.Debug.Assert$1(this.ResumeWriterThreshold >= 1n, "ResumeWriterThreshold is less than 1");
                            if (oldLength >= this.ResumeWriterThreshold && this._unconsumedBytes < this.ResumeWriterThreshold)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(examinedBytes > 0n, "examinedBytes > 0");
                                this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                            }
                        }
                        if (consumedSegment !== null)
                        {
                            if (this._readHead === null)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AdvanceToInvalidCursor();
                                return;
                            }
                            returnStart = this._readHead;
                            returnEnd = consumedSegment;
                            /*void*/  function MoveReturnEndToNextBlock()
                            {
                                /*BufferSegment?*/ let nextBlock = returnEnd.NextSegment;
                                if (this._readTail === returnEnd)
                                {
                                    this._readTail = nextBlock;
                                    this._readTailIndex = 0;
                                }
                                this._readHead = nextBlock;
                                this._readHeadIndex = 0;
                                returnEnd = nextBlock;
                            }
                            if (consumedIndex === returnEnd.Length)
                            {
                                if (this._writingHead !== returnEnd)
                                {
                                    MoveReturnEndToNextBlock.call(this);
                                }
                                else if (this._writingHeadBytesBuffered === 0 && !this._operationState.IsWritingActive)
                                {
                                    this._writingHead = null;
                                    this._writingHeadMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                                    MoveReturnEndToNextBlock.call(this);
                                }
                                else 
                                {
                                    this._readHead = consumedSegment;
                                    this._readHeadIndex = consumedIndex;
                                }
                            }
                            else 
                            {
                                this._readHead = consumedSegment;
                                this._readHeadIndex = consumedIndex;
                            }
                        }
                        if (examinedEverything && !this._writerCompletion.IsCompleted)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._writerAwaitable.IsCompleted, "PipeWriter.FlushAsync isn't completed and will deadlock");
                            this._readerAwaitable.SetUncompleted();
                        }
                        while(returnStart !== null && returnStart !== returnEnd)
                        {
                            /*BufferSegment?*/ let next = returnStart.NextSegment;
                            returnStart.Reset();
                            this.ReturnSegmentUnsynchronized(returnStart);
                            returnStart = next;
                        }
                        this._operationState.EndRead();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ CompleteReader(/*Exception?*/ exception)
            {
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                /*CompletionData*/ let completionData;
                /*bool*/ let writerCompleted;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (this._operationState.IsReadingActive)
                        {
                            this._operationState.EndRead();
                        }
                        completionCallbacks = this._readerCompletion.TryComplete(exception);
                        this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        writerCompleted = this._writerCompletion.IsCompleted;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (writerCompleted)
                {
                    this.CompletePipe();
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.WriterScheduler, completionCallbacks);
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                if (callback === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.callback*/);
                }
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        completionCallbacks = this._writerCompletion.AddCallback(callback, state);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.ReaderScheduler, completionCallbacks);
                }
            }
            /*void */ CancelPendingRead()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.Cancel($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ CancelPendingFlush()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._writerAwaitable.Cancel($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                if (callback === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.callback*/);
                }
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        completionCallbacks = this._readerCompletion.AddCallback(callback, state);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.WriterScheduler, completionCallbacks);
                }
            }
            /*ValueTask<ReadResult> */ ReadAtLeastAsync(/*int*/ minimumBytes, /*CancellationToken*/ token)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                if (token.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.ReadResult, token));
                }
                /*CompletionData*/ let completionData = new $.$sipl.System.IO.Pipelines.CompletionData();
                /*ValueTask<ReadResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        if (this._readerAwaitable.IsCompleted)
                        {
                            /*ReadResult*/ let readResult;
                            this.GetReadResult($.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                            if (this._unconsumedBytes >= BigInt(minimumBytes) || readResult.IsCanceled || readResult.IsCompleted)
                            {
                                return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(readResult);
                            }
                            this._readerAwaitable.SetUncompleted();
                            this._operationState.EndRead();
                            this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        }
                        if (!this._writerAwaitable.IsCompleted)
                        {
                            this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        }
                        this._minimumReadBytes = minimumBytes;
                        result = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$4(this._reader, 0);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, undefined, $.$sipl.System.IO.Pipelines.CompletionData));
                return result;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ token)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                if (token.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.ReadResult, token));
                }
                /*ValueTask<ReadResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        if (this._readerAwaitable.IsCompleted)
                        {
                            /*ReadResult*/ let readResult;
                            this.GetReadResult($.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                            result = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(readResult);
                        }
                        else 
                        {
                            result = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$4(this._reader, 0);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                return result;
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (this._readerCompletion.IsCompleted)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                        }
                        if (this._unconsumedBytes > 0n || this._readerAwaitable.IsCompleted)
                        {
                            this.GetReadResult(result);
                            return true;
                        }
                        if (this._readerAwaitable.IsRunning)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                        }
                        this._operationState.BeginReadTentative();
                        result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                        return false;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            static /*void */ ScheduleCallbacks(/*PipeScheduler*/ scheduler, /*PipeCompletionCallbacks*/ completionCallbacks)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(completionCallbacks !== null, "completionCallbacks != null");
                scheduler.UnsafeSchedule($.$sipl.System.IO.Pipelines.Pipe.s_invokeCompletionCallbacks, completionCallbacks);
            }
            static /*void */ TrySchedule(/*PipeScheduler*/ scheduler, /*in CompletionData*/ completionData)
            {
                /*Action<object?>*/ let completion = completionData.$v.Completion;
                if (completion === null)
                {
                    return;
                }
                if (completionData.$v.SynchronizationContext === null && completionData.$v.ExecutionContext === null)
                {
                    scheduler.UnsafeSchedule(completion, completionData.$v.CompletionState);
                }
                else 
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleWithContext(scheduler, completionData);
                }
            }
            static /*void */ ScheduleWithContext(/*PipeScheduler*/ scheduler, /*in CompletionData*/ completionData)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(completionData.$v.SynchronizationContext !== null || completionData.$v.ExecutionContext !== null, "completionData.SynchronizationContext != null || completionData.ExecutionContext != null");
                if (completionData.$v.SynchronizationContext === null)
                {
                    scheduler.UnsafeSchedule($.$sipl.System.IO.Pipelines.Pipe.s_scheduleWithExecutionContextCallback, completionData.$v);
                }
                else 
                {
                    if (completionData.$v.ExecutionContext === null)
                    {
                        completionData.$v.SynchronizationContext.Post($.$sipl.System.IO.Pipelines.Pipe.s_syncContextExecuteWithoutExecutionContextCallback, completionData.$v);
                    }
                    else 
                    {
                        completionData.$v.SynchronizationContext.Post($.$sipl.System.IO.Pipelines.Pipe.s_syncContextExecutionContextCallback, completionData.$v);
                    }
                }
            }
            static /*void */ ExecuteWithoutExecutionContext(/*object*/ state)
            {
                /*CompletionData*/ let completionData = $.$cast(state, $.$sipl.System.IO.Pipelines.CompletionData);
                completionData.Completion.Invoke(completionData.CompletionState);
            }
            static /*void */ ExecuteWithExecutionContext(/*object*/ state)
            {
                /*CompletionData*/ let completionData = $.$cast(state, $.$sipl.System.IO.Pipelines.CompletionData);
                $.$spc.System.Diagnostics.Debug.Assert$1(completionData.ExecutionContext !== null, "completionData.ExecutionContext != null");
                $.$spc.System.Threading.ExecutionContext.Run(completionData.ExecutionContext, $.$sipl.System.IO.Pipelines.Pipe.s_executionContextRawCallback, state);
            }
            /*void */ CompletePipe()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        this._disposed = true;
                        /*BufferSegment?*/ let segment = this._readHead ?? this._readTail;
                        while(segment !== null)
                        {
                            /*BufferSegment*/ let returnSegment = segment;
                            segment = segment.NextSegment;
                            returnSegment.Reset();
                        }
                        this._writingHead = null;
                        this._writingHeadMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                        this._readHead = null;
                        this._readTail = null;
                        this._lastExaminedIndex = BigInt(-1);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*ValueTaskSourceStatus */ GetReadAsyncStatus()
            {
                if (this._readerAwaitable.IsCompleted)
                {
                    if (this._writerCompletion.IsFaulted)
                    {
                        return 2/*ValueTaskSourceStatus.Faulted*/;
                    }
                    return 1/*ValueTaskSourceStatus.Succeeded*/;
                }
                return 0/*ValueTaskSourceStatus.Pending*/;
            }
            /*void */ OnReadAsyncCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                /*CompletionData*/ let completionData;
                /*bool*/ let doubleCompletion;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.OnCompleted(continuation, state, flags, $.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => doubleCompletion, ($v) => doubleCompletion = $v, $.$spc.System.Boolean));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (doubleCompletion)
                {
                    this.Writer.Complete($.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation());
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*ReadResult */ GetReadAsyncResult()
            {
                /*ReadResult*/ let result;
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                /*CancellationToken*/ let cancellationToken = new $.$spc.System.Threading.CancellationToken();
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                        {
                            if (!this._readerAwaitable.IsCompleted)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_GetResultNotCompleted();
                            }
                            cancellationTokenRegistration = this._readerAwaitable.ReleaseCancellationTokenRegistration($.$ref(() => cancellationToken, ($v) => cancellationToken = $v, $.$spc.System.Threading.CancellationToken));
                            this.GetReadResult($.$ref(() => result, ($v) => result = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                    }
                }
                finally
                {
                    {
                        cancellationTokenRegistration.Dispose();
                    }
                }
                if (result.IsCanceled)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                }
                return result;
            }
            /*void */ GetReadResult(/*out ReadResult*/ result)
            {
                /*bool*/ let isCompleted = this._writerCompletion.IsCompletedOrThrow();
                /*bool*/ let isCanceled = this._readerAwaitable.ObserveCancellation();
                /*BufferSegment?*/ let head = this._readHead;
                if (head !== null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readTail !== null, "_readTail != null");
                    /*var*/ let readOnlySequence = new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))().$ctor$3(head, this._readHeadIndex, this._readTail, this._readTailIndex);
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(readOnlySequence, isCanceled, isCompleted);
                }
                else 
                {
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))(), isCanceled, isCompleted);
                }
                if (isCanceled)
                {
                    this._operationState.BeginReadTentative();
                }
                else 
                {
                    this._operationState.BeginRead();
                }
                this._minimumReadBytes = 0;
            }
            /*ValueTaskSourceStatus */ GetFlushAsyncStatus()
            {
                if (this._writerAwaitable.IsCompleted)
                {
                    if (this._readerCompletion.IsFaulted)
                    {
                        return 2/*ValueTaskSourceStatus.Faulted*/;
                    }
                    return 1/*ValueTaskSourceStatus.Succeeded*/;
                }
                return 0/*ValueTaskSourceStatus.Pending*/;
            }
            /*FlushResult */ GetFlushAsyncResult()
            {
                /*FlushResult*/ let result = new $.$sipl.System.IO.Pipelines.FlushResult();
                /*CancellationToken*/ let cancellationToken = new $.$spc.System.Threading.CancellationToken();
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                        {
                            if (!this._writerAwaitable.IsCompleted)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_GetResultNotCompleted();
                            }
                            this.GetFlushResult($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sipl.System.IO.Pipelines.FlushResult, () => result, ($v) => result = $v, null));
                            cancellationTokenRegistration = this._writerAwaitable.ReleaseCancellationTokenRegistration($.$ref(() => cancellationToken, ($v) => cancellationToken = $v, $.$spc.System.Threading.CancellationToken));
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                    }
                }
                finally
                {
                    {
                        cancellationTokenRegistration.Dispose();
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                }
                return result;
            }
            /*long */ GetUnflushedBytes()
            {
                return this._unflushedBytes;
            }
            /*void */ GetFlushResult(/*ref FlushResult*/ result)
            {
                if (this._writerAwaitable.ObserveCancellation())
                {
                    result.$v._resultFlags |= 1/*ResultFlags.Canceled*/;
                }
                if (this._readerCompletion.IsCompletedOrThrow())
                {
                    result.$v._resultFlags |= 2/*ResultFlags.Completed*/;
                }
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (this._readerCompletion.IsCompletedOrThrow())
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, true));
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.FlushResult, cancellationToken));
                }
                /*CompletionData*/ let completionData;
                /*ValueTask<FlushResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this.AllocateWriteHeadIfNeeded(0);
                        if (source.Length <= this._writingHeadMemory.Length)
                        {
                            source.CopyTo(this._writingHeadMemory);
                            this.AdvanceCore(source.Length);
                        }
                        else 
                        {
                            this.WriteMultiSegment(source.Span);
                        }
                        this.PrepareFlushUnsynchronized($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => result, ($v) => result = $v, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)), cancellationToken);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
                return result;
            }
            /*void */ WriteMultiSegment(/*ReadOnlySpan<byte>*/ source)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writingHead !== null, "_writingHead != null");
                /*Span<byte>*/ let destination = this._writingHeadMemory.Span;
                while(true)
                {
                    /*int*/ let writable = $.$spc.System.Math.Min$4(destination.Length, source.Length);
                    source.Slice$1(0, writable).CopyTo(destination);
                    source = source.Slice(writable);
                    this.AdvanceCore(writable);
                    if (source.Length === 0)
                    {
                        break;
                    }
                    this._writingHead.End += this._writingHeadBytesBuffered;
                    this._writingHeadBytesBuffered = 0;
                    /*BufferSegment*/ let newSegment = this.AllocateSegment(0);
                    this._writingHead.SetNext(newSegment);
                    this._writingHead = newSegment;
                    destination = this._writingHeadMemory.Span;
                }
            }
            /*void */ OnFlushAsyncCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                /*CompletionData*/ let completionData;
                /*bool*/ let doubleCompletion;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._writerAwaitable.OnCompleted(continuation, state, flags, $.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => doubleCompletion, ($v) => doubleCompletion = $v, $.$spc.System.Boolean));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (doubleCompletion)
                {
                    this.Reader.Complete($.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation());
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ ReaderCancellationRequested()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.CancellationTokenFired($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ WriterCancellationRequested()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._writerAwaitable.CancellationTokenFired($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*PipeReader */ get Reader()
            {
                return this._reader;
            }
            /*PipeWriter */ get Writer()
            {
                return this._writer;
            }
            /*void */ Reset()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (!this._disposed)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_ResetIncompleteReaderWriter();
                        }
                        this._disposed = false;
                        this.ResetState();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
                this._sync = new $.$spc.System.Object().$ctor();
                this._readerAwaitable = $.$default($.$sipl.System.IO.Pipelines.PipeAwaitable);
                this._writerAwaitable = $.$default($.$sipl.System.IO.Pipelines.PipeAwaitable);
                this._writerCompletion = $.$default($.$sipl.System.IO.Pipelines.PipeCompletion);
                this._readerCompletion = $.$default($.$sipl.System.IO.Pipelines.PipeCompletion);
                this._writingHeadMemory = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
                this._operationState = $.$default($.$sipl.System.IO.Pipelines.PipeOperationState);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_signalReaderAwaitable = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.Pipe)).ReaderCancellationRequested();
                    });
                }
                {
                    this.s_signalWriterAwaitable = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.Pipe)).WriterCancellationRequested();
                    });
                }
                {
                    this.s_invokeCompletionCallbacks = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.PipeCompletionCallbacks)).Execute();
                    });
                }
                {
                    this.s_executionContextRawCallback = new $.$spc.System.Threading.ContextCallback().$ctor(null, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithoutExecutionContext);
                }
                {
                    this.s_syncContextExecutionContextCallback = new $.$spc.System.Threading.SendOrPostCallback().$ctor(null, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithExecutionContext);
                }
                {
                    this.s_syncContextExecuteWithoutExecutionContextCallback = new $.$spc.System.Threading.SendOrPostCallback().$ctor(null, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithoutExecutionContext);
                }
                {
                    this.s_scheduleWithExecutionContextCallback = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(null, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithExecutionContext);
                }
            }
            static $h = 653001;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":68720129737,"f":2},"n":"UseSynchronizationContext","d":653001,"h":64425162441,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":77310064329,"f":2},"n":"MinimumSegmentSize","d":653001,"h":73015097033,"f":2},{"p":917505,"g":{"r":0,"d":0,"h":85899998921,"f":2},"n":"PauseWriterThreshold","d":653001,"h":81605031625,"f":2},{"p":917505,"g":{"r":0,"d":0,"h":94489933513,"f":2},"n":"ResumeWriterThreshold","d":653001,"h":90194966217,"f":2},{"p":1570505,"g":{"r":0,"d":0,"h":103079868105,"f":2},"n":"ReaderScheduler","d":653001,"h":98784900809,"f":2},{"p":1570505,"g":{"r":0,"d":0,"h":111669802697,"f":2},"n":"WriterScheduler","d":653001,"h":107374835401,"f":2},{"p":131073,"g":{"r":0,"d":0,"h":120259737289,"f":2},"n":"SyncObj","d":653001,"h":115964769993,"f":2},{"p":917505,"g":{"r":0,"d":0,"h":201864115913,"f":8},"n":"Length","d":653001,"h":197569148617,"f":8},{"p":1439433,"g":{"r":0,"d":0,"h":416612480713,"f":1},"n":"Reader","d":653001,"h":412317513417,"f":1},{"p":1636041,"g":{"r":0,"d":0,"h":425202415305,"f":1},"n":"Writer","d":653001,"h":420907448009,"f":1}],"m":[{"r":65537,"n":"ResetState","d":653001,"h":214749017801,"f":2},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361}],"n":"GetMemory","d":653001,"h":219043985097,"f":8},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361}],"n":"GetSpan","d":653001,"h":223338952393,"f":8},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateWriteHeadIfNeeded","d":653001,"h":227633919689,"f":2},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateWriteHeadSynchronized","d":653001,"h":231928886985,"f":2},{"r":128713,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateSegment","d":653001,"h":236223854281,"f":2},{"r":65537,"p":[{"n":"segment","p":128713},{"n":"sizeHint","p":655361}],"n":"RentMemory","d":653001,"h":240518821577,"f":2},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361,"f":65,"v":2147483647}],"n":"GetSegmentSize","d":653001,"h":244813788873,"f":2},{"r":128713,"n":"CreateSegmentUnsynchronized","d":653001,"h":249108756169,"f":2},{"r":65537,"p":[{"n":"segment","p":128713}],"n":"ReturnSegmentUnsynchronized","d":653001,"h":253403723465,"f":2},{"r":262145,"n":"CommitUnsynchronized","d":653001,"h":257698690761,"f":8},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":653001,"h":261993658057,"f":8},{"r":65537,"p":[{"n":"bytesWritten","p":655361}],"n":"AdvanceCore","d":653001,"h":266288625353,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","d":653001,"h":270583592649,"f":8},{"r":65537,"p":[{"n":"completionData","p":325321,"f":2},{"n":"result","p":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"f":2},{"n":"cancellationToken","p":125960193}],"n":"PrepareFlushUnsynchronized","d":653001,"h":274878559945,"f":2},{"r":65537,"p":[{"n":"exception","p":47185921}],"n":"CompleteWriter","d":653001,"h":279173527241,"f":8},{"r":65537,"p":[{"n":"consumed","p":1218810,"f":8}],"n":"AdvanceReader","d":653001,"h":283468494537,"f":8},{"r":65537,"p":[{"n":"consumed","p":1218810,"f":8},{"n":"examined","p":1218810,"f":8}],"n":"AdvanceReader","o":"@$1","d":653001,"h":287763461833,"f":8},{"r":65537,"p":[{"n":"consumedSegment","p":128713},{"n":"consumedIndex","p":655361},{"n":"examinedSegment","p":128713},{"n":"examinedIndex","p":655361}],"n":"AdvanceReader","o":"@$2","d":653001,"h":292058429129,"f":2},{"r":65537,"p":[{"n":"exception","p":47185921}],"n":"CompleteReader","d":653001,"h":296353396425,"f":8},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":653001,"h":300648363721,"f":8},{"r":65537,"n":"CancelPendingRead","d":653001,"h":304943331017,"f":8},{"r":65537,"n":"CancelPendingFlush","d":653001,"h":309238298313,"f":8},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":653001,"h":313533265609,"f":8},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumBytes","p":655361},{"n":"token","p":125960193}],"n":"ReadAtLeastAsync","d":653001,"h":317828232905,"f":8},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"token","p":125960193}],"n":"ReadAsync","d":653001,"h":322123200201,"f":8},{"r":262145,"p":[{"n":"result","p":1767113,"f":2}],"n":"TryRead","d":653001,"h":326418167497,"f":8},{"r":65537,"p":[{"n":"scheduler","p":1570505},{"n":"completionCallbacks","p":1177289}],"n":"ScheduleCallbacks","d":653001,"h":330713134793,"f":34},{"r":65537,"p":[{"n":"scheduler","p":1570505},{"n":"completionData","p":325321,"f":8}],"n":"TrySchedule","d":653001,"h":335008102089,"f":34},{"r":65537,"p":[{"n":"scheduler","p":1570505},{"n":"completionData","p":325321,"f":8}],"n":"ScheduleWithContext","d":653001,"h":339303069385,"f":34},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ExecuteWithoutExecutionContext","d":653001,"h":343598036681,"f":34},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ExecuteWithExecutionContext","d":653001,"h":347893003977,"f":34},{"r":65537,"n":"CompletePipe","d":653001,"h":352187971273,"f":2},{"r":133038081,"n":"GetReadAsyncStatus","d":653001,"h":356482938569,"f":8},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132972545}],"n":"OnReadAsyncCompleted","d":653001,"h":360777905865,"f":8},{"r":1767113,"n":"GetReadAsyncResult","d":653001,"h":365072873161,"f":8},{"r":65537,"p":[{"n":"result","p":1767113,"f":2}],"n":"GetReadResult","d":653001,"h":369367840457,"f":2},{"r":133038081,"n":"GetFlushAsyncStatus","d":653001,"h":373662807753,"f":8},{"r":456393,"n":"GetFlushAsyncResult","d":653001,"h":377957775049,"f":8},{"r":917505,"n":"GetUnflushedBytes","d":653001,"h":382252742345,"f":8},{"r":65537,"p":[{"n":"result","p":456393,"f":4}],"n":"GetFlushResult","d":653001,"h":386547709641,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","d":653001,"h":390842676937,"f":8},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"WriteMultiSegment","d":653001,"h":395137644233,"f":2},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132972545}],"n":"OnFlushAsyncCompleted","d":653001,"h":399432611529,"f":8},{"r":65537,"n":"ReaderCancellationRequested","d":653001,"h":403727578825,"f":2},{"r":65537,"n":"WriterCancellationRequested","d":653001,"h":408022546121,"f":2},{"r":65537,"n":"Reset","d":653001,"h":429497382601,"f":1}],"l":[{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_signalReaderAwaitable","d":653001,"h":12885554889,"f":34},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_signalWriterAwaitable","d":653001,"h":17180522185,"f":34},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_invokeCompletionCallbacks","d":653001,"h":21475489481,"f":34},{"t":126615553,"n":"s_executionContextRawCallback","d":653001,"h":25770456777,"f":34},{"t":130875393,"n":"s_syncContextExecutionContextCallback","d":653001,"h":30065424073,"f":34},{"t":130875393,"n":"s_syncContextExecuteWithoutExecutionContextCallback","d":653001,"h":34360391369,"f":34},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_scheduleWithExecutionContextCallback","d":653001,"h":38655358665,"f":34},{"t":194249,"n":"_bufferSegmentPool","d":653001,"h":42950325961,"f":2},{"t":718537,"n":"_reader","d":653001,"h":47245293257,"f":2},{"t":784073,"n":"_writer","d":653001,"h":51540260553,"f":2},{"t":1373897,"n":"_options","d":653001,"h":55835227849,"f":2},{"t":131073,"n":"_sync","d":653001,"h":60130195145,"f":2},{"t":917505,"n":"_unconsumedBytes","d":653001,"h":124554704585,"f":2},{"t":917505,"n":"_unflushedBytes","d":653001,"h":128849671881,"f":2},{"t":849609,"n":"_readerAwaitable","d":653001,"h":133144639177,"f":2},{"t":849609,"n":"_writerAwaitable","d":653001,"h":137439606473,"f":2},{"t":1046217,"n":"_writerCompletion","d":653001,"h":141734573769,"f":2},{"t":1046217,"n":"_readerCompletion","d":653001,"h":146029541065,"f":2},{"t":917505,"n":"_lastExaminedIndex","d":653001,"h":150324508361,"f":2},{"t":128713,"n":"_readHead","d":653001,"h":154619475657,"f":2},{"t":655361,"n":"_readHeadIndex","d":653001,"h":158914442953,"f":2},{"t":262145,"n":"_disposed","d":653001,"h":163209410249,"f":2},{"t":128713,"n":"_readTail","d":653001,"h":167504377545,"f":2},{"t":655361,"n":"_readTailIndex","d":653001,"h":171799344841,"f":2},{"t":655361,"n":"_minimumReadBytes","d":653001,"h":176094312137,"f":2},{"t":128713,"n":"_writingHead","d":653001,"h":180389279433,"f":2},{"t":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"n":"_writingHeadMemory","d":653001,"h":184684246729,"f":2},{"t":655361,"n":"_writingHeadBytesBuffered","d":653001,"h":188979214025,"f":2},{"t":1242825,"n":"_operationState","d":653001,"h":193274181321,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":653001,"h":206159083209,"f":1},{"p":[{"n":"options","p":1373897}],"n":".ctor","o":"$ctor$2","d":653001,"h":210454050505,"f":1}],"j":[718537,784073],"h":653001}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.Pipe`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeCompletionCallbacks", ($self) => class PipeCompletionCallbacks extends $.$spc.System.Object
        {
            /*List<PipeCompletionCallback>*/ _callbacks = null;
            /*Exception?*/ _exception = null;
            $ctor$1(/*List<PipeCompletionCallback>*/ callbacks, /*ExceptionDispatchInfo?*/ edi)
            {
                super.$ctor();
                {
                    this._callbacks = callbacks;
                    this._exception = (edi?.SourceException ?? null);
                }
                return this;
            }
            /*void */ Execute()
            {
                /*var*/ let count = this._callbacks.Count;
                if (count === 0)
                {
                    return;
                }
                /*List<Exception>?*/ let exceptions = null;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*var*/ let callback = this._callbacks.get_Item(i);
                    this.Execute$1(callback, $.$ref(() => exceptions, ($v) => exceptions = $v, $.$spc.System.Collections.Generic.List$$($.$spc.System.Exception)));
                }
                if (exceptions !== null)
                {
                    throw new $.$spc.System.AggregateException().$ctor$8(exceptions);
                }
            }
            /*void */ Execute$1(/*PipeCompletionCallback*/ callback, /*ref List<Exception>?*/ exceptions)
            {
                try
                {
                    callback.Callback.Invoke(this._exception, callback.State);
                }
                catch(ex)
                {
                    exceptions.$v ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Exception))().$ctor$1();
                    exceptions.$v.Add(ex);
                }
            }
            static $h = 1177289;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","d":1177289,"h":17181046473,"f":1},{"r":65537,"p":[{"n":"callback","p":1111753},{"n":"exceptions","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Exception).$h,"f":4}],"n":"Execute","o":"@$1","d":1177289,"h":21476013769,"f":2}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h,"n":"_callbacks","d":1177289,"h":4296144585,"f":2},{"t":47185921,"n":"_exception","d":1177289,"h":8591111881,"f":2}],"c":[{"p":[{"n":"callbacks","p":$.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h},{"n":"edi","p":97517569}],"n":".ctor","o":"$ctor$1","d":1177289,"h":12886079177,"f":1}],"h":1177289}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletionCallbacks`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeOptions", ($self) => class PipeOptions extends $.$spc.System.Object
        {
            /*int*/ static DefaultMinimumSegmentSize = 4096;
            /*PipeOptions*/ static Default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*PipeScheduler?*/ readerScheduler, /*PipeScheduler?*/ writerScheduler, /*long*/ pauseWriterThreshold, /*long*/ resumeWriterThreshold, /*int*/ minimumSegmentSize, /*bool*/ useSynchronizationContext)
            {
                super.$ctor();
                {
                    this.MinimumSegmentSize = minimumSegmentSize === -1 ? 4096/*DefaultMinimumSegmentSize*/ : minimumSegmentSize;
                    this.InitialSegmentPoolSize = 4;
                    this.MaxSegmentPoolSize = 256;
                    /*int*/ let DefaultPauseWriterThreshold = 65536;
                    /*int*/ let DefaultResumeWriterThreshold = $.trunc(DefaultPauseWriterThreshold / 2);
                    if (pauseWriterThreshold === BigInt(-1))
                    {
                        pauseWriterThreshold = BigInt(DefaultPauseWriterThreshold);
                    }
                    else if (pauseWriterThreshold < 0n)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(4/*ExceptionArgument.pauseWriterThreshold*/);
                    }
                    if (resumeWriterThreshold === BigInt(-1))
                    {
                        resumeWriterThreshold = BigInt(DefaultResumeWriterThreshold);
                    }
                    else if (resumeWriterThreshold === 0n)
                    {
                        resumeWriterThreshold = 1n;
                    }
                    if (resumeWriterThreshold < 0n || (pauseWriterThreshold > 0n && resumeWriterThreshold > pauseWriterThreshold))
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(5/*ExceptionArgument.resumeWriterThreshold*/);
                    }
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.IsDefaultSharedMemoryPool = this.Pool === $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.ReaderScheduler = readerScheduler ?? $.$sipl.System.IO.Pipelines.PipeScheduler.ThreadPool;
                    this.WriterScheduler = writerScheduler ?? $.$sipl.System.IO.Pipelines.PipeScheduler.ThreadPool;
                    this.PauseWriterThreshold = pauseWriterThreshold;
                    this.ResumeWriterThreshold = resumeWriterThreshold;
                    this.UseSynchronizationContext = useSynchronizationContext;
                }
                return this;
            }
            /*bool*/ UseSynchronizationContext = false;
            /*long*/ PauseWriterThreshold = 0n;
            /*long*/ ResumeWriterThreshold = 0n;
            /*int*/ MinimumSegmentSize = 0;
            /*PipeScheduler*/ WriterScheduler = null;
            /*PipeScheduler*/ ReaderScheduler = null;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ IsDefaultSharedMemoryPool = false;
            /*int*/ InitialSegmentPoolSize = 0;
            /*int*/ MaxSegmentPoolSize = 0;
            //default member initializer
            constructor()
            {
                super();
                this.UseSynchronizationContext = false;
                this.IsDefaultSharedMemoryPool = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$sipl.System.IO.Pipelines.PipeOptions().$ctor$1(null, null, null, -1n, -1n, -1, true);
                }
            }
            static $h = 1373897;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1373897,"g":{"r":0,"d":0,"h":17181243081,"f":33},"n":"Default","d":1373897,"h":12886275785,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":34361112265,"f":1},"n":"UseSynchronizationContext","d":1373897,"h":30066144969,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":47246014153,"f":1},"n":"PauseWriterThreshold","d":1373897,"h":42951046857,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":60130916041,"f":1},"n":"ResumeWriterThreshold","d":1373897,"h":55835948745,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73015817929,"f":1},"n":"MinimumSegmentSize","d":1373897,"h":68720850633,"f":1},{"p":1570505,"g":{"r":0,"d":0,"h":85900719817,"f":1},"n":"WriterScheduler","d":1373897,"h":81605752521,"f":1},{"p":1570505,"g":{"r":0,"d":0,"h":98785621705,"f":1},"n":"ReaderScheduler","d":1373897,"h":94490654409,"f":1},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":111670523593,"f":1},"n":"Pool","d":1373897,"h":107375556297,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124555425481,"f":8},"n":"IsDefaultSharedMemoryPool","d":1373897,"h":120260458185,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":137440327369,"f":8},"n":"InitialSegmentPoolSize","d":1373897,"h":133145360073,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":150325229257,"f":8},"n":"MaxSegmentPoolSize","d":1373897,"h":146030261961,"f":8}],"l":[{"t":655361,"n":"DefaultMinimumSegmentSize","d":1373897,"h":4296341193,"f":34}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"f":65},{"n":"readerScheduler","p":1570505,"f":65},{"n":"writerScheduler","p":1570505,"f":65},{"n":"pauseWriterThreshold","p":917505,"f":65,"v":-1},{"n":"resumeWriterThreshold","p":917505,"f":65,"v":-1},{"n":"minimumSegmentSize","p":655361,"f":65,"v":-1},{"n":"useSynchronizationContext","p":262145,"f":65,"v":true}],"n":".ctor","o":"$ctor$1","d":1373897,"h":21476210377,"f":1}],"h":1373897}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeOptions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeExtensions", ($self) => class StreamPipeExtensions
        {
            static /*Task */ CopyToAsync(/*this Stream*/ source, /*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (source === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.source*/);
                }
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return destination.CopyFromAsync(source, cancellationToken);
            }
            static $h = 1963721;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"p":[{"n":"source","p":62128129},{"n":"destination","p":1636041},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","d":1963721,"h":4296931017,"f":33}],"h":1963721}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeExtensions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeReaderOptions", ($self) => class StreamPipeReaderOptions extends $.$spc.System.Object
        {
            /*int*/ static DefaultBufferSize = 4096;
            /*int*/ static DefaultMaxBufferSize = 2097152;
            /*int*/ static DefaultMinimumReadSize = 1024;
            /*StreamPipeReaderOptions*/ static s_default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*int*/ bufferSize, /*int*/ minimumReadSize, /*bool*/ leaveOpen)
            {
                this.$ctor$2(null, -1, -1, false, false);
                {
                }
                return this;
            }
            $ctor$2(/*MemoryPool<byte>?*/ pool, /*int*/ bufferSize, /*int*/ minimumReadSize, /*bool*/ leaveOpen, /*bool*/ useZeroByteReads)
            {
                super.$ctor();
                {
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.IsDefaultSharedMemoryPool = this.Pool === $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.BufferSize = bufferSize === -1 ? 4096/*DefaultBufferSize*/ : bufferSize <= 0 ? (() =>
                    {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("bufferSize")            })() : bufferSize;
                    this.MinimumReadSize = minimumReadSize === -1 ? 1024/*DefaultMinimumReadSize*/ : minimumReadSize <= 0 ? (() =>
                    {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("minimumReadSize")            })() : minimumReadSize;
                    this.LeaveOpen = leaveOpen;
                    this.UseZeroByteReads = useZeroByteReads;
                }
                return this;
            }
            /*int*/ BufferSize = 0;
            /*int*/ MaxBufferSize = 0;
            /*int*/ MinimumReadSize = 0;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ LeaveOpen = false;
            /*bool*/ UseZeroByteReads = false;
            /*bool*/ IsDefaultSharedMemoryPool = false;
            //default member initializer
            constructor()
            {
                super();
                this.MaxBufferSize = 2097152;
                this.LeaveOpen = false;
                this.UseZeroByteReads = false;
                this.IsDefaultSharedMemoryPool = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_default = new $.$sipl.System.IO.Pipelines.StreamPipeReaderOptions().$ctor$2(null, -1, -1, false, false);
                }
            }
            static $h = 2094793;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":38656800457,"f":1},"n":"BufferSize","d":2094793,"h":34361833161,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51541702345,"f":8},"n":"MaxBufferSize","d":2094793,"h":47246735049,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":64426604233,"f":1},"n":"MinimumReadSize","d":2094793,"h":60131636937,"f":1},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":77311506121,"f":1},"n":"Pool","d":2094793,"h":73016538825,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":90196408009,"f":1},"n":"LeaveOpen","d":2094793,"h":85901440713,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":103081309897,"f":1},"n":"UseZeroByteReads","d":2094793,"h":98786342601,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115966211785,"f":8},"n":"IsDefaultSharedMemoryPool","d":2094793,"h":111671244489,"f":8}],"l":[{"t":655361,"n":"DefaultBufferSize","d":2094793,"h":4297062089,"f":34},{"t":655361,"n":"DefaultMaxBufferSize","d":2094793,"h":8592029385,"f":40},{"t":655361,"n":"DefaultMinimumReadSize","d":2094793,"h":12886996681,"f":34},{"t":2094793,"n":"s_default","d":2094793,"h":17181963977,"f":40}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h},{"n":"bufferSize","p":655361},{"n":"minimumReadSize","p":655361},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$1","d":2094793,"h":21476931273,"f":1},{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"f":65},{"n":"bufferSize","p":655361,"f":65,"v":-1},{"n":"minimumReadSize","p":655361,"f":65,"v":-1},{"n":"leaveOpen","p":262145,"f":65,"v":false},{"n":"useZeroByteReads","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$2","d":2094793,"h":25771898569,"f":1}],"h":2094793}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeReaderOptions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateArgumentOutOfRangeException(argument);
            }
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                return new $.$spc.System.ArgumentOutOfRangeException().$ctor$16($.$spc.System.Enum.ToStringT($.$sipl.System.IO.Pipelines.ExceptionArgument, $.$spc.System.UInt32, argument));
            }
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateArgumentNullException(argument);
            }
            static /*ArgumentNullException */ CreateArgumentNullException(/*ExceptionArgument*/ argument)
            {
                return new $.$spc.System.ArgumentNullException().$ctor$16($.$spc.System.Enum.ToStringT($.$sipl.System.IO.Pipelines.ExceptionArgument, $.$spc.System.UInt32, argument));
            }
            static /*void */ ThrowInvalidOperationException_AlreadyReading()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_AlreadyReading();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_AlreadyReading()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ReadingIsInProgress);
            }
            static /*void */ ThrowInvalidOperationException_NoReadToComplete()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoReadToComplete();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoReadToComplete()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.NoReadingOperationToComplete);
            }
            static /*void */ ThrowInvalidOperationException_NoConcurrentOperation()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoConcurrentOperation()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ConcurrentOperationsNotSupported);
            }
            static /*void */ ThrowInvalidOperationException_GetResultNotCompleted()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_GetResultNotCompleted();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_GetResultNotCompleted()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.GetResultBeforeCompleted);
            }
            static /*void */ ThrowInvalidOperationException_NoWritingAllowed()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoWritingAllowed();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoWritingAllowed()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.WritingAfterCompleted);
            }
            static /*void */ ThrowInvalidOperationException_NoReadingAllowed()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoReadingAllowed();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoReadingAllowed()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ReadingAfterCompleted);
            }
            static /*void */ ThrowInvalidOperationException_InvalidExaminedPosition()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidExaminedPosition();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidExaminedPosition()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.InvalidExaminedPosition);
            }
            static /*void */ ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidExaminedOrConsumedPosition();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidExaminedOrConsumedPosition()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.InvalidExaminedOrConsumedPosition);
            }
            static /*void */ ThrowInvalidOperationException_AdvanceToInvalidCursor()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_AdvanceToInvalidCursor();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_AdvanceToInvalidCursor()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.AdvanceToInvalidCursor);
            }
            static /*void */ ThrowInvalidOperationException_ResetIncompleteReaderWriter()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_ResetIncompleteReaderWriter();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_ResetIncompleteReaderWriter()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ReaderAndWriterHasToBeCompleted);
            }
            static /*void */ ThrowOperationCanceledException_ReadCanceled()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateOperationCanceledException_ReadCanceled();
            }
            static /*OperationCanceledException */ CreateOperationCanceledException_ReadCanceled()
            {
                return new $.$spc.System.OperationCanceledException().$ctor$10($.$sipl.System.SR.ReadCanceledOnPipeReader);
            }
            static /*void */ ThrowOperationCanceledException_FlushCanceled()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateOperationCanceledException_FlushCanceled();
            }
            static /*OperationCanceledException */ CreateOperationCanceledException_FlushCanceled()
            {
                return new $.$spc.System.OperationCanceledException().$ctor$10($.$sipl.System.SR.FlushCanceledOnPipeWriter);
            }
            static /*void */ ThrowInvalidOperationException_InvalidZeroByteRead()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidZeroByteRead();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidZeroByteRead()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.InvalidZeroByteRead);
            }
            static /*void */ ThrowNotSupported_UnflushedBytes()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateNotSupportedException_UnflushedBytes();
            }
            static /*NotSupportedException */ CreateNotSupportedException_UnflushedBytes()
            {
                return new $.$spc.System.NotSupportedException().$ctor$10($.$sipl.System.SR.UnflushedBytesNotSupported);
            }
            static $h = 2356937;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":390857}],"n":"ThrowArgumentOutOfRangeException","d":2356937,"h":4297324233,"f":40},{"r":13500417,"p":[{"n":"argument","p":390857}],"n":"CreateArgumentOutOfRangeException","d":2356937,"h":8592291529,"f":34},{"r":65537,"p":[{"n":"argument","p":390857}],"n":"ThrowArgumentNullException","d":2356937,"h":12887258825,"f":40},{"r":13434881,"p":[{"n":"argument","p":390857}],"n":"CreateArgumentNullException","d":2356937,"h":17182226121,"f":34},{"r":65537,"n":"ThrowInvalidOperationException_AlreadyReading","d":2356937,"h":21477193417,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_AlreadyReading","d":2356937,"h":25772160713,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoReadToComplete","d":2356937,"h":30067128009,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_NoReadToComplete","d":2356937,"h":34362095305,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoConcurrentOperation","d":2356937,"h":38657062601,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_NoConcurrentOperation","d":2356937,"h":42952029897,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_GetResultNotCompleted","d":2356937,"h":47246997193,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_GetResultNotCompleted","d":2356937,"h":51541964489,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoWritingAllowed","d":2356937,"h":55836931785,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_NoWritingAllowed","d":2356937,"h":60131899081,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoReadingAllowed","d":2356937,"h":64426866377,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_NoReadingAllowed","d":2356937,"h":68721833673,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_InvalidExaminedPosition","d":2356937,"h":73016800969,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_InvalidExaminedPosition","d":2356937,"h":77311768265,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition","d":2356937,"h":81606735561,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_InvalidExaminedOrConsumedPosition","d":2356937,"h":85901702857,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_AdvanceToInvalidCursor","d":2356937,"h":90196670153,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_AdvanceToInvalidCursor","d":2356937,"h":94491637449,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_ResetIncompleteReaderWriter","d":2356937,"h":98786604745,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_ResetIncompleteReaderWriter","d":2356937,"h":103081572041,"f":33},{"r":65537,"n":"ThrowOperationCanceledException_ReadCanceled","d":2356937,"h":107376539337,"f":33},{"r":71106561,"n":"CreateOperationCanceledException_ReadCanceled","d":2356937,"h":111671506633,"f":33},{"r":65537,"n":"ThrowOperationCanceledException_FlushCanceled","d":2356937,"h":115966473929,"f":33},{"r":71106561,"n":"CreateOperationCanceledException_FlushCanceled","d":2356937,"h":120261441225,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_InvalidZeroByteRead","d":2356937,"h":124556408521,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_InvalidZeroByteRead","d":2356937,"h":128851375817,"f":33},{"r":65537,"n":"ThrowNotSupported_UnflushedBytes","d":2356937,"h":133146343113,"f":33},{"r":66781185,"n":"CreateNotSupportedException_UnflushedBytes","d":2356937,"h":137441310409,"f":33}],"h":2356937}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.ThrowHelper`; }
        });
        
        $asm.$cls("$sipl.System.IO.StreamHelpers", ($self) => class StreamHelpers
        {
            static /*void */ ValidateCopyToArgs(/*Stream*/ source, /*Stream*/ destination, /*int*/ bufferSize)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(destination, "destination");
                if (bufferSize <= 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("bufferSize", $.$box(bufferSize, $.$spc.System.Int32), $.$sipl.System.SR.ArgumentOutOfRange_NeedPosNum);
                }
                /*bool*/ let sourceCanRead = source.CanRead;
                if (!sourceCanRead && !source.CanWrite)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15(null, $.$sipl.System.SR.ObjectDisposed_StreamClosed);
                }
                /*bool*/ let destinationCanWrite = destination.CanWrite;
                if (!destinationCanWrite && !destination.CanRead)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15("destination", $.$sipl.System.SR.ObjectDisposed_StreamClosed);
                }
                if (!sourceCanRead)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sipl.System.SR.NotSupported_UnreadableStream);
                }
                if (!destinationCanWrite)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sipl.System.SR.NotSupported_UnwritableStream);
                }
            }
            static $h = 2422473;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"source","p":62128129},{"n":"destination","p":62128129},{"n":"bufferSize","p":655361}],"n":"ValidateCopyToArgs","d":2422473,"h":4297389769,"f":33}],"h":2422473}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.StreamHelpers`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeWriterOptions", ($self) => class StreamPipeWriterOptions extends $.$spc.System.Object
        {
            /*int*/ static DefaultMinimumBufferSize = 4096;
            /*StreamPipeWriterOptions*/ static s_default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*int*/ minimumBufferSize, /*bool*/ leaveOpen)
            {
                super.$ctor();
                {
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.MinimumBufferSize = minimumBufferSize === -1 ? 4096/*DefaultMinimumBufferSize*/ : minimumBufferSize <= 0 ? (() =>
                    {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("minimumBufferSize")            })() : minimumBufferSize;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*int*/ MinimumBufferSize = 0;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ LeaveOpen = false;
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_default = new $.$sipl.System.IO.Pipelines.StreamPipeWriterOptions().$ctor$1(null, -1, false);
                }
            }
            static $h = 2225865;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25772029641,"f":1},"n":"MinimumBufferSize","d":2225865,"h":21477062345,"f":1},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":38656931529,"f":1},"n":"Pool","d":2225865,"h":34361964233,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51541833417,"f":1},"n":"LeaveOpen","d":2225865,"h":47246866121,"f":1}],"l":[{"t":655361,"n":"DefaultMinimumBufferSize","d":2225865,"h":4297193161,"f":34},{"t":2225865,"n":"s_default","d":2225865,"h":8592160457,"f":40}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"f":65},{"n":"minimumBufferSize","p":655361,"f":65,"v":-1},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$1","d":2225865,"h":12887127753,"f":1}],"h":2225865}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeWriterOptions`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.FlushResult", ($self) => class FlushResult extends $.$spc.System.ValueType
        {
            /*ResultFlags*/  get _resultFlags() { return this.$getField(0, $.$sipl.System.IO.Pipelines.ResultFlags); }
            /*ResultFlags*/  set _resultFlags(value) { this.$setField(0, $.$sipl.System.IO.Pipelines.ResultFlags, value); }
            $ctor$2(/*bool*/ isCanceled, /*bool*/ isCompleted)
            {
                super.$ctor$1();
                {
                    this._resultFlags = 0/*ResultFlags.None*/;
                    if (isCanceled)
                    {
                        this._resultFlags |= 1/*ResultFlags.Canceled*/;
                    }
                    if (isCompleted)
                    {
                        this._resultFlags |= 2/*ResultFlags.Completed*/;
                    }
                }
                return this;
            }
            /*bool */ get IsCanceled()
            {
                return (this._resultFlags & 1/*ResultFlags.Canceled*/) !== 0;
            }
            /*bool */ get IsCompleted()
            {
                return (this._resultFlags & 2/*ResultFlags.Completed*/) !== 0;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resultFlags = this._resultFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resultFlags = 0;
            }
            static $h = 456393;
            static $z = 1;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180325577,"f":1},"n":"IsCanceled","d":456393,"h":12885358281,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770260169,"f":1},"n":"IsCompleted","d":456393,"h":21475292873,"f":1}],"l":[{"t":1832649,"n":"_resultFlags","d":456393,"h":4295423689,"f":8}],"c":[{"p":[{"n":"isCanceled","p":262145},{"n":"isCompleted","p":262145}],"n":".ctor","o":"$ctor$2","d":456393,"h":8590390985,"f":1},{"n":".ctor","o":"$ctor$3","d":456393,"h":30065227465,"f":1}],"h":456393}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.FlushResult`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.InlineScheduler", ($self) => class InlineScheduler extends $.$sipl.System.IO.Pipelines.PipeScheduler
        {
            /*void */ Schedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                action.Invoke(state);
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                action.Invoke(state);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 587465;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1570505,"m":[{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":587465,"h":4295554761,"f":32769},{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":587465,"h":8590522057,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":587465,"h":12885489353,"f":1}],"h":587465}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeScheduler; }
            static get $fullName() { return `System.IO.Pipelines.InlineScheduler`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.BufferSegmentStack", ($self) => class BufferSegmentStack extends $.$spc.System.ValueType
        {
            /*SegmentAsValueType[]*/  get _array() { return this.$getField(0, 4); }
            /*SegmentAsValueType[]*/  set _array(value) { this.$setField(0, 4, value); }
            /*int*/  get _size() { return this.$getField(4, 4); }
            /*int*/  set _size(value) { this.$setField(4, 4, value); }
            $ctor$2(/*int*/ size)
            {
                super.$ctor$1();
                {
                    this._array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType), null, [size], null);
                    this._size = 0;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._size;
            }
            /*bool */ TryPop(/*out BufferSegment?*/ result)
            {
                /*int*/ let size = ((this._size - 1) | 0);
                /*SegmentAsValueType[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    result.$v = null;
                    return false;
                }
                this._size = size;
                result.$v = $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit$1($.$spc.System.Array.$ReadT1.call(array, size));
                $.$spc.System.Array.$WriteT1.call(array, new $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType(), size);
                return true;
            }
            /*void */ Push(/*BufferSegment*/ item)
            {
                /*int*/ let size = this._size;
                /*SegmentAsValueType[]*/ let array = this._array;
                if ((size >>> 0) < (array.length >>> 0))
                {
                    $.$spc.System.Array.$WriteT1.call(array, $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit(item), size);
                    this._size = ((size + 1) | 0);
                }
                else 
                {
                    this.PushWithResize(item);
                }
            }
            /*void */ PushWithResize(/*BufferSegment*/ item)
            {
                $.$spc.System.Array.Resize($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType, $.$ref(() => this._array, ($v) => this._array = $v, $.$typeArray($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType)), ((2 * this._array.length) | 0));
                $.$spc.System.Array.$WriteT1.call(this._array, $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit(item), this._size);
                this._size++;
            }
            static $_SegmentAsValueType;
            static get SegmentAsValueType()
            {
                let $cls = $.$sipl.System.IO.Pipelines.BufferSegmentStack;
                return $cls.$_SegmentAsValueType ??= $asm.$nstr("$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType", ($self) => class SegmentAsValueType extends $.$spc.System.ValueType
                {
                    /*BufferSegment*/  get _value() { return this.$getField(0, 4); }
                    /*BufferSegment*/  set _value(value) { this.$setField(0, 4, value); }
                    $ctor$2(/*BufferSegment*/ value)
                    {
                        super.$ctor$1();
                        this._value = value;
                        return this;
                    }
                    static /*SegmentAsValueType */ op_Implicit(/*BufferSegment*/ s)
                    {
                        return new $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType().$ctor$2(s);
                    }
                    static /*BufferSegment */ op_Implicit$1(/*SegmentAsValueType*/ s)
                    {
                        return s._value;
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._value = this._value;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._value = null;
                    }
                    static $h = 259785;
                    static $z = 4;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":128713,"n":"_value","d":259785,"h":4295227081,"f":2}],"c":[{"p":[{"n":"value","p":128713}],"n":".ctor","o":"$ctor$2","d":259785,"h":8590194377,"f":2},{"n":".ctor","o":"$ctor$3","d":259785,"h":21475096265,"f":1}],"d":194249,"h":259785}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType`; }
                }, $cls, ($v) => $cls.$_SegmentAsValueType = $v);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._array = this._array;
                copy._size = this._size;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._array = null;
                this._size = 0;
            }
            static $h = 194249;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21475030729,"f":1},"n":"Count","d":194249,"h":17180063433,"f":1}],"m":[{"r":262145,"p":[{"n":"result","p":128713,"f":2}],"n":"TryPop","d":194249,"h":25769998025,"f":1},{"r":65537,"p":[{"n":"item","p":128713}],"n":"Push","d":194249,"h":30064965321,"f":1},{"r":65537,"p":[{"n":"item","p":128713}],"n":"PushWithResize","d":194249,"h":34359932617,"f":2}],"l":[{"t":0,"n":"_array","d":194249,"h":4295161545,"f":2},{"t":655361,"n":"_size","d":194249,"h":8590128841,"f":2}],"c":[{"p":[{"n":"size","p":655361}],"n":".ctor","o":"$ctor$2","d":194249,"h":12885096137,"f":1},{"n":".ctor","o":"$ctor$3","d":194249,"h":42949867209,"f":1}],"j":[259785],"h":194249}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.BufferSegmentStack`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeAwaitable", ($self) => class PipeAwaitable extends $.$spc.System.ValueType
        {
            /*AwaitableState*/  get _awaitableState() { return this.$getField(0, 4); }
            /*AwaitableState*/  set _awaitableState(value) { this.$setField(0, 4, value); }
            /*Action<object?>?*/  get _completion() { return this.$getField(4, 4); }
            /*Action<object?>?*/  set _completion(value) { this.$setField(4, 4, value); }
            /*object?*/  get _completionState() { return this.$getField(8, 4); }
            /*object?*/  set _completionState(value) { this.$setField(8, 4, value); }
            /*SchedulingContext?*/  get _schedulingContext() { return this.$getField(12, 4); }
            /*SchedulingContext?*/  set _schedulingContext(value) { this.$setField(12, 4, value); }
            /*CancellationTokenRegistration*/  get _cancellationTokenRegistration() { return this.$getField(16, 12); }
            /*CancellationTokenRegistration*/  set _cancellationTokenRegistration(value) { this.$setField(16, 12, value); }
            /*CancellationToken */ get CancellationToken()
            {
                return this._cancellationTokenRegistration.Token;
            }
            $ctor$2(/*bool*/ completed, /*bool*/ useSynchronizationContext)
            {
                super.$ctor$1();
                {
                    this._awaitableState = (completed ? 1/*AwaitableState.Completed*/ : 0/*AwaitableState.None*/) | (useSynchronizationContext ? 8/*AwaitableState.UseSynchronizationContext*/ : 0/*AwaitableState.None*/);
                    this._completion = null;
                    this._completionState = null;
                    this._cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                    this._schedulingContext = null;
                }
                return this;
            }
            /*bool */ get IsCompleted()
            {
                return (this._awaitableState & (1/*AwaitableState.Completed*/ | 4/*AwaitableState.Canceled*/)) !== 0;
            }
            /*bool */ get IsRunning()
            {
                return (this._awaitableState & 2/*AwaitableState.Running*/) !== 0;
            }
            /*void */ BeginOperation(/*CancellationToken*/ cancellationToken, /*Action<object?>*/ callback, /*object?*/ state)
            {
                if (cancellationToken.CanBeCanceled && !this.IsCompleted)
                {
                    /*var*/ let previousAwaitableState = this._awaitableState;
                    this._cancellationTokenRegistration = cancellationToken.UnsafeRegister(callback, state);
                    if ($.$spc.System.Threading.CancellationTokenRegistration.op_Equality(this._cancellationTokenRegistration, $.$default($.$spc.System.Threading.CancellationTokenRegistration)))
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(previousAwaitableState === this._awaitableState, "The awaitable state changed!");
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                }
                this._awaitableState |= 2/*AwaitableState.Running*/;
            }
            /*void */ Complete(/*out CompletionData*/ completionData)
            {
                this.ExtractCompletion(completionData);
                this._awaitableState |= 1/*AwaitableState.Completed*/;
            }
            /*void */ ExtractCompletion(/*out CompletionData*/ completionData)
            {
                /*Action<object?>?*/ let currentCompletion = this._completion;
                /*object?*/ let currentState = this._completionState;
                /*SchedulingContext?*/ let schedulingContext = this._schedulingContext;
                /*ExecutionContext?*/ let executionContext = (schedulingContext?.ExecutionContext ?? null);
                /*SynchronizationContext?*/ let synchronizationContext = (schedulingContext?.SynchronizationContext ?? null);
                this._completion = null;
                this._completionState = null;
                this._schedulingContext = null;
                completionData.$v = currentCompletion !== null ? new $.$sipl.System.IO.Pipelines.CompletionData().$ctor$2(currentCompletion, currentState, executionContext, synchronizationContext) : new $.$sipl.System.IO.Pipelines.CompletionData();
            }
            /*void */ SetUncompleted()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._completion === null, "_completion == null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._completionState === null, "_completionState == null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._schedulingContext === null, "_schedulingContext == null");
                this._awaitableState &= ~1/*AwaitableState.Completed*/;
            }
            /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags, /*out CompletionData*/ completionData, /*out bool*/ doubleCompletion)
            {
                completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                doubleCompletion.$v = !(this._completion === null);
                if (this.IsCompleted || doubleCompletion.$v)
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData().$ctor$2(continuation, state, (this._schedulingContext?.ExecutionContext ?? null), (this._schedulingContext?.SynchronizationContext ?? null));
                    return;
                }
                this._completion = continuation;
                this._completionState = state;
                if ((this._awaitableState & 8/*AwaitableState.UseSynchronizationContext*/) !== 0 && (flags & 1/*ValueTaskSourceOnCompletedFlags.UseSchedulingContext*/) !== 0)
                {
                    /*SynchronizationContext?*/ let sc = $.$spc.System.Threading.SynchronizationContext.Current;
                    if (sc !== null && $.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(sc), $.$spc.System.Threading.SynchronizationContext.$type))
                    {
                        this._schedulingContext ??= new $.$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext().$ctor$1();
                        this._schedulingContext.SynchronizationContext = sc;
                    }
                }
                if ((flags & 2/*ValueTaskSourceOnCompletedFlags.FlowExecutionContext*/) !== 0)
                {
                    this._schedulingContext ??= new $.$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext().$ctor$1();
                    this._schedulingContext.ExecutionContext = $.$spc.System.Threading.ExecutionContext.Capture();
                }
            }
            /*void */ Cancel(/*out CompletionData*/ completionData)
            {
                this.ExtractCompletion(completionData);
                this._awaitableState |= 4/*AwaitableState.Canceled*/;
            }
            /*void */ CancellationTokenFired(/*out CompletionData*/ completionData)
            {
                if (this.CancellationToken.IsCancellationRequested)
                {
                    this.Cancel(completionData);
                }
                else 
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                }
            }
            /*bool */ ObserveCancellation()
            {
                /*bool*/ let isCanceled = (this._awaitableState & 4/*AwaitableState.Canceled*/) === 4/*AwaitableState.Canceled*/;
                this._awaitableState &= ~(4/*AwaitableState.Canceled*/ | 2/*AwaitableState.Running*/);
                return isCanceled;
            }
            /*CancellationTokenRegistration */ ReleaseCancellationTokenRegistration(/*out CancellationToken*/ cancellationToken)
            {
                cancellationToken.$v = this.CancellationToken;
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = this._cancellationTokenRegistration;
                this._cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                return cancellationTokenRegistration;
            }
            static $_AwaitableState;
            static get AwaitableState()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeAwaitable;
                return $cls.$_AwaitableState ??= $asm.$nstr("$sipl.System.IO.Pipelines.PipeAwaitable.AwaitableState", ($self) => class AwaitableState extends $.$spc.System.Enum
                {
                    static None = 0;
                    static Completed = 1;
                    static Running = 2;
                    static Canceled = 4;
                    static UseSynchronizationContext = 8;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "Completed": 1n,
                            "Running": 2n,
                            "Canceled": 4n,
                            "UseSynchronizationContext": 8n
                        };
                    }
                    static $h = 915145;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":915145,"n":"None","d":915145,"h":4295882441,"f":33},{"t":915145,"n":"Completed","d":915145,"h":8590849737,"f":33},{"t":915145,"n":"Running","d":915145,"h":12885817033,"f":33},{"t":915145,"n":"Canceled","d":915145,"h":17180784329,"f":33},{"t":915145,"n":"UseSynchronizationContext","d":915145,"h":21475751625,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":915145,"h":25770718921,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":849609,"h":915145,"a":[{"t":47644673,"c":4342611969}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Pipelines.PipeAwaitable.AwaitableState`; }
                }, $cls, ($v) => $cls.$_AwaitableState = $v);
            }
            static $_SchedulingContext;
            static get SchedulingContext()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeAwaitable;
                return $cls.$_SchedulingContext ??= $asm.$ncls("$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext", ($self) => class SchedulingContext extends $.$spc.System.Object
                {
                    /*SynchronizationContext?*/ SynchronizationContext = null;
                    /*ExecutionContext?*/ ExecutionContext = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 980681;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131137537,"g":{"r":0,"d":0,"h":12885882569,"f":1},"s":{"r":0,"d":0,"h":17180849865,"f":1},"n":"SynchronizationContext","d":980681,"h":8590915273,"f":1},{"p":126943233,"g":{"r":0,"d":0,"h":30065751753,"f":1},"s":{"r":0,"d":0,"h":34360719049,"f":1},"n":"ExecutionContext","d":980681,"h":25770784457,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":980681,"h":38655686345,"f":1}],"d":849609,"h":980681}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Pipelines.PipeAwaitable.SchedulingContext`; }
                }, $cls, ($v) => $cls.$_SchedulingContext = $v);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._awaitableState = this._awaitableState;
                copy._completion = this._completion;
                copy._completionState = this._completionState;
                copy._schedulingContext = this._schedulingContext;
                copy._cancellationTokenRegistration = this._cancellationTokenRegistration.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._awaitableState = 0;
                this._completion = null;
                this._completionState = null;
                this._schedulingContext = null;
                this._cancellationTokenRegistration = $.$default($.$spc.System.Threading.CancellationTokenRegistration);
            }
            static $h = 849609;
            static $z = 28;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":125960193,"g":{"r":0,"d":0,"h":30065620681,"f":2},"n":"CancellationToken","d":849609,"h":25770653385,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":42950522569,"f":1},"n":"IsCompleted","d":849609,"h":38655555273,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540457161,"f":1},"n":"IsRunning","d":849609,"h":47245489865,"f":1}],"m":[{"r":65537,"p":[{"n":"cancellationToken","p":125960193},{"n":"callback","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"BeginOperation","d":849609,"h":55835424457,"f":1},{"r":65537,"p":[{"n":"completionData","p":325321,"f":2}],"n":"Complete","d":849609,"h":60130391753,"f":1},{"r":65537,"p":[{"n":"completionData","p":325321,"f":2}],"n":"ExtractCompletion","d":849609,"h":64425359049,"f":2},{"r":65537,"n":"SetUncompleted","d":849609,"h":68720326345,"f":1},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132972545},{"n":"completionData","p":325321,"f":2},{"n":"doubleCompletion","p":262145,"f":2}],"n":"OnCompleted","d":849609,"h":73015293641,"f":1},{"r":65537,"p":[{"n":"completionData","p":325321,"f":2}],"n":"Cancel","d":849609,"h":77310260937,"f":1},{"r":65537,"p":[{"n":"completionData","p":325321,"f":2}],"n":"CancellationTokenFired","d":849609,"h":81605228233,"f":1},{"r":262145,"n":"ObserveCancellation","d":849609,"h":85900195529,"f":1},{"r":126025729,"p":[{"n":"cancellationToken","p":125960193,"f":2}],"n":"ReleaseCancellationTokenRegistration","d":849609,"h":90195162825,"f":1}],"l":[{"t":915145,"n":"_awaitableState","d":849609,"h":4295816905,"f":2},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"_completion","d":849609,"h":8590784201,"f":2},{"t":131073,"n":"_completionState","d":849609,"h":12885751497,"f":2},{"t":980681,"n":"_schedulingContext","d":849609,"h":17180718793,"f":2},{"t":126025729,"n":"_cancellationTokenRegistration","d":849609,"h":21475686089,"f":2}],"c":[{"p":[{"n":"completed","p":262145},{"n":"useSynchronizationContext","p":262145}],"n":".ctor","o":"$ctor$2","d":849609,"h":34360587977,"f":1},{"n":".ctor","o":"$ctor$3","d":849609,"h":103080064713,"f":1}],"j":[915145,980681],"h":849609,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"CanceledState = {_awaitableState}, IsCompleted = {IsCompleted}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeAwaitable`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeCompletion", ($self) => class PipeCompletion extends $.$spc.System.ValueType
        {
            /*object*/ static s_completedSuccessfully = null;
            /*object?*/  get _state() { return this.$getField(0, 4); }
            /*object?*/  set _state(value) { this.$setField(0, 4, value); }
            /*List<PipeCompletionCallback>?*/  get _callbacks() { return this.$getField(4, 4); }
            /*List<PipeCompletionCallback>?*/  set _callbacks(value) { this.$setField(4, 4, value); }
            /*bool */ get IsCompleted()
            {
                return this._state !== null;
            }
            /*bool */ get IsFaulted()
            {
                return $.$is(this._state, $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo);
            }
            /*PipeCompletionCallbacks? */ TryComplete(/*Exception?*/ exception)
            {
                if (this._state === null)
                {
                    if (exception !== null)
                    {
                        this._state = $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exception);
                    }
                    else 
                    {
                        this._state = $.$sipl.System.IO.Pipelines.PipeCompletion.s_completedSuccessfully;
                    }
                }
                return this.GetCallbacks();
            }
            /*PipeCompletionCallbacks? */ AddCallback(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                this._callbacks ??= new ($.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback))().$ctor$1();
                this._callbacks.Add(new $.$sipl.System.IO.Pipelines.PipeCompletionCallback().$ctor$2(callback, state));
                if (this.IsCompleted)
                {
                    return this.GetCallbacks();
                }
                return null;
            }
            /*bool */ IsCompletedOrThrow()
            {
                if (!this.IsCompleted)
                {
                    return false;
                }
                let edi;
                if ($.$is(this._state, $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo, { set $v(v){ edi = v; } }))
                {
                    edi.Throw();
                }
                return true;
            }
            /*PipeCompletionCallbacks? */ GetCallbacks()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsCompleted, "IsCompleted");
                /*var*/ let callbacks = this._callbacks;
                if (callbacks === null)
                {
                    return null;
                }
                this._callbacks = null;
                return new $.$sipl.System.IO.Pipelines.PipeCompletionCallbacks().$ctor$1(callbacks, $.$as(this._state, $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo));
            }
            /*void */ Reset()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsCompleted, "IsCompleted");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._callbacks === null, "_callbacks == null");
                this._state = null;
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `${"IsCompleted"}: ${this.IsCompleted}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sipl.System.IO.Pipelines.PipeCompletion.ToString.apply(this, arguments); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._state = this._state;
                copy._callbacks = this._callbacks;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = null;
                this._callbacks = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_completedSuccessfully = new $.$spc.System.Object().$ctor();
                }
            }
            static $h = 1046217;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475882697,"f":1},"n":"IsCompleted","d":1046217,"h":17180915401,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065817289,"f":1},"n":"IsFaulted","d":1046217,"h":25770849993,"f":1}],"m":[{"r":1177289,"p":[{"n":"exception","p":47185921,"f":65}],"n":"TryComplete","d":1046217,"h":34360784585,"f":1},{"r":1177289,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"AddCallback","d":1046217,"h":38655751881,"f":1},{"r":262145,"n":"IsCompletedOrThrow","d":1046217,"h":42950719177,"f":1},{"r":1177289,"n":"GetCallbacks","d":1046217,"h":47245686473,"f":2},{"r":65537,"n":"Reset","d":1046217,"h":51540653769,"f":1},{"r":1310721,"n":"ToString","d":1046217,"h":55835621065,"f":32769}],"l":[{"t":131073,"n":"s_completedSuccessfully","d":1046217,"h":4296013513,"f":34},{"t":131073,"n":"_state","d":1046217,"h":8590980809,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h,"n":"_callbacks","d":1046217,"h":12885948105,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1046217,"h":60130588361,"f":1}],"h":1046217,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"IsCompleted = {IsCompleted}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletion`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeCompletionCallback", ($self) => class PipeCompletionCallback extends $.$spc.System.ValueType
        {
            /*Action<Exception?, object?>*/  get Callback() { return this.$getField(0, 4); }
            /*Action<Exception?, object?>*/  set Callback(value) { this.$setField(0, 4, value); }
            /*object?*/  get State() { return this.$getField(4, 4); }
            /*object?*/  set State(value) { this.$setField(4, 4, value); }
            $ctor$2(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                super.$ctor$1();
                {
                    this.Callback = callback;
                    this.State = state;
                }
                return this;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Callback = this.Callback;
                copy.State = this.State;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Callback = null;
                this.State = null;
            }
            static $h = 1111753;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h,"n":"Callback","d":1111753,"h":4296079049,"f":1},{"t":131073,"n":"State","d":1111753,"h":8591046345,"f":1}],"c":[{"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":".ctor","o":"$ctor$2","d":1111753,"h":12886013641,"f":1},{"n":".ctor","o":"$ctor$3","d":1111753,"h":17180980937,"f":1}],"h":1111753}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletionCallback`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.CompletionData", ($self) => class CompletionData extends $.$spc.System.ValueType
        {
            /*Action<object?>*/ Completion = null;
            /*object?*/ CompletionState = null;
            /*ExecutionContext?*/ ExecutionContext = null;
            /*SynchronizationContext?*/ SynchronizationContext = null;
            $ctor$2(/*Action<object?>*/ completion, /*object?*/ completionState, /*ExecutionContext?*/ executionContext, /*SynchronizationContext?*/ synchronizationContext)
            {
                super.$ctor$1();
                {
                    this.Completion = completion;
                    this.CompletionState = completionState;
                    this.ExecutionContext = executionContext;
                    this.SynchronizationContext = synchronizationContext;
                }
                return this;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Completion = this.Completion;
                copy.CompletionState = this.CompletionState;
                copy.ExecutionContext = this.ExecutionContext;
                copy.SynchronizationContext = this.SynchronizationContext;
                return copy;
            }
            static $h = 325321;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.Action$$($.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":12885227209,"f":1},"n":"Completion","d":325321,"h":8590259913,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":25770129097,"f":1},"n":"CompletionState","d":325321,"h":21475161801,"f":1},{"p":126943233,"g":{"r":0,"d":0,"h":38655030985,"f":1},"n":"ExecutionContext","d":325321,"h":34360063689,"f":1},{"p":131137537,"g":{"r":0,"d":0,"h":51539932873,"f":1},"n":"SynchronizationContext","d":325321,"h":47244965577,"f":1}],"c":[{"p":[{"n":"completion","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"completionState","p":131073},{"n":"executionContext","p":126943233},{"n":"synchronizationContext","p":131137537}],"n":".ctor","o":"$ctor$2","d":325321,"h":55834900169,"f":1},{"n":".ctor","o":"$ctor$3","d":325321,"h":60129867465,"f":1}],"h":325321}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.CompletionData`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeOperationState", ($self) => class PipeOperationState extends $.$spc.System.ValueType
        {
            /*State*/  get _state() { return this.$getField(0, $.$sipl.System.IO.Pipelines.PipeOperationState.State); }
            /*State*/  set _state(value) { this.$setField(0, $.$sipl.System.IO.Pipelines.PipeOperationState.State, value); }
            /*void */ BeginRead()
            {
                if ((this._state & 1/*State.Reading*/) === 1/*State.Reading*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                }
                this._state |= 1/*State.Reading*/;
            }
            /*void */ BeginReadTentative()
            {
                if ((this._state & 1/*State.Reading*/) === 1/*State.Reading*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                }
                this._state |= 2/*State.ReadingTentative*/;
            }
            /*void */ EndRead()
            {
                if ((this._state & 1/*State.Reading*/) !== 1/*State.Reading*/ && (this._state & 2/*State.ReadingTentative*/) !== 2/*State.ReadingTentative*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadToComplete();
                }
                this._state &= ~(1/*State.Reading*/ | 2/*State.ReadingTentative*/);
            }
            /*void */ BeginWrite()
            {
                this._state |= 4/*State.Writing*/;
            }
            /*void */ EndWrite()
            {
                this._state &= ~4/*State.Writing*/;
            }
            /*bool */ get IsWritingActive()
            {
                return (this._state & 4/*State.Writing*/) === 4/*State.Writing*/;
            }
            /*bool */ get IsReadingActive()
            {
                return (this._state & 1/*State.Reading*/) === 1/*State.Reading*/;
            }
            static $_State;
            static get State()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeOperationState;
                return $cls.$_State ??= $asm.$nstr("$sipl.System.IO.Pipelines.PipeOperationState.State", ($self) => class State extends $.$spc.System.Enum
                {
                    static Reading = 1;
                    static ReadingTentative = 2;
                    static Writing = 4;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Reading": 1n,
                            "ReadingTentative": 2n,
                            "Writing": 4n
                        };
                    }
                    static $h = 1308361;
                    static $z = 1;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Byte; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":1308361,"n":"Reading","d":1308361,"h":4296275657,"f":33},{"t":1308361,"n":"ReadingTentative","d":1308361,"h":8591242953,"f":33},{"t":1308361,"n":"Writing","d":1308361,"h":12886210249,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1308361,"h":17181177545,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":1242825,"h":1308361,"a":[{"t":47644673,"c":4342611969}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Pipelines.PipeOperationState.State`; }
                }, $cls, ($v) => $cls.$_State = $v);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._state = this._state;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = 0;
            }
            static $h = 1242825;
            static $z = 1;
            static $f = 0b10000000000001010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360981193,"f":1},"n":"IsWritingActive","d":1242825,"h":30066013897,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950915785,"f":1},"n":"IsReadingActive","d":1242825,"h":38655948489,"f":1}],"m":[{"r":65537,"n":"BeginRead","d":1242825,"h":8591177417,"f":1},{"r":65537,"n":"BeginReadTentative","d":1242825,"h":12886144713,"f":1},{"r":65537,"n":"EndRead","d":1242825,"h":17181112009,"f":1},{"r":65537,"n":"BeginWrite","d":1242825,"h":21476079305,"f":1},{"r":65537,"n":"EndWrite","d":1242825,"h":25771046601,"f":1}],"l":[{"t":1308361,"n":"_state","d":1242825,"h":4296210121,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1242825,"h":51540850377,"f":1}],"j":[1308361],"h":1242825,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"State = {_state}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeOperationState`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ReadResult", ($self) => class ReadResult extends $.$spc.System.ValueType
        {
            /*ReadOnlySequence<byte>*/  get _resultBuffer() { return this.$getField(0, 16); }
            /*ReadOnlySequence<byte>*/  set _resultBuffer(value) { this.$setField(0, 16, value); }
            /*ResultFlags*/  get _resultFlags() { return this.$getField(16, 1); }
            /*ResultFlags*/  set _resultFlags(value) { this.$setField(16, 1, value); }
            $ctor$2(/*ReadOnlySequence<byte>*/ buffer, /*bool*/ isCanceled, /*bool*/ isCompleted)
            {
                super.$ctor$1();
                {
                    this._resultBuffer = buffer;
                    this._resultFlags = 0/*ResultFlags.None*/;
                    if (isCompleted)
                    {
                        this._resultFlags |= 2/*ResultFlags.Completed*/;
                    }
                    if (isCanceled)
                    {
                        this._resultFlags |= 1/*ResultFlags.Canceled*/;
                    }
                }
                return this;
            }
            /*ReadOnlySequence<byte> */ get Buffer()
            {
                return this._resultBuffer;
            }
            /*bool */ get IsCanceled()
            {
                return (this._resultFlags & 1/*ResultFlags.Canceled*/) !== 0;
            }
            /*bool */ get IsCompleted()
            {
                return (this._resultFlags & 2/*ResultFlags.Completed*/) !== 0;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resultBuffer = this._resultBuffer.Clone();
                copy._resultFlags = this._resultFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resultBuffer = $.$default($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte));
                this._resultFlags = 0;
            }
            static $h = 1767113;
            static $z = 17;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":21476603593,"f":1},"n":"Buffer","d":1767113,"h":17181636297,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30066538185,"f":1},"n":"IsCanceled","d":1767113,"h":25771570889,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38656472777,"f":1},"n":"IsCompleted","d":1767113,"h":34361505481,"f":1}],"l":[{"t":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"n":"_resultBuffer","d":1767113,"h":4296734409,"f":8},{"t":1832649,"n":"_resultFlags","d":1767113,"h":8591701705,"f":8}],"c":[{"p":[{"n":"buffer","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h},{"n":"isCanceled","p":262145},{"n":"isCompleted","p":262145}],"n":".ctor","o":"$ctor$2","d":1767113,"h":12886669001,"f":1},{"n":".ctor","o":"$ctor$3","d":1767113,"h":42951440073,"f":1}],"h":1767113}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.ReadResult`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.SequencePipeReader", ($self) => class SequencePipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
        {
            /*ReadOnlySequence<byte>*/ _sequence;
            /*bool*/ _isReaderCompleted = false;
            /*int*/ _cancelNext = 0;
            $ctor$2(/*ReadOnlySequence<byte>*/ sequence)
            {
                super.$ctor$1();
                {
                    this._sequence = sequence;
                }
                return this;
            }
            /*void */ AdvanceTo(/*SequencePosition*/ consumed)
            {
                this.AdvanceTo$1(consumed, consumed);
            }
            /*void */ AdvanceTo$1(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
            {
                this.ThrowIfCompleted();
                if (consumed.Equals$2(this._sequence.End))
                {
                    this._sequence = $.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).Empty;
                    return;
                }
                this._sequence = this._sequence.Slice$7(consumed);
            }
            /*void */ CancelPendingRead()
            {
                $.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._cancelNext, ($v) => this._cancelNext = $v, $.$spc.System.Int32), 1);
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this._isReaderCompleted)
                {
                    return;
                }
                this._isReaderCompleted = true;
                this._sequence = $.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).Empty;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                /*ReadResult*/ let result;
                if (this.TryRead($.$ref(() => result, ($v) => result = $v, $.$sipl.System.IO.Pipelines.ReadResult)))
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(result);
                }
                result = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).Empty, false, true);
                return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(result);
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                this.ThrowIfCompleted();
                /*bool*/ let isCancellationRequested = $.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._cancelNext, ($v) => this._cancelNext = $v, $.$spc.System.Int32), 0) === 1;
                if (isCancellationRequested || this._sequence.Length > 0n)
                {
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(this._sequence, isCancellationRequested, true);
                    return true;
                }
                result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                return false;
            }
            /*void */ ThrowIfCompleted()
            {
                if (this._isReaderCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._sequence = $.$default($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte));
            }
            static $h = 1898185;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1439433,"m":[{"r":65537,"p":[{"n":"consumed","p":1218810}],"n":"AdvanceTo","d":1898185,"h":21476734665,"f":32769},{"r":65537,"p":[{"n":"consumed","p":1218810},{"n":"examined","p":1218810}],"n":"AdvanceTo","o":"@$1","d":1898185,"h":25771701961,"f":32769},{"r":65537,"n":"CancelPendingRead","d":1898185,"h":30066669257,"f":32769},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":1898185,"h":34361636553,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":1898185,"h":38656603849,"f":32769},{"r":262145,"p":[{"n":"result","p":1767113,"f":2}],"n":"TryRead","d":1898185,"h":42951571145,"f":32769},{"r":65537,"n":"ThrowIfCompleted","d":1898185,"h":47246538441,"f":2}],"l":[{"t":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"n":"_sequence","d":1898185,"h":4296865481,"f":2},{"t":262145,"n":"_isReaderCompleted","d":1898185,"h":8591832777,"f":2},{"t":655361,"n":"_cancelNext","d":1898185,"h":12886800073,"f":2}],"c":[{"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h}],"n":".ctor","o":"$ctor$2","d":1898185,"h":17181767369,"f":1}],"h":1898185}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
            static get $fullName() { return `System.IO.Pipelines.SequencePipeReader`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeReader", ($self) => class StreamPipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
        {
            /*int*/ static InitialSegmentPoolSize = 4;
            /*int*/ static MaxSegmentPoolSize = 256;
            /*CancellationTokenSource?*/ _internalTokenSource = null;
            /*bool*/ _isReaderCompleted = false;
            /*BufferSegment?*/ _readHead = null;
            /*int*/ _readIndex = 0;
            /*BufferSegment?*/ _readTail = null;
            /*long*/ _bufferedBytes = 0n;
            /*bool*/ _examinedEverything = false;
            /*object*/ _lock = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*StreamPipeReaderOptions*/ _options = null;
            $ctor$2(/*Stream*/ readingStream, /*StreamPipeReaderOptions*/ options)
            {
                super.$ctor$1();
                {
                    if (readingStream === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(10/*ExceptionArgument.readingStream*/);
                    }
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this.InnerStream = readingStream;
                    this._options = options;
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$2(4/*InitialSegmentPoolSize*/);
                }
                return this;
            }
            /*bool */ get LeaveOpen()
            {
                return this._options.LeaveOpen;
            }
            /*bool */ get UseZeroByteReads()
            {
                return this._options.UseZeroByteReads;
            }
            /*int */ get BufferSize()
            {
                return this._options.BufferSize;
            }
            /*int */ get MaxBufferSize()
            {
                return this._options.MaxBufferSize;
            }
            /*int */ get MinimumReadThreshold()
            {
                return this._options.MinimumReadSize;
            }
            /*MemoryPool<byte> */ get Pool()
            {
                return this._options.Pool;
            }
            /*Stream*/ InnerStream = null;
            /*void */ AdvanceTo(/*SequencePosition*/ consumed)
            {
                this.AdvanceTo$1(consumed, consumed);
            }
            /*CancellationTokenSource */ get InternalTokenSource()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        return this._internalTokenSource ??= new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
            }
            /*void */ AdvanceTo$1(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
            {
                this.ThrowIfCompleted();
                this.AdvanceTo$2($.$cast(consumed.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), consumed.GetInteger(), $.$cast(examined.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), examined.GetInteger());
            }
            /*void */ AdvanceTo$2(/*BufferSegment?*/ consumedSegment, /*int*/ consumedIndex, /*BufferSegment?*/ examinedSegment, /*int*/ examinedIndex)
            {
                if (consumedSegment === null || examinedSegment === null)
                {
                    return;
                }
                if (this._readHead === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AdvanceToInvalidCursor();
                }
                /*BufferSegment*/ let returnStart = this._readHead;
                /*BufferSegment?*/ let returnEnd = consumedSegment;
                /*long*/ let consumedBytes = $.$sipl.System.IO.Pipelines.BufferSegment.GetLength(returnStart, this._readIndex, consumedSegment, consumedIndex);
                this._bufferedBytes -= consumedBytes;
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bufferedBytes >= 0n, "_bufferedBytes >= 0");
                this._examinedEverything = false;
                if (examinedSegment === this._readTail)
                {
                    this._examinedEverything = examinedIndex === this._readTail.End;
                }
                if (this._bufferedBytes === 0n)
                {
                    returnEnd = null;
                    this._readHead = null;
                    this._readTail = null;
                    this._readIndex = 0;
                }
                else if (consumedIndex === returnEnd.Length)
                {
                    /*BufferSegment?*/ let nextBlock = returnEnd.NextSegment;
                    this._readHead = nextBlock;
                    this._readIndex = 0;
                    returnEnd = nextBlock;
                }
                else 
                {
                    this._readHead = consumedSegment;
                    this._readIndex = consumedIndex;
                }
                while(returnStart !== returnEnd)
                {
                    /*BufferSegment*/ let next = returnStart.NextSegment;
                    this.ReturnSegmentUnsynchronized(returnStart);
                    returnStart = next;
                }
            }
            /*void */ CancelPendingRead()
            {
                this.InternalTokenSource.Cancel();
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this.CompleteAndGetNeedsDispose())
                {
                    this.InnerStream.Dispose();
                }
            }
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                return this.CompleteAndGetNeedsDispose() ? this.InnerStream.DisposeAsync() : new $.$spc.System.Threading.Tasks.ValueTask();
            }
            /*bool */ CompleteAndGetNeedsDispose()
            {
                if (this._isReaderCompleted)
                {
                    return false;
                }
                this._isReaderCompleted = true;
                /*BufferSegment?*/ let segment = this._readHead;
                while(segment !== null)
                {
                    /*BufferSegment*/ let returnSegment = segment;
                    segment = segment.NextSegment;
                    returnSegment.Reset();
                }
                return !this.LeaveOpen;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                return this.ReadInternalAsync(null, cancellationToken);
            }
            /*ValueTask<ReadResult> */ ReadAtLeastAsyncCore(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadInternalAsync(minimumSize, cancellationToken);
            }
            /*ValueTask<ReadResult> */ ReadInternalAsync(/*int?*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfCompleted();
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.ReadResult, cancellationToken));
                }
                /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                /*ReadResult*/ let readResult;
                if (this.TryReadInternal(tokenSource, $.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult)))
                {
                    if (minimumSize === null || readResult.Buffer.Length >= minimumSize || readResult.IsCompleted || readResult.IsCanceled)
                    {
                        return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(readResult);
                    }
                }
                return Core(this, minimumSize, tokenSource, cancellationToken);
                /*static ValueTask<ReadResult>*/ /*async*/  function Core(/*StreamPipeReader*/ reader, /*int?*/ minimumSize, /*CancellationTokenSource*/ tokenSource, /*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult), $.$sipl.System.IO.Pipelines.ReadResult, async () => 
                    {
                        /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                        if (cancellationToken.CanBeCanceled)
                        {
                            reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                            {
                                return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                            }), reader);
                        }
                        let $disposable2 = null;
                        try
                        {
                            $disposable2 = reg;
                            /*var*/ let isCanceled = false;
                            /*bool*/ let isCompleted = false;
                            try
                            {
                                if (reader.UseZeroByteReads && reader._bufferedBytes === 0n)
                                {
                                    await reader.InnerStream.ReadAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).Empty, tokenSource.Token).ConfigureAwait(false);
                                }
                                do
                                {
                                    reader.AllocateReadTail(minimumSize);
                                    /*Memory<byte>*/ let buffer = reader._readTail.AvailableMemory.Slice(reader._readTail.End);
                                    /*int*/ let length = await reader.InnerStream.ReadAsync$2(buffer, tokenSource.Token).ConfigureAwait(false);
                                    $.$spc.System.Diagnostics.Debug.Assert$1(((length + reader._readTail.End) | 0) <= reader._readTail.AvailableMemory.Length, "length + reader._readTail.End <= reader._readTail.AvailableMemory.Length");
                                    reader._readTail.End += length;
                                    reader._bufferedBytes += BigInt(length);
                                    if (length === 0)
                                    {
                                        isCompleted = true;
                                        break;
                                    }
                                }
                                while(minimumSize !== null && reader._bufferedBytes < minimumSize);
                            }
                            catch(ex)
                            {
                                reader.ClearCancellationToken();
                                if (cancellationToken.IsCancellationRequested)
                                {
                                    throw new $.$spc.System.OperationCanceledException().$ctor$14(ex.Message, ex, cancellationToken);
                                }
                                else if (tokenSource.IsCancellationRequested)
                                {
                                    isCanceled = true;
                                }
                                else 
                                {
                                    throw ex;
                                }
                            }
                            return new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(reader.GetCurrentReadOnlySequence(), isCanceled, isCompleted);
                        }
                        finally
                        {
                            $disposable2?.System$IDisposable$Dispose();
                        }
                    });
                }
            }
            /*Task *//*async*/  CopyToAsync(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.ThrowIfCompleted();
                    /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                    if (tokenSource.IsCancellationRequested)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                    }
                    /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                        }), this);
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._readHead;
                            /*int*/ let segmentIndex = this._readIndex;
                            try
                            {
                                while(segment !== null)
                                {
                                    /*FlushResult*/ let flushResult = await destination.WriteAsync(segment.Memory.Slice(segmentIndex), tokenSource.Token).ConfigureAwait(false);
                                    if (flushResult.IsCanceled)
                                    {
                                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                                    }
                                    segment = segment.NextSegment;
                                    segmentIndex = 0;
                                    if (flushResult.IsCompleted)
                                    {
                                        return;
                                    }
                                }
                            }
                            finally
                            {
                                {
                                    if (segment !== null)
                                    {
                                        this.AdvanceTo$2(segment, segment.End, segment, segment.End);
                                    }
                                }
                            }
                            await $.$sipl.System.IO.Pipelines.StreamPipeExtensions.CopyToAsync(this.InnerStream, destination, tokenSource.Token).ConfigureAwait(false);
                        }
                        catch($e)
                        {
                            this.ClearCancellationToken();
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*Task *//*async*/  CopyToAsync$1(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.ThrowIfCompleted();
                    /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                    if (tokenSource.IsCancellationRequested)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                    }
                    /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                        }), this);
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._readHead;
                            /*int*/ let segmentIndex = this._readIndex;
                            try
                            {
                                while(segment !== null)
                                {
                                    await destination.WriteAsync$2(segment.Memory.Slice(segmentIndex), tokenSource.Token).ConfigureAwait(false);
                                    segment = segment.NextSegment;
                                    segmentIndex = 0;
                                }
                            }
                            finally
                            {
                                {
                                    if (segment !== null)
                                    {
                                        this.AdvanceTo$2(segment, segment.End, segment, segment.End);
                                    }
                                }
                            }
                            await this.InnerStream.CopyToAsync$2(destination, tokenSource.Token).ConfigureAwait(false);
                        }
                        catch($e)
                        {
                            this.ClearCancellationToken();
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*void */ ClearCancellationToken()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        this._internalTokenSource = null;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
            }
            /*void */ ThrowIfCompleted()
            {
                if (this._isReaderCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                this.ThrowIfCompleted();
                return this.TryReadInternal(this.InternalTokenSource, result);
            }
            /*bool */ TryReadInternal(/*CancellationTokenSource*/ source, /*out ReadResult*/ result)
            {
                /*bool*/ let isCancellationRequested = source.IsCancellationRequested;
                if (isCancellationRequested || (this._bufferedBytes > 0n && !this._examinedEverything))
                {
                    if (isCancellationRequested)
                    {
                        this.ClearCancellationToken();
                    }
                    /*ReadOnlySequence<byte>*/ let buffer = this.GetCurrentReadOnlySequence();
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(buffer, isCancellationRequested, false);
                    return true;
                }
                result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                return false;
            }
            /*ReadOnlySequence<byte> */ GetCurrentReadOnlySequence()
            {
                return this._readHead === null ? new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))() : new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))().$ctor$3(this._readHead, this._readIndex, this._readTail, this._readTail.End);
            }
            /*void */ AllocateReadTail(/*int?*/ minimumSize)
            {
                if (this._readHead === null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readTail === null, "_readTail == null");
                    this._readHead = this.AllocateSegment(minimumSize);
                    this._readTail = this._readHead;
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readTail !== null, "_readTail != null");
                    if (this._readTail.WritableBytes < this.MinimumReadThreshold)
                    {
                        /*BufferSegment*/ let nextSegment = this.AllocateSegment(minimumSize);
                        this._readTail.SetNext(nextSegment);
                        this._readTail = nextSegment;
                    }
                }
            }
            /*BufferSegment */ AllocateSegment(/*int?*/ minimumSize)
            {
                /*BufferSegment*/ let nextSegment = this.CreateSegmentUnsynchronized();
                /*var*/ let bufferSize = minimumSize ?? this.BufferSize;
                /*int*/ let maxSize = !this._options.IsDefaultSharedMemoryPool ? this._options.Pool.MaxBufferSize : -1;
                if (bufferSize <= maxSize)
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(bufferSize, maxSize);
                    nextSegment.SetOwnedMemory(this._options.Pool.Rent(sizeToRequest));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(bufferSize, this.MaxBufferSize);
                    nextSegment.SetOwnedMemory$1($.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(sizeToRequest));
                }
                return nextSegment;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$spc.System.Math.Max$4(this.BufferSize, sizeHint);
                /*int*/ let adjustedToMaximumSize = $.$spc.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readHead, "Returning _readHead segment that's in use!");
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readTail, "Returning _readTail segment that's in use!");
                segment.Reset();
                if (this._bufferSegmentPool.Count < 256/*MaxSegmentPoolSize*/)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*void */ Cancel()
            {
                this.InternalTokenSource.Cancel();
            }
            //default member initializer
            constructor()
            {
                super();
                this._lock = new $.$spc.System.Object().$ctor();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
            }
            static $h = 2029257;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1439433,"p":[{"p":262145,"g":{"r":0,"d":0,"h":64426538697,"f":2},"n":"LeaveOpen","d":2029257,"h":60131571401,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":73016473289,"f":2},"n":"UseZeroByteReads","d":2029257,"h":68721505993,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":81606407881,"f":2},"n":"BufferSize","d":2029257,"h":77311440585,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":90196342473,"f":2},"n":"MaxBufferSize","d":2029257,"h":85901375177,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":98786277065,"f":2},"n":"MinimumReadThreshold","d":2029257,"h":94491309769,"f":2},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":107376211657,"f":2},"n":"Pool","d":2029257,"h":103081244361,"f":2},{"p":62128129,"g":{"r":0,"d":0,"h":120261113545,"f":1},"n":"InnerStream","d":2029257,"h":115966146249,"f":1},{"p":126091265,"g":{"r":0,"d":0,"h":133146015433,"f":2},"n":"InternalTokenSource","d":2029257,"h":128851048137,"f":2}],"m":[{"r":65537,"p":[{"n":"consumed","p":1218810}],"n":"AdvanceTo","d":2029257,"h":124556080841,"f":32769},{"r":65537,"p":[{"n":"consumed","p":1218810},{"n":"examined","p":1218810}],"n":"AdvanceTo","o":"@$1","d":2029257,"h":137440982729,"f":32769},{"r":65537,"p":[{"n":"consumedSegment","p":128713},{"n":"consumedIndex","p":655361},{"n":"examinedSegment","p":128713},{"n":"examinedIndex","p":655361}],"n":"AdvanceTo","o":"@$2","d":2029257,"h":141735950025,"f":2},{"r":65537,"n":"CancelPendingRead","d":2029257,"h":146030917321,"f":32769},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":2029257,"h":150325884617,"f":32769},{"r":136118273,"p":[{"n":"exception","p":47185921,"f":65}],"n":"CompleteAsync","d":2029257,"h":154620851913,"f":32769},{"r":262145,"n":"CompleteAndGetNeedsDispose","d":2029257,"h":158915819209,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":2029257,"h":163210786505,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAtLeastAsyncCore","d":2029257,"h":167505753801,"f":32772},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":$.$typeNullable($.$spc.System.Int32).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadInternalAsync","d":2029257,"h":171800721097,"f":2},{"r":133300225,"p":[{"n":"destination","p":1636041},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","d":2029257,"h":176095688393,"f":36865},{"r":133300225,"p":[{"n":"destination","p":62128129},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","o":"@$1","d":2029257,"h":180390655689,"f":36865},{"r":65537,"n":"ClearCancellationToken","d":2029257,"h":184685622985,"f":2},{"r":65537,"n":"ThrowIfCompleted","d":2029257,"h":188980590281,"f":2},{"r":262145,"p":[{"n":"result","p":1767113,"f":2}],"n":"TryRead","d":2029257,"h":193275557577,"f":32769},{"r":262145,"p":[{"n":"source","p":126091265},{"n":"result","p":1767113,"f":2}],"n":"TryReadInternal","d":2029257,"h":197570524873,"f":2},{"r":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"n":"GetCurrentReadOnlySequence","d":2029257,"h":201865492169,"f":2},{"r":65537,"p":[{"n":"minimumSize","p":$.$typeNullable($.$spc.System.Int32).$h,"f":65}],"n":"AllocateReadTail","d":2029257,"h":206160459465,"f":2},{"r":128713,"p":[{"n":"minimumSize","p":$.$typeNullable($.$spc.System.Int32).$h,"f":65}],"n":"AllocateSegment","d":2029257,"h":210455426761,"f":2},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361}],"n":"GetSegmentSize","d":2029257,"h":214750394057,"f":2},{"r":128713,"n":"CreateSegmentUnsynchronized","d":2029257,"h":219045361353,"f":2},{"r":65537,"p":[{"n":"segment","p":128713}],"n":"ReturnSegmentUnsynchronized","d":2029257,"h":223340328649,"f":2},{"r":65537,"n":"Cancel","d":2029257,"h":227635295945,"f":2}],"l":[{"t":655361,"n":"InitialSegmentPoolSize","d":2029257,"h":4296996553,"f":40},{"t":655361,"n":"MaxSegmentPoolSize","d":2029257,"h":8591963849,"f":40},{"t":126091265,"n":"_internalTokenSource","d":2029257,"h":12886931145,"f":2},{"t":262145,"n":"_isReaderCompleted","d":2029257,"h":17181898441,"f":2},{"t":128713,"n":"_readHead","d":2029257,"h":21476865737,"f":2},{"t":655361,"n":"_readIndex","d":2029257,"h":25771833033,"f":2},{"t":128713,"n":"_readTail","d":2029257,"h":30066800329,"f":2},{"t":917505,"n":"_bufferedBytes","d":2029257,"h":34361767625,"f":2},{"t":262145,"n":"_examinedEverything","d":2029257,"h":38656734921,"f":2},{"t":131073,"n":"_lock","d":2029257,"h":42951702217,"f":2},{"t":194249,"n":"_bufferSegmentPool","d":2029257,"h":47246669513,"f":2},{"t":2094793,"n":"_options","d":2029257,"h":51541636809,"f":2}],"c":[{"p":[{"n":"readingStream","p":62128129},{"n":"options","p":2094793}],"n":".ctor","o":"$ctor$2","d":2029257,"h":55836604105,"f":1}],"h":2029257}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeReader`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.ThreadPoolScheduler", ($self) => class ThreadPoolScheduler extends $.$sipl.System.IO.Pipelines.PipeScheduler
        {
            /*void */ Schedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                $.$spc.System.Threading.ThreadPool.QueueUserWorkItem$2($.$spc.System.Object, action, state, false);
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                $.$spc.System.Threading.ThreadPool.UnsafeQueueUserWorkItem($.$spc.System.Object, action, state, false);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2291401;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1570505,"m":[{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":2291401,"h":4297258697,"f":32769},{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":2291401,"h":8592225993,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":2291401,"h":12887193289,"f":1}],"h":2291401}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeScheduler; }
            static get $fullName() { return `System.IO.Pipelines.ThreadPoolScheduler`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeReaderStream", ($self) => class PipeReaderStream extends $.$spc.System.IO.Stream
        {
            /*PipeReader*/ _pipeReader = null;
            $ctor$3(/*PipeReader*/ pipeReader, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(pipeReader !== null, "pipeReader != null");
                    this._pipeReader = pipeReader;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this.LeaveOpen)
                {
                    this._pipeReader.Complete(null);
                }
                super.Dispose$1(disposing);
            }
            /*bool */ get CanRead()
            {
                return true;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*bool*/ LeaveOpen = false;
            /*void */ Flush()
            {
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                return this.ReadInternal(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count));
            }
            /*int */ ReadByte()
            {
                /*Span<byte>*/ let oneByte = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 1, null);
                return this.ReadInternal(oneByte) === 0 ? -1 : oneByte.get_Item(0).$v;
            }
            /*int */ ReadInternal(/*Span<byte>*/ buffer)
            {
                /*ValueTask<ReadResult>*/ let vt = this._pipeReader.ReadAsync(new $.$spc.System.Threading.CancellationToken());
                /*ReadResult*/ let result = vt.IsCompletedSuccessfully ? vt.Result : vt.AsTask().GetAwaiter$1().GetResult();
                return this.HandleReadResult(result, buffer);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.ReadAsync$1(buffer, offset, count, new $.$spc.System.Threading.CancellationToken()), callback, state);
            }
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.End$1($.$spc.System.Int32, asyncResult);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                return this.ReadAsyncInternal(new ($.$spc.System.Memory$$($.$spc.System.Byte))().$ctor$4(buffer, offset, count), cancellationToken).AsTask();
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                return this.ReadInternal(buffer);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadAsyncInternal(buffer, cancellationToken);
            }
            /*ValueTask<int> *//*async*/  ReadAsyncInternal(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                {
                    /*ReadResult*/ let result = await this._pipeReader.ReadAsync(cancellationToken).ConfigureAwait(false);
                    return this.HandleReadResult(result, buffer.Span);
                });
            }
            /*int */ HandleReadResult(/*ReadResult*/ result, /*Span<byte>*/ buffer)
            {
                if (result.IsCanceled)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                }
                /*ReadOnlySequence<byte>*/ let sequence = result.Buffer;
                /*long*/ let bufferLength = sequence.Length;
                /*SequencePosition*/ let consumed = sequence.Start;
                try
                {
                    if (bufferLength !== 0n)
                    {
                        /*int*/ let actual = $.$cast($.$spc.System.Math.Min$5(bufferLength, BigInt(buffer.Length)), $.$spc.System.Int32);
                        /*ReadOnlySequence<byte>*/ let slice = BigInt(actual) === bufferLength ? sequence : sequence.Slice$3(0, actual);
                        consumed = slice.End;
                        $.$sm.System.Buffers.BuffersExtensions.CopyTo($.$spc.System.Byte, $.$ref(() => slice, ), buffer);
                        return actual;
                    }
                    if (result.IsCompleted)
                    {
                        return 0;
                    }
                }
                finally
                {
                    {
                        this._pipeReader.AdvanceTo(consumed);
                    }
                }
                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_InvalidZeroByteRead();
                return 0;
            }
            /*Task */ CopyToAsync$3(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                $.$sipl.System.IO.StreamHelpers.ValidateCopyToArgs(this, destination, bufferSize);
                return this._pipeReader.CopyToAsync$1(destination, cancellationToken);
            }
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            static $h = 1504969;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476341449,"f":32769},"n":"CanRead","d":1504969,"h":17181374153,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":30066276041,"f":32769},"n":"CanSeek","d":1504969,"h":25771308745,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38656210633,"f":32769},"n":"CanWrite","d":1504969,"h":34361243337,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":47246145225,"f":32769},"n":"Length","d":1504969,"h":42951177929,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":55836079817,"f":32769},"s":{"r":0,"d":0,"h":60131047113,"f":32769},"n":"Position","d":1504969,"h":51541112521,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":73015949001,"f":8},"s":{"r":0,"d":0,"h":77310916297,"f":8},"n":"LeaveOpen","d":1504969,"h":68720981705,"f":8}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1504969,"h":12886406857,"f":32772},{"r":65537,"n":"Flush","d":1504969,"h":81605883593,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1504969,"h":85900850889,"f":32769},{"r":655361,"n":"ReadByte","d":1504969,"h":90195818185,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"ReadInternal","d":1504969,"h":94490785481,"f":2},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1504969,"h":98785752777,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1504969,"h":103080720073,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1504969,"h":107375687369,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginRead","d":1504969,"h":111670654665,"f":98305},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":1504969,"h":115965621961,"f":98305},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1504969,"h":120260589257,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1504969,"h":124555556553,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1504969,"h":128850523849,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadAsyncInternal","d":1504969,"h":133145491145,"f":4098},{"r":655361,"p":[{"n":"result","p":1767113},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"HandleReadResult","d":1504969,"h":137440458441,"f":2},{"r":133300225,"p":[{"n":"destination","p":62128129},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"CopyToAsync","o":"@$3","d":1504969,"h":141735425737,"f":32769}],"l":[{"t":1439433,"n":"_pipeReader","d":1504969,"h":4296472265,"f":2}],"c":[{"p":[{"n":"pipeReader","p":1439433},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":1504969,"h":8591439561,"f":1}],"i":[57475073,56885249],"h":1504969}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeReaderStream`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeWriterStream", ($self) => class PipeWriterStream extends $.$spc.System.IO.Stream
        {
            /*PipeWriter*/ _pipeWriter = null;
            $ctor$3(/*PipeWriter*/ pipeWriter, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(pipeWriter !== null, "pipeWriter != null");
                    this._pipeWriter = pipeWriter;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this.LeaveOpen)
                {
                    this._pipeWriter.Complete(null);
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                if (!this.LeaveOpen)
                {
                    return this._pipeWriter.CompleteAsync(null);
                }
                return new $.$spc.System.Threading.Tasks.ValueTask();
            }
            /*bool*/ LeaveOpen = false;
            /*bool */ get CanRead()
            {
                return false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return true;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Flush()
            {
                this.FlushAsync().GetAwaiter().GetResult();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.WriteAsync$1(buffer, offset, count, new $.$spc.System.Threading.CancellationToken()), callback, state);
            }
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.End(asyncResult);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                return this.WriteAsync(buffer, offset, count).GetAwaiter().GetResult();
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.WriteAsync(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count), cancellationToken);
                return $.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.WriteAsync(buffer, cancellationToken);
                return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask));
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.FlushAsync(cancellationToken);
                return $.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask);
            }
            static /*Task */ GetFlushResultAsTask(/*ValueTask<FlushResult>*/ valueTask)
            {
                if (valueTask.IsCompletedSuccessfully)
                {
                    /*FlushResult*/ let result = valueTask.Result;
                    if (result.IsCanceled)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                    }
                    return $.$spc.System.Threading.Tasks.Task.CompletedTask;
                }
                /*static Task*/ /*async*/  function AwaitTask(/*ValueTask<FlushResult>*/ valueTask)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                    {
                        /*FlushResult*/ let result = await valueTask.ConfigureAwait(false);
                        if (result.IsCanceled)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                        }
                    });
                }
                return AwaitTask(valueTask);
            }
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            static $h = 1701577;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066472649,"f":8},"s":{"r":0,"d":0,"h":34361439945,"f":8},"n":"LeaveOpen","d":1701577,"h":25771505353,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":42951374537,"f":32769},"n":"CanRead","d":1701577,"h":38656407241,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51541309129,"f":32769},"n":"CanSeek","d":1701577,"h":47246341833,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60131243721,"f":32769},"n":"CanWrite","d":1701577,"h":55836276425,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68721178313,"f":32769},"n":"Length","d":1701577,"h":64426211017,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":77311112905,"f":32769},"s":{"r":0,"d":0,"h":81606080201,"f":32769},"n":"Position","d":1701577,"h":73016145609,"f":32769}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1701577,"h":12886603465,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1701577,"h":17181570761,"f":32769},{"r":65537,"n":"Flush","d":1701577,"h":85901047497,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1701577,"h":90196014793,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1701577,"h":94490982089,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1701577,"h":98785949385,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWrite","d":1701577,"h":103080916681,"f":98305},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":1701577,"h":107375883977,"f":98305},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1701577,"h":111670851273,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1701577,"h":115965818569,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1701577,"h":120260785865,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1701577,"h":124555753161,"f":32769},{"r":133300225,"p":[{"n":"valueTask","p":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h}],"n":"GetFlushResultAsTask","d":1701577,"h":128850720457,"f":34}],"l":[{"t":1636041,"n":"_pipeWriter","d":1701577,"h":4296668873,"f":2}],"c":[{"p":[{"n":"pipeWriter","p":1636041},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":1701577,"h":8591636169,"f":1}],"i":[57475073,56885249],"h":1701577}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeWriterStream`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ResultFlags", ($self) => class ResultFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static Canceled = 1;
            static Completed = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Canceled": 1n,
                    "Completed": 2n
                };
            }
            static $h = 1832649;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":1832649,"n":"None","d":1832649,"h":4296799945,"f":33},{"t":1832649,"n":"Canceled","d":1832649,"h":8591767241,"f":33},{"t":1832649,"n":"Completed","d":1832649,"h":12886734537,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1832649,"h":17181701833,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1832649,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipelines.ResultFlags`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ExceptionArgument", ($self) => class ExceptionArgument extends $.$spc.System.Enum
        {
            static minimumSize = 0;
            static bytes = 1;
            static callback = 2;
            static options = 3;
            static pauseWriterThreshold = 4;
            static resumeWriterThreshold = 5;
            static sizeHint = 6;
            static destination = 7;
            static buffer = 8;
            static source = 9;
            static readingStream = 10;
            static writingStream = 11;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "minimumSize": 0n,
                    "bytes": 1n,
                    "callback": 2n,
                    "options": 3n,
                    "pauseWriterThreshold": 4n,
                    "resumeWriterThreshold": 5n,
                    "sizeHint": 6n,
                    "destination": 7n,
                    "buffer": 8n,
                    "source": 9n,
                    "readingStream": 10n,
                    "writingStream": 11n
                };
            }
            static $h = 390857;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":390857,"n":"minimumSize","d":390857,"h":4295358153,"f":33},{"t":390857,"n":"bytes","d":390857,"h":8590325449,"f":33},{"t":390857,"n":"callback","d":390857,"h":12885292745,"f":33},{"t":390857,"n":"options","d":390857,"h":17180260041,"f":33},{"t":390857,"n":"pauseWriterThreshold","d":390857,"h":21475227337,"f":33},{"t":390857,"n":"resumeWriterThreshold","d":390857,"h":25770194633,"f":33},{"t":390857,"n":"sizeHint","d":390857,"h":30065161929,"f":33},{"t":390857,"n":"destination","d":390857,"h":34360129225,"f":33},{"t":390857,"n":"buffer","d":390857,"h":38655096521,"f":33},{"t":390857,"n":"source","d":390857,"h":42950063817,"f":33},{"t":390857,"n":"readingStream","d":390857,"h":47245031113,"f":33},{"t":390857,"n":"writingStream","d":390857,"h":51539998409,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":390857,"h":55834965705,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":390857}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipelines.ExceptionArgument`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.BufferSegment", ($self) => class BufferSegment extends $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$spc.System.Byte)
        {
            /*IMemoryOwner<byte>?*/ _memoryOwner = null;
            /*byte[]?*/ _array = null;
            /*BufferSegment?*/ _next = null;
            /*int*/ _end = 0;
            /*int */ get End()
            {
                return this._end;
            }
            /*int */ set End(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value <= this.AvailableMemory.Length, "value <= AvailableMemory.Length");
                this._end = value;
                this.Memory = $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2(this.AvailableMemory.Slice$1(0, value));
            }
            /*BufferSegment? */ get NextSegment()
            {
                return this._next;
            }
            /*BufferSegment? */ set NextSegment(value)
            {
                this.Next = value;
                this._next = value;
            }
            /*void */ SetOwnedMemory(/*IMemoryOwner<byte>*/ memoryOwner)
            {
                this._memoryOwner = memoryOwner;
                this.AvailableMemory = memoryOwner.System$Buffers$IMemoryOwner$$$Memory;
            }
            /*void */ SetOwnedMemory$1(/*byte[]*/ arrayPoolBuffer)
            {
                this._array = arrayPoolBuffer;
                this.AvailableMemory = $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(arrayPoolBuffer);
            }
            /*void */ Reset()
            {
                this.ResetMemory();
                this.Next = null;
                this.RunningIndex = 0n;
                this._next = null;
            }
            /*void */ ResetMemory()
            {
                /*IMemoryOwner<byte>?*/ let memoryOwner = this._memoryOwner;
                if (memoryOwner !== null)
                {
                    this._memoryOwner = null;
                    memoryOwner.System$IDisposable$Dispose();
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._array !== null, "_array != null");
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(this._array, false);
                    this._array = null;
                }
                this.Memory = new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))();
                this._end = 0;
                this.AvailableMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
            }
            /*object? */ get MemoryOwner()
            {
                return $.$cast(this._memoryOwner, $.$spc.System.Object) ?? this._array;
            }
            /*Memory<byte>*/ AvailableMemory;
            /*int */ get Length()
            {
                return this.End;
            }
            /*int */ get WritableBytes()
            {
                return ((this.AvailableMemory.Length - this.End) | 0);
            }
            /*void */ SetNext(/*BufferSegment*/ segment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== null, "segment != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this.Next === null, "Next == null");
                this.NextSegment = segment;
                segment = this;
                while(segment.Next !== null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(segment.NextSegment !== null, "segment.NextSegment != null");
                    segment.NextSegment.RunningIndex = segment.RunningIndex + BigInt(segment.Length);
                    segment = segment.NextSegment;
                }
            }
            static /*long */ GetLength(/*BufferSegment*/ startSegment, /*int*/ startIndex, /*BufferSegment*/ endSegment, /*int*/ endIndex)
            {
                return (endSegment.RunningIndex + BigInt((endIndex >>> 0))) - (startSegment.RunningIndex + BigInt((startIndex >>> 0)));
            }
            static /*long */ GetLength$1(/*long*/ startPosition, /*BufferSegment*/ endSegment, /*int*/ endIndex)
            {
                return (endSegment.RunningIndex + BigInt((endIndex >>> 0))) - startPosition;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.AvailableMemory = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
            }
            static $h = 128713;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":655361,"g":{"r":0,"d":0,"h":25769932489,"f":1},"s":{"r":0,"d":0,"h":30064899785,"f":1},"n":"End","d":128713,"h":21474965193,"f":1},{"p":128713,"g":{"r":0,"d":0,"h":38654834377,"f":1},"s":{"r":0,"d":0,"h":42949801673,"f":1},"n":"NextSegment","d":128713,"h":34359867081,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":68719605449,"f":8},"n":"MemoryOwner","d":128713,"h":64424638153,"f":8},{"p":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":81604507337,"f":1},"s":{"r":0,"d":0,"h":85899474633,"f":2},"n":"AvailableMemory","d":128713,"h":77309540041,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":94489409225,"f":1},"n":"Length","d":128713,"h":90194441929,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103079343817,"f":1},"n":"WritableBytes","d":128713,"h":98784376521,"f":1}],"m":[{"r":65537,"p":[{"n":"memoryOwner","p":$.$spc.System.Buffers.IMemoryOwner$$($.$spc.System.Byte).$h}],"n":"SetOwnedMemory","d":128713,"h":47244768969,"f":1},{"r":65537,"p":[{"n":"arrayPoolBuffer","p":0}],"n":"SetOwnedMemory","o":"@$1","d":128713,"h":51539736265,"f":1},{"r":65537,"n":"Reset","d":128713,"h":55834703561,"f":1},{"r":65537,"n":"ResetMemory","d":128713,"h":60129670857,"f":1},{"r":65537,"p":[{"n":"segment","p":128713}],"n":"SetNext","d":128713,"h":107374311113,"f":1},{"r":917505,"p":[{"n":"startSegment","p":128713},{"n":"startIndex","p":655361},{"n":"endSegment","p":128713},{"n":"endIndex","p":655361}],"n":"GetLength","d":128713,"h":111669278409,"f":40},{"r":917505,"p":[{"n":"startPosition","p":917505},{"n":"endSegment","p":128713},{"n":"endIndex","p":655361}],"n":"GetLength","o":"@$1","d":128713,"h":115964245705,"f":40}],"l":[{"t":$.$spc.System.Buffers.IMemoryOwner$$($.$spc.System.Byte).$h,"n":"_memoryOwner","d":128713,"h":4295096009,"f":2},{"t":0,"n":"_array","d":128713,"h":8590063305,"f":2},{"t":128713,"n":"_next","d":128713,"h":12885030601,"f":2},{"t":655361,"n":"_end","d":128713,"h":17179997897,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":128713,"h":120259213001,"f":1}],"h":128713}; }
            static get $b() { return $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$spc.System.Byte); }
            static get $fullName() { return `System.IO.Pipelines.BufferSegment`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeWriter", ($self) => class StreamPipeWriter extends $.$sipl.System.IO.Pipelines.PipeWriter
        {
            /*int*/ static InitialSegmentPoolSize = 4;
            /*int*/ static MaxSegmentPoolSize = 256;
            /*int*/ _minimumBufferSize = 0;
            /*BufferSegment?*/ _head = null;
            /*BufferSegment?*/ _tail = null;
            /*Memory<byte>*/ _tailMemory;
            /*int*/ _tailBytesBuffered = 0;
            /*long*/ _bytesBuffered = 0n;
            /*MemoryPool<byte>?*/ _pool = null;
            /*int*/ _maxPooledBufferSize = 0;
            /*CancellationTokenSource?*/ _internalTokenSource = null;
            /*bool*/ _isCompleted = false;
            /*object*/ _lockObject = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*bool*/ _leaveOpen = false;
            /*CancellationTokenSource */ get InternalTokenSource()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lockObject)
                    {
                        return this._internalTokenSource ??= new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lockObject)
                }
            }
            $ctor$2(/*Stream*/ writingStream, /*StreamPipeWriterOptions*/ options)
            {
                super.$ctor$1();
                {
                    if (writingStream === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(11/*ExceptionArgument.writingStream*/);
                    }
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this.InnerStream = writingStream;
                    this._minimumBufferSize = options.MinimumBufferSize;
                    this._pool = options.Pool === $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared ? null : options.Pool;
                    this._maxPooledBufferSize = (this._pool?.MaxBufferSize ?? null) ?? -1;
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$2(4/*InitialSegmentPoolSize*/);
                    this._leaveOpen = options.LeaveOpen;
                }
                return this;
            }
            /*Stream*/ InnerStream = null;
            /*void */ Advance(/*int*/ bytes)
            {
                if ((bytes >>> 0) > (this._tailMemory.Length >>> 0))
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.bytes*/);
                }
                this._tailBytesBuffered += bytes;
                this._bytesBuffered += BigInt(bytes);
                this._tailMemory = this._tailMemory.Slice(bytes);
            }
            /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
            {
                if (this._isCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateMemory(sizeHint);
                return this._tailMemory;
            }
            /*Span<byte> */ GetSpan(/*int*/ sizeHint)
            {
                if (this._isCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateMemory(sizeHint);
                return this._tailMemory.Span;
            }
            /*void */ AllocateMemory(/*int*/ sizeHint)
            {
                if (this._head === null)
                {
                    /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                    this._head = this._tail = newSegment;
                    this._tailBytesBuffered = 0;
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._tail !== null, "_tail != null");
                    /*int*/ let bytesLeftInBuffer = this._tailMemory.Length;
                    if (bytesLeftInBuffer === 0 || bytesLeftInBuffer < sizeHint)
                    {
                        if (this._tailBytesBuffered > 0)
                        {
                            this._tail.End += this._tailBytesBuffered;
                            this._tailBytesBuffered = 0;
                        }
                        /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                        this._tail.SetNext(newSegment);
                        this._tail = newSegment;
                    }
                }
            }
            /*BufferSegment */ AllocateSegment(/*int*/ sizeHint)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(sizeHint >= 0, "sizeHint >= 0");
                /*BufferSegment*/ let newSegment = this.CreateSegmentUnsynchronized();
                /*int*/ let maxSize = this._maxPooledBufferSize;
                if (sizeHint <= maxSize)
                {
                    newSegment.SetOwnedMemory(this._pool.Rent(this.GetSegmentSize(sizeHint, maxSize)));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(sizeHint, 2147483647);
                    newSegment.SetOwnedMemory$1($.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(sizeToRequest));
                }
                this._tailMemory = newSegment.AvailableMemory;
                return newSegment;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$spc.System.Math.Max$4(this._minimumBufferSize, sizeHint);
                /*var*/ let adjustedToMaximumSize = $.$spc.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                segment.Reset();
                if (this._bufferSegmentPool.Count < 256/*MaxSegmentPoolSize*/)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*void */ CancelPendingFlush()
            {
                this.Cancel();
            }
            /*bool */ get CanGetUnflushedBytes()
            {
                return true;
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this._isCompleted)
                {
                    return;
                }
                this._isCompleted = true;
                try
                {
                    this.FlushInternal(exception === null);
                }
                finally
                {
                    {
                        this._internalTokenSource?.Dispose();
                        if (!this._leaveOpen)
                        {
                            this.InnerStream.Dispose();
                        }
                    }
                }
            }
            /*ValueTask *//*async*/  CompleteAsync(/*Exception?*/ exception)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    if (this._isCompleted)
                    {
                        return;
                    }
                    this._isCompleted = true;
                    try
                    {
                        await this.FlushAsyncInternal(exception === null, $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.Memory$$($.$spc.System.Byte).Empty), new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    }
                    finally
                    {
                        {
                            this._internalTokenSource?.Dispose();
                            if (!this._leaveOpen)
                            {
                                await this.InnerStream.DisposeAsync().ConfigureAwait(false);
                            }
                        }
                    }
                });
            }
            /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
            {
                if (this._bytesBuffered === 0n)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false));
                }
                return this.FlushAsyncInternal(true, $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.Memory$$($.$spc.System.Byte).Empty), new $.$spc.System.Threading.CancellationToken());
            }
            /*long */ get UnflushedBytes()
            {
                return this._bytesBuffered;
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                return this.FlushAsyncInternal(true, source, new $.$spc.System.Threading.CancellationToken());
            }
            /*void */ Cancel()
            {
                this.InternalTokenSource.Cancel();
            }
            /*ValueTask<FlushResult> *//*async*/  FlushAsyncInternal(/*bool*/ writeToStream, /*ReadOnlyMemory<byte>*/ data, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult), $.$sipl.System.IO.Pipelines.FlushResult, async () => 
                {
                    /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeWriter)).Cancel();
                        }), this);
                    }
                    if (this._tailBytesBuffered > 0)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._tail !== null, "_tail != null");
                        this._tail.End += this._tailBytesBuffered;
                        this._tailBytesBuffered = 0;
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        /*CancellationToken*/ let localToken = this.InternalTokenSource.Token;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._head;
                            while(segment !== null)
                            {
                                /*BufferSegment*/ let returnSegment = segment;
                                segment = segment.NextSegment;
                                if (returnSegment.Length > 0 && writeToStream)
                                {
                                    await this.InnerStream.WriteAsync$2(returnSegment.Memory, localToken).ConfigureAwait(false);
                                }
                                this.ReturnSegmentUnsynchronized(returnSegment);
                                this._head = segment;
                            }
                            if (writeToStream)
                            {
                                if (data.Length > 0)
                                {
                                    await this.InnerStream.WriteAsync$2(data, localToken).ConfigureAwait(false);
                                }
                                if (this._bytesBuffered > 0n || data.Length > 0)
                                {
                                    await this.InnerStream.FlushAsync$1(localToken).ConfigureAwait(false);
                                }
                            }
                            this._head = null;
                            this._tail = null;
                            this._tailMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                            this._bytesBuffered = 0n;
                            return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false);
                        }
                        catch($e)
                        {
                            //lock
                            try
                            {
                                $.$spc.System.Threading.Monitor.Enter(this._lockObject)
                                {
                                    this._internalTokenSource = null;
                                }
                            }
                            finally
                            {
                                $.$spc.System.Threading.Monitor.Exit(this._lockObject)
                            }
                            if (localToken.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
                            {
                                return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(true, false);
                            }
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*void */ FlushInternal(/*bool*/ writeToStream)
            {
                if (this._tailBytesBuffered > 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._tail !== null, "_tail != null");
                    this._tail.End += this._tailBytesBuffered;
                    this._tailBytesBuffered = 0;
                }
                /*BufferSegment?*/ let segment = this._head;
                while(segment !== null)
                {
                    /*BufferSegment*/ let returnSegment = segment;
                    segment = segment.NextSegment;
                    if (returnSegment.Length > 0 && writeToStream)
                    {
                        this.InnerStream.Write$1(returnSegment.Memory.Span);
                    }
                    this.ReturnSegmentUnsynchronized(returnSegment);
                    this._head = segment;
                }
                if (this._bytesBuffered > 0n && writeToStream)
                {
                    this.InnerStream.Flush();
                }
                this._head = null;
                this._tail = null;
                this._tailMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                this._bytesBuffered = 0n;
            }
            //default member initializer
            constructor()
            {
                super();
                this._tailMemory = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
                this._lockObject = new $.$spc.System.Object().$ctor();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
            }
            static $h = 2160329;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1636041,"p":[{"p":126091265,"g":{"r":0,"d":0,"h":73016604361,"f":2},"n":"InternalTokenSource","d":2160329,"h":68721637065,"f":2},{"p":62128129,"g":{"r":0,"d":0,"h":90196473545,"f":1},"n":"InnerStream","d":2160329,"h":85901506249,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":137441113801,"f":32769},"n":"CanGetUnflushedBytes","d":2160329,"h":133146146505,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":158915950281,"f":32769},"n":"UnflushedBytes","d":2160329,"h":154620982985,"f":32769}],"m":[{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":2160329,"h":94491440841,"f":32769},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":2160329,"h":98786408137,"f":32769},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":2160329,"h":103081375433,"f":32769},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateMemory","d":2160329,"h":107376342729,"f":2},{"r":128713,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateSegment","d":2160329,"h":111671310025,"f":2},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361,"f":65,"v":2147483647}],"n":"GetSegmentSize","d":2160329,"h":115966277321,"f":2},{"r":128713,"n":"CreateSegmentUnsynchronized","d":2160329,"h":120261244617,"f":2},{"r":65537,"p":[{"n":"segment","p":128713}],"n":"ReturnSegmentUnsynchronized","d":2160329,"h":124556211913,"f":2},{"r":65537,"n":"CancelPendingFlush","d":2160329,"h":128851179209,"f":32769},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":2160329,"h":141736081097,"f":32769},{"r":136118273,"p":[{"n":"exception","p":47185921,"f":65}],"n":"CompleteAsync","d":2160329,"h":146031048393,"f":36865},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","d":2160329,"h":150326015689,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","d":2160329,"h":163210917577,"f":32769},{"r":65537,"n":"Cancel","d":2160329,"h":167505884873,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"writeToStream","p":262145},{"n":"data","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsyncInternal","d":2160329,"h":171800852169,"f":4098,"a":[{"t":86638593,"c":4381605889,"a":[{"v":$.$spc.System.Runtime.CompilerServices.PoolingAsyncValueTaskMethodBuilder$$().$h,"t":142606337}]}]},{"r":65537,"p":[{"n":"writeToStream","p":262145}],"n":"FlushInternal","d":2160329,"h":176095819465,"f":2}],"l":[{"t":655361,"n":"InitialSegmentPoolSize","d":2160329,"h":4297127625,"f":40},{"t":655361,"n":"MaxSegmentPoolSize","d":2160329,"h":8592094921,"f":40},{"t":655361,"n":"_minimumBufferSize","d":2160329,"h":12887062217,"f":2},{"t":128713,"n":"_head","d":2160329,"h":17182029513,"f":2},{"t":128713,"n":"_tail","d":2160329,"h":21476996809,"f":2},{"t":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"n":"_tailMemory","d":2160329,"h":25771964105,"f":2},{"t":655361,"n":"_tailBytesBuffered","d":2160329,"h":30066931401,"f":2},{"t":917505,"n":"_bytesBuffered","d":2160329,"h":34361898697,"f":2},{"t":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"n":"_pool","d":2160329,"h":38656865993,"f":2},{"t":655361,"n":"_maxPooledBufferSize","d":2160329,"h":42951833289,"f":2},{"t":126091265,"n":"_internalTokenSource","d":2160329,"h":47246800585,"f":2},{"t":262145,"n":"_isCompleted","d":2160329,"h":51541767881,"f":2},{"t":131073,"n":"_lockObject","d":2160329,"h":55836735177,"f":2},{"t":194249,"n":"_bufferSegmentPool","d":2160329,"h":60131702473,"f":2},{"t":262145,"n":"_leaveOpen","d":2160329,"h":64426669769,"f":2}],"c":[{"p":[{"n":"writingStream","p":62128129},{"n":"options","p":2225865}],"n":".ctor","o":"$ctor$2","d":2160329,"h":77311571657,"f":1}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h],"h":2160329}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeWriter; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte) ]; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeWriter`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime"))