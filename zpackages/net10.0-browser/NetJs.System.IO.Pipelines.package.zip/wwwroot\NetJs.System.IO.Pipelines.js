
(function ($global, $, $spc, $sc, $sm, $spu, $st, $sttp, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Pipelines", 
    {"h":38907,"f":"System.IO.Pipelines","v":"1.0.35.0","a":[{"t":92405761,"c":4387373057,"a":[{"v":"System.IO.Pipelines.Tests, PublicKey=00240000048000009400000006020000002400005253413100040000010001004b86c4cb78549b34bab61a3b1800e23bfeb5b3ec390074041536a7e3cbd97f5f04cf0f857155a8928eaa29ebfd11cfbbad3ba70efea7bda3226c6a8d370a4cd303f714486b6ebc225985a638471e6ef571cc92a4613c00b8fa65d61ccee0cbe5f36330c9a01f4183559f1bef24cc2917c6d913e3a541333a1d05d9bed22b38cb","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Pipelines","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Pipelines","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sipl.System.IO.Pipelines.IDuplexPipe", ($self) => class IDuplexPipe
        {
            static $h = 497659;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1415163,"g":{"r":0,"d":0,"h":8590432251,"f":257},"n":"Input","o":"System$IO$Pipelines$IDuplexPipe$Input","d":497659,"h":4295464955,"f":257},{"p":1611771,"g":{"r":0,"d":0,"h":17180366843,"f":257},"n":"Output","o":"System$IO$Pipelines$IDuplexPipe$Output","d":497659,"h":12885399547,"f":257}],"h":497659}; }
            static get $fullName() { return `System.IO.Pipelines.IDuplexPipe`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeScheduler", ($self) => class PipeScheduler extends $.$spc.System.Object
        {
            /*ThreadPoolScheduler*/ static s_threadPoolScheduler = null;
            /*InlineScheduler*/ static s_inlineScheduler = null;
            static /*PipeScheduler */ get ThreadPool()
            {
                return $.$sipl.System.IO.Pipelines.PipeScheduler.s_threadPoolScheduler;
            }
            static /*PipeScheduler */ get Inline()
            {
                return $.$sipl.System.IO.Pipelines.PipeScheduler.s_inlineScheduler;
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                return this.Schedule(action, state);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_threadPoolScheduler = new $.$sipl.System.IO.Pipelines.ThreadPoolScheduler().$ctor$2();
                }
                {
                    this.s_inlineScheduler = new $.$sipl.System.IO.Pipelines.InlineScheduler().$ctor$2();
                }
            }
            static $h = 1546235;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1546235,"g":{"r":0,"d":0,"h":17181415419,"f":33},"n":"ThreadPool","d":1546235,"h":12886448123,"f":33},{"p":1546235,"g":{"r":0,"d":0,"h":25771350011,"f":33},"n":"Inline","d":1546235,"h":21476382715,"f":33}],"m":[{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":1546235,"h":30066317307,"f":257},{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":1546235,"h":34361284603,"f":136}],"l":[{"t":2267131,"n":"s_threadPoolScheduler","d":1546235,"h":4296513531,"f":34},{"t":563195,"n":"s_inlineScheduler","d":1546235,"h":8591480827,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":1546235,"h":38656251899,"f":4}],"h":1546235}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeScheduler`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeReader", ($self) => class PipeReader extends $.$spc.System.Object
        {
            /*PipeReaderStream?*/ _stream = null;
            /*ValueTask<ReadResult> */ ReadAtLeastAsync(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                if (minimumSize < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(0/*ExceptionArgument.minimumSize*/);
                }
                return this.ReadAtLeastAsyncCore(minimumSize, cancellationToken);
            }
            /*ValueTask<ReadResult> *//*async*/  ReadAtLeastAsyncCore(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult), $.$sipl.System.IO.Pipelines.ReadResult, async () => 
                {
                    while(true)
                    {
                        /*ReadResult*/ let result = await this.ReadAsync(cancellationToken).ConfigureAwait(false);
                        /*ReadOnlySequence<byte>*/ let buffer = result.Buffer;
                        if (buffer.Length >= BigInt(minimumSize) || result.IsCompleted || result.IsCanceled)
                        {
                            return result;
                        }
                        this.AdvanceTo$1(buffer.Start, buffer.End);
                    }
                });
            }
            /*Stream */ AsStream(/*bool*/ leaveOpen)
            {
                if (this._stream === null)
                {
                    this._stream = new $.$sipl.System.IO.Pipelines.PipeReaderStream().$ctor$3(this, leaveOpen);
                }
                else if (leaveOpen)
                {
                    this._stream.LeaveOpen = leaveOpen;
                }
                return this._stream;
            }
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                try
                {
                    this.Complete(exception);
                    return new $.$spc.System.Threading.Tasks.ValueTask();
                }
                catch(ex)
                {
                    return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException(ex));
                }
            }
            /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
            }
            static /*PipeReader */ Create(/*Stream*/ stream, /*StreamPipeReaderOptions?*/ readerOptions)
            {
                return new $.$sipl.System.IO.Pipelines.StreamPipeReader().$ctor$2(stream, readerOptions ?? $.$sipl.System.IO.Pipelines.StreamPipeReaderOptions.s_default);
            }
            static /*PipeReader */ Create$1(/*ReadOnlySequence<byte>*/ sequence)
            {
                return new $.$sipl.System.IO.Pipelines.SequencePipeReader().$ctor$2(sequence);
            }
            /*Task */ CopyToAsync(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this.CopyToAsyncCore($.$sipl.System.IO.Pipelines.PipeWriter, destination, new ($.$spc.System.Func$$$$$($.$sipl.System.IO.Pipelines.PipeWriter, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)))().$ctor(this,  (/**/ destination, /*memory*/ memory, /*cancellationToken*/ cancellationToken) =>
                {
                    return destination.WriteAsync(memory, cancellationToken);
                }), cancellationToken);
            }
            /*Task */ CopyToAsync$1(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this.CopyToAsyncCore($.$spc.System.IO.Stream, destination, new ($.$spc.System.Func$$$$$($.$spc.System.IO.Stream, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)))().$ctor(this,  (/*destination*/ destination, /*memory*/ memory, /*cancellationToken*/ cancellationToken) =>
                {
                    /*ValueTask*/ let task = destination.WriteAsync$2(memory, cancellationToken);
                    if (task.IsCompletedSuccessfully)
                    {
                        task.GetAwaiter().GetResult();
                        return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false));
                    }
                    /*static ValueTask<FlushResult>*/ /*async*/  function Awaited(/*ValueTask*/ writeTask)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult), $.$sipl.System.IO.Pipelines.FlushResult, async () => 
                        {
                            await writeTask.ConfigureAwait(false);
                            return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false);
                        });
                    }
                    return Awaited(task);
                }), cancellationToken);
            }
            /*Task *//*async*/  CopyToAsyncCore(TStream, /*TStream*/ destination, /*Func<TStream, ReadOnlyMemory<byte>, CancellationToken, ValueTask<FlushResult>>*/ writeAsync, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    while(true)
                    {
                        /*ReadResult*/ let result = await this.ReadAsync(cancellationToken).ConfigureAwait(false);
                        /*ReadOnlySequence<byte>*/ let buffer = result.Buffer;
                        /*SequencePosition*/ let position = buffer.Start;
                        /*SequencePosition*/ let consumed = position;
                        try
                        {
                            if (result.IsCanceled)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                            }
                            /*ReadOnlyMemory<byte>*/ let memory;
                            while(buffer.TryGet($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => position, ($v) => position = $v, null), $.$ref(() => memory, ($v) => memory = $v, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte)), true))
                            {
                                if (memory.IsEmpty)
                                {
                                    consumed = position;
                                }
                                else 
                                {
                                    /*FlushResult*/ let flushResult = await writeAsync.Invoke(destination, memory, cancellationToken).ConfigureAwait(false);
                                    if (flushResult.IsCanceled)
                                    {
                                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                                    }
                                    consumed = position;
                                    if (flushResult.IsCompleted)
                                    {
                                        return;
                                    }
                                }
                            }
                            consumed = buffer.End;
                            if (result.IsCompleted)
                            {
                                break;
                            }
                        }
                        finally
                        {
                            {
                                this.AdvanceTo(consumed);
                            }
                        }
                    }
                });
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1415163;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"result","p":1742843,"f":2}],"n":"TryRead","d":1415163,"h":8591349755,"f":257},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":1415163,"h":12886317051,"f":257},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAtLeastAsync","d":1415163,"h":17181284347,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAtLeastAsyncCore","d":1415163,"h":21476251643,"f":4228},{"r":65537,"p":[{"n":"consumed","p":1226203}],"n":"AdvanceTo","d":1415163,"h":25771218939,"f":257},{"r":65537,"p":[{"n":"consumed","p":1226203},{"n":"examined","p":1226203}],"n":"AdvanceTo","o":"@$1","d":1415163,"h":30066186235,"f":257},{"r":62128129,"p":[{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":"AsStream","d":1415163,"h":34361153531,"f":129},{"r":65537,"n":"CancelPendingRead","d":1415163,"h":38656120827,"f":257},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":1415163,"h":42951088123,"f":257},{"r":136118273,"p":[{"n":"exception","p":47185921,"f":65}],"n":"CompleteAsync","d":1415163,"h":47246055419,"f":129},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":1415163,"h":51541022715,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"OnWriterCompleted has been deprecated and may not be invoked on all implementations of PipeReader.","t":1310721}]}]},{"r":1415163,"p":[{"n":"stream","p":62128129},{"n":"readerOptions","p":2070523,"f":65}],"n":"Create","d":1415163,"h":55835990011,"f":33},{"r":1415163,"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h}],"n":"Create","o":"@$1","d":1415163,"h":60130957307,"f":33},{"r":133300225,"p":[{"n":"destination","p":1611771},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","d":1415163,"h":64425924603,"f":129},{"r":133300225,"p":[{"n":"destination","p":62128129},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","o":"@$1","d":1415163,"h":68720891899,"f":129},{"r":133300225,"p":[{"n":"destination","p":68723081216},{"n":"writeAsync","p":(TStream) => $.$spc.System.Func$$$$$(TStream, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)).$h},{"n":"cancellationToken","p":125960193}],"g":["TStream"],"n":"CopyToAsyncCore","d":1415163,"h":73015859195,"f":135170}],"l":[{"t":1480699,"n":"_stream","d":1415163,"h":4296382459,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1415163,"h":77310826491,"f":4}],"h":1415163}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeReader`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeWriter", ($self) => class PipeWriter extends $.$spc.System.Object
        {
            /*PipeWriterStream?*/ _stream = null;
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                try
                {
                    this.Complete(exception);
                    return new $.$spc.System.Threading.Tasks.ValueTask();
                }
                catch(ex)
                {
                    return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException(ex));
                }
            }
            /*bool */ get CanGetUnflushedBytes()
            {
                return false;
            }
            /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
            }
            /*Stream */ AsStream(/*bool*/ leaveOpen)
            {
                if (this._stream === null)
                {
                    this._stream = new $.$sipl.System.IO.Pipelines.PipeWriterStream().$ctor$3(this, leaveOpen);
                }
                else if (leaveOpen)
                {
                    this._stream.LeaveOpen = leaveOpen;
                }
                return this._stream;
            }
            static /*PipeWriter */ Create(/*Stream*/ stream, /*StreamPipeWriterOptions?*/ writerOptions)
            {
                return new $.$sipl.System.IO.Pipelines.StreamPipeWriter().$ctor$2(stream, writerOptions ?? $.$sipl.System.IO.Pipelines.StreamPipeWriterOptions.s_default);
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                $.$sm.System.Buffers.BuffersExtensions.Write($.$spc.System.Byte, this, source.Span);
                return this.FlushAsync(cancellationToken);
            }
            /*Task *//*async*/  CopyFromAsync(/*Stream*/ source, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    while(true)
                    {
                        /*Memory<byte>*/ let buffer = this.GetMemory(0);
                        /*int*/ let read = await source.ReadAsync$2(buffer, cancellationToken).ConfigureAwait(false);
                        if (read === 0)
                        {
                            break;
                        }
                        this.Advance(read);
                        /*FlushResult*/ let result = await this.FlushAsync(cancellationToken).ConfigureAwait(false);
                        if (result.IsCanceled)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                        }
                        if (result.IsCompleted)
                        {
                            break;
                        }
                    }
                });
            }
            /*long */ get UnflushedBytes()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateNotSupportedException_UnflushedBytes();
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.Advance(int)
            System$Buffers$IBufferWriter$$$Advance()
            {
                return this.Advance(...arguments);
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.GetMemory(int)
            System$Buffers$IBufferWriter$$$GetMemory()
            {
                return this.GetMemory(...arguments);
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.GetSpan(int)
            System$Buffers$IBufferWriter$$$GetSpan()
            {
                return this.GetSpan(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1611771;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771415547,"f":129},"n":"CanGetUnflushedBytes","d":1611771,"h":21476448251,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":73016055803,"f":129},"n":"UnflushedBytes","d":1611771,"h":68721088507,"f":129}],"m":[{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":1611771,"h":8591546363,"f":257},{"r":136118273,"p":[{"n":"exception","p":47185921,"f":65}],"n":"CompleteAsync","d":1611771,"h":12886513659,"f":129},{"r":65537,"n":"CancelPendingFlush","d":1611771,"h":17181480955,"f":257},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":1611771,"h":30066382843,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"OnReaderCompleted has been deprecated and may not be invoked on all implementations of PipeWriter.","t":1310721}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","d":1611771,"h":34361350139,"f":257},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":1611771,"h":38656317435,"f":257},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":1611771,"h":42951284731,"f":257},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":1611771,"h":47246252027,"f":257},{"r":62128129,"p":[{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":"AsStream","d":1611771,"h":51541219323,"f":129},{"r":1611771,"p":[{"n":"stream","p":62128129},{"n":"writerOptions","p":2201595,"f":65}],"n":"Create","d":1611771,"h":55836186619,"f":33},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","d":1611771,"h":60131153915,"f":129},{"r":133300225,"p":[{"n":"source","p":62128129},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyFromAsync","d":1611771,"h":64426121211,"f":4240}],"l":[{"t":1677307,"n":"_stream","d":1611771,"h":4296579067,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1611771,"h":77311023099,"f":4}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h],"h":1611771}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte) ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeWriter`; }
        });
        
        $asm.$cls("$sipl.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sipl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.IO.Pipelines", $.$sipl.System.SR.$type.Assembly);
                    $.$sipl.System.SR.s_resourceManager = temp;
                }
                return $.$sipl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sipl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sipl.System.SR.resourceCulture = value;
            }
            static /*string */ get AdvanceToInvalidCursor()
            {
                return "The PipeReader has already advanced past the provided position.";
            }
            static /*string */ get ArgumentOutOfRange_NeedPosNum()
            {
                return "Positive number required.";
            }
            static /*string */ get ConcurrentOperationsNotSupported()
            {
                return "Concurrent reads or writes are not supported.";
            }
            static /*string */ get FlushCanceledOnPipeWriter()
            {
                return "Flush was canceled on underlying PipeWriter.";
            }
            static /*string */ get GetResultBeforeCompleted()
            {
                return "Can't GetResult unless awaiter is completed.";
            }
            static /*string */ get InvalidExaminedOrConsumedPosition()
            {
                return "The examined position must be greater than or equal to the consumed position.";
            }
            static /*string */ get InvalidExaminedPosition()
            {
                return "The examined position cannot be less than the previously examined position.";
            }
            static /*string */ get InvalidZeroByteRead()
            {
                return "The PipeReader returned 0 bytes when the ReadResult was not completed or canceled.";
            }
            static /*string */ get ObjectDisposed_StreamClosed()
            {
                return "Cannot access a closed stream.";
            }
            static /*string */ get NoReadingOperationToComplete()
            {
                return "No reading operation to complete.";
            }
            static /*string */ get NotSupported_UnreadableStream()
            {
                return "Stream does not support reading.";
            }
            static /*string */ get NotSupported_UnwritableStream()
            {
                return "Stream does not support writing.";
            }
            static /*string */ get ReadCanceledOnPipeReader()
            {
                return "Read was canceled on underlying PipeReader.";
            }
            static /*string */ get ReaderAndWriterHasToBeCompleted()
            {
                return "Both reader and writer has to be completed to be able to reset the pipe.";
            }
            static /*string */ get ReadingAfterCompleted()
            {
                return "Reading is not allowed after reader was completed.";
            }
            static /*string */ get ReadingIsInProgress()
            {
                return "Reading is already in progress.";
            }
            static /*string */ get WritingAfterCompleted()
            {
                return "Writing is not allowed after writer was completed.";
            }
            static /*string */ get UnflushedBytesNotSupported()
            {
                return "UnflushedBytes is not supported.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sipl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sipl.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sipl.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sipl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sipl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sipl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2463739;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2463739}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.Pipe", ($self) => class Pipe extends $.$spc.System.Object
        {
            static $_DefaultPipeReader;
            static get DefaultPipeReader()
            {
                let $cls = $.$sipl.System.IO.Pipelines.Pipe;
                return $cls.$_DefaultPipeReader ??= $asm.$ncls("$sipl.System.IO.Pipelines.Pipe.DefaultPipeReader", ($self) => class DefaultPipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
                {
                    /*Pipe*/ _pipe = null;
                    $ctor$2(/*Pipe*/ pipe)
                    {
                        super.$ctor$1();
                        {
                            this._pipe = pipe;
                        }
                        return this;
                    }
                    /*bool */ TryRead(/*out ReadResult*/ result)
                    {
                        return this._pipe.TryRead(result);
                    }
                    /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.ReadAsync(cancellationToken);
                    }
                    /*ValueTask<ReadResult> */ ReadAtLeastAsyncCore(/*int*/ minimumBytes, /*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.ReadAtLeastAsync(minimumBytes, cancellationToken);
                    }
                    /*void */ AdvanceTo(/*SequencePosition*/ consumed)
                    {
                        return this._pipe.AdvanceReader($.$ref(() => consumed, ));
                    }
                    /*void */ AdvanceTo$1(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
                    {
                        return this._pipe.AdvanceReader$1($.$ref(() => consumed, ), $.$ref(() => examined, ));
                    }
                    /*void */ CancelPendingRead()
                    {
                        return this._pipe.CancelPendingRead();
                    }
                    /*void */ Complete(/*Exception?*/ exception)
                    {
                        return this._pipe.CompleteReader(exception);
                    }
                    /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
                    {
                        return this._pipe.OnWriterCompleted(callback, state);
                    }
                    /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
                    {
                        return this._pipe.GetReadAsyncStatus();
                    }
                    /*ReadResult */ GetResult(/*short*/ token)
                    {
                        return this._pipe.GetReadAsyncResult();
                    }
                    /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
                    {
                        return this._pipe.OnReadAsyncCompleted(continuation, state, flags);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.GetStatus(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetStatus()
                    {
                        return this.GetStatus(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$OnCompleted()
                    {
                        return this.OnCompleted(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.GetResult(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetResult()
                    {
                        return this.GetResult(...arguments);
                    }
                    static $h = 694267;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1415163,"m":[{"r":262145,"p":[{"n":"result","p":1742843,"f":2}],"n":"TryRead","d":694267,"h":12885596155,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":694267,"h":17180563451,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumBytes","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAtLeastAsyncCore","d":694267,"h":21475530747,"f":32772},{"r":65537,"p":[{"n":"consumed","p":1226203}],"n":"AdvanceTo","d":694267,"h":25770498043,"f":32769},{"r":65537,"p":[{"n":"consumed","p":1226203},{"n":"examined","p":1226203}],"n":"AdvanceTo","o":"@$1","d":694267,"h":30065465339,"f":32769},{"r":65537,"n":"CancelPendingRead","d":694267,"h":34360432635,"f":32769},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":694267,"h":38655399931,"f":32769},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":694267,"h":42950367227,"f":32769},{"r":133038081,"p":[{"n":"token","p":524289}],"n":"GetStatus","d":694267,"h":47245334523,"f":1},{"r":1742843,"p":[{"n":"token","p":524289}],"n":"GetResult","d":694267,"h":51540301819,"f":1},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"token","p":524289},{"n":"flags","p":132972545}],"n":"OnCompleted","d":694267,"h":55835269115,"f":1}],"l":[{"t":628731,"n":"_pipe","d":694267,"h":4295661563,"f":2}],"c":[{"p":[{"n":"pipe","p":628731}],"n":".ctor","o":"$ctor$2","d":694267,"h":8590628859,"f":1}],"i":[$.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.ReadResult).$h],"d":628731,"h":694267}; }
                    static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.ReadResult) ]; }
                    static get $fullName() { return `System.IO.Pipelines.Pipe.DefaultPipeReader`; }
                }, $cls, ($v) => $cls.$_DefaultPipeReader = $v);
            }
            static $_DefaultPipeWriter;
            static get DefaultPipeWriter()
            {
                let $cls = $.$sipl.System.IO.Pipelines.Pipe;
                return $cls.$_DefaultPipeWriter ??= $asm.$ncls("$sipl.System.IO.Pipelines.Pipe.DefaultPipeWriter", ($self) => class DefaultPipeWriter extends $.$sipl.System.IO.Pipelines.PipeWriter
                {
                    /*Pipe*/ _pipe = null;
                    $ctor$2(/*Pipe*/ pipe)
                    {
                        super.$ctor$1();
                        {
                            this._pipe = pipe;
                        }
                        return this;
                    }
                    /*void */ Complete(/*Exception?*/ exception)
                    {
                        return this._pipe.CompleteWriter(exception);
                    }
                    /*void */ CancelPendingFlush()
                    {
                        return this._pipe.CancelPendingFlush();
                    }
                    /*bool */ get CanGetUnflushedBytes()
                    {
                        return true;
                    }
                    /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
                    {
                        return this._pipe.OnReaderCompleted(callback, state);
                    }
                    /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.FlushAsync(cancellationToken);
                    }
                    /*void */ Advance(/*int*/ bytes)
                    {
                        return this._pipe.Advance(bytes);
                    }
                    /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
                    {
                        return this._pipe.GetMemory(sizeHint);
                    }
                    /*Span<byte> */ GetSpan(/*int*/ sizeHint)
                    {
                        return this._pipe.GetSpan(sizeHint);
                    }
                    /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
                    {
                        return this._pipe.GetFlushAsyncStatus();
                    }
                    /*FlushResult */ GetResult(/*short*/ token)
                    {
                        return this._pipe.GetFlushAsyncResult();
                    }
                    /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
                    {
                        return this._pipe.OnFlushAsyncCompleted(continuation, state, flags);
                    }
                    /*long */ get UnflushedBytes()
                    {
                        return this._pipe.GetUnflushedBytes();
                    }
                    /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.WriteAsync(source, cancellationToken);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.GetStatus(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetStatus()
                    {
                        return this.GetStatus(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$OnCompleted()
                    {
                        return this.OnCompleted(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.GetResult(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetResult()
                    {
                        return this.GetResult(...arguments);
                    }
                    static $h = 759803;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1611771,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770563579,"f":32769},"n":"CanGetUnflushedBytes","d":759803,"h":21475596283,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68720236539,"f":32769},"n":"UnflushedBytes","d":759803,"h":64425269243,"f":32769}],"m":[{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":759803,"h":12885661691,"f":32769},{"r":65537,"n":"CancelPendingFlush","d":759803,"h":17180628987,"f":32769},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":759803,"h":30065530875,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","d":759803,"h":34360498171,"f":32769},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":759803,"h":38655465467,"f":32769},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":759803,"h":42950432763,"f":32769},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":759803,"h":47245400059,"f":32769},{"r":133038081,"p":[{"n":"token","p":524289}],"n":"GetStatus","d":759803,"h":51540367355,"f":1},{"r":432123,"p":[{"n":"token","p":524289}],"n":"GetResult","d":759803,"h":55835334651,"f":1},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"token","p":524289},{"n":"flags","p":132972545}],"n":"OnCompleted","d":759803,"h":60130301947,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","d":759803,"h":73015203835,"f":32769}],"l":[{"t":628731,"n":"_pipe","d":759803,"h":4295727099,"f":2}],"c":[{"p":[{"n":"pipe","p":628731}],"n":".ctor","o":"$ctor$2","d":759803,"h":8590694395,"f":1}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h,$.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.FlushResult).$h],"d":628731,"h":759803}; }
                    static get $b() { return $.$sipl.System.IO.Pipelines.PipeWriter; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte), $.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.FlushResult) ]; }
                    static get $fullName() { return `System.IO.Pipelines.Pipe.DefaultPipeWriter`; }
                }, $cls, ($v) => $cls.$_DefaultPipeWriter = $v);
            }
            /*Action<object?>*/ static s_signalReaderAwaitable = null;
            /*Action<object?>*/ static s_signalWriterAwaitable = null;
            /*Action<object?>*/ static s_invokeCompletionCallbacks = null;
            /*ContextCallback*/ static s_executionContextRawCallback = null;
            /*SendOrPostCallback*/ static s_syncContextExecutionContextCallback = null;
            /*SendOrPostCallback*/ static s_syncContextExecuteWithoutExecutionContextCallback = null;
            /*Action<object?>*/ static s_scheduleWithExecutionContextCallback = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*DefaultPipeReader*/ _reader = null;
            /*DefaultPipeWriter*/ _writer = null;
            /*PipeOptions*/ _options = null;
            /*object*/ _sync = null;
            /*bool */ get UseSynchronizationContext()
            {
                return this._options.UseSynchronizationContext;
            }
            /*int */ get MinimumSegmentSize()
            {
                return this._options.MinimumSegmentSize;
            }
            /*long */ get PauseWriterThreshold()
            {
                return this._options.PauseWriterThreshold;
            }
            /*long */ get ResumeWriterThreshold()
            {
                return this._options.ResumeWriterThreshold;
            }
            /*PipeScheduler */ get ReaderScheduler()
            {
                return this._options.ReaderScheduler;
            }
            /*PipeScheduler */ get WriterScheduler()
            {
                return this._options.WriterScheduler;
            }
            /*object */ get SyncObj()
            {
                return this._sync;
            }
            /*long*/ _unconsumedBytes = 0n;
            /*long*/ _unflushedBytes = 0n;
            /*PipeAwaitable*/ _readerAwaitable;
            /*PipeAwaitable*/ _writerAwaitable;
            /*PipeCompletion*/ _writerCompletion;
            /*PipeCompletion*/ _readerCompletion;
            /*long*/ _lastExaminedIndex = -1n;
            /*BufferSegment?*/ _readHead = null;
            /*int*/ _readHeadIndex = 0;
            /*bool*/ _disposed = false;
            /*BufferSegment?*/ _readTail = null;
            /*int*/ _readTailIndex = 0;
            /*int*/ _minimumReadBytes = 0;
            /*BufferSegment?*/ _writingHead = null;
            /*Memory<byte>*/ _writingHeadMemory;
            /*int*/ _writingHeadBytesBuffered = 0;
            /*PipeOperationState*/ _operationState;
            /*long */ get Length()
            {
                return this._unconsumedBytes;
            }
            $ctor$1()
            {
                this.$ctor$2($.$sipl.System.IO.Pipelines.PipeOptions.Default);
                {
                }
                return this;
            }
            $ctor$2(/*PipeOptions*/ options)
            {
                super.$ctor();
                {
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$2(options.InitialSegmentPoolSize);
                    this._operationState = new $.$sipl.System.IO.Pipelines.PipeOperationState();
                    this._readerCompletion = new $.$sipl.System.IO.Pipelines.PipeCompletion();
                    this._writerCompletion = new $.$sipl.System.IO.Pipelines.PipeCompletion();
                    this._options = options;
                    this._readerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(false, this.UseSynchronizationContext);
                    this._writerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(true, this.UseSynchronizationContext);
                    this._reader = new $.$sipl.System.IO.Pipelines.Pipe.DefaultPipeReader().$ctor$2(this);
                    this._writer = new $.$sipl.System.IO.Pipelines.Pipe.DefaultPipeWriter().$ctor$2(this);
                }
                return this;
            }
            /*void */ ResetState()
            {
                this._readerCompletion.Reset();
                this._writerCompletion.Reset();
                this._readerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(false, this.UseSynchronizationContext);
                this._writerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(true, this.UseSynchronizationContext);
                this._readTailIndex = 0;
                this._readHeadIndex = 0;
                this._lastExaminedIndex = BigInt(-1);
                this._unflushedBytes = 0n;
                this._unconsumedBytes = 0n;
            }
            /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateWriteHeadIfNeeded(sizeHint);
                return this._writingHeadMemory;
            }
            /*Span<byte> */ GetSpan(/*int*/ sizeHint)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateWriteHeadIfNeeded(sizeHint);
                return this._writingHeadMemory.Span;
            }
            /*void */ AllocateWriteHeadIfNeeded(/*int*/ sizeHint)
            {
                if (!this._operationState.IsWritingActive || this._writingHeadMemory.Length === 0 || this._writingHeadMemory.Length < sizeHint)
                {
                    this.AllocateWriteHeadSynchronized(sizeHint);
                }
            }
            /*void */ AllocateWriteHeadSynchronized(/*int*/ sizeHint)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._operationState.BeginWrite();
                        if (this._writingHead === null)
                        {
                            /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                            this._writingHead = this._readHead = this._readTail = newSegment;
                            this._lastExaminedIndex = 0n;
                        }
                        else 
                        {
                            /*int*/ let bytesLeftInBuffer = this._writingHeadMemory.Length;
                            if (bytesLeftInBuffer === 0 || bytesLeftInBuffer < sizeHint)
                            {
                                if (this._writingHeadBytesBuffered > 0)
                                {
                                    this._writingHead.End += this._writingHeadBytesBuffered;
                                    this._writingHeadBytesBuffered = 0;
                                }
                                if (this._writingHead.Length === 0)
                                {
                                    this._writingHead.ResetMemory();
                                    this.RentMemory(this._writingHead, sizeHint);
                                }
                                else 
                                {
                                    /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                                    this._writingHead.SetNext(newSegment);
                                    this._writingHead = newSegment;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*BufferSegment */ AllocateSegment(/*int*/ sizeHint)
            {
                /*BufferSegment*/ let newSegment = this.CreateSegmentUnsynchronized();
                this.RentMemory(newSegment, sizeHint);
                return newSegment;
            }
            /*void */ RentMemory(/*BufferSegment*/ segment, /*int*/ sizeHint)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment.MemoryOwner === null, "segment.MemoryOwner is null");
                $.$spc.System.Diagnostics.Debug.Assert$1(sizeHint >= 0, "sizeHint >= 0");
                /*MemoryPool<byte>?*/ let pool = null;
                /*int*/ let maxSize = -1;
                if (!this._options.IsDefaultSharedMemoryPool)
                {
                    pool = this._options.Pool;
                    maxSize = pool.MaxBufferSize;
                }
                if (sizeHint <= maxSize)
                {
                    segment.SetOwnedMemory(pool.Rent(this.GetSegmentSize(sizeHint, maxSize)));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(sizeHint, 2147483647);
                    segment.SetOwnedMemory$1($.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(sizeToRequest));
                }
                this._writingHeadMemory = segment.AvailableMemory;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$spc.System.Math.Max$4(this.MinimumSegmentSize, sizeHint);
                /*int*/ let adjustedToMaximumSize = $.$spc.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readHead, "Returning _readHead segment that's in use!");
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readTail, "Returning _readTail segment that's in use!");
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._writingHead, "Returning _writingHead segment that's in use!");
                if (this._bufferSegmentPool.Count < this._options.MaxSegmentPoolSize)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*bool */ CommitUnsynchronized()
            {
                this._operationState.EndWrite();
                if (this._unflushedBytes === 0n)
                {
                    return false;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writingHead !== null, "_writingHead != null");
                this._writingHead.End += this._writingHeadBytesBuffered;
                this._readTail = this._writingHead;
                this._readTailIndex = this._writingHead.End;
                /*long*/ let oldLength = this._unconsumedBytes;
                this._unconsumedBytes += this._unflushedBytes;
                /*bool*/ let resumeReader = true;
                if (this._unconsumedBytes < BigInt(this._minimumReadBytes))
                {
                    resumeReader = false;
                }
                else if (this.PauseWriterThreshold > 0n && oldLength < this.PauseWriterThreshold && this._unconsumedBytes >= this.PauseWriterThreshold && !this._readerCompletion.IsCompleted)
                {
                    this._writerAwaitable.SetUncompleted();
                }
                this._unflushedBytes = 0n;
                this._writingHeadBytesBuffered = 0;
                return resumeReader;
            }
            /*void */ Advance(/*int*/ bytes)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if ((bytes >>> 0) > (this._writingHeadMemory.Length >>> 0))
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.bytes*/);
                        }
                        if (this._readerCompletion.IsCompleted)
                        {
                            return;
                        }
                        this.AdvanceCore(bytes);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*void */ AdvanceCore(/*int*/ bytesWritten)
            {
                this._unflushedBytes += BigInt(bytesWritten);
                this._writingHeadBytesBuffered += bytesWritten;
                this._writingHeadMemory = this._writingHeadMemory.Slice(bytesWritten);
            }
            /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.FlushResult, cancellationToken));
                }
                /*CompletionData*/ let completionData;
                /*ValueTask<FlushResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this.PrepareFlushUnsynchronized($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => result, ($v) => result = $v, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)), cancellationToken);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
                return result;
            }
            /*void */ PrepareFlushUnsynchronized(/*out CompletionData*/ completionData, /*out ValueTask<FlushResult>*/ result, /*CancellationToken*/ cancellationToken)
            {
                /*var*/ let completeReader = this.CommitUnsynchronized();
                this._writerAwaitable.BeginOperation(cancellationToken, $.$sipl.System.IO.Pipelines.Pipe.s_signalWriterAwaitable, this);
                if (this._writerAwaitable.IsCompleted)
                {
                    /*FlushResult*/ let flushResult = new $.$sipl.System.IO.Pipelines.FlushResult();
                    this.GetFlushResult($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sipl.System.IO.Pipelines.FlushResult, () => flushResult, ($v) => flushResult = $v, null));
                    result.$v = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(flushResult.Clone());
                }
                else 
                {
                    result.$v = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$4(this._writer, 0);
                }
                if (completeReader)
                {
                    this._readerAwaitable.Complete(completionData);
                }
                else 
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writerAwaitable.IsCompleted || this._readerAwaitable.IsCompleted, "_writerAwaitable.IsCompleted || _readerAwaitable.IsCompleted");
            }
            /*void */ CompleteWriter(/*Exception?*/ exception)
            {
                /*CompletionData*/ let completionData;
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                /*bool*/ let readerCompleted;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this.CommitUnsynchronized();
                        completionCallbacks = this._writerCompletion.TryComplete(exception);
                        this._readerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        readerCompleted = this._readerCompletion.IsCompleted;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (readerCompleted)
                {
                    this.CompletePipe();
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.ReaderScheduler, completionCallbacks);
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ AdvanceReader(/*in SequencePosition*/ consumed)
            {
                this.AdvanceReader$1(consumed, consumed);
            }
            /*void */ AdvanceReader$1(/*in SequencePosition*/ consumed, /*in SequencePosition*/ examined)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                this.AdvanceReader$2($.$cast(consumed.$v.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), consumed.$v.GetInteger(), $.$cast(examined.$v.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), examined.$v.GetInteger());
            }
            /*void */ AdvanceReader$2(/*BufferSegment?*/ consumedSegment, /*int*/ consumedIndex, /*BufferSegment?*/ examinedSegment, /*int*/ examinedIndex)
            {
                if (consumedSegment !== null && examinedSegment !== null && $.$sipl.System.IO.Pipelines.BufferSegment.GetLength(consumedSegment, consumedIndex, examinedSegment, examinedIndex) < 0n)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition();
                }
                /*BufferSegment?*/ let returnStart = null;
                /*BufferSegment?*/ let returnEnd = null;
                /*CompletionData*/ let completionData = new $.$sipl.System.IO.Pipelines.CompletionData();
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        /*var*/ let examinedEverything = false;
                        if (examinedSegment === this._readTail)
                        {
                            examinedEverything = examinedIndex === this._readTailIndex;
                        }
                        if (examinedSegment !== null && this._lastExaminedIndex >= 0n)
                        {
                            /*long*/ let examinedBytes = $.$sipl.System.IO.Pipelines.BufferSegment.GetLength$1(this._lastExaminedIndex, examinedSegment, examinedIndex);
                            /*long*/ let oldLength = this._unconsumedBytes;
                            this._unconsumedBytes -= examinedBytes;
                            this._lastExaminedIndex = examinedSegment.RunningIndex + BigInt(examinedIndex);
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._unconsumedBytes >= 0n, "Length has gone negative");
                            $.$spc.System.Diagnostics.Debug.Assert$1(this.ResumeWriterThreshold >= 1n, "ResumeWriterThreshold is less than 1");
                            if (oldLength >= this.ResumeWriterThreshold && this._unconsumedBytes < this.ResumeWriterThreshold)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(examinedBytes > 0n, "examinedBytes > 0");
                                this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                            }
                        }
                        if (consumedSegment !== null)
                        {
                            if (this._readHead === null)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AdvanceToInvalidCursor();
                                return;
                            }
                            returnStart = this._readHead;
                            returnEnd = consumedSegment;
                            /*void*/  function MoveReturnEndToNextBlock()
                            {
                                /*BufferSegment?*/ let nextBlock = returnEnd.NextSegment;
                                if (this._readTail === returnEnd)
                                {
                                    this._readTail = nextBlock;
                                    this._readTailIndex = 0;
                                }
                                this._readHead = nextBlock;
                                this._readHeadIndex = 0;
                                returnEnd = nextBlock;
                            }
                            if (consumedIndex === returnEnd.Length)
                            {
                                if (this._writingHead !== returnEnd)
                                {
                                    MoveReturnEndToNextBlock.call(this);
                                }
                                else if (this._writingHeadBytesBuffered === 0 && !this._operationState.IsWritingActive)
                                {
                                    this._writingHead = null;
                                    this._writingHeadMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                                    MoveReturnEndToNextBlock.call(this);
                                }
                                else 
                                {
                                    this._readHead = consumedSegment;
                                    this._readHeadIndex = consumedIndex;
                                }
                            }
                            else 
                            {
                                this._readHead = consumedSegment;
                                this._readHeadIndex = consumedIndex;
                            }
                        }
                        if (examinedEverything && !this._writerCompletion.IsCompleted)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._writerAwaitable.IsCompleted, "PipeWriter.FlushAsync isn't completed and will deadlock");
                            this._readerAwaitable.SetUncompleted();
                        }
                        while(returnStart !== null && returnStart !== returnEnd)
                        {
                            /*BufferSegment?*/ let next = returnStart.NextSegment;
                            returnStart.Reset();
                            this.ReturnSegmentUnsynchronized(returnStart);
                            returnStart = next;
                        }
                        this._operationState.EndRead();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ CompleteReader(/*Exception?*/ exception)
            {
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                /*CompletionData*/ let completionData;
                /*bool*/ let writerCompleted;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (this._operationState.IsReadingActive)
                        {
                            this._operationState.EndRead();
                        }
                        completionCallbacks = this._readerCompletion.TryComplete(exception);
                        this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        writerCompleted = this._writerCompletion.IsCompleted;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (writerCompleted)
                {
                    this.CompletePipe();
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.WriterScheduler, completionCallbacks);
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                if (callback === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.callback*/);
                }
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        completionCallbacks = this._writerCompletion.AddCallback(callback, state);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.ReaderScheduler, completionCallbacks);
                }
            }
            /*void */ CancelPendingRead()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.Cancel($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ CancelPendingFlush()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._writerAwaitable.Cancel($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                if (callback === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.callback*/);
                }
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        completionCallbacks = this._readerCompletion.AddCallback(callback, state);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.WriterScheduler, completionCallbacks);
                }
            }
            /*ValueTask<ReadResult> */ ReadAtLeastAsync(/*int*/ minimumBytes, /*CancellationToken*/ token)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                if (token.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.ReadResult, token));
                }
                /*CompletionData*/ let completionData = new $.$sipl.System.IO.Pipelines.CompletionData();
                /*ValueTask<ReadResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        if (this._readerAwaitable.IsCompleted)
                        {
                            /*ReadResult*/ let readResult;
                            this.GetReadResult($.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                            if (this._unconsumedBytes >= BigInt(minimumBytes) || readResult.IsCanceled || readResult.IsCompleted)
                            {
                                return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(readResult);
                            }
                            this._readerAwaitable.SetUncompleted();
                            this._operationState.EndRead();
                            this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        }
                        if (!this._writerAwaitable.IsCompleted)
                        {
                            this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        }
                        this._minimumReadBytes = minimumBytes;
                        result = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$4(this._reader, 0);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, undefined, $.$sipl.System.IO.Pipelines.CompletionData));
                return result;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ token)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                if (token.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.ReadResult, token));
                }
                /*ValueTask<ReadResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        if (this._readerAwaitable.IsCompleted)
                        {
                            /*ReadResult*/ let readResult;
                            this.GetReadResult($.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                            result = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(readResult);
                        }
                        else 
                        {
                            result = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$4(this._reader, 0);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                return result;
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (this._readerCompletion.IsCompleted)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                        }
                        if (this._unconsumedBytes > 0n || this._readerAwaitable.IsCompleted)
                        {
                            this.GetReadResult(result);
                            return true;
                        }
                        if (this._readerAwaitable.IsRunning)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                        }
                        this._operationState.BeginReadTentative();
                        result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                        return false;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            static /*void */ ScheduleCallbacks(/*PipeScheduler*/ scheduler, /*PipeCompletionCallbacks*/ completionCallbacks)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(completionCallbacks !== null, "completionCallbacks != null");
                scheduler.UnsafeSchedule($.$sipl.System.IO.Pipelines.Pipe.s_invokeCompletionCallbacks, completionCallbacks);
            }
            static /*void */ TrySchedule(/*PipeScheduler*/ scheduler, /*in CompletionData*/ completionData)
            {
                /*Action<object?>*/ let completion = completionData.$v.Completion;
                if (completion === null)
                {
                    return;
                }
                if (completionData.$v.SynchronizationContext === null && completionData.$v.ExecutionContext === null)
                {
                    scheduler.UnsafeSchedule(completion, completionData.$v.CompletionState);
                }
                else 
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleWithContext(scheduler, completionData);
                }
            }
            static /*void */ ScheduleWithContext(/*PipeScheduler*/ scheduler, /*in CompletionData*/ completionData)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(completionData.$v.SynchronizationContext !== null || completionData.$v.ExecutionContext !== null, "completionData.SynchronizationContext != null || completionData.ExecutionContext != null");
                if (completionData.$v.SynchronizationContext === null)
                {
                    scheduler.UnsafeSchedule($.$sipl.System.IO.Pipelines.Pipe.s_scheduleWithExecutionContextCallback, completionData.$v);
                }
                else 
                {
                    if (completionData.$v.ExecutionContext === null)
                    {
                        completionData.$v.SynchronizationContext.Post($.$sipl.System.IO.Pipelines.Pipe.s_syncContextExecuteWithoutExecutionContextCallback, completionData.$v);
                    }
                    else 
                    {
                        completionData.$v.SynchronizationContext.Post($.$sipl.System.IO.Pipelines.Pipe.s_syncContextExecutionContextCallback, completionData.$v);
                    }
                }
            }
            static /*void */ ExecuteWithoutExecutionContext(/*object*/ state)
            {
                /*CompletionData*/ let completionData = $.$cast(state, $.$sipl.System.IO.Pipelines.CompletionData);
                completionData.Completion.Invoke(completionData.CompletionState);
            }
            static /*void */ ExecuteWithExecutionContext(/*object*/ state)
            {
                /*CompletionData*/ let completionData = $.$cast(state, $.$sipl.System.IO.Pipelines.CompletionData);
                $.$spc.System.Diagnostics.Debug.Assert$1(completionData.ExecutionContext !== null, "completionData.ExecutionContext != null");
                $.$spc.System.Threading.ExecutionContext.Run(completionData.ExecutionContext, $.$sipl.System.IO.Pipelines.Pipe.s_executionContextRawCallback, state);
            }
            /*void */ CompletePipe()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        this._disposed = true;
                        /*BufferSegment?*/ let segment = this._readHead ?? this._readTail;
                        while(segment !== null)
                        {
                            /*BufferSegment*/ let returnSegment = segment;
                            segment = segment.NextSegment;
                            returnSegment.Reset();
                        }
                        this._writingHead = null;
                        this._writingHeadMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                        this._readHead = null;
                        this._readTail = null;
                        this._lastExaminedIndex = BigInt(-1);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*ValueTaskSourceStatus */ GetReadAsyncStatus()
            {
                if (this._readerAwaitable.IsCompleted)
                {
                    if (this._writerCompletion.IsFaulted)
                    {
                        return 2/*ValueTaskSourceStatus.Faulted*/;
                    }
                    return 1/*ValueTaskSourceStatus.Succeeded*/;
                }
                return 0/*ValueTaskSourceStatus.Pending*/;
            }
            /*void */ OnReadAsyncCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                /*CompletionData*/ let completionData;
                /*bool*/ let doubleCompletion;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.OnCompleted(continuation, state, flags, $.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => doubleCompletion, ($v) => doubleCompletion = $v, $.$spc.System.Boolean));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (doubleCompletion)
                {
                    this.Writer.Complete($.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation());
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*ReadResult */ GetReadAsyncResult()
            {
                /*ReadResult*/ let result;
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                /*CancellationToken*/ let cancellationToken = new $.$spc.System.Threading.CancellationToken();
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                        {
                            if (!this._readerAwaitable.IsCompleted)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_GetResultNotCompleted();
                            }
                            cancellationTokenRegistration = this._readerAwaitable.ReleaseCancellationTokenRegistration($.$ref(() => cancellationToken, ($v) => cancellationToken = $v, $.$spc.System.Threading.CancellationToken));
                            this.GetReadResult($.$ref(() => result, ($v) => result = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                    }
                }
                finally
                {
                    {
                        cancellationTokenRegistration.Dispose();
                    }
                }
                if (result.IsCanceled)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                }
                return result;
            }
            /*void */ GetReadResult(/*out ReadResult*/ result)
            {
                /*bool*/ let isCompleted = this._writerCompletion.IsCompletedOrThrow();
                /*bool*/ let isCanceled = this._readerAwaitable.ObserveCancellation();
                /*BufferSegment?*/ let head = this._readHead;
                if (head !== null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readTail !== null, "_readTail != null");
                    /*var*/ let readOnlySequence = new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))().$ctor$3(head, this._readHeadIndex, this._readTail, this._readTailIndex);
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(readOnlySequence, isCanceled, isCompleted);
                }
                else 
                {
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))(), isCanceled, isCompleted);
                }
                if (isCanceled)
                {
                    this._operationState.BeginReadTentative();
                }
                else 
                {
                    this._operationState.BeginRead();
                }
                this._minimumReadBytes = 0;
            }
            /*ValueTaskSourceStatus */ GetFlushAsyncStatus()
            {
                if (this._writerAwaitable.IsCompleted)
                {
                    if (this._readerCompletion.IsFaulted)
                    {
                        return 2/*ValueTaskSourceStatus.Faulted*/;
                    }
                    return 1/*ValueTaskSourceStatus.Succeeded*/;
                }
                return 0/*ValueTaskSourceStatus.Pending*/;
            }
            /*FlushResult */ GetFlushAsyncResult()
            {
                /*FlushResult*/ let result = new $.$sipl.System.IO.Pipelines.FlushResult();
                /*CancellationToken*/ let cancellationToken = new $.$spc.System.Threading.CancellationToken();
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                        {
                            if (!this._writerAwaitable.IsCompleted)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_GetResultNotCompleted();
                            }
                            this.GetFlushResult($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sipl.System.IO.Pipelines.FlushResult, () => result, ($v) => result = $v, null));
                            cancellationTokenRegistration = this._writerAwaitable.ReleaseCancellationTokenRegistration($.$ref(() => cancellationToken, ($v) => cancellationToken = $v, $.$spc.System.Threading.CancellationToken));
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                    }
                }
                finally
                {
                    {
                        cancellationTokenRegistration.Dispose();
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                }
                return result;
            }
            /*long */ GetUnflushedBytes()
            {
                return this._unflushedBytes;
            }
            /*void */ GetFlushResult(/*ref FlushResult*/ result)
            {
                if (this._writerAwaitable.ObserveCancellation())
                {
                    result.$v._resultFlags |= 1/*ResultFlags.Canceled*/;
                }
                if (this._readerCompletion.IsCompletedOrThrow())
                {
                    result.$v._resultFlags |= 2/*ResultFlags.Completed*/;
                }
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (this._readerCompletion.IsCompletedOrThrow())
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, true));
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.FlushResult, cancellationToken));
                }
                /*CompletionData*/ let completionData;
                /*ValueTask<FlushResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this.AllocateWriteHeadIfNeeded(0);
                        if (source.Length <= this._writingHeadMemory.Length)
                        {
                            source.CopyTo(this._writingHeadMemory);
                            this.AdvanceCore(source.Length);
                        }
                        else 
                        {
                            this.WriteMultiSegment(source.Span);
                        }
                        this.PrepareFlushUnsynchronized($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => result, ($v) => result = $v, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)), cancellationToken);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
                return result;
            }
            /*void */ WriteMultiSegment(/*ReadOnlySpan<byte>*/ source)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writingHead !== null, "_writingHead != null");
                /*Span<byte>*/ let destination = this._writingHeadMemory.Span;
                while(true)
                {
                    /*int*/ let writable = $.$spc.System.Math.Min$4(destination.Length, source.Length);
                    source.Slice$1(0, writable).CopyTo(destination);
                    source = source.Slice(writable);
                    this.AdvanceCore(writable);
                    if (source.Length === 0)
                    {
                        break;
                    }
                    this._writingHead.End += this._writingHeadBytesBuffered;
                    this._writingHeadBytesBuffered = 0;
                    /*BufferSegment*/ let newSegment = this.AllocateSegment(0);
                    this._writingHead.SetNext(newSegment);
                    this._writingHead = newSegment;
                    destination = this._writingHeadMemory.Span;
                }
            }
            /*void */ OnFlushAsyncCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                /*CompletionData*/ let completionData;
                /*bool*/ let doubleCompletion;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._writerAwaitable.OnCompleted(continuation, state, flags, $.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => doubleCompletion, ($v) => doubleCompletion = $v, $.$spc.System.Boolean));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (doubleCompletion)
                {
                    this.Reader.Complete($.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation());
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ ReaderCancellationRequested()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.CancellationTokenFired($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ WriterCancellationRequested()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._writerAwaitable.CancellationTokenFired($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*PipeReader */ get Reader()
            {
                return this._reader;
            }
            /*PipeWriter */ get Writer()
            {
                return this._writer;
            }
            /*void */ Reset()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (!this._disposed)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_ResetIncompleteReaderWriter();
                        }
                        this._disposed = false;
                        this.ResetState();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
                this._sync = new $.$spc.System.Object().$ctor();
                this._readerAwaitable = $.$default($.$sipl.System.IO.Pipelines.PipeAwaitable);
                this._writerAwaitable = $.$default($.$sipl.System.IO.Pipelines.PipeAwaitable);
                this._writerCompletion = $.$default($.$sipl.System.IO.Pipelines.PipeCompletion);
                this._readerCompletion = $.$default($.$sipl.System.IO.Pipelines.PipeCompletion);
                this._writingHeadMemory = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
                this._operationState = $.$default($.$sipl.System.IO.Pipelines.PipeOperationState);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_signalReaderAwaitable = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.Pipe)).ReaderCancellationRequested();
                    });
                }
                {
                    this.s_signalWriterAwaitable = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.Pipe)).WriterCancellationRequested();
                    });
                }
                {
                    this.s_invokeCompletionCallbacks = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.PipeCompletionCallbacks)).Execute();
                    });
                }
                {
                    this.s_executionContextRawCallback = new $.$spc.System.Threading.ContextCallback().$ctor(null, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithoutExecutionContext);
                }
                {
                    this.s_syncContextExecutionContextCallback = new $.$spc.System.Threading.SendOrPostCallback().$ctor(null, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithExecutionContext);
                }
                {
                    this.s_syncContextExecuteWithoutExecutionContextCallback = new $.$spc.System.Threading.SendOrPostCallback().$ctor(null, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithoutExecutionContext);
                }
                {
                    this.s_scheduleWithExecutionContextCallback = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(null, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithExecutionContext);
                }
            }
            static $h = 628731;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":68720105467,"f":2},"n":"UseSynchronizationContext","d":628731,"h":64425138171,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":77310040059,"f":2},"n":"MinimumSegmentSize","d":628731,"h":73015072763,"f":2},{"p":917505,"g":{"r":0,"d":0,"h":85899974651,"f":2},"n":"PauseWriterThreshold","d":628731,"h":81605007355,"f":2},{"p":917505,"g":{"r":0,"d":0,"h":94489909243,"f":2},"n":"ResumeWriterThreshold","d":628731,"h":90194941947,"f":2},{"p":1546235,"g":{"r":0,"d":0,"h":103079843835,"f":2},"n":"ReaderScheduler","d":628731,"h":98784876539,"f":2},{"p":1546235,"g":{"r":0,"d":0,"h":111669778427,"f":2},"n":"WriterScheduler","d":628731,"h":107374811131,"f":2},{"p":131073,"g":{"r":0,"d":0,"h":120259713019,"f":2},"n":"SyncObj","d":628731,"h":115964745723,"f":2},{"p":917505,"g":{"r":0,"d":0,"h":201864091643,"f":8},"n":"Length","d":628731,"h":197569124347,"f":8},{"p":1415163,"g":{"r":0,"d":0,"h":416612456443,"f":1},"n":"Reader","d":628731,"h":412317489147,"f":1},{"p":1611771,"g":{"r":0,"d":0,"h":425202391035,"f":1},"n":"Writer","d":628731,"h":420907423739,"f":1}],"m":[{"r":65537,"n":"ResetState","d":628731,"h":214748993531,"f":2},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361}],"n":"GetMemory","d":628731,"h":219043960827,"f":8},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361}],"n":"GetSpan","d":628731,"h":223338928123,"f":8},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateWriteHeadIfNeeded","d":628731,"h":227633895419,"f":2},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateWriteHeadSynchronized","d":628731,"h":231928862715,"f":2},{"r":104443,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateSegment","d":628731,"h":236223830011,"f":2},{"r":65537,"p":[{"n":"segment","p":104443},{"n":"sizeHint","p":655361}],"n":"RentMemory","d":628731,"h":240518797307,"f":2},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361,"f":65,"v":2147483647}],"n":"GetSegmentSize","d":628731,"h":244813764603,"f":2},{"r":104443,"n":"CreateSegmentUnsynchronized","d":628731,"h":249108731899,"f":2},{"r":65537,"p":[{"n":"segment","p":104443}],"n":"ReturnSegmentUnsynchronized","d":628731,"h":253403699195,"f":2},{"r":262145,"n":"CommitUnsynchronized","d":628731,"h":257698666491,"f":8},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":628731,"h":261993633787,"f":8},{"r":65537,"p":[{"n":"bytesWritten","p":655361}],"n":"AdvanceCore","d":628731,"h":266288601083,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","d":628731,"h":270583568379,"f":8},{"r":65537,"p":[{"n":"completionData","p":301051,"f":2},{"n":"result","p":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"f":2},{"n":"cancellationToken","p":125960193}],"n":"PrepareFlushUnsynchronized","d":628731,"h":274878535675,"f":2},{"r":65537,"p":[{"n":"exception","p":47185921}],"n":"CompleteWriter","d":628731,"h":279173502971,"f":8},{"r":65537,"p":[{"n":"consumed","p":1226203,"f":8}],"n":"AdvanceReader","d":628731,"h":283468470267,"f":8},{"r":65537,"p":[{"n":"consumed","p":1226203,"f":8},{"n":"examined","p":1226203,"f":8}],"n":"AdvanceReader","o":"@$1","d":628731,"h":287763437563,"f":8},{"r":65537,"p":[{"n":"consumedSegment","p":104443},{"n":"consumedIndex","p":655361},{"n":"examinedSegment","p":104443},{"n":"examinedIndex","p":655361}],"n":"AdvanceReader","o":"@$2","d":628731,"h":292058404859,"f":2},{"r":65537,"p":[{"n":"exception","p":47185921}],"n":"CompleteReader","d":628731,"h":296353372155,"f":8},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":628731,"h":300648339451,"f":8},{"r":65537,"n":"CancelPendingRead","d":628731,"h":304943306747,"f":8},{"r":65537,"n":"CancelPendingFlush","d":628731,"h":309238274043,"f":8},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":628731,"h":313533241339,"f":8},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumBytes","p":655361},{"n":"token","p":125960193}],"n":"ReadAtLeastAsync","d":628731,"h":317828208635,"f":8},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"token","p":125960193}],"n":"ReadAsync","d":628731,"h":322123175931,"f":8},{"r":262145,"p":[{"n":"result","p":1742843,"f":2}],"n":"TryRead","d":628731,"h":326418143227,"f":8},{"r":65537,"p":[{"n":"scheduler","p":1546235},{"n":"completionCallbacks","p":1153019}],"n":"ScheduleCallbacks","d":628731,"h":330713110523,"f":34},{"r":65537,"p":[{"n":"scheduler","p":1546235},{"n":"completionData","p":301051,"f":8}],"n":"TrySchedule","d":628731,"h":335008077819,"f":34},{"r":65537,"p":[{"n":"scheduler","p":1546235},{"n":"completionData","p":301051,"f":8}],"n":"ScheduleWithContext","d":628731,"h":339303045115,"f":34},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ExecuteWithoutExecutionContext","d":628731,"h":343598012411,"f":34},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ExecuteWithExecutionContext","d":628731,"h":347892979707,"f":34},{"r":65537,"n":"CompletePipe","d":628731,"h":352187947003,"f":2},{"r":133038081,"n":"GetReadAsyncStatus","d":628731,"h":356482914299,"f":8},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132972545}],"n":"OnReadAsyncCompleted","d":628731,"h":360777881595,"f":8},{"r":1742843,"n":"GetReadAsyncResult","d":628731,"h":365072848891,"f":8},{"r":65537,"p":[{"n":"result","p":1742843,"f":2}],"n":"GetReadResult","d":628731,"h":369367816187,"f":2},{"r":133038081,"n":"GetFlushAsyncStatus","d":628731,"h":373662783483,"f":8},{"r":432123,"n":"GetFlushAsyncResult","d":628731,"h":377957750779,"f":8},{"r":917505,"n":"GetUnflushedBytes","d":628731,"h":382252718075,"f":8},{"r":65537,"p":[{"n":"result","p":432123,"f":4}],"n":"GetFlushResult","d":628731,"h":386547685371,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","d":628731,"h":390842652667,"f":8},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"WriteMultiSegment","d":628731,"h":395137619963,"f":2},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132972545}],"n":"OnFlushAsyncCompleted","d":628731,"h":399432587259,"f":8},{"r":65537,"n":"ReaderCancellationRequested","d":628731,"h":403727554555,"f":2},{"r":65537,"n":"WriterCancellationRequested","d":628731,"h":408022521851,"f":2},{"r":65537,"n":"Reset","d":628731,"h":429497358331,"f":1}],"l":[{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_signalReaderAwaitable","d":628731,"h":12885530619,"f":34},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_signalWriterAwaitable","d":628731,"h":17180497915,"f":34},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_invokeCompletionCallbacks","d":628731,"h":21475465211,"f":34},{"t":126615553,"n":"s_executionContextRawCallback","d":628731,"h":25770432507,"f":34},{"t":130875393,"n":"s_syncContextExecutionContextCallback","d":628731,"h":30065399803,"f":34},{"t":130875393,"n":"s_syncContextExecuteWithoutExecutionContextCallback","d":628731,"h":34360367099,"f":34},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_scheduleWithExecutionContextCallback","d":628731,"h":38655334395,"f":34},{"t":169979,"n":"_bufferSegmentPool","d":628731,"h":42950301691,"f":2},{"t":694267,"n":"_reader","d":628731,"h":47245268987,"f":2},{"t":759803,"n":"_writer","d":628731,"h":51540236283,"f":2},{"t":1349627,"n":"_options","d":628731,"h":55835203579,"f":2},{"t":131073,"n":"_sync","d":628731,"h":60130170875,"f":2},{"t":917505,"n":"_unconsumedBytes","d":628731,"h":124554680315,"f":2},{"t":917505,"n":"_unflushedBytes","d":628731,"h":128849647611,"f":2},{"t":825339,"n":"_readerAwaitable","d":628731,"h":133144614907,"f":2},{"t":825339,"n":"_writerAwaitable","d":628731,"h":137439582203,"f":2},{"t":1021947,"n":"_writerCompletion","d":628731,"h":141734549499,"f":2},{"t":1021947,"n":"_readerCompletion","d":628731,"h":146029516795,"f":2},{"t":917505,"n":"_lastExaminedIndex","d":628731,"h":150324484091,"f":2},{"t":104443,"n":"_readHead","d":628731,"h":154619451387,"f":2},{"t":655361,"n":"_readHeadIndex","d":628731,"h":158914418683,"f":2},{"t":262145,"n":"_disposed","d":628731,"h":163209385979,"f":2},{"t":104443,"n":"_readTail","d":628731,"h":167504353275,"f":2},{"t":655361,"n":"_readTailIndex","d":628731,"h":171799320571,"f":2},{"t":655361,"n":"_minimumReadBytes","d":628731,"h":176094287867,"f":2},{"t":104443,"n":"_writingHead","d":628731,"h":180389255163,"f":2},{"t":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"n":"_writingHeadMemory","d":628731,"h":184684222459,"f":2},{"t":655361,"n":"_writingHeadBytesBuffered","d":628731,"h":188979189755,"f":2},{"t":1218555,"n":"_operationState","d":628731,"h":193274157051,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":628731,"h":206159058939,"f":1},{"p":[{"n":"options","p":1349627}],"n":".ctor","o":"$ctor$2","d":628731,"h":210454026235,"f":1}],"j":[694267,759803],"h":628731}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.Pipe`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeCompletionCallbacks", ($self) => class PipeCompletionCallbacks extends $.$spc.System.Object
        {
            /*List<PipeCompletionCallback>*/ _callbacks = null;
            /*Exception?*/ _exception = null;
            $ctor$1(/*List<PipeCompletionCallback>*/ callbacks, /*ExceptionDispatchInfo?*/ edi)
            {
                super.$ctor();
                {
                    this._callbacks = callbacks;
                    this._exception = (edi?.SourceException ?? null);
                }
                return this;
            }
            /*void */ Execute()
            {
                /*var*/ let count = this._callbacks.Count;
                if (count === 0)
                {
                    return;
                }
                /*List<Exception>?*/ let exceptions = null;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*var*/ let callback = this._callbacks.get_Item(i);
                    this.Execute$1(callback, $.$ref(() => exceptions, ($v) => exceptions = $v, $.$spc.System.Collections.Generic.List$$($.$spc.System.Exception)));
                }
                if (exceptions !== null)
                {
                    throw new $.$spc.System.AggregateException().$ctor$8(exceptions);
                }
            }
            /*void */ Execute$1(/*PipeCompletionCallback*/ callback, /*ref List<Exception>?*/ exceptions)
            {
                try
                {
                    callback.Callback.Invoke(this._exception, callback.State);
                }
                catch(ex)
                {
                    exceptions.$v ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Exception))().$ctor$1();
                    exceptions.$v.Add(ex);
                }
            }
            static $h = 1153019;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","d":1153019,"h":17181022203,"f":1},{"r":65537,"p":[{"n":"callback","p":1087483},{"n":"exceptions","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Exception).$h,"f":4}],"n":"Execute","o":"@$1","d":1153019,"h":21475989499,"f":2}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h,"n":"_callbacks","d":1153019,"h":4296120315,"f":2},{"t":47185921,"n":"_exception","d":1153019,"h":8591087611,"f":2}],"c":[{"p":[{"n":"callbacks","p":$.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h},{"n":"edi","p":97517569}],"n":".ctor","o":"$ctor$1","d":1153019,"h":12886054907,"f":1}],"h":1153019}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletionCallbacks`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeOptions", ($self) => class PipeOptions extends $.$spc.System.Object
        {
            /*int*/ static DefaultMinimumSegmentSize = 4096;
            /*PipeOptions*/ static Default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*PipeScheduler?*/ readerScheduler, /*PipeScheduler?*/ writerScheduler, /*long*/ pauseWriterThreshold, /*long*/ resumeWriterThreshold, /*int*/ minimumSegmentSize, /*bool*/ useSynchronizationContext)
            {
                super.$ctor();
                {
                    this.MinimumSegmentSize = minimumSegmentSize === -1 ? 4096/*DefaultMinimumSegmentSize*/ : minimumSegmentSize;
                    this.InitialSegmentPoolSize = 4;
                    this.MaxSegmentPoolSize = 256;
                    /*int*/ let DefaultPauseWriterThreshold = 65536;
                    /*int*/ let DefaultResumeWriterThreshold = $.trunc(DefaultPauseWriterThreshold / 2);
                    if (pauseWriterThreshold === BigInt(-1))
                    {
                        pauseWriterThreshold = BigInt(DefaultPauseWriterThreshold);
                    }
                    else if (pauseWriterThreshold < 0n)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(4/*ExceptionArgument.pauseWriterThreshold*/);
                    }
                    if (resumeWriterThreshold === BigInt(-1))
                    {
                        resumeWriterThreshold = BigInt(DefaultResumeWriterThreshold);
                    }
                    else if (resumeWriterThreshold === 0n)
                    {
                        resumeWriterThreshold = 1n;
                    }
                    if (resumeWriterThreshold < 0n || (pauseWriterThreshold > 0n && resumeWriterThreshold > pauseWriterThreshold))
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(5/*ExceptionArgument.resumeWriterThreshold*/);
                    }
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.IsDefaultSharedMemoryPool = this.Pool === $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.ReaderScheduler = readerScheduler ?? $.$sipl.System.IO.Pipelines.PipeScheduler.ThreadPool;
                    this.WriterScheduler = writerScheduler ?? $.$sipl.System.IO.Pipelines.PipeScheduler.ThreadPool;
                    this.PauseWriterThreshold = pauseWriterThreshold;
                    this.ResumeWriterThreshold = resumeWriterThreshold;
                    this.UseSynchronizationContext = useSynchronizationContext;
                }
                return this;
            }
            /*bool*/ UseSynchronizationContext = false;
            /*long*/ PauseWriterThreshold = 0n;
            /*long*/ ResumeWriterThreshold = 0n;
            /*int*/ MinimumSegmentSize = 0;
            /*PipeScheduler*/ WriterScheduler = null;
            /*PipeScheduler*/ ReaderScheduler = null;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ IsDefaultSharedMemoryPool = false;
            /*int*/ InitialSegmentPoolSize = 0;
            /*int*/ MaxSegmentPoolSize = 0;
            //default member initializer
            constructor()
            {
                super();
                this.UseSynchronizationContext = false;
                this.IsDefaultSharedMemoryPool = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$sipl.System.IO.Pipelines.PipeOptions().$ctor$1(null, null, null, -1n, -1n, -1, true);
                }
            }
            static $h = 1349627;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1349627,"g":{"r":0,"d":0,"h":17181218811,"f":33},"n":"Default","d":1349627,"h":12886251515,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":34361087995,"f":1},"n":"UseSynchronizationContext","d":1349627,"h":30066120699,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":47245989883,"f":1},"n":"PauseWriterThreshold","d":1349627,"h":42951022587,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":60130891771,"f":1},"n":"ResumeWriterThreshold","d":1349627,"h":55835924475,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73015793659,"f":1},"n":"MinimumSegmentSize","d":1349627,"h":68720826363,"f":1},{"p":1546235,"g":{"r":0,"d":0,"h":85900695547,"f":1},"n":"WriterScheduler","d":1349627,"h":81605728251,"f":1},{"p":1546235,"g":{"r":0,"d":0,"h":98785597435,"f":1},"n":"ReaderScheduler","d":1349627,"h":94490630139,"f":1},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":111670499323,"f":1},"n":"Pool","d":1349627,"h":107375532027,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124555401211,"f":8},"n":"IsDefaultSharedMemoryPool","d":1349627,"h":120260433915,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":137440303099,"f":8},"n":"InitialSegmentPoolSize","d":1349627,"h":133145335803,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":150325204987,"f":8},"n":"MaxSegmentPoolSize","d":1349627,"h":146030237691,"f":8}],"l":[{"t":655361,"n":"DefaultMinimumSegmentSize","d":1349627,"h":4296316923,"f":34}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"f":65},{"n":"readerScheduler","p":1546235,"f":65},{"n":"writerScheduler","p":1546235,"f":65},{"n":"pauseWriterThreshold","p":917505,"f":65,"v":-1},{"n":"resumeWriterThreshold","p":917505,"f":65,"v":-1},{"n":"minimumSegmentSize","p":655361,"f":65,"v":-1},{"n":"useSynchronizationContext","p":262145,"f":65,"v":true}],"n":".ctor","o":"$ctor$1","d":1349627,"h":21476186107,"f":1}],"h":1349627}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeOptions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeExtensions", ($self) => class StreamPipeExtensions
        {
            static /*Task */ CopyToAsync(/*this Stream*/ source, /*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (source === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.source*/);
                }
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return destination.CopyFromAsync(source, cancellationToken);
            }
            static $h = 1939451;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"p":[{"n":"source","p":62128129},{"n":"destination","p":1611771},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","d":1939451,"h":4296906747,"f":33}],"h":1939451}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeExtensions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeReaderOptions", ($self) => class StreamPipeReaderOptions extends $.$spc.System.Object
        {
            /*int*/ static DefaultBufferSize = 4096;
            /*int*/ static DefaultMaxBufferSize = 2097152;
            /*int*/ static DefaultMinimumReadSize = 1024;
            /*StreamPipeReaderOptions*/ static s_default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*int*/ bufferSize, /*int*/ minimumReadSize, /*bool*/ leaveOpen)
            {
                this.$ctor$2(null, -1, -1, false, false);
                {
                }
                return this;
            }
            $ctor$2(/*MemoryPool<byte>?*/ pool, /*int*/ bufferSize, /*int*/ minimumReadSize, /*bool*/ leaveOpen, /*bool*/ useZeroByteReads)
            {
                super.$ctor();
                {
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.IsDefaultSharedMemoryPool = this.Pool === $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.BufferSize = bufferSize === -1 ? 4096/*DefaultBufferSize*/ : bufferSize <= 0 ? (() =>
                    {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("bufferSize")            })() : bufferSize;
                    this.MinimumReadSize = minimumReadSize === -1 ? 1024/*DefaultMinimumReadSize*/ : minimumReadSize <= 0 ? (() =>
                    {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("minimumReadSize")            })() : minimumReadSize;
                    this.LeaveOpen = leaveOpen;
                    this.UseZeroByteReads = useZeroByteReads;
                }
                return this;
            }
            /*int*/ BufferSize = 0;
            /*int*/ MaxBufferSize = 0;
            /*int*/ MinimumReadSize = 0;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ LeaveOpen = false;
            /*bool*/ UseZeroByteReads = false;
            /*bool*/ IsDefaultSharedMemoryPool = false;
            //default member initializer
            constructor()
            {
                super();
                this.MaxBufferSize = 2097152;
                this.LeaveOpen = false;
                this.UseZeroByteReads = false;
                this.IsDefaultSharedMemoryPool = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_default = new $.$sipl.System.IO.Pipelines.StreamPipeReaderOptions().$ctor$2(null, -1, -1, false, false);
                }
            }
            static $h = 2070523;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":38656776187,"f":1},"n":"BufferSize","d":2070523,"h":34361808891,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51541678075,"f":8},"n":"MaxBufferSize","d":2070523,"h":47246710779,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":64426579963,"f":1},"n":"MinimumReadSize","d":2070523,"h":60131612667,"f":1},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":77311481851,"f":1},"n":"Pool","d":2070523,"h":73016514555,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":90196383739,"f":1},"n":"LeaveOpen","d":2070523,"h":85901416443,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":103081285627,"f":1},"n":"UseZeroByteReads","d":2070523,"h":98786318331,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115966187515,"f":8},"n":"IsDefaultSharedMemoryPool","d":2070523,"h":111671220219,"f":8}],"l":[{"t":655361,"n":"DefaultBufferSize","d":2070523,"h":4297037819,"f":34},{"t":655361,"n":"DefaultMaxBufferSize","d":2070523,"h":8592005115,"f":40},{"t":655361,"n":"DefaultMinimumReadSize","d":2070523,"h":12886972411,"f":34},{"t":2070523,"n":"s_default","d":2070523,"h":17181939707,"f":40}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h},{"n":"bufferSize","p":655361},{"n":"minimumReadSize","p":655361},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$1","d":2070523,"h":21476907003,"f":1},{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"f":65},{"n":"bufferSize","p":655361,"f":65,"v":-1},{"n":"minimumReadSize","p":655361,"f":65,"v":-1},{"n":"leaveOpen","p":262145,"f":65,"v":false},{"n":"useZeroByteReads","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$2","d":2070523,"h":25771874299,"f":1}],"h":2070523}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeReaderOptions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeWriterOptions", ($self) => class StreamPipeWriterOptions extends $.$spc.System.Object
        {
            /*int*/ static DefaultMinimumBufferSize = 4096;
            /*StreamPipeWriterOptions*/ static s_default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*int*/ minimumBufferSize, /*bool*/ leaveOpen)
            {
                super.$ctor();
                {
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.MinimumBufferSize = minimumBufferSize === -1 ? 4096/*DefaultMinimumBufferSize*/ : minimumBufferSize <= 0 ? (() =>
                    {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("minimumBufferSize")            })() : minimumBufferSize;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*int*/ MinimumBufferSize = 0;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ LeaveOpen = false;
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_default = new $.$sipl.System.IO.Pipelines.StreamPipeWriterOptions().$ctor$1(null, -1, false);
                }
            }
            static $h = 2201595;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25772005371,"f":1},"n":"MinimumBufferSize","d":2201595,"h":21477038075,"f":1},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":38656907259,"f":1},"n":"Pool","d":2201595,"h":34361939963,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51541809147,"f":1},"n":"LeaveOpen","d":2201595,"h":47246841851,"f":1}],"l":[{"t":655361,"n":"DefaultMinimumBufferSize","d":2201595,"h":4297168891,"f":34},{"t":2201595,"n":"s_default","d":2201595,"h":8592136187,"f":40}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"f":65},{"n":"minimumBufferSize","p":655361,"f":65,"v":-1},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$1","d":2201595,"h":12887103483,"f":1}],"h":2201595}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeWriterOptions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateArgumentOutOfRangeException(argument);
            }
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                return new $.$spc.System.ArgumentOutOfRangeException().$ctor$16($.$spc.System.Enum.ToStringT($.$sipl.System.IO.Pipelines.ExceptionArgument, $.$spc.System.UInt32, argument));
            }
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateArgumentNullException(argument);
            }
            static /*ArgumentNullException */ CreateArgumentNullException(/*ExceptionArgument*/ argument)
            {
                return new $.$spc.System.ArgumentNullException().$ctor$16($.$spc.System.Enum.ToStringT($.$sipl.System.IO.Pipelines.ExceptionArgument, $.$spc.System.UInt32, argument));
            }
            static /*void */ ThrowInvalidOperationException_AlreadyReading()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_AlreadyReading();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_AlreadyReading()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ReadingIsInProgress);
            }
            static /*void */ ThrowInvalidOperationException_NoReadToComplete()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoReadToComplete();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoReadToComplete()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.NoReadingOperationToComplete);
            }
            static /*void */ ThrowInvalidOperationException_NoConcurrentOperation()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoConcurrentOperation()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ConcurrentOperationsNotSupported);
            }
            static /*void */ ThrowInvalidOperationException_GetResultNotCompleted()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_GetResultNotCompleted();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_GetResultNotCompleted()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.GetResultBeforeCompleted);
            }
            static /*void */ ThrowInvalidOperationException_NoWritingAllowed()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoWritingAllowed();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoWritingAllowed()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.WritingAfterCompleted);
            }
            static /*void */ ThrowInvalidOperationException_NoReadingAllowed()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoReadingAllowed();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoReadingAllowed()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ReadingAfterCompleted);
            }
            static /*void */ ThrowInvalidOperationException_InvalidExaminedPosition()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidExaminedPosition();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidExaminedPosition()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.InvalidExaminedPosition);
            }
            static /*void */ ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidExaminedOrConsumedPosition();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidExaminedOrConsumedPosition()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.InvalidExaminedOrConsumedPosition);
            }
            static /*void */ ThrowInvalidOperationException_AdvanceToInvalidCursor()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_AdvanceToInvalidCursor();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_AdvanceToInvalidCursor()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.AdvanceToInvalidCursor);
            }
            static /*void */ ThrowInvalidOperationException_ResetIncompleteReaderWriter()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_ResetIncompleteReaderWriter();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_ResetIncompleteReaderWriter()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ReaderAndWriterHasToBeCompleted);
            }
            static /*void */ ThrowOperationCanceledException_ReadCanceled()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateOperationCanceledException_ReadCanceled();
            }
            static /*OperationCanceledException */ CreateOperationCanceledException_ReadCanceled()
            {
                return new $.$spc.System.OperationCanceledException().$ctor$10($.$sipl.System.SR.ReadCanceledOnPipeReader);
            }
            static /*void */ ThrowOperationCanceledException_FlushCanceled()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateOperationCanceledException_FlushCanceled();
            }
            static /*OperationCanceledException */ CreateOperationCanceledException_FlushCanceled()
            {
                return new $.$spc.System.OperationCanceledException().$ctor$10($.$sipl.System.SR.FlushCanceledOnPipeWriter);
            }
            static /*void */ ThrowInvalidOperationException_InvalidZeroByteRead()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidZeroByteRead();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidZeroByteRead()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.InvalidZeroByteRead);
            }
            static /*void */ ThrowNotSupported_UnflushedBytes()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateNotSupportedException_UnflushedBytes();
            }
            static /*NotSupportedException */ CreateNotSupportedException_UnflushedBytes()
            {
                return new $.$spc.System.NotSupportedException().$ctor$10($.$sipl.System.SR.UnflushedBytesNotSupported);
            }
            static $h = 2332667;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":366587}],"n":"ThrowArgumentOutOfRangeException","d":2332667,"h":4297299963,"f":40},{"r":13500417,"p":[{"n":"argument","p":366587}],"n":"CreateArgumentOutOfRangeException","d":2332667,"h":8592267259,"f":34},{"r":65537,"p":[{"n":"argument","p":366587}],"n":"ThrowArgumentNullException","d":2332667,"h":12887234555,"f":40},{"r":13434881,"p":[{"n":"argument","p":366587}],"n":"CreateArgumentNullException","d":2332667,"h":17182201851,"f":34},{"r":65537,"n":"ThrowInvalidOperationException_AlreadyReading","d":2332667,"h":21477169147,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_AlreadyReading","d":2332667,"h":25772136443,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoReadToComplete","d":2332667,"h":30067103739,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_NoReadToComplete","d":2332667,"h":34362071035,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoConcurrentOperation","d":2332667,"h":38657038331,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_NoConcurrentOperation","d":2332667,"h":42952005627,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_GetResultNotCompleted","d":2332667,"h":47246972923,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_GetResultNotCompleted","d":2332667,"h":51541940219,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoWritingAllowed","d":2332667,"h":55836907515,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_NoWritingAllowed","d":2332667,"h":60131874811,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoReadingAllowed","d":2332667,"h":64426842107,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_NoReadingAllowed","d":2332667,"h":68721809403,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_InvalidExaminedPosition","d":2332667,"h":73016776699,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_InvalidExaminedPosition","d":2332667,"h":77311743995,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition","d":2332667,"h":81606711291,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_InvalidExaminedOrConsumedPosition","d":2332667,"h":85901678587,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_AdvanceToInvalidCursor","d":2332667,"h":90196645883,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_AdvanceToInvalidCursor","d":2332667,"h":94491613179,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_ResetIncompleteReaderWriter","d":2332667,"h":98786580475,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_ResetIncompleteReaderWriter","d":2332667,"h":103081547771,"f":33},{"r":65537,"n":"ThrowOperationCanceledException_ReadCanceled","d":2332667,"h":107376515067,"f":33},{"r":71106561,"n":"CreateOperationCanceledException_ReadCanceled","d":2332667,"h":111671482363,"f":33},{"r":65537,"n":"ThrowOperationCanceledException_FlushCanceled","d":2332667,"h":115966449659,"f":33},{"r":71106561,"n":"CreateOperationCanceledException_FlushCanceled","d":2332667,"h":120261416955,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_InvalidZeroByteRead","d":2332667,"h":124556384251,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_InvalidZeroByteRead","d":2332667,"h":128851351547,"f":33},{"r":65537,"n":"ThrowNotSupported_UnflushedBytes","d":2332667,"h":133146318843,"f":33},{"r":66781185,"n":"CreateNotSupportedException_UnflushedBytes","d":2332667,"h":137441286139,"f":33}],"h":2332667}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.ThrowHelper`; }
        });
        
        $asm.$cls("$sipl.System.IO.StreamHelpers", ($self) => class StreamHelpers
        {
            static /*void */ ValidateCopyToArgs(/*Stream*/ source, /*Stream*/ destination, /*int*/ bufferSize)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(destination, "destination");
                if (bufferSize <= 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("bufferSize", $.$box(bufferSize, $.$spc.System.Int32), $.$sipl.System.SR.ArgumentOutOfRange_NeedPosNum);
                }
                /*bool*/ let sourceCanRead = source.CanRead;
                if (!sourceCanRead && !source.CanWrite)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15(null, $.$sipl.System.SR.ObjectDisposed_StreamClosed);
                }
                /*bool*/ let destinationCanWrite = destination.CanWrite;
                if (!destinationCanWrite && !destination.CanRead)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15("destination", $.$sipl.System.SR.ObjectDisposed_StreamClosed);
                }
                if (!sourceCanRead)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sipl.System.SR.NotSupported_UnreadableStream);
                }
                if (!destinationCanWrite)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sipl.System.SR.NotSupported_UnwritableStream);
                }
            }
            static $h = 2398203;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"source","p":62128129},{"n":"destination","p":62128129},{"n":"bufferSize","p":655361}],"n":"ValidateCopyToArgs","d":2398203,"h":4297365499,"f":33}],"h":2398203}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.StreamHelpers`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.InlineScheduler", ($self) => class InlineScheduler extends $.$sipl.System.IO.Pipelines.PipeScheduler
        {
            /*void */ Schedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                action.Invoke(state);
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                action.Invoke(state);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 563195;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1546235,"m":[{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":563195,"h":4295530491,"f":32769},{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":563195,"h":8590497787,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":563195,"h":12885465083,"f":1}],"h":563195}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeScheduler; }
            static get $fullName() { return `System.IO.Pipelines.InlineScheduler`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.CompletionData", ($self) => class CompletionData extends $.$spc.System.ValueType
        {
            /*Action<object?>*/ Completion = null;
            /*object?*/ CompletionState = null;
            /*ExecutionContext?*/ ExecutionContext = null;
            /*SynchronizationContext?*/ SynchronizationContext = null;
            $ctor$2(/*Action<object?>*/ completion, /*object?*/ completionState, /*ExecutionContext?*/ executionContext, /*SynchronizationContext?*/ synchronizationContext)
            {
                super.$ctor$1();
                {
                    this.Completion = completion;
                    this.CompletionState = completionState;
                    this.ExecutionContext = executionContext;
                    this.SynchronizationContext = synchronizationContext;
                }
                return this;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Completion = this.Completion;
                copy.CompletionState = this.CompletionState;
                copy.ExecutionContext = this.ExecutionContext;
                copy.SynchronizationContext = this.SynchronizationContext;
                return copy;
            }
            static $h = 301051;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.Action$$($.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":12885202939,"f":1},"n":"Completion","d":301051,"h":8590235643,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":25770104827,"f":1},"n":"CompletionState","d":301051,"h":21475137531,"f":1},{"p":126943233,"g":{"r":0,"d":0,"h":38655006715,"f":1},"n":"ExecutionContext","d":301051,"h":34360039419,"f":1},{"p":131137537,"g":{"r":0,"d":0,"h":51539908603,"f":1},"n":"SynchronizationContext","d":301051,"h":47244941307,"f":1}],"c":[{"p":[{"n":"completion","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"completionState","p":131073},{"n":"executionContext","p":126943233},{"n":"synchronizationContext","p":131137537}],"n":".ctor","o":"$ctor$2","d":301051,"h":55834875899,"f":1},{"n":".ctor","o":"$ctor$3","d":301051,"h":60129843195,"f":1}],"h":301051}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.CompletionData`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.FlushResult", ($self) => class FlushResult extends $.$spc.System.ValueType
        {
            /*ResultFlags*/  get _resultFlags() { return this.$getField(0, $.$sipl.System.IO.Pipelines.ResultFlags); }
            /*ResultFlags*/  set _resultFlags(value) { this.$setField(0, $.$sipl.System.IO.Pipelines.ResultFlags, value); }
            $ctor$2(/*bool*/ isCanceled, /*bool*/ isCompleted)
            {
                super.$ctor$1();
                {
                    this._resultFlags = 0/*ResultFlags.None*/;
                    if (isCanceled)
                    {
                        this._resultFlags |= 1/*ResultFlags.Canceled*/;
                    }
                    if (isCompleted)
                    {
                        this._resultFlags |= 2/*ResultFlags.Completed*/;
                    }
                }
                return this;
            }
            /*bool */ get IsCanceled()
            {
                return (this._resultFlags & 1/*ResultFlags.Canceled*/) !== 0;
            }
            /*bool */ get IsCompleted()
            {
                return (this._resultFlags & 2/*ResultFlags.Completed*/) !== 0;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resultFlags = this._resultFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resultFlags = 0;
            }
            static $h = 432123;
            static $z = 1;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180301307,"f":1},"n":"IsCanceled","d":432123,"h":12885334011,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770235899,"f":1},"n":"IsCompleted","d":432123,"h":21475268603,"f":1}],"l":[{"t":1808379,"n":"_resultFlags","d":432123,"h":4295399419,"f":8}],"c":[{"p":[{"n":"isCanceled","p":262145},{"n":"isCompleted","p":262145}],"n":".ctor","o":"$ctor$2","d":432123,"h":8590366715,"f":1},{"n":".ctor","o":"$ctor$3","d":432123,"h":30065203195,"f":1}],"h":432123}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.FlushResult`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.BufferSegmentStack", ($self) => class BufferSegmentStack extends $.$spc.System.ValueType
        {
            /*SegmentAsValueType[]*/  get _array() { return this.$getField(0, 4); }
            /*SegmentAsValueType[]*/  set _array(value) { this.$setField(0, 4, value); }
            /*int*/  get _size() { return this.$getField(4, 4); }
            /*int*/  set _size(value) { this.$setField(4, 4, value); }
            $ctor$2(/*int*/ size)
            {
                super.$ctor$1();
                {
                    this._array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType), null, [size], null);
                    this._size = 0;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._size;
            }
            /*bool */ TryPop(/*out BufferSegment?*/ result)
            {
                /*int*/ let size = ((this._size - 1) | 0);
                /*SegmentAsValueType[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    result.$v = null;
                    return false;
                }
                this._size = size;
                result.$v = $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit$1($.$spc.System.Array.$ReadT1.call(array, size));
                $.$spc.System.Array.$WriteT1.call(array, new $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType(), size);
                return true;
            }
            /*void */ Push(/*BufferSegment*/ item)
            {
                /*int*/ let size = this._size;
                /*SegmentAsValueType[]*/ let array = this._array;
                if ((size >>> 0) < (array.length >>> 0))
                {
                    $.$spc.System.Array.$WriteT1.call(array, $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit(item), size);
                    this._size = ((size + 1) | 0);
                }
                else 
                {
                    this.PushWithResize(item);
                }
            }
            /*void */ PushWithResize(/*BufferSegment*/ item)
            {
                $.$spc.System.Array.Resize($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType, $.$ref(() => this._array, ($v) => this._array = $v, $.$typeArray($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType)), ((2 * this._array.length) | 0));
                $.$spc.System.Array.$WriteT1.call(this._array, $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit(item), this._size);
                this._size++;
            }
            static $_SegmentAsValueType;
            static get SegmentAsValueType()
            {
                let $cls = $.$sipl.System.IO.Pipelines.BufferSegmentStack;
                return $cls.$_SegmentAsValueType ??= $asm.$nstr("$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType", ($self) => class SegmentAsValueType extends $.$spc.System.ValueType
                {
                    /*BufferSegment*/  get _value() { return this.$getField(0, 4); }
                    /*BufferSegment*/  set _value(value) { this.$setField(0, 4, value); }
                    $ctor$2(/*BufferSegment*/ value)
                    {
                        super.$ctor$1();
                        this._value = value;
                        return this;
                    }
                    static /*SegmentAsValueType */ op_Implicit(/*BufferSegment*/ s)
                    {
                        return new $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType().$ctor$2(s);
                    }
                    static /*BufferSegment */ op_Implicit$1(/*SegmentAsValueType*/ s)
                    {
                        return s._value;
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._value = this._value;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._value = null;
                    }
                    static $h = 235515;
                    static $z = 4;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":104443,"n":"_value","d":235515,"h":4295202811,"f":2}],"c":[{"p":[{"n":"value","p":104443}],"n":".ctor","o":"$ctor$2","d":235515,"h":8590170107,"f":2},{"n":".ctor","o":"$ctor$3","d":235515,"h":21475071995,"f":1}],"d":169979,"h":235515}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType`; }
                }, $cls, ($v) => $cls.$_SegmentAsValueType = $v);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._array = this._array;
                copy._size = this._size;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._array = null;
                this._size = 0;
            }
            static $h = 169979;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21475006459,"f":1},"n":"Count","d":169979,"h":17180039163,"f":1}],"m":[{"r":262145,"p":[{"n":"result","p":104443,"f":2}],"n":"TryPop","d":169979,"h":25769973755,"f":1},{"r":65537,"p":[{"n":"item","p":104443}],"n":"Push","d":169979,"h":30064941051,"f":1},{"r":65537,"p":[{"n":"item","p":104443}],"n":"PushWithResize","d":169979,"h":34359908347,"f":2}],"l":[{"t":0,"n":"_array","d":169979,"h":4295137275,"f":2},{"t":655361,"n":"_size","d":169979,"h":8590104571,"f":2}],"c":[{"p":[{"n":"size","p":655361}],"n":".ctor","o":"$ctor$2","d":169979,"h":12885071867,"f":1},{"n":".ctor","o":"$ctor$3","d":169979,"h":42949842939,"f":1}],"j":[235515],"h":169979}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.BufferSegmentStack`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeAwaitable", ($self) => class PipeAwaitable extends $.$spc.System.ValueType
        {
            /*AwaitableState*/  get _awaitableState() { return this.$getField(0, 4); }
            /*AwaitableState*/  set _awaitableState(value) { this.$setField(0, 4, value); }
            /*Action<object?>?*/  get _completion() { return this.$getField(4, 4); }
            /*Action<object?>?*/  set _completion(value) { this.$setField(4, 4, value); }
            /*object?*/  get _completionState() { return this.$getField(8, 4); }
            /*object?*/  set _completionState(value) { this.$setField(8, 4, value); }
            /*SchedulingContext?*/  get _schedulingContext() { return this.$getField(12, 4); }
            /*SchedulingContext?*/  set _schedulingContext(value) { this.$setField(12, 4, value); }
            /*CancellationTokenRegistration*/  get _cancellationTokenRegistration() { return this.$getField(16, 12); }
            /*CancellationTokenRegistration*/  set _cancellationTokenRegistration(value) { this.$setField(16, 12, value); }
            /*CancellationToken */ get CancellationToken()
            {
                return this._cancellationTokenRegistration.Token;
            }
            $ctor$2(/*bool*/ completed, /*bool*/ useSynchronizationContext)
            {
                super.$ctor$1();
                {
                    this._awaitableState = (completed ? 1/*AwaitableState.Completed*/ : 0/*AwaitableState.None*/) | (useSynchronizationContext ? 8/*AwaitableState.UseSynchronizationContext*/ : 0/*AwaitableState.None*/);
                    this._completion = null;
                    this._completionState = null;
                    this._cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                    this._schedulingContext = null;
                }
                return this;
            }
            /*bool */ get IsCompleted()
            {
                return (this._awaitableState & (1/*AwaitableState.Completed*/ | 4/*AwaitableState.Canceled*/)) !== 0;
            }
            /*bool */ get IsRunning()
            {
                return (this._awaitableState & 2/*AwaitableState.Running*/) !== 0;
            }
            /*void */ BeginOperation(/*CancellationToken*/ cancellationToken, /*Action<object?>*/ callback, /*object?*/ state)
            {
                if (cancellationToken.CanBeCanceled && !this.IsCompleted)
                {
                    /*var*/ let previousAwaitableState = this._awaitableState;
                    this._cancellationTokenRegistration = cancellationToken.UnsafeRegister(callback, state);
                    if ($.$spc.System.Threading.CancellationTokenRegistration.op_Equality(this._cancellationTokenRegistration, $.$default($.$spc.System.Threading.CancellationTokenRegistration)))
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(previousAwaitableState === this._awaitableState, "The awaitable state changed!");
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                }
                this._awaitableState |= 2/*AwaitableState.Running*/;
            }
            /*void */ Complete(/*out CompletionData*/ completionData)
            {
                this.ExtractCompletion(completionData);
                this._awaitableState |= 1/*AwaitableState.Completed*/;
            }
            /*void */ ExtractCompletion(/*out CompletionData*/ completionData)
            {
                /*Action<object?>?*/ let currentCompletion = this._completion;
                /*object?*/ let currentState = this._completionState;
                /*SchedulingContext?*/ let schedulingContext = this._schedulingContext;
                /*ExecutionContext?*/ let executionContext = (schedulingContext?.ExecutionContext ?? null);
                /*SynchronizationContext?*/ let synchronizationContext = (schedulingContext?.SynchronizationContext ?? null);
                this._completion = null;
                this._completionState = null;
                this._schedulingContext = null;
                completionData.$v = currentCompletion !== null ? new $.$sipl.System.IO.Pipelines.CompletionData().$ctor$2(currentCompletion, currentState, executionContext, synchronizationContext) : new $.$sipl.System.IO.Pipelines.CompletionData();
            }
            /*void */ SetUncompleted()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._completion === null, "_completion == null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._completionState === null, "_completionState == null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._schedulingContext === null, "_schedulingContext == null");
                this._awaitableState &= ~1/*AwaitableState.Completed*/;
            }
            /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags, /*out CompletionData*/ completionData, /*out bool*/ doubleCompletion)
            {
                completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                doubleCompletion.$v = !(this._completion === null);
                if (this.IsCompleted || doubleCompletion.$v)
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData().$ctor$2(continuation, state, (this._schedulingContext?.ExecutionContext ?? null), (this._schedulingContext?.SynchronizationContext ?? null));
                    return;
                }
                this._completion = continuation;
                this._completionState = state;
                if ((this._awaitableState & 8/*AwaitableState.UseSynchronizationContext*/) !== 0 && (flags & 1/*ValueTaskSourceOnCompletedFlags.UseSchedulingContext*/) !== 0)
                {
                    /*SynchronizationContext?*/ let sc = $.$spc.System.Threading.SynchronizationContext.Current;
                    if (sc !== null && $.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(sc), $.$spc.System.Threading.SynchronizationContext.$type))
                    {
                        this._schedulingContext ??= new $.$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext().$ctor$1();
                        this._schedulingContext.SynchronizationContext = sc;
                    }
                }
                if ((flags & 2/*ValueTaskSourceOnCompletedFlags.FlowExecutionContext*/) !== 0)
                {
                    this._schedulingContext ??= new $.$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext().$ctor$1();
                    this._schedulingContext.ExecutionContext = $.$spc.System.Threading.ExecutionContext.Capture();
                }
            }
            /*void */ Cancel(/*out CompletionData*/ completionData)
            {
                this.ExtractCompletion(completionData);
                this._awaitableState |= 4/*AwaitableState.Canceled*/;
            }
            /*void */ CancellationTokenFired(/*out CompletionData*/ completionData)
            {
                if (this.CancellationToken.IsCancellationRequested)
                {
                    this.Cancel(completionData);
                }
                else 
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                }
            }
            /*bool */ ObserveCancellation()
            {
                /*bool*/ let isCanceled = (this._awaitableState & 4/*AwaitableState.Canceled*/) === 4/*AwaitableState.Canceled*/;
                this._awaitableState &= ~(4/*AwaitableState.Canceled*/ | 2/*AwaitableState.Running*/);
                return isCanceled;
            }
            /*CancellationTokenRegistration */ ReleaseCancellationTokenRegistration(/*out CancellationToken*/ cancellationToken)
            {
                cancellationToken.$v = this.CancellationToken;
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = this._cancellationTokenRegistration;
                this._cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                return cancellationTokenRegistration;
            }
            static $_AwaitableState;
            static get AwaitableState()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeAwaitable;
                return $cls.$_AwaitableState ??= $asm.$nstr("$sipl.System.IO.Pipelines.PipeAwaitable.AwaitableState", ($self) => class AwaitableState extends $.$spc.System.Enum
                {
                    static None = 0;
                    static Completed = 1;
                    static Running = 2;
                    static Canceled = 4;
                    static UseSynchronizationContext = 8;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "Completed": 1n,
                            "Running": 2n,
                            "Canceled": 4n,
                            "UseSynchronizationContext": 8n
                        };
                    }
                    static $h = 890875;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":890875,"n":"None","d":890875,"h":4295858171,"f":33},{"t":890875,"n":"Completed","d":890875,"h":8590825467,"f":33},{"t":890875,"n":"Running","d":890875,"h":12885792763,"f":33},{"t":890875,"n":"Canceled","d":890875,"h":17180760059,"f":33},{"t":890875,"n":"UseSynchronizationContext","d":890875,"h":21475727355,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":890875,"h":25770694651,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":825339,"h":890875,"a":[{"t":47644673,"c":4342611969}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Pipelines.PipeAwaitable.AwaitableState`; }
                }, $cls, ($v) => $cls.$_AwaitableState = $v);
            }
            static $_SchedulingContext;
            static get SchedulingContext()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeAwaitable;
                return $cls.$_SchedulingContext ??= $asm.$ncls("$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext", ($self) => class SchedulingContext extends $.$spc.System.Object
                {
                    /*SynchronizationContext?*/ SynchronizationContext = null;
                    /*ExecutionContext?*/ ExecutionContext = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 956411;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131137537,"g":{"r":0,"d":0,"h":12885858299,"f":1},"s":{"r":0,"d":0,"h":17180825595,"f":1},"n":"SynchronizationContext","d":956411,"h":8590891003,"f":1},{"p":126943233,"g":{"r":0,"d":0,"h":30065727483,"f":1},"s":{"r":0,"d":0,"h":34360694779,"f":1},"n":"ExecutionContext","d":956411,"h":25770760187,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":956411,"h":38655662075,"f":1}],"d":825339,"h":956411}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Pipelines.PipeAwaitable.SchedulingContext`; }
                }, $cls, ($v) => $cls.$_SchedulingContext = $v);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._awaitableState = this._awaitableState;
                copy._completion = this._completion;
                copy._completionState = this._completionState;
                copy._schedulingContext = this._schedulingContext;
                copy._cancellationTokenRegistration = this._cancellationTokenRegistration.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._awaitableState = 0;
                this._completion = null;
                this._completionState = null;
                this._schedulingContext = null;
                this._cancellationTokenRegistration = $.$default($.$spc.System.Threading.CancellationTokenRegistration);
            }
            static $h = 825339;
            static $z = 28;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":125960193,"g":{"r":0,"d":0,"h":30065596411,"f":2},"n":"CancellationToken","d":825339,"h":25770629115,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":42950498299,"f":1},"n":"IsCompleted","d":825339,"h":38655531003,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540432891,"f":1},"n":"IsRunning","d":825339,"h":47245465595,"f":1}],"m":[{"r":65537,"p":[{"n":"cancellationToken","p":125960193},{"n":"callback","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"BeginOperation","d":825339,"h":55835400187,"f":1},{"r":65537,"p":[{"n":"completionData","p":301051,"f":2}],"n":"Complete","d":825339,"h":60130367483,"f":1},{"r":65537,"p":[{"n":"completionData","p":301051,"f":2}],"n":"ExtractCompletion","d":825339,"h":64425334779,"f":2},{"r":65537,"n":"SetUncompleted","d":825339,"h":68720302075,"f":1},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132972545},{"n":"completionData","p":301051,"f":2},{"n":"doubleCompletion","p":262145,"f":2}],"n":"OnCompleted","d":825339,"h":73015269371,"f":1},{"r":65537,"p":[{"n":"completionData","p":301051,"f":2}],"n":"Cancel","d":825339,"h":77310236667,"f":1},{"r":65537,"p":[{"n":"completionData","p":301051,"f":2}],"n":"CancellationTokenFired","d":825339,"h":81605203963,"f":1},{"r":262145,"n":"ObserveCancellation","d":825339,"h":85900171259,"f":1},{"r":126025729,"p":[{"n":"cancellationToken","p":125960193,"f":2}],"n":"ReleaseCancellationTokenRegistration","d":825339,"h":90195138555,"f":1}],"l":[{"t":890875,"n":"_awaitableState","d":825339,"h":4295792635,"f":2},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"_completion","d":825339,"h":8590759931,"f":2},{"t":131073,"n":"_completionState","d":825339,"h":12885727227,"f":2},{"t":956411,"n":"_schedulingContext","d":825339,"h":17180694523,"f":2},{"t":126025729,"n":"_cancellationTokenRegistration","d":825339,"h":21475661819,"f":2}],"c":[{"p":[{"n":"completed","p":262145},{"n":"useSynchronizationContext","p":262145}],"n":".ctor","o":"$ctor$2","d":825339,"h":34360563707,"f":1},{"n":".ctor","o":"$ctor$3","d":825339,"h":103080040443,"f":1}],"j":[890875,956411],"h":825339,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"CanceledState = {_awaitableState}, IsCompleted = {IsCompleted}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeAwaitable`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeCompletion", ($self) => class PipeCompletion extends $.$spc.System.ValueType
        {
            /*object*/ static s_completedSuccessfully = null;
            /*object?*/  get _state() { return this.$getField(0, 4); }
            /*object?*/  set _state(value) { this.$setField(0, 4, value); }
            /*List<PipeCompletionCallback>?*/  get _callbacks() { return this.$getField(4, 4); }
            /*List<PipeCompletionCallback>?*/  set _callbacks(value) { this.$setField(4, 4, value); }
            /*bool */ get IsCompleted()
            {
                return this._state !== null;
            }
            /*bool */ get IsFaulted()
            {
                return $.$is(this._state, $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo);
            }
            /*PipeCompletionCallbacks? */ TryComplete(/*Exception?*/ exception)
            {
                if (this._state === null)
                {
                    if (exception !== null)
                    {
                        this._state = $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exception);
                    }
                    else 
                    {
                        this._state = $.$sipl.System.IO.Pipelines.PipeCompletion.s_completedSuccessfully;
                    }
                }
                return this.GetCallbacks();
            }
            /*PipeCompletionCallbacks? */ AddCallback(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                this._callbacks ??= new ($.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback))().$ctor$1();
                this._callbacks.Add(new $.$sipl.System.IO.Pipelines.PipeCompletionCallback().$ctor$2(callback, state));
                if (this.IsCompleted)
                {
                    return this.GetCallbacks();
                }
                return null;
            }
            /*bool */ IsCompletedOrThrow()
            {
                if (!this.IsCompleted)
                {
                    return false;
                }
                let edi;
                if ($.$is(this._state, $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo, { set $v(v){ edi = v; } }))
                {
                    edi.Throw();
                }
                return true;
            }
            /*PipeCompletionCallbacks? */ GetCallbacks()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsCompleted, "IsCompleted");
                /*var*/ let callbacks = this._callbacks;
                if (callbacks === null)
                {
                    return null;
                }
                this._callbacks = null;
                return new $.$sipl.System.IO.Pipelines.PipeCompletionCallbacks().$ctor$1(callbacks, $.$as(this._state, $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo));
            }
            /*void */ Reset()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsCompleted, "IsCompleted");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._callbacks === null, "_callbacks == null");
                this._state = null;
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `${"IsCompleted"}: ${this.IsCompleted}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sipl.System.IO.Pipelines.PipeCompletion.ToString.apply(this, arguments); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._state = this._state;
                copy._callbacks = this._callbacks;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = null;
                this._callbacks = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_completedSuccessfully = new $.$spc.System.Object().$ctor();
                }
            }
            static $h = 1021947;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475858427,"f":1},"n":"IsCompleted","d":1021947,"h":17180891131,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065793019,"f":1},"n":"IsFaulted","d":1021947,"h":25770825723,"f":1}],"m":[{"r":1153019,"p":[{"n":"exception","p":47185921,"f":65}],"n":"TryComplete","d":1021947,"h":34360760315,"f":1},{"r":1153019,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"AddCallback","d":1021947,"h":38655727611,"f":1},{"r":262145,"n":"IsCompletedOrThrow","d":1021947,"h":42950694907,"f":1},{"r":1153019,"n":"GetCallbacks","d":1021947,"h":47245662203,"f":2},{"r":65537,"n":"Reset","d":1021947,"h":51540629499,"f":1},{"r":1310721,"n":"ToString","d":1021947,"h":55835596795,"f":32769}],"l":[{"t":131073,"n":"s_completedSuccessfully","d":1021947,"h":4295989243,"f":34},{"t":131073,"n":"_state","d":1021947,"h":8590956539,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h,"n":"_callbacks","d":1021947,"h":12885923835,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1021947,"h":60130564091,"f":1}],"h":1021947,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"IsCompleted = {IsCompleted}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletion`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeCompletionCallback", ($self) => class PipeCompletionCallback extends $.$spc.System.ValueType
        {
            /*Action<Exception?, object?>*/  get Callback() { return this.$getField(0, 4); }
            /*Action<Exception?, object?>*/  set Callback(value) { this.$setField(0, 4, value); }
            /*object?*/  get State() { return this.$getField(4, 4); }
            /*object?*/  set State(value) { this.$setField(4, 4, value); }
            $ctor$2(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                super.$ctor$1();
                {
                    this.Callback = callback;
                    this.State = state;
                }
                return this;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Callback = this.Callback;
                copy.State = this.State;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Callback = null;
                this.State = null;
            }
            static $h = 1087483;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h,"n":"Callback","d":1087483,"h":4296054779,"f":1},{"t":131073,"n":"State","d":1087483,"h":8591022075,"f":1}],"c":[{"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":".ctor","o":"$ctor$2","d":1087483,"h":12885989371,"f":1},{"n":".ctor","o":"$ctor$3","d":1087483,"h":17180956667,"f":1}],"h":1087483}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletionCallback`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeOperationState", ($self) => class PipeOperationState extends $.$spc.System.ValueType
        {
            /*State*/  get _state() { return this.$getField(0, $.$sipl.System.IO.Pipelines.PipeOperationState.State); }
            /*State*/  set _state(value) { this.$setField(0, $.$sipl.System.IO.Pipelines.PipeOperationState.State, value); }
            /*void */ BeginRead()
            {
                if ((this._state & 1/*State.Reading*/) === 1/*State.Reading*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                }
                this._state |= 1/*State.Reading*/;
            }
            /*void */ BeginReadTentative()
            {
                if ((this._state & 1/*State.Reading*/) === 1/*State.Reading*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                }
                this._state |= 2/*State.ReadingTentative*/;
            }
            /*void */ EndRead()
            {
                if ((this._state & 1/*State.Reading*/) !== 1/*State.Reading*/ && (this._state & 2/*State.ReadingTentative*/) !== 2/*State.ReadingTentative*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadToComplete();
                }
                this._state &= ~(1/*State.Reading*/ | 2/*State.ReadingTentative*/);
            }
            /*void */ BeginWrite()
            {
                this._state |= 4/*State.Writing*/;
            }
            /*void */ EndWrite()
            {
                this._state &= ~4/*State.Writing*/;
            }
            /*bool */ get IsWritingActive()
            {
                return (this._state & 4/*State.Writing*/) === 4/*State.Writing*/;
            }
            /*bool */ get IsReadingActive()
            {
                return (this._state & 1/*State.Reading*/) === 1/*State.Reading*/;
            }
            static $_State;
            static get State()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeOperationState;
                return $cls.$_State ??= $asm.$nstr("$sipl.System.IO.Pipelines.PipeOperationState.State", ($self) => class State extends $.$spc.System.Enum
                {
                    static Reading = 1;
                    static ReadingTentative = 2;
                    static Writing = 4;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Reading": 1n,
                            "ReadingTentative": 2n,
                            "Writing": 4n
                        };
                    }
                    static $h = 1284091;
                    static $z = 1;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Byte; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":1284091,"n":"Reading","d":1284091,"h":4296251387,"f":33},{"t":1284091,"n":"ReadingTentative","d":1284091,"h":8591218683,"f":33},{"t":1284091,"n":"Writing","d":1284091,"h":12886185979,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1284091,"h":17181153275,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":1218555,"h":1284091,"a":[{"t":47644673,"c":4342611969}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Pipelines.PipeOperationState.State`; }
                }, $cls, ($v) => $cls.$_State = $v);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._state = this._state;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = 0;
            }
            static $h = 1218555;
            static $z = 1;
            static $f = 0b10000000000001010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360956923,"f":1},"n":"IsWritingActive","d":1218555,"h":30065989627,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950891515,"f":1},"n":"IsReadingActive","d":1218555,"h":38655924219,"f":1}],"m":[{"r":65537,"n":"BeginRead","d":1218555,"h":8591153147,"f":1},{"r":65537,"n":"BeginReadTentative","d":1218555,"h":12886120443,"f":1},{"r":65537,"n":"EndRead","d":1218555,"h":17181087739,"f":1},{"r":65537,"n":"BeginWrite","d":1218555,"h":21476055035,"f":1},{"r":65537,"n":"EndWrite","d":1218555,"h":25771022331,"f":1}],"l":[{"t":1284091,"n":"_state","d":1218555,"h":4296185851,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1218555,"h":51540826107,"f":1}],"j":[1284091],"h":1218555,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"State = {_state}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeOperationState`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ReadResult", ($self) => class ReadResult extends $.$spc.System.ValueType
        {
            /*ReadOnlySequence<byte>*/  get _resultBuffer() { return this.$getField(0, 16); }
            /*ReadOnlySequence<byte>*/  set _resultBuffer(value) { this.$setField(0, 16, value); }
            /*ResultFlags*/  get _resultFlags() { return this.$getField(16, 1); }
            /*ResultFlags*/  set _resultFlags(value) { this.$setField(16, 1, value); }
            $ctor$2(/*ReadOnlySequence<byte>*/ buffer, /*bool*/ isCanceled, /*bool*/ isCompleted)
            {
                super.$ctor$1();
                {
                    this._resultBuffer = buffer;
                    this._resultFlags = 0/*ResultFlags.None*/;
                    if (isCompleted)
                    {
                        this._resultFlags |= 2/*ResultFlags.Completed*/;
                    }
                    if (isCanceled)
                    {
                        this._resultFlags |= 1/*ResultFlags.Canceled*/;
                    }
                }
                return this;
            }
            /*ReadOnlySequence<byte> */ get Buffer()
            {
                return this._resultBuffer;
            }
            /*bool */ get IsCanceled()
            {
                return (this._resultFlags & 1/*ResultFlags.Canceled*/) !== 0;
            }
            /*bool */ get IsCompleted()
            {
                return (this._resultFlags & 2/*ResultFlags.Completed*/) !== 0;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resultBuffer = this._resultBuffer.Clone();
                copy._resultFlags = this._resultFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resultBuffer = $.$default($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte));
                this._resultFlags = 0;
            }
            static $h = 1742843;
            static $z = 17;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":21476579323,"f":1},"n":"Buffer","d":1742843,"h":17181612027,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30066513915,"f":1},"n":"IsCanceled","d":1742843,"h":25771546619,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38656448507,"f":1},"n":"IsCompleted","d":1742843,"h":34361481211,"f":1}],"l":[{"t":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"n":"_resultBuffer","d":1742843,"h":4296710139,"f":8},{"t":1808379,"n":"_resultFlags","d":1742843,"h":8591677435,"f":8}],"c":[{"p":[{"n":"buffer","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h},{"n":"isCanceled","p":262145},{"n":"isCompleted","p":262145}],"n":".ctor","o":"$ctor$2","d":1742843,"h":12886644731,"f":1},{"n":".ctor","o":"$ctor$3","d":1742843,"h":42951415803,"f":1}],"h":1742843}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.ReadResult`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.SequencePipeReader", ($self) => class SequencePipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
        {
            /*ReadOnlySequence<byte>*/ _sequence;
            /*bool*/ _isReaderCompleted = false;
            /*int*/ _cancelNext = 0;
            $ctor$2(/*ReadOnlySequence<byte>*/ sequence)
            {
                super.$ctor$1();
                {
                    this._sequence = sequence;
                }
                return this;
            }
            /*void */ AdvanceTo(/*SequencePosition*/ consumed)
            {
                this.AdvanceTo$1(consumed, consumed);
            }
            /*void */ AdvanceTo$1(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
            {
                this.ThrowIfCompleted();
                if (consumed.Equals$2(this._sequence.End))
                {
                    this._sequence = $.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).Empty;
                    return;
                }
                this._sequence = this._sequence.Slice$7(consumed);
            }
            /*void */ CancelPendingRead()
            {
                $.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._cancelNext, ($v) => this._cancelNext = $v, $.$spc.System.Int32), 1);
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this._isReaderCompleted)
                {
                    return;
                }
                this._isReaderCompleted = true;
                this._sequence = $.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).Empty;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                /*ReadResult*/ let result;
                if (this.TryRead($.$ref(() => result, ($v) => result = $v, $.$sipl.System.IO.Pipelines.ReadResult)))
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(result);
                }
                result = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).Empty, false, true);
                return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(result);
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                this.ThrowIfCompleted();
                /*bool*/ let isCancellationRequested = $.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._cancelNext, ($v) => this._cancelNext = $v, $.$spc.System.Int32), 0) === 1;
                if (isCancellationRequested || this._sequence.Length > 0n)
                {
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(this._sequence, isCancellationRequested, true);
                    return true;
                }
                result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                return false;
            }
            /*void */ ThrowIfCompleted()
            {
                if (this._isReaderCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._sequence = $.$default($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte));
            }
            static $h = 1873915;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1415163,"m":[{"r":65537,"p":[{"n":"consumed","p":1226203}],"n":"AdvanceTo","d":1873915,"h":21476710395,"f":32769},{"r":65537,"p":[{"n":"consumed","p":1226203},{"n":"examined","p":1226203}],"n":"AdvanceTo","o":"@$1","d":1873915,"h":25771677691,"f":32769},{"r":65537,"n":"CancelPendingRead","d":1873915,"h":30066644987,"f":32769},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":1873915,"h":34361612283,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":1873915,"h":38656579579,"f":32769},{"r":262145,"p":[{"n":"result","p":1742843,"f":2}],"n":"TryRead","d":1873915,"h":42951546875,"f":32769},{"r":65537,"n":"ThrowIfCompleted","d":1873915,"h":47246514171,"f":2}],"l":[{"t":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"n":"_sequence","d":1873915,"h":4296841211,"f":2},{"t":262145,"n":"_isReaderCompleted","d":1873915,"h":8591808507,"f":2},{"t":655361,"n":"_cancelNext","d":1873915,"h":12886775803,"f":2}],"c":[{"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h}],"n":".ctor","o":"$ctor$2","d":1873915,"h":17181743099,"f":1}],"h":1873915}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
            static get $fullName() { return `System.IO.Pipelines.SequencePipeReader`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeReader", ($self) => class StreamPipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
        {
            /*int*/ static InitialSegmentPoolSize = 4;
            /*int*/ static MaxSegmentPoolSize = 256;
            /*CancellationTokenSource?*/ _internalTokenSource = null;
            /*bool*/ _isReaderCompleted = false;
            /*BufferSegment?*/ _readHead = null;
            /*int*/ _readIndex = 0;
            /*BufferSegment?*/ _readTail = null;
            /*long*/ _bufferedBytes = 0n;
            /*bool*/ _examinedEverything = false;
            /*object*/ _lock = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*StreamPipeReaderOptions*/ _options = null;
            $ctor$2(/*Stream*/ readingStream, /*StreamPipeReaderOptions*/ options)
            {
                super.$ctor$1();
                {
                    if (readingStream === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(10/*ExceptionArgument.readingStream*/);
                    }
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this.InnerStream = readingStream;
                    this._options = options;
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$2(4/*InitialSegmentPoolSize*/);
                }
                return this;
            }
            /*bool */ get LeaveOpen()
            {
                return this._options.LeaveOpen;
            }
            /*bool */ get UseZeroByteReads()
            {
                return this._options.UseZeroByteReads;
            }
            /*int */ get BufferSize()
            {
                return this._options.BufferSize;
            }
            /*int */ get MaxBufferSize()
            {
                return this._options.MaxBufferSize;
            }
            /*int */ get MinimumReadThreshold()
            {
                return this._options.MinimumReadSize;
            }
            /*MemoryPool<byte> */ get Pool()
            {
                return this._options.Pool;
            }
            /*Stream*/ InnerStream = null;
            /*void */ AdvanceTo(/*SequencePosition*/ consumed)
            {
                this.AdvanceTo$1(consumed, consumed);
            }
            /*CancellationTokenSource */ get InternalTokenSource()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        return this._internalTokenSource ??= new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
            }
            /*void */ AdvanceTo$1(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
            {
                this.ThrowIfCompleted();
                this.AdvanceTo$2($.$cast(consumed.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), consumed.GetInteger(), $.$cast(examined.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), examined.GetInteger());
            }
            /*void */ AdvanceTo$2(/*BufferSegment?*/ consumedSegment, /*int*/ consumedIndex, /*BufferSegment?*/ examinedSegment, /*int*/ examinedIndex)
            {
                if (consumedSegment === null || examinedSegment === null)
                {
                    return;
                }
                if (this._readHead === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AdvanceToInvalidCursor();
                }
                /*BufferSegment*/ let returnStart = this._readHead;
                /*BufferSegment?*/ let returnEnd = consumedSegment;
                /*long*/ let consumedBytes = $.$sipl.System.IO.Pipelines.BufferSegment.GetLength(returnStart, this._readIndex, consumedSegment, consumedIndex);
                this._bufferedBytes -= consumedBytes;
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bufferedBytes >= 0n, "_bufferedBytes >= 0");
                this._examinedEverything = false;
                if (examinedSegment === this._readTail)
                {
                    this._examinedEverything = examinedIndex === this._readTail.End;
                }
                if (this._bufferedBytes === 0n)
                {
                    returnEnd = null;
                    this._readHead = null;
                    this._readTail = null;
                    this._readIndex = 0;
                }
                else if (consumedIndex === returnEnd.Length)
                {
                    /*BufferSegment?*/ let nextBlock = returnEnd.NextSegment;
                    this._readHead = nextBlock;
                    this._readIndex = 0;
                    returnEnd = nextBlock;
                }
                else 
                {
                    this._readHead = consumedSegment;
                    this._readIndex = consumedIndex;
                }
                while(returnStart !== returnEnd)
                {
                    /*BufferSegment*/ let next = returnStart.NextSegment;
                    this.ReturnSegmentUnsynchronized(returnStart);
                    returnStart = next;
                }
            }
            /*void */ CancelPendingRead()
            {
                this.InternalTokenSource.Cancel();
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this.CompleteAndGetNeedsDispose())
                {
                    this.InnerStream.Dispose();
                }
            }
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                return this.CompleteAndGetNeedsDispose() ? this.InnerStream.DisposeAsync() : new $.$spc.System.Threading.Tasks.ValueTask();
            }
            /*bool */ CompleteAndGetNeedsDispose()
            {
                if (this._isReaderCompleted)
                {
                    return false;
                }
                this._isReaderCompleted = true;
                /*BufferSegment?*/ let segment = this._readHead;
                while(segment !== null)
                {
                    /*BufferSegment*/ let returnSegment = segment;
                    segment = segment.NextSegment;
                    returnSegment.Reset();
                }
                return !this.LeaveOpen;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                return this.ReadInternalAsync(null, cancellationToken);
            }
            /*ValueTask<ReadResult> */ ReadAtLeastAsyncCore(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadInternalAsync(minimumSize, cancellationToken);
            }
            /*ValueTask<ReadResult> */ ReadInternalAsync(/*int?*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfCompleted();
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.ReadResult, cancellationToken));
                }
                /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                /*ReadResult*/ let readResult;
                if (this.TryReadInternal(tokenSource, $.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult)))
                {
                    if (minimumSize === null || readResult.Buffer.Length >= minimumSize || readResult.IsCompleted || readResult.IsCanceled)
                    {
                        return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(readResult);
                    }
                }
                return Core(this, minimumSize, tokenSource, cancellationToken);
                /*static ValueTask<ReadResult>*/ /*async*/  function Core(/*StreamPipeReader*/ reader, /*int?*/ minimumSize, /*CancellationTokenSource*/ tokenSource, /*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult), $.$sipl.System.IO.Pipelines.ReadResult, async () => 
                    {
                        /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                        if (cancellationToken.CanBeCanceled)
                        {
                            reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/**/ state) =>
                            {
                                return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                            }), reader);
                        }
                        let $disposable2 = null;
                        try
                        {
                            $disposable2 = reg;
                            /*var*/ let isCanceled = false;
                            /*bool*/ let isCompleted = false;
                            try
                            {
                                if (reader.UseZeroByteReads && reader._bufferedBytes === 0n)
                                {
                                    await reader.InnerStream.ReadAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).Empty, tokenSource.Token).ConfigureAwait(false);
                                }
                                do
                                {
                                    reader.AllocateReadTail(minimumSize);
                                    /*Memory<byte>*/ let buffer = reader._readTail.AvailableMemory.Slice(reader._readTail.End);
                                    /*int*/ let length = await reader.InnerStream.ReadAsync$2(buffer, tokenSource.Token).ConfigureAwait(false);
                                    $.$spc.System.Diagnostics.Debug.Assert$1(((length + reader._readTail.End) | 0) <= reader._readTail.AvailableMemory.Length, "length + reader._readTail.End <= reader._readTail.AvailableMemory.Length");
                                    reader._readTail.End += length;
                                    reader._bufferedBytes += BigInt(length);
                                    if (length === 0)
                                    {
                                        isCompleted = true;
                                        break;
                                    }
                                }
                                while(minimumSize !== null && reader._bufferedBytes < minimumSize);
                            }
                            catch(ex)
                            {
                                reader.ClearCancellationToken();
                                if (cancellationToken.IsCancellationRequested)
                                {
                                    throw new $.$spc.System.OperationCanceledException().$ctor$14(ex.Message, ex, cancellationToken);
                                }
                                else if (tokenSource.IsCancellationRequested)
                                {
                                    isCanceled = true;
                                }
                                else 
                                {
                                    throw ex;
                                }
                            }
                            return new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(reader.GetCurrentReadOnlySequence(), isCanceled, isCompleted);
                        }
                        finally
                        {
                            $disposable2?.System$IDisposable$Dispose();
                        }
                    });
                }
            }
            /*Task *//*async*/  CopyToAsync(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.ThrowIfCompleted();
                    /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                    if (tokenSource.IsCancellationRequested)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                    }
                    /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                        }), this);
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._readHead;
                            /*int*/ let segmentIndex = this._readIndex;
                            try
                            {
                                while(segment !== null)
                                {
                                    /*FlushResult*/ let flushResult = await destination.WriteAsync(segment.Memory.Slice(segmentIndex), tokenSource.Token).ConfigureAwait(false);
                                    if (flushResult.IsCanceled)
                                    {
                                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                                    }
                                    segment = segment.NextSegment;
                                    segmentIndex = 0;
                                    if (flushResult.IsCompleted)
                                    {
                                        return;
                                    }
                                }
                            }
                            finally
                            {
                                {
                                    if (segment !== null)
                                    {
                                        this.AdvanceTo$2(segment, segment.End, segment, segment.End);
                                    }
                                }
                            }
                            await $.$sipl.System.IO.Pipelines.StreamPipeExtensions.CopyToAsync(this.InnerStream, destination, tokenSource.Token).ConfigureAwait(false);
                        }
                        catch($e)
                        {
                            this.ClearCancellationToken();
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*Task *//*async*/  CopyToAsync$1(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.ThrowIfCompleted();
                    /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                    if (tokenSource.IsCancellationRequested)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                    }
                    /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                        }), this);
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._readHead;
                            /*int*/ let segmentIndex = this._readIndex;
                            try
                            {
                                while(segment !== null)
                                {
                                    await destination.WriteAsync$2(segment.Memory.Slice(segmentIndex), tokenSource.Token).ConfigureAwait(false);
                                    segment = segment.NextSegment;
                                    segmentIndex = 0;
                                }
                            }
                            finally
                            {
                                {
                                    if (segment !== null)
                                    {
                                        this.AdvanceTo$2(segment, segment.End, segment, segment.End);
                                    }
                                }
                            }
                            await this.InnerStream.CopyToAsync$2(destination, tokenSource.Token).ConfigureAwait(false);
                        }
                        catch($e)
                        {
                            this.ClearCancellationToken();
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*void */ ClearCancellationToken()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        this._internalTokenSource = null;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
            }
            /*void */ ThrowIfCompleted()
            {
                if (this._isReaderCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                this.ThrowIfCompleted();
                return this.TryReadInternal(this.InternalTokenSource, result);
            }
            /*bool */ TryReadInternal(/*CancellationTokenSource*/ source, /*out ReadResult*/ result)
            {
                /*bool*/ let isCancellationRequested = source.IsCancellationRequested;
                if (isCancellationRequested || (this._bufferedBytes > 0n && !this._examinedEverything))
                {
                    if (isCancellationRequested)
                    {
                        this.ClearCancellationToken();
                    }
                    /*ReadOnlySequence<byte>*/ let buffer = this.GetCurrentReadOnlySequence();
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(buffer, isCancellationRequested, false);
                    return true;
                }
                result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                return false;
            }
            /*ReadOnlySequence<byte> */ GetCurrentReadOnlySequence()
            {
                return this._readHead === null ? new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))() : new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))().$ctor$3(this._readHead, this._readIndex, this._readTail, this._readTail.End);
            }
            /*void */ AllocateReadTail(/*int?*/ minimumSize)
            {
                if (this._readHead === null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readTail === null, "_readTail == null");
                    this._readHead = this.AllocateSegment(minimumSize);
                    this._readTail = this._readHead;
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readTail !== null, "_readTail != null");
                    if (this._readTail.WritableBytes < this.MinimumReadThreshold)
                    {
                        /*BufferSegment*/ let nextSegment = this.AllocateSegment(minimumSize);
                        this._readTail.SetNext(nextSegment);
                        this._readTail = nextSegment;
                    }
                }
            }
            /*BufferSegment */ AllocateSegment(/*int?*/ minimumSize)
            {
                /*BufferSegment*/ let nextSegment = this.CreateSegmentUnsynchronized();
                /*var*/ let bufferSize = minimumSize ?? this.BufferSize;
                /*int*/ let maxSize = !this._options.IsDefaultSharedMemoryPool ? this._options.Pool.MaxBufferSize : -1;
                if (bufferSize <= maxSize)
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(bufferSize, maxSize);
                    nextSegment.SetOwnedMemory(this._options.Pool.Rent(sizeToRequest));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(bufferSize, this.MaxBufferSize);
                    nextSegment.SetOwnedMemory$1($.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(sizeToRequest));
                }
                return nextSegment;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$spc.System.Math.Max$4(this.BufferSize, sizeHint);
                /*int*/ let adjustedToMaximumSize = $.$spc.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readHead, "Returning _readHead segment that's in use!");
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readTail, "Returning _readTail segment that's in use!");
                segment.Reset();
                if (this._bufferSegmentPool.Count < 256/*MaxSegmentPoolSize*/)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*void */ Cancel()
            {
                this.InternalTokenSource.Cancel();
            }
            //default member initializer
            constructor()
            {
                super();
                this._lock = new $.$spc.System.Object().$ctor();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
            }
            static $h = 2004987;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1415163,"p":[{"p":262145,"g":{"r":0,"d":0,"h":64426514427,"f":2},"n":"LeaveOpen","d":2004987,"h":60131547131,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":73016449019,"f":2},"n":"UseZeroByteReads","d":2004987,"h":68721481723,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":81606383611,"f":2},"n":"BufferSize","d":2004987,"h":77311416315,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":90196318203,"f":2},"n":"MaxBufferSize","d":2004987,"h":85901350907,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":98786252795,"f":2},"n":"MinimumReadThreshold","d":2004987,"h":94491285499,"f":2},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":107376187387,"f":2},"n":"Pool","d":2004987,"h":103081220091,"f":2},{"p":62128129,"g":{"r":0,"d":0,"h":120261089275,"f":1},"n":"InnerStream","d":2004987,"h":115966121979,"f":1},{"p":126091265,"g":{"r":0,"d":0,"h":133145991163,"f":2},"n":"InternalTokenSource","d":2004987,"h":128851023867,"f":2}],"m":[{"r":65537,"p":[{"n":"consumed","p":1226203}],"n":"AdvanceTo","d":2004987,"h":124556056571,"f":32769},{"r":65537,"p":[{"n":"consumed","p":1226203},{"n":"examined","p":1226203}],"n":"AdvanceTo","o":"@$1","d":2004987,"h":137440958459,"f":32769},{"r":65537,"p":[{"n":"consumedSegment","p":104443},{"n":"consumedIndex","p":655361},{"n":"examinedSegment","p":104443},{"n":"examinedIndex","p":655361}],"n":"AdvanceTo","o":"@$2","d":2004987,"h":141735925755,"f":2},{"r":65537,"n":"CancelPendingRead","d":2004987,"h":146030893051,"f":32769},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":2004987,"h":150325860347,"f":32769},{"r":136118273,"p":[{"n":"exception","p":47185921,"f":65}],"n":"CompleteAsync","d":2004987,"h":154620827643,"f":32769},{"r":262145,"n":"CompleteAndGetNeedsDispose","d":2004987,"h":158915794939,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":2004987,"h":163210762235,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAtLeastAsyncCore","d":2004987,"h":167505729531,"f":32772},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":$.$typeNullable($.$spc.System.Int32).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadInternalAsync","d":2004987,"h":171800696827,"f":2},{"r":133300225,"p":[{"n":"destination","p":1611771},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","d":2004987,"h":176095664123,"f":36865},{"r":133300225,"p":[{"n":"destination","p":62128129},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","o":"@$1","d":2004987,"h":180390631419,"f":36865},{"r":65537,"n":"ClearCancellationToken","d":2004987,"h":184685598715,"f":2},{"r":65537,"n":"ThrowIfCompleted","d":2004987,"h":188980566011,"f":2},{"r":262145,"p":[{"n":"result","p":1742843,"f":2}],"n":"TryRead","d":2004987,"h":193275533307,"f":32769},{"r":262145,"p":[{"n":"source","p":126091265},{"n":"result","p":1742843,"f":2}],"n":"TryReadInternal","d":2004987,"h":197570500603,"f":2},{"r":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"n":"GetCurrentReadOnlySequence","d":2004987,"h":201865467899,"f":2},{"r":65537,"p":[{"n":"minimumSize","p":$.$typeNullable($.$spc.System.Int32).$h,"f":65}],"n":"AllocateReadTail","d":2004987,"h":206160435195,"f":2},{"r":104443,"p":[{"n":"minimumSize","p":$.$typeNullable($.$spc.System.Int32).$h,"f":65}],"n":"AllocateSegment","d":2004987,"h":210455402491,"f":2},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361}],"n":"GetSegmentSize","d":2004987,"h":214750369787,"f":2},{"r":104443,"n":"CreateSegmentUnsynchronized","d":2004987,"h":219045337083,"f":2},{"r":65537,"p":[{"n":"segment","p":104443}],"n":"ReturnSegmentUnsynchronized","d":2004987,"h":223340304379,"f":2},{"r":65537,"n":"Cancel","d":2004987,"h":227635271675,"f":2}],"l":[{"t":655361,"n":"InitialSegmentPoolSize","d":2004987,"h":4296972283,"f":40},{"t":655361,"n":"MaxSegmentPoolSize","d":2004987,"h":8591939579,"f":40},{"t":126091265,"n":"_internalTokenSource","d":2004987,"h":12886906875,"f":2},{"t":262145,"n":"_isReaderCompleted","d":2004987,"h":17181874171,"f":2},{"t":104443,"n":"_readHead","d":2004987,"h":21476841467,"f":2},{"t":655361,"n":"_readIndex","d":2004987,"h":25771808763,"f":2},{"t":104443,"n":"_readTail","d":2004987,"h":30066776059,"f":2},{"t":917505,"n":"_bufferedBytes","d":2004987,"h":34361743355,"f":2},{"t":262145,"n":"_examinedEverything","d":2004987,"h":38656710651,"f":2},{"t":131073,"n":"_lock","d":2004987,"h":42951677947,"f":2},{"t":169979,"n":"_bufferSegmentPool","d":2004987,"h":47246645243,"f":2},{"t":2070523,"n":"_options","d":2004987,"h":51541612539,"f":2}],"c":[{"p":[{"n":"readingStream","p":62128129},{"n":"options","p":2070523}],"n":".ctor","o":"$ctor$2","d":2004987,"h":55836579835,"f":1}],"h":2004987}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeReader`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.ThreadPoolScheduler", ($self) => class ThreadPoolScheduler extends $.$sipl.System.IO.Pipelines.PipeScheduler
        {
            /*void */ Schedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                $.$spc.System.Threading.ThreadPool.QueueUserWorkItem$2($.$spc.System.Object, action, state, false);
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                $.$spc.System.Threading.ThreadPool.UnsafeQueueUserWorkItem($.$spc.System.Object, action, state, false);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2267131;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1546235,"m":[{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":2267131,"h":4297234427,"f":32769},{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":2267131,"h":8592201723,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":2267131,"h":12887169019,"f":1}],"h":2267131}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeScheduler; }
            static get $fullName() { return `System.IO.Pipelines.ThreadPoolScheduler`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeReaderStream", ($self) => class PipeReaderStream extends $.$spc.System.IO.Stream
        {
            /*PipeReader*/ _pipeReader = null;
            $ctor$3(/*PipeReader*/ pipeReader, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(pipeReader !== null, "pipeReader != null");
                    this._pipeReader = pipeReader;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this.LeaveOpen)
                {
                    this._pipeReader.Complete(null);
                }
                super.Dispose$1(disposing);
            }
            /*bool */ get CanRead()
            {
                return true;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*bool*/ LeaveOpen = false;
            /*void */ Flush()
            {
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                return this.ReadInternal(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count));
            }
            /*int */ ReadByte()
            {
                /*Span<byte>*/ let oneByte = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 1, null);
                return this.ReadInternal(oneByte) === 0 ? -1 : oneByte.get_Item(0).$v;
            }
            /*int */ ReadInternal(/*Span<byte>*/ buffer)
            {
                /*ValueTask<ReadResult>*/ let vt = this._pipeReader.ReadAsync(new $.$spc.System.Threading.CancellationToken());
                /*ReadResult*/ let result = vt.IsCompletedSuccessfully ? vt.Result : vt.AsTask().GetAwaiter$1().GetResult();
                return this.HandleReadResult(result, buffer);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.ReadAsync$1(buffer, offset, count, new $.$spc.System.Threading.CancellationToken()), callback, state);
            }
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.End$1($.$spc.System.Int32, asyncResult);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                return this.ReadAsyncInternal(new ($.$spc.System.Memory$$($.$spc.System.Byte))().$ctor$4(buffer, offset, count), cancellationToken).AsTask();
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                return this.ReadInternal(buffer);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadAsyncInternal(buffer, cancellationToken);
            }
            /*ValueTask<int> *//*async*/  ReadAsyncInternal(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                {
                    /*ReadResult*/ let result = await this._pipeReader.ReadAsync(cancellationToken).ConfigureAwait(false);
                    return this.HandleReadResult(result, buffer.Span);
                });
            }
            /*int */ HandleReadResult(/*ReadResult*/ result, /*Span<byte>*/ buffer)
            {
                if (result.IsCanceled)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                }
                /*ReadOnlySequence<byte>*/ let sequence = result.Buffer;
                /*long*/ let bufferLength = sequence.Length;
                /*SequencePosition*/ let consumed = sequence.Start;
                try
                {
                    if (bufferLength !== 0n)
                    {
                        /*int*/ let actual = $.$cast($.$spc.System.Math.Min$5(bufferLength, BigInt(buffer.Length)), $.$spc.System.Int32);
                        /*ReadOnlySequence<byte>*/ let slice = BigInt(actual) === bufferLength ? sequence : sequence.Slice$3(0, actual);
                        consumed = slice.End;
                        $.$sm.System.Buffers.BuffersExtensions.CopyTo($.$spc.System.Byte, $.$ref(() => slice, ), buffer);
                        return actual;
                    }
                    if (result.IsCompleted)
                    {
                        return 0;
                    }
                }
                finally
                {
                    {
                        this._pipeReader.AdvanceTo(consumed);
                    }
                }
                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_InvalidZeroByteRead();
                return 0;
            }
            /*Task */ CopyToAsync$3(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                $.$sipl.System.IO.StreamHelpers.ValidateCopyToArgs(this, destination, bufferSize);
                return this._pipeReader.CopyToAsync$1(destination, cancellationToken);
            }
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            static $h = 1480699;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476317179,"f":32769},"n":"CanRead","d":1480699,"h":17181349883,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":30066251771,"f":32769},"n":"CanSeek","d":1480699,"h":25771284475,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38656186363,"f":32769},"n":"CanWrite","d":1480699,"h":34361219067,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":47246120955,"f":32769},"n":"Length","d":1480699,"h":42951153659,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":55836055547,"f":32769},"s":{"r":0,"d":0,"h":60131022843,"f":32769},"n":"Position","d":1480699,"h":51541088251,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":73015924731,"f":8},"s":{"r":0,"d":0,"h":77310892027,"f":8},"n":"LeaveOpen","d":1480699,"h":68720957435,"f":8}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1480699,"h":12886382587,"f":32772},{"r":65537,"n":"Flush","d":1480699,"h":81605859323,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1480699,"h":85900826619,"f":32769},{"r":655361,"n":"ReadByte","d":1480699,"h":90195793915,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"ReadInternal","d":1480699,"h":94490761211,"f":2},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1480699,"h":98785728507,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1480699,"h":103080695803,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1480699,"h":107375663099,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginRead","d":1480699,"h":111670630395,"f":98305},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":1480699,"h":115965597691,"f":98305},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1480699,"h":120260564987,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1480699,"h":124555532283,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1480699,"h":128850499579,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadAsyncInternal","d":1480699,"h":133145466875,"f":4098},{"r":655361,"p":[{"n":"result","p":1742843},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"HandleReadResult","d":1480699,"h":137440434171,"f":2},{"r":133300225,"p":[{"n":"destination","p":62128129},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"CopyToAsync","o":"@$3","d":1480699,"h":141735401467,"f":32769}],"l":[{"t":1415163,"n":"_pipeReader","d":1480699,"h":4296447995,"f":2}],"c":[{"p":[{"n":"pipeReader","p":1415163},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":1480699,"h":8591415291,"f":1}],"i":[57475073,56885249],"h":1480699}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeReaderStream`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeWriterStream", ($self) => class PipeWriterStream extends $.$spc.System.IO.Stream
        {
            /*PipeWriter*/ _pipeWriter = null;
            $ctor$3(/*PipeWriter*/ pipeWriter, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(pipeWriter !== null, "pipeWriter != null");
                    this._pipeWriter = pipeWriter;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this.LeaveOpen)
                {
                    this._pipeWriter.Complete(null);
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                if (!this.LeaveOpen)
                {
                    return this._pipeWriter.CompleteAsync(null);
                }
                return new $.$spc.System.Threading.Tasks.ValueTask();
            }
            /*bool*/ LeaveOpen = false;
            /*bool */ get CanRead()
            {
                return false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return true;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Flush()
            {
                this.FlushAsync().GetAwaiter().GetResult();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.WriteAsync$1(buffer, offset, count, new $.$spc.System.Threading.CancellationToken()), callback, state);
            }
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.End(asyncResult);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                return this.WriteAsync(buffer, offset, count).GetAwaiter().GetResult();
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.WriteAsync(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count), cancellationToken);
                return $.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.WriteAsync(buffer, cancellationToken);
                return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask));
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.FlushAsync(cancellationToken);
                return $.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask);
            }
            static /*Task */ GetFlushResultAsTask(/*ValueTask<FlushResult>*/ valueTask)
            {
                if (valueTask.IsCompletedSuccessfully)
                {
                    /*FlushResult*/ let result = valueTask.Result;
                    if (result.IsCanceled)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                    }
                    return $.$spc.System.Threading.Tasks.Task.CompletedTask;
                }
                /*static Task*/ /*async*/  function AwaitTask(/*ValueTask<FlushResult>*/ valueTask)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                    {
                        /*FlushResult*/ let result = await valueTask.ConfigureAwait(false);
                        if (result.IsCanceled)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                        }
                    });
                }
                return AwaitTask(valueTask);
            }
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            static $h = 1677307;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066448379,"f":8},"s":{"r":0,"d":0,"h":34361415675,"f":8},"n":"LeaveOpen","d":1677307,"h":25771481083,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":42951350267,"f":32769},"n":"CanRead","d":1677307,"h":38656382971,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51541284859,"f":32769},"n":"CanSeek","d":1677307,"h":47246317563,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60131219451,"f":32769},"n":"CanWrite","d":1677307,"h":55836252155,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68721154043,"f":32769},"n":"Length","d":1677307,"h":64426186747,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":77311088635,"f":32769},"s":{"r":0,"d":0,"h":81606055931,"f":32769},"n":"Position","d":1677307,"h":73016121339,"f":32769}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1677307,"h":12886579195,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1677307,"h":17181546491,"f":32769},{"r":65537,"n":"Flush","d":1677307,"h":85901023227,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1677307,"h":90195990523,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1677307,"h":94490957819,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1677307,"h":98785925115,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWrite","d":1677307,"h":103080892411,"f":98305},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":1677307,"h":107375859707,"f":98305},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1677307,"h":111670827003,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1677307,"h":115965794299,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1677307,"h":120260761595,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1677307,"h":124555728891,"f":32769},{"r":133300225,"p":[{"n":"valueTask","p":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h}],"n":"GetFlushResultAsTask","d":1677307,"h":128850696187,"f":34}],"l":[{"t":1611771,"n":"_pipeWriter","d":1677307,"h":4296644603,"f":2}],"c":[{"p":[{"n":"pipeWriter","p":1611771},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":1677307,"h":8591611899,"f":1}],"i":[57475073,56885249],"h":1677307}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeWriterStream`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ResultFlags", ($self) => class ResultFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static Canceled = 1;
            static Completed = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Canceled": 1n,
                    "Completed": 2n
                };
            }
            static $h = 1808379;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":1808379,"n":"None","d":1808379,"h":4296775675,"f":33},{"t":1808379,"n":"Canceled","d":1808379,"h":8591742971,"f":33},{"t":1808379,"n":"Completed","d":1808379,"h":12886710267,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1808379,"h":17181677563,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1808379,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipelines.ResultFlags`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ExceptionArgument", ($self) => class ExceptionArgument extends $.$spc.System.Enum
        {
            static minimumSize = 0;
            static bytes = 1;
            static callback = 2;
            static options = 3;
            static pauseWriterThreshold = 4;
            static resumeWriterThreshold = 5;
            static sizeHint = 6;
            static destination = 7;
            static buffer = 8;
            static source = 9;
            static readingStream = 10;
            static writingStream = 11;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "minimumSize": 0n,
                    "bytes": 1n,
                    "callback": 2n,
                    "options": 3n,
                    "pauseWriterThreshold": 4n,
                    "resumeWriterThreshold": 5n,
                    "sizeHint": 6n,
                    "destination": 7n,
                    "buffer": 8n,
                    "source": 9n,
                    "readingStream": 10n,
                    "writingStream": 11n
                };
            }
            static $h = 366587;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":366587,"n":"minimumSize","d":366587,"h":4295333883,"f":33},{"t":366587,"n":"bytes","d":366587,"h":8590301179,"f":33},{"t":366587,"n":"callback","d":366587,"h":12885268475,"f":33},{"t":366587,"n":"options","d":366587,"h":17180235771,"f":33},{"t":366587,"n":"pauseWriterThreshold","d":366587,"h":21475203067,"f":33},{"t":366587,"n":"resumeWriterThreshold","d":366587,"h":25770170363,"f":33},{"t":366587,"n":"sizeHint","d":366587,"h":30065137659,"f":33},{"t":366587,"n":"destination","d":366587,"h":34360104955,"f":33},{"t":366587,"n":"buffer","d":366587,"h":38655072251,"f":33},{"t":366587,"n":"source","d":366587,"h":42950039547,"f":33},{"t":366587,"n":"readingStream","d":366587,"h":47245006843,"f":33},{"t":366587,"n":"writingStream","d":366587,"h":51539974139,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":366587,"h":55834941435,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":366587}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipelines.ExceptionArgument`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.BufferSegment", ($self) => class BufferSegment extends $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$spc.System.Byte)
        {
            /*IMemoryOwner<byte>?*/ _memoryOwner = null;
            /*byte[]?*/ _array = null;
            /*BufferSegment?*/ _next = null;
            /*int*/ _end = 0;
            /*int */ get End()
            {
                return this._end;
            }
            /*int */ set End(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value <= this.AvailableMemory.Length, "value <= AvailableMemory.Length");
                this._end = value;
                this.Memory = $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2(this.AvailableMemory.Slice$1(0, value));
            }
            /*BufferSegment? */ get NextSegment()
            {
                return this._next;
            }
            /*BufferSegment? */ set NextSegment(value)
            {
                this.Next = value;
                this._next = value;
            }
            /*void */ SetOwnedMemory(/*IMemoryOwner<byte>*/ memoryOwner)
            {
                this._memoryOwner = memoryOwner;
                this.AvailableMemory = memoryOwner.System$Buffers$IMemoryOwner$$$Memory;
            }
            /*void */ SetOwnedMemory$1(/*byte[]*/ arrayPoolBuffer)
            {
                this._array = arrayPoolBuffer;
                this.AvailableMemory = $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(arrayPoolBuffer);
            }
            /*void */ Reset()
            {
                this.ResetMemory();
                this.Next = null;
                this.RunningIndex = 0n;
                this._next = null;
            }
            /*void */ ResetMemory()
            {
                /*IMemoryOwner<byte>?*/ let memoryOwner = this._memoryOwner;
                if (memoryOwner !== null)
                {
                    this._memoryOwner = null;
                    memoryOwner.System$IDisposable$Dispose();
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._array !== null, "_array != null");
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(this._array, false);
                    this._array = null;
                }
                this.Memory = new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))();
                this._end = 0;
                this.AvailableMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
            }
            /*object? */ get MemoryOwner()
            {
                return $.$cast(this._memoryOwner, $.$spc.System.Object) ?? this._array;
            }
            /*Memory<byte>*/ AvailableMemory;
            /*int */ get Length()
            {
                return this.End;
            }
            /*int */ get WritableBytes()
            {
                return ((this.AvailableMemory.Length - this.End) | 0);
            }
            /*void */ SetNext(/*BufferSegment*/ segment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== null, "segment != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this.Next === null, "Next == null");
                this.NextSegment = segment;
                segment = this;
                while(segment.Next !== null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(segment.NextSegment !== null, "segment.NextSegment != null");
                    segment.NextSegment.RunningIndex = segment.RunningIndex + BigInt(segment.Length);
                    segment = segment.NextSegment;
                }
            }
            static /*long */ GetLength(/*BufferSegment*/ startSegment, /*int*/ startIndex, /*BufferSegment*/ endSegment, /*int*/ endIndex)
            {
                return (endSegment.RunningIndex + BigInt((endIndex >>> 0))) - (startSegment.RunningIndex + BigInt((startIndex >>> 0)));
            }
            static /*long */ GetLength$1(/*long*/ startPosition, /*BufferSegment*/ endSegment, /*int*/ endIndex)
            {
                return (endSegment.RunningIndex + BigInt((endIndex >>> 0))) - startPosition;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.AvailableMemory = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
            }
            static $h = 104443;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":655361,"g":{"r":0,"d":0,"h":25769908219,"f":1},"s":{"r":0,"d":0,"h":30064875515,"f":1},"n":"End","d":104443,"h":21474940923,"f":1},{"p":104443,"g":{"r":0,"d":0,"h":38654810107,"f":1},"s":{"r":0,"d":0,"h":42949777403,"f":1},"n":"NextSegment","d":104443,"h":34359842811,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":68719581179,"f":8},"n":"MemoryOwner","d":104443,"h":64424613883,"f":8},{"p":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":81604483067,"f":1},"s":{"r":0,"d":0,"h":85899450363,"f":2},"n":"AvailableMemory","d":104443,"h":77309515771,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":94489384955,"f":1},"n":"Length","d":104443,"h":90194417659,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103079319547,"f":1},"n":"WritableBytes","d":104443,"h":98784352251,"f":1}],"m":[{"r":65537,"p":[{"n":"memoryOwner","p":$.$spc.System.Buffers.IMemoryOwner$$($.$spc.System.Byte).$h}],"n":"SetOwnedMemory","d":104443,"h":47244744699,"f":1},{"r":65537,"p":[{"n":"arrayPoolBuffer","p":0}],"n":"SetOwnedMemory","o":"@$1","d":104443,"h":51539711995,"f":1},{"r":65537,"n":"Reset","d":104443,"h":55834679291,"f":1},{"r":65537,"n":"ResetMemory","d":104443,"h":60129646587,"f":1},{"r":65537,"p":[{"n":"segment","p":104443}],"n":"SetNext","d":104443,"h":107374286843,"f":1},{"r":917505,"p":[{"n":"startSegment","p":104443},{"n":"startIndex","p":655361},{"n":"endSegment","p":104443},{"n":"endIndex","p":655361}],"n":"GetLength","d":104443,"h":111669254139,"f":40},{"r":917505,"p":[{"n":"startPosition","p":917505},{"n":"endSegment","p":104443},{"n":"endIndex","p":655361}],"n":"GetLength","o":"@$1","d":104443,"h":115964221435,"f":40}],"l":[{"t":$.$spc.System.Buffers.IMemoryOwner$$($.$spc.System.Byte).$h,"n":"_memoryOwner","d":104443,"h":4295071739,"f":2},{"t":0,"n":"_array","d":104443,"h":8590039035,"f":2},{"t":104443,"n":"_next","d":104443,"h":12885006331,"f":2},{"t":655361,"n":"_end","d":104443,"h":17179973627,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":104443,"h":120259188731,"f":1}],"h":104443}; }
            static get $b() { return $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$spc.System.Byte); }
            static get $fullName() { return `System.IO.Pipelines.BufferSegment`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeWriter", ($self) => class StreamPipeWriter extends $.$sipl.System.IO.Pipelines.PipeWriter
        {
            /*int*/ static InitialSegmentPoolSize = 4;
            /*int*/ static MaxSegmentPoolSize = 256;
            /*int*/ _minimumBufferSize = 0;
            /*BufferSegment?*/ _head = null;
            /*BufferSegment?*/ _tail = null;
            /*Memory<byte>*/ _tailMemory;
            /*int*/ _tailBytesBuffered = 0;
            /*long*/ _bytesBuffered = 0n;
            /*MemoryPool<byte>?*/ _pool = null;
            /*int*/ _maxPooledBufferSize = 0;
            /*CancellationTokenSource?*/ _internalTokenSource = null;
            /*bool*/ _isCompleted = false;
            /*object*/ _lockObject = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*bool*/ _leaveOpen = false;
            /*CancellationTokenSource */ get InternalTokenSource()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lockObject)
                    {
                        return this._internalTokenSource ??= new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lockObject)
                }
            }
            $ctor$2(/*Stream*/ writingStream, /*StreamPipeWriterOptions*/ options)
            {
                super.$ctor$1();
                {
                    if (writingStream === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(11/*ExceptionArgument.writingStream*/);
                    }
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this.InnerStream = writingStream;
                    this._minimumBufferSize = options.MinimumBufferSize;
                    this._pool = options.Pool === $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared ? null : options.Pool;
                    this._maxPooledBufferSize = (this._pool?.MaxBufferSize ?? null) ?? -1;
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$2(4/*InitialSegmentPoolSize*/);
                    this._leaveOpen = options.LeaveOpen;
                }
                return this;
            }
            /*Stream*/ InnerStream = null;
            /*void */ Advance(/*int*/ bytes)
            {
                if ((bytes >>> 0) > (this._tailMemory.Length >>> 0))
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.bytes*/);
                }
                this._tailBytesBuffered += bytes;
                this._bytesBuffered += BigInt(bytes);
                this._tailMemory = this._tailMemory.Slice(bytes);
            }
            /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
            {
                if (this._isCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateMemory(sizeHint);
                return this._tailMemory;
            }
            /*Span<byte> */ GetSpan(/*int*/ sizeHint)
            {
                if (this._isCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateMemory(sizeHint);
                return this._tailMemory.Span;
            }
            /*void */ AllocateMemory(/*int*/ sizeHint)
            {
                if (this._head === null)
                {
                    /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                    this._head = this._tail = newSegment;
                    this._tailBytesBuffered = 0;
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._tail !== null, "_tail != null");
                    /*int*/ let bytesLeftInBuffer = this._tailMemory.Length;
                    if (bytesLeftInBuffer === 0 || bytesLeftInBuffer < sizeHint)
                    {
                        if (this._tailBytesBuffered > 0)
                        {
                            this._tail.End += this._tailBytesBuffered;
                            this._tailBytesBuffered = 0;
                        }
                        /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                        this._tail.SetNext(newSegment);
                        this._tail = newSegment;
                    }
                }
            }
            /*BufferSegment */ AllocateSegment(/*int*/ sizeHint)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(sizeHint >= 0, "sizeHint >= 0");
                /*BufferSegment*/ let newSegment = this.CreateSegmentUnsynchronized();
                /*int*/ let maxSize = this._maxPooledBufferSize;
                if (sizeHint <= maxSize)
                {
                    newSegment.SetOwnedMemory(this._pool.Rent(this.GetSegmentSize(sizeHint, maxSize)));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(sizeHint, 2147483647);
                    newSegment.SetOwnedMemory$1($.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(sizeToRequest));
                }
                this._tailMemory = newSegment.AvailableMemory;
                return newSegment;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$spc.System.Math.Max$4(this._minimumBufferSize, sizeHint);
                /*var*/ let adjustedToMaximumSize = $.$spc.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                segment.Reset();
                if (this._bufferSegmentPool.Count < 256/*MaxSegmentPoolSize*/)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*void */ CancelPendingFlush()
            {
                this.Cancel();
            }
            /*bool */ get CanGetUnflushedBytes()
            {
                return true;
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this._isCompleted)
                {
                    return;
                }
                this._isCompleted = true;
                try
                {
                    this.FlushInternal(exception === null);
                }
                finally
                {
                    {
                        this._internalTokenSource?.Dispose();
                        if (!this._leaveOpen)
                        {
                            this.InnerStream.Dispose();
                        }
                    }
                }
            }
            /*ValueTask *//*async*/  CompleteAsync(/*Exception?*/ exception)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    if (this._isCompleted)
                    {
                        return;
                    }
                    this._isCompleted = true;
                    try
                    {
                        await this.FlushAsyncInternal(exception === null, $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.Memory$$($.$spc.System.Byte).Empty), new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    }
                    finally
                    {
                        {
                            this._internalTokenSource?.Dispose();
                            if (!this._leaveOpen)
                            {
                                await this.InnerStream.DisposeAsync().ConfigureAwait(false);
                            }
                        }
                    }
                });
            }
            /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
            {
                if (this._bytesBuffered === 0n)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false));
                }
                return this.FlushAsyncInternal(true, $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.Memory$$($.$spc.System.Byte).Empty), new $.$spc.System.Threading.CancellationToken());
            }
            /*long */ get UnflushedBytes()
            {
                return this._bytesBuffered;
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                return this.FlushAsyncInternal(true, source, new $.$spc.System.Threading.CancellationToken());
            }
            /*void */ Cancel()
            {
                this.InternalTokenSource.Cancel();
            }
            /*ValueTask<FlushResult> *//*async*/  FlushAsyncInternal(/*bool*/ writeToStream, /*ReadOnlyMemory<byte>*/ data, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult), $.$sipl.System.IO.Pipelines.FlushResult, async () => 
                {
                    /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/**/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeWriter)).Cancel();
                        }), this);
                    }
                    if (this._tailBytesBuffered > 0)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._tail !== null, "_tail != null");
                        this._tail.End += this._tailBytesBuffered;
                        this._tailBytesBuffered = 0;
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        /*CancellationToken*/ let localToken = this.InternalTokenSource.Token;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._head;
                            while(segment !== null)
                            {
                                /*BufferSegment*/ let returnSegment = segment;
                                segment = segment.NextSegment;
                                if (returnSegment.Length > 0 && writeToStream)
                                {
                                    await this.InnerStream.WriteAsync$2(returnSegment.Memory, localToken).ConfigureAwait(false);
                                }
                                this.ReturnSegmentUnsynchronized(returnSegment);
                                this._head = segment;
                            }
                            if (writeToStream)
                            {
                                if (data.Length > 0)
                                {
                                    await this.InnerStream.WriteAsync$2(data, localToken).ConfigureAwait(false);
                                }
                                if (this._bytesBuffered > 0n || data.Length > 0)
                                {
                                    await this.InnerStream.FlushAsync$1(localToken).ConfigureAwait(false);
                                }
                            }
                            this._head = null;
                            this._tail = null;
                            this._tailMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                            this._bytesBuffered = 0n;
                            return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false);
                        }
                        catch($e)
                        {
                            //lock
                            try
                            {
                                $.$spc.System.Threading.Monitor.Enter(this._lockObject)
                                {
                                    this._internalTokenSource = null;
                                }
                            }
                            finally
                            {
                                $.$spc.System.Threading.Monitor.Exit(this._lockObject)
                            }
                            if (localToken.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
                            {
                                return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(true, false);
                            }
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*void */ FlushInternal(/*bool*/ writeToStream)
            {
                if (this._tailBytesBuffered > 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._tail !== null, "_tail != null");
                    this._tail.End += this._tailBytesBuffered;
                    this._tailBytesBuffered = 0;
                }
                /*BufferSegment?*/ let segment = this._head;
                while(segment !== null)
                {
                    /*BufferSegment*/ let returnSegment = segment;
                    segment = segment.NextSegment;
                    if (returnSegment.Length > 0 && writeToStream)
                    {
                        this.InnerStream.Write$1(returnSegment.Memory.Span);
                    }
                    this.ReturnSegmentUnsynchronized(returnSegment);
                    this._head = segment;
                }
                if (this._bytesBuffered > 0n && writeToStream)
                {
                    this.InnerStream.Flush();
                }
                this._head = null;
                this._tail = null;
                this._tailMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                this._bytesBuffered = 0n;
            }
            //default member initializer
            constructor()
            {
                super();
                this._tailMemory = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
                this._lockObject = new $.$spc.System.Object().$ctor();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
            }
            static $h = 2136059;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1611771,"p":[{"p":126091265,"g":{"r":0,"d":0,"h":73016580091,"f":2},"n":"InternalTokenSource","d":2136059,"h":68721612795,"f":2},{"p":62128129,"g":{"r":0,"d":0,"h":90196449275,"f":1},"n":"InnerStream","d":2136059,"h":85901481979,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":137441089531,"f":32769},"n":"CanGetUnflushedBytes","d":2136059,"h":133146122235,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":158915926011,"f":32769},"n":"UnflushedBytes","d":2136059,"h":154620958715,"f":32769}],"m":[{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":2136059,"h":94491416571,"f":32769},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":2136059,"h":98786383867,"f":32769},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":2136059,"h":103081351163,"f":32769},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateMemory","d":2136059,"h":107376318459,"f":2},{"r":104443,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateSegment","d":2136059,"h":111671285755,"f":2},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361,"f":65,"v":2147483647}],"n":"GetSegmentSize","d":2136059,"h":115966253051,"f":2},{"r":104443,"n":"CreateSegmentUnsynchronized","d":2136059,"h":120261220347,"f":2},{"r":65537,"p":[{"n":"segment","p":104443}],"n":"ReturnSegmentUnsynchronized","d":2136059,"h":124556187643,"f":2},{"r":65537,"n":"CancelPendingFlush","d":2136059,"h":128851154939,"f":32769},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":2136059,"h":141736056827,"f":32769},{"r":136118273,"p":[{"n":"exception","p":47185921,"f":65}],"n":"CompleteAsync","d":2136059,"h":146031024123,"f":36865},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","d":2136059,"h":150325991419,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","d":2136059,"h":163210893307,"f":32769},{"r":65537,"n":"Cancel","d":2136059,"h":167505860603,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"writeToStream","p":262145},{"n":"data","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsyncInternal","d":2136059,"h":171800827899,"f":4098,"a":[{"t":86638593,"c":4381605889,"a":[{"v":$.$spc.System.Runtime.CompilerServices.PoolingAsyncValueTaskMethodBuilder$$().$h,"t":142606337}]}]},{"r":65537,"p":[{"n":"writeToStream","p":262145}],"n":"FlushInternal","d":2136059,"h":176095795195,"f":2}],"l":[{"t":655361,"n":"InitialSegmentPoolSize","d":2136059,"h":4297103355,"f":40},{"t":655361,"n":"MaxSegmentPoolSize","d":2136059,"h":8592070651,"f":40},{"t":655361,"n":"_minimumBufferSize","d":2136059,"h":12887037947,"f":2},{"t":104443,"n":"_head","d":2136059,"h":17182005243,"f":2},{"t":104443,"n":"_tail","d":2136059,"h":21476972539,"f":2},{"t":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"n":"_tailMemory","d":2136059,"h":25771939835,"f":2},{"t":655361,"n":"_tailBytesBuffered","d":2136059,"h":30066907131,"f":2},{"t":917505,"n":"_bytesBuffered","d":2136059,"h":34361874427,"f":2},{"t":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"n":"_pool","d":2136059,"h":38656841723,"f":2},{"t":655361,"n":"_maxPooledBufferSize","d":2136059,"h":42951809019,"f":2},{"t":126091265,"n":"_internalTokenSource","d":2136059,"h":47246776315,"f":2},{"t":262145,"n":"_isCompleted","d":2136059,"h":51541743611,"f":2},{"t":131073,"n":"_lockObject","d":2136059,"h":55836710907,"f":2},{"t":169979,"n":"_bufferSegmentPool","d":2136059,"h":60131678203,"f":2},{"t":262145,"n":"_leaveOpen","d":2136059,"h":64426645499,"f":2}],"c":[{"p":[{"n":"writingStream","p":62128129},{"n":"options","p":2201595}],"n":".ctor","o":"$ctor$2","d":2136059,"h":77311547387,"f":1}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h],"h":2136059}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeWriter; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte) ]; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeWriter`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime"))