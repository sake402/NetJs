
(function ($global, $, $spc, $sc, $sm, $spu, $st, $sttp, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Pipelines", 
    {"h":37608,"f":"System.IO.Pipelines","v":"1.0.35.0","a":[{"t":92405761,"c":4387373057,"a":[{"v":"System.IO.Pipelines.Tests, PublicKey=00240000048000009400000006020000002400005253413100040000010001004b86c4cb78549b34bab61a3b1800e23bfeb5b3ec390074041536a7e3cbd97f5f04cf0f857155a8928eaa29ebfd11cfbbad3ba70efea7bda3226c6a8d370a4cd303f714486b6ebc225985a638471e6ef571cc92a4613c00b8fa65d61ccee0cbe5f36330c9a01f4183559f1bef24cc2917c6d913e3a541333a1d05d9bed22b38cb","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Pipelines","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Pipelines","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sipl.System.IO.Pipelines.IDuplexPipe", ($self) => class IDuplexPipe
        {
            static $h = 496360;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1413864,"g":{"r":0,"d":0,"h":8590430952,"f":257},"n":"Input","o":"System$IO$Pipelines$IDuplexPipe$Input","d":496360,"h":4295463656,"f":257},{"p":1610472,"g":{"r":0,"d":0,"h":17180365544,"f":257},"n":"Output","o":"System$IO$Pipelines$IDuplexPipe$Output","d":496360,"h":12885398248,"f":257}],"h":496360}; }
            static get $fullName() { return `System.IO.Pipelines.IDuplexPipe`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeScheduler", ($self) => class PipeScheduler extends $.$spc.System.Object
        {
            /*ThreadPoolScheduler*/ static s_threadPoolScheduler = null;
            /*InlineScheduler*/ static s_inlineScheduler = null;
            static /*PipeScheduler */ get ThreadPool()
            {
                return $.$sipl.System.IO.Pipelines.PipeScheduler.s_threadPoolScheduler;
            }
            static /*PipeScheduler */ get Inline()
            {
                return $.$sipl.System.IO.Pipelines.PipeScheduler.s_inlineScheduler;
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                return this.Schedule(action, state);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_threadPoolScheduler = new $.$sipl.System.IO.Pipelines.ThreadPoolScheduler().$ctor$2();
                }
                {
                    this.s_inlineScheduler = new $.$sipl.System.IO.Pipelines.InlineScheduler().$ctor$2();
                }
            }
            static $h = 1544936;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1544936,"g":{"r":0,"d":0,"h":17181414120,"f":33},"n":"ThreadPool","d":1544936,"h":12886446824,"f":33},{"p":1544936,"g":{"r":0,"d":0,"h":25771348712,"f":33},"n":"Inline","d":1544936,"h":21476381416,"f":33}],"m":[{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":1544936,"h":30066316008,"f":257},{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":1544936,"h":34361283304,"f":136}],"l":[{"t":2265832,"n":"s_threadPoolScheduler","d":1544936,"h":4296512232,"f":34},{"t":561896,"n":"s_inlineScheduler","d":1544936,"h":8591479528,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":1544936,"h":38656250600,"f":4}],"h":1544936}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeScheduler`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeReader", ($self) => class PipeReader extends $.$spc.System.Object
        {
            /*PipeReaderStream?*/ _stream = null;
            /*ValueTask<ReadResult> */ ReadAtLeastAsync(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                if (minimumSize < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(0/*ExceptionArgument.minimumSize*/);
                }
                return this.ReadAtLeastAsyncCore(minimumSize, cancellationToken);
            }
            /*ValueTask<ReadResult> *//*async*/  ReadAtLeastAsyncCore(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult), $.$sipl.System.IO.Pipelines.ReadResult, async () => 
                {
                    while(true)
                    {
                        /*ReadResult*/ let result = await this.ReadAsync(cancellationToken).ConfigureAwait(false);
                        /*ReadOnlySequence<byte>*/ let buffer = result.Buffer;
                        if (buffer.Length >= BigInt(minimumSize) || result.IsCompleted || result.IsCanceled)
                        {
                            return result;
                        }
                        this.AdvanceTo$1(buffer.Start, buffer.End);
                    }
                });
            }
            /*Stream */ AsStream(/*bool*/ leaveOpen)
            {
                if (this._stream === null)
                {
                    this._stream = new $.$sipl.System.IO.Pipelines.PipeReaderStream().$ctor$3(this, leaveOpen);
                }
                else if (leaveOpen)
                {
                    this._stream.LeaveOpen = leaveOpen;
                }
                return this._stream;
            }
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                try
                {
                    this.Complete(exception);
                    return new $.$spc.System.Threading.Tasks.ValueTask();
                }
                catch(ex)
                {
                    return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException(ex));
                }
            }
            /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
            }
            static /*PipeReader */ Create(/*Stream*/ stream, /*StreamPipeReaderOptions?*/ readerOptions)
            {
                return new $.$sipl.System.IO.Pipelines.StreamPipeReader().$ctor$2(stream, readerOptions ?? $.$sipl.System.IO.Pipelines.StreamPipeReaderOptions.s_default);
            }
            static /*PipeReader */ Create$1(/*ReadOnlySequence<byte>*/ sequence)
            {
                return new $.$sipl.System.IO.Pipelines.SequencePipeReader().$ctor$2(sequence);
            }
            /*Task */ CopyToAsync(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this.CopyToAsyncCore($.$sipl.System.IO.Pipelines.PipeWriter, destination, new ($.$spc.System.Func$$$$$($.$sipl.System.IO.Pipelines.PipeWriter, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)))().$ctor(this,  (/**/ destination, /*memory*/ memory, /*cancellationToken*/ cancellationToken) =>
                {
                    return destination.WriteAsync(memory, cancellationToken);
                }), cancellationToken);
            }
            /*Task */ CopyToAsync$1(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return this.CopyToAsyncCore($.$spc.System.IO.Stream, destination, new ($.$spc.System.Func$$$$$($.$spc.System.IO.Stream, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)))().$ctor(this,  (/**/ destination, /*memory*/ memory, /*cancellationToken*/ cancellationToken) =>
                {
                    /*ValueTask*/ let task = destination.WriteAsync$2(memory, cancellationToken);
                    if (task.IsCompletedSuccessfully)
                    {
                        task.GetAwaiter().GetResult();
                        return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false));
                    }
                    /*static ValueTask<FlushResult>*/ /*async*/  function Awaited(/*ValueTask*/ writeTask)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult), $.$sipl.System.IO.Pipelines.FlushResult, async () => 
                        {
                            await writeTask.ConfigureAwait(false);
                            return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false);
                        });
                    }
                    return Awaited(task);
                }), cancellationToken);
            }
            /*Task *//*async*/  CopyToAsyncCore(TStream, /*TStream*/ destination, /*Func<TStream, ReadOnlyMemory<byte>, CancellationToken, ValueTask<FlushResult>>*/ writeAsync, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    while(true)
                    {
                        /*ReadResult*/ let result = await this.ReadAsync(cancellationToken).ConfigureAwait(false);
                        /*ReadOnlySequence<byte>*/ let buffer = result.Buffer;
                        /*SequencePosition*/ let position = buffer.Start;
                        /*SequencePosition*/ let consumed = position;
                        try
                        {
                            if (result.IsCanceled)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                            }
                            /*ReadOnlyMemory<byte>*/ let memory;
                            while(buffer.TryGet($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => position, ($v) => position = $v, null), $.$ref(() => memory, ($v) => memory = $v, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte)), true))
                            {
                                if (memory.IsEmpty)
                                {
                                    consumed = position;
                                }
                                else 
                                {
                                    /*FlushResult*/ let flushResult = await writeAsync.Invoke(destination, memory, cancellationToken).ConfigureAwait(false);
                                    if (flushResult.IsCanceled)
                                    {
                                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                                    }
                                    consumed = position;
                                    if (flushResult.IsCompleted)
                                    {
                                        return;
                                    }
                                }
                            }
                            consumed = buffer.End;
                            if (result.IsCompleted)
                            {
                                break;
                            }
                        }
                        finally
                        {
                            {
                                this.AdvanceTo(consumed);
                            }
                        }
                    }
                });
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1413864;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"result","p":1741544,"f":2}],"n":"TryRead","d":1413864,"h":8591348456,"f":257},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":1413864,"h":12886315752,"f":257},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAtLeastAsync","d":1413864,"h":17181283048,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAtLeastAsyncCore","d":1413864,"h":21476250344,"f":4228},{"r":65537,"p":[{"n":"consumed","p":1222797}],"n":"AdvanceTo","d":1413864,"h":25771217640,"f":257},{"r":65537,"p":[{"n":"consumed","p":1222797},{"n":"examined","p":1222797}],"n":"AdvanceTo","o":"@$1","d":1413864,"h":30066184936,"f":257},{"r":62128129,"p":[{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":"AsStream","d":1413864,"h":34361152232,"f":129},{"r":65537,"n":"CancelPendingRead","d":1413864,"h":38656119528,"f":257},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":1413864,"h":42951086824,"f":257},{"r":136118273,"p":[{"n":"exception","p":47185921,"f":65}],"n":"CompleteAsync","d":1413864,"h":47246054120,"f":129},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":1413864,"h":51541021416,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"OnWriterCompleted has been deprecated and may not be invoked on all implementations of PipeReader.","t":1310721}]}]},{"r":1413864,"p":[{"n":"stream","p":62128129},{"n":"readerOptions","p":2069224,"f":65}],"n":"Create","d":1413864,"h":55835988712,"f":33},{"r":1413864,"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h}],"n":"Create","o":"@$1","d":1413864,"h":60130956008,"f":33},{"r":133300225,"p":[{"n":"destination","p":1610472},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","d":1413864,"h":64425923304,"f":129},{"r":133300225,"p":[{"n":"destination","p":62128129},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","o":"@$1","d":1413864,"h":68720890600,"f":129},{"r":133300225,"p":[{"n":"destination","p":(TStream) => TStream.$h},{"n":"writeAsync","p":(TStream) => $.$spc.System.Func$$$$$(TStream, $.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)).$h},{"n":"cancellationToken","p":125960193}],"g":["TStream"],"n":"CopyToAsyncCore","d":1413864,"h":73015857896,"f":135170}],"l":[{"t":1479400,"n":"_stream","d":1413864,"h":4296381160,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1413864,"h":77310825192,"f":4}],"h":1413864}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeReader`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeWriter", ($self) => class PipeWriter extends $.$spc.System.Object
        {
            /*PipeWriterStream?*/ _stream = null;
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                try
                {
                    this.Complete(exception);
                    return new $.$spc.System.Threading.Tasks.ValueTask();
                }
                catch(ex)
                {
                    return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException(ex));
                }
            }
            /*bool */ get CanGetUnflushedBytes()
            {
                return false;
            }
            /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
            }
            /*Stream */ AsStream(/*bool*/ leaveOpen)
            {
                if (this._stream === null)
                {
                    this._stream = new $.$sipl.System.IO.Pipelines.PipeWriterStream().$ctor$3(this, leaveOpen);
                }
                else if (leaveOpen)
                {
                    this._stream.LeaveOpen = leaveOpen;
                }
                return this._stream;
            }
            static /*PipeWriter */ Create(/*Stream*/ stream, /*StreamPipeWriterOptions?*/ writerOptions)
            {
                return new $.$sipl.System.IO.Pipelines.StreamPipeWriter().$ctor$2(stream, writerOptions ?? $.$sipl.System.IO.Pipelines.StreamPipeWriterOptions.s_default);
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                $.$sm.System.Buffers.BuffersExtensions.Write($.$spc.System.Byte, this, source.Span);
                return this.FlushAsync(cancellationToken);
            }
            /*Task *//*async*/  CopyFromAsync(/*Stream*/ source, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    while(true)
                    {
                        /*Memory<byte>*/ let buffer = this.GetMemory(0);
                        /*int*/ let read = await source.ReadAsync$2(buffer, cancellationToken).ConfigureAwait(false);
                        if (read === 0)
                        {
                            break;
                        }
                        this.Advance(read);
                        /*FlushResult*/ let result = await this.FlushAsync(cancellationToken).ConfigureAwait(false);
                        if (result.IsCanceled)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                        }
                        if (result.IsCompleted)
                        {
                            break;
                        }
                    }
                });
            }
            /*long */ get UnflushedBytes()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateNotSupportedException_UnflushedBytes();
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.Advance(int)
            System$Buffers$IBufferWriter$$$Advance()
            {
                return this.Advance(...arguments);
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.GetMemory(int)
            System$Buffers$IBufferWriter$$$GetMemory()
            {
                return this.GetMemory(...arguments);
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<byte>.GetSpan(int)
            System$Buffers$IBufferWriter$$$GetSpan()
            {
                return this.GetSpan(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1610472;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771414248,"f":129},"n":"CanGetUnflushedBytes","d":1610472,"h":21476446952,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":73016054504,"f":129},"n":"UnflushedBytes","d":1610472,"h":68721087208,"f":129}],"m":[{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":1610472,"h":8591545064,"f":257},{"r":136118273,"p":[{"n":"exception","p":47185921,"f":65}],"n":"CompleteAsync","d":1610472,"h":12886512360,"f":129},{"r":65537,"n":"CancelPendingFlush","d":1610472,"h":17181479656,"f":257},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":1610472,"h":30066381544,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"OnReaderCompleted has been deprecated and may not be invoked on all implementations of PipeWriter.","t":1310721}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","d":1610472,"h":34361348840,"f":257},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":1610472,"h":38656316136,"f":257},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":1610472,"h":42951283432,"f":257},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":1610472,"h":47246250728,"f":257},{"r":62128129,"p":[{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":"AsStream","d":1610472,"h":51541218024,"f":129},{"r":1610472,"p":[{"n":"stream","p":62128129},{"n":"writerOptions","p":2200296,"f":65}],"n":"Create","d":1610472,"h":55836185320,"f":33},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","d":1610472,"h":60131152616,"f":129},{"r":133300225,"p":[{"n":"source","p":62128129},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyFromAsync","d":1610472,"h":64426119912,"f":4240}],"l":[{"t":1676008,"n":"_stream","d":1610472,"h":4296577768,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1610472,"h":77311021800,"f":4}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h],"h":1610472}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte) ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeWriter`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.Pipe", ($self) => class Pipe extends $.$spc.System.Object
        {
            static $_DefaultPipeReader;
            static get DefaultPipeReader()
            {
                let $cls = $.$sipl.System.IO.Pipelines.Pipe;
                return $cls.$_DefaultPipeReader ??= $asm.$ncls("$sipl.System.IO.Pipelines.Pipe.DefaultPipeReader", ($self) => class DefaultPipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
                {
                    /*Pipe*/ _pipe = null;
                    $ctor$2(/*Pipe*/ pipe)
                    {
                        super.$ctor$1();
                        {
                            this._pipe = pipe;
                        }
                        return this;
                    }
                    /*bool */ TryRead(/*out ReadResult*/ result)
                    {
                        return this._pipe.TryRead(result);
                    }
                    /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.ReadAsync(cancellationToken);
                    }
                    /*ValueTask<ReadResult> */ ReadAtLeastAsyncCore(/*int*/ minimumBytes, /*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.ReadAtLeastAsync(minimumBytes, cancellationToken);
                    }
                    /*void */ AdvanceTo(/*SequencePosition*/ consumed)
                    {
                        return this._pipe.AdvanceReader($.$ref(() => consumed, ));
                    }
                    /*void */ AdvanceTo$1(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
                    {
                        return this._pipe.AdvanceReader$1($.$ref(() => consumed, ), $.$ref(() => examined, ));
                    }
                    /*void */ CancelPendingRead()
                    {
                        return this._pipe.CancelPendingRead();
                    }
                    /*void */ Complete(/*Exception?*/ exception)
                    {
                        return this._pipe.CompleteReader(exception);
                    }
                    /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
                    {
                        return this._pipe.OnWriterCompleted(callback, state);
                    }
                    /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
                    {
                        return this._pipe.GetReadAsyncStatus();
                    }
                    /*ReadResult */ GetResult(/*short*/ token)
                    {
                        return this._pipe.GetReadAsyncResult();
                    }
                    /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
                    {
                        return this._pipe.OnReadAsyncCompleted(continuation, state, flags);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.GetStatus(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetStatus()
                    {
                        return this.GetStatus(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$OnCompleted()
                    {
                        return this.OnCompleted(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.ReadResult>.GetResult(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetResult()
                    {
                        return this.GetResult(...arguments);
                    }
                    static $h = 692968;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1413864,"m":[{"r":262145,"p":[{"n":"result","p":1741544,"f":2}],"n":"TryRead","d":692968,"h":12885594856,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":692968,"h":17180562152,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumBytes","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAtLeastAsyncCore","d":692968,"h":21475529448,"f":32772},{"r":65537,"p":[{"n":"consumed","p":1222797}],"n":"AdvanceTo","d":692968,"h":25770496744,"f":32769},{"r":65537,"p":[{"n":"consumed","p":1222797},{"n":"examined","p":1222797}],"n":"AdvanceTo","o":"@$1","d":692968,"h":30065464040,"f":32769},{"r":65537,"n":"CancelPendingRead","d":692968,"h":34360431336,"f":32769},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":692968,"h":38655398632,"f":32769},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":692968,"h":42950365928,"f":32769},{"r":133038081,"p":[{"n":"token","p":524289}],"n":"GetStatus","d":692968,"h":47245333224,"f":1},{"r":1741544,"p":[{"n":"token","p":524289}],"n":"GetResult","d":692968,"h":51540300520,"f":1},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"token","p":524289},{"n":"flags","p":132972545}],"n":"OnCompleted","d":692968,"h":55835267816,"f":1}],"l":[{"t":627432,"n":"_pipe","d":692968,"h":4295660264,"f":2}],"c":[{"p":[{"n":"pipe","p":627432}],"n":".ctor","o":"$ctor$2","d":692968,"h":8590627560,"f":1}],"i":[$.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.ReadResult).$h],"d":627432,"h":692968}; }
                    static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.ReadResult) ]; }
                    static get $fullName() { return `System.IO.Pipelines.Pipe.DefaultPipeReader`; }
                }, $cls, ($v) => $cls.$_DefaultPipeReader = $v);
            }
            static $_DefaultPipeWriter;
            static get DefaultPipeWriter()
            {
                let $cls = $.$sipl.System.IO.Pipelines.Pipe;
                return $cls.$_DefaultPipeWriter ??= $asm.$ncls("$sipl.System.IO.Pipelines.Pipe.DefaultPipeWriter", ($self) => class DefaultPipeWriter extends $.$sipl.System.IO.Pipelines.PipeWriter
                {
                    /*Pipe*/ _pipe = null;
                    $ctor$2(/*Pipe*/ pipe)
                    {
                        super.$ctor$1();
                        {
                            this._pipe = pipe;
                        }
                        return this;
                    }
                    /*void */ Complete(/*Exception?*/ exception)
                    {
                        return this._pipe.CompleteWriter(exception);
                    }
                    /*void */ CancelPendingFlush()
                    {
                        return this._pipe.CancelPendingFlush();
                    }
                    /*bool */ get CanGetUnflushedBytes()
                    {
                        return true;
                    }
                    /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
                    {
                        return this._pipe.OnReaderCompleted(callback, state);
                    }
                    /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.FlushAsync(cancellationToken);
                    }
                    /*void */ Advance(/*int*/ bytes)
                    {
                        return this._pipe.Advance(bytes);
                    }
                    /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
                    {
                        return this._pipe.GetMemory(sizeHint);
                    }
                    /*Span<byte> */ GetSpan(/*int*/ sizeHint)
                    {
                        return this._pipe.GetSpan(sizeHint);
                    }
                    /*ValueTaskSourceStatus */ GetStatus(/*short*/ token)
                    {
                        return this._pipe.GetFlushAsyncStatus();
                    }
                    /*FlushResult */ GetResult(/*short*/ token)
                    {
                        return this._pipe.GetFlushAsyncResult();
                    }
                    /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*short*/ token, /*ValueTaskSourceOnCompletedFlags*/ flags)
                    {
                        return this._pipe.OnFlushAsyncCompleted(continuation, state, flags);
                    }
                    /*long */ get UnflushedBytes()
                    {
                        return this._pipe.GetUnflushedBytes();
                    }
                    /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
                    {
                        return this._pipe.WriteAsync(source, cancellationToken);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.GetStatus(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetStatus()
                    {
                        return this.GetStatus(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.OnCompleted(System.Action<object?>, object?, short, System.Threading.Tasks.Sources.ValueTaskSourceOnCompletedFlags)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$OnCompleted()
                    {
                        return this.OnCompleted(...arguments);
                    }
                    //Generated interface implemetation for System.Threading.Tasks.Sources.IValueTaskSource<System.IO.Pipelines.FlushResult>.GetResult(short)
                    System$Threading$Tasks$Sources$IValueTaskSource$$$GetResult()
                    {
                        return this.GetResult(...arguments);
                    }
                    static $h = 758504;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1610472,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770562280,"f":32769},"n":"CanGetUnflushedBytes","d":758504,"h":21475594984,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68720235240,"f":32769},"n":"UnflushedBytes","d":758504,"h":64425267944,"f":32769}],"m":[{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":758504,"h":12885660392,"f":32769},{"r":65537,"n":"CancelPendingFlush","d":758504,"h":17180627688,"f":32769},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":758504,"h":30065529576,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","d":758504,"h":34360496872,"f":32769},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":758504,"h":38655464168,"f":32769},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":758504,"h":42950431464,"f":32769},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":758504,"h":47245398760,"f":32769},{"r":133038081,"p":[{"n":"token","p":524289}],"n":"GetStatus","d":758504,"h":51540366056,"f":1},{"r":430824,"p":[{"n":"token","p":524289}],"n":"GetResult","d":758504,"h":55835333352,"f":1},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"token","p":524289},{"n":"flags","p":132972545}],"n":"OnCompleted","d":758504,"h":60130300648,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","d":758504,"h":73015202536,"f":32769}],"l":[{"t":627432,"n":"_pipe","d":758504,"h":4295725800,"f":2}],"c":[{"p":[{"n":"pipe","p":627432}],"n":".ctor","o":"$ctor$2","d":758504,"h":8590693096,"f":1}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h,$.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.FlushResult).$h],"d":627432,"h":758504}; }
                    static get $b() { return $.$sipl.System.IO.Pipelines.PipeWriter; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte), $.$spc.System.Threading.Tasks.Sources.IValueTaskSource$$($.$sipl.System.IO.Pipelines.FlushResult) ]; }
                    static get $fullName() { return `System.IO.Pipelines.Pipe.DefaultPipeWriter`; }
                }, $cls, ($v) => $cls.$_DefaultPipeWriter = $v);
            }
            /*Action<object?>*/ static s_signalReaderAwaitable = null;
            /*Action<object?>*/ static s_signalWriterAwaitable = null;
            /*Action<object?>*/ static s_invokeCompletionCallbacks = null;
            /*ContextCallback*/ static s_executionContextRawCallback = null;
            /*SendOrPostCallback*/ static s_syncContextExecutionContextCallback = null;
            /*SendOrPostCallback*/ static s_syncContextExecuteWithoutExecutionContextCallback = null;
            /*Action<object?>*/ static s_scheduleWithExecutionContextCallback = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*DefaultPipeReader*/ _reader = null;
            /*DefaultPipeWriter*/ _writer = null;
            /*PipeOptions*/ _options = null;
            /*object*/ _sync = null;
            /*bool */ get UseSynchronizationContext()
            {
                return this._options.UseSynchronizationContext;
            }
            /*int */ get MinimumSegmentSize()
            {
                return this._options.MinimumSegmentSize;
            }
            /*long */ get PauseWriterThreshold()
            {
                return this._options.PauseWriterThreshold;
            }
            /*long */ get ResumeWriterThreshold()
            {
                return this._options.ResumeWriterThreshold;
            }
            /*PipeScheduler */ get ReaderScheduler()
            {
                return this._options.ReaderScheduler;
            }
            /*PipeScheduler */ get WriterScheduler()
            {
                return this._options.WriterScheduler;
            }
            /*object */ get SyncObj()
            {
                return this._sync;
            }
            /*long*/ _unconsumedBytes = 0n;
            /*long*/ _unflushedBytes = 0n;
            /*PipeAwaitable*/ _readerAwaitable;
            /*PipeAwaitable*/ _writerAwaitable;
            /*PipeCompletion*/ _writerCompletion;
            /*PipeCompletion*/ _readerCompletion;
            /*long*/ _lastExaminedIndex = -1n;
            /*BufferSegment?*/ _readHead = null;
            /*int*/ _readHeadIndex = 0;
            /*bool*/ _disposed = false;
            /*BufferSegment?*/ _readTail = null;
            /*int*/ _readTailIndex = 0;
            /*int*/ _minimumReadBytes = 0;
            /*BufferSegment?*/ _writingHead = null;
            /*Memory<byte>*/ _writingHeadMemory;
            /*int*/ _writingHeadBytesBuffered = 0;
            /*PipeOperationState*/ _operationState;
            /*long */ get Length()
            {
                return this._unconsumedBytes;
            }
            $ctor$1()
            {
                this.$ctor$2($.$sipl.System.IO.Pipelines.PipeOptions.Default);
                {
                }
                return this;
            }
            $ctor$2(/*PipeOptions*/ options)
            {
                super.$ctor();
                {
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$2(options.InitialSegmentPoolSize);
                    this._operationState = new $.$sipl.System.IO.Pipelines.PipeOperationState();
                    this._readerCompletion = new $.$sipl.System.IO.Pipelines.PipeCompletion();
                    this._writerCompletion = new $.$sipl.System.IO.Pipelines.PipeCompletion();
                    this._options = options;
                    this._readerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(false, this.UseSynchronizationContext);
                    this._writerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(true, this.UseSynchronizationContext);
                    this._reader = new $.$sipl.System.IO.Pipelines.Pipe.DefaultPipeReader().$ctor$2(this);
                    this._writer = new $.$sipl.System.IO.Pipelines.Pipe.DefaultPipeWriter().$ctor$2(this);
                }
                return this;
            }
            /*void */ ResetState()
            {
                this._readerCompletion.Reset();
                this._writerCompletion.Reset();
                this._readerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(false, this.UseSynchronizationContext);
                this._writerAwaitable = new $.$sipl.System.IO.Pipelines.PipeAwaitable().$ctor$2(true, this.UseSynchronizationContext);
                this._readTailIndex = 0;
                this._readHeadIndex = 0;
                this._lastExaminedIndex = BigInt(-1);
                this._unflushedBytes = 0n;
                this._unconsumedBytes = 0n;
            }
            /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateWriteHeadIfNeeded(sizeHint);
                return this._writingHeadMemory;
            }
            /*Span<byte> */ GetSpan(/*int*/ sizeHint)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateWriteHeadIfNeeded(sizeHint);
                return this._writingHeadMemory.Span;
            }
            /*void */ AllocateWriteHeadIfNeeded(/*int*/ sizeHint)
            {
                if (!this._operationState.IsWritingActive || this._writingHeadMemory.Length === 0 || this._writingHeadMemory.Length < sizeHint)
                {
                    this.AllocateWriteHeadSynchronized(sizeHint);
                }
            }
            /*void */ AllocateWriteHeadSynchronized(/*int*/ sizeHint)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._operationState.BeginWrite();
                        if (this._writingHead === null)
                        {
                            /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                            this._writingHead = this._readHead = this._readTail = newSegment;
                            this._lastExaminedIndex = 0n;
                        }
                        else 
                        {
                            /*int*/ let bytesLeftInBuffer = this._writingHeadMemory.Length;
                            if (bytesLeftInBuffer === 0 || bytesLeftInBuffer < sizeHint)
                            {
                                if (this._writingHeadBytesBuffered > 0)
                                {
                                    this._writingHead.End += this._writingHeadBytesBuffered;
                                    this._writingHeadBytesBuffered = 0;
                                }
                                if (this._writingHead.Length === 0)
                                {
                                    this._writingHead.ResetMemory();
                                    this.RentMemory(this._writingHead, sizeHint);
                                }
                                else 
                                {
                                    /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                                    this._writingHead.SetNext(newSegment);
                                    this._writingHead = newSegment;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*BufferSegment */ AllocateSegment(/*int*/ sizeHint)
            {
                /*BufferSegment*/ let newSegment = this.CreateSegmentUnsynchronized();
                this.RentMemory(newSegment, sizeHint);
                return newSegment;
            }
            /*void */ RentMemory(/*BufferSegment*/ segment, /*int*/ sizeHint)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment.MemoryOwner === null, "segment.MemoryOwner is null");
                $.$spc.System.Diagnostics.Debug.Assert$1(sizeHint >= 0, "sizeHint >= 0");
                /*MemoryPool<byte>?*/ let pool = null;
                /*int*/ let maxSize = -1;
                if (!this._options.IsDefaultSharedMemoryPool)
                {
                    pool = this._options.Pool;
                    maxSize = pool.MaxBufferSize;
                }
                if (sizeHint <= maxSize)
                {
                    segment.SetOwnedMemory(pool.Rent(this.GetSegmentSize(sizeHint, maxSize)));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(sizeHint, 2147483647);
                    segment.SetOwnedMemory$1($.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(sizeToRequest));
                }
                this._writingHeadMemory = segment.AvailableMemory;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$spc.System.Math.Max$4(this.MinimumSegmentSize, sizeHint);
                /*int*/ let adjustedToMaximumSize = $.$spc.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readHead, "Returning _readHead segment that's in use!");
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readTail, "Returning _readTail segment that's in use!");
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._writingHead, "Returning _writingHead segment that's in use!");
                if (this._bufferSegmentPool.Count < this._options.MaxSegmentPoolSize)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*bool */ CommitUnsynchronized()
            {
                this._operationState.EndWrite();
                if (this._unflushedBytes === 0n)
                {
                    return false;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writingHead !== null, "_writingHead != null");
                this._writingHead.End += this._writingHeadBytesBuffered;
                this._readTail = this._writingHead;
                this._readTailIndex = this._writingHead.End;
                /*long*/ let oldLength = this._unconsumedBytes;
                this._unconsumedBytes += this._unflushedBytes;
                /*bool*/ let resumeReader = true;
                if (this._unconsumedBytes < BigInt(this._minimumReadBytes))
                {
                    resumeReader = false;
                }
                else if (this.PauseWriterThreshold > 0n && oldLength < this.PauseWriterThreshold && this._unconsumedBytes >= this.PauseWriterThreshold && !this._readerCompletion.IsCompleted)
                {
                    this._writerAwaitable.SetUncompleted();
                }
                this._unflushedBytes = 0n;
                this._writingHeadBytesBuffered = 0;
                return resumeReader;
            }
            /*void */ Advance(/*int*/ bytes)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if ((bytes >>> 0) > (this._writingHeadMemory.Length >>> 0))
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.bytes*/);
                        }
                        if (this._readerCompletion.IsCompleted)
                        {
                            return;
                        }
                        this.AdvanceCore(bytes);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*void */ AdvanceCore(/*int*/ bytesWritten)
            {
                this._unflushedBytes += BigInt(bytesWritten);
                this._writingHeadBytesBuffered += bytesWritten;
                this._writingHeadMemory = this._writingHeadMemory.Slice(bytesWritten);
            }
            /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.FlushResult, cancellationToken));
                }
                /*CompletionData*/ let completionData;
                /*ValueTask<FlushResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this.PrepareFlushUnsynchronized($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => result, ($v) => result = $v, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)), cancellationToken);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
                return result;
            }
            /*void */ PrepareFlushUnsynchronized(/*out CompletionData*/ completionData, /*out ValueTask<FlushResult>*/ result, /*CancellationToken*/ cancellationToken)
            {
                /*var*/ let completeReader = this.CommitUnsynchronized();
                this._writerAwaitable.BeginOperation(cancellationToken, $.$sipl.System.IO.Pipelines.Pipe.s_signalWriterAwaitable, this);
                if (this._writerAwaitable.IsCompleted)
                {
                    /*FlushResult*/ let flushResult = new $.$sipl.System.IO.Pipelines.FlushResult();
                    this.GetFlushResult($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sipl.System.IO.Pipelines.FlushResult, () => flushResult, ($v) => flushResult = $v, null));
                    result.$v = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(flushResult.Clone());
                }
                else 
                {
                    result.$v = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$4(this._writer, 0);
                }
                if (completeReader)
                {
                    this._readerAwaitable.Complete(completionData);
                }
                else 
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writerAwaitable.IsCompleted || this._readerAwaitable.IsCompleted, "_writerAwaitable.IsCompleted || _readerAwaitable.IsCompleted");
            }
            /*void */ CompleteWriter(/*Exception?*/ exception)
            {
                /*CompletionData*/ let completionData;
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                /*bool*/ let readerCompleted;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this.CommitUnsynchronized();
                        completionCallbacks = this._writerCompletion.TryComplete(exception);
                        this._readerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        readerCompleted = this._readerCompletion.IsCompleted;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (readerCompleted)
                {
                    this.CompletePipe();
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.ReaderScheduler, completionCallbacks);
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ AdvanceReader(/*in SequencePosition*/ consumed)
            {
                this.AdvanceReader$1(consumed, consumed);
            }
            /*void */ AdvanceReader$1(/*in SequencePosition*/ consumed, /*in SequencePosition*/ examined)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                this.AdvanceReader$2($.$cast(consumed.$v.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), consumed.$v.GetInteger(), $.$cast(examined.$v.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), examined.$v.GetInteger());
            }
            /*void */ AdvanceReader$2(/*BufferSegment?*/ consumedSegment, /*int*/ consumedIndex, /*BufferSegment?*/ examinedSegment, /*int*/ examinedIndex)
            {
                if (consumedSegment !== null && examinedSegment !== null && $.$sipl.System.IO.Pipelines.BufferSegment.GetLength(consumedSegment, consumedIndex, examinedSegment, examinedIndex) < 0n)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition();
                }
                /*BufferSegment?*/ let returnStart = null;
                /*BufferSegment?*/ let returnEnd = null;
                /*CompletionData*/ let completionData = new $.$sipl.System.IO.Pipelines.CompletionData();
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        /*var*/ let examinedEverything = false;
                        if (examinedSegment === this._readTail)
                        {
                            examinedEverything = examinedIndex === this._readTailIndex;
                        }
                        if (examinedSegment !== null && this._lastExaminedIndex >= 0n)
                        {
                            /*long*/ let examinedBytes = $.$sipl.System.IO.Pipelines.BufferSegment.GetLength$1(this._lastExaminedIndex, examinedSegment, examinedIndex);
                            /*long*/ let oldLength = this._unconsumedBytes;
                            this._unconsumedBytes -= examinedBytes;
                            this._lastExaminedIndex = examinedSegment.RunningIndex + BigInt(examinedIndex);
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._unconsumedBytes >= 0n, "Length has gone negative");
                            $.$spc.System.Diagnostics.Debug.Assert$1(this.ResumeWriterThreshold >= 1n, "ResumeWriterThreshold is less than 1");
                            if (oldLength >= this.ResumeWriterThreshold && this._unconsumedBytes < this.ResumeWriterThreshold)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(examinedBytes > 0n, "examinedBytes > 0");
                                this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                            }
                        }
                        if (consumedSegment !== null)
                        {
                            if (this._readHead === null)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AdvanceToInvalidCursor();
                                return;
                            }
                            returnStart = this._readHead;
                            returnEnd = consumedSegment;
                            /*void*/  function MoveReturnEndToNextBlock()
                            {
                                /*BufferSegment?*/ let nextBlock = returnEnd.NextSegment;
                                if (this._readTail === returnEnd)
                                {
                                    this._readTail = nextBlock;
                                    this._readTailIndex = 0;
                                }
                                this._readHead = nextBlock;
                                this._readHeadIndex = 0;
                                returnEnd = nextBlock;
                            }
                            if (consumedIndex === returnEnd.Length)
                            {
                                if (this._writingHead !== returnEnd)
                                {
                                    MoveReturnEndToNextBlock.call(this);
                                }
                                else if (this._writingHeadBytesBuffered === 0 && !this._operationState.IsWritingActive)
                                {
                                    this._writingHead = null;
                                    this._writingHeadMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                                    MoveReturnEndToNextBlock.call(this);
                                }
                                else 
                                {
                                    this._readHead = consumedSegment;
                                    this._readHeadIndex = consumedIndex;
                                }
                            }
                            else 
                            {
                                this._readHead = consumedSegment;
                                this._readHeadIndex = consumedIndex;
                            }
                        }
                        if (examinedEverything && !this._writerCompletion.IsCompleted)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._writerAwaitable.IsCompleted, "PipeWriter.FlushAsync isn't completed and will deadlock");
                            this._readerAwaitable.SetUncompleted();
                        }
                        while(returnStart !== null && returnStart !== returnEnd)
                        {
                            /*BufferSegment?*/ let next = returnStart.NextSegment;
                            returnStart.Reset();
                            this.ReturnSegmentUnsynchronized(returnStart);
                            returnStart = next;
                        }
                        this._operationState.EndRead();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ CompleteReader(/*Exception?*/ exception)
            {
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                /*CompletionData*/ let completionData;
                /*bool*/ let writerCompleted;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (this._operationState.IsReadingActive)
                        {
                            this._operationState.EndRead();
                        }
                        completionCallbacks = this._readerCompletion.TryComplete(exception);
                        this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        writerCompleted = this._writerCompletion.IsCompleted;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (writerCompleted)
                {
                    this.CompletePipe();
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.WriterScheduler, completionCallbacks);
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ OnWriterCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                if (callback === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.callback*/);
                }
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        completionCallbacks = this._writerCompletion.AddCallback(callback, state);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.ReaderScheduler, completionCallbacks);
                }
            }
            /*void */ CancelPendingRead()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.Cancel($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ CancelPendingFlush()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._writerAwaitable.Cancel($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ OnReaderCompleted(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                if (callback === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.callback*/);
                }
                /*PipeCompletionCallbacks?*/ let completionCallbacks;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        completionCallbacks = this._readerCompletion.AddCallback(callback, state);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (completionCallbacks !== null)
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleCallbacks(this.WriterScheduler, completionCallbacks);
                }
            }
            /*ValueTask<ReadResult> */ ReadAtLeastAsync(/*int*/ minimumBytes, /*CancellationToken*/ token)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                if (token.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.ReadResult, token));
                }
                /*CompletionData*/ let completionData = new $.$sipl.System.IO.Pipelines.CompletionData();
                /*ValueTask<ReadResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        if (this._readerAwaitable.IsCompleted)
                        {
                            /*ReadResult*/ let readResult;
                            this.GetReadResult($.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                            if (this._unconsumedBytes >= BigInt(minimumBytes) || readResult.IsCanceled || readResult.IsCompleted)
                            {
                                return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(readResult);
                            }
                            this._readerAwaitable.SetUncompleted();
                            this._operationState.EndRead();
                            this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        }
                        if (!this._writerAwaitable.IsCompleted)
                        {
                            this._writerAwaitable.Complete($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                        }
                        this._minimumReadBytes = minimumBytes;
                        result = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$4(this._reader, 0);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, undefined, $.$sipl.System.IO.Pipelines.CompletionData));
                return result;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ token)
            {
                if (this._readerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
                if (token.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.ReadResult, token));
                }
                /*ValueTask<ReadResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.BeginOperation(token, $.$sipl.System.IO.Pipelines.Pipe.s_signalReaderAwaitable, this);
                        if (this._readerAwaitable.IsCompleted)
                        {
                            /*ReadResult*/ let readResult;
                            this.GetReadResult($.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                            result = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(readResult);
                        }
                        else 
                        {
                            result = new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$4(this._reader, 0);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                return result;
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (this._readerCompletion.IsCompleted)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                        }
                        if (this._unconsumedBytes > 0n || this._readerAwaitable.IsCompleted)
                        {
                            this.GetReadResult(result);
                            return true;
                        }
                        if (this._readerAwaitable.IsRunning)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                        }
                        this._operationState.BeginReadTentative();
                        result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                        return false;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            static /*void */ ScheduleCallbacks(/*PipeScheduler*/ scheduler, /*PipeCompletionCallbacks*/ completionCallbacks)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(completionCallbacks !== null, "completionCallbacks != null");
                scheduler.UnsafeSchedule($.$sipl.System.IO.Pipelines.Pipe.s_invokeCompletionCallbacks, completionCallbacks);
            }
            static /*void */ TrySchedule(/*PipeScheduler*/ scheduler, /*in CompletionData*/ completionData)
            {
                /*Action<object?>*/ let completion = completionData.$v.Completion;
                if (completion === null)
                {
                    return;
                }
                if (completionData.$v.SynchronizationContext === null && completionData.$v.ExecutionContext === null)
                {
                    scheduler.UnsafeSchedule(completion, completionData.$v.CompletionState);
                }
                else 
                {
                    $.$sipl.System.IO.Pipelines.Pipe.ScheduleWithContext(scheduler, completionData);
                }
            }
            static /*void */ ScheduleWithContext(/*PipeScheduler*/ scheduler, /*in CompletionData*/ completionData)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(completionData.$v.SynchronizationContext !== null || completionData.$v.ExecutionContext !== null, "completionData.SynchronizationContext != null || completionData.ExecutionContext != null");
                if (completionData.$v.SynchronizationContext === null)
                {
                    scheduler.UnsafeSchedule($.$sipl.System.IO.Pipelines.Pipe.s_scheduleWithExecutionContextCallback, completionData.$v);
                }
                else 
                {
                    if (completionData.$v.ExecutionContext === null)
                    {
                        completionData.$v.SynchronizationContext.Post($.$sipl.System.IO.Pipelines.Pipe.s_syncContextExecuteWithoutExecutionContextCallback, completionData.$v);
                    }
                    else 
                    {
                        completionData.$v.SynchronizationContext.Post($.$sipl.System.IO.Pipelines.Pipe.s_syncContextExecutionContextCallback, completionData.$v);
                    }
                }
            }
            static /*void */ ExecuteWithoutExecutionContext(/*object*/ state)
            {
                /*CompletionData*/ let completionData = $.$cast(state, $.$sipl.System.IO.Pipelines.CompletionData);
                completionData.Completion.Invoke(completionData.CompletionState);
            }
            static /*void */ ExecuteWithExecutionContext(/*object*/ state)
            {
                /*CompletionData*/ let completionData = $.$cast(state, $.$sipl.System.IO.Pipelines.CompletionData);
                $.$spc.System.Diagnostics.Debug.Assert$1(completionData.ExecutionContext !== null, "completionData.ExecutionContext != null");
                $.$spc.System.Threading.ExecutionContext.Run(completionData.ExecutionContext, $.$sipl.System.IO.Pipelines.Pipe.s_executionContextRawCallback, state);
            }
            /*void */ CompletePipe()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        this._disposed = true;
                        /*BufferSegment?*/ let segment = this._readHead ?? this._readTail;
                        while(segment !== null)
                        {
                            /*BufferSegment*/ let returnSegment = segment;
                            segment = segment.NextSegment;
                            returnSegment.Reset();
                        }
                        this._writingHead = null;
                        this._writingHeadMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                        this._readHead = null;
                        this._readTail = null;
                        this._lastExaminedIndex = BigInt(-1);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            /*ValueTaskSourceStatus */ GetReadAsyncStatus()
            {
                if (this._readerAwaitable.IsCompleted)
                {
                    if (this._writerCompletion.IsFaulted)
                    {
                        return 2/*ValueTaskSourceStatus.Faulted*/;
                    }
                    return 1/*ValueTaskSourceStatus.Succeeded*/;
                }
                return 0/*ValueTaskSourceStatus.Pending*/;
            }
            /*void */ OnReadAsyncCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                /*CompletionData*/ let completionData;
                /*bool*/ let doubleCompletion;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.OnCompleted(continuation, state, flags, $.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => doubleCompletion, ($v) => doubleCompletion = $v, $.$spc.System.Boolean));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (doubleCompletion)
                {
                    this.Writer.Complete($.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation());
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*ReadResult */ GetReadAsyncResult()
            {
                /*ReadResult*/ let result;
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                /*CancellationToken*/ let cancellationToken = new $.$spc.System.Threading.CancellationToken();
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                        {
                            if (!this._readerAwaitable.IsCompleted)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_GetResultNotCompleted();
                            }
                            cancellationTokenRegistration = this._readerAwaitable.ReleaseCancellationTokenRegistration($.$ref(() => cancellationToken, ($v) => cancellationToken = $v, $.$spc.System.Threading.CancellationToken));
                            this.GetReadResult($.$ref(() => result, ($v) => result = $v, $.$sipl.System.IO.Pipelines.ReadResult));
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                    }
                }
                finally
                {
                    {
                        cancellationTokenRegistration.Dispose();
                    }
                }
                if (result.IsCanceled)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                }
                return result;
            }
            /*void */ GetReadResult(/*out ReadResult*/ result)
            {
                /*bool*/ let isCompleted = this._writerCompletion.IsCompletedOrThrow();
                /*bool*/ let isCanceled = this._readerAwaitable.ObserveCancellation();
                /*BufferSegment?*/ let head = this._readHead;
                if (head !== null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readTail !== null, "_readTail != null");
                    /*var*/ let readOnlySequence = new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))().$ctor$3(head, this._readHeadIndex, this._readTail, this._readTailIndex);
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(readOnlySequence, isCanceled, isCompleted);
                }
                else 
                {
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))(), isCanceled, isCompleted);
                }
                if (isCanceled)
                {
                    this._operationState.BeginReadTentative();
                }
                else 
                {
                    this._operationState.BeginRead();
                }
                this._minimumReadBytes = 0;
            }
            /*ValueTaskSourceStatus */ GetFlushAsyncStatus()
            {
                if (this._writerAwaitable.IsCompleted)
                {
                    if (this._readerCompletion.IsFaulted)
                    {
                        return 2/*ValueTaskSourceStatus.Faulted*/;
                    }
                    return 1/*ValueTaskSourceStatus.Succeeded*/;
                }
                return 0/*ValueTaskSourceStatus.Pending*/;
            }
            /*FlushResult */ GetFlushAsyncResult()
            {
                /*FlushResult*/ let result = new $.$sipl.System.IO.Pipelines.FlushResult();
                /*CancellationToken*/ let cancellationToken = new $.$spc.System.Threading.CancellationToken();
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                        {
                            if (!this._writerAwaitable.IsCompleted)
                            {
                                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_GetResultNotCompleted();
                            }
                            this.GetFlushResult($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sipl.System.IO.Pipelines.FlushResult, () => result, ($v) => result = $v, null));
                            cancellationTokenRegistration = this._writerAwaitable.ReleaseCancellationTokenRegistration($.$ref(() => cancellationToken, ($v) => cancellationToken = $v, $.$spc.System.Threading.CancellationToken));
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                    }
                }
                finally
                {
                    {
                        cancellationTokenRegistration.Dispose();
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                }
                return result;
            }
            /*long */ GetUnflushedBytes()
            {
                return this._unflushedBytes;
            }
            /*void */ GetFlushResult(/*ref FlushResult*/ result)
            {
                if (this._writerAwaitable.ObserveCancellation())
                {
                    result.$v._resultFlags |= 1/*ResultFlags.Canceled*/;
                }
                if (this._readerCompletion.IsCompletedOrThrow())
                {
                    result.$v._resultFlags |= 2/*ResultFlags.Completed*/;
                }
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                if (this._writerCompletion.IsCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (this._readerCompletion.IsCompletedOrThrow())
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, true));
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.FlushResult, cancellationToken));
                }
                /*CompletionData*/ let completionData;
                /*ValueTask<FlushResult>*/ let result;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this.AllocateWriteHeadIfNeeded(0);
                        if (source.Length <= this._writingHeadMemory.Length)
                        {
                            source.CopyTo(this._writingHeadMemory);
                            this.AdvanceCore(source.Length);
                        }
                        else 
                        {
                            this.WriteMultiSegment(source.Span);
                        }
                        this.PrepareFlushUnsynchronized($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => result, ($v) => result = $v, $.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult)), cancellationToken);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
                return result;
            }
            /*void */ WriteMultiSegment(/*ReadOnlySpan<byte>*/ source)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._writingHead !== null, "_writingHead != null");
                /*Span<byte>*/ let destination = this._writingHeadMemory.Span;
                while(true)
                {
                    /*int*/ let writable = $.$spc.System.Math.Min$4(destination.Length, source.Length);
                    source.Slice$1(0, writable).CopyTo(destination);
                    source = source.Slice(writable);
                    this.AdvanceCore(writable);
                    if (source.Length === 0)
                    {
                        break;
                    }
                    this._writingHead.End += this._writingHeadBytesBuffered;
                    this._writingHeadBytesBuffered = 0;
                    /*BufferSegment*/ let newSegment = this.AllocateSegment(0);
                    this._writingHead.SetNext(newSegment);
                    this._writingHead = newSegment;
                    destination = this._writingHeadMemory.Span;
                }
            }
            /*void */ OnFlushAsyncCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags)
            {
                /*CompletionData*/ let completionData;
                /*bool*/ let doubleCompletion;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._writerAwaitable.OnCompleted(continuation, state, flags, $.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData), $.$ref(() => doubleCompletion, ($v) => doubleCompletion = $v, $.$spc.System.Boolean));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                if (doubleCompletion)
                {
                    this.Reader.Complete($.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation());
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*void */ ReaderCancellationRequested()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._readerAwaitable.CancellationTokenFired($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.ReaderScheduler, $.$ref(() => completionData, ));
            }
            /*void */ WriterCancellationRequested()
            {
                /*CompletionData*/ let completionData;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        this._writerAwaitable.CancellationTokenFired($.$ref(() => completionData, ($v) => completionData = $v, $.$sipl.System.IO.Pipelines.CompletionData));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
                $.$sipl.System.IO.Pipelines.Pipe.TrySchedule(this.WriterScheduler, $.$ref(() => completionData, ));
            }
            /*PipeReader */ get Reader()
            {
                return this._reader;
            }
            /*PipeWriter */ get Writer()
            {
                return this._writer;
            }
            /*void */ Reset()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncObj)
                    {
                        if (!this._disposed)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_ResetIncompleteReaderWriter();
                        }
                        this._disposed = false;
                        this.ResetState();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncObj)
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
                this._sync = new $.$spc.System.Object().$ctor();
                this._readerAwaitable = $.$default($.$sipl.System.IO.Pipelines.PipeAwaitable);
                this._writerAwaitable = $.$default($.$sipl.System.IO.Pipelines.PipeAwaitable);
                this._writerCompletion = $.$default($.$sipl.System.IO.Pipelines.PipeCompletion);
                this._readerCompletion = $.$default($.$sipl.System.IO.Pipelines.PipeCompletion);
                this._writingHeadMemory = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
                this._operationState = $.$default($.$sipl.System.IO.Pipelines.PipeOperationState);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_signalReaderAwaitable = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.Pipe)).ReaderCancellationRequested();
                    });
                }
                {
                    this.s_signalWriterAwaitable = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.Pipe)).WriterCancellationRequested();
                    });
                }
                {
                    this.s_invokeCompletionCallbacks = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$sipl.System.IO.Pipelines.PipeCompletionCallbacks)).Execute();
                    });
                }
                {
                    this.s_executionContextRawCallback = new $.$spc.System.Threading.ContextCallback().$ctor(null, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithoutExecutionContext);
                }
                {
                    this.s_syncContextExecutionContextCallback = new $.$spc.System.Threading.SendOrPostCallback().$ctor(null, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithExecutionContext);
                }
                {
                    this.s_syncContextExecuteWithoutExecutionContextCallback = new $.$spc.System.Threading.SendOrPostCallback().$ctor(null, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithoutExecutionContext);
                }
                {
                    this.s_scheduleWithExecutionContextCallback = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(null, $.$sipl.System.IO.Pipelines.Pipe.ExecuteWithExecutionContext);
                }
            }
            static $h = 627432;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":68720104168,"f":2},"n":"UseSynchronizationContext","d":627432,"h":64425136872,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":77310038760,"f":2},"n":"MinimumSegmentSize","d":627432,"h":73015071464,"f":2},{"p":917505,"g":{"r":0,"d":0,"h":85899973352,"f":2},"n":"PauseWriterThreshold","d":627432,"h":81605006056,"f":2},{"p":917505,"g":{"r":0,"d":0,"h":94489907944,"f":2},"n":"ResumeWriterThreshold","d":627432,"h":90194940648,"f":2},{"p":1544936,"g":{"r":0,"d":0,"h":103079842536,"f":2},"n":"ReaderScheduler","d":627432,"h":98784875240,"f":2},{"p":1544936,"g":{"r":0,"d":0,"h":111669777128,"f":2},"n":"WriterScheduler","d":627432,"h":107374809832,"f":2},{"p":131073,"g":{"r":0,"d":0,"h":120259711720,"f":2},"n":"SyncObj","d":627432,"h":115964744424,"f":2},{"p":917505,"g":{"r":0,"d":0,"h":201864090344,"f":8},"n":"Length","d":627432,"h":197569123048,"f":8},{"p":1413864,"g":{"r":0,"d":0,"h":416612455144,"f":1},"n":"Reader","d":627432,"h":412317487848,"f":1},{"p":1610472,"g":{"r":0,"d":0,"h":425202389736,"f":1},"n":"Writer","d":627432,"h":420907422440,"f":1}],"m":[{"r":65537,"n":"ResetState","d":627432,"h":214748992232,"f":2},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361}],"n":"GetMemory","d":627432,"h":219043959528,"f":8},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361}],"n":"GetSpan","d":627432,"h":223338926824,"f":8},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateWriteHeadIfNeeded","d":627432,"h":227633894120,"f":2},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateWriteHeadSynchronized","d":627432,"h":231928861416,"f":2},{"r":103144,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateSegment","d":627432,"h":236223828712,"f":2},{"r":65537,"p":[{"n":"segment","p":103144},{"n":"sizeHint","p":655361}],"n":"RentMemory","d":627432,"h":240518796008,"f":2},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361,"f":65,"v":2147483647}],"n":"GetSegmentSize","d":627432,"h":244813763304,"f":2},{"r":103144,"n":"CreateSegmentUnsynchronized","d":627432,"h":249108730600,"f":2},{"r":65537,"p":[{"n":"segment","p":103144}],"n":"ReturnSegmentUnsynchronized","d":627432,"h":253403697896,"f":2},{"r":262145,"n":"CommitUnsynchronized","d":627432,"h":257698665192,"f":8},{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":627432,"h":261993632488,"f":8},{"r":65537,"p":[{"n":"bytesWritten","p":655361}],"n":"AdvanceCore","d":627432,"h":266288599784,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","d":627432,"h":270583567080,"f":8},{"r":65537,"p":[{"n":"completionData","p":299752,"f":2},{"n":"result","p":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"f":2},{"n":"cancellationToken","p":125960193}],"n":"PrepareFlushUnsynchronized","d":627432,"h":274878534376,"f":2},{"r":65537,"p":[{"n":"exception","p":47185921}],"n":"CompleteWriter","d":627432,"h":279173501672,"f":8},{"r":65537,"p":[{"n":"consumed","p":1222797,"f":8}],"n":"AdvanceReader","d":627432,"h":283468468968,"f":8},{"r":65537,"p":[{"n":"consumed","p":1222797,"f":8},{"n":"examined","p":1222797,"f":8}],"n":"AdvanceReader","o":"@$1","d":627432,"h":287763436264,"f":8},{"r":65537,"p":[{"n":"consumedSegment","p":103144},{"n":"consumedIndex","p":655361},{"n":"examinedSegment","p":103144},{"n":"examinedIndex","p":655361}],"n":"AdvanceReader","o":"@$2","d":627432,"h":292058403560,"f":2},{"r":65537,"p":[{"n":"exception","p":47185921}],"n":"CompleteReader","d":627432,"h":296353370856,"f":8},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnWriterCompleted","d":627432,"h":300648338152,"f":8},{"r":65537,"n":"CancelPendingRead","d":627432,"h":304943305448,"f":8},{"r":65537,"n":"CancelPendingFlush","d":627432,"h":309238272744,"f":8},{"r":65537,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"OnReaderCompleted","d":627432,"h":313533240040,"f":8},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumBytes","p":655361},{"n":"token","p":125960193}],"n":"ReadAtLeastAsync","d":627432,"h":317828207336,"f":8},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"token","p":125960193}],"n":"ReadAsync","d":627432,"h":322123174632,"f":8},{"r":262145,"p":[{"n":"result","p":1741544,"f":2}],"n":"TryRead","d":627432,"h":326418141928,"f":8},{"r":65537,"p":[{"n":"scheduler","p":1544936},{"n":"completionCallbacks","p":1151720}],"n":"ScheduleCallbacks","d":627432,"h":330713109224,"f":34},{"r":65537,"p":[{"n":"scheduler","p":1544936},{"n":"completionData","p":299752,"f":8}],"n":"TrySchedule","d":627432,"h":335008076520,"f":34},{"r":65537,"p":[{"n":"scheduler","p":1544936},{"n":"completionData","p":299752,"f":8}],"n":"ScheduleWithContext","d":627432,"h":339303043816,"f":34},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ExecuteWithoutExecutionContext","d":627432,"h":343598011112,"f":34},{"r":65537,"p":[{"n":"state","p":131073}],"n":"ExecuteWithExecutionContext","d":627432,"h":347892978408,"f":34},{"r":65537,"n":"CompletePipe","d":627432,"h":352187945704,"f":2},{"r":133038081,"n":"GetReadAsyncStatus","d":627432,"h":356482913000,"f":8},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132972545}],"n":"OnReadAsyncCompleted","d":627432,"h":360777880296,"f":8},{"r":1741544,"n":"GetReadAsyncResult","d":627432,"h":365072847592,"f":8},{"r":65537,"p":[{"n":"result","p":1741544,"f":2}],"n":"GetReadResult","d":627432,"h":369367814888,"f":2},{"r":133038081,"n":"GetFlushAsyncStatus","d":627432,"h":373662782184,"f":8},{"r":430824,"n":"GetFlushAsyncResult","d":627432,"h":377957749480,"f":8},{"r":917505,"n":"GetUnflushedBytes","d":627432,"h":382252716776,"f":8},{"r":65537,"p":[{"n":"result","p":430824,"f":4}],"n":"GetFlushResult","d":627432,"h":386547684072,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","d":627432,"h":390842651368,"f":8},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"WriteMultiSegment","d":627432,"h":395137618664,"f":2},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132972545}],"n":"OnFlushAsyncCompleted","d":627432,"h":399432585960,"f":8},{"r":65537,"n":"ReaderCancellationRequested","d":627432,"h":403727553256,"f":2},{"r":65537,"n":"WriterCancellationRequested","d":627432,"h":408022520552,"f":2},{"r":65537,"n":"Reset","d":627432,"h":429497357032,"f":1}],"l":[{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_signalReaderAwaitable","d":627432,"h":12885529320,"f":34},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_signalWriterAwaitable","d":627432,"h":17180496616,"f":34},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_invokeCompletionCallbacks","d":627432,"h":21475463912,"f":34},{"t":126615553,"n":"s_executionContextRawCallback","d":627432,"h":25770431208,"f":34},{"t":130875393,"n":"s_syncContextExecutionContextCallback","d":627432,"h":30065398504,"f":34},{"t":130875393,"n":"s_syncContextExecuteWithoutExecutionContextCallback","d":627432,"h":34360365800,"f":34},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"s_scheduleWithExecutionContextCallback","d":627432,"h":38655333096,"f":34},{"t":168680,"n":"_bufferSegmentPool","d":627432,"h":42950300392,"f":2},{"t":692968,"n":"_reader","d":627432,"h":47245267688,"f":2},{"t":758504,"n":"_writer","d":627432,"h":51540234984,"f":2},{"t":1348328,"n":"_options","d":627432,"h":55835202280,"f":2},{"t":131073,"n":"_sync","d":627432,"h":60130169576,"f":2},{"t":917505,"n":"_unconsumedBytes","d":627432,"h":124554679016,"f":2},{"t":917505,"n":"_unflushedBytes","d":627432,"h":128849646312,"f":2},{"t":824040,"n":"_readerAwaitable","d":627432,"h":133144613608,"f":2},{"t":824040,"n":"_writerAwaitable","d":627432,"h":137439580904,"f":2},{"t":1020648,"n":"_writerCompletion","d":627432,"h":141734548200,"f":2},{"t":1020648,"n":"_readerCompletion","d":627432,"h":146029515496,"f":2},{"t":917505,"n":"_lastExaminedIndex","d":627432,"h":150324482792,"f":2},{"t":103144,"n":"_readHead","d":627432,"h":154619450088,"f":2},{"t":655361,"n":"_readHeadIndex","d":627432,"h":158914417384,"f":2},{"t":262145,"n":"_disposed","d":627432,"h":163209384680,"f":2},{"t":103144,"n":"_readTail","d":627432,"h":167504351976,"f":2},{"t":655361,"n":"_readTailIndex","d":627432,"h":171799319272,"f":2},{"t":655361,"n":"_minimumReadBytes","d":627432,"h":176094286568,"f":2},{"t":103144,"n":"_writingHead","d":627432,"h":180389253864,"f":2},{"t":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"n":"_writingHeadMemory","d":627432,"h":184684221160,"f":2},{"t":655361,"n":"_writingHeadBytesBuffered","d":627432,"h":188979188456,"f":2},{"t":1217256,"n":"_operationState","d":627432,"h":193274155752,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":627432,"h":206159057640,"f":1},{"p":[{"n":"options","p":1348328}],"n":".ctor","o":"$ctor$2","d":627432,"h":210454024936,"f":1}],"j":[692968,758504],"h":627432}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.Pipe`; }
        });
        
        $asm.$cls("$sipl.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sipl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.IO.Pipelines", $.$sipl.System.SR.$type.Assembly);
                    $.$sipl.System.SR.s_resourceManager = temp;
                }
                return $.$sipl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sipl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sipl.System.SR.resourceCulture = value;
            }
            static /*string */ get AdvanceToInvalidCursor()
            {
                return "The PipeReader has already advanced past the provided position.";
            }
            static /*string */ get ArgumentOutOfRange_NeedPosNum()
            {
                return "Positive number required.";
            }
            static /*string */ get ConcurrentOperationsNotSupported()
            {
                return "Concurrent reads or writes are not supported.";
            }
            static /*string */ get FlushCanceledOnPipeWriter()
            {
                return "Flush was canceled on underlying PipeWriter.";
            }
            static /*string */ get GetResultBeforeCompleted()
            {
                return "Can't GetResult unless awaiter is completed.";
            }
            static /*string */ get InvalidExaminedOrConsumedPosition()
            {
                return "The examined position must be greater than or equal to the consumed position.";
            }
            static /*string */ get InvalidExaminedPosition()
            {
                return "The examined position cannot be less than the previously examined position.";
            }
            static /*string */ get InvalidZeroByteRead()
            {
                return "The PipeReader returned 0 bytes when the ReadResult was not completed or canceled.";
            }
            static /*string */ get ObjectDisposed_StreamClosed()
            {
                return "Cannot access a closed stream.";
            }
            static /*string */ get NoReadingOperationToComplete()
            {
                return "No reading operation to complete.";
            }
            static /*string */ get NotSupported_UnreadableStream()
            {
                return "Stream does not support reading.";
            }
            static /*string */ get NotSupported_UnwritableStream()
            {
                return "Stream does not support writing.";
            }
            static /*string */ get ReadCanceledOnPipeReader()
            {
                return "Read was canceled on underlying PipeReader.";
            }
            static /*string */ get ReaderAndWriterHasToBeCompleted()
            {
                return "Both reader and writer has to be completed to be able to reset the pipe.";
            }
            static /*string */ get ReadingAfterCompleted()
            {
                return "Reading is not allowed after reader was completed.";
            }
            static /*string */ get ReadingIsInProgress()
            {
                return "Reading is already in progress.";
            }
            static /*string */ get WritingAfterCompleted()
            {
                return "Writing is not allowed after writer was completed.";
            }
            static /*string */ get UnflushedBytesNotSupported()
            {
                return "UnflushedBytes is not supported.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sipl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sipl.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sipl.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sipl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sipl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sipl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sipl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2462440;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2462440}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeCompletionCallbacks", ($self) => class PipeCompletionCallbacks extends $.$spc.System.Object
        {
            /*List<PipeCompletionCallback>*/ _callbacks = null;
            /*Exception?*/ _exception = null;
            $ctor$1(/*List<PipeCompletionCallback>*/ callbacks, /*ExceptionDispatchInfo?*/ edi)
            {
                super.$ctor();
                {
                    this._callbacks = callbacks;
                    this._exception = (edi?.SourceException ?? null);
                }
                return this;
            }
            /*void */ Execute()
            {
                /*var*/ let count = this._callbacks.Count;
                if (count === 0)
                {
                    return;
                }
                /*List<Exception>?*/ let exceptions = null;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*var*/ let callback = this._callbacks.get_Item(i);
                    this.Execute$1(callback, $.$ref(() => exceptions, ($v) => exceptions = $v, $.$spc.System.Collections.Generic.List$$($.$spc.System.Exception)));
                }
                if (exceptions !== null)
                {
                    throw new $.$spc.System.AggregateException().$ctor$8(exceptions);
                }
            }
            /*void */ Execute$1(/*PipeCompletionCallback*/ callback, /*ref List<Exception>?*/ exceptions)
            {
                try
                {
                    callback.Callback.Invoke(this._exception, callback.State);
                }
                catch(ex)
                {
                    exceptions.$v ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Exception))().$ctor$1();
                    exceptions.$v.Add(ex);
                }
            }
            static $h = 1151720;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Execute","d":1151720,"h":17181020904,"f":1},{"r":65537,"p":[{"n":"callback","p":1086184},{"n":"exceptions","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Exception).$h,"f":4}],"n":"Execute","o":"@$1","d":1151720,"h":21475988200,"f":2}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h,"n":"_callbacks","d":1151720,"h":4296119016,"f":2},{"t":47185921,"n":"_exception","d":1151720,"h":8591086312,"f":2}],"c":[{"p":[{"n":"callbacks","p":$.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h},{"n":"edi","p":97517569}],"n":".ctor","o":"$ctor$1","d":1151720,"h":12886053608,"f":1}],"h":1151720}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletionCallbacks`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeOptions", ($self) => class PipeOptions extends $.$spc.System.Object
        {
            /*int*/ static DefaultMinimumSegmentSize = 4096;
            /*PipeOptions*/ static Default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*PipeScheduler?*/ readerScheduler, /*PipeScheduler?*/ writerScheduler, /*long*/ pauseWriterThreshold, /*long*/ resumeWriterThreshold, /*int*/ minimumSegmentSize, /*bool*/ useSynchronizationContext)
            {
                super.$ctor();
                {
                    this.MinimumSegmentSize = minimumSegmentSize === -1 ? 4096/*DefaultMinimumSegmentSize*/ : minimumSegmentSize;
                    this.InitialSegmentPoolSize = 4;
                    this.MaxSegmentPoolSize = 256;
                    /*int*/ let DefaultPauseWriterThreshold = 65536;
                    /*int*/ let DefaultResumeWriterThreshold = $.trunc(DefaultPauseWriterThreshold / 2);
                    if (pauseWriterThreshold === BigInt(-1))
                    {
                        pauseWriterThreshold = BigInt(DefaultPauseWriterThreshold);
                    }
                    else if (pauseWriterThreshold < 0n)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(4/*ExceptionArgument.pauseWriterThreshold*/);
                    }
                    if (resumeWriterThreshold === BigInt(-1))
                    {
                        resumeWriterThreshold = BigInt(DefaultResumeWriterThreshold);
                    }
                    else if (resumeWriterThreshold === 0n)
                    {
                        resumeWriterThreshold = 1n;
                    }
                    if (resumeWriterThreshold < 0n || (pauseWriterThreshold > 0n && resumeWriterThreshold > pauseWriterThreshold))
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(5/*ExceptionArgument.resumeWriterThreshold*/);
                    }
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.IsDefaultSharedMemoryPool = this.Pool === $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.ReaderScheduler = readerScheduler ?? $.$sipl.System.IO.Pipelines.PipeScheduler.ThreadPool;
                    this.WriterScheduler = writerScheduler ?? $.$sipl.System.IO.Pipelines.PipeScheduler.ThreadPool;
                    this.PauseWriterThreshold = pauseWriterThreshold;
                    this.ResumeWriterThreshold = resumeWriterThreshold;
                    this.UseSynchronizationContext = useSynchronizationContext;
                }
                return this;
            }
            /*bool*/ UseSynchronizationContext = false;
            /*long*/ PauseWriterThreshold = 0n;
            /*long*/ ResumeWriterThreshold = 0n;
            /*int*/ MinimumSegmentSize = 0;
            /*PipeScheduler*/ WriterScheduler = null;
            /*PipeScheduler*/ ReaderScheduler = null;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ IsDefaultSharedMemoryPool = false;
            /*int*/ InitialSegmentPoolSize = 0;
            /*int*/ MaxSegmentPoolSize = 0;
            //default member initializer
            constructor()
            {
                super();
                this.UseSynchronizationContext = false;
                this.IsDefaultSharedMemoryPool = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$sipl.System.IO.Pipelines.PipeOptions().$ctor$1(null, null, null, -1n, -1n, -1, true);
                }
            }
            static $h = 1348328;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1348328,"g":{"r":0,"d":0,"h":17181217512,"f":33},"n":"Default","d":1348328,"h":12886250216,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":34361086696,"f":1},"n":"UseSynchronizationContext","d":1348328,"h":30066119400,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":47245988584,"f":1},"n":"PauseWriterThreshold","d":1348328,"h":42951021288,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":60130890472,"f":1},"n":"ResumeWriterThreshold","d":1348328,"h":55835923176,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73015792360,"f":1},"n":"MinimumSegmentSize","d":1348328,"h":68720825064,"f":1},{"p":1544936,"g":{"r":0,"d":0,"h":85900694248,"f":1},"n":"WriterScheduler","d":1348328,"h":81605726952,"f":1},{"p":1544936,"g":{"r":0,"d":0,"h":98785596136,"f":1},"n":"ReaderScheduler","d":1348328,"h":94490628840,"f":1},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":111670498024,"f":1},"n":"Pool","d":1348328,"h":107375530728,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124555399912,"f":8},"n":"IsDefaultSharedMemoryPool","d":1348328,"h":120260432616,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":137440301800,"f":8},"n":"InitialSegmentPoolSize","d":1348328,"h":133145334504,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":150325203688,"f":8},"n":"MaxSegmentPoolSize","d":1348328,"h":146030236392,"f":8}],"l":[{"t":655361,"n":"DefaultMinimumSegmentSize","d":1348328,"h":4296315624,"f":34}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"f":65},{"n":"readerScheduler","p":1544936,"f":65},{"n":"writerScheduler","p":1544936,"f":65},{"n":"pauseWriterThreshold","p":917505,"f":65,"v":-1},{"n":"resumeWriterThreshold","p":917505,"f":65,"v":-1},{"n":"minimumSegmentSize","p":655361,"f":65,"v":-1},{"n":"useSynchronizationContext","p":262145,"f":65,"v":true}],"n":".ctor","o":"$ctor$1","d":1348328,"h":21476184808,"f":1}],"h":1348328}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.PipeOptions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeExtensions", ($self) => class StreamPipeExtensions
        {
            static /*Task */ CopyToAsync(/*this Stream*/ source, /*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                if (source === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.source*/);
                }
                if (destination === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.destination*/);
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$spc.System.Threading.Tasks.Task.FromCanceled(cancellationToken);
                }
                return destination.CopyFromAsync(source, cancellationToken);
            }
            static $h = 1938152;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"p":[{"n":"source","p":62128129},{"n":"destination","p":1610472},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","d":1938152,"h":4296905448,"f":33}],"h":1938152}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeExtensions`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateArgumentOutOfRangeException(argument);
            }
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                return new $.$spc.System.ArgumentOutOfRangeException().$ctor$16($.$spc.System.Enum.ToStringT($.$sipl.System.IO.Pipelines.ExceptionArgument, $.$spc.System.UInt32, argument));
            }
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateArgumentNullException(argument);
            }
            static /*ArgumentNullException */ CreateArgumentNullException(/*ExceptionArgument*/ argument)
            {
                return new $.$spc.System.ArgumentNullException().$ctor$16($.$spc.System.Enum.ToStringT($.$sipl.System.IO.Pipelines.ExceptionArgument, $.$spc.System.UInt32, argument));
            }
            static /*void */ ThrowInvalidOperationException_AlreadyReading()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_AlreadyReading();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_AlreadyReading()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ReadingIsInProgress);
            }
            static /*void */ ThrowInvalidOperationException_NoReadToComplete()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoReadToComplete();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoReadToComplete()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.NoReadingOperationToComplete);
            }
            static /*void */ ThrowInvalidOperationException_NoConcurrentOperation()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoConcurrentOperation();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoConcurrentOperation()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ConcurrentOperationsNotSupported);
            }
            static /*void */ ThrowInvalidOperationException_GetResultNotCompleted()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_GetResultNotCompleted();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_GetResultNotCompleted()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.GetResultBeforeCompleted);
            }
            static /*void */ ThrowInvalidOperationException_NoWritingAllowed()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoWritingAllowed();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoWritingAllowed()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.WritingAfterCompleted);
            }
            static /*void */ ThrowInvalidOperationException_NoReadingAllowed()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_NoReadingAllowed();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_NoReadingAllowed()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ReadingAfterCompleted);
            }
            static /*void */ ThrowInvalidOperationException_InvalidExaminedPosition()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidExaminedPosition();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidExaminedPosition()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.InvalidExaminedPosition);
            }
            static /*void */ ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidExaminedOrConsumedPosition();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidExaminedOrConsumedPosition()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.InvalidExaminedOrConsumedPosition);
            }
            static /*void */ ThrowInvalidOperationException_AdvanceToInvalidCursor()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_AdvanceToInvalidCursor();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_AdvanceToInvalidCursor()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.AdvanceToInvalidCursor);
            }
            static /*void */ ThrowInvalidOperationException_ResetIncompleteReaderWriter()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_ResetIncompleteReaderWriter();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_ResetIncompleteReaderWriter()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.ReaderAndWriterHasToBeCompleted);
            }
            static /*void */ ThrowOperationCanceledException_ReadCanceled()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateOperationCanceledException_ReadCanceled();
            }
            static /*OperationCanceledException */ CreateOperationCanceledException_ReadCanceled()
            {
                return new $.$spc.System.OperationCanceledException().$ctor$10($.$sipl.System.SR.ReadCanceledOnPipeReader);
            }
            static /*void */ ThrowOperationCanceledException_FlushCanceled()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateOperationCanceledException_FlushCanceled();
            }
            static /*OperationCanceledException */ CreateOperationCanceledException_FlushCanceled()
            {
                return new $.$spc.System.OperationCanceledException().$ctor$10($.$sipl.System.SR.FlushCanceledOnPipeWriter);
            }
            static /*void */ ThrowInvalidOperationException_InvalidZeroByteRead()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateInvalidOperationException_InvalidZeroByteRead();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_InvalidZeroByteRead()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$sipl.System.SR.InvalidZeroByteRead);
            }
            static /*void */ ThrowNotSupported_UnflushedBytes()
            {
                throw $.$sipl.System.IO.Pipelines.ThrowHelper.CreateNotSupportedException_UnflushedBytes();
            }
            static /*NotSupportedException */ CreateNotSupportedException_UnflushedBytes()
            {
                return new $.$spc.System.NotSupportedException().$ctor$10($.$sipl.System.SR.UnflushedBytesNotSupported);
            }
            static $h = 2331368;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":365288}],"n":"ThrowArgumentOutOfRangeException","d":2331368,"h":4297298664,"f":40},{"r":13500417,"p":[{"n":"argument","p":365288}],"n":"CreateArgumentOutOfRangeException","d":2331368,"h":8592265960,"f":34},{"r":65537,"p":[{"n":"argument","p":365288}],"n":"ThrowArgumentNullException","d":2331368,"h":12887233256,"f":40},{"r":13434881,"p":[{"n":"argument","p":365288}],"n":"CreateArgumentNullException","d":2331368,"h":17182200552,"f":34},{"r":65537,"n":"ThrowInvalidOperationException_AlreadyReading","d":2331368,"h":21477167848,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_AlreadyReading","d":2331368,"h":25772135144,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoReadToComplete","d":2331368,"h":30067102440,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_NoReadToComplete","d":2331368,"h":34362069736,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoConcurrentOperation","d":2331368,"h":38657037032,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_NoConcurrentOperation","d":2331368,"h":42952004328,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_GetResultNotCompleted","d":2331368,"h":47246971624,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_GetResultNotCompleted","d":2331368,"h":51541938920,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoWritingAllowed","d":2331368,"h":55836906216,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_NoWritingAllowed","d":2331368,"h":60131873512,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_NoReadingAllowed","d":2331368,"h":64426840808,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_NoReadingAllowed","d":2331368,"h":68721808104,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_InvalidExaminedPosition","d":2331368,"h":73016775400,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_InvalidExaminedPosition","d":2331368,"h":77311742696,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_InvalidExaminedOrConsumedPosition","d":2331368,"h":81606709992,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_InvalidExaminedOrConsumedPosition","d":2331368,"h":85901677288,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_AdvanceToInvalidCursor","d":2331368,"h":90196644584,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_AdvanceToInvalidCursor","d":2331368,"h":94491611880,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_ResetIncompleteReaderWriter","d":2331368,"h":98786579176,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_ResetIncompleteReaderWriter","d":2331368,"h":103081546472,"f":33},{"r":65537,"n":"ThrowOperationCanceledException_ReadCanceled","d":2331368,"h":107376513768,"f":33},{"r":71106561,"n":"CreateOperationCanceledException_ReadCanceled","d":2331368,"h":111671481064,"f":33},{"r":65537,"n":"ThrowOperationCanceledException_FlushCanceled","d":2331368,"h":115966448360,"f":33},{"r":71106561,"n":"CreateOperationCanceledException_FlushCanceled","d":2331368,"h":120261415656,"f":33},{"r":65537,"n":"ThrowInvalidOperationException_InvalidZeroByteRead","d":2331368,"h":124556382952,"f":33},{"r":58195969,"n":"CreateInvalidOperationException_InvalidZeroByteRead","d":2331368,"h":128851350248,"f":33},{"r":65537,"n":"ThrowNotSupported_UnflushedBytes","d":2331368,"h":133146317544,"f":33},{"r":66781185,"n":"CreateNotSupportedException_UnflushedBytes","d":2331368,"h":137441284840,"f":33}],"h":2331368}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.ThrowHelper`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeReaderOptions", ($self) => class StreamPipeReaderOptions extends $.$spc.System.Object
        {
            /*int*/ static DefaultBufferSize = 4096;
            /*int*/ static DefaultMaxBufferSize = 2097152;
            /*int*/ static DefaultMinimumReadSize = 1024;
            /*StreamPipeReaderOptions*/ static s_default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*int*/ bufferSize, /*int*/ minimumReadSize, /*bool*/ leaveOpen)
            {
                this.$ctor$2(null, -1, -1, false, false);
                {
                }
                return this;
            }
            $ctor$2(/*MemoryPool<byte>?*/ pool, /*int*/ bufferSize, /*int*/ minimumReadSize, /*bool*/ leaveOpen, /*bool*/ useZeroByteReads)
            {
                super.$ctor();
                {
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.IsDefaultSharedMemoryPool = this.Pool === $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.BufferSize = bufferSize === -1 ? 4096/*DefaultBufferSize*/ : bufferSize <= 0 ? (() =>
                    {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("bufferSize")            })() : bufferSize;
                    this.MinimumReadSize = minimumReadSize === -1 ? 1024/*DefaultMinimumReadSize*/ : minimumReadSize <= 0 ? (() =>
                    {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("minimumReadSize")            })() : minimumReadSize;
                    this.LeaveOpen = leaveOpen;
                    this.UseZeroByteReads = useZeroByteReads;
                }
                return this;
            }
            /*int*/ BufferSize = 0;
            /*int*/ MaxBufferSize = 0;
            /*int*/ MinimumReadSize = 0;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ LeaveOpen = false;
            /*bool*/ UseZeroByteReads = false;
            /*bool*/ IsDefaultSharedMemoryPool = false;
            //default member initializer
            constructor()
            {
                super();
                this.MaxBufferSize = 2097152;
                this.LeaveOpen = false;
                this.UseZeroByteReads = false;
                this.IsDefaultSharedMemoryPool = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_default = new $.$sipl.System.IO.Pipelines.StreamPipeReaderOptions().$ctor$2(null, -1, -1, false, false);
                }
            }
            static $h = 2069224;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":38656774888,"f":1},"n":"BufferSize","d":2069224,"h":34361807592,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51541676776,"f":8},"n":"MaxBufferSize","d":2069224,"h":47246709480,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":64426578664,"f":1},"n":"MinimumReadSize","d":2069224,"h":60131611368,"f":1},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":77311480552,"f":1},"n":"Pool","d":2069224,"h":73016513256,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":90196382440,"f":1},"n":"LeaveOpen","d":2069224,"h":85901415144,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":103081284328,"f":1},"n":"UseZeroByteReads","d":2069224,"h":98786317032,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115966186216,"f":8},"n":"IsDefaultSharedMemoryPool","d":2069224,"h":111671218920,"f":8}],"l":[{"t":655361,"n":"DefaultBufferSize","d":2069224,"h":4297036520,"f":34},{"t":655361,"n":"DefaultMaxBufferSize","d":2069224,"h":8592003816,"f":40},{"t":655361,"n":"DefaultMinimumReadSize","d":2069224,"h":12886971112,"f":34},{"t":2069224,"n":"s_default","d":2069224,"h":17181938408,"f":40}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h},{"n":"bufferSize","p":655361},{"n":"minimumReadSize","p":655361},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$1","d":2069224,"h":21476905704,"f":1},{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"f":65},{"n":"bufferSize","p":655361,"f":65,"v":-1},{"n":"minimumReadSize","p":655361,"f":65,"v":-1},{"n":"leaveOpen","p":262145,"f":65,"v":false},{"n":"useZeroByteReads","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$2","d":2069224,"h":25771873000,"f":1}],"h":2069224}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeReaderOptions`; }
        });
        
        $asm.$cls("$sipl.System.IO.StreamHelpers", ($self) => class StreamHelpers
        {
            static /*void */ ValidateCopyToArgs(/*Stream*/ source, /*Stream*/ destination, /*int*/ bufferSize)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(destination, "destination");
                if (bufferSize <= 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("bufferSize", $.$box(bufferSize, $.$spc.System.Int32), $.$sipl.System.SR.ArgumentOutOfRange_NeedPosNum);
                }
                /*bool*/ let sourceCanRead = source.CanRead;
                if (!sourceCanRead && !source.CanWrite)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15(null, $.$sipl.System.SR.ObjectDisposed_StreamClosed);
                }
                /*bool*/ let destinationCanWrite = destination.CanWrite;
                if (!destinationCanWrite && !destination.CanRead)
                {
                    throw new $.$spc.System.ObjectDisposedException().$ctor$15("destination", $.$sipl.System.SR.ObjectDisposed_StreamClosed);
                }
                if (!sourceCanRead)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sipl.System.SR.NotSupported_UnreadableStream);
                }
                if (!destinationCanWrite)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$sipl.System.SR.NotSupported_UnwritableStream);
                }
            }
            static $h = 2396904;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"source","p":62128129},{"n":"destination","p":62128129},{"n":"bufferSize","p":655361}],"n":"ValidateCopyToArgs","d":2396904,"h":4297364200,"f":33}],"h":2396904}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.StreamHelpers`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeWriterOptions", ($self) => class StreamPipeWriterOptions extends $.$spc.System.Object
        {
            /*int*/ static DefaultMinimumBufferSize = 4096;
            /*StreamPipeWriterOptions*/ static s_default = null;
            $ctor$1(/*MemoryPool<byte>?*/ pool, /*int*/ minimumBufferSize, /*bool*/ leaveOpen)
            {
                super.$ctor();
                {
                    this.Pool = pool ?? $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared;
                    this.MinimumBufferSize = minimumBufferSize === -1 ? 4096/*DefaultMinimumBufferSize*/ : minimumBufferSize <= 0 ? (() =>
                    {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("minimumBufferSize")            })() : minimumBufferSize;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*int*/ MinimumBufferSize = 0;
            /*MemoryPool<byte>*/ Pool = null;
            /*bool*/ LeaveOpen = false;
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_default = new $.$sipl.System.IO.Pipelines.StreamPipeWriterOptions().$ctor$1(null, -1, false);
                }
            }
            static $h = 2200296;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25772004072,"f":1},"n":"MinimumBufferSize","d":2200296,"h":21477036776,"f":1},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":38656905960,"f":1},"n":"Pool","d":2200296,"h":34361938664,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51541807848,"f":1},"n":"LeaveOpen","d":2200296,"h":47246840552,"f":1}],"l":[{"t":655361,"n":"DefaultMinimumBufferSize","d":2200296,"h":4297167592,"f":34},{"t":2200296,"n":"s_default","d":2200296,"h":8592134888,"f":40}],"c":[{"p":[{"n":"pool","p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"f":65},{"n":"minimumBufferSize","p":655361,"f":65,"v":-1},{"n":"leaveOpen","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$1","d":2200296,"h":12887102184,"f":1}],"h":2200296}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeWriterOptions`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.BufferSegmentStack", ($self) => class BufferSegmentStack extends $.$spc.System.ValueType
        {
            /*SegmentAsValueType[]*/  get _array() { return this.$getField(0, 4); }
            /*SegmentAsValueType[]*/  set _array(value) { this.$setField(0, 4, value); }
            /*int*/  get _size() { return this.$getField(4, 4); }
            /*int*/  set _size(value) { this.$setField(4, 4, value); }
            $ctor$2(/*int*/ size)
            {
                super.$ctor$1();
                {
                    this._array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType), null, [size], null);
                    this._size = 0;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._size;
            }
            /*bool */ TryPop(/*out BufferSegment?*/ result)
            {
                /*int*/ let size = ((this._size - 1) | 0);
                /*SegmentAsValueType[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    result.$v = null;
                    return false;
                }
                this._size = size;
                result.$v = $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit$1($.$spc.System.Array.$ReadT1.call(array, size));
                $.$spc.System.Array.$WriteT1.call(array, new $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType(), size);
                return true;
            }
            /*void */ Push(/*BufferSegment*/ item)
            {
                /*int*/ let size = this._size;
                /*SegmentAsValueType[]*/ let array = this._array;
                if ((size >>> 0) < (array.length >>> 0))
                {
                    $.$spc.System.Array.$WriteT1.call(array, $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit(item), size);
                    this._size = ((size + 1) | 0);
                }
                else 
                {
                    this.PushWithResize(item);
                }
            }
            /*void */ PushWithResize(/*BufferSegment*/ item)
            {
                $.$spc.System.Array.Resize($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType, $.$ref(() => this._array, ($v) => this._array = $v, $.$typeArray($.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType)), ((2 * this._array.length) | 0));
                $.$spc.System.Array.$WriteT1.call(this._array, $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType.op_Implicit(item), this._size);
                this._size++;
            }
            static $_SegmentAsValueType;
            static get SegmentAsValueType()
            {
                let $cls = $.$sipl.System.IO.Pipelines.BufferSegmentStack;
                return $cls.$_SegmentAsValueType ??= $asm.$nstr("$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType", ($self) => class SegmentAsValueType extends $.$spc.System.ValueType
                {
                    /*BufferSegment*/  get _value() { return this.$getField(0, 4); }
                    /*BufferSegment*/  set _value(value) { this.$setField(0, 4, value); }
                    $ctor$2(/*BufferSegment*/ value)
                    {
                        super.$ctor$1();
                        this._value = value;
                        return this;
                    }
                    static /*SegmentAsValueType */ op_Implicit(/*BufferSegment*/ s)
                    {
                        return new $.$sipl.System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType().$ctor$2(s);
                    }
                    static /*BufferSegment */ op_Implicit$1(/*SegmentAsValueType*/ s)
                    {
                        return s._value;
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._value = this._value;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._value = null;
                    }
                    static $h = 234216;
                    static $z = 4;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":103144,"n":"_value","d":234216,"h":4295201512,"f":2}],"c":[{"p":[{"n":"value","p":103144}],"n":".ctor","o":"$ctor$2","d":234216,"h":8590168808,"f":2},{"n":".ctor","o":"$ctor$3","d":234216,"h":21475070696,"f":1}],"d":168680,"h":234216}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.IO.Pipelines.BufferSegmentStack.SegmentAsValueType`; }
                }, $cls, ($v) => $cls.$_SegmentAsValueType = $v);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._array = this._array;
                copy._size = this._size;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._array = null;
                this._size = 0;
            }
            static $h = 168680;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21475005160,"f":1},"n":"Count","d":168680,"h":17180037864,"f":1}],"m":[{"r":262145,"p":[{"n":"result","p":103144,"f":2}],"n":"TryPop","d":168680,"h":25769972456,"f":1},{"r":65537,"p":[{"n":"item","p":103144}],"n":"Push","d":168680,"h":30064939752,"f":1},{"r":65537,"p":[{"n":"item","p":103144}],"n":"PushWithResize","d":168680,"h":34359907048,"f":2}],"l":[{"t":0,"n":"_array","d":168680,"h":4295135976,"f":2},{"t":655361,"n":"_size","d":168680,"h":8590103272,"f":2}],"c":[{"p":[{"n":"size","p":655361}],"n":".ctor","o":"$ctor$2","d":168680,"h":12885070568,"f":1},{"n":".ctor","o":"$ctor$3","d":168680,"h":42949841640,"f":1}],"j":[234216],"h":168680}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.BufferSegmentStack`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeCompletion", ($self) => class PipeCompletion extends $.$spc.System.ValueType
        {
            /*object*/ static s_completedSuccessfully = null;
            /*object?*/  get _state() { return this.$getField(0, 4); }
            /*object?*/  set _state(value) { this.$setField(0, 4, value); }
            /*List<PipeCompletionCallback>?*/  get _callbacks() { return this.$getField(4, 4); }
            /*List<PipeCompletionCallback>?*/  set _callbacks(value) { this.$setField(4, 4, value); }
            /*bool */ get IsCompleted()
            {
                return this._state !== null;
            }
            /*bool */ get IsFaulted()
            {
                return $.$is(this._state, $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo);
            }
            /*PipeCompletionCallbacks? */ TryComplete(/*Exception?*/ exception)
            {
                if (this._state === null)
                {
                    if (exception !== null)
                    {
                        this._state = $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exception);
                    }
                    else 
                    {
                        this._state = $.$sipl.System.IO.Pipelines.PipeCompletion.s_completedSuccessfully;
                    }
                }
                return this.GetCallbacks();
            }
            /*PipeCompletionCallbacks? */ AddCallback(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                this._callbacks ??= new ($.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback))().$ctor$1();
                this._callbacks.Add(new $.$sipl.System.IO.Pipelines.PipeCompletionCallback().$ctor$2(callback, state));
                if (this.IsCompleted)
                {
                    return this.GetCallbacks();
                }
                return null;
            }
            /*bool */ IsCompletedOrThrow()
            {
                if (!this.IsCompleted)
                {
                    return false;
                }
                let edi;
                if ($.$is(this._state, $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo, { set $v(v){ edi = v; } }))
                {
                    edi.Throw();
                }
                return true;
            }
            /*PipeCompletionCallbacks? */ GetCallbacks()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsCompleted, "IsCompleted");
                /*var*/ let callbacks = this._callbacks;
                if (callbacks === null)
                {
                    return null;
                }
                this._callbacks = null;
                return new $.$sipl.System.IO.Pipelines.PipeCompletionCallbacks().$ctor$1(callbacks, $.$as(this._state, $.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo));
            }
            /*void */ Reset()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsCompleted, "IsCompleted");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._callbacks === null, "_callbacks == null");
                this._state = null;
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `${"IsCompleted"}: ${this.IsCompleted}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sipl.System.IO.Pipelines.PipeCompletion.ToString.apply(this, arguments); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._state = this._state;
                copy._callbacks = this._callbacks;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = null;
                this._callbacks = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_completedSuccessfully = new $.$spc.System.Object().$ctor();
                }
            }
            static $h = 1020648;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475857128,"f":1},"n":"IsCompleted","d":1020648,"h":17180889832,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065791720,"f":1},"n":"IsFaulted","d":1020648,"h":25770824424,"f":1}],"m":[{"r":1151720,"p":[{"n":"exception","p":47185921,"f":65}],"n":"TryComplete","d":1020648,"h":34360759016,"f":1},{"r":1151720,"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"AddCallback","d":1020648,"h":38655726312,"f":1},{"r":262145,"n":"IsCompletedOrThrow","d":1020648,"h":42950693608,"f":1},{"r":1151720,"n":"GetCallbacks","d":1020648,"h":47245660904,"f":2},{"r":65537,"n":"Reset","d":1020648,"h":51540628200,"f":1},{"r":1310721,"n":"ToString","d":1020648,"h":55835595496,"f":32769}],"l":[{"t":131073,"n":"s_completedSuccessfully","d":1020648,"h":4295987944,"f":34},{"t":131073,"n":"_state","d":1020648,"h":8590955240,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$sipl.System.IO.Pipelines.PipeCompletionCallback).$h,"n":"_callbacks","d":1020648,"h":12885922536,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1020648,"h":60130562792,"f":1}],"h":1020648,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"IsCompleted = {IsCompleted}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletion`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.InlineScheduler", ($self) => class InlineScheduler extends $.$sipl.System.IO.Pipelines.PipeScheduler
        {
            /*void */ Schedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                action.Invoke(state);
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                action.Invoke(state);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 561896;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1544936,"m":[{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":561896,"h":4295529192,"f":32769},{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":561896,"h":8590496488,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":561896,"h":12885463784,"f":1}],"h":561896}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeScheduler; }
            static get $fullName() { return `System.IO.Pipelines.InlineScheduler`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.FlushResult", ($self) => class FlushResult extends $.$spc.System.ValueType
        {
            /*ResultFlags*/  get _resultFlags() { return this.$getField(0, $.$sipl.System.IO.Pipelines.ResultFlags); }
            /*ResultFlags*/  set _resultFlags(value) { this.$setField(0, $.$sipl.System.IO.Pipelines.ResultFlags, value); }
            $ctor$2(/*bool*/ isCanceled, /*bool*/ isCompleted)
            {
                super.$ctor$1();
                {
                    this._resultFlags = 0/*ResultFlags.None*/;
                    if (isCanceled)
                    {
                        this._resultFlags |= 1/*ResultFlags.Canceled*/;
                    }
                    if (isCompleted)
                    {
                        this._resultFlags |= 2/*ResultFlags.Completed*/;
                    }
                }
                return this;
            }
            /*bool */ get IsCanceled()
            {
                return (this._resultFlags & 1/*ResultFlags.Canceled*/) !== 0;
            }
            /*bool */ get IsCompleted()
            {
                return (this._resultFlags & 2/*ResultFlags.Completed*/) !== 0;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resultFlags = this._resultFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resultFlags = 0;
            }
            static $h = 430824;
            static $z = 1;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180300008,"f":1},"n":"IsCanceled","d":430824,"h":12885332712,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770234600,"f":1},"n":"IsCompleted","d":430824,"h":21475267304,"f":1}],"l":[{"t":1807080,"n":"_resultFlags","d":430824,"h":4295398120,"f":8}],"c":[{"p":[{"n":"isCanceled","p":262145},{"n":"isCompleted","p":262145}],"n":".ctor","o":"$ctor$2","d":430824,"h":8590365416,"f":1},{"n":".ctor","o":"$ctor$3","d":430824,"h":30065201896,"f":1}],"h":430824}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.FlushResult`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.CompletionData", ($self) => class CompletionData extends $.$spc.System.ValueType
        {
            /*Action<object?>*/ Completion = null;
            /*object?*/ CompletionState = null;
            /*ExecutionContext?*/ ExecutionContext = null;
            /*SynchronizationContext?*/ SynchronizationContext = null;
            $ctor$2(/*Action<object?>*/ completion, /*object?*/ completionState, /*ExecutionContext?*/ executionContext, /*SynchronizationContext?*/ synchronizationContext)
            {
                super.$ctor$1();
                {
                    this.Completion = completion;
                    this.CompletionState = completionState;
                    this.ExecutionContext = executionContext;
                    this.SynchronizationContext = synchronizationContext;
                }
                return this;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Completion = this.Completion;
                copy.CompletionState = this.CompletionState;
                copy.ExecutionContext = this.ExecutionContext;
                copy.SynchronizationContext = this.SynchronizationContext;
                return copy;
            }
            static $h = 299752;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.Action$$($.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":12885201640,"f":1},"n":"Completion","d":299752,"h":8590234344,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":25770103528,"f":1},"n":"CompletionState","d":299752,"h":21475136232,"f":1},{"p":126943233,"g":{"r":0,"d":0,"h":38655005416,"f":1},"n":"ExecutionContext","d":299752,"h":34360038120,"f":1},{"p":131137537,"g":{"r":0,"d":0,"h":51539907304,"f":1},"n":"SynchronizationContext","d":299752,"h":47244940008,"f":1}],"c":[{"p":[{"n":"completion","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"completionState","p":131073},{"n":"executionContext","p":126943233},{"n":"synchronizationContext","p":131137537}],"n":".ctor","o":"$ctor$2","d":299752,"h":55834874600,"f":1},{"n":".ctor","o":"$ctor$3","d":299752,"h":60129841896,"f":1}],"h":299752}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.CompletionData`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeAwaitable", ($self) => class PipeAwaitable extends $.$spc.System.ValueType
        {
            /*AwaitableState*/  get _awaitableState() { return this.$getField(0, 4); }
            /*AwaitableState*/  set _awaitableState(value) { this.$setField(0, 4, value); }
            /*Action<object?>?*/  get _completion() { return this.$getField(4, 4); }
            /*Action<object?>?*/  set _completion(value) { this.$setField(4, 4, value); }
            /*object?*/  get _completionState() { return this.$getField(8, 4); }
            /*object?*/  set _completionState(value) { this.$setField(8, 4, value); }
            /*SchedulingContext?*/  get _schedulingContext() { return this.$getField(12, 4); }
            /*SchedulingContext?*/  set _schedulingContext(value) { this.$setField(12, 4, value); }
            /*CancellationTokenRegistration*/  get _cancellationTokenRegistration() { return this.$getField(16, 12); }
            /*CancellationTokenRegistration*/  set _cancellationTokenRegistration(value) { this.$setField(16, 12, value); }
            /*CancellationToken */ get CancellationToken()
            {
                return this._cancellationTokenRegistration.Token;
            }
            $ctor$2(/*bool*/ completed, /*bool*/ useSynchronizationContext)
            {
                super.$ctor$1();
                {
                    this._awaitableState = (completed ? 1/*AwaitableState.Completed*/ : 0/*AwaitableState.None*/) | (useSynchronizationContext ? 8/*AwaitableState.UseSynchronizationContext*/ : 0/*AwaitableState.None*/);
                    this._completion = null;
                    this._completionState = null;
                    this._cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                    this._schedulingContext = null;
                }
                return this;
            }
            /*bool */ get IsCompleted()
            {
                return (this._awaitableState & (1/*AwaitableState.Completed*/ | 4/*AwaitableState.Canceled*/)) !== 0;
            }
            /*bool */ get IsRunning()
            {
                return (this._awaitableState & 2/*AwaitableState.Running*/) !== 0;
            }
            /*void */ BeginOperation(/*CancellationToken*/ cancellationToken, /*Action<object?>*/ callback, /*object?*/ state)
            {
                if (cancellationToken.CanBeCanceled && !this.IsCompleted)
                {
                    /*var*/ let previousAwaitableState = this._awaitableState;
                    this._cancellationTokenRegistration = cancellationToken.UnsafeRegister(callback, state);
                    if ($.$spc.System.Threading.CancellationTokenRegistration.op_Equality(this._cancellationTokenRegistration, $.$default($.$spc.System.Threading.CancellationTokenRegistration)))
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(previousAwaitableState === this._awaitableState, "The awaitable state changed!");
                        cancellationToken.ThrowIfCancellationRequested();
                    }
                }
                this._awaitableState |= 2/*AwaitableState.Running*/;
            }
            /*void */ Complete(/*out CompletionData*/ completionData)
            {
                this.ExtractCompletion(completionData);
                this._awaitableState |= 1/*AwaitableState.Completed*/;
            }
            /*void */ ExtractCompletion(/*out CompletionData*/ completionData)
            {
                /*Action<object?>?*/ let currentCompletion = this._completion;
                /*object?*/ let currentState = this._completionState;
                /*SchedulingContext?*/ let schedulingContext = this._schedulingContext;
                /*ExecutionContext?*/ let executionContext = (schedulingContext?.ExecutionContext ?? null);
                /*SynchronizationContext?*/ let synchronizationContext = (schedulingContext?.SynchronizationContext ?? null);
                this._completion = null;
                this._completionState = null;
                this._schedulingContext = null;
                completionData.$v = currentCompletion !== null ? new $.$sipl.System.IO.Pipelines.CompletionData().$ctor$2(currentCompletion, currentState, executionContext, synchronizationContext) : new $.$sipl.System.IO.Pipelines.CompletionData();
            }
            /*void */ SetUncompleted()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._completion === null, "_completion == null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._completionState === null, "_completionState == null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._schedulingContext === null, "_schedulingContext == null");
                this._awaitableState &= ~1/*AwaitableState.Completed*/;
            }
            /*void */ OnCompleted(/*Action<object?>*/ continuation, /*object?*/ state, /*ValueTaskSourceOnCompletedFlags*/ flags, /*out CompletionData*/ completionData, /*out bool*/ doubleCompletion)
            {
                completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                doubleCompletion.$v = !(this._completion === null);
                if (this.IsCompleted || doubleCompletion.$v)
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData().$ctor$2(continuation, state, (this._schedulingContext?.ExecutionContext ?? null), (this._schedulingContext?.SynchronizationContext ?? null));
                    return;
                }
                this._completion = continuation;
                this._completionState = state;
                if ((this._awaitableState & 8/*AwaitableState.UseSynchronizationContext*/) !== 0 && (flags & 1/*ValueTaskSourceOnCompletedFlags.UseSchedulingContext*/) !== 0)
                {
                    /*SynchronizationContext?*/ let sc = $.$spc.System.Threading.SynchronizationContext.Current;
                    if (sc !== null && $.$spc.System.Type.op_Inequality$1($.$spc.System.Object.GetType.call(sc), $.$spc.System.Threading.SynchronizationContext.$type))
                    {
                        this._schedulingContext ??= new $.$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext().$ctor$1();
                        this._schedulingContext.SynchronizationContext = sc;
                    }
                }
                if ((flags & 2/*ValueTaskSourceOnCompletedFlags.FlowExecutionContext*/) !== 0)
                {
                    this._schedulingContext ??= new $.$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext().$ctor$1();
                    this._schedulingContext.ExecutionContext = $.$spc.System.Threading.ExecutionContext.Capture();
                }
            }
            /*void */ Cancel(/*out CompletionData*/ completionData)
            {
                this.ExtractCompletion(completionData);
                this._awaitableState |= 4/*AwaitableState.Canceled*/;
            }
            /*void */ CancellationTokenFired(/*out CompletionData*/ completionData)
            {
                if (this.CancellationToken.IsCancellationRequested)
                {
                    this.Cancel(completionData);
                }
                else 
                {
                    completionData.$v = new $.$sipl.System.IO.Pipelines.CompletionData();
                }
            }
            /*bool */ ObserveCancellation()
            {
                /*bool*/ let isCanceled = (this._awaitableState & 4/*AwaitableState.Canceled*/) === 4/*AwaitableState.Canceled*/;
                this._awaitableState &= ~(4/*AwaitableState.Canceled*/ | 2/*AwaitableState.Running*/);
                return isCanceled;
            }
            /*CancellationTokenRegistration */ ReleaseCancellationTokenRegistration(/*out CancellationToken*/ cancellationToken)
            {
                cancellationToken.$v = this.CancellationToken;
                /*CancellationTokenRegistration*/ let cancellationTokenRegistration = this._cancellationTokenRegistration;
                this._cancellationTokenRegistration = new $.$spc.System.Threading.CancellationTokenRegistration();
                return cancellationTokenRegistration;
            }
            static $_AwaitableState;
            static get AwaitableState()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeAwaitable;
                return $cls.$_AwaitableState ??= $asm.$nstr("$sipl.System.IO.Pipelines.PipeAwaitable.AwaitableState", ($self) => class AwaitableState extends $.$spc.System.Enum
                {
                    static None = 0;
                    static Completed = 1;
                    static Running = 2;
                    static Canceled = 4;
                    static UseSynchronizationContext = 8;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "Completed": 1n,
                            "Running": 2n,
                            "Canceled": 4n,
                            "UseSynchronizationContext": 8n
                        };
                    }
                    static $h = 889576;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":889576,"n":"None","d":889576,"h":4295856872,"f":33},{"t":889576,"n":"Completed","d":889576,"h":8590824168,"f":33},{"t":889576,"n":"Running","d":889576,"h":12885791464,"f":33},{"t":889576,"n":"Canceled","d":889576,"h":17180758760,"f":33},{"t":889576,"n":"UseSynchronizationContext","d":889576,"h":21475726056,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":889576,"h":25770693352,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":824040,"h":889576,"a":[{"t":47644673,"c":4342611969}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Pipelines.PipeAwaitable.AwaitableState`; }
                }, $cls, ($v) => $cls.$_AwaitableState = $v);
            }
            static $_SchedulingContext;
            static get SchedulingContext()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeAwaitable;
                return $cls.$_SchedulingContext ??= $asm.$ncls("$sipl.System.IO.Pipelines.PipeAwaitable.SchedulingContext", ($self) => class SchedulingContext extends $.$spc.System.Object
                {
                    /*SynchronizationContext?*/ SynchronizationContext = null;
                    /*ExecutionContext?*/ ExecutionContext = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 955112;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131137537,"g":{"r":0,"d":0,"h":12885857000,"f":1},"s":{"r":0,"d":0,"h":17180824296,"f":1},"n":"SynchronizationContext","d":955112,"h":8590889704,"f":1},{"p":126943233,"g":{"r":0,"d":0,"h":30065726184,"f":1},"s":{"r":0,"d":0,"h":34360693480,"f":1},"n":"ExecutionContext","d":955112,"h":25770758888,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":955112,"h":38655660776,"f":1}],"d":824040,"h":955112}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.IO.Pipelines.PipeAwaitable.SchedulingContext`; }
                }, $cls, ($v) => $cls.$_SchedulingContext = $v);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._awaitableState = this._awaitableState;
                copy._completion = this._completion;
                copy._completionState = this._completionState;
                copy._schedulingContext = this._schedulingContext;
                copy._cancellationTokenRegistration = this._cancellationTokenRegistration.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._awaitableState = 0;
                this._completion = null;
                this._completionState = null;
                this._schedulingContext = null;
                this._cancellationTokenRegistration = $.$default($.$spc.System.Threading.CancellationTokenRegistration);
            }
            static $h = 824040;
            static $z = 28;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":125960193,"g":{"r":0,"d":0,"h":30065595112,"f":2},"n":"CancellationToken","d":824040,"h":25770627816,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":42950497000,"f":1},"n":"IsCompleted","d":824040,"h":38655529704,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540431592,"f":1},"n":"IsRunning","d":824040,"h":47245464296,"f":1}],"m":[{"r":65537,"p":[{"n":"cancellationToken","p":125960193},{"n":"callback","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"BeginOperation","d":824040,"h":55835398888,"f":1},{"r":65537,"p":[{"n":"completionData","p":299752,"f":2}],"n":"Complete","d":824040,"h":60130366184,"f":1},{"r":65537,"p":[{"n":"completionData","p":299752,"f":2}],"n":"ExtractCompletion","d":824040,"h":64425333480,"f":2},{"r":65537,"n":"SetUncompleted","d":824040,"h":68720300776,"f":1},{"r":65537,"p":[{"n":"continuation","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073},{"n":"flags","p":132972545},{"n":"completionData","p":299752,"f":2},{"n":"doubleCompletion","p":262145,"f":2}],"n":"OnCompleted","d":824040,"h":73015268072,"f":1},{"r":65537,"p":[{"n":"completionData","p":299752,"f":2}],"n":"Cancel","d":824040,"h":77310235368,"f":1},{"r":65537,"p":[{"n":"completionData","p":299752,"f":2}],"n":"CancellationTokenFired","d":824040,"h":81605202664,"f":1},{"r":262145,"n":"ObserveCancellation","d":824040,"h":85900169960,"f":1},{"r":126025729,"p":[{"n":"cancellationToken","p":125960193,"f":2}],"n":"ReleaseCancellationTokenRegistration","d":824040,"h":90195137256,"f":1}],"l":[{"t":889576,"n":"_awaitableState","d":824040,"h":4295791336,"f":2},{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"_completion","d":824040,"h":8590758632,"f":2},{"t":131073,"n":"_completionState","d":824040,"h":12885725928,"f":2},{"t":955112,"n":"_schedulingContext","d":824040,"h":17180693224,"f":2},{"t":126025729,"n":"_cancellationTokenRegistration","d":824040,"h":21475660520,"f":2}],"c":[{"p":[{"n":"completed","p":262145},{"n":"useSynchronizationContext","p":262145}],"n":".ctor","o":"$ctor$2","d":824040,"h":34360562408,"f":1},{"n":".ctor","o":"$ctor$3","d":824040,"h":103080039144,"f":1}],"j":[889576,955112],"h":824040,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"CanceledState = {_awaitableState}, IsCompleted = {IsCompleted}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeAwaitable`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeCompletionCallback", ($self) => class PipeCompletionCallback extends $.$spc.System.ValueType
        {
            /*Action<Exception?, object?>*/  get Callback() { return this.$getField(0, 4); }
            /*Action<Exception?, object?>*/  set Callback(value) { this.$setField(0, 4, value); }
            /*object?*/  get State() { return this.$getField(4, 4); }
            /*object?*/  set State(value) { this.$setField(4, 4, value); }
            $ctor$2(/*Action<Exception?, object?>*/ callback, /*object?*/ state)
            {
                super.$ctor$1();
                {
                    this.Callback = callback;
                    this.State = state;
                }
                return this;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Callback = this.Callback;
                copy.State = this.State;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Callback = null;
                this.State = null;
            }
            static $h = 1086184;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h,"n":"Callback","d":1086184,"h":4296053480,"f":1},{"t":131073,"n":"State","d":1086184,"h":8591020776,"f":1}],"c":[{"p":[{"n":"callback","p":$.$spc.System.Action$$$($.$spc.System.Exception, $.$spc.System.Object).$h},{"n":"state","p":131073}],"n":".ctor","o":"$ctor$2","d":1086184,"h":12885988072,"f":1},{"n":".ctor","o":"$ctor$3","d":1086184,"h":17180955368,"f":1}],"h":1086184}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeCompletionCallback`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.PipeOperationState", ($self) => class PipeOperationState extends $.$spc.System.ValueType
        {
            /*State*/  get _state() { return this.$getField(0, $.$sipl.System.IO.Pipelines.PipeOperationState.State); }
            /*State*/  set _state(value) { this.$setField(0, $.$sipl.System.IO.Pipelines.PipeOperationState.State, value); }
            /*void */ BeginRead()
            {
                if ((this._state & 1/*State.Reading*/) === 1/*State.Reading*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                }
                this._state |= 1/*State.Reading*/;
            }
            /*void */ BeginReadTentative()
            {
                if ((this._state & 1/*State.Reading*/) === 1/*State.Reading*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AlreadyReading();
                }
                this._state |= 2/*State.ReadingTentative*/;
            }
            /*void */ EndRead()
            {
                if ((this._state & 1/*State.Reading*/) !== 1/*State.Reading*/ && (this._state & 2/*State.ReadingTentative*/) !== 2/*State.ReadingTentative*/)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadToComplete();
                }
                this._state &= ~(1/*State.Reading*/ | 2/*State.ReadingTentative*/);
            }
            /*void */ BeginWrite()
            {
                this._state |= 4/*State.Writing*/;
            }
            /*void */ EndWrite()
            {
                this._state &= ~4/*State.Writing*/;
            }
            /*bool */ get IsWritingActive()
            {
                return (this._state & 4/*State.Writing*/) === 4/*State.Writing*/;
            }
            /*bool */ get IsReadingActive()
            {
                return (this._state & 1/*State.Reading*/) === 1/*State.Reading*/;
            }
            static $_State;
            static get State()
            {
                let $cls = $.$sipl.System.IO.Pipelines.PipeOperationState;
                return $cls.$_State ??= $asm.$nstr("$sipl.System.IO.Pipelines.PipeOperationState.State", ($self) => class State extends $.$spc.System.Enum
                {
                    static Reading = 1;
                    static ReadingTentative = 2;
                    static Writing = 4;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Reading": 1n,
                            "ReadingTentative": 2n,
                            "Writing": 4n
                        };
                    }
                    static $h = 1282792;
                    static $z = 1;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Byte; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":1282792,"n":"Reading","d":1282792,"h":4296250088,"f":33},{"t":1282792,"n":"ReadingTentative","d":1282792,"h":8591217384,"f":33},{"t":1282792,"n":"Writing","d":1282792,"h":12886184680,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1282792,"h":17181151976,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":1217256,"h":1282792,"a":[{"t":47644673,"c":4342611969}]}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.IO.Pipelines.PipeOperationState.State`; }
                }, $cls, ($v) => $cls.$_State = $v);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._state = this._state;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._state = 0;
            }
            static $h = 1217256;
            static $z = 1;
            static $f = 0b10000000000001010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360955624,"f":1},"n":"IsWritingActive","d":1217256,"h":30065988328,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950890216,"f":1},"n":"IsReadingActive","d":1217256,"h":38655922920,"f":1}],"m":[{"r":65537,"n":"BeginRead","d":1217256,"h":8591151848,"f":1},{"r":65537,"n":"BeginReadTentative","d":1217256,"h":12886119144,"f":1},{"r":65537,"n":"EndRead","d":1217256,"h":17181086440,"f":1},{"r":65537,"n":"BeginWrite","d":1217256,"h":21476053736,"f":1},{"r":65537,"n":"EndWrite","d":1217256,"h":25771021032,"f":1}],"l":[{"t":1282792,"n":"_state","d":1217256,"h":4296184552,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1217256,"h":51540824808,"f":1}],"j":[1282792],"h":1217256,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"State = {_state}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.PipeOperationState`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ReadResult", ($self) => class ReadResult extends $.$spc.System.ValueType
        {
            /*ReadOnlySequence<byte>*/  get _resultBuffer() { return this.$getField(0, 16); }
            /*ReadOnlySequence<byte>*/  set _resultBuffer(value) { this.$setField(0, 16, value); }
            /*ResultFlags*/  get _resultFlags() { return this.$getField(16, 1); }
            /*ResultFlags*/  set _resultFlags(value) { this.$setField(16, 1, value); }
            $ctor$2(/*ReadOnlySequence<byte>*/ buffer, /*bool*/ isCanceled, /*bool*/ isCompleted)
            {
                super.$ctor$1();
                {
                    this._resultBuffer = buffer;
                    this._resultFlags = 0/*ResultFlags.None*/;
                    if (isCompleted)
                    {
                        this._resultFlags |= 2/*ResultFlags.Completed*/;
                    }
                    if (isCanceled)
                    {
                        this._resultFlags |= 1/*ResultFlags.Canceled*/;
                    }
                }
                return this;
            }
            /*ReadOnlySequence<byte> */ get Buffer()
            {
                return this._resultBuffer;
            }
            /*bool */ get IsCanceled()
            {
                return (this._resultFlags & 1/*ResultFlags.Canceled*/) !== 0;
            }
            /*bool */ get IsCompleted()
            {
                return (this._resultFlags & 2/*ResultFlags.Completed*/) !== 0;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._resultBuffer = this._resultBuffer.Clone();
                copy._resultFlags = this._resultFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._resultBuffer = $.$default($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte));
                this._resultFlags = 0;
            }
            static $h = 1741544;
            static $z = 17;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":21476578024,"f":1},"n":"Buffer","d":1741544,"h":17181610728,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30066512616,"f":1},"n":"IsCanceled","d":1741544,"h":25771545320,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38656447208,"f":1},"n":"IsCompleted","d":1741544,"h":34361479912,"f":1}],"l":[{"t":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"n":"_resultBuffer","d":1741544,"h":4296708840,"f":8},{"t":1807080,"n":"_resultFlags","d":1741544,"h":8591676136,"f":8}],"c":[{"p":[{"n":"buffer","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h},{"n":"isCanceled","p":262145},{"n":"isCompleted","p":262145}],"n":".ctor","o":"$ctor$2","d":1741544,"h":12886643432,"f":1},{"n":".ctor","o":"$ctor$3","d":1741544,"h":42951414504,"f":1}],"h":1741544}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.IO.Pipelines.ReadResult`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.SequencePipeReader", ($self) => class SequencePipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
        {
            /*ReadOnlySequence<byte>*/ _sequence;
            /*bool*/ _isReaderCompleted = false;
            /*int*/ _cancelNext = 0;
            $ctor$2(/*ReadOnlySequence<byte>*/ sequence)
            {
                super.$ctor$1();
                {
                    this._sequence = sequence;
                }
                return this;
            }
            /*void */ AdvanceTo(/*SequencePosition*/ consumed)
            {
                this.AdvanceTo$1(consumed, consumed);
            }
            /*void */ AdvanceTo$1(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
            {
                this.ThrowIfCompleted();
                if (consumed.Equals$2(this._sequence.End))
                {
                    this._sequence = $.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).Empty;
                    return;
                }
                this._sequence = this._sequence.Slice$7(consumed);
            }
            /*void */ CancelPendingRead()
            {
                $.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._cancelNext, ($v) => this._cancelNext = $v, $.$spc.System.Int32), 1);
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this._isReaderCompleted)
                {
                    return;
                }
                this._isReaderCompleted = true;
                this._sequence = $.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).Empty;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                /*ReadResult*/ let result;
                if (this.TryRead($.$ref(() => result, ($v) => result = $v, $.$sipl.System.IO.Pipelines.ReadResult)))
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(result);
                }
                result = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).Empty, false, true);
                return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(result);
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                this.ThrowIfCompleted();
                /*bool*/ let isCancellationRequested = $.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._cancelNext, ($v) => this._cancelNext = $v, $.$spc.System.Int32), 0) === 1;
                if (isCancellationRequested || this._sequence.Length > 0n)
                {
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(this._sequence, isCancellationRequested, true);
                    return true;
                }
                result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                return false;
            }
            /*void */ ThrowIfCompleted()
            {
                if (this._isReaderCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._sequence = $.$default($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte));
            }
            static $h = 1872616;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1413864,"m":[{"r":65537,"p":[{"n":"consumed","p":1222797}],"n":"AdvanceTo","d":1872616,"h":21476709096,"f":32769},{"r":65537,"p":[{"n":"consumed","p":1222797},{"n":"examined","p":1222797}],"n":"AdvanceTo","o":"@$1","d":1872616,"h":25771676392,"f":32769},{"r":65537,"n":"CancelPendingRead","d":1872616,"h":30066643688,"f":32769},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":1872616,"h":34361610984,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":1872616,"h":38656578280,"f":32769},{"r":262145,"p":[{"n":"result","p":1741544,"f":2}],"n":"TryRead","d":1872616,"h":42951545576,"f":32769},{"r":65537,"n":"ThrowIfCompleted","d":1872616,"h":47246512872,"f":2}],"l":[{"t":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"n":"_sequence","d":1872616,"h":4296839912,"f":2},{"t":262145,"n":"_isReaderCompleted","d":1872616,"h":8591807208,"f":2},{"t":655361,"n":"_cancelNext","d":1872616,"h":12886774504,"f":2}],"c":[{"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h}],"n":".ctor","o":"$ctor$2","d":1872616,"h":17181741800,"f":1}],"h":1872616}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
            static get $fullName() { return `System.IO.Pipelines.SequencePipeReader`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeReader", ($self) => class StreamPipeReader extends $.$sipl.System.IO.Pipelines.PipeReader
        {
            /*int*/ static InitialSegmentPoolSize = 4;
            /*int*/ static MaxSegmentPoolSize = 256;
            /*CancellationTokenSource?*/ _internalTokenSource = null;
            /*bool*/ _isReaderCompleted = false;
            /*BufferSegment?*/ _readHead = null;
            /*int*/ _readIndex = 0;
            /*BufferSegment?*/ _readTail = null;
            /*long*/ _bufferedBytes = 0n;
            /*bool*/ _examinedEverything = false;
            /*object*/ _lock = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*StreamPipeReaderOptions*/ _options = null;
            $ctor$2(/*Stream*/ readingStream, /*StreamPipeReaderOptions*/ options)
            {
                super.$ctor$1();
                {
                    if (readingStream === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(10/*ExceptionArgument.readingStream*/);
                    }
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this.InnerStream = readingStream;
                    this._options = options;
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$2(4/*InitialSegmentPoolSize*/);
                }
                return this;
            }
            /*bool */ get LeaveOpen()
            {
                return this._options.LeaveOpen;
            }
            /*bool */ get UseZeroByteReads()
            {
                return this._options.UseZeroByteReads;
            }
            /*int */ get BufferSize()
            {
                return this._options.BufferSize;
            }
            /*int */ get MaxBufferSize()
            {
                return this._options.MaxBufferSize;
            }
            /*int */ get MinimumReadThreshold()
            {
                return this._options.MinimumReadSize;
            }
            /*MemoryPool<byte> */ get Pool()
            {
                return this._options.Pool;
            }
            /*Stream*/ InnerStream = null;
            /*void */ AdvanceTo(/*SequencePosition*/ consumed)
            {
                this.AdvanceTo$1(consumed, consumed);
            }
            /*CancellationTokenSource */ get InternalTokenSource()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        return this._internalTokenSource ??= new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
            }
            /*void */ AdvanceTo$1(/*SequencePosition*/ consumed, /*SequencePosition*/ examined)
            {
                this.ThrowIfCompleted();
                this.AdvanceTo$2($.$cast(consumed.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), consumed.GetInteger(), $.$cast(examined.GetObject(), $.$sipl.System.IO.Pipelines.BufferSegment), examined.GetInteger());
            }
            /*void */ AdvanceTo$2(/*BufferSegment?*/ consumedSegment, /*int*/ consumedIndex, /*BufferSegment?*/ examinedSegment, /*int*/ examinedIndex)
            {
                if (consumedSegment === null || examinedSegment === null)
                {
                    return;
                }
                if (this._readHead === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_AdvanceToInvalidCursor();
                }
                /*BufferSegment*/ let returnStart = this._readHead;
                /*BufferSegment?*/ let returnEnd = consumedSegment;
                /*long*/ let consumedBytes = $.$sipl.System.IO.Pipelines.BufferSegment.GetLength(returnStart, this._readIndex, consumedSegment, consumedIndex);
                this._bufferedBytes -= consumedBytes;
                $.$spc.System.Diagnostics.Debug.Assert$1(this._bufferedBytes >= 0n, "_bufferedBytes >= 0");
                this._examinedEverything = false;
                if (examinedSegment === this._readTail)
                {
                    this._examinedEverything = examinedIndex === this._readTail.End;
                }
                if (this._bufferedBytes === 0n)
                {
                    returnEnd = null;
                    this._readHead = null;
                    this._readTail = null;
                    this._readIndex = 0;
                }
                else if (consumedIndex === returnEnd.Length)
                {
                    /*BufferSegment?*/ let nextBlock = returnEnd.NextSegment;
                    this._readHead = nextBlock;
                    this._readIndex = 0;
                    returnEnd = nextBlock;
                }
                else 
                {
                    this._readHead = consumedSegment;
                    this._readIndex = consumedIndex;
                }
                while(returnStart !== returnEnd)
                {
                    /*BufferSegment*/ let next = returnStart.NextSegment;
                    this.ReturnSegmentUnsynchronized(returnStart);
                    returnStart = next;
                }
            }
            /*void */ CancelPendingRead()
            {
                this.InternalTokenSource.Cancel();
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this.CompleteAndGetNeedsDispose())
                {
                    this.InnerStream.Dispose();
                }
            }
            /*ValueTask */ CompleteAsync(/*Exception?*/ exception)
            {
                return this.CompleteAndGetNeedsDispose() ? this.InnerStream.DisposeAsync() : new $.$spc.System.Threading.Tasks.ValueTask();
            }
            /*bool */ CompleteAndGetNeedsDispose()
            {
                if (this._isReaderCompleted)
                {
                    return false;
                }
                this._isReaderCompleted = true;
                /*BufferSegment?*/ let segment = this._readHead;
                while(segment !== null)
                {
                    /*BufferSegment*/ let returnSegment = segment;
                    segment = segment.NextSegment;
                    returnSegment.Reset();
                }
                return !this.LeaveOpen;
            }
            /*ValueTask<ReadResult> */ ReadAsync(/*CancellationToken*/ cancellationToken)
            {
                return this.ReadInternalAsync(null, cancellationToken);
            }
            /*ValueTask<ReadResult> */ ReadAtLeastAsyncCore(/*int*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadInternalAsync(minimumSize, cancellationToken);
            }
            /*ValueTask<ReadResult> */ ReadInternalAsync(/*int?*/ minimumSize, /*CancellationToken*/ cancellationToken)
            {
                this.ThrowIfCompleted();
                if (cancellationToken.IsCancellationRequested)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$3($.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$sipl.System.IO.Pipelines.ReadResult, cancellationToken));
                }
                /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                /*ReadResult*/ let readResult;
                if (this.TryReadInternal(tokenSource, $.$ref(() => readResult, ($v) => readResult = $v, $.$sipl.System.IO.Pipelines.ReadResult)))
                {
                    if (minimumSize === null || readResult.Buffer.Length >= minimumSize || readResult.IsCompleted || readResult.IsCanceled)
                    {
                        return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult))().$ctor$2(readResult);
                    }
                }
                return Core(this, minimumSize, tokenSource, cancellationToken);
                /*static ValueTask<ReadResult>*/ /*async*/  function Core(/*StreamPipeReader*/ reader, /*int?*/ minimumSize, /*CancellationTokenSource*/ tokenSource, /*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult), $.$sipl.System.IO.Pipelines.ReadResult, async () => 
                    {
                        /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                        if (cancellationToken.CanBeCanceled)
                        {
                            reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                            {
                                return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                            }), reader);
                        }
                        let $disposable2 = null;
                        try
                        {
                            $disposable2 = reg;
                            /*var*/ let isCanceled = false;
                            /*bool*/ let isCompleted = false;
                            try
                            {
                                if (reader.UseZeroByteReads && reader._bufferedBytes === 0n)
                                {
                                    await reader.InnerStream.ReadAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).Empty, tokenSource.Token).ConfigureAwait(false);
                                }
                                do
                                {
                                    reader.AllocateReadTail(minimumSize);
                                    /*Memory<byte>*/ let buffer = reader._readTail.AvailableMemory.Slice(reader._readTail.End);
                                    /*int*/ let length = await reader.InnerStream.ReadAsync$2(buffer, tokenSource.Token).ConfigureAwait(false);
                                    $.$spc.System.Diagnostics.Debug.Assert$1(((length + reader._readTail.End) | 0) <= reader._readTail.AvailableMemory.Length, "length + reader._readTail.End <= reader._readTail.AvailableMemory.Length");
                                    reader._readTail.End += length;
                                    reader._bufferedBytes += BigInt(length);
                                    if (length === 0)
                                    {
                                        isCompleted = true;
                                        break;
                                    }
                                }
                                while(minimumSize !== null && reader._bufferedBytes < minimumSize);
                            }
                            catch(ex)
                            {
                                reader.ClearCancellationToken();
                                if (cancellationToken.IsCancellationRequested)
                                {
                                    throw new $.$spc.System.OperationCanceledException().$ctor$14(ex.Message, ex, cancellationToken);
                                }
                                else if (tokenSource.IsCancellationRequested)
                                {
                                    isCanceled = true;
                                }
                                else 
                                {
                                    throw ex;
                                }
                            }
                            return new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(reader.GetCurrentReadOnlySequence(), isCanceled, isCompleted);
                        }
                        finally
                        {
                            $disposable2?.System$IDisposable$Dispose();
                        }
                    });
                }
            }
            /*Task *//*async*/  CopyToAsync(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.ThrowIfCompleted();
                    /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                    if (tokenSource.IsCancellationRequested)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                    }
                    /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                        }), this);
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._readHead;
                            /*int*/ let segmentIndex = this._readIndex;
                            try
                            {
                                while(segment !== null)
                                {
                                    /*FlushResult*/ let flushResult = await destination.WriteAsync(segment.Memory.Slice(segmentIndex), tokenSource.Token).ConfigureAwait(false);
                                    if (flushResult.IsCanceled)
                                    {
                                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                                    }
                                    segment = segment.NextSegment;
                                    segmentIndex = 0;
                                    if (flushResult.IsCompleted)
                                    {
                                        return;
                                    }
                                }
                            }
                            finally
                            {
                                {
                                    if (segment !== null)
                                    {
                                        this.AdvanceTo$2(segment, segment.End, segment, segment.End);
                                    }
                                }
                            }
                            await $.$sipl.System.IO.Pipelines.StreamPipeExtensions.CopyToAsync(this.InnerStream, destination, tokenSource.Token).ConfigureAwait(false);
                        }
                        catch($e)
                        {
                            this.ClearCancellationToken();
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*Task *//*async*/  CopyToAsync$1(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    this.ThrowIfCompleted();
                    /*CancellationTokenSource*/ let tokenSource = this.InternalTokenSource;
                    if (tokenSource.IsCancellationRequested)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                    }
                    /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/**/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeReader)).Cancel();
                        }), this);
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._readHead;
                            /*int*/ let segmentIndex = this._readIndex;
                            try
                            {
                                while(segment !== null)
                                {
                                    await destination.WriteAsync$2(segment.Memory.Slice(segmentIndex), tokenSource.Token).ConfigureAwait(false);
                                    segment = segment.NextSegment;
                                    segmentIndex = 0;
                                }
                            }
                            finally
                            {
                                {
                                    if (segment !== null)
                                    {
                                        this.AdvanceTo$2(segment, segment.End, segment, segment.End);
                                    }
                                }
                            }
                            await this.InnerStream.CopyToAsync$2(destination, tokenSource.Token).ConfigureAwait(false);
                        }
                        catch($e)
                        {
                            this.ClearCancellationToken();
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*void */ ClearCancellationToken()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lock)
                    {
                        this._internalTokenSource = null;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lock)
                }
            }
            /*void */ ThrowIfCompleted()
            {
                if (this._isReaderCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoReadingAllowed();
                }
            }
            /*bool */ TryRead(/*out ReadResult*/ result)
            {
                this.ThrowIfCompleted();
                return this.TryReadInternal(this.InternalTokenSource, result);
            }
            /*bool */ TryReadInternal(/*CancellationTokenSource*/ source, /*out ReadResult*/ result)
            {
                /*bool*/ let isCancellationRequested = source.IsCancellationRequested;
                if (isCancellationRequested || (this._bufferedBytes > 0n && !this._examinedEverything))
                {
                    if (isCancellationRequested)
                    {
                        this.ClearCancellationToken();
                    }
                    /*ReadOnlySequence<byte>*/ let buffer = this.GetCurrentReadOnlySequence();
                    result.$v = new $.$sipl.System.IO.Pipelines.ReadResult().$ctor$2(buffer, isCancellationRequested, false);
                    return true;
                }
                result.$v = new $.$sipl.System.IO.Pipelines.ReadResult();
                return false;
            }
            /*ReadOnlySequence<byte> */ GetCurrentReadOnlySequence()
            {
                return this._readHead === null ? new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))() : new ($.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte))().$ctor$3(this._readHead, this._readIndex, this._readTail, this._readTail.End);
            }
            /*void */ AllocateReadTail(/*int?*/ minimumSize)
            {
                if (this._readHead === null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readTail === null, "_readTail == null");
                    this._readHead = this.AllocateSegment(minimumSize);
                    this._readTail = this._readHead;
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._readTail !== null, "_readTail != null");
                    if (this._readTail.WritableBytes < this.MinimumReadThreshold)
                    {
                        /*BufferSegment*/ let nextSegment = this.AllocateSegment(minimumSize);
                        this._readTail.SetNext(nextSegment);
                        this._readTail = nextSegment;
                    }
                }
            }
            /*BufferSegment */ AllocateSegment(/*int?*/ minimumSize)
            {
                /*BufferSegment*/ let nextSegment = this.CreateSegmentUnsynchronized();
                /*var*/ let bufferSize = minimumSize ?? this.BufferSize;
                /*int*/ let maxSize = !this._options.IsDefaultSharedMemoryPool ? this._options.Pool.MaxBufferSize : -1;
                if (bufferSize <= maxSize)
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(bufferSize, maxSize);
                    nextSegment.SetOwnedMemory(this._options.Pool.Rent(sizeToRequest));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(bufferSize, this.MaxBufferSize);
                    nextSegment.SetOwnedMemory$1($.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(sizeToRequest));
                }
                return nextSegment;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$spc.System.Math.Max$4(this.BufferSize, sizeHint);
                /*int*/ let adjustedToMaximumSize = $.$spc.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readHead, "Returning _readHead segment that's in use!");
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== this._readTail, "Returning _readTail segment that's in use!");
                segment.Reset();
                if (this._bufferSegmentPool.Count < 256/*MaxSegmentPoolSize*/)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*void */ Cancel()
            {
                this.InternalTokenSource.Cancel();
            }
            //default member initializer
            constructor()
            {
                super();
                this._lock = new $.$spc.System.Object().$ctor();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
            }
            static $h = 2003688;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1413864,"p":[{"p":262145,"g":{"r":0,"d":0,"h":64426513128,"f":2},"n":"LeaveOpen","d":2003688,"h":60131545832,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":73016447720,"f":2},"n":"UseZeroByteReads","d":2003688,"h":68721480424,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":81606382312,"f":2},"n":"BufferSize","d":2003688,"h":77311415016,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":90196316904,"f":2},"n":"MaxBufferSize","d":2003688,"h":85901349608,"f":2},{"p":655361,"g":{"r":0,"d":0,"h":98786251496,"f":2},"n":"MinimumReadThreshold","d":2003688,"h":94491284200,"f":2},{"p":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":107376186088,"f":2},"n":"Pool","d":2003688,"h":103081218792,"f":2},{"p":62128129,"g":{"r":0,"d":0,"h":120261087976,"f":1},"n":"InnerStream","d":2003688,"h":115966120680,"f":1},{"p":126091265,"g":{"r":0,"d":0,"h":133145989864,"f":2},"n":"InternalTokenSource","d":2003688,"h":128851022568,"f":2}],"m":[{"r":65537,"p":[{"n":"consumed","p":1222797}],"n":"AdvanceTo","d":2003688,"h":124556055272,"f":32769},{"r":65537,"p":[{"n":"consumed","p":1222797},{"n":"examined","p":1222797}],"n":"AdvanceTo","o":"@$1","d":2003688,"h":137440957160,"f":32769},{"r":65537,"p":[{"n":"consumedSegment","p":103144},{"n":"consumedIndex","p":655361},{"n":"examinedSegment","p":103144},{"n":"examinedIndex","p":655361}],"n":"AdvanceTo","o":"@$2","d":2003688,"h":141735924456,"f":2},{"r":65537,"n":"CancelPendingRead","d":2003688,"h":146030891752,"f":32769},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":2003688,"h":150325859048,"f":32769},{"r":136118273,"p":[{"n":"exception","p":47185921,"f":65}],"n":"CompleteAsync","d":2003688,"h":154620826344,"f":32769},{"r":262145,"n":"CompleteAndGetNeedsDispose","d":2003688,"h":158915793640,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","d":2003688,"h":163210760936,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAtLeastAsyncCore","d":2003688,"h":167505728232,"f":32772},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.ReadResult).$h,"p":[{"n":"minimumSize","p":$.$typeNullable($.$spc.System.Int32).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadInternalAsync","d":2003688,"h":171800695528,"f":2},{"r":133300225,"p":[{"n":"destination","p":1610472},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","d":2003688,"h":176095662824,"f":36865},{"r":133300225,"p":[{"n":"destination","p":62128129},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CopyToAsync","o":"@$1","d":2003688,"h":180390630120,"f":36865},{"r":65537,"n":"ClearCancellationToken","d":2003688,"h":184685597416,"f":2},{"r":65537,"n":"ThrowIfCompleted","d":2003688,"h":188980564712,"f":2},{"r":262145,"p":[{"n":"result","p":1741544,"f":2}],"n":"TryRead","d":2003688,"h":193275532008,"f":32769},{"r":262145,"p":[{"n":"source","p":126091265},{"n":"result","p":1741544,"f":2}],"n":"TryReadInternal","d":2003688,"h":197570499304,"f":2},{"r":$.$sm.System.Buffers.ReadOnlySequence$$($.$spc.System.Byte).$h,"n":"GetCurrentReadOnlySequence","d":2003688,"h":201865466600,"f":2},{"r":65537,"p":[{"n":"minimumSize","p":$.$typeNullable($.$spc.System.Int32).$h,"f":65}],"n":"AllocateReadTail","d":2003688,"h":206160433896,"f":2},{"r":103144,"p":[{"n":"minimumSize","p":$.$typeNullable($.$spc.System.Int32).$h,"f":65}],"n":"AllocateSegment","d":2003688,"h":210455401192,"f":2},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361}],"n":"GetSegmentSize","d":2003688,"h":214750368488,"f":2},{"r":103144,"n":"CreateSegmentUnsynchronized","d":2003688,"h":219045335784,"f":2},{"r":65537,"p":[{"n":"segment","p":103144}],"n":"ReturnSegmentUnsynchronized","d":2003688,"h":223340303080,"f":2},{"r":65537,"n":"Cancel","d":2003688,"h":227635270376,"f":2}],"l":[{"t":655361,"n":"InitialSegmentPoolSize","d":2003688,"h":4296970984,"f":40},{"t":655361,"n":"MaxSegmentPoolSize","d":2003688,"h":8591938280,"f":40},{"t":126091265,"n":"_internalTokenSource","d":2003688,"h":12886905576,"f":2},{"t":262145,"n":"_isReaderCompleted","d":2003688,"h":17181872872,"f":2},{"t":103144,"n":"_readHead","d":2003688,"h":21476840168,"f":2},{"t":655361,"n":"_readIndex","d":2003688,"h":25771807464,"f":2},{"t":103144,"n":"_readTail","d":2003688,"h":30066774760,"f":2},{"t":917505,"n":"_bufferedBytes","d":2003688,"h":34361742056,"f":2},{"t":262145,"n":"_examinedEverything","d":2003688,"h":38656709352,"f":2},{"t":131073,"n":"_lock","d":2003688,"h":42951676648,"f":2},{"t":168680,"n":"_bufferSegmentPool","d":2003688,"h":47246643944,"f":2},{"t":2069224,"n":"_options","d":2003688,"h":51541611240,"f":2}],"c":[{"p":[{"n":"readingStream","p":62128129},{"n":"options","p":2069224}],"n":".ctor","o":"$ctor$2","d":2003688,"h":55836578536,"f":1}],"h":2003688}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeReader; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeReader`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.ThreadPoolScheduler", ($self) => class ThreadPoolScheduler extends $.$sipl.System.IO.Pipelines.PipeScheduler
        {
            /*void */ Schedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                $.$spc.System.Threading.ThreadPool.QueueUserWorkItem$2($.$spc.System.Object, action, state, false);
            }
            /*void */ UnsafeSchedule(/*Action<object?>*/ action, /*object?*/ state)
            {
                $.$spc.System.Threading.ThreadPool.UnsafeQueueUserWorkItem($.$spc.System.Object, action, state, false);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2265832;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1544936,"m":[{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"Schedule","d":2265832,"h":4297233128,"f":32769},{"r":65537,"p":[{"n":"action","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"UnsafeSchedule","d":2265832,"h":8592200424,"f":32776}],"c":[{"n":".ctor","o":"$ctor$2","d":2265832,"h":12887167720,"f":1}],"h":2265832}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeScheduler; }
            static get $fullName() { return `System.IO.Pipelines.ThreadPoolScheduler`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeReaderStream", ($self) => class PipeReaderStream extends $.$spc.System.IO.Stream
        {
            /*PipeReader*/ _pipeReader = null;
            $ctor$3(/*PipeReader*/ pipeReader, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(pipeReader !== null, "pipeReader != null");
                    this._pipeReader = pipeReader;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this.LeaveOpen)
                {
                    this._pipeReader.Complete(null);
                }
                super.Dispose$1(disposing);
            }
            /*bool */ get CanRead()
            {
                return true;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*bool*/ LeaveOpen = false;
            /*void */ Flush()
            {
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                return this.ReadInternal(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count));
            }
            /*int */ ReadByte()
            {
                /*Span<byte>*/ let oneByte = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 1, null);
                return this.ReadInternal(oneByte) === 0 ? -1 : oneByte.get_Item(0).$v;
            }
            /*int */ ReadInternal(/*Span<byte>*/ buffer)
            {
                /*ValueTask<ReadResult>*/ let vt = this._pipeReader.ReadAsync(new $.$spc.System.Threading.CancellationToken());
                /*ReadResult*/ let result = vt.IsCompletedSuccessfully ? vt.Result : vt.AsTask().GetAwaiter$1().GetResult();
                return this.HandleReadResult(result, buffer);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.ReadAsync$1(buffer, offset, count, new $.$spc.System.Threading.CancellationToken()), callback, state);
            }
            /*int */ EndRead(/*IAsyncResult*/ asyncResult)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.End$1($.$spc.System.Int32, asyncResult);
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                return this.ReadAsyncInternal(new ($.$spc.System.Memory$$($.$spc.System.Byte))().$ctor$4(buffer, offset, count), cancellationToken).AsTask();
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                return this.ReadInternal(buffer);
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadAsyncInternal(buffer, cancellationToken);
            }
            /*ValueTask<int> *//*async*/  ReadAsyncInternal(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                {
                    /*ReadResult*/ let result = await this._pipeReader.ReadAsync(cancellationToken).ConfigureAwait(false);
                    return this.HandleReadResult(result, buffer.Span);
                });
            }
            /*int */ HandleReadResult(/*ReadResult*/ result, /*Span<byte>*/ buffer)
            {
                if (result.IsCanceled)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_ReadCanceled();
                }
                /*ReadOnlySequence<byte>*/ let sequence = result.Buffer;
                /*long*/ let bufferLength = sequence.Length;
                /*SequencePosition*/ let consumed = sequence.Start;
                try
                {
                    if (bufferLength !== 0n)
                    {
                        /*int*/ let actual = $.$cast($.$spc.System.Math.Min$5(bufferLength, BigInt(buffer.Length)), $.$spc.System.Int32);
                        /*ReadOnlySequence<byte>*/ let slice = BigInt(actual) === bufferLength ? sequence : sequence.Slice$3(0, actual);
                        consumed = slice.End;
                        $.$sm.System.Buffers.BuffersExtensions.CopyTo($.$spc.System.Byte, $.$ref(() => slice, ), buffer);
                        return actual;
                    }
                    if (result.IsCompleted)
                    {
                        return 0;
                    }
                }
                finally
                {
                    {
                        this._pipeReader.AdvanceTo(consumed);
                    }
                }
                $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_InvalidZeroByteRead();
                return 0;
            }
            /*Task */ CopyToAsync$3(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                $.$sipl.System.IO.StreamHelpers.ValidateCopyToArgs(this, destination, bufferSize);
                return this._pipeReader.CopyToAsync$1(destination, cancellationToken);
            }
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            static $h = 1479400;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476315880,"f":32769},"n":"CanRead","d":1479400,"h":17181348584,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":30066250472,"f":32769},"n":"CanSeek","d":1479400,"h":25771283176,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38656185064,"f":32769},"n":"CanWrite","d":1479400,"h":34361217768,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":47246119656,"f":32769},"n":"Length","d":1479400,"h":42951152360,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":55836054248,"f":32769},"s":{"r":0,"d":0,"h":60131021544,"f":32769},"n":"Position","d":1479400,"h":51541086952,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":73015923432,"f":8},"s":{"r":0,"d":0,"h":77310890728,"f":8},"n":"LeaveOpen","d":1479400,"h":68720956136,"f":8}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1479400,"h":12886381288,"f":32772},{"r":65537,"n":"Flush","d":1479400,"h":81605858024,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1479400,"h":85900825320,"f":32769},{"r":655361,"n":"ReadByte","d":1479400,"h":90195792616,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"ReadInternal","d":1479400,"h":94490759912,"f":2},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1479400,"h":98785727208,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1479400,"h":103080694504,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1479400,"h":107375661800,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginRead","d":1479400,"h":111670629096,"f":98305},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":1479400,"h":115965596392,"f":98305},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1479400,"h":120260563688,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1479400,"h":124555530984,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1479400,"h":128850498280,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193}],"n":"ReadAsyncInternal","d":1479400,"h":133145465576,"f":4098},{"r":655361,"p":[{"n":"result","p":1741544},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"HandleReadResult","d":1479400,"h":137440432872,"f":2},{"r":133300225,"p":[{"n":"destination","p":62128129},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125960193}],"n":"CopyToAsync","o":"@$3","d":1479400,"h":141735400168,"f":32769}],"l":[{"t":1413864,"n":"_pipeReader","d":1479400,"h":4296446696,"f":2}],"c":[{"p":[{"n":"pipeReader","p":1413864},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":1479400,"h":8591413992,"f":1}],"i":[57475073,56885249],"h":1479400}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeReaderStream`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.PipeWriterStream", ($self) => class PipeWriterStream extends $.$spc.System.IO.Stream
        {
            /*PipeWriter*/ _pipeWriter = null;
            $ctor$3(/*PipeWriter*/ pipeWriter, /*bool*/ leaveOpen)
            {
                super.$ctor$2();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(pipeWriter !== null, "pipeWriter != null");
                    this._pipeWriter = pipeWriter;
                    this.LeaveOpen = leaveOpen;
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this.LeaveOpen)
                {
                    this._pipeWriter.Complete(null);
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                if (!this.LeaveOpen)
                {
                    return this._pipeWriter.CompleteAsync(null);
                }
                return new $.$spc.System.Threading.Tasks.ValueTask();
            }
            /*bool*/ LeaveOpen = false;
            /*bool */ get CanRead()
            {
                return false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return true;
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Flush()
            {
                this.FlushAsync().GetAwaiter().GetResult();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*AsyncCallback?*/ callback, /*object?*/ state)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.Begin(this.WriteAsync$1(buffer, offset, count, new $.$spc.System.Threading.CancellationToken()), callback, state);
            }
            /*void */ EndWrite(/*IAsyncResult*/ asyncResult)
            {
                return $.$spc.System.Threading.Tasks.TaskToAsyncResult.End(asyncResult);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                return this.WriteAsync(buffer, offset, count).GetAwaiter().GetResult();
            }
            /*Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                if (buffer === null)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.buffer*/);
                }
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.WriteAsync(new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count), cancellationToken);
                return $.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.WriteAsync(buffer, cancellationToken);
                return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask));
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                /*ValueTask<FlushResult>*/ let valueTask = this._pipeWriter.FlushAsync(cancellationToken);
                return $.$sipl.System.IO.Pipelines.PipeWriterStream.GetFlushResultAsTask(valueTask);
            }
            static /*Task */ GetFlushResultAsTask(/*ValueTask<FlushResult>*/ valueTask)
            {
                if (valueTask.IsCompletedSuccessfully)
                {
                    /*FlushResult*/ let result = valueTask.Result;
                    if (result.IsCanceled)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                    }
                    return $.$spc.System.Threading.Tasks.Task.CompletedTask;
                }
                /*static Task*/ /*async*/  function AwaitTask(/*ValueTask<FlushResult>*/ valueTask)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                    {
                        /*FlushResult*/ let result = await valueTask.ConfigureAwait(false);
                        if (result.IsCanceled)
                        {
                            $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowOperationCanceledException_FlushCanceled();
                        }
                    });
                }
                return AwaitTask(valueTask);
            }
            //default member initializer
            constructor()
            {
                super();
                this.LeaveOpen = false;
            }
            static $h = 1676008;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066447080,"f":8},"s":{"r":0,"d":0,"h":34361414376,"f":8},"n":"LeaveOpen","d":1676008,"h":25771479784,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":42951348968,"f":32769},"n":"CanRead","d":1676008,"h":38656381672,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51541283560,"f":32769},"n":"CanSeek","d":1676008,"h":47246316264,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":60131218152,"f":32769},"n":"CanWrite","d":1676008,"h":55836250856,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":68721152744,"f":32769},"n":"Length","d":1676008,"h":64426185448,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":77311087336,"f":32769},"s":{"r":0,"d":0,"h":81606054632,"f":32769},"n":"Position","d":1676008,"h":73016120040,"f":32769}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1676008,"h":12886577896,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1676008,"h":17181545192,"f":32769},{"r":65537,"n":"Flush","d":1676008,"h":85901021928,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1676008,"h":90195989224,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1676008,"h":94490956520,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1676008,"h":98785923816,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWrite","d":1676008,"h":103080891112,"f":98305},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":1676008,"h":107375858408,"f":98305},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1676008,"h":111670825704,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1676008,"h":115965793000,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1676008,"h":120260760296,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1676008,"h":124555727592,"f":32769},{"r":133300225,"p":[{"n":"valueTask","p":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h}],"n":"GetFlushResultAsTask","d":1676008,"h":128850694888,"f":34}],"l":[{"t":1610472,"n":"_pipeWriter","d":1676008,"h":4296643304,"f":2}],"c":[{"p":[{"n":"pipeWriter","p":1610472},{"n":"leaveOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":1676008,"h":8591610600,"f":1}],"i":[57475073,56885249],"h":1676008}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipelines.PipeWriterStream`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ResultFlags", ($self) => class ResultFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static Canceled = 1;
            static Completed = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Canceled": 1n,
                    "Completed": 2n
                };
            }
            static $h = 1807080;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"l":[{"t":1807080,"n":"None","d":1807080,"h":4296774376,"f":33},{"t":1807080,"n":"Canceled","d":1807080,"h":8591741672,"f":33},{"t":1807080,"n":"Completed","d":1807080,"h":12886708968,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1807080,"h":17181676264,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1807080,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipelines.ResultFlags`; }
        });
        
        $asm.$str("$sipl.System.IO.Pipelines.ExceptionArgument", ($self) => class ExceptionArgument extends $.$spc.System.Enum
        {
            static minimumSize = 0;
            static bytes = 1;
            static callback = 2;
            static options = 3;
            static pauseWriterThreshold = 4;
            static resumeWriterThreshold = 5;
            static sizeHint = 6;
            static destination = 7;
            static buffer = 8;
            static source = 9;
            static readingStream = 10;
            static writingStream = 11;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "minimumSize": 0n,
                    "bytes": 1n,
                    "callback": 2n,
                    "options": 3n,
                    "pauseWriterThreshold": 4n,
                    "resumeWriterThreshold": 5n,
                    "sizeHint": 6n,
                    "destination": 7n,
                    "buffer": 8n,
                    "source": 9n,
                    "readingStream": 10n,
                    "writingStream": 11n
                };
            }
            static $h = 365288;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":365288,"n":"minimumSize","d":365288,"h":4295332584,"f":33},{"t":365288,"n":"bytes","d":365288,"h":8590299880,"f":33},{"t":365288,"n":"callback","d":365288,"h":12885267176,"f":33},{"t":365288,"n":"options","d":365288,"h":17180234472,"f":33},{"t":365288,"n":"pauseWriterThreshold","d":365288,"h":21475201768,"f":33},{"t":365288,"n":"resumeWriterThreshold","d":365288,"h":25770169064,"f":33},{"t":365288,"n":"sizeHint","d":365288,"h":30065136360,"f":33},{"t":365288,"n":"destination","d":365288,"h":34360103656,"f":33},{"t":365288,"n":"buffer","d":365288,"h":38655070952,"f":33},{"t":365288,"n":"source","d":365288,"h":42950038248,"f":33},{"t":365288,"n":"readingStream","d":365288,"h":47245005544,"f":33},{"t":365288,"n":"writingStream","d":365288,"h":51539972840,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":365288,"h":55834940136,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":365288}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipelines.ExceptionArgument`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.BufferSegment", ($self) => class BufferSegment extends $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$spc.System.Byte)
        {
            /*IMemoryOwner<byte>?*/ _memoryOwner = null;
            /*byte[]?*/ _array = null;
            /*BufferSegment?*/ _next = null;
            /*int*/ _end = 0;
            /*int */ get End()
            {
                return this._end;
            }
            /*int */ set End(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value <= this.AvailableMemory.Length, "value <= AvailableMemory.Length");
                this._end = value;
                this.Memory = $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2(this.AvailableMemory.Slice$1(0, value));
            }
            /*BufferSegment? */ get NextSegment()
            {
                return this._next;
            }
            /*BufferSegment? */ set NextSegment(value)
            {
                this.Next = value;
                this._next = value;
            }
            /*void */ SetOwnedMemory(/*IMemoryOwner<byte>*/ memoryOwner)
            {
                this._memoryOwner = memoryOwner;
                this.AvailableMemory = memoryOwner.System$Buffers$IMemoryOwner$$$Memory;
            }
            /*void */ SetOwnedMemory$1(/*byte[]*/ arrayPoolBuffer)
            {
                this._array = arrayPoolBuffer;
                this.AvailableMemory = $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(arrayPoolBuffer);
            }
            /*void */ Reset()
            {
                this.ResetMemory();
                this.Next = null;
                this.RunningIndex = 0n;
                this._next = null;
            }
            /*void */ ResetMemory()
            {
                /*IMemoryOwner<byte>?*/ let memoryOwner = this._memoryOwner;
                if (memoryOwner !== null)
                {
                    this._memoryOwner = null;
                    memoryOwner.System$IDisposable$Dispose();
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._array !== null, "_array != null");
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(this._array, false);
                    this._array = null;
                }
                this.Memory = new ($.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte))();
                this._end = 0;
                this.AvailableMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
            }
            /*object? */ get MemoryOwner()
            {
                return $.$cast(this._memoryOwner, $.$spc.System.Object) ?? this._array;
            }
            /*Memory<byte>*/ AvailableMemory;
            /*int */ get Length()
            {
                return this.End;
            }
            /*int */ get WritableBytes()
            {
                return ((this.AvailableMemory.Length - this.End) | 0);
            }
            /*void */ SetNext(/*BufferSegment*/ segment)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segment !== null, "segment != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this.Next === null, "Next == null");
                this.NextSegment = segment;
                segment = this;
                while(segment.Next !== null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(segment.NextSegment !== null, "segment.NextSegment != null");
                    segment.NextSegment.RunningIndex = segment.RunningIndex + BigInt(segment.Length);
                    segment = segment.NextSegment;
                }
            }
            static /*long */ GetLength(/*BufferSegment*/ startSegment, /*int*/ startIndex, /*BufferSegment*/ endSegment, /*int*/ endIndex)
            {
                return (endSegment.RunningIndex + BigInt((endIndex >>> 0))) - (startSegment.RunningIndex + BigInt((startIndex >>> 0)));
            }
            static /*long */ GetLength$1(/*long*/ startPosition, /*BufferSegment*/ endSegment, /*int*/ endIndex)
            {
                return (endSegment.RunningIndex + BigInt((endIndex >>> 0))) - startPosition;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.AvailableMemory = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
            }
            static $h = 103144;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":655361,"g":{"r":0,"d":0,"h":25769906920,"f":1},"s":{"r":0,"d":0,"h":30064874216,"f":1},"n":"End","d":103144,"h":21474939624,"f":1},{"p":103144,"g":{"r":0,"d":0,"h":38654808808,"f":1},"s":{"r":0,"d":0,"h":42949776104,"f":1},"n":"NextSegment","d":103144,"h":34359841512,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":68719579880,"f":8},"n":"MemoryOwner","d":103144,"h":64424612584,"f":8},{"p":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":81604481768,"f":1},"s":{"r":0,"d":0,"h":85899449064,"f":2},"n":"AvailableMemory","d":103144,"h":77309514472,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":94489383656,"f":1},"n":"Length","d":103144,"h":90194416360,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103079318248,"f":1},"n":"WritableBytes","d":103144,"h":98784350952,"f":1}],"m":[{"r":65537,"p":[{"n":"memoryOwner","p":$.$spc.System.Buffers.IMemoryOwner$$($.$spc.System.Byte).$h}],"n":"SetOwnedMemory","d":103144,"h":47244743400,"f":1},{"r":65537,"p":[{"n":"arrayPoolBuffer","p":0}],"n":"SetOwnedMemory","o":"@$1","d":103144,"h":51539710696,"f":1},{"r":65537,"n":"Reset","d":103144,"h":55834677992,"f":1},{"r":65537,"n":"ResetMemory","d":103144,"h":60129645288,"f":1},{"r":65537,"p":[{"n":"segment","p":103144}],"n":"SetNext","d":103144,"h":107374285544,"f":1},{"r":917505,"p":[{"n":"startSegment","p":103144},{"n":"startIndex","p":655361},{"n":"endSegment","p":103144},{"n":"endIndex","p":655361}],"n":"GetLength","d":103144,"h":111669252840,"f":40},{"r":917505,"p":[{"n":"startPosition","p":917505},{"n":"endSegment","p":103144},{"n":"endIndex","p":655361}],"n":"GetLength","o":"@$1","d":103144,"h":115964220136,"f":40}],"l":[{"t":$.$spc.System.Buffers.IMemoryOwner$$($.$spc.System.Byte).$h,"n":"_memoryOwner","d":103144,"h":4295070440,"f":2},{"t":0,"n":"_array","d":103144,"h":8590037736,"f":2},{"t":103144,"n":"_next","d":103144,"h":12885005032,"f":2},{"t":655361,"n":"_end","d":103144,"h":17179972328,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":103144,"h":120259187432,"f":1}],"h":103144}; }
            static get $b() { return $.$sm.System.Buffers.ReadOnlySequenceSegment$$($.$spc.System.Byte); }
            static get $fullName() { return `System.IO.Pipelines.BufferSegment`; }
        });
        
        $asm.$cls("$sipl.System.IO.Pipelines.StreamPipeWriter", ($self) => class StreamPipeWriter extends $.$sipl.System.IO.Pipelines.PipeWriter
        {
            /*int*/ static InitialSegmentPoolSize = 4;
            /*int*/ static MaxSegmentPoolSize = 256;
            /*int*/ _minimumBufferSize = 0;
            /*BufferSegment?*/ _head = null;
            /*BufferSegment?*/ _tail = null;
            /*Memory<byte>*/ _tailMemory;
            /*int*/ _tailBytesBuffered = 0;
            /*long*/ _bytesBuffered = 0n;
            /*MemoryPool<byte>?*/ _pool = null;
            /*int*/ _maxPooledBufferSize = 0;
            /*CancellationTokenSource?*/ _internalTokenSource = null;
            /*bool*/ _isCompleted = false;
            /*object*/ _lockObject = null;
            /*BufferSegmentStack*/ _bufferSegmentPool;
            /*bool*/ _leaveOpen = false;
            /*CancellationTokenSource */ get InternalTokenSource()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._lockObject)
                    {
                        return this._internalTokenSource ??= new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._lockObject)
                }
            }
            $ctor$2(/*Stream*/ writingStream, /*StreamPipeWriterOptions*/ options)
            {
                super.$ctor$1();
                {
                    if (writingStream === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(11/*ExceptionArgument.writingStream*/);
                    }
                    if (options === null)
                    {
                        $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.options*/);
                    }
                    this.InnerStream = writingStream;
                    this._minimumBufferSize = options.MinimumBufferSize;
                    this._pool = options.Pool === $.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).Shared ? null : options.Pool;
                    this._maxPooledBufferSize = (this._pool?.MaxBufferSize ?? null) ?? -1;
                    this._bufferSegmentPool = new $.$sipl.System.IO.Pipelines.BufferSegmentStack().$ctor$2(4/*InitialSegmentPoolSize*/);
                    this._leaveOpen = options.LeaveOpen;
                }
                return this;
            }
            /*Stream*/ InnerStream = null;
            /*void */ Advance(/*int*/ bytes)
            {
                if ((bytes >>> 0) > (this._tailMemory.Length >>> 0))
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.bytes*/);
                }
                this._tailBytesBuffered += bytes;
                this._bytesBuffered += BigInt(bytes);
                this._tailMemory = this._tailMemory.Slice(bytes);
            }
            /*Memory<byte> */ GetMemory(/*int*/ sizeHint)
            {
                if (this._isCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateMemory(sizeHint);
                return this._tailMemory;
            }
            /*Span<byte> */ GetSpan(/*int*/ sizeHint)
            {
                if (this._isCompleted)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowInvalidOperationException_NoWritingAllowed();
                }
                if (sizeHint < 0)
                {
                    $.$sipl.System.IO.Pipelines.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.sizeHint*/);
                }
                this.AllocateMemory(sizeHint);
                return this._tailMemory.Span;
            }
            /*void */ AllocateMemory(/*int*/ sizeHint)
            {
                if (this._head === null)
                {
                    /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                    this._head = this._tail = newSegment;
                    this._tailBytesBuffered = 0;
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._tail !== null, "_tail != null");
                    /*int*/ let bytesLeftInBuffer = this._tailMemory.Length;
                    if (bytesLeftInBuffer === 0 || bytesLeftInBuffer < sizeHint)
                    {
                        if (this._tailBytesBuffered > 0)
                        {
                            this._tail.End += this._tailBytesBuffered;
                            this._tailBytesBuffered = 0;
                        }
                        /*BufferSegment*/ let newSegment = this.AllocateSegment(sizeHint);
                        this._tail.SetNext(newSegment);
                        this._tail = newSegment;
                    }
                }
            }
            /*BufferSegment */ AllocateSegment(/*int*/ sizeHint)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(sizeHint >= 0, "sizeHint >= 0");
                /*BufferSegment*/ let newSegment = this.CreateSegmentUnsynchronized();
                /*int*/ let maxSize = this._maxPooledBufferSize;
                if (sizeHint <= maxSize)
                {
                    newSegment.SetOwnedMemory(this._pool.Rent(this.GetSegmentSize(sizeHint, maxSize)));
                }
                else 
                {
                    /*int*/ let sizeToRequest = this.GetSegmentSize(sizeHint, 2147483647);
                    newSegment.SetOwnedMemory$1($.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(sizeToRequest));
                }
                this._tailMemory = newSegment.AvailableMemory;
                return newSegment;
            }
            /*int */ GetSegmentSize(/*int*/ sizeHint, /*int*/ maxBufferSize)
            {
                sizeHint = $.$spc.System.Math.Max$4(this._minimumBufferSize, sizeHint);
                /*var*/ let adjustedToMaximumSize = $.$spc.System.Math.Min$4(maxBufferSize, sizeHint);
                return adjustedToMaximumSize;
            }
            /*BufferSegment */ CreateSegmentUnsynchronized()
            {
                /*BufferSegment?*/ let segment;
                if (this._bufferSegmentPool.TryPop($.$ref(() => segment, ($v) => segment = $v, $.$sipl.System.IO.Pipelines.BufferSegment)))
                {
                    return segment;
                }
                return new $.$sipl.System.IO.Pipelines.BufferSegment().$ctor$2();
            }
            /*void */ ReturnSegmentUnsynchronized(/*BufferSegment*/ segment)
            {
                segment.Reset();
                if (this._bufferSegmentPool.Count < 256/*MaxSegmentPoolSize*/)
                {
                    this._bufferSegmentPool.Push(segment);
                }
            }
            /*void */ CancelPendingFlush()
            {
                this.Cancel();
            }
            /*bool */ get CanGetUnflushedBytes()
            {
                return true;
            }
            /*void */ Complete(/*Exception?*/ exception)
            {
                if (this._isCompleted)
                {
                    return;
                }
                this._isCompleted = true;
                try
                {
                    this.FlushInternal(exception === null);
                }
                finally
                {
                    {
                        this._internalTokenSource?.Dispose();
                        if (!this._leaveOpen)
                        {
                            this.InnerStream.Dispose();
                        }
                    }
                }
            }
            /*ValueTask *//*async*/  CompleteAsync(/*Exception?*/ exception)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    if (this._isCompleted)
                    {
                        return;
                    }
                    this._isCompleted = true;
                    try
                    {
                        await this.FlushAsyncInternal(exception === null, $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.Memory$$($.$spc.System.Byte).Empty), new $.$spc.System.Threading.CancellationToken()).ConfigureAwait(false);
                    }
                    finally
                    {
                        {
                            this._internalTokenSource?.Dispose();
                            if (!this._leaveOpen)
                            {
                                await this.InnerStream.DisposeAsync().ConfigureAwait(false);
                            }
                        }
                    }
                });
            }
            /*ValueTask<FlushResult> */ FlushAsync(/*CancellationToken*/ cancellationToken)
            {
                if (this._bytesBuffered === 0n)
                {
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult))().$ctor$2(new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false));
                }
                return this.FlushAsyncInternal(true, $.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.Memory$$($.$spc.System.Byte).Empty), new $.$spc.System.Threading.CancellationToken());
            }
            /*long */ get UnflushedBytes()
            {
                return this._bytesBuffered;
            }
            /*ValueTask<FlushResult> */ WriteAsync(/*ReadOnlyMemory<byte>*/ source, /*CancellationToken*/ cancellationToken)
            {
                return this.FlushAsyncInternal(true, source, new $.$spc.System.Threading.CancellationToken());
            }
            /*void */ Cancel()
            {
                this.InternalTokenSource.Cancel();
            }
            /*ValueTask<FlushResult> *//*async*/  FlushAsyncInternal(/*bool*/ writeToStream, /*ReadOnlyMemory<byte>*/ data, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult), $.$sipl.System.IO.Pipelines.FlushResult, async () => 
                {
                    /*CancellationTokenRegistration*/ let reg = new $.$spc.System.Threading.CancellationTokenRegistration();
                    if (cancellationToken.CanBeCanceled)
                    {
                        reg = cancellationToken.UnsafeRegister(new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/**/ state) =>
                        {
                            return ($.$cast(state, $.$sipl.System.IO.Pipelines.StreamPipeWriter)).Cancel();
                        }), this);
                    }
                    if (this._tailBytesBuffered > 0)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._tail !== null, "_tail != null");
                        this._tail.End += this._tailBytesBuffered;
                        this._tailBytesBuffered = 0;
                    }
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = reg;
                        /*CancellationToken*/ let localToken = this.InternalTokenSource.Token;
                        try
                        {
                            /*BufferSegment?*/ let segment = this._head;
                            while(segment !== null)
                            {
                                /*BufferSegment*/ let returnSegment = segment;
                                segment = segment.NextSegment;
                                if (returnSegment.Length > 0 && writeToStream)
                                {
                                    await this.InnerStream.WriteAsync$2(returnSegment.Memory, localToken).ConfigureAwait(false);
                                }
                                this.ReturnSegmentUnsynchronized(returnSegment);
                                this._head = segment;
                            }
                            if (writeToStream)
                            {
                                if (data.Length > 0)
                                {
                                    await this.InnerStream.WriteAsync$2(data, localToken).ConfigureAwait(false);
                                }
                                if (this._bytesBuffered > 0n || data.Length > 0)
                                {
                                    await this.InnerStream.FlushAsync$1(localToken).ConfigureAwait(false);
                                }
                            }
                            this._head = null;
                            this._tail = null;
                            this._tailMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                            this._bytesBuffered = 0n;
                            return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(false, false);
                        }
                        catch($e)
                        {
                            //lock
                            try
                            {
                                $.$spc.System.Threading.Monitor.Enter(this._lockObject)
                                {
                                    this._internalTokenSource = null;
                                }
                            }
                            finally
                            {
                                $.$spc.System.Threading.Monitor.Exit(this._lockObject)
                            }
                            if (localToken.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
                            {
                                return new $.$sipl.System.IO.Pipelines.FlushResult().$ctor$2(true, false);
                            }
                            throw $e;
                        }
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            /*void */ FlushInternal(/*bool*/ writeToStream)
            {
                if (this._tailBytesBuffered > 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._tail !== null, "_tail != null");
                    this._tail.End += this._tailBytesBuffered;
                    this._tailBytesBuffered = 0;
                }
                /*BufferSegment?*/ let segment = this._head;
                while(segment !== null)
                {
                    /*BufferSegment*/ let returnSegment = segment;
                    segment = segment.NextSegment;
                    if (returnSegment.Length > 0 && writeToStream)
                    {
                        this.InnerStream.Write$1(returnSegment.Memory.Span);
                    }
                    this.ReturnSegmentUnsynchronized(returnSegment);
                    this._head = segment;
                }
                if (this._bytesBuffered > 0n && writeToStream)
                {
                    this.InnerStream.Flush();
                }
                this._head = null;
                this._tail = null;
                this._tailMemory = new ($.$spc.System.Memory$$($.$spc.System.Byte))();
                this._bytesBuffered = 0n;
            }
            //default member initializer
            constructor()
            {
                super();
                this._tailMemory = $.$default($.$spc.System.Memory$$($.$spc.System.Byte));
                this._lockObject = new $.$spc.System.Object().$ctor();
                this._bufferSegmentPool = $.$default($.$sipl.System.IO.Pipelines.BufferSegmentStack);
            }
            static $h = 2134760;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1610472,"p":[{"p":126091265,"g":{"r":0,"d":0,"h":73016578792,"f":2},"n":"InternalTokenSource","d":2134760,"h":68721611496,"f":2},{"p":62128129,"g":{"r":0,"d":0,"h":90196447976,"f":1},"n":"InnerStream","d":2134760,"h":85901480680,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":137441088232,"f":32769},"n":"CanGetUnflushedBytes","d":2134760,"h":133146120936,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":158915924712,"f":32769},"n":"UnflushedBytes","d":2134760,"h":154620957416,"f":32769}],"m":[{"r":65537,"p":[{"n":"bytes","p":655361}],"n":"Advance","d":2134760,"h":94491415272,"f":32769},{"r":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":2134760,"h":98786382568,"f":32769},{"r":$.$spc.System.Span$$($.$spc.System.Byte).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":2134760,"h":103081349864,"f":32769},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateMemory","d":2134760,"h":107376317160,"f":2},{"r":103144,"p":[{"n":"sizeHint","p":655361}],"n":"AllocateSegment","d":2134760,"h":111671284456,"f":2},{"r":655361,"p":[{"n":"sizeHint","p":655361},{"n":"maxBufferSize","p":655361,"f":65,"v":2147483647}],"n":"GetSegmentSize","d":2134760,"h":115966251752,"f":2},{"r":103144,"n":"CreateSegmentUnsynchronized","d":2134760,"h":120261219048,"f":2},{"r":65537,"p":[{"n":"segment","p":103144}],"n":"ReturnSegmentUnsynchronized","d":2134760,"h":124556186344,"f":2},{"r":65537,"n":"CancelPendingFlush","d":2134760,"h":128851153640,"f":32769},{"r":65537,"p":[{"n":"exception","p":47185921,"f":65}],"n":"Complete","d":2134760,"h":141736055528,"f":32769},{"r":136118273,"p":[{"n":"exception","p":47185921,"f":65}],"n":"CompleteAsync","d":2134760,"h":146031022824,"f":36865},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","d":2134760,"h":150325990120,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"source","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","d":2134760,"h":163210892008,"f":32769},{"r":65537,"n":"Cancel","d":2134760,"h":167505859304,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$sipl.System.IO.Pipelines.FlushResult).$h,"p":[{"n":"writeToStream","p":262145},{"n":"data","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsyncInternal","d":2134760,"h":171800826600,"f":4098,"a":[{"t":86638593,"c":4381605889,"a":[{"v":$.$spc.System.Runtime.CompilerServices.PoolingAsyncValueTaskMethodBuilder$$().$h,"t":142606337}]}]},{"r":65537,"p":[{"n":"writeToStream","p":262145}],"n":"FlushInternal","d":2134760,"h":176095793896,"f":2}],"l":[{"t":655361,"n":"InitialSegmentPoolSize","d":2134760,"h":4297102056,"f":40},{"t":655361,"n":"MaxSegmentPoolSize","d":2134760,"h":8592069352,"f":40},{"t":655361,"n":"_minimumBufferSize","d":2134760,"h":12887036648,"f":2},{"t":103144,"n":"_head","d":2134760,"h":17182003944,"f":2},{"t":103144,"n":"_tail","d":2134760,"h":21476971240,"f":2},{"t":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"n":"_tailMemory","d":2134760,"h":25771938536,"f":2},{"t":655361,"n":"_tailBytesBuffered","d":2134760,"h":30066905832,"f":2},{"t":917505,"n":"_bytesBuffered","d":2134760,"h":34361873128,"f":2},{"t":$.$sm.System.Buffers.MemoryPool$$($.$spc.System.Byte).$h,"n":"_pool","d":2134760,"h":38656840424,"f":2},{"t":655361,"n":"_maxPooledBufferSize","d":2134760,"h":42951807720,"f":2},{"t":126091265,"n":"_internalTokenSource","d":2134760,"h":47246775016,"f":2},{"t":262145,"n":"_isCompleted","d":2134760,"h":51541742312,"f":2},{"t":131073,"n":"_lockObject","d":2134760,"h":55836709608,"f":2},{"t":168680,"n":"_bufferSegmentPool","d":2134760,"h":60131676904,"f":2},{"t":262145,"n":"_leaveOpen","d":2134760,"h":64426644200,"f":2}],"c":[{"p":[{"n":"writingStream","p":62128129},{"n":"options","p":2200296}],"n":".ctor","o":"$ctor$2","d":2134760,"h":77311546088,"f":1}],"i":[$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h],"h":2134760}; }
            static get $b() { return $.$sipl.System.IO.Pipelines.PipeWriter; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte) ]; }
            static get $fullName() { return `System.IO.Pipelines.StreamPipeWriter`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime"))