
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stt, $ssc, $sspw, $ssa, $sto) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Pipes", 
    {"h":48240,"f":"System.IO.Pipes","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Pipes","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Pipes","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sip.System.IO.Pipes.PipeStream", ($self) => class PipeStream extends $.$$.System.IO.Stream
        {
            $ctor$3(/*System.IO.Pipes.PipeDirection*/ direction, /*int*/ bufferSize)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*int*/ outBufferSize)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InBufferSize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsConnected()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IsConnected(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsHandleExposed()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMessageComplete()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OutBufferSize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get ReadMode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get SafePipeHandle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CheckPipePropertyOperations()
            {
            }
            /*void */ CheckReadOperations()
            {
            }
            /*void */ CheckWriteOperations()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ InitializeHandle(/*Microsoft.Win32.SafeHandles.SafePipeHandle?*/ handle, /*bool*/ isExposed, /*bool*/ isAsync)
            {
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ WaitForPipeDrain()
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 638064;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180507248,"f":50364417},"n":"CanRead","d":638064,"h":12885539952,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":25770441840,"f":50364417},"n":"CanSeek","d":638064,"h":21475474544,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":34360376432,"f":50364417},"n":"CanWrite","d":638064,"h":30065409136,"f":2129921},{"p":655361,"g":{"r":0,"d":0,"h":42950311024,"f":50331777},"n":"InBufferSize","d":638064,"h":38655343728,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":51540245616,"f":50331649},"n":"IsAsync","d":638064,"h":47245278320,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":60130180208,"f":50331649},"s":{"r":0,"d":0,"h":64425147504,"f":83886084},"n":"IsConnected","d":638064,"h":55835212912,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":73015082096,"f":50331652},"n":"IsHandleExposed","d":638064,"h":68720114800,"f":2097156},{"p":262145,"g":{"r":0,"d":0,"h":81605016688,"f":50331649},"n":"IsMessageComplete","d":638064,"h":77310049392,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":90194951280,"f":50364417},"n":"Length","d":638064,"h":85899983984,"f":2129921},{"p":655361,"g":{"r":0,"d":0,"h":98784885872,"f":50331777},"n":"OutBufferSize","d":638064,"h":94489918576,"f":2097281},{"p":917505,"g":{"r":0,"d":0,"h":107374820464,"f":50364417},"s":{"r":0,"d":0,"h":111669787760,"f":83918849},"n":"Position","d":638064,"h":103079853168,"f":2129921},{"p":769136,"g":{"r":0,"d":0,"h":120259722352,"f":50331777},"s":{"r":0,"d":0,"h":124554689648,"f":83886209},"n":"ReadMode","d":638064,"h":115964755056,"f":2097281},{"p":113776,"g":{"r":0,"d":0,"h":133144624240,"f":50331649},"n":"SafePipeHandle","d":638064,"h":128849656944,"f":2097153},{"p":769136,"g":{"r":0,"d":0,"h":141734558832,"f":50331777},"n":"TransmissionMode","d":638064,"h":137439591536,"f":2097281}],"m":[{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginRead","d":638064,"h":146029526128,"f":16809985},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginWrite","d":638064,"h":150324493424,"f":16809985},{"r":65537,"n":"CheckPipePropertyOperations","d":638064,"h":154619460720,"f":16777360},{"r":65537,"n":"CheckReadOperations","d":638064,"h":158914428016,"f":16777232},{"r":65537,"n":"CheckWriteOperations","d":638064,"h":163209395312,"f":16777232},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":638064,"h":167504362608,"f":16809988},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":638064,"h":171799329904,"f":16809985},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":638064,"h":176094297200,"f":16809985},{"r":65537,"n":"Flush","d":638064,"h":180389264496,"f":16809985},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"FlushAsync","o":"@$1","d":638064,"h":184684231792,"f":16809985},{"r":65537,"p":[{"n":"handle","p":113776},{"n":"isExposed","p":262145},{"n":"isAsync","p":262145}],"n":"InitializeHandle","d":638064,"h":188979199088,"f":16777220},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":638064,"h":193274166384,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"Read","o":"@$1","d":638064,"h":197569133680,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","d":638064,"h":201864100976,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","o":"@$2","d":638064,"h":206159068272,"f":16809985},{"r":655361,"n":"ReadByte","d":638064,"h":210454035568,"f":16809985},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":638064,"h":214749002864,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":638064,"h":219043970160,"f":16809985},{"r":65537,"n":"WaitForPipeDrain","d":638064,"h":223338937456,"f":16777217,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":638064,"h":227633904752,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"Write","o":"@$1","d":638064,"h":231928872048,"f":16809985},{"r":133169153,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"WriteAsync","d":638064,"h":236223839344,"f":16809985},{"r":135987201,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","o":"@$2","d":638064,"h":240518806640,"f":16809985},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":638064,"h":244813773936,"f":16809985}],"c":[{"p":[{"n":"direction","p":506992},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$3","d":638064,"h":4295605360,"f":16777220},{"p":[{"n":"direction","p":506992},{"n":"transmissionMode","p":769136},{"n":"outBufferSize","p":655361}],"n":".ctor","o":"$ctor$4","d":638064,"h":8590572656,"f":16777220}],"i":[57540609,56950785],"h":638064}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.PipeStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.PipeStreamImpersonationWorker", ($self) => class PipeStreamImpersonationWorker extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke()
            {
                return this.$nativeFunction.call(this.$target, );
            }
            static $h = 703600;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"n":"Invoke","d":703600,"h":8590638192,"f":16777345},{"r":57016321,"p":[{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":703600,"h":12885605488,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":703600,"h":17180572784,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":703600,"h":4295670896,"f":16777217}],"i":[57212929,113246209],"h":703600}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.Pipes.PipeStreamImpersonationWorker`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeAccessRights", ($self) => class PipeAccessRights extends $.$$.System.Enum
        {
            static ReadData = 1;
            static WriteData = 2;
            static CreateNewInstance = 4;
            static ReadExtendedAttributes = 8;
            static WriteExtendedAttributes = 16;
            static ReadAttributes = 128;
            static WriteAttributes = 256;
            static Write = 274;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static Read = 131209;
            static ReadWrite = 131483;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static Synchronize = 1048576;
            static FullControl = 2032031;
            static AccessSystemSecurity = 16777216;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ReadData": 1n,
                    "WriteData": 2n,
                    "CreateNewInstance": 4n,
                    "ReadExtendedAttributes": 8n,
                    "WriteExtendedAttributes": 16n,
                    "ReadAttributes": 128n,
                    "WriteAttributes": 256n,
                    "Write": 274n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "Read": 131209n,
                    "ReadWrite": 131483n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "Synchronize": 1048576n,
                    "FullControl": 2032031n,
                    "AccessSystemSecurity": 16777216n
                };
            }
            static $h = 441456;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":441456,"n":"ReadData","d":441456,"h":4295408752,"f":4194337},{"t":441456,"n":"WriteData","d":441456,"h":8590376048,"f":4194337},{"t":441456,"n":"CreateNewInstance","d":441456,"h":12885343344,"f":4194337},{"t":441456,"n":"ReadExtendedAttributes","d":441456,"h":17180310640,"f":4194337},{"t":441456,"n":"WriteExtendedAttributes","d":441456,"h":21475277936,"f":4194337},{"t":441456,"n":"ReadAttributes","d":441456,"h":25770245232,"f":4194337},{"t":441456,"n":"WriteAttributes","d":441456,"h":30065212528,"f":4194337},{"t":441456,"n":"Write","d":441456,"h":34360179824,"f":4194337},{"t":441456,"n":"Delete","d":441456,"h":38655147120,"f":4194337},{"t":441456,"n":"ReadPermissions","d":441456,"h":42950114416,"f":4194337},{"t":441456,"n":"Read","d":441456,"h":47245081712,"f":4194337},{"t":441456,"n":"ReadWrite","d":441456,"h":51540049008,"f":4194337},{"t":441456,"n":"ChangePermissions","d":441456,"h":55835016304,"f":4194337},{"t":441456,"n":"TakeOwnership","d":441456,"h":60129983600,"f":4194337},{"t":441456,"n":"Synchronize","d":441456,"h":64424950896,"f":4194337},{"t":441456,"n":"FullControl","d":441456,"h":68719918192,"f":4194337},{"t":441456,"n":"AccessSystemSecurity","d":441456,"h":73014885488,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":441456,"h":77309852784,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":441456,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeAccessRights`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeDirection", ($self) => class PipeDirection extends $.$$.System.Enum
        {
            static In = 1;
            static Out = 2;
            static InOut = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "In": 1n,
                    "Out": 2n,
                    "InOut": 3n
                };
            }
            static $h = 506992;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":506992,"n":"In","d":506992,"h":4295474288,"f":4194337},{"t":506992,"n":"Out","d":506992,"h":8590441584,"f":4194337},{"t":506992,"n":"InOut","d":506992,"h":12885408880,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":506992,"h":17180376176,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":506992}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeDirection`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeOptions", ($self) => class PipeOptions extends $.$$.System.Enum
        {
            static WriteThrough = -2147483648;
            static None = 0;
            static CurrentUserOnly = 536870912;
            static Asynchronous = 1073741824;
            static FirstPipeInstance = 524288;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "WriteThrough": -2147483648n,
                    "None": 0n,
                    "CurrentUserOnly": 536870912n,
                    "Asynchronous": 1073741824n,
                    "FirstPipeInstance": 524288n
                };
            }
            static $h = 572528;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":572528,"n":"WriteThrough","d":572528,"h":4295539824,"f":4194337},{"t":572528,"n":"None","d":572528,"h":8590507120,"f":4194337},{"t":572528,"n":"CurrentUserOnly","d":572528,"h":12885474416,"f":4194337},{"t":572528,"n":"Asynchronous","d":572528,"h":17180441712,"f":4194337},{"t":572528,"n":"FirstPipeInstance","d":572528,"h":21475409008,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":572528,"h":25770376304,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":572528,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeOptions`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeTransmissionMode", ($self) => class PipeTransmissionMode extends $.$$.System.Enum
        {
            static Byte = 0;
            static Message = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Byte": 0n,
                    "Message": 1n
                };
            }
            static $h = 769136;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":769136,"n":"Byte","d":769136,"h":4295736432,"f":4194337},{"t":769136,"n":"Message","d":769136,"h":8590703728,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":769136,"h":12885671024,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":769136}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeTransmissionMode`; }
        });
        
        $asm.$cls("$sip.Microsoft.Win32.SafeHandles.SafePipeHandle", ($self) => class SafePipeHandle extends $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 113776;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17179982960,"f":50364417},"n":"IsInvalid","d":113776,"h":12885015664,"f":2129921}],"m":[{"r":262145,"n":"ReleaseHandle","d":113776,"h":21474950256,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$4","d":113776,"h":4295081072,"f":16777217},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":113776,"h":8590048368,"f":16777217}],"i":[57540609],"h":113776}; }
            static get $b() { return $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafePipeHandle`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.AnonymousPipeClientStream", ($self) => class AnonymousPipeClientStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$7(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction, /*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 179312;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":638064,"p":[{"p":769136,"s":{"r":0,"d":0,"h":21475015792,"f":83918849},"n":"ReadMode","d":179312,"h":17180048496,"f":2129921},{"p":769136,"g":{"r":0,"d":0,"h":30064950384,"f":50364417},"n":"TransmissionMode","d":179312,"h":25769983088,"f":2129921}],"c":[{"p":[{"n":"direction","p":506992},{"n":"safePipeHandle","p":113776}],"n":".ctor","o":"$ctor$7","d":179312,"h":4295146608,"f":16777217},{"p":[{"n":"direction","p":506992},{"n":"pipeHandleAsString","p":1310721}],"n":".ctor","o":"$ctor$6","d":179312,"h":8590113904,"f":16777217},{"p":[{"n":"pipeHandleAsString","p":1310721}],"n":".ctor","o":"$ctor$5","d":179312,"h":12885081200,"f":16777217}],"i":[57540609,56950785],"h":179312}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.AnonymousPipeClientStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.AnonymousPipeServerStream", ($self) => class AnonymousPipeServerStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5()
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ serverSafePipeHandle, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ clientSafePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability, /*int*/ bufferSize)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get ClientSafePipeHandle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ DisposeLocalCopyOfClientHandle()
            {
            }
            $dtor()
            {
            }
            /*string */ GetClientHandleAsString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 244848;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":638064,"p":[{"p":113776,"g":{"r":0,"d":0,"h":30065015920,"f":50331649},"n":"ClientSafePipeHandle","d":244848,"h":25770048624,"f":2097153},{"p":769136,"s":{"r":0,"d":0,"h":38654950512,"f":83918849},"n":"ReadMode","d":244848,"h":34359983216,"f":2129921},{"p":769136,"g":{"r":0,"d":0,"h":47244885104,"f":50364417},"n":"TransmissionMode","d":244848,"h":42949917808,"f":2129921}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":244848,"h":51539852400,"f":16809988},{"r":65537,"n":"DisposeLocalCopyOfClientHandle","d":244848,"h":55834819696,"f":16777217},{"r":1310721,"n":"GetClientHandleAsString","d":244848,"h":64424754288,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$5","d":244848,"h":4295212144,"f":16777217},{"p":[{"n":"direction","p":506992}],"n":".ctor","o":"$ctor$9","d":244848,"h":8590179440,"f":16777217},{"p":[{"n":"direction","p":506992},{"n":"serverSafePipeHandle","p":113776},{"n":"clientSafePipeHandle","p":113776}],"n":".ctor","o":"$ctor$8","d":244848,"h":12885146736,"f":16777217},{"p":[{"n":"direction","p":506992},{"n":"inheritability","p":60620801}],"n":".ctor","o":"$ctor$7","d":244848,"h":17180114032,"f":16777217},{"p":[{"n":"direction","p":506992},{"n":"inheritability","p":60620801},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$6","d":244848,"h":21475081328,"f":16777217}],"i":[57540609,56950785],"h":244848}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.AnonymousPipeServerStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.NamedPipeClientStream", ($self) => class NamedPipeClientStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$12(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$11(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$10(/*string*/ serverName, /*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeAccessRights*/ desiredAccessRights, /*PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*int */ get NumberOfServerInstances()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CheckPipePropertyOperations()
            {
            }
            /*void */ Connect()
            {
            }
            /*void */ Connect$1(/*int*/ timeout)
            {
            }
            /*void */ Connect$2(/*System.TimeSpan*/ timeout)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*int*/ timeout)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$1(/*int*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.TimeSpan*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$3(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 310384;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":638064,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42949983344,"f":50331649},"n":"NumberOfServerInstances","d":310384,"h":38655016048,"f":2097153,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]}],"m":[{"r":65537,"n":"CheckPipePropertyOperations","d":310384,"h":47244950640,"f":16810000},{"r":65537,"n":"Connect","d":310384,"h":51539917936,"f":16777217},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Connect","o":"@$1","d":310384,"h":55834885232,"f":16777217},{"r":65537,"p":[{"n":"timeout","p":140574721}],"n":"Connect","o":"@$2","d":310384,"h":60129852528,"f":16777217},{"r":133169153,"n":"ConnectAsync","d":310384,"h":64424819824,"f":16777217},{"r":133169153,"p":[{"n":"timeout","p":655361}],"n":"ConnectAsync","o":"@$2","d":310384,"h":68719787120,"f":16777217},{"r":133169153,"p":[{"n":"timeout","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","o":"@$1","d":310384,"h":73014754416,"f":16777217},{"r":133169153,"p":[{"n":"timeout","p":140574721},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","o":"@$4","d":310384,"h":77309721712,"f":16777217},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","o":"@$3","d":310384,"h":81604689008,"f":16777217}],"c":[{"p":[{"n":"direction","p":506992},{"n":"isAsync","p":262145},{"n":"isConnected","p":262145},{"n":"safePipeHandle","p":113776}],"n":".ctor","o":"$ctor$12","d":310384,"h":4295277680,"f":16777217},{"p":[{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$11","d":310384,"h":8590244976,"f":16777217},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$10","d":310384,"h":12885212272,"f":16777217},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"desiredAccessRights","p":441456},{"n":"options","p":572528},{"n":"impersonationLevel","p":117112833},{"n":"inheritability","p":60620801}],"n":".ctor","o":"$ctor$5","d":310384,"h":17180179568,"f":16777217,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":506992}],"n":".ctor","o":"$ctor$9","d":310384,"h":21475146864,"f":16777217},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":506992},{"n":"options","p":572528}],"n":".ctor","o":"$ctor$8","d":310384,"h":25770114160,"f":16777217},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":506992},{"n":"options","p":572528},{"n":"impersonationLevel","p":117112833}],"n":".ctor","o":"$ctor$7","d":310384,"h":30065081456,"f":16777217},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":506992},{"n":"options","p":572528},{"n":"impersonationLevel","p":117112833},{"n":"inheritability","p":60620801}],"n":".ctor","o":"$ctor$6","d":310384,"h":34360048752,"f":16777217}],"i":[57540609,56950785],"h":310384}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.NamedPipeClientStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.NamedPipeServerStream", ($self) => class NamedPipeServerStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            /*int*/ static MaxAllowedServerInstances = -1;
            $ctor$11(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$10(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options, /*int*/ inBufferSize, /*int*/ outBufferSize)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*System.IAsyncResult */ BeginWaitForConnection(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Disconnect()
            {
            }
            /*void */ EndWaitForConnection(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*string */ GetImpersonationUserName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RunAsClient(/*System.IO.Pipes.PipeStreamImpersonationWorker*/ impersonationWorker)
            {
            }
            /*void */ WaitForConnection()
            {
            }
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 375920;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":638064,"m":[{"r":57016321,"p":[{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginWaitForConnection","d":375920,"h":38655081584,"f":16777217},{"r":65537,"n":"Disconnect","d":375920,"h":42950048880,"f":16777217},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWaitForConnection","d":375920,"h":47245016176,"f":16777217},{"r":1310721,"n":"GetImpersonationUserName","d":375920,"h":55834950768,"f":16777217},{"r":65537,"p":[{"n":"impersonationWorker","p":703600}],"n":"RunAsClient","d":375920,"h":60129918064,"f":16777217},{"r":65537,"n":"WaitForConnection","d":375920,"h":64424885360,"f":16777217},{"r":133169153,"n":"WaitForConnectionAsync","d":375920,"h":68719852656,"f":16777217},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"WaitForConnectionAsync","o":"@$1","d":375920,"h":73014819952,"f":16777217}],"l":[{"t":655361,"n":"MaxAllowedServerInstances","d":375920,"h":4295343216,"f":4194337}],"c":[{"p":[{"n":"direction","p":506992},{"n":"isAsync","p":262145},{"n":"isConnected","p":262145},{"n":"safePipeHandle","p":113776}],"n":".ctor","o":"$ctor$11","d":375920,"h":8590310512,"f":16777217},{"p":[{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$10","d":375920,"h":12885277808,"f":16777217},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":506992}],"n":".ctor","o":"$ctor$9","d":375920,"h":17180245104,"f":16777217},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":506992},{"n":"maxNumberOfServerInstances","p":655361}],"n":".ctor","o":"$ctor$8","d":375920,"h":21475212400,"f":16777217},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":506992},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":769136}],"n":".ctor","o":"$ctor$7","d":375920,"h":25770179696,"f":16777217},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":506992},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":769136},{"n":"options","p":572528}],"n":".ctor","o":"$ctor$6","d":375920,"h":30065146992,"f":16777217},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":506992},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":769136},{"n":"options","p":572528},{"n":"inBufferSize","p":655361},{"n":"outBufferSize","p":655361}],"n":".ctor","o":"$ctor$5","d":375920,"h":34360114288,"f":16777217}],"i":[57540609,56950785],"h":375920}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.NamedPipeServerStream`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl", "NetJs.System.Threading.Overlapped"))