
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stt, $ssc, $sspw, $ssa, $sto) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Pipes", 
    {"h":39165,"f":"System.IO.Pipes","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Pipes","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Pipes","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sip.System.IO.Pipes.PipeStream", ($self) => class PipeStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.IO.Pipes.PipeDirection*/ direction, /*int*/ bufferSize)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*int*/ outBufferSize)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsConnected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IsConnected(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsHandleExposed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMessageComplete()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OutBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get ReadMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get SafePipeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CheckPipePropertyOperations()
            {
            }
            /*void */ CheckReadOperations()
            {
            }
            /*void */ CheckWriteOperations()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ InitializeHandle(/*Microsoft.Win32.SafeHandles.SafePipeHandle?*/ handle, /*bool*/ isExposed, /*bool*/ isAsync)
            {
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ WaitForPipeDrain()
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 628989;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180498173,"f":32769},"n":"CanRead","d":628989,"h":12885530877,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":25770432765,"f":32769},"n":"CanSeek","d":628989,"h":21475465469,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360367357,"f":32769},"n":"CanWrite","d":628989,"h":30065400061,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":42950301949,"f":129},"n":"InBufferSize","d":628989,"h":38655334653,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":51540236541,"f":1},"n":"IsAsync","d":628989,"h":47245269245,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60130171133,"f":1},"s":{"r":0,"d":0,"h":64425138429,"f":4},"n":"IsConnected","d":628989,"h":55835203837,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73015073021,"f":4},"n":"IsHandleExposed","d":628989,"h":68720105725,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":81605007613,"f":1},"n":"IsMessageComplete","d":628989,"h":77310040317,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":90194942205,"f":32769},"n":"Length","d":628989,"h":85899974909,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":98784876797,"f":129},"n":"OutBufferSize","d":628989,"h":94489909501,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":107374811389,"f":32769},"s":{"r":0,"d":0,"h":111669778685,"f":32769},"n":"Position","d":628989,"h":103079844093,"f":32769},{"p":760061,"g":{"r":0,"d":0,"h":120259713277,"f":129},"s":{"r":0,"d":0,"h":124554680573,"f":129},"n":"ReadMode","d":628989,"h":115964745981,"f":129},{"p":104701,"g":{"r":0,"d":0,"h":133144615165,"f":1},"n":"SafePipeHandle","d":628989,"h":128849647869,"f":1},{"p":760061,"g":{"r":0,"d":0,"h":141734549757,"f":129},"n":"TransmissionMode","d":628989,"h":137439582461,"f":129}],"m":[{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginRead","d":628989,"h":146029517053,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginWrite","d":628989,"h":150324484349,"f":32769},{"r":65537,"n":"CheckPipePropertyOperations","d":628989,"h":154619451645,"f":144},{"r":65537,"n":"CheckReadOperations","d":628989,"h":158914418941,"f":16},{"r":65537,"n":"CheckWriteOperations","d":628989,"h":163209386237,"f":16},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":628989,"h":167504353533,"f":32772},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":628989,"h":171799320829,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":628989,"h":176094288125,"f":32769},{"r":65537,"n":"Flush","d":628989,"h":180389255421,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":628989,"h":184684222717,"f":32769},{"r":65537,"p":[{"n":"handle","p":104701},{"n":"isExposed","p":262145},{"n":"isAsync","p":262145}],"n":"InitializeHandle","d":628989,"h":188979190013,"f":4},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":628989,"h":193274157309,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":628989,"h":197569124605,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":628989,"h":201864091901,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":628989,"h":206159059197,"f":32769},{"r":655361,"n":"ReadByte","d":628989,"h":210454026493,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":628989,"h":214748993789,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":628989,"h":219043961085,"f":32769},{"r":65537,"n":"WaitForPipeDrain","d":628989,"h":223338928381,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":628989,"h":227633895677,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":628989,"h":231928862973,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":628989,"h":236223830269,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":628989,"h":240518797565,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":628989,"h":244813764861,"f":32769}],"c":[{"p":[{"n":"direction","p":497917},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$3","d":628989,"h":4295596285,"f":4},{"p":[{"n":"direction","p":497917},{"n":"transmissionMode","p":760061},{"n":"outBufferSize","p":655361}],"n":".ctor","o":"$ctor$4","d":628989,"h":8590563581,"f":4}],"i":[57540609,56950785],"h":628989}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.PipeStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.PipeStreamImpersonationWorker", ($self) => class PipeStreamImpersonationWorker extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke()
            {
                return this.$nativeFunction.call(this.$target, );
            }
            static $h = 694525;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"n":"Invoke","d":694525,"h":8590629117,"f":129},{"r":57016321,"p":[{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":694525,"h":12885596413,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":694525,"h":17180563709,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":694525,"h":4295661821,"f":1}],"i":[57212929,113377281],"h":694525}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.Pipes.PipeStreamImpersonationWorker`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeAccessRights", ($self) => class PipeAccessRights extends $.$spc.System.Enum
        {
            static ReadData = 1;
            static WriteData = 2;
            static CreateNewInstance = 4;
            static ReadExtendedAttributes = 8;
            static WriteExtendedAttributes = 16;
            static ReadAttributes = 128;
            static WriteAttributes = 256;
            static Write = 274;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static Read = 131209;
            static ReadWrite = 131483;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static Synchronize = 1048576;
            static FullControl = 2032031;
            static AccessSystemSecurity = 16777216;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ReadData": 1n,
                    "WriteData": 2n,
                    "CreateNewInstance": 4n,
                    "ReadExtendedAttributes": 8n,
                    "WriteExtendedAttributes": 16n,
                    "ReadAttributes": 128n,
                    "WriteAttributes": 256n,
                    "Write": 274n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "Read": 131209n,
                    "ReadWrite": 131483n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "Synchronize": 1048576n,
                    "FullControl": 2032031n,
                    "AccessSystemSecurity": 16777216n
                };
            }
            static $h = 432381;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":432381,"n":"ReadData","d":432381,"h":4295399677,"f":33},{"t":432381,"n":"WriteData","d":432381,"h":8590366973,"f":33},{"t":432381,"n":"CreateNewInstance","d":432381,"h":12885334269,"f":33},{"t":432381,"n":"ReadExtendedAttributes","d":432381,"h":17180301565,"f":33},{"t":432381,"n":"WriteExtendedAttributes","d":432381,"h":21475268861,"f":33},{"t":432381,"n":"ReadAttributes","d":432381,"h":25770236157,"f":33},{"t":432381,"n":"WriteAttributes","d":432381,"h":30065203453,"f":33},{"t":432381,"n":"Write","d":432381,"h":34360170749,"f":33},{"t":432381,"n":"Delete","d":432381,"h":38655138045,"f":33},{"t":432381,"n":"ReadPermissions","d":432381,"h":42950105341,"f":33},{"t":432381,"n":"Read","d":432381,"h":47245072637,"f":33},{"t":432381,"n":"ReadWrite","d":432381,"h":51540039933,"f":33},{"t":432381,"n":"ChangePermissions","d":432381,"h":55835007229,"f":33},{"t":432381,"n":"TakeOwnership","d":432381,"h":60129974525,"f":33},{"t":432381,"n":"Synchronize","d":432381,"h":64424941821,"f":33},{"t":432381,"n":"FullControl","d":432381,"h":68719909117,"f":33},{"t":432381,"n":"AccessSystemSecurity","d":432381,"h":73014876413,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":432381,"h":77309843709,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":432381,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeAccessRights`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeDirection", ($self) => class PipeDirection extends $.$spc.System.Enum
        {
            static In = 1;
            static Out = 2;
            static InOut = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "In": 1n,
                    "Out": 2n,
                    "InOut": 3n
                };
            }
            static $h = 497917;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":497917,"n":"In","d":497917,"h":4295465213,"f":33},{"t":497917,"n":"Out","d":497917,"h":8590432509,"f":33},{"t":497917,"n":"InOut","d":497917,"h":12885399805,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":497917,"h":17180367101,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":497917}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeDirection`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeOptions", ($self) => class PipeOptions extends $.$spc.System.Enum
        {
            static WriteThrough = -2147483648;
            static None = 0;
            static CurrentUserOnly = 536870912;
            static Asynchronous = 1073741824;
            static FirstPipeInstance = 524288;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "WriteThrough": -2147483648n,
                    "None": 0n,
                    "CurrentUserOnly": 536870912n,
                    "Asynchronous": 1073741824n,
                    "FirstPipeInstance": 524288n
                };
            }
            static $h = 563453;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":563453,"n":"WriteThrough","d":563453,"h":4295530749,"f":33},{"t":563453,"n":"None","d":563453,"h":8590498045,"f":33},{"t":563453,"n":"CurrentUserOnly","d":563453,"h":12885465341,"f":33},{"t":563453,"n":"Asynchronous","d":563453,"h":17180432637,"f":33},{"t":563453,"n":"FirstPipeInstance","d":563453,"h":21475399933,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":563453,"h":25770367229,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":563453,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeOptions`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeTransmissionMode", ($self) => class PipeTransmissionMode extends $.$spc.System.Enum
        {
            static Byte = 0;
            static Message = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Byte": 0n,
                    "Message": 1n
                };
            }
            static $h = 760061;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":760061,"n":"Byte","d":760061,"h":4295727357,"f":33},{"t":760061,"n":"Message","d":760061,"h":8590694653,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":760061,"h":12885661949,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":760061}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeTransmissionMode`; }
        });
        
        $asm.$cls("$sip.Microsoft.Win32.SafeHandles.SafePipeHandle", ($self) => class SafePipeHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 104701;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17179973885,"f":32769},"n":"IsInvalid","d":104701,"h":12885006589,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":104701,"h":21474941181,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":104701,"h":4295071997,"f":1},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":104701,"h":8590039293,"f":1}],"i":[57540609],"h":104701}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafePipeHandle`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.AnonymousPipeClientStream", ($self) => class AnonymousPipeClientStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction, /*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 170237;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":628989,"p":[{"p":760061,"s":{"r":0,"d":0,"h":21475006717,"f":32769},"n":"ReadMode","d":170237,"h":17180039421,"f":32769},{"p":760061,"g":{"r":0,"d":0,"h":30064941309,"f":32769},"n":"TransmissionMode","d":170237,"h":25769974013,"f":32769}],"c":[{"p":[{"n":"direction","p":497917},{"n":"safePipeHandle","p":104701}],"n":".ctor","o":"$ctor$5","d":170237,"h":4295137533,"f":1},{"p":[{"n":"direction","p":497917},{"n":"pipeHandleAsString","p":1310721}],"n":".ctor","o":"$ctor$6","d":170237,"h":8590104829,"f":1},{"p":[{"n":"pipeHandleAsString","p":1310721}],"n":".ctor","o":"$ctor$7","d":170237,"h":12885072125,"f":1}],"i":[57540609,56950785],"h":170237}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.AnonymousPipeClientStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.AnonymousPipeServerStream", ($self) => class AnonymousPipeServerStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5()
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ serverSafePipeHandle, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ clientSafePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability, /*int*/ bufferSize)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get ClientSafePipeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ DisposeLocalCopyOfClientHandle()
            {
            }
            $dtor()
            {
            }
            /*string */ GetClientHandleAsString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 235773;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":628989,"p":[{"p":104701,"g":{"r":0,"d":0,"h":30065006845,"f":1},"n":"ClientSafePipeHandle","d":235773,"h":25770039549,"f":1},{"p":760061,"s":{"r":0,"d":0,"h":38654941437,"f":32769},"n":"ReadMode","d":235773,"h":34359974141,"f":32769},{"p":760061,"g":{"r":0,"d":0,"h":47244876029,"f":32769},"n":"TransmissionMode","d":235773,"h":42949908733,"f":32769}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":235773,"h":51539843325,"f":32772},{"r":65537,"n":"DisposeLocalCopyOfClientHandle","d":235773,"h":55834810621,"f":1},{"r":1310721,"n":"GetClientHandleAsString","d":235773,"h":64424745213,"f":1}],"c":[{"n":".ctor","o":"$ctor$5","d":235773,"h":4295203069,"f":1},{"p":[{"n":"direction","p":497917}],"n":".ctor","o":"$ctor$6","d":235773,"h":8590170365,"f":1},{"p":[{"n":"direction","p":497917},{"n":"serverSafePipeHandle","p":104701},{"n":"clientSafePipeHandle","p":104701}],"n":".ctor","o":"$ctor$7","d":235773,"h":12885137661,"f":1},{"p":[{"n":"direction","p":497917},{"n":"inheritability","p":60620801}],"n":".ctor","o":"$ctor$8","d":235773,"h":17180104957,"f":1},{"p":[{"n":"direction","p":497917},{"n":"inheritability","p":60620801},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$9","d":235773,"h":21475072253,"f":1}],"i":[57540609,56950785],"h":235773}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.AnonymousPipeServerStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.NamedPipeClientStream", ($self) => class NamedPipeClientStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ serverName, /*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeAccessRights*/ desiredAccessRights, /*PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$10(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$11(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$12(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*int */ get NumberOfServerInstances()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CheckPipePropertyOperations()
            {
            }
            /*void */ Connect()
            {
            }
            /*void */ Connect$1(/*int*/ timeout)
            {
            }
            /*void */ Connect$2(/*System.TimeSpan*/ timeout)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$1(/*int*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*int*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$3(/*System.TimeSpan*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 301309;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":628989,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42949974269,"f":1},"n":"NumberOfServerInstances","d":301309,"h":38655006973,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"m":[{"r":65537,"n":"CheckPipePropertyOperations","d":301309,"h":47244941565,"f":32784},{"r":65537,"n":"Connect","d":301309,"h":51539908861,"f":1},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Connect","o":"@$1","d":301309,"h":55834876157,"f":1},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"Connect","o":"@$2","d":301309,"h":60129843453,"f":1},{"r":133300225,"n":"ConnectAsync","d":301309,"h":64424810749,"f":1},{"r":133300225,"p":[{"n":"timeout","p":655361}],"n":"ConnectAsync","o":"@$1","d":301309,"h":68719778045,"f":1},{"r":133300225,"p":[{"n":"timeout","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$2","d":301309,"h":73014745341,"f":1},{"r":133300225,"p":[{"n":"timeout","p":140705793},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":301309,"h":77309712637,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$4","d":301309,"h":81604679933,"f":1}],"c":[{"p":[{"n":"direction","p":497917},{"n":"isAsync","p":262145},{"n":"isConnected","p":262145},{"n":"safePipeHandle","p":104701}],"n":".ctor","o":"$ctor$5","d":301309,"h":4295268605,"f":1},{"p":[{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$6","d":301309,"h":8590235901,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$7","d":301309,"h":12885203197,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"desiredAccessRights","p":432381},{"n":"options","p":563453},{"n":"impersonationLevel","p":117243905},{"n":"inheritability","p":60620801}],"n":".ctor","o":"$ctor$8","d":301309,"h":17180170493,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":497917}],"n":".ctor","o":"$ctor$9","d":301309,"h":21475137789,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":497917},{"n":"options","p":563453}],"n":".ctor","o":"$ctor$10","d":301309,"h":25770105085,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":497917},{"n":"options","p":563453},{"n":"impersonationLevel","p":117243905}],"n":".ctor","o":"$ctor$11","d":301309,"h":30065072381,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":497917},{"n":"options","p":563453},{"n":"impersonationLevel","p":117243905},{"n":"inheritability","p":60620801}],"n":".ctor","o":"$ctor$12","d":301309,"h":34360039677,"f":1}],"i":[57540609,56950785],"h":301309}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.NamedPipeClientStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.NamedPipeServerStream", ($self) => class NamedPipeServerStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            /*int*/ static MaxAllowedServerInstances = -1;
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$10(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$11(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options, /*int*/ inBufferSize, /*int*/ outBufferSize)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*System.IAsyncResult */ BeginWaitForConnection(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Disconnect()
            {
            }
            /*void */ EndWaitForConnection(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*string */ GetImpersonationUserName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RunAsClient(/*System.IO.Pipes.PipeStreamImpersonationWorker*/ impersonationWorker)
            {
            }
            /*void */ WaitForConnection()
            {
            }
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 366845;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":628989,"m":[{"r":57016321,"p":[{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginWaitForConnection","d":366845,"h":38655072509,"f":1},{"r":65537,"n":"Disconnect","d":366845,"h":42950039805,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWaitForConnection","d":366845,"h":47245007101,"f":1},{"r":1310721,"n":"GetImpersonationUserName","d":366845,"h":55834941693,"f":1},{"r":65537,"p":[{"n":"impersonationWorker","p":694525}],"n":"RunAsClient","d":366845,"h":60129908989,"f":1},{"r":65537,"n":"WaitForConnection","d":366845,"h":64424876285,"f":1},{"r":133300225,"n":"WaitForConnectionAsync","d":366845,"h":68719843581,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitForConnectionAsync","o":"@$1","d":366845,"h":73014810877,"f":1}],"l":[{"t":655361,"n":"MaxAllowedServerInstances","d":366845,"h":4295334141,"f":33}],"c":[{"p":[{"n":"direction","p":497917},{"n":"isAsync","p":262145},{"n":"isConnected","p":262145},{"n":"safePipeHandle","p":104701}],"n":".ctor","o":"$ctor$5","d":366845,"h":8590301437,"f":1},{"p":[{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$6","d":366845,"h":12885268733,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":497917}],"n":".ctor","o":"$ctor$7","d":366845,"h":17180236029,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":497917},{"n":"maxNumberOfServerInstances","p":655361}],"n":".ctor","o":"$ctor$8","d":366845,"h":21475203325,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":497917},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":760061}],"n":".ctor","o":"$ctor$9","d":366845,"h":25770170621,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":497917},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":760061},{"n":"options","p":563453}],"n":".ctor","o":"$ctor$10","d":366845,"h":30065137917,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":497917},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":760061},{"n":"options","p":563453},{"n":"inBufferSize","p":655361},{"n":"outBufferSize","p":655361}],"n":".ctor","o":"$ctor$11","d":366845,"h":34360105213,"f":1}],"i":[57540609,56950785],"h":366845}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.NamedPipeServerStream`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl", "NetJs.System.Threading.Overlapped"))