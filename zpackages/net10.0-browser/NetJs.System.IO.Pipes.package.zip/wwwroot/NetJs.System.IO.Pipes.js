
//--TRIMMABLE-BOUNDARY-START(80)
(async function () {
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stt, $ssc, $sspw, $ssa, $sto) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.IO.Pipes", 
    {
  "h": 80,
  "f": "System.IO.Pipes",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.IO.Pipes",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.IO.Pipes",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(589904)
        $asm.$cls(`$sip.SIP.PipeStream`, ($self) => class PipeStream extends $.$$.SI.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(4295557200)
            $ctor$3(/*System.IO.Pipes.PipeDirection*/ direction, /*int*/ bufferSize)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295557200);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557200)
            
            //--TRIMMABLE-BOUNDARY-START(8590524496)
            $ctor$4(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*int*/ outBufferSize)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590524496);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524496)
            
            //--TRIMMABLE-BOUNDARY-START(21475426384)
            /*bool */ get CanRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475426384)
            
            //--TRIMMABLE-BOUNDARY-START(25770393680)
            /*bool */ get CanSeek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604968528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770393680)
            
            //--TRIMMABLE-BOUNDARY-START(30065360976)
            /*bool */ get CanWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065360976)
            
            //--TRIMMABLE-BOUNDARY-START(188979150928)
            /*int */ get InBufferSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784837712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(188979150928)
            
            //--TRIMMABLE-BOUNDARY-START(197569085520)
            /*bool */ get IsAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374772304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(197569085520)
            
            //--TRIMMABLE-BOUNDARY-START(201864052816)
            /*bool */ get IsConnected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IsConnected(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288562256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(201864052816)
            
            //--TRIMMABLE-BOUNDARY-START(206159020112)
            /*bool */ get IsHandleExposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554641488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(206159020112)
            
            //--TRIMMABLE-BOUNDARY-START(210453987408)
            /*bool */ get IsMessageComplete()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144576080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(210453987408)
            
            //--TRIMMABLE-BOUNDARY-START(214748954704)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734510672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(214748954704)
            
            //--TRIMMABLE-BOUNDARY-START(219043922000)
            /*int */ get OutBufferSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324445264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(219043922000)
            
            //--TRIMMABLE-BOUNDARY-START(223338889296)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914379856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878496848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(223338889296)
            
            //--TRIMMABLE-BOUNDARY-START(249108693072)
            /*System.IO.Pipes.PipeTransmissionMode */ get ReadMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504314448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468431440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(249108693072)
            
            //--TRIMMABLE-BOUNDARY-START(253403660368)
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get SafePipeHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094249040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(253403660368)
            
            //--TRIMMABLE-BOUNDARY-START(292058366032)
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684183632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(292058366032)
            
            //--TRIMMABLE-BOUNDARY-START(12885491792)
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885491792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885491792)
            
            //--TRIMMABLE-BOUNDARY-START(17180459088)
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180459088)
            
            //--TRIMMABLE-BOUNDARY-START(34360328272)
            /*void */ CheckPipePropertyOperations()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34360328272)
            
            //--TRIMMABLE-BOUNDARY-START(38655295568)
            /*void */ CheckReadOperations()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38655295568)
            
            //--TRIMMABLE-BOUNDARY-START(42950262864)
            /*void */ CheckWriteOperations()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42950262864)
            
            //--TRIMMABLE-BOUNDARY-START(47245230160)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245230160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47245230160)
            
            //--TRIMMABLE-BOUNDARY-START(51540197456)
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540197456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540197456)
            
            //--TRIMMABLE-BOUNDARY-START(55835164752)
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835164752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(55835164752)
            
            //--TRIMMABLE-BOUNDARY-START(60130132048)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130132048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60130132048)
            
            //--TRIMMABLE-BOUNDARY-START(64425099344)
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425099344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64425099344)
            
            //--TRIMMABLE-BOUNDARY-START(193274118224)
            /*void */ InitializeHandle(/*Microsoft.Win32.SafeHandles.SafePipeHandle?*/ handle, /*bool*/ isExposed, /*bool*/ isAsync)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274118224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(193274118224)
            
            //--TRIMMABLE-BOUNDARY-START(227633856592)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633856592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(227633856592)
            
            //--TRIMMABLE-BOUNDARY-START(231928823888)
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928823888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(231928823888)
            
            //--TRIMMABLE-BOUNDARY-START(236223791184)
            /*System.Threading.Tasks.Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223791184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(236223791184)
            
            //--TRIMMABLE-BOUNDARY-START(240518758480)
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518758480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(240518758480)
            
            //--TRIMMABLE-BOUNDARY-START(244813725776)
            /*int */ ReadByte()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813725776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(244813725776)
            
            //--TRIMMABLE-BOUNDARY-START(257698627664)
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698627664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(257698627664)
            
            //--TRIMMABLE-BOUNDARY-START(287763398736)
            /*void */ SetLength(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763398736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(287763398736)
            
            //--TRIMMABLE-BOUNDARY-START(296353333328)
            /*void */ WaitForPipeDrain()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353333328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(296353333328)
            
            //--TRIMMABLE-BOUNDARY-START(300648300624)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648300624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(300648300624)
            
            //--TRIMMABLE-BOUNDARY-START(304943267920)
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943267920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(304943267920)
            
            //--TRIMMABLE-BOUNDARY-START(309238235216)
            /*System.Threading.Tasks.Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238235216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(309238235216)
            
            //--TRIMMABLE-BOUNDARY-START(313533202512)
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533202512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(313533202512)
            
            //--TRIMMABLE-BOUNDARY-START(317828169808)
            /*void */ WriteByte(/*byte*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828169808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(317828169808)
            
            static $h = 589904;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.Stream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475426384),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015033936,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 589904,
      "h": 21475426384,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475426384),
//--TRIMMABLE-BOUNDARY-START(25770393680),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604968528,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 589904,
      "h": 25770393680,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770393680),
//--TRIMMABLE-BOUNDARY-START(30065360976),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194903120,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 589904,
      "h": 30065360976,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065360976),
//--TRIMMABLE-BOUNDARY-START(188979150928),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784837712,
        "f": 50331777
      },
      "n": "InBufferSize",
      "d": 589904,
      "h": 188979150928,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(188979150928),
//--TRIMMABLE-BOUNDARY-START(197569085520),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374772304,
        "f": 50331649
      },
      "n": "IsAsync",
      "d": 589904,
      "h": 197569085520,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569085520),
//--TRIMMABLE-BOUNDARY-START(201864052816),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964706896,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288562256,
        "f": 83886084
      },
      "n": "IsConnected",
      "d": 589904,
      "h": 201864052816,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864052816),
//--TRIMMABLE-BOUNDARY-START(206159020112),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554641488,
        "f": 50331652
      },
      "n": "IsHandleExposed",
      "d": 589904,
      "h": 206159020112,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(206159020112),
//--TRIMMABLE-BOUNDARY-START(210453987408),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144576080,
        "f": 50331649
      },
      "n": "IsMessageComplete",
      "d": 589904,
      "h": 210453987408,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210453987408),
//--TRIMMABLE-BOUNDARY-START(214748954704),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734510672,
        "f": 50364417
      },
      "n": "Length",
      "d": 589904,
      "h": 214748954704,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(214748954704),
//--TRIMMABLE-BOUNDARY-START(219043922000),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324445264,
        "f": 50331777
      },
      "n": "OutBufferSize",
      "d": 589904,
      "h": 219043922000,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(219043922000),
//--TRIMMABLE-BOUNDARY-START(223338889296),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914379856,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274878496848,
        "f": 83918849
      },
      "n": "Position",
      "d": 589904,
      "h": 223338889296,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(223338889296),
//--TRIMMABLE-BOUNDARY-START(249108693072),
    {
      "p": 720976,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504314448,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283468431440,
        "f": 83886209
      },
      "n": "ReadMode",
      "d": 589904,
      "h": 249108693072,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(249108693072),
//--TRIMMABLE-BOUNDARY-START(253403660368),
    {
      "p": 65616,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094249040,
        "f": 50331649
      },
      "n": "SafePipeHandle",
      "d": 589904,
      "h": 253403660368,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253403660368),
//--TRIMMABLE-BOUNDARY-START(292058366032),
    {
      "p": 720976,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684183632,
        "f": 50331777
      },
      "n": "TransmissionMode",
      "d": 589904,
      "h": 292058366032,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(292058366032)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885491792),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginRead",
      "d": 589904,
      "h": 12885491792,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885491792),
//--TRIMMABLE-BOUNDARY-START(17180459088),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginWrite",
      "d": 589904,
      "h": 17180459088,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180459088),
//--TRIMMABLE-BOUNDARY-START(34360328272),
    {
      "r": 65537,
      "n": "CheckPipePropertyOperations",
      "d": 589904,
      "h": 34360328272,
      "f": 16777360
    },
//--TRIMMABLE-BOUNDARY-END(34360328272),
//--TRIMMABLE-BOUNDARY-START(38655295568),
    {
      "r": 65537,
      "n": "CheckReadOperations",
      "d": 589904,
      "h": 38655295568,
      "f": 16777232
    },
//--TRIMMABLE-BOUNDARY-END(38655295568),
//--TRIMMABLE-BOUNDARY-START(42950262864),
    {
      "r": 65537,
      "n": "CheckWriteOperations",
      "d": 589904,
      "h": 42950262864,
      "f": 16777232
    },
//--TRIMMABLE-BOUNDARY-END(42950262864),
//--TRIMMABLE-BOUNDARY-START(47245230160),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 589904,
      "h": 47245230160,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47245230160),
//--TRIMMABLE-BOUNDARY-START(51540197456),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndRead",
      "d": 589904,
      "h": 51540197456,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540197456),
//--TRIMMABLE-BOUNDARY-START(55835164752),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndWrite",
      "d": 589904,
      "h": 55835164752,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835164752),
//--TRIMMABLE-BOUNDARY-START(60130132048),
    {
      "r": 65537,
      "n": "Flush",
      "d": 589904,
      "h": 60130132048,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130132048),
//--TRIMMABLE-BOUNDARY-START(64425099344),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 589904,
      "h": 64425099344,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425099344),
//--TRIMMABLE-BOUNDARY-START(193274118224),
    {
      "r": 65537,
      "p": [
        {
          "n": "handle",
          "p": 65616
        },
        {
          "n": "isExposed",
          "p": 262145
        },
        {
          "n": "isAsync",
          "p": 262145
        }
      ],
      "n": "InitializeHandle",
      "d": 589904,
      "h": 193274118224,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(193274118224),
//--TRIMMABLE-BOUNDARY-START(227633856592),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 589904,
      "h": 227633856592,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(227633856592),
//--TRIMMABLE-BOUNDARY-START(231928823888),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 589904,
      "h": 231928823888,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(231928823888),
//--TRIMMABLE-BOUNDARY-START(236223791184),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "d": 589904,
      "h": 236223791184,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(236223791184),
//--TRIMMABLE-BOUNDARY-START(240518758480),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 589904,
      "h": 240518758480,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(240518758480),
//--TRIMMABLE-BOUNDARY-START(244813725776),
    {
      "r": 655361,
      "n": "ReadByte",
      "d": 589904,
      "h": 244813725776,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(244813725776),
//--TRIMMABLE-BOUNDARY-START(257698627664),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 589904,
      "h": 257698627664,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(257698627664),
//--TRIMMABLE-BOUNDARY-START(287763398736),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 589904,
      "h": 287763398736,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(287763398736),
//--TRIMMABLE-BOUNDARY-START(296353333328),
    {
      "r": 65537,
      "n": "WaitForPipeDrain",
      "d": 589904,
      "h": 296353333328,
      "f": 16777217,
      "a": [
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(296353333328),
//--TRIMMABLE-BOUNDARY-START(300648300624),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 589904,
      "h": 300648300624,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(300648300624),
//--TRIMMABLE-BOUNDARY-START(304943267920),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 589904,
      "h": 304943267920,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(304943267920),
//--TRIMMABLE-BOUNDARY-START(309238235216),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "d": 589904,
      "h": 309238235216,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(309238235216),
//--TRIMMABLE-BOUNDARY-START(313533202512),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 589904,
      "h": 313533202512,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(313533202512),
//--TRIMMABLE-BOUNDARY-START(317828169808),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        }
      ],
      "n": "WriteByte",
      "d": 589904,
      "h": 317828169808,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(317828169808)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557200),
    {
      "p": [
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589904,
      "h": 4295557200,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295557200),
//--TRIMMABLE-BOUNDARY-START(8590524496),
    {
      "p": [
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "transmissionMode",
          "p": 720976
        },
        {
          "n": "outBufferSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 589904,
      "h": 8590524496,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590524496)
  ],
  "h": 589904
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipes.PipeStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipes${separator}PipeStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589904)
        
        

        //--TRIMMABLE-BOUNDARY-START(655440)
        $asm.$cls(`$sip.SIP.PipeStreamImpersonationWorker`, ($self) => class PipeStreamImpersonationWorker extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke()
            {
                return this.$nativeFunction.call(this.$target, );
            }
            static $h = 655440;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180524624),
    {
      "r": 65537,
      "n": "Invoke",
      "d": 655440,
      "h": 17180524624,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180524624),
//--TRIMMABLE-BOUNDARY-START(8590590032),
    {
      "r": 90570753,
      "p": [
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 655440,
      "h": 8590590032,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590590032),
//--TRIMMABLE-BOUNDARY-START(12885557328),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 655440,
      "h": 12885557328,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885557328)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622736),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 655440,
      "h": 4295622736,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622736)
  ],
  "h": 655440
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipes.PipeStreamImpersonationWorker`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipes${separator}PipeStreamImpersonationWorker`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655440)
        
        

        //--TRIMMABLE-BOUNDARY-START(393296)
        $asm.$str(`$sip.SIP.PipeAccessRights`, ($self) => class PipeAccessRights extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static ReadData = 1;
            static WriteData = 2;
            static CreateNewInstance = 4;
            static ReadExtendedAttributes = 8;
            static WriteExtendedAttributes = 16;
            static ReadAttributes = 128;
            static WriteAttributes = 256;
            static Write = 274;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static Read = 131209;
            static ReadWrite = 131483;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static Synchronize = 1048576;
            static FullControl = 2032031;
            static AccessSystemSecurity = 16777216;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "ReadData": 1n,
                    "WriteData": 2n,
                    "CreateNewInstance": 4n,
                    "ReadExtendedAttributes": 8n,
                    "WriteExtendedAttributes": 16n,
                    "ReadAttributes": 128n,
                    "WriteAttributes": 256n,
                    "Write": 274n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "Read": 131209n,
                    "ReadWrite": 131483n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "Synchronize": 1048576n,
                    "FullControl": 2032031n,
                    "AccessSystemSecurity": 16777216n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295360592)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360592)
            
            //--TRIMMABLE-BOUNDARY-START(4295360592)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295360592)
            
            static $h = 393296;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655098960),
    {
      "t": 393296,
      "n": "ReadData",
      "d": 393296,
      "h": 38655098960,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655098960),
//--TRIMMABLE-BOUNDARY-START(73014837328),
    {
      "t": 393296,
      "n": "WriteData",
      "d": 393296,
      "h": 73014837328,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014837328),
//--TRIMMABLE-BOUNDARY-START(17180262480),
    {
      "t": 393296,
      "n": "CreateNewInstance",
      "d": 393296,
      "h": 17180262480,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180262480),
//--TRIMMABLE-BOUNDARY-START(42950066256),
    {
      "t": 393296,
      "n": "ReadExtendedAttributes",
      "d": 393296,
      "h": 42950066256,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950066256),
//--TRIMMABLE-BOUNDARY-START(77309804624),
    {
      "t": 393296,
      "n": "WriteExtendedAttributes",
      "d": 393296,
      "h": 77309804624,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77309804624),
//--TRIMMABLE-BOUNDARY-START(34360131664),
    {
      "t": 393296,
      "n": "ReadAttributes",
      "d": 393296,
      "h": 34360131664,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360131664),
//--TRIMMABLE-BOUNDARY-START(68719870032),
    {
      "t": 393296,
      "n": "WriteAttributes",
      "d": 393296,
      "h": 68719870032,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68719870032),
//--TRIMMABLE-BOUNDARY-START(64424902736),
    {
      "t": 393296,
      "n": "Write",
      "d": 393296,
      "h": 64424902736,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424902736),
//--TRIMMABLE-BOUNDARY-START(21475229776),
    {
      "t": 393296,
      "n": "Delete",
      "d": 393296,
      "h": 21475229776,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475229776),
//--TRIMMABLE-BOUNDARY-START(47245033552),
    {
      "t": 393296,
      "n": "ReadPermissions",
      "d": 393296,
      "h": 47245033552,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245033552),
//--TRIMMABLE-BOUNDARY-START(30065164368),
    {
      "t": 393296,
      "n": "Read",
      "d": 393296,
      "h": 30065164368,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065164368),
//--TRIMMABLE-BOUNDARY-START(51540000848),
    {
      "t": 393296,
      "n": "ReadWrite",
      "d": 393296,
      "h": 51540000848,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540000848),
//--TRIMMABLE-BOUNDARY-START(12885295184),
    {
      "t": 393296,
      "n": "ChangePermissions",
      "d": 393296,
      "h": 12885295184,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885295184),
//--TRIMMABLE-BOUNDARY-START(60129935440),
    {
      "t": 393296,
      "n": "TakeOwnership",
      "d": 393296,
      "h": 60129935440,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129935440),
//--TRIMMABLE-BOUNDARY-START(55834968144),
    {
      "t": 393296,
      "n": "Synchronize",
      "d": 393296,
      "h": 55834968144,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834968144),
//--TRIMMABLE-BOUNDARY-START(25770197072),
    {
      "t": 393296,
      "n": "FullControl",
      "d": 393296,
      "h": 25770197072,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770197072),
//--TRIMMABLE-BOUNDARY-START(8590327888),
    {
      "t": 393296,
      "n": "AccessSystemSecurity",
      "d": 393296,
      "h": 8590327888,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590327888)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360592),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393296,
      "h": 4295360592,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360592)
  ],
  "h": 393296,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipes.PipeAccessRights`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipes${separator}PipeAccessRights`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393296)
        
        

        //--TRIMMABLE-BOUNDARY-START(458832)
        $asm.$str(`$sip.SIP.PipeDirection`, ($self) => class PipeDirection extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static In = 1;
            static Out = 2;
            static InOut = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(458832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "In": 1n,
                    "Out": 2n,
                    "InOut": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295426128)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426128)
            
            //--TRIMMABLE-BOUNDARY-START(4295426128)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295426128)
            
            static $h = 458832;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393424),
    {
      "t": 458832,
      "n": "In",
      "d": 458832,
      "h": 8590393424,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393424),
//--TRIMMABLE-BOUNDARY-START(17180328016),
    {
      "t": 458832,
      "n": "Out",
      "d": 458832,
      "h": 17180328016,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180328016),
//--TRIMMABLE-BOUNDARY-START(12885360720),
    {
      "t": 458832,
      "n": "InOut",
      "d": 458832,
      "h": 12885360720,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360720)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426128),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458832,
      "h": 4295426128,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426128)
  ],
  "h": 458832
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipes.PipeDirection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipes${separator}PipeDirection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458832)
        
        

        //--TRIMMABLE-BOUNDARY-START(524368)
        $asm.$str(`$sip.SIP.PipeOptions`, ($self) => class PipeOptions extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static WriteThrough = -2147483648;
            static None = 0;
            static CurrentUserOnly = 536870912;
            static Asynchronous = 1073741824;
            static FirstPipeInstance = 524288;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "WriteThrough": 2147483648n,
                    "None": 0n,
                    "CurrentUserOnly": 536870912n,
                    "Asynchronous": 1073741824n,
                    "FirstPipeInstance": 524288n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295491664)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491664)
            
            //--TRIMMABLE-BOUNDARY-START(4295491664)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295491664)
            
            static $h = 524368;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770328144),
    {
      "t": 524368,
      "n": "WriteThrough",
      "d": 524368,
      "h": 25770328144,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328144),
//--TRIMMABLE-BOUNDARY-START(21475360848),
    {
      "t": 524368,
      "n": "None",
      "d": 524368,
      "h": 21475360848,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475360848),
//--TRIMMABLE-BOUNDARY-START(12885426256),
    {
      "t": 524368,
      "n": "CurrentUserOnly",
      "d": 524368,
      "h": 12885426256,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426256),
//--TRIMMABLE-BOUNDARY-START(8590458960),
    {
      "t": 524368,
      "n": "Asynchronous",
      "d": 524368,
      "h": 8590458960,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458960),
//--TRIMMABLE-BOUNDARY-START(17180393552),
    {
      "t": 524368,
      "n": "FirstPipeInstance",
      "d": 524368,
      "h": 17180393552,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393552)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491664),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524368,
      "h": 4295491664,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491664)
  ],
  "h": 524368,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipes.PipeOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipes${separator}PipeOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524368)
        
        

        //--TRIMMABLE-BOUNDARY-START(720976)
        $asm.$str(`$sip.SIP.PipeTransmissionMode`, ($self) => class PipeTransmissionMode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Byte = 0;
            static Message = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Byte": 0n,
                    "Message": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295688272)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688272)
            
            //--TRIMMABLE-BOUNDARY-START(4295688272)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295688272)
            
            static $h = 720976;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590655568),
    {
      "t": 720976,
      "n": "Byte",
      "d": 720976,
      "h": 8590655568,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655568),
//--TRIMMABLE-BOUNDARY-START(12885622864),
    {
      "t": 720976,
      "n": "Message",
      "d": 720976,
      "h": 12885622864,
      "f": 4194337,
      "a": [
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885622864)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688272),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720976,
      "h": 4295688272,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688272)
  ],
  "h": 720976
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipes.PipeTransmissionMode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipes${separator}PipeTransmissionMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720976)
        
        

        //--TRIMMABLE-BOUNDARY-START(65616)
        $asm.$cls(`$sip.MWS.SafePipeHandle`, ($self) => class SafePipeHandle extends $.$$.MWS.SafeHandleZeroOrMinusOneIsInvalid
        {
            //--TRIMMABLE-BOUNDARY-START(4295032912)
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032912);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032912)
            
            //--TRIMMABLE-BOUNDARY-START(8590000208)
            $ctor$5(/*System.IntPtr*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000208);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000208)
            
            //--TRIMMABLE-BOUNDARY-START(21474902096)
            /*bool */ get IsInvalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21474902096)
            
            //--TRIMMABLE-BOUNDARY-START(25769869392)
            /*bool */ ReleaseHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25769869392)
            
            //--TRIMMABLE-BOUNDARY-START(4295032912)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295032912)
            
            static $h = 65616;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.MWS.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474902096),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17179934800,
        "f": 50364417
      },
      "n": "IsInvalid",
      "d": 65616,
      "h": 21474902096,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21474902096)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769869392),
    {
      "r": 262145,
      "n": "ReleaseHandle",
      "d": 65616,
      "h": 25769869392,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25769869392)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032912),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 65616,
      "h": 4295032912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032912),
//--TRIMMABLE-BOUNDARY-START(8590000208),
    {
      "p": [
        {
          "n": "preexistingHandle",
          "p": 786433
        },
        {
          "n": "ownsHandle",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 65616,
      "h": 8590000208,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000208)
  ],
  "h": 65616
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Win32.SafeHandles.SafePipeHandle`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Win32${separator}SafeHandles${separator}SafePipeHandle`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65616)
        
        

        //--TRIMMABLE-BOUNDARY-START(131152)
        $asm.$cls(`$sip.SIP.AnonymousPipeClientStream`, ($self) => class AnonymousPipeClientStream extends $.$sip.SIP.PipeStream
        {
            //--TRIMMABLE-BOUNDARY-START(4295098448)
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098448);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098448)
            
            //--TRIMMABLE-BOUNDARY-START(8590065744)
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction, /*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065744);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065744)
            
            //--TRIMMABLE-BOUNDARY-START(12885033040)
            $ctor$7(/*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033040);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033040)
            
            //--TRIMMABLE-BOUNDARY-START(30064902224)
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30064902224)
            
            //--TRIMMABLE-BOUNDARY-START(42949804112)
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42949804112)
            
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 131152;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sip.SIP.PipeStream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064902224),
    {
      "p": 720976,
      "s": {
        "r": 0,
        "d": 0,
        "h": 38654836816,
        "f": 83918849
      },
      "n": "ReadMode",
      "d": 131152,
      "h": 30064902224,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30064902224),
//--TRIMMABLE-BOUNDARY-START(42949804112),
    {
      "p": 720976,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769934928,
        "f": 50364417
      },
      "n": "TransmissionMode",
      "d": 131152,
      "h": 42949804112,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42949804112)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098448),
    {
      "p": [
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "safePipeHandle",
          "p": 65616
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 131152,
      "h": 4295098448,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098448),
//--TRIMMABLE-BOUNDARY-START(8590065744),
    {
      "p": [
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "pipeHandleAsString",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 131152,
      "h": 8590065744,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065744),
//--TRIMMABLE-BOUNDARY-START(12885033040),
    {
      "p": [
        {
          "n": "pipeHandleAsString",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 131152,
      "h": 12885033040,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885033040)
  ],
  "h": 131152
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipes.AnonymousPipeClientStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipes${separator}AnonymousPipeClientStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131152)
        
        

        //--TRIMMABLE-BOUNDARY-START(196688)
        $asm.$cls(`$sip.SIP.AnonymousPipeServerStream`, ($self) => class AnonymousPipeServerStream extends $.$sip.SIP.PipeStream
        {
            //--TRIMMABLE-BOUNDARY-START(4295163984)
            $ctor$5()
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295163984);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163984)
            
            //--TRIMMABLE-BOUNDARY-START(21475033168)
            $ctor$9(/*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475033168);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475033168)
            
            //--TRIMMABLE-BOUNDARY-START(8590131280)
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ serverSafePipeHandle, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ clientSafePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131280);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131280)
            
            //--TRIMMABLE-BOUNDARY-START(17180065872)
            $ctor$8(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065872);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065872)
            
            //--TRIMMABLE-BOUNDARY-START(12885098576)
            $ctor$7(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability, /*int*/ bufferSize)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885098576);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098576)
            
            //--TRIMMABLE-BOUNDARY-START(25770000464)
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get ClientSafePipeHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244836944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770000464)
            
            //--TRIMMABLE-BOUNDARY-START(64424706128)
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64424706128)
            
            //--TRIMMABLE-BOUNDARY-START(77309608016)
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77309608016)
            
            //--TRIMMABLE-BOUNDARY-START(30064967760)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30064967760)
            
            //--TRIMMABLE-BOUNDARY-START(34359935056)
            /*void */ DisposeLocalCopyOfClientHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359935056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34359935056)
            
            $dtor()
            {
            }
            //--TRIMMABLE-BOUNDARY-START(60129738832)
            /*string */ GetClientHandleAsString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129738832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60129738832)
            
            //--TRIMMABLE-BOUNDARY-START(4295163984)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$5();
            }
            //--TRIMMABLE-BOUNDARY-END(4295163984)
            
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 196688;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sip.SIP.PipeStream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770000464),
    {
      "p": 65616,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244836944,
        "f": 50331649
      },
      "n": "ClientSafePipeHandle",
      "d": 196688,
      "h": 25770000464,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770000464),
//--TRIMMABLE-BOUNDARY-START(64424706128),
    {
      "p": 720976,
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014640720,
        "f": 83918849
      },
      "n": "ReadMode",
      "d": 196688,
      "h": 64424706128,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64424706128),
//--TRIMMABLE-BOUNDARY-START(77309608016),
    {
      "p": 720976,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834771536,
        "f": 50364417
      },
      "n": "TransmissionMode",
      "d": 196688,
      "h": 77309608016,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77309608016)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064967760),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 196688,
      "h": 30064967760,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30064967760),
//--TRIMMABLE-BOUNDARY-START(34359935056),
    {
      "r": 65537,
      "n": "DisposeLocalCopyOfClientHandle",
      "d": 196688,
      "h": 34359935056,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359935056),
//--TRIMMABLE-BOUNDARY-START(60129738832),
    {
      "r": 1310721,
      "n": "GetClientHandleAsString",
      "d": 196688,
      "h": 60129738832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129738832)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163984),
    {
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 196688,
      "h": 4295163984,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163984),
//--TRIMMABLE-BOUNDARY-START(21475033168),
    {
      "p": [
        {
          "n": "direction",
          "p": 458832
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 196688,
      "h": 21475033168,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475033168),
//--TRIMMABLE-BOUNDARY-START(8590131280),
    {
      "p": [
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "serverSafePipeHandle",
          "p": 65616
        },
        {
          "n": "clientSafePipeHandle",
          "p": 65616
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 196688,
      "h": 8590131280,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131280),
//--TRIMMABLE-BOUNDARY-START(17180065872),
    {
      "p": [
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "inheritability",
          "p": 94175233
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 196688,
      "h": 17180065872,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065872),
//--TRIMMABLE-BOUNDARY-START(12885098576),
    {
      "p": [
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "inheritability",
          "p": 94175233
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 196688,
      "h": 12885098576,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098576)
  ],
  "h": 196688
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipes.AnonymousPipeServerStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipes${separator}AnonymousPipeServerStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196688)
        
        

        //--TRIMMABLE-BOUNDARY-START(262224)
        $asm.$cls(`$sip.SIP.NamedPipeClientStream`, ($self) => class NamedPipeClientStream extends $.$sip.SIP.PipeStream
        {
            //--TRIMMABLE-BOUNDARY-START(4295229520)
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229520);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229520)
            
            //--TRIMMABLE-BOUNDARY-START(34360000592)
            $ctor$12(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360000592);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360000592)
            
            //--TRIMMABLE-BOUNDARY-START(30065033296)
            $ctor$11(/*string*/ serverName, /*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065033296);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065033296)
            
            //--TRIMMABLE-BOUNDARY-START(8590196816)
            $ctor$6(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeAccessRights*/ desiredAccessRights, /*PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196816);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196816)
            
            //--TRIMMABLE-BOUNDARY-START(25770066000)
            $ctor$10(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770066000);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770066000)
            
            //--TRIMMABLE-BOUNDARY-START(21475098704)
            $ctor$9(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475098704);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098704)
            
            //--TRIMMABLE-BOUNDARY-START(17180131408)
            $ctor$8(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180131408);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131408)
            
            //--TRIMMABLE-BOUNDARY-START(12885164112)
            $ctor$7(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885164112);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885164112)
            
            //--TRIMMABLE-BOUNDARY-START(90194575440)
            /*int */ get NumberOfServerInstances()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899608144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90194575440)
            
            //--TRIMMABLE-BOUNDARY-START(38654967888)
            /*void */ CheckPipePropertyOperations()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38654967888)
            
            //--TRIMMABLE-BOUNDARY-START(42949935184)
            /*void */ Connect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42949935184)
            
            //--TRIMMABLE-BOUNDARY-START(47244902480)
            /*void */ Connect$1(/*int*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244902480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47244902480)
            
            //--TRIMMABLE-BOUNDARY-START(51539869776)
            /*void */ Connect$2(/*System.TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539869776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51539869776)
            
            //--TRIMMABLE-BOUNDARY-START(55834837072)
            /*System.Threading.Tasks.Task */ ConnectAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55834837072)
            
            //--TRIMMABLE-BOUNDARY-START(64424771664)
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*int*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424771664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64424771664)
            
            //--TRIMMABLE-BOUNDARY-START(60129804368)
            /*System.Threading.Tasks.Task */ ConnectAsync$1(/*int*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129804368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60129804368)
            
            //--TRIMMABLE-BOUNDARY-START(73014706256)
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.TimeSpan*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73014706256)
            
            //--TRIMMABLE-BOUNDARY-START(68719738960)
            /*System.Threading.Tasks.Task */ ConnectAsync$3(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719738960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68719738960)
            
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 262224;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sip.SIP.PipeStream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90194575440),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899608144,
        "f": 50331649
      },
      "n": "NumberOfServerInstances",
      "d": 262224,
      "h": 90194575440,
      "f": 2097153,
      "a": [
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194575440)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38654967888),
    {
      "r": 65537,
      "n": "CheckPipePropertyOperations",
      "d": 262224,
      "h": 38654967888,
      "f": 16810000
    },
//--TRIMMABLE-BOUNDARY-END(38654967888),
//--TRIMMABLE-BOUNDARY-START(42949935184),
    {
      "r": 65537,
      "n": "Connect",
      "d": 262224,
      "h": 42949935184,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949935184),
//--TRIMMABLE-BOUNDARY-START(47244902480),
    {
      "r": 65537,
      "p": [
        {
          "n": "timeout",
          "p": 655361
        }
      ],
      "n": "Connect",
      "o": "@$1",
      "d": 262224,
      "h": 47244902480,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244902480),
//--TRIMMABLE-BOUNDARY-START(51539869776),
    {
      "r": 65537,
      "p": [
        {
          "n": "timeout",
          "p": 186646529
        }
      ],
      "n": "Connect",
      "o": "@$2",
      "d": 262224,
      "h": 51539869776,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539869776),
//--TRIMMABLE-BOUNDARY-START(55834837072),
    {
      "r": 178454529,
      "n": "ConnectAsync",
      "d": 262224,
      "h": 55834837072,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834837072),
//--TRIMMABLE-BOUNDARY-START(64424771664),
    {
      "r": 178454529,
      "p": [
        {
          "n": "timeout",
          "p": 655361
        }
      ],
      "n": "ConnectAsync",
      "o": "@$2",
      "d": 262224,
      "h": 64424771664,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424771664),
//--TRIMMABLE-BOUNDARY-START(60129804368),
    {
      "r": 178454529,
      "p": [
        {
          "n": "timeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ConnectAsync",
      "o": "@$1",
      "d": 262224,
      "h": 60129804368,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129804368),
//--TRIMMABLE-BOUNDARY-START(73014706256),
    {
      "r": 178454529,
      "p": [
        {
          "n": "timeout",
          "p": 186646529
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ConnectAsync",
      "o": "@$4",
      "d": 262224,
      "h": 73014706256,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014706256),
//--TRIMMABLE-BOUNDARY-START(68719738960),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ConnectAsync",
      "o": "@$3",
      "d": 262224,
      "h": 68719738960,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719738960)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229520),
    {
      "p": [
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "isAsync",
          "p": 262145
        },
        {
          "n": "isConnected",
          "p": 262145
        },
        {
          "n": "safePipeHandle",
          "p": 65616
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 262224,
      "h": 4295229520,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229520),
//--TRIMMABLE-BOUNDARY-START(34360000592),
    {
      "p": [
        {
          "n": "pipeName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 262224,
      "h": 34360000592,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360000592),
//--TRIMMABLE-BOUNDARY-START(30065033296),
    {
      "p": [
        {
          "n": "serverName",
          "p": 1310721
        },
        {
          "n": "pipeName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 262224,
      "h": 30065033296,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065033296),
//--TRIMMABLE-BOUNDARY-START(8590196816),
    {
      "p": [
        {
          "n": "serverName",
          "p": 1310721
        },
        {
          "n": "pipeName",
          "p": 1310721
        },
        {
          "n": "desiredAccessRights",
          "p": 393296
        },
        {
          "n": "options",
          "p": 524368
        },
        {
          "n": "impersonationLevel",
          "p": 162136065
        },
        {
          "n": "inheritability",
          "p": 94175233
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 262224,
      "h": 8590196816,
      "f": 16777217,
      "a": [
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590196816),
//--TRIMMABLE-BOUNDARY-START(25770066000),
    {
      "p": [
        {
          "n": "serverName",
          "p": 1310721
        },
        {
          "n": "pipeName",
          "p": 1310721
        },
        {
          "n": "direction",
          "p": 458832
        }
      ],
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 262224,
      "h": 25770066000,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770066000),
//--TRIMMABLE-BOUNDARY-START(21475098704),
    {
      "p": [
        {
          "n": "serverName",
          "p": 1310721
        },
        {
          "n": "pipeName",
          "p": 1310721
        },
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "options",
          "p": 524368
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 262224,
      "h": 21475098704,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475098704),
//--TRIMMABLE-BOUNDARY-START(17180131408),
    {
      "p": [
        {
          "n": "serverName",
          "p": 1310721
        },
        {
          "n": "pipeName",
          "p": 1310721
        },
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "options",
          "p": 524368
        },
        {
          "n": "impersonationLevel",
          "p": 162136065
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 262224,
      "h": 17180131408,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131408),
//--TRIMMABLE-BOUNDARY-START(12885164112),
    {
      "p": [
        {
          "n": "serverName",
          "p": 1310721
        },
        {
          "n": "pipeName",
          "p": 1310721
        },
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "options",
          "p": 524368
        },
        {
          "n": "impersonationLevel",
          "p": 162136065
        },
        {
          "n": "inheritability",
          "p": 94175233
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 262224,
      "h": 12885164112,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885164112)
  ],
  "h": 262224
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipes.NamedPipeClientStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipes${separator}NamedPipeClientStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262224)
        
        

        //--TRIMMABLE-BOUNDARY-START(327760)
        $asm.$cls(`$sip.SIP.NamedPipeServerStream`, ($self) => class NamedPipeServerStream extends $.$sip.SIP.PipeStream
        {
            //--TRIMMABLE-BOUNDARY-START(55834902608)
            /*int*/ static MaxAllowedServerInstances = -1;
            //--TRIMMABLE-BOUNDARY-END(55834902608)
            
            //--TRIMMABLE-BOUNDARY-START(4295295056)
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295056);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295056)
            
            //--TRIMMABLE-BOUNDARY-START(30065098832)
            $ctor$11(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065098832);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065098832)
            
            //--TRIMMABLE-BOUNDARY-START(25770131536)
            $ctor$10(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770131536);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131536)
            
            //--TRIMMABLE-BOUNDARY-START(21475164240)
            $ctor$9(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475164240);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475164240)
            
            //--TRIMMABLE-BOUNDARY-START(17180196944)
            $ctor$8(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180196944);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196944)
            
            //--TRIMMABLE-BOUNDARY-START(12885229648)
            $ctor$7(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885229648);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885229648)
            
            //--TRIMMABLE-BOUNDARY-START(8590262352)
            $ctor$6(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options, /*int*/ inBufferSize, /*int*/ outBufferSize)
            {
                super.$ctor$3(0, 0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262352);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262352)
            
            //--TRIMMABLE-BOUNDARY-START(34360066128)
            /*System.IAsyncResult */ BeginWaitForConnection(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360066128)
            
            //--TRIMMABLE-BOUNDARY-START(38655033424)
            /*void */ Disconnect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38655033424)
            
            //--TRIMMABLE-BOUNDARY-START(42950000720)
            /*void */ EndWaitForConnection(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950000720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42950000720)
            
            $dtor()
            {
            }
            //--TRIMMABLE-BOUNDARY-START(51539935312)
            /*string */ GetImpersonationUserName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539935312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51539935312)
            
            //--TRIMMABLE-BOUNDARY-START(60129869904)
            /*void */ RunAsClient(/*System.IO.Pipes.PipeStreamImpersonationWorker*/ impersonationWorker)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129869904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60129869904)
            
            //--TRIMMABLE-BOUNDARY-START(64424837200)
            /*void */ WaitForConnection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64424837200)
            
            //--TRIMMABLE-BOUNDARY-START(68719804496)
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719804496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68719804496)
            
            //--TRIMMABLE-BOUNDARY-START(73014771792)
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014771792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73014771792)
            
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 327760;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sip.SIP.PipeStream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360066128),
    {
      "r": 90570753,
      "p": [
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginWaitForConnection",
      "d": 327760,
      "h": 34360066128,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360066128),
//--TRIMMABLE-BOUNDARY-START(38655033424),
    {
      "r": 65537,
      "n": "Disconnect",
      "d": 327760,
      "h": 38655033424,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655033424),
//--TRIMMABLE-BOUNDARY-START(42950000720),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndWaitForConnection",
      "d": 327760,
      "h": 42950000720,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950000720),
//--TRIMMABLE-BOUNDARY-START(51539935312),
    {
      "r": 1310721,
      "n": "GetImpersonationUserName",
      "d": 327760,
      "h": 51539935312,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539935312),
//--TRIMMABLE-BOUNDARY-START(60129869904),
    {
      "r": 65537,
      "p": [
        {
          "n": "impersonationWorker",
          "p": 655440
        }
      ],
      "n": "RunAsClient",
      "d": 327760,
      "h": 60129869904,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129869904),
//--TRIMMABLE-BOUNDARY-START(64424837200),
    {
      "r": 65537,
      "n": "WaitForConnection",
      "d": 327760,
      "h": 64424837200,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424837200),
//--TRIMMABLE-BOUNDARY-START(68719804496),
    {
      "r": 178454529,
      "n": "WaitForConnectionAsync",
      "d": 327760,
      "h": 68719804496,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719804496),
//--TRIMMABLE-BOUNDARY-START(73014771792),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WaitForConnectionAsync",
      "o": "@$1",
      "d": 327760,
      "h": 73014771792,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014771792)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55834902608),
    {
      "t": 655361,
      "n": "MaxAllowedServerInstances",
      "d": 327760,
      "h": 55834902608,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834902608)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295056),
    {
      "p": [
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "isAsync",
          "p": 262145
        },
        {
          "n": "isConnected",
          "p": 262145
        },
        {
          "n": "safePipeHandle",
          "p": 65616
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 327760,
      "h": 4295295056,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295056),
//--TRIMMABLE-BOUNDARY-START(30065098832),
    {
      "p": [
        {
          "n": "pipeName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 327760,
      "h": 30065098832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065098832),
//--TRIMMABLE-BOUNDARY-START(25770131536),
    {
      "p": [
        {
          "n": "pipeName",
          "p": 1310721
        },
        {
          "n": "direction",
          "p": 458832
        }
      ],
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 327760,
      "h": 25770131536,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770131536),
//--TRIMMABLE-BOUNDARY-START(21475164240),
    {
      "p": [
        {
          "n": "pipeName",
          "p": 1310721
        },
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "maxNumberOfServerInstances",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 327760,
      "h": 21475164240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475164240),
//--TRIMMABLE-BOUNDARY-START(17180196944),
    {
      "p": [
        {
          "n": "pipeName",
          "p": 1310721
        },
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "maxNumberOfServerInstances",
          "p": 655361
        },
        {
          "n": "transmissionMode",
          "p": 720976
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 327760,
      "h": 17180196944,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180196944),
//--TRIMMABLE-BOUNDARY-START(12885229648),
    {
      "p": [
        {
          "n": "pipeName",
          "p": 1310721
        },
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "maxNumberOfServerInstances",
          "p": 655361
        },
        {
          "n": "transmissionMode",
          "p": 720976
        },
        {
          "n": "options",
          "p": 524368
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 327760,
      "h": 12885229648,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885229648),
//--TRIMMABLE-BOUNDARY-START(8590262352),
    {
      "p": [
        {
          "n": "pipeName",
          "p": 1310721
        },
        {
          "n": "direction",
          "p": 458832
        },
        {
          "n": "maxNumberOfServerInstances",
          "p": 655361
        },
        {
          "n": "transmissionMode",
          "p": 720976
        },
        {
          "n": "options",
          "p": 524368
        },
        {
          "n": "inBufferSize",
          "p": 655361
        },
        {
          "n": "outBufferSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 327760,
      "h": 8590262352,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262352)
  ],
  "h": 327760
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IO.Pipes.NamedPipeServerStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IO${separator}Pipes${separator}NamedPipeServerStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327760)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl", "NetJs.System.Threading.Overlapped"));
})();
//--TRIMMABLE-BOUNDARY-END(80)
