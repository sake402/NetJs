
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $sto, $stt, $sr, $scc, $scn, $ssc, $sris, $sspw, $ssa) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Pipes", 
    {"h":44882,"f":"System.IO.Pipes","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Pipes","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Pipes","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sip.System.IO.Pipes.PipeStream", ($self) => class PipeStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.IO.Pipes.PipeDirection*/ direction, /*int*/ bufferSize)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*int*/ outBufferSize)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsConnected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IsConnected(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsHandleExposed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMessageComplete()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OutBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get ReadMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get SafePipeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CheckPipePropertyOperations()
            {
            }
            /*void */ CheckReadOperations()
            {
            }
            /*void */ CheckWriteOperations()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ InitializeHandle(/*Microsoft.Win32.SafeHandles.SafePipeHandle?*/ handle, /*bool*/ isExposed, /*bool*/ isAsync)
            {
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ WaitForPipeDrain()
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 634706;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180503890,"f":32769},"n":"CanRead","d":634706,"h":12885536594,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":25770438482,"f":32769},"n":"CanSeek","d":634706,"h":21475471186,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360373074,"f":32769},"n":"CanWrite","d":634706,"h":30065405778,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":42950307666,"f":129},"n":"InBufferSize","d":634706,"h":38655340370,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":51540242258,"f":1},"n":"IsAsync","d":634706,"h":47245274962,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60130176850,"f":1},"s":{"r":0,"d":0,"h":64425144146,"f":4},"n":"IsConnected","d":634706,"h":55835209554,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73015078738,"f":4},"n":"IsHandleExposed","d":634706,"h":68720111442,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":81605013330,"f":1},"n":"IsMessageComplete","d":634706,"h":77310046034,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":90194947922,"f":32769},"n":"Length","d":634706,"h":85899980626,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":98784882514,"f":129},"n":"OutBufferSize","d":634706,"h":94489915218,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":107374817106,"f":32769},"s":{"r":0,"d":0,"h":111669784402,"f":32769},"n":"Position","d":634706,"h":103079849810,"f":32769},{"p":765778,"g":{"r":0,"d":0,"h":120259718994,"f":129},"s":{"r":0,"d":0,"h":124554686290,"f":129},"n":"ReadMode","d":634706,"h":115964751698,"f":129},{"p":110418,"g":{"r":0,"d":0,"h":133144620882,"f":1},"n":"SafePipeHandle","d":634706,"h":128849653586,"f":1},{"p":765778,"g":{"r":0,"d":0,"h":141734555474,"f":129},"n":"TransmissionMode","d":634706,"h":137439588178,"f":129}],"m":[{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginRead","d":634706,"h":146029522770,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWrite","d":634706,"h":150324490066,"f":32769},{"r":65537,"n":"CheckPipePropertyOperations","d":634706,"h":154619457362,"f":144},{"r":65537,"n":"CheckReadOperations","d":634706,"h":158914424658,"f":16},{"r":65537,"n":"CheckWriteOperations","d":634706,"h":163209391954,"f":16},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":634706,"h":167504359250,"f":32772},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":634706,"h":171799326546,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":634706,"h":176094293842,"f":32769},{"r":65537,"n":"Flush","d":634706,"h":180389261138,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":634706,"h":184684228434,"f":32769},{"r":65537,"p":[{"n":"handle","p":110418},{"n":"isExposed","p":262145},{"n":"isAsync","p":262145}],"n":"InitializeHandle","d":634706,"h":188979195730,"f":4},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":634706,"h":193274163026,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":634706,"h":197569130322,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":634706,"h":201864097618,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":634706,"h":206159064914,"f":32769},{"r":655361,"n":"ReadByte","d":634706,"h":210454032210,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":634706,"h":214748999506,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":634706,"h":219043966802,"f":32769},{"r":65537,"n":"WaitForPipeDrain","d":634706,"h":223338934098,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":634706,"h":227633901394,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":634706,"h":231928868690,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":634706,"h":236223835986,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":634706,"h":240518803282,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":634706,"h":244813770578,"f":32769}],"c":[{"p":[{"n":"direction","p":503634},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$3","d":634706,"h":4295602002,"f":4},{"p":[{"n":"direction","p":503634},{"n":"transmissionMode","p":765778},{"n":"outBufferSize","p":655361}],"n":".ctor","o":"$ctor$4","d":634706,"h":8590569298,"f":4}],"i":[57475073,56885249],"h":634706}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.PipeStream`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeAccessRights", ($self) => class PipeAccessRights extends $.$spc.System.Enum
        {
            static ReadData = 1;
            static WriteData = 2;
            static CreateNewInstance = 4;
            static ReadExtendedAttributes = 8;
            static WriteExtendedAttributes = 16;
            static ReadAttributes = 128;
            static WriteAttributes = 256;
            static Write = 274;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static Read = 131209;
            static ReadWrite = 131483;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static Synchronize = 1048576;
            static FullControl = 2032031;
            static AccessSystemSecurity = 16777216;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ReadData": 1n,
                    "WriteData": 2n,
                    "CreateNewInstance": 4n,
                    "ReadExtendedAttributes": 8n,
                    "WriteExtendedAttributes": 16n,
                    "ReadAttributes": 128n,
                    "WriteAttributes": 256n,
                    "Write": 274n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "Read": 131209n,
                    "ReadWrite": 131483n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "Synchronize": 1048576n,
                    "FullControl": 2032031n,
                    "AccessSystemSecurity": 16777216n
                };
            }
            static $h = 438098;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":438098,"n":"ReadData","d":438098,"h":4295405394,"f":33},{"t":438098,"n":"WriteData","d":438098,"h":8590372690,"f":33},{"t":438098,"n":"CreateNewInstance","d":438098,"h":12885339986,"f":33},{"t":438098,"n":"ReadExtendedAttributes","d":438098,"h":17180307282,"f":33},{"t":438098,"n":"WriteExtendedAttributes","d":438098,"h":21475274578,"f":33},{"t":438098,"n":"ReadAttributes","d":438098,"h":25770241874,"f":33},{"t":438098,"n":"WriteAttributes","d":438098,"h":30065209170,"f":33},{"t":438098,"n":"Write","d":438098,"h":34360176466,"f":33},{"t":438098,"n":"Delete","d":438098,"h":38655143762,"f":33},{"t":438098,"n":"ReadPermissions","d":438098,"h":42950111058,"f":33},{"t":438098,"n":"Read","d":438098,"h":47245078354,"f":33},{"t":438098,"n":"ReadWrite","d":438098,"h":51540045650,"f":33},{"t":438098,"n":"ChangePermissions","d":438098,"h":55835012946,"f":33},{"t":438098,"n":"TakeOwnership","d":438098,"h":60129980242,"f":33},{"t":438098,"n":"Synchronize","d":438098,"h":64424947538,"f":33},{"t":438098,"n":"FullControl","d":438098,"h":68719914834,"f":33},{"t":438098,"n":"AccessSystemSecurity","d":438098,"h":73014882130,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":438098,"h":77309849426,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":438098,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeAccessRights`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeDirection", ($self) => class PipeDirection extends $.$spc.System.Enum
        {
            static In = 1;
            static Out = 2;
            static InOut = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "In": 1n,
                    "Out": 2n,
                    "InOut": 3n
                };
            }
            static $h = 503634;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":503634,"n":"In","d":503634,"h":4295470930,"f":33},{"t":503634,"n":"Out","d":503634,"h":8590438226,"f":33},{"t":503634,"n":"InOut","d":503634,"h":12885405522,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":503634,"h":17180372818,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":503634}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeDirection`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeOptions", ($self) => class PipeOptions extends $.$spc.System.Enum
        {
            static WriteThrough = -2147483648;
            static None = 0;
            static CurrentUserOnly = 536870912;
            static Asynchronous = 1073741824;
            static FirstPipeInstance = 524288;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "WriteThrough": -2147483648n,
                    "None": 0n,
                    "CurrentUserOnly": 536870912n,
                    "Asynchronous": 1073741824n,
                    "FirstPipeInstance": 524288n
                };
            }
            static $h = 569170;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":569170,"n":"WriteThrough","d":569170,"h":4295536466,"f":33},{"t":569170,"n":"None","d":569170,"h":8590503762,"f":33},{"t":569170,"n":"CurrentUserOnly","d":569170,"h":12885471058,"f":33},{"t":569170,"n":"Asynchronous","d":569170,"h":17180438354,"f":33},{"t":569170,"n":"FirstPipeInstance","d":569170,"h":21475405650,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":569170,"h":25770372946,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":569170,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeOptions`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeTransmissionMode", ($self) => class PipeTransmissionMode extends $.$spc.System.Enum
        {
            static Byte = 0;
            static Message = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Byte": 0n,
                    "Message": 1n
                };
            }
            static $h = 765778;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":765778,"n":"Byte","d":765778,"h":4295733074,"f":33},{"t":765778,"n":"Message","d":765778,"h":8590700370,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":765778,"h":12885667666,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":765778}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeTransmissionMode`; }
        });
        
        $asm.$cls("$sip.Microsoft.Win32.SafeHandles.SafePipeHandle", ($self) => class SafePipeHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 110418;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17179979602,"f":32769},"n":"IsInvalid","d":110418,"h":12885012306,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":110418,"h":21474946898,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":110418,"h":4295077714,"f":1},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":110418,"h":8590045010,"f":1}],"i":[57475073],"h":110418}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafePipeHandle`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.AnonymousPipeClientStream", ($self) => class AnonymousPipeClientStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction, /*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 175954;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":634706,"p":[{"p":765778,"s":{"r":0,"d":0,"h":21475012434,"f":32769},"n":"ReadMode","d":175954,"h":17180045138,"f":32769},{"p":765778,"g":{"r":0,"d":0,"h":30064947026,"f":32769},"n":"TransmissionMode","d":175954,"h":25769979730,"f":32769}],"c":[{"p":[{"n":"direction","p":503634},{"n":"safePipeHandle","p":110418}],"n":".ctor","o":"$ctor$5","d":175954,"h":4295143250,"f":1},{"p":[{"n":"direction","p":503634},{"n":"pipeHandleAsString","p":1310721}],"n":".ctor","o":"$ctor$6","d":175954,"h":8590110546,"f":1},{"p":[{"n":"pipeHandleAsString","p":1310721}],"n":".ctor","o":"$ctor$7","d":175954,"h":12885077842,"f":1}],"i":[57475073,56885249],"h":175954}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.AnonymousPipeClientStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.AnonymousPipeServerStream", ($self) => class AnonymousPipeServerStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5()
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ serverSafePipeHandle, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ clientSafePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability, /*int*/ bufferSize)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get ClientSafePipeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ DisposeLocalCopyOfClientHandle()
            {
            }
            $dtor()
            {
            }
            /*string */ GetClientHandleAsString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 241490;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":634706,"p":[{"p":110418,"g":{"r":0,"d":0,"h":30065012562,"f":1},"n":"ClientSafePipeHandle","d":241490,"h":25770045266,"f":1},{"p":765778,"s":{"r":0,"d":0,"h":38654947154,"f":32769},"n":"ReadMode","d":241490,"h":34359979858,"f":32769},{"p":765778,"g":{"r":0,"d":0,"h":47244881746,"f":32769},"n":"TransmissionMode","d":241490,"h":42949914450,"f":32769}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":241490,"h":51539849042,"f":32772},{"r":65537,"n":"DisposeLocalCopyOfClientHandle","d":241490,"h":55834816338,"f":1},{"r":1310721,"n":"GetClientHandleAsString","d":241490,"h":64424750930,"f":1}],"c":[{"n":".ctor","o":"$ctor$5","d":241490,"h":4295208786,"f":1},{"p":[{"n":"direction","p":503634}],"n":".ctor","o":"$ctor$6","d":241490,"h":8590176082,"f":1},{"p":[{"n":"direction","p":503634},{"n":"serverSafePipeHandle","p":110418},{"n":"clientSafePipeHandle","p":110418}],"n":".ctor","o":"$ctor$7","d":241490,"h":12885143378,"f":1},{"p":[{"n":"direction","p":503634},{"n":"inheritability","p":60555265}],"n":".ctor","o":"$ctor$8","d":241490,"h":17180110674,"f":1},{"p":[{"n":"direction","p":503634},{"n":"inheritability","p":60555265},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$9","d":241490,"h":21475077970,"f":1}],"i":[57475073,56885249],"h":241490}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.AnonymousPipeServerStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.NamedPipeClientStream", ($self) => class NamedPipeClientStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ serverName, /*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeAccessRights*/ desiredAccessRights, /*PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$10(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$11(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$12(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*int */ get NumberOfServerInstances()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CheckPipePropertyOperations()
            {
            }
            /*void */ Connect()
            {
            }
            /*void */ Connect$1(/*int*/ timeout)
            {
            }
            /*void */ Connect$2(/*System.TimeSpan*/ timeout)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$1(/*int*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*int*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$3(/*System.TimeSpan*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 307026;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":634706,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42949979986,"f":1},"n":"NumberOfServerInstances","d":307026,"h":38655012690,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"m":[{"r":65537,"n":"CheckPipePropertyOperations","d":307026,"h":47244947282,"f":32784},{"r":65537,"n":"Connect","d":307026,"h":51539914578,"f":1},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Connect","o":"@$1","d":307026,"h":55834881874,"f":1},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"Connect","o":"@$2","d":307026,"h":60129849170,"f":1},{"r":133300225,"n":"ConnectAsync","d":307026,"h":64424816466,"f":1},{"r":133300225,"p":[{"n":"timeout","p":655361}],"n":"ConnectAsync","o":"@$1","d":307026,"h":68719783762,"f":1},{"r":133300225,"p":[{"n":"timeout","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$2","d":307026,"h":73014751058,"f":1},{"r":133300225,"p":[{"n":"timeout","p":140705793},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":307026,"h":77309718354,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$4","d":307026,"h":81604685650,"f":1}],"c":[{"p":[{"n":"direction","p":503634},{"n":"isAsync","p":262145},{"n":"isConnected","p":262145},{"n":"safePipeHandle","p":110418}],"n":".ctor","o":"$ctor$5","d":307026,"h":4295274322,"f":1},{"p":[{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$6","d":307026,"h":8590241618,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$7","d":307026,"h":12885208914,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"desiredAccessRights","p":438098},{"n":"options","p":569170},{"n":"impersonationLevel","p":117243905},{"n":"inheritability","p":60555265}],"n":".ctor","o":"$ctor$8","d":307026,"h":17180176210,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":503634}],"n":".ctor","o":"$ctor$9","d":307026,"h":21475143506,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":503634},{"n":"options","p":569170}],"n":".ctor","o":"$ctor$10","d":307026,"h":25770110802,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":503634},{"n":"options","p":569170},{"n":"impersonationLevel","p":117243905}],"n":".ctor","o":"$ctor$11","d":307026,"h":30065078098,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":503634},{"n":"options","p":569170},{"n":"impersonationLevel","p":117243905},{"n":"inheritability","p":60555265}],"n":".ctor","o":"$ctor$12","d":307026,"h":34360045394,"f":1}],"i":[57475073,56885249],"h":307026}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.NamedPipeClientStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.NamedPipeServerStream", ($self) => class NamedPipeServerStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            /*int*/ static MaxAllowedServerInstances = -1;
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$10(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$11(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options, /*int*/ inBufferSize, /*int*/ outBufferSize)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*System.IAsyncResult */ BeginWaitForConnection(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Disconnect()
            {
            }
            /*void */ EndWaitForConnection(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*string */ GetImpersonationUserName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RunAsClient(/*System.IO.Pipes.PipeStreamImpersonationWorker*/ impersonationWorker)
            {
            }
            /*void */ WaitForConnection()
            {
            }
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 372562;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":634706,"m":[{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWaitForConnection","d":372562,"h":38655078226,"f":1},{"r":65537,"n":"Disconnect","d":372562,"h":42950045522,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWaitForConnection","d":372562,"h":47245012818,"f":1},{"r":1310721,"n":"GetImpersonationUserName","d":372562,"h":55834947410,"f":1},{"r":65537,"p":[{"n":"impersonationWorker","p":700242}],"n":"RunAsClient","d":372562,"h":60129914706,"f":1},{"r":65537,"n":"WaitForConnection","d":372562,"h":64424882002,"f":1},{"r":133300225,"n":"WaitForConnectionAsync","d":372562,"h":68719849298,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitForConnectionAsync","o":"@$1","d":372562,"h":73014816594,"f":1}],"l":[{"t":655361,"n":"MaxAllowedServerInstances","d":372562,"h":4295339858,"f":33}],"c":[{"p":[{"n":"direction","p":503634},{"n":"isAsync","p":262145},{"n":"isConnected","p":262145},{"n":"safePipeHandle","p":110418}],"n":".ctor","o":"$ctor$5","d":372562,"h":8590307154,"f":1},{"p":[{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$6","d":372562,"h":12885274450,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":503634}],"n":".ctor","o":"$ctor$7","d":372562,"h":17180241746,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":503634},{"n":"maxNumberOfServerInstances","p":655361}],"n":".ctor","o":"$ctor$8","d":372562,"h":21475209042,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":503634},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":765778}],"n":".ctor","o":"$ctor$9","d":372562,"h":25770176338,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":503634},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":765778},{"n":"options","p":569170}],"n":".ctor","o":"$ctor$10","d":372562,"h":30065143634,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":503634},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":765778},{"n":"options","p":569170},{"n":"inBufferSize","p":655361},{"n":"outBufferSize","p":655361}],"n":".ctor","o":"$ctor$11","d":372562,"h":34360110930,"f":1}],"i":[57475073,56885249],"h":372562}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.NamedPipeServerStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.PipeStreamImpersonationWorker", ($self) => class PipeStreamImpersonationWorker extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke()
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 700242;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"n":"Invoke","d":700242,"h":8590634834,"f":129},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":700242,"h":12885602130,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":700242,"h":17180569426,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":700242,"h":4295667538,"f":1}],"i":[57147393,113377281],"h":700242}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.Pipes.PipeStreamImpersonationWorker`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl"))