
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $sto, $stt, $sr, $scc, $scn, $ssc, $sris, $sspw, $ssa) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Pipes", 
    {"h":47136,"f":"System.IO.Pipes","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Pipes","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Pipes","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sip.System.IO.Pipes.PipeStream", ($self) => class PipeStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.IO.Pipes.PipeDirection*/ direction, /*int*/ bufferSize)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*int*/ outBufferSize)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsConnected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IsConnected(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsHandleExposed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMessageComplete()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OutBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get ReadMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get SafePipeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CheckPipePropertyOperations()
            {
            }
            /*void */ CheckReadOperations()
            {
            }
            /*void */ CheckWriteOperations()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ InitializeHandle(/*Microsoft.Win32.SafeHandles.SafePipeHandle?*/ handle, /*bool*/ isExposed, /*bool*/ isAsync)
            {
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ WaitForPipeDrain()
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 636960;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180506144,"f":32769},"n":"CanRead","d":636960,"h":12885538848,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":25770440736,"f":32769},"n":"CanSeek","d":636960,"h":21475473440,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360375328,"f":32769},"n":"CanWrite","d":636960,"h":30065408032,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":42950309920,"f":129},"n":"InBufferSize","d":636960,"h":38655342624,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":51540244512,"f":1},"n":"IsAsync","d":636960,"h":47245277216,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60130179104,"f":1},"s":{"r":0,"d":0,"h":64425146400,"f":4},"n":"IsConnected","d":636960,"h":55835211808,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73015080992,"f":4},"n":"IsHandleExposed","d":636960,"h":68720113696,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":81605015584,"f":1},"n":"IsMessageComplete","d":636960,"h":77310048288,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":90194950176,"f":32769},"n":"Length","d":636960,"h":85899982880,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":98784884768,"f":129},"n":"OutBufferSize","d":636960,"h":94489917472,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":107374819360,"f":32769},"s":{"r":0,"d":0,"h":111669786656,"f":32769},"n":"Position","d":636960,"h":103079852064,"f":32769},{"p":768032,"g":{"r":0,"d":0,"h":120259721248,"f":129},"s":{"r":0,"d":0,"h":124554688544,"f":129},"n":"ReadMode","d":636960,"h":115964753952,"f":129},{"p":112672,"g":{"r":0,"d":0,"h":133144623136,"f":1},"n":"SafePipeHandle","d":636960,"h":128849655840,"f":1},{"p":768032,"g":{"r":0,"d":0,"h":141734557728,"f":129},"n":"TransmissionMode","d":636960,"h":137439590432,"f":129}],"m":[{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginRead","d":636960,"h":146029525024,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWrite","d":636960,"h":150324492320,"f":32769},{"r":65537,"n":"CheckPipePropertyOperations","d":636960,"h":154619459616,"f":144},{"r":65537,"n":"CheckReadOperations","d":636960,"h":158914426912,"f":16},{"r":65537,"n":"CheckWriteOperations","d":636960,"h":163209394208,"f":16},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":636960,"h":167504361504,"f":32772},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":636960,"h":171799328800,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":636960,"h":176094296096,"f":32769},{"r":65537,"n":"Flush","d":636960,"h":180389263392,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":636960,"h":184684230688,"f":32769},{"r":65537,"p":[{"n":"handle","p":112672},{"n":"isExposed","p":262145},{"n":"isAsync","p":262145}],"n":"InitializeHandle","d":636960,"h":188979197984,"f":4},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":636960,"h":193274165280,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":636960,"h":197569132576,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":636960,"h":201864099872,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":636960,"h":206159067168,"f":32769},{"r":655361,"n":"ReadByte","d":636960,"h":210454034464,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":636960,"h":214749001760,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":636960,"h":219043969056,"f":32769},{"r":65537,"n":"WaitForPipeDrain","d":636960,"h":223338936352,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":636960,"h":227633903648,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":636960,"h":231928870944,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":636960,"h":236223838240,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":636960,"h":240518805536,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":636960,"h":244813772832,"f":32769}],"c":[{"p":[{"n":"direction","p":505888},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$3","d":636960,"h":4295604256,"f":4},{"p":[{"n":"direction","p":505888},{"n":"transmissionMode","p":768032},{"n":"outBufferSize","p":655361}],"n":".ctor","o":"$ctor$4","d":636960,"h":8590571552,"f":4}],"i":[57475073,56885249],"h":636960}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.PipeStream`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeAccessRights", ($self) => class PipeAccessRights extends $.$spc.System.Enum
        {
            static ReadData = 1;
            static WriteData = 2;
            static CreateNewInstance = 4;
            static ReadExtendedAttributes = 8;
            static WriteExtendedAttributes = 16;
            static ReadAttributes = 128;
            static WriteAttributes = 256;
            static Write = 274;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static Read = 131209;
            static ReadWrite = 131483;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static Synchronize = 1048576;
            static FullControl = 2032031;
            static AccessSystemSecurity = 16777216;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ReadData": 1n,
                    "WriteData": 2n,
                    "CreateNewInstance": 4n,
                    "ReadExtendedAttributes": 8n,
                    "WriteExtendedAttributes": 16n,
                    "ReadAttributes": 128n,
                    "WriteAttributes": 256n,
                    "Write": 274n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "Read": 131209n,
                    "ReadWrite": 131483n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "Synchronize": 1048576n,
                    "FullControl": 2032031n,
                    "AccessSystemSecurity": 16777216n
                };
            }
            static $h = 440352;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":440352,"n":"ReadData","d":440352,"h":4295407648,"f":33},{"t":440352,"n":"WriteData","d":440352,"h":8590374944,"f":33},{"t":440352,"n":"CreateNewInstance","d":440352,"h":12885342240,"f":33},{"t":440352,"n":"ReadExtendedAttributes","d":440352,"h":17180309536,"f":33},{"t":440352,"n":"WriteExtendedAttributes","d":440352,"h":21475276832,"f":33},{"t":440352,"n":"ReadAttributes","d":440352,"h":25770244128,"f":33},{"t":440352,"n":"WriteAttributes","d":440352,"h":30065211424,"f":33},{"t":440352,"n":"Write","d":440352,"h":34360178720,"f":33},{"t":440352,"n":"Delete","d":440352,"h":38655146016,"f":33},{"t":440352,"n":"ReadPermissions","d":440352,"h":42950113312,"f":33},{"t":440352,"n":"Read","d":440352,"h":47245080608,"f":33},{"t":440352,"n":"ReadWrite","d":440352,"h":51540047904,"f":33},{"t":440352,"n":"ChangePermissions","d":440352,"h":55835015200,"f":33},{"t":440352,"n":"TakeOwnership","d":440352,"h":60129982496,"f":33},{"t":440352,"n":"Synchronize","d":440352,"h":64424949792,"f":33},{"t":440352,"n":"FullControl","d":440352,"h":68719917088,"f":33},{"t":440352,"n":"AccessSystemSecurity","d":440352,"h":73014884384,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":440352,"h":77309851680,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":440352,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeAccessRights`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeDirection", ($self) => class PipeDirection extends $.$spc.System.Enum
        {
            static In = 1;
            static Out = 2;
            static InOut = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "In": 1n,
                    "Out": 2n,
                    "InOut": 3n
                };
            }
            static $h = 505888;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":505888,"n":"In","d":505888,"h":4295473184,"f":33},{"t":505888,"n":"Out","d":505888,"h":8590440480,"f":33},{"t":505888,"n":"InOut","d":505888,"h":12885407776,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":505888,"h":17180375072,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":505888}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeDirection`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeOptions", ($self) => class PipeOptions extends $.$spc.System.Enum
        {
            static WriteThrough = -2147483648;
            static None = 0;
            static CurrentUserOnly = 536870912;
            static Asynchronous = 1073741824;
            static FirstPipeInstance = 524288;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "WriteThrough": -2147483648n,
                    "None": 0n,
                    "CurrentUserOnly": 536870912n,
                    "Asynchronous": 1073741824n,
                    "FirstPipeInstance": 524288n
                };
            }
            static $h = 571424;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":571424,"n":"WriteThrough","d":571424,"h":4295538720,"f":33},{"t":571424,"n":"None","d":571424,"h":8590506016,"f":33},{"t":571424,"n":"CurrentUserOnly","d":571424,"h":12885473312,"f":33},{"t":571424,"n":"Asynchronous","d":571424,"h":17180440608,"f":33},{"t":571424,"n":"FirstPipeInstance","d":571424,"h":21475407904,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":571424,"h":25770375200,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":571424,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeOptions`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeTransmissionMode", ($self) => class PipeTransmissionMode extends $.$spc.System.Enum
        {
            static Byte = 0;
            static Message = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Byte": 0n,
                    "Message": 1n
                };
            }
            static $h = 768032;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":768032,"n":"Byte","d":768032,"h":4295735328,"f":33},{"t":768032,"n":"Message","d":768032,"h":8590702624,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":768032,"h":12885669920,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":768032}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeTransmissionMode`; }
        });
        
        $asm.$cls("$sip.Microsoft.Win32.SafeHandles.SafePipeHandle", ($self) => class SafePipeHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 112672;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17179981856,"f":32769},"n":"IsInvalid","d":112672,"h":12885014560,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":112672,"h":21474949152,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":112672,"h":4295079968,"f":1},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":112672,"h":8590047264,"f":1}],"i":[57475073],"h":112672}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafePipeHandle`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.AnonymousPipeClientStream", ($self) => class AnonymousPipeClientStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction, /*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 178208;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":636960,"p":[{"p":768032,"s":{"r":0,"d":0,"h":21475014688,"f":32769},"n":"ReadMode","d":178208,"h":17180047392,"f":32769},{"p":768032,"g":{"r":0,"d":0,"h":30064949280,"f":32769},"n":"TransmissionMode","d":178208,"h":25769981984,"f":32769}],"c":[{"p":[{"n":"direction","p":505888},{"n":"safePipeHandle","p":112672}],"n":".ctor","o":"$ctor$5","d":178208,"h":4295145504,"f":1},{"p":[{"n":"direction","p":505888},{"n":"pipeHandleAsString","p":1310721}],"n":".ctor","o":"$ctor$6","d":178208,"h":8590112800,"f":1},{"p":[{"n":"pipeHandleAsString","p":1310721}],"n":".ctor","o":"$ctor$7","d":178208,"h":12885080096,"f":1}],"i":[57475073,56885249],"h":178208}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.AnonymousPipeClientStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.AnonymousPipeServerStream", ($self) => class AnonymousPipeServerStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5()
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ serverSafePipeHandle, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ clientSafePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability, /*int*/ bufferSize)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get ClientSafePipeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ DisposeLocalCopyOfClientHandle()
            {
            }
            $dtor()
            {
            }
            /*string */ GetClientHandleAsString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 243744;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":636960,"p":[{"p":112672,"g":{"r":0,"d":0,"h":30065014816,"f":1},"n":"ClientSafePipeHandle","d":243744,"h":25770047520,"f":1},{"p":768032,"s":{"r":0,"d":0,"h":38654949408,"f":32769},"n":"ReadMode","d":243744,"h":34359982112,"f":32769},{"p":768032,"g":{"r":0,"d":0,"h":47244884000,"f":32769},"n":"TransmissionMode","d":243744,"h":42949916704,"f":32769}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":243744,"h":51539851296,"f":32772},{"r":65537,"n":"DisposeLocalCopyOfClientHandle","d":243744,"h":55834818592,"f":1},{"r":1310721,"n":"GetClientHandleAsString","d":243744,"h":64424753184,"f":1}],"c":[{"n":".ctor","o":"$ctor$5","d":243744,"h":4295211040,"f":1},{"p":[{"n":"direction","p":505888}],"n":".ctor","o":"$ctor$6","d":243744,"h":8590178336,"f":1},{"p":[{"n":"direction","p":505888},{"n":"serverSafePipeHandle","p":112672},{"n":"clientSafePipeHandle","p":112672}],"n":".ctor","o":"$ctor$7","d":243744,"h":12885145632,"f":1},{"p":[{"n":"direction","p":505888},{"n":"inheritability","p":60555265}],"n":".ctor","o":"$ctor$8","d":243744,"h":17180112928,"f":1},{"p":[{"n":"direction","p":505888},{"n":"inheritability","p":60555265},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$9","d":243744,"h":21475080224,"f":1}],"i":[57475073,56885249],"h":243744}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.AnonymousPipeServerStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.NamedPipeClientStream", ($self) => class NamedPipeClientStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ serverName, /*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeAccessRights*/ desiredAccessRights, /*PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$10(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$11(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$12(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*int */ get NumberOfServerInstances()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CheckPipePropertyOperations()
            {
            }
            /*void */ Connect()
            {
            }
            /*void */ Connect$1(/*int*/ timeout)
            {
            }
            /*void */ Connect$2(/*System.TimeSpan*/ timeout)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$1(/*int*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*int*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$3(/*System.TimeSpan*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 309280;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":636960,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42949982240,"f":1},"n":"NumberOfServerInstances","d":309280,"h":38655014944,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"m":[{"r":65537,"n":"CheckPipePropertyOperations","d":309280,"h":47244949536,"f":32784},{"r":65537,"n":"Connect","d":309280,"h":51539916832,"f":1},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Connect","o":"@$1","d":309280,"h":55834884128,"f":1},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"Connect","o":"@$2","d":309280,"h":60129851424,"f":1},{"r":133300225,"n":"ConnectAsync","d":309280,"h":64424818720,"f":1},{"r":133300225,"p":[{"n":"timeout","p":655361}],"n":"ConnectAsync","o":"@$1","d":309280,"h":68719786016,"f":1},{"r":133300225,"p":[{"n":"timeout","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$2","d":309280,"h":73014753312,"f":1},{"r":133300225,"p":[{"n":"timeout","p":140705793},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":309280,"h":77309720608,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$4","d":309280,"h":81604687904,"f":1}],"c":[{"p":[{"n":"direction","p":505888},{"n":"isAsync","p":262145},{"n":"isConnected","p":262145},{"n":"safePipeHandle","p":112672}],"n":".ctor","o":"$ctor$5","d":309280,"h":4295276576,"f":1},{"p":[{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$6","d":309280,"h":8590243872,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$7","d":309280,"h":12885211168,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"desiredAccessRights","p":440352},{"n":"options","p":571424},{"n":"impersonationLevel","p":117243905},{"n":"inheritability","p":60555265}],"n":".ctor","o":"$ctor$8","d":309280,"h":17180178464,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":505888}],"n":".ctor","o":"$ctor$9","d":309280,"h":21475145760,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":505888},{"n":"options","p":571424}],"n":".ctor","o":"$ctor$10","d":309280,"h":25770113056,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":505888},{"n":"options","p":571424},{"n":"impersonationLevel","p":117243905}],"n":".ctor","o":"$ctor$11","d":309280,"h":30065080352,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":505888},{"n":"options","p":571424},{"n":"impersonationLevel","p":117243905},{"n":"inheritability","p":60555265}],"n":".ctor","o":"$ctor$12","d":309280,"h":34360047648,"f":1}],"i":[57475073,56885249],"h":309280}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.NamedPipeClientStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.NamedPipeServerStream", ($self) => class NamedPipeServerStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            /*int*/ static MaxAllowedServerInstances = -1;
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$10(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$11(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options, /*int*/ inBufferSize, /*int*/ outBufferSize)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*System.IAsyncResult */ BeginWaitForConnection(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Disconnect()
            {
            }
            /*void */ EndWaitForConnection(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*string */ GetImpersonationUserName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RunAsClient(/*System.IO.Pipes.PipeStreamImpersonationWorker*/ impersonationWorker)
            {
            }
            /*void */ WaitForConnection()
            {
            }
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 374816;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":636960,"m":[{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWaitForConnection","d":374816,"h":38655080480,"f":1},{"r":65537,"n":"Disconnect","d":374816,"h":42950047776,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWaitForConnection","d":374816,"h":47245015072,"f":1},{"r":1310721,"n":"GetImpersonationUserName","d":374816,"h":55834949664,"f":1},{"r":65537,"p":[{"n":"impersonationWorker","p":702496}],"n":"RunAsClient","d":374816,"h":60129916960,"f":1},{"r":65537,"n":"WaitForConnection","d":374816,"h":64424884256,"f":1},{"r":133300225,"n":"WaitForConnectionAsync","d":374816,"h":68719851552,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitForConnectionAsync","o":"@$1","d":374816,"h":73014818848,"f":1}],"l":[{"t":655361,"n":"MaxAllowedServerInstances","d":374816,"h":4295342112,"f":33}],"c":[{"p":[{"n":"direction","p":505888},{"n":"isAsync","p":262145},{"n":"isConnected","p":262145},{"n":"safePipeHandle","p":112672}],"n":".ctor","o":"$ctor$5","d":374816,"h":8590309408,"f":1},{"p":[{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$6","d":374816,"h":12885276704,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":505888}],"n":".ctor","o":"$ctor$7","d":374816,"h":17180244000,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":505888},{"n":"maxNumberOfServerInstances","p":655361}],"n":".ctor","o":"$ctor$8","d":374816,"h":21475211296,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":505888},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":768032}],"n":".ctor","o":"$ctor$9","d":374816,"h":25770178592,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":505888},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":768032},{"n":"options","p":571424}],"n":".ctor","o":"$ctor$10","d":374816,"h":30065145888,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":505888},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":768032},{"n":"options","p":571424},{"n":"inBufferSize","p":655361},{"n":"outBufferSize","p":655361}],"n":".ctor","o":"$ctor$11","d":374816,"h":34360113184,"f":1}],"i":[57475073,56885249],"h":374816}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.NamedPipeServerStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.PipeStreamImpersonationWorker", ($self) => class PipeStreamImpersonationWorker extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke()
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 702496;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"n":"Invoke","d":702496,"h":8590637088,"f":129},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":702496,"h":12885604384,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":702496,"h":17180571680,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":702496,"h":4295669792,"f":1}],"i":[57147393,113377281],"h":702496}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.Pipes.PipeStreamImpersonationWorker`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl"))