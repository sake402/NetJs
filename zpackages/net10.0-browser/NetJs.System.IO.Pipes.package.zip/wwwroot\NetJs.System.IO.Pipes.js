
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $sto, $stt, $sr, $scc, $scn, $ssc, $sris, $sspw, $ssa) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Pipes", 
    {"h":45797,"f":"System.IO.Pipes","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Pipes","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Pipes","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sip.System.IO.Pipes.PipeStream", ($self) => class PipeStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.IO.Pipes.PipeDirection*/ direction, /*int*/ bufferSize)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*int*/ outBufferSize)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsConnected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IsConnected(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsHandleExposed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMessageComplete()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OutBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get ReadMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get SafePipeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CheckPipePropertyOperations()
            {
            }
            /*void */ CheckReadOperations()
            {
            }
            /*void */ CheckWriteOperations()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ InitializeHandle(/*Microsoft.Win32.SafeHandles.SafePipeHandle?*/ handle, /*bool*/ isExposed, /*bool*/ isAsync)
            {
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ WaitForPipeDrain()
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 635621;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180504805,"f":32769},"n":"CanRead","d":635621,"h":12885537509,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":25770439397,"f":32769},"n":"CanSeek","d":635621,"h":21475472101,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360373989,"f":32769},"n":"CanWrite","d":635621,"h":30065406693,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":42950308581,"f":129},"n":"InBufferSize","d":635621,"h":38655341285,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":51540243173,"f":1},"n":"IsAsync","d":635621,"h":47245275877,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60130177765,"f":1},"s":{"r":0,"d":0,"h":64425145061,"f":4},"n":"IsConnected","d":635621,"h":55835210469,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73015079653,"f":4},"n":"IsHandleExposed","d":635621,"h":68720112357,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":81605014245,"f":1},"n":"IsMessageComplete","d":635621,"h":77310046949,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":90194948837,"f":32769},"n":"Length","d":635621,"h":85899981541,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":98784883429,"f":129},"n":"OutBufferSize","d":635621,"h":94489916133,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":107374818021,"f":32769},"s":{"r":0,"d":0,"h":111669785317,"f":32769},"n":"Position","d":635621,"h":103079850725,"f":32769},{"p":766693,"g":{"r":0,"d":0,"h":120259719909,"f":129},"s":{"r":0,"d":0,"h":124554687205,"f":129},"n":"ReadMode","d":635621,"h":115964752613,"f":129},{"p":111333,"g":{"r":0,"d":0,"h":133144621797,"f":1},"n":"SafePipeHandle","d":635621,"h":128849654501,"f":1},{"p":766693,"g":{"r":0,"d":0,"h":141734556389,"f":129},"n":"TransmissionMode","d":635621,"h":137439589093,"f":129}],"m":[{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginRead","d":635621,"h":146029523685,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWrite","d":635621,"h":150324490981,"f":32769},{"r":65537,"n":"CheckPipePropertyOperations","d":635621,"h":154619458277,"f":144},{"r":65537,"n":"CheckReadOperations","d":635621,"h":158914425573,"f":16},{"r":65537,"n":"CheckWriteOperations","d":635621,"h":163209392869,"f":16},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":635621,"h":167504360165,"f":32772},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":635621,"h":171799327461,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":635621,"h":176094294757,"f":32769},{"r":65537,"n":"Flush","d":635621,"h":180389262053,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":635621,"h":184684229349,"f":32769},{"r":65537,"p":[{"n":"handle","p":111333},{"n":"isExposed","p":262145},{"n":"isAsync","p":262145}],"n":"InitializeHandle","d":635621,"h":188979196645,"f":4},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":635621,"h":193274163941,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":635621,"h":197569131237,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":635621,"h":201864098533,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":635621,"h":206159065829,"f":32769},{"r":655361,"n":"ReadByte","d":635621,"h":210454033125,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":635621,"h":214749000421,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":635621,"h":219043967717,"f":32769},{"r":65537,"n":"WaitForPipeDrain","d":635621,"h":223338935013,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":635621,"h":227633902309,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":635621,"h":231928869605,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":635621,"h":236223836901,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":635621,"h":240518804197,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":635621,"h":244813771493,"f":32769}],"c":[{"p":[{"n":"direction","p":504549},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$3","d":635621,"h":4295602917,"f":4},{"p":[{"n":"direction","p":504549},{"n":"transmissionMode","p":766693},{"n":"outBufferSize","p":655361}],"n":".ctor","o":"$ctor$4","d":635621,"h":8590570213,"f":4}],"i":[57475073,56885249],"h":635621}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.PipeStream`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeAccessRights", ($self) => class PipeAccessRights extends $.$spc.System.Enum
        {
            static ReadData = 1;
            static WriteData = 2;
            static CreateNewInstance = 4;
            static ReadExtendedAttributes = 8;
            static WriteExtendedAttributes = 16;
            static ReadAttributes = 128;
            static WriteAttributes = 256;
            static Write = 274;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static Read = 131209;
            static ReadWrite = 131483;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static Synchronize = 1048576;
            static FullControl = 2032031;
            static AccessSystemSecurity = 16777216;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ReadData": 1n,
                    "WriteData": 2n,
                    "CreateNewInstance": 4n,
                    "ReadExtendedAttributes": 8n,
                    "WriteExtendedAttributes": 16n,
                    "ReadAttributes": 128n,
                    "WriteAttributes": 256n,
                    "Write": 274n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "Read": 131209n,
                    "ReadWrite": 131483n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "Synchronize": 1048576n,
                    "FullControl": 2032031n,
                    "AccessSystemSecurity": 16777216n
                };
            }
            static $h = 439013;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":439013,"n":"ReadData","d":439013,"h":4295406309,"f":33},{"t":439013,"n":"WriteData","d":439013,"h":8590373605,"f":33},{"t":439013,"n":"CreateNewInstance","d":439013,"h":12885340901,"f":33},{"t":439013,"n":"ReadExtendedAttributes","d":439013,"h":17180308197,"f":33},{"t":439013,"n":"WriteExtendedAttributes","d":439013,"h":21475275493,"f":33},{"t":439013,"n":"ReadAttributes","d":439013,"h":25770242789,"f":33},{"t":439013,"n":"WriteAttributes","d":439013,"h":30065210085,"f":33},{"t":439013,"n":"Write","d":439013,"h":34360177381,"f":33},{"t":439013,"n":"Delete","d":439013,"h":38655144677,"f":33},{"t":439013,"n":"ReadPermissions","d":439013,"h":42950111973,"f":33},{"t":439013,"n":"Read","d":439013,"h":47245079269,"f":33},{"t":439013,"n":"ReadWrite","d":439013,"h":51540046565,"f":33},{"t":439013,"n":"ChangePermissions","d":439013,"h":55835013861,"f":33},{"t":439013,"n":"TakeOwnership","d":439013,"h":60129981157,"f":33},{"t":439013,"n":"Synchronize","d":439013,"h":64424948453,"f":33},{"t":439013,"n":"FullControl","d":439013,"h":68719915749,"f":33},{"t":439013,"n":"AccessSystemSecurity","d":439013,"h":73014883045,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":439013,"h":77309850341,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":439013,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeAccessRights`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeDirection", ($self) => class PipeDirection extends $.$spc.System.Enum
        {
            static In = 1;
            static Out = 2;
            static InOut = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "In": 1n,
                    "Out": 2n,
                    "InOut": 3n
                };
            }
            static $h = 504549;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":504549,"n":"In","d":504549,"h":4295471845,"f":33},{"t":504549,"n":"Out","d":504549,"h":8590439141,"f":33},{"t":504549,"n":"InOut","d":504549,"h":12885406437,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":504549,"h":17180373733,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":504549}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeDirection`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeOptions", ($self) => class PipeOptions extends $.$spc.System.Enum
        {
            static WriteThrough = -2147483648;
            static None = 0;
            static CurrentUserOnly = 536870912;
            static Asynchronous = 1073741824;
            static FirstPipeInstance = 524288;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "WriteThrough": -2147483648n,
                    "None": 0n,
                    "CurrentUserOnly": 536870912n,
                    "Asynchronous": 1073741824n,
                    "FirstPipeInstance": 524288n
                };
            }
            static $h = 570085;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":570085,"n":"WriteThrough","d":570085,"h":4295537381,"f":33},{"t":570085,"n":"None","d":570085,"h":8590504677,"f":33},{"t":570085,"n":"CurrentUserOnly","d":570085,"h":12885471973,"f":33},{"t":570085,"n":"Asynchronous","d":570085,"h":17180439269,"f":33},{"t":570085,"n":"FirstPipeInstance","d":570085,"h":21475406565,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":570085,"h":25770373861,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":570085,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeOptions`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeTransmissionMode", ($self) => class PipeTransmissionMode extends $.$spc.System.Enum
        {
            static Byte = 0;
            static Message = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Byte": 0n,
                    "Message": 1n
                };
            }
            static $h = 766693;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":766693,"n":"Byte","d":766693,"h":4295733989,"f":33},{"t":766693,"n":"Message","d":766693,"h":8590701285,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":766693,"h":12885668581,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":766693}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeTransmissionMode`; }
        });
        
        $asm.$cls("$sip.Microsoft.Win32.SafeHandles.SafePipeHandle", ($self) => class SafePipeHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 111333;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17179980517,"f":32769},"n":"IsInvalid","d":111333,"h":12885013221,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":111333,"h":21474947813,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":111333,"h":4295078629,"f":1},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":111333,"h":8590045925,"f":1}],"i":[57475073],"h":111333}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafePipeHandle`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.AnonymousPipeClientStream", ($self) => class AnonymousPipeClientStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction, /*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 176869;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":635621,"p":[{"p":766693,"s":{"r":0,"d":0,"h":21475013349,"f":32769},"n":"ReadMode","d":176869,"h":17180046053,"f":32769},{"p":766693,"g":{"r":0,"d":0,"h":30064947941,"f":32769},"n":"TransmissionMode","d":176869,"h":25769980645,"f":32769}],"c":[{"p":[{"n":"direction","p":504549},{"n":"safePipeHandle","p":111333}],"n":".ctor","o":"$ctor$5","d":176869,"h":4295144165,"f":1},{"p":[{"n":"direction","p":504549},{"n":"pipeHandleAsString","p":1310721}],"n":".ctor","o":"$ctor$6","d":176869,"h":8590111461,"f":1},{"p":[{"n":"pipeHandleAsString","p":1310721}],"n":".ctor","o":"$ctor$7","d":176869,"h":12885078757,"f":1}],"i":[57475073,56885249],"h":176869}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.AnonymousPipeClientStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.AnonymousPipeServerStream", ($self) => class AnonymousPipeServerStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5()
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ serverSafePipeHandle, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ clientSafePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability, /*int*/ bufferSize)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get ClientSafePipeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ DisposeLocalCopyOfClientHandle()
            {
            }
            $dtor()
            {
            }
            /*string */ GetClientHandleAsString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 242405;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":635621,"p":[{"p":111333,"g":{"r":0,"d":0,"h":30065013477,"f":1},"n":"ClientSafePipeHandle","d":242405,"h":25770046181,"f":1},{"p":766693,"s":{"r":0,"d":0,"h":38654948069,"f":32769},"n":"ReadMode","d":242405,"h":34359980773,"f":32769},{"p":766693,"g":{"r":0,"d":0,"h":47244882661,"f":32769},"n":"TransmissionMode","d":242405,"h":42949915365,"f":32769}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":242405,"h":51539849957,"f":32772},{"r":65537,"n":"DisposeLocalCopyOfClientHandle","d":242405,"h":55834817253,"f":1},{"r":1310721,"n":"GetClientHandleAsString","d":242405,"h":64424751845,"f":1}],"c":[{"n":".ctor","o":"$ctor$5","d":242405,"h":4295209701,"f":1},{"p":[{"n":"direction","p":504549}],"n":".ctor","o":"$ctor$6","d":242405,"h":8590176997,"f":1},{"p":[{"n":"direction","p":504549},{"n":"serverSafePipeHandle","p":111333},{"n":"clientSafePipeHandle","p":111333}],"n":".ctor","o":"$ctor$7","d":242405,"h":12885144293,"f":1},{"p":[{"n":"direction","p":504549},{"n":"inheritability","p":60555265}],"n":".ctor","o":"$ctor$8","d":242405,"h":17180111589,"f":1},{"p":[{"n":"direction","p":504549},{"n":"inheritability","p":60555265},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$9","d":242405,"h":21475078885,"f":1}],"i":[57475073,56885249],"h":242405}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.AnonymousPipeServerStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.NamedPipeClientStream", ($self) => class NamedPipeClientStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ serverName, /*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeAccessRights*/ desiredAccessRights, /*PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$10(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$11(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$12(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*int */ get NumberOfServerInstances()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CheckPipePropertyOperations()
            {
            }
            /*void */ Connect()
            {
            }
            /*void */ Connect$1(/*int*/ timeout)
            {
            }
            /*void */ Connect$2(/*System.TimeSpan*/ timeout)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$1(/*int*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*int*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$3(/*System.TimeSpan*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 307941;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":635621,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42949980901,"f":1},"n":"NumberOfServerInstances","d":307941,"h":38655013605,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"m":[{"r":65537,"n":"CheckPipePropertyOperations","d":307941,"h":47244948197,"f":32784},{"r":65537,"n":"Connect","d":307941,"h":51539915493,"f":1},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Connect","o":"@$1","d":307941,"h":55834882789,"f":1},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"Connect","o":"@$2","d":307941,"h":60129850085,"f":1},{"r":133300225,"n":"ConnectAsync","d":307941,"h":64424817381,"f":1},{"r":133300225,"p":[{"n":"timeout","p":655361}],"n":"ConnectAsync","o":"@$1","d":307941,"h":68719784677,"f":1},{"r":133300225,"p":[{"n":"timeout","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$2","d":307941,"h":73014751973,"f":1},{"r":133300225,"p":[{"n":"timeout","p":140705793},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":307941,"h":77309719269,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$4","d":307941,"h":81604686565,"f":1}],"c":[{"p":[{"n":"direction","p":504549},{"n":"isAsync","p":262145},{"n":"isConnected","p":262145},{"n":"safePipeHandle","p":111333}],"n":".ctor","o":"$ctor$5","d":307941,"h":4295275237,"f":1},{"p":[{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$6","d":307941,"h":8590242533,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$7","d":307941,"h":12885209829,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"desiredAccessRights","p":439013},{"n":"options","p":570085},{"n":"impersonationLevel","p":117243905},{"n":"inheritability","p":60555265}],"n":".ctor","o":"$ctor$8","d":307941,"h":17180177125,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":504549}],"n":".ctor","o":"$ctor$9","d":307941,"h":21475144421,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":504549},{"n":"options","p":570085}],"n":".ctor","o":"$ctor$10","d":307941,"h":25770111717,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":504549},{"n":"options","p":570085},{"n":"impersonationLevel","p":117243905}],"n":".ctor","o":"$ctor$11","d":307941,"h":30065079013,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":504549},{"n":"options","p":570085},{"n":"impersonationLevel","p":117243905},{"n":"inheritability","p":60555265}],"n":".ctor","o":"$ctor$12","d":307941,"h":34360046309,"f":1}],"i":[57475073,56885249],"h":307941}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.NamedPipeClientStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.NamedPipeServerStream", ($self) => class NamedPipeServerStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            /*int*/ static MaxAllowedServerInstances = -1;
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$10(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$11(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options, /*int*/ inBufferSize, /*int*/ outBufferSize)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*System.IAsyncResult */ BeginWaitForConnection(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Disconnect()
            {
            }
            /*void */ EndWaitForConnection(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*string */ GetImpersonationUserName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RunAsClient(/*System.IO.Pipes.PipeStreamImpersonationWorker*/ impersonationWorker)
            {
            }
            /*void */ WaitForConnection()
            {
            }
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 373477;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":635621,"m":[{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWaitForConnection","d":373477,"h":38655079141,"f":1},{"r":65537,"n":"Disconnect","d":373477,"h":42950046437,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWaitForConnection","d":373477,"h":47245013733,"f":1},{"r":1310721,"n":"GetImpersonationUserName","d":373477,"h":55834948325,"f":1},{"r":65537,"p":[{"n":"impersonationWorker","p":701157}],"n":"RunAsClient","d":373477,"h":60129915621,"f":1},{"r":65537,"n":"WaitForConnection","d":373477,"h":64424882917,"f":1},{"r":133300225,"n":"WaitForConnectionAsync","d":373477,"h":68719850213,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitForConnectionAsync","o":"@$1","d":373477,"h":73014817509,"f":1}],"l":[{"t":655361,"n":"MaxAllowedServerInstances","d":373477,"h":4295340773,"f":33}],"c":[{"p":[{"n":"direction","p":504549},{"n":"isAsync","p":262145},{"n":"isConnected","p":262145},{"n":"safePipeHandle","p":111333}],"n":".ctor","o":"$ctor$5","d":373477,"h":8590308069,"f":1},{"p":[{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$6","d":373477,"h":12885275365,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":504549}],"n":".ctor","o":"$ctor$7","d":373477,"h":17180242661,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":504549},{"n":"maxNumberOfServerInstances","p":655361}],"n":".ctor","o":"$ctor$8","d":373477,"h":21475209957,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":504549},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":766693}],"n":".ctor","o":"$ctor$9","d":373477,"h":25770177253,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":504549},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":766693},{"n":"options","p":570085}],"n":".ctor","o":"$ctor$10","d":373477,"h":30065144549,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":504549},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":766693},{"n":"options","p":570085},{"n":"inBufferSize","p":655361},{"n":"outBufferSize","p":655361}],"n":".ctor","o":"$ctor$11","d":373477,"h":34360111845,"f":1}],"i":[57475073,56885249],"h":373477}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.NamedPipeServerStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.PipeStreamImpersonationWorker", ($self) => class PipeStreamImpersonationWorker extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke()
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 701157;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"n":"Invoke","d":701157,"h":8590635749,"f":129},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":701157,"h":12885603045,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":701157,"h":17180570341,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":701157,"h":4295668453,"f":1}],"i":[57147393,113377281],"h":701157}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.Pipes.PipeStreamImpersonationWorker`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl"))