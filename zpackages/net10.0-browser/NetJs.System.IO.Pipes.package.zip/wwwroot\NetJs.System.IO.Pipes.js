
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $st, $sto, $stt, $sr, $scc, $scn, $ssc, $sris, $sspw, $ssa) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IO.Pipes", 
    {"h":53845,"f":"System.IO.Pipes","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.IO.Pipes","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IO.Pipes","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sip.System.IO.Pipes.PipeStream", ($self) => class PipeStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.IO.Pipes.PipeDirection*/ direction, /*int*/ bufferSize)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*int*/ outBufferSize)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsConnected()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set IsConnected(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsHandleExposed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMessageComplete()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get OutBufferSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get ReadMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get SafePipeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CheckPipePropertyOperations()
            {
            }
            /*void */ CheckReadOperations()
            {
            }
            /*void */ CheckWriteOperations()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ InitializeHandle(/*Microsoft.Win32.SafeHandles.SafePipeHandle?*/ handle, /*bool*/ isExposed, /*bool*/ isAsync)
            {
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ WaitForPipeDrain()
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 643669;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180512853,"f":32769},"n":"CanRead","d":643669,"h":12885545557,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":25770447445,"f":32769},"n":"CanSeek","d":643669,"h":21475480149,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360382037,"f":32769},"n":"CanWrite","d":643669,"h":30065414741,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":42950316629,"f":129},"n":"InBufferSize","d":643669,"h":38655349333,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":51540251221,"f":1},"n":"IsAsync","d":643669,"h":47245283925,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60130185813,"f":1},"s":{"r":0,"d":0,"h":64425153109,"f":4},"n":"IsConnected","d":643669,"h":55835218517,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73015087701,"f":4},"n":"IsHandleExposed","d":643669,"h":68720120405,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":81605022293,"f":1},"n":"IsMessageComplete","d":643669,"h":77310054997,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":90194956885,"f":32769},"n":"Length","d":643669,"h":85899989589,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":98784891477,"f":129},"n":"OutBufferSize","d":643669,"h":94489924181,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":107374826069,"f":32769},"s":{"r":0,"d":0,"h":111669793365,"f":32769},"n":"Position","d":643669,"h":103079858773,"f":32769},{"p":774741,"g":{"r":0,"d":0,"h":120259727957,"f":129},"s":{"r":0,"d":0,"h":124554695253,"f":129},"n":"ReadMode","d":643669,"h":115964760661,"f":129},{"p":119381,"g":{"r":0,"d":0,"h":133144629845,"f":1},"n":"SafePipeHandle","d":643669,"h":128849662549,"f":1},{"p":774741,"g":{"r":0,"d":0,"h":141734564437,"f":129},"n":"TransmissionMode","d":643669,"h":137439597141,"f":129}],"m":[{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginRead","d":643669,"h":146029531733,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWrite","d":643669,"h":150324499029,"f":32769},{"r":65537,"n":"CheckPipePropertyOperations","d":643669,"h":154619466325,"f":144},{"r":65537,"n":"CheckReadOperations","d":643669,"h":158914433621,"f":16},{"r":65537,"n":"CheckWriteOperations","d":643669,"h":163209400917,"f":16},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":643669,"h":167504368213,"f":32772},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":643669,"h":171799335509,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":643669,"h":176094302805,"f":32769},{"r":65537,"n":"Flush","d":643669,"h":180389270101,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":643669,"h":184684237397,"f":32769},{"r":65537,"p":[{"n":"handle","p":119381},{"n":"isExposed","p":262145},{"n":"isAsync","p":262145}],"n":"InitializeHandle","d":643669,"h":188979204693,"f":4},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":643669,"h":193274171989,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":643669,"h":197569139285,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":643669,"h":201864106581,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":643669,"h":206159073877,"f":32769},{"r":655361,"n":"ReadByte","d":643669,"h":210454041173,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":643669,"h":214749008469,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":643669,"h":219043975765,"f":32769},{"r":65537,"n":"WaitForPipeDrain","d":643669,"h":223338943061,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":643669,"h":227633910357,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":643669,"h":231928877653,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":643669,"h":236223844949,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":643669,"h":240518812245,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":643669,"h":244813779541,"f":32769}],"c":[{"p":[{"n":"direction","p":512597},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$3","d":643669,"h":4295610965,"f":4},{"p":[{"n":"direction","p":512597},{"n":"transmissionMode","p":774741},{"n":"outBufferSize","p":655361}],"n":".ctor","o":"$ctor$4","d":643669,"h":8590578261,"f":4}],"i":[57475073,56885249],"h":643669}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.PipeStream`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeAccessRights", ($self) => class PipeAccessRights extends $.$spc.System.Enum
        {
            static ReadData = 1;
            static WriteData = 2;
            static CreateNewInstance = 4;
            static ReadExtendedAttributes = 8;
            static WriteExtendedAttributes = 16;
            static ReadAttributes = 128;
            static WriteAttributes = 256;
            static Write = 274;
            static Delete = 65536;
            static ReadPermissions = 131072;
            static Read = 131209;
            static ReadWrite = 131483;
            static ChangePermissions = 262144;
            static TakeOwnership = 524288;
            static Synchronize = 1048576;
            static FullControl = 2032031;
            static AccessSystemSecurity = 16777216;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ReadData": 1n,
                    "WriteData": 2n,
                    "CreateNewInstance": 4n,
                    "ReadExtendedAttributes": 8n,
                    "WriteExtendedAttributes": 16n,
                    "ReadAttributes": 128n,
                    "WriteAttributes": 256n,
                    "Write": 274n,
                    "Delete": 65536n,
                    "ReadPermissions": 131072n,
                    "Read": 131209n,
                    "ReadWrite": 131483n,
                    "ChangePermissions": 262144n,
                    "TakeOwnership": 524288n,
                    "Synchronize": 1048576n,
                    "FullControl": 2032031n,
                    "AccessSystemSecurity": 16777216n
                };
            }
            static $h = 447061;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":447061,"n":"ReadData","d":447061,"h":4295414357,"f":33},{"t":447061,"n":"WriteData","d":447061,"h":8590381653,"f":33},{"t":447061,"n":"CreateNewInstance","d":447061,"h":12885348949,"f":33},{"t":447061,"n":"ReadExtendedAttributes","d":447061,"h":17180316245,"f":33},{"t":447061,"n":"WriteExtendedAttributes","d":447061,"h":21475283541,"f":33},{"t":447061,"n":"ReadAttributes","d":447061,"h":25770250837,"f":33},{"t":447061,"n":"WriteAttributes","d":447061,"h":30065218133,"f":33},{"t":447061,"n":"Write","d":447061,"h":34360185429,"f":33},{"t":447061,"n":"Delete","d":447061,"h":38655152725,"f":33},{"t":447061,"n":"ReadPermissions","d":447061,"h":42950120021,"f":33},{"t":447061,"n":"Read","d":447061,"h":47245087317,"f":33},{"t":447061,"n":"ReadWrite","d":447061,"h":51540054613,"f":33},{"t":447061,"n":"ChangePermissions","d":447061,"h":55835021909,"f":33},{"t":447061,"n":"TakeOwnership","d":447061,"h":60129989205,"f":33},{"t":447061,"n":"Synchronize","d":447061,"h":64424956501,"f":33},{"t":447061,"n":"FullControl","d":447061,"h":68719923797,"f":33},{"t":447061,"n":"AccessSystemSecurity","d":447061,"h":73014891093,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":447061,"h":77309858389,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":447061,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeAccessRights`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeDirection", ($self) => class PipeDirection extends $.$spc.System.Enum
        {
            static In = 1;
            static Out = 2;
            static InOut = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "In": 1n,
                    "Out": 2n,
                    "InOut": 3n
                };
            }
            static $h = 512597;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":512597,"n":"In","d":512597,"h":4295479893,"f":33},{"t":512597,"n":"Out","d":512597,"h":8590447189,"f":33},{"t":512597,"n":"InOut","d":512597,"h":12885414485,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":512597,"h":17180381781,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":512597}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeDirection`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeOptions", ($self) => class PipeOptions extends $.$spc.System.Enum
        {
            static WriteThrough = -2147483648;
            static None = 0;
            static CurrentUserOnly = 536870912;
            static Asynchronous = 1073741824;
            static FirstPipeInstance = 524288;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "WriteThrough": -2147483648n,
                    "None": 0n,
                    "CurrentUserOnly": 536870912n,
                    "Asynchronous": 1073741824n,
                    "FirstPipeInstance": 524288n
                };
            }
            static $h = 578133;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":578133,"n":"WriteThrough","d":578133,"h":4295545429,"f":33},{"t":578133,"n":"None","d":578133,"h":8590512725,"f":33},{"t":578133,"n":"CurrentUserOnly","d":578133,"h":12885480021,"f":33},{"t":578133,"n":"Asynchronous","d":578133,"h":17180447317,"f":33},{"t":578133,"n":"FirstPipeInstance","d":578133,"h":21475414613,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":578133,"h":25770381909,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":578133,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeOptions`; }
        });
        
        $asm.$str("$sip.System.IO.Pipes.PipeTransmissionMode", ($self) => class PipeTransmissionMode extends $.$spc.System.Enum
        {
            static Byte = 0;
            static Message = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Byte": 0n,
                    "Message": 1n
                };
            }
            static $h = 774741;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":774741,"n":"Byte","d":774741,"h":4295742037,"f":33},{"t":774741,"n":"Message","d":774741,"h":8590709333,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":774741,"h":12885676629,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":774741}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.IO.Pipes.PipeTransmissionMode`; }
        });
        
        $asm.$cls("$sip.Microsoft.Win32.SafeHandles.SafePipeHandle", ($self) => class SafePipeHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 119381;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17179988565,"f":32769},"n":"IsInvalid","d":119381,"h":12885021269,"f":32769}],"m":[{"r":262145,"n":"ReleaseHandle","d":119381,"h":21474955861,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":119381,"h":4295086677,"f":1},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":119381,"h":8590053973,"f":1}],"i":[57475073],"h":119381}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafePipeHandle`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.AnonymousPipeClientStream", ($self) => class AnonymousPipeClientStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction, /*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ pipeHandleAsString)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 184917;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":643669,"p":[{"p":774741,"s":{"r":0,"d":0,"h":21475021397,"f":32769},"n":"ReadMode","d":184917,"h":17180054101,"f":32769},{"p":774741,"g":{"r":0,"d":0,"h":30064955989,"f":32769},"n":"TransmissionMode","d":184917,"h":25769988693,"f":32769}],"c":[{"p":[{"n":"direction","p":512597},{"n":"safePipeHandle","p":119381}],"n":".ctor","o":"$ctor$5","d":184917,"h":4295152213,"f":1},{"p":[{"n":"direction","p":512597},{"n":"pipeHandleAsString","p":1310721}],"n":".ctor","o":"$ctor$6","d":184917,"h":8590119509,"f":1},{"p":[{"n":"pipeHandleAsString","p":1310721}],"n":".ctor","o":"$ctor$7","d":184917,"h":12885086805,"f":1}],"i":[57475073,56885249],"h":184917}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.AnonymousPipeClientStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.AnonymousPipeServerStream", ($self) => class AnonymousPipeServerStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5()
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Pipes.PipeDirection*/ direction, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ serverSafePipeHandle, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ clientSafePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.HandleInheritability*/ inheritability, /*int*/ bufferSize)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*Microsoft.Win32.SafeHandles.SafePipeHandle */ get ClientSafePipeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ set ReadMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.Pipes.PipeTransmissionMode */ get TransmissionMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ DisposeLocalCopyOfClientHandle()
            {
            }
            $dtor()
            {
            }
            /*string */ GetClientHandleAsString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 250453;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":643669,"p":[{"p":119381,"g":{"r":0,"d":0,"h":30065021525,"f":1},"n":"ClientSafePipeHandle","d":250453,"h":25770054229,"f":1},{"p":774741,"s":{"r":0,"d":0,"h":38654956117,"f":32769},"n":"ReadMode","d":250453,"h":34359988821,"f":32769},{"p":774741,"g":{"r":0,"d":0,"h":47244890709,"f":32769},"n":"TransmissionMode","d":250453,"h":42949923413,"f":32769}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":250453,"h":51539858005,"f":32772},{"r":65537,"n":"DisposeLocalCopyOfClientHandle","d":250453,"h":55834825301,"f":1},{"r":1310721,"n":"GetClientHandleAsString","d":250453,"h":64424759893,"f":1}],"c":[{"n":".ctor","o":"$ctor$5","d":250453,"h":4295217749,"f":1},{"p":[{"n":"direction","p":512597}],"n":".ctor","o":"$ctor$6","d":250453,"h":8590185045,"f":1},{"p":[{"n":"direction","p":512597},{"n":"serverSafePipeHandle","p":119381},{"n":"clientSafePipeHandle","p":119381}],"n":".ctor","o":"$ctor$7","d":250453,"h":12885152341,"f":1},{"p":[{"n":"direction","p":512597},{"n":"inheritability","p":60555265}],"n":".ctor","o":"$ctor$8","d":250453,"h":17180119637,"f":1},{"p":[{"n":"direction","p":512597},{"n":"inheritability","p":60555265},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$9","d":250453,"h":21475086933,"f":1}],"i":[57475073,56885249],"h":250453}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.AnonymousPipeServerStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.NamedPipeClientStream", ($self) => class NamedPipeClientStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ serverName, /*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeAccessRights*/ desiredAccessRights, /*PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$10(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$11(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$12(/*string*/ serverName, /*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*System.IO.Pipes.PipeOptions*/ options, /*System.Security.Principal.TokenImpersonationLevel*/ impersonationLevel, /*System.IO.HandleInheritability*/ inheritability)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*int */ get NumberOfServerInstances()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CheckPipePropertyOperations()
            {
            }
            /*void */ Connect()
            {
            }
            /*void */ Connect$1(/*int*/ timeout)
            {
            }
            /*void */ Connect$2(/*System.TimeSpan*/ timeout)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$1(/*int*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$2(/*int*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$3(/*System.TimeSpan*/ timeout, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$4(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 315989;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":643669,"p":[{"p":655361,"g":{"r":0,"d":0,"h":42949988949,"f":1},"n":"NumberOfServerInstances","d":315989,"h":38655021653,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"m":[{"r":65537,"n":"CheckPipePropertyOperations","d":315989,"h":47244956245,"f":32784},{"r":65537,"n":"Connect","d":315989,"h":51539923541,"f":1},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Connect","o":"@$1","d":315989,"h":55834890837,"f":1},{"r":65537,"p":[{"n":"timeout","p":140705793}],"n":"Connect","o":"@$2","d":315989,"h":60129858133,"f":1},{"r":133300225,"n":"ConnectAsync","d":315989,"h":64424825429,"f":1},{"r":133300225,"p":[{"n":"timeout","p":655361}],"n":"ConnectAsync","o":"@$1","d":315989,"h":68719792725,"f":1},{"r":133300225,"p":[{"n":"timeout","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$2","d":315989,"h":73014760021,"f":1},{"r":133300225,"p":[{"n":"timeout","p":140705793},{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$3","d":315989,"h":77309727317,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"ConnectAsync","o":"@$4","d":315989,"h":81604694613,"f":1}],"c":[{"p":[{"n":"direction","p":512597},{"n":"isAsync","p":262145},{"n":"isConnected","p":262145},{"n":"safePipeHandle","p":119381}],"n":".ctor","o":"$ctor$5","d":315989,"h":4295283285,"f":1},{"p":[{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$6","d":315989,"h":8590250581,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$7","d":315989,"h":12885217877,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"desiredAccessRights","p":447061},{"n":"options","p":578133},{"n":"impersonationLevel","p":117243905},{"n":"inheritability","p":60555265}],"n":".ctor","o":"$ctor$8","d":315989,"h":17180185173,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":512597}],"n":".ctor","o":"$ctor$9","d":315989,"h":21475152469,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":512597},{"n":"options","p":578133}],"n":".ctor","o":"$ctor$10","d":315989,"h":25770119765,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":512597},{"n":"options","p":578133},{"n":"impersonationLevel","p":117243905}],"n":".ctor","o":"$ctor$11","d":315989,"h":30065087061,"f":1},{"p":[{"n":"serverName","p":1310721},{"n":"pipeName","p":1310721},{"n":"direction","p":512597},{"n":"options","p":578133},{"n":"impersonationLevel","p":117243905},{"n":"inheritability","p":60555265}],"n":".ctor","o":"$ctor$12","d":315989,"h":34360054357,"f":1}],"i":[57475073,56885249],"h":315989}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.NamedPipeClientStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.NamedPipeServerStream", ($self) => class NamedPipeServerStream extends $.$sip.System.IO.Pipes.PipeStream
        {
            /*int*/ static MaxAllowedServerInstances = -1;
            $ctor$5(/*System.IO.Pipes.PipeDirection*/ direction, /*bool*/ isAsync, /*bool*/ isConnected, /*Microsoft.Win32.SafeHandles.SafePipeHandle*/ safePipeHandle)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$6(/*string*/ pipeName)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$7(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$8(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$9(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$10(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            $ctor$11(/*string*/ pipeName, /*System.IO.Pipes.PipeDirection*/ direction, /*int*/ maxNumberOfServerInstances, /*System.IO.Pipes.PipeTransmissionMode*/ transmissionMode, /*System.IO.Pipes.PipeOptions*/ options, /*int*/ inBufferSize, /*int*/ outBufferSize)
            {
                super.$ctor$3(0, 0);
                {
                }
                return this;
            }
            /*System.IAsyncResult */ BeginWaitForConnection(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Disconnect()
            {
            }
            /*void */ EndWaitForConnection(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*string */ GetImpersonationUserName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ RunAsClient(/*System.IO.Pipes.PipeStreamImpersonationWorker*/ impersonationWorker)
            {
            }
            /*void */ WaitForConnection()
            {
            }
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ WaitForConnectionAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 381525;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":643669,"m":[{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWaitForConnection","d":381525,"h":38655087189,"f":1},{"r":65537,"n":"Disconnect","d":381525,"h":42950054485,"f":1},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWaitForConnection","d":381525,"h":47245021781,"f":1},{"r":1310721,"n":"GetImpersonationUserName","d":381525,"h":55834956373,"f":1},{"r":65537,"p":[{"n":"impersonationWorker","p":709205}],"n":"RunAsClient","d":381525,"h":60129923669,"f":1},{"r":65537,"n":"WaitForConnection","d":381525,"h":64424890965,"f":1},{"r":133300225,"n":"WaitForConnectionAsync","d":381525,"h":68719858261,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"WaitForConnectionAsync","o":"@$1","d":381525,"h":73014825557,"f":1}],"l":[{"t":655361,"n":"MaxAllowedServerInstances","d":381525,"h":4295348821,"f":33}],"c":[{"p":[{"n":"direction","p":512597},{"n":"isAsync","p":262145},{"n":"isConnected","p":262145},{"n":"safePipeHandle","p":119381}],"n":".ctor","o":"$ctor$5","d":381525,"h":8590316117,"f":1},{"p":[{"n":"pipeName","p":1310721}],"n":".ctor","o":"$ctor$6","d":381525,"h":12885283413,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":512597}],"n":".ctor","o":"$ctor$7","d":381525,"h":17180250709,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":512597},{"n":"maxNumberOfServerInstances","p":655361}],"n":".ctor","o":"$ctor$8","d":381525,"h":21475218005,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":512597},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":774741}],"n":".ctor","o":"$ctor$9","d":381525,"h":25770185301,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":512597},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":774741},{"n":"options","p":578133}],"n":".ctor","o":"$ctor$10","d":381525,"h":30065152597,"f":1},{"p":[{"n":"pipeName","p":1310721},{"n":"direction","p":512597},{"n":"maxNumberOfServerInstances","p":655361},{"n":"transmissionMode","p":774741},{"n":"options","p":578133},{"n":"inBufferSize","p":655361},{"n":"outBufferSize","p":655361}],"n":".ctor","o":"$ctor$11","d":381525,"h":34360119893,"f":1}],"i":[57475073,56885249],"h":381525}; }
            static get $b() { return $.$sip.System.IO.Pipes.PipeStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.Pipes.NamedPipeServerStream`; }
        });
        
        $asm.$cls("$sip.System.IO.Pipes.PipeStreamImpersonationWorker", ($self) => class PipeStreamImpersonationWorker extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke()
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 709205;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"n":"Invoke","d":709205,"h":8590643797,"f":129},{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":709205,"h":12885611093,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":709205,"h":17180578389,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":709205,"h":4295676501,"f":1}],"i":[57147393,113377281],"h":709205}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.IO.Pipes.PipeStreamImpersonationWorker`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl"))