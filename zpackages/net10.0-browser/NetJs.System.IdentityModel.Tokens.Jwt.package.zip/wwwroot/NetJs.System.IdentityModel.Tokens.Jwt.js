
(function ($global, $, $$, $mia, $sc, $sm, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $mwp, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sci, $sim, $srm, $sds, $srn, $sfa, $sscr, $snsc, $stc, $snq, $srij, $snh, $mil, $scm, $so, $sre, $srei, $srel, $srp, $sle, $mxdi, $med, $mela, $mep, $scp, $scs, $sdp, $srw, $srl, $srsf, $str, $sdts, $spx, $spxl, $sxxd, $sct, $sca, $meo, $mel, $sipl, $stew, $stj, $mit, $mij) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IdentityModel.Tokens.Jwt", 
    {"h":57249,"f":"System.IdentityModel.Tokens.Jwt","v":"1.0.35.0","a":[{"t":74448897,"c":4369416193,"a":[{"v":"Serviceable","t":1310721},{"v":"True","t":1310721}]},{"t":23527425,"c":8613462017,"a":[{"v":true,"t":262145}]},{"t":102432769,"c":4397400065,"a":[{"v":false,"t":262145}]},{"t":92274689,"c":4387241985,"a":[{"v":"System.IdentityModel.Tokens.Jwt.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsAotCompatible","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"Microsoft Corporation.","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":73793537,"c":4368760833,"a":[{"v":"\u00A9 Microsoft Corporation. All rights reserved.","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Includes types that provide support for creating, serializing and validating JSON Web Tokens. As of IdentityModel 7x, this is a legacy tool that should be replaced with Microsoft.IdentityModel.JsonWebTokens.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"9.0.0.26241","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"Microsoft IdentityModel","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.IdentityModel.Tokens.Jwt","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"RepositoryUrl","t":1310721},{"v":"https://github.com/AzureAD/azure-activedirectory-identitymodel-extensions-for-dotnet","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenConverter", ($self) => class JwtSecurityTokenConverter
        {
            static /*JwtSecurityToken */ Convert(/*JsonWebToken*/ token)
            {
                if (token === null)
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("token");
                }
                if (token.InnerToken !== null)
                {
                    /*var*/ let jwtSecurityToken = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$3(token.EncodedToken);
                    jwtSecurityToken.InnerToken = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$3(token.InnerToken.EncodedToken);
                    return jwtSecurityToken;
                }
                else if (!$.$$.System.String.IsNullOrEmpty(token.EncodedToken))
                {
                    return new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$3(token.EncodedToken);
                }
                throw new $.$$.System.ArgumentException().$ctor$14("token.EncodedToken must be set");
            }
            static $h = 581537;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":516001,"p":[{"n":"token","p":326941}],"n":"Convert","d":581537,"h":4295548833,"f":16777249}],"h":581537}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtSecurityTokenConverter`; }
        });
        
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.LogMessages", ($self) => class LogMessages
        {
            /*string*/ static IDX12401 = null;
            /*string*/ static IDX12706 = null;
            /*string*/ static IDX12709 = null;
            /*string*/ static IDX12710 = null;
            /*string*/ static IDX12711 = null;
            /*string*/ static IDX12712 = null;
            /*string*/ static IDX12713 = null;
            /*string*/ static IDX12714 = null;
            /*string*/ static IDX12715 = null;
            /*string*/ static IDX12720 = null;
            /*string*/ static IDX12721 = null;
            /*string*/ static IDX12722 = null;
            /*string*/ static IDX12723 = null;
            /*string*/ static IDX12729 = null;
            /*string*/ static IDX12730 = null;
            /*string*/ static IDX12735 = null;
            /*string*/ static IDX12736 = null;
            /*string*/ static IDX12737 = null;
            /*string*/ static IDX12738 = null;
            /*string*/ static IDX12739 = null;
            /*string*/ static IDX12740 = null;
            /*string*/ static IDX12741 = null;
            /*string*/ static IDX12742 = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.IDX12401 = "IDX12401: Expires: '{0}' must be after NotBefore: '{1}'.";
                }
                {
                    this.IDX12706 = "IDX12706: '{0}' can only write SecurityTokens of type: '{1}', 'token' type is: '{2}'.";
                }
                {
                    this.IDX12709 = "IDX12709: CanReadToken() returned false. JWT is not well formed.\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                }
                {
                    this.IDX12710 = "IDX12710: Only a single 'Actor' is supported. Found second claim of type: '{0}', value: '{1}'";
                }
                {
                    this.IDX12711 = "IDX12711: actor.BootstrapContext is not a string AND actor.BootstrapContext is not a JWT";
                }
                {
                    this.IDX12712 = "IDX12712: actor.BootstrapContext is null. Creating the token using actor.Claims.";
                }
                {
                    this.IDX12713 = "IDX12713: Creating actor value using actor.BootstrapContext(as string)";
                }
                {
                    this.IDX12714 = "IDX12714: Creating actor value using actor.BootstrapContext.rawData";
                }
                {
                    this.IDX12715 = "IDX12715: Creating actor value by writing the JwtSecurityToken created from actor.BootstrapContext";
                }
                {
                    this.IDX12720 = "IDX12720: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)";
                }
                {
                    this.IDX12721 = "IDX12721: Creating JwtSecurityToken: Issuer: '{0}', Audience: '{1}'";
                }
                {
                    this.IDX12722 = "IDX12722: Creating security token from the header: '{0}', payload: '{1}'.";
                }
                {
                    this.IDX12723 = "IDX12723: Unable to decode the payload '{0}' as Base64Url encoded string.";
                }
                {
                    this.IDX12729 = "IDX12729: Unable to decode the header '{0}' as Base64Url encoded string.";
                }
                {
                    this.IDX12730 = "IDX12730: Failed to create the token encryption provider.";
                }
                {
                    this.IDX12735 = "IDX12735: If JwtSecurityToken.InnerToken != null, then JwtSecurityToken.Header.EncryptingCredentials must be set.";
                }
                {
                    this.IDX12736 = "IDX12736: JwtSecurityToken.SigningCredentials is not supported when JwtSecurityToken.InnerToken is set.";
                }
                {
                    this.IDX12737 = "IDX12737: EncryptingCredentials set on JwtSecurityToken.InnerToken is not supported.";
                }
                {
                    this.IDX12738 = "IDX12738: Header.Cty != null, assuming JWS. Cty: '{0}'.";
                }
                {
                    this.IDX12739 = "IDX12739: JWT has three segments but is not in proper JWS format.";
                }
                {
                    this.IDX12740 = "IDX12740: JWT has five segments but is not in proper JWE format.";
                }
                {
                    this.IDX12741 = "IDX12741: JWT must have three segments (JWS) or five segments (JWE).";
                }
                {
                    this.IDX12742 = "IDX12742: ''{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation.";
                }
            }
            static $h = 778145;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"IDX12401","d":778145,"h":4295745441,"f":4194344},{"t":1310721,"n":"IDX12706","d":778145,"h":8590712737,"f":4194344},{"t":1310721,"n":"IDX12709","d":778145,"h":12885680033,"f":4194344},{"t":1310721,"n":"IDX12710","d":778145,"h":17180647329,"f":4194344},{"t":1310721,"n":"IDX12711","d":778145,"h":21475614625,"f":4194344},{"t":1310721,"n":"IDX12712","d":778145,"h":25770581921,"f":4194344},{"t":1310721,"n":"IDX12713","d":778145,"h":30065549217,"f":4194344},{"t":1310721,"n":"IDX12714","d":778145,"h":34360516513,"f":4194344},{"t":1310721,"n":"IDX12715","d":778145,"h":38655483809,"f":4194344},{"t":1310721,"n":"IDX12720","d":778145,"h":42950451105,"f":4194344},{"t":1310721,"n":"IDX12721","d":778145,"h":47245418401,"f":4194344},{"t":1310721,"n":"IDX12722","d":778145,"h":51540385697,"f":4194344},{"t":1310721,"n":"IDX12723","d":778145,"h":55835352993,"f":4194344},{"t":1310721,"n":"IDX12729","d":778145,"h":60130320289,"f":4194344},{"t":1310721,"n":"IDX12730","d":778145,"h":64425287585,"f":4194344},{"t":1310721,"n":"IDX12735","d":778145,"h":68720254881,"f":4194344},{"t":1310721,"n":"IDX12736","d":778145,"h":73015222177,"f":4194344},{"t":1310721,"n":"IDX12737","d":778145,"h":77310189473,"f":4194344},{"t":1310721,"n":"IDX12738","d":778145,"h":81605156769,"f":4194344},{"t":1310721,"n":"IDX12739","d":778145,"h":85900124065,"f":4194344},{"t":1310721,"n":"IDX12740","d":778145,"h":90195091361,"f":4194344},{"t":1310721,"n":"IDX12741","d":778145,"h":94490058657,"f":4194344},{"t":1310721,"n":"IDX12742","d":778145,"h":98785025953,"f":4194344}],"h":778145}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.LogMessages`; }
        });
        
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JwtConstants", ($self) => class JwtConstants
        {
            /*string*/ static HeaderType = null;
            /*string*/ static HeaderTypeAlt = null;
            /*string*/ static TokenType = null;
            /*string*/ static TokenTypeAlt = null;
            /*string*/ static JsonCompactSerializationRegex = null;
            /*string*/ static JweCompactSerializationRegex = null;
            /*int*/ static JweSegmentCount = 5;
            /*int*/ static JwsSegmentCount = 3;
            /*int*/ static MaxJwtSegmentCount = 5;
            /*string*/ static DirectKeyUseAlg = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.HeaderType = "JWT";
                }
                {
                    this.HeaderTypeAlt = "http://openid.net/specs/jwt/1.0";
                }
                {
                    this.TokenType = "JWT";
                }
                {
                    this.TokenTypeAlt = "urn:ietf:params:oauth:token-type:jwt";
                }
                {
                    this.JsonCompactSerializationRegex = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*$";
                }
                {
                    this.JweCompactSerializationRegex = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+$";
                }
                {
                    this.DirectKeyUseAlg = "dir";
                }
            }
            static $h = 188321;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"HeaderType","d":188321,"h":4295155617,"f":4194337},{"t":1310721,"n":"HeaderTypeAlt","d":188321,"h":8590122913,"f":4194337},{"t":1310721,"n":"TokenType","d":188321,"h":12885090209,"f":4194337},{"t":1310721,"n":"TokenTypeAlt","d":188321,"h":17180057505,"f":4194337},{"t":1310721,"n":"JsonCompactSerializationRegex","d":188321,"h":21475024801,"f":4194337},{"t":1310721,"n":"JweCompactSerializationRegex","d":188321,"h":25769992097,"f":4194337},{"t":655361,"n":"JweSegmentCount","d":188321,"h":30064959393,"f":4194344},{"t":655361,"n":"JwsSegmentCount","d":188321,"h":34359926689,"f":4194344},{"t":655361,"n":"MaxJwtSegmentCount","d":188321,"h":38654893985,"f":4194344},{"t":1310721,"n":"DirectKeyUseAlg","d":188321,"h":42949861281,"f":4194337}],"h":188321}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtConstants`; }
        });
        
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JsonClaimValueTypes", ($self) => class JsonClaimValueTypes
        {
            /*string*/ static Json = null;
            /*string*/ static JsonArray = null;
            /*string*/ static JsonNull = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.Json = "JSON";
                }
                {
                    this.JsonArray = "JSON_ARRAY";
                }
                {
                    this.JsonNull = "JSON_NULL";
                }
            }
            static $h = 122785;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"Json","d":122785,"h":4295090081,"f":4194337},{"t":1310721,"n":"JsonArray","d":122785,"h":8590057377,"f":4194337},{"t":1310721,"n":"JsonNull","d":122785,"h":12885024673,"f":4194337}],"h":122785}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JsonClaimValueTypes`; }
        });
        
        $asm.$str("$sitj.System.IdentityModel.Tokens.Jwt.JwtHeaderParameterNames", ($self) => class JwtHeaderParameterNames extends $.$$.System.ValueType
        {
            /*string*/ static Alg = null;
            /*string*/ static Cty = null;
            /*string*/ static Enc = null;
            /*string*/ static IV = null;
            /*string*/ static Jku = null;
            /*string*/ static Jwk = null;
            /*string*/ static Kid = null;
            /*string*/ static Typ = null;
            /*string*/ static X5c = null;
            /*string*/ static X5t = null;
            /*string*/ static X5u = null;
            /*string*/ static Zip = null;
            /*string*/ static Epk = null;
            /*string*/ static Apu = null;
            /*string*/ static Apv = null;
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Alg = "alg";
                }
                {
                    this.Cty = "cty";
                }
                {
                    this.Enc = "enc";
                }
                {
                    this.IV = "iv";
                }
                {
                    this.Jku = "jku";
                }
                {
                    this.Jwk = "jwk";
                }
                {
                    this.Kid = "kid";
                }
                {
                    this.Typ = "typ";
                }
                {
                    this.X5c = "x5c";
                }
                {
                    this.X5t = "x5t";
                }
                {
                    this.X5u = "x5u";
                }
                {
                    this.Zip = "zip";
                }
                {
                    this.Epk = "epk";
                }
                {
                    this.Apu = "apu";
                }
                {
                    this.Apv = "apv";
                }
            }
            static $h = 319393;
            static $z = 0;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":1310721,"n":"Alg","d":319393,"h":4295286689,"f":4194337},{"t":1310721,"n":"Cty","d":319393,"h":8590253985,"f":4194337},{"t":1310721,"n":"Enc","d":319393,"h":12885221281,"f":4194337},{"t":1310721,"n":"IV","d":319393,"h":17180188577,"f":4194337},{"t":1310721,"n":"Jku","d":319393,"h":21475155873,"f":4194337},{"t":1310721,"n":"Jwk","d":319393,"h":25770123169,"f":4194337},{"t":1310721,"n":"Kid","d":319393,"h":30065090465,"f":4194337},{"t":1310721,"n":"Typ","d":319393,"h":34360057761,"f":4194337},{"t":1310721,"n":"X5c","d":319393,"h":38655025057,"f":4194337},{"t":1310721,"n":"X5t","d":319393,"h":42949992353,"f":4194337},{"t":1310721,"n":"X5u","d":319393,"h":47244959649,"f":4194337},{"t":1310721,"n":"Zip","d":319393,"h":51539926945,"f":4194337},{"t":1310721,"n":"Epk","d":319393,"h":55834894241,"f":4194337},{"t":1310721,"n":"Apu","d":319393,"h":60129861537,"f":4194337},{"t":1310721,"n":"Apv","d":319393,"h":64424828833,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$2","d":319393,"h":68719796129,"f":16777217}],"h":319393}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtHeaderParameterNames`; }
        });
        
        $asm.$str("$sitj.System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames", ($self) => class JwtRegisteredClaimNames extends $.$$.System.ValueType
        {
            /*string*/ static Act = null;
            /*string*/ static Actort = null;
            /*string*/ static Acr = null;
            /*string*/ static Alg = null;
            /*string*/ static Amr = null;
            /*string*/ static Address = null;
            /*string*/ static AtHash = null;
            /*string*/ static Aud = null;
            /*string*/ static AuthTime = null;
            /*string*/ static Azp = null;
            /*string*/ static Birthdate = null;
            /*string*/ static CHash = null;
            /*string*/ static Email = null;
            /*string*/ static EmailVerified = null;
            /*string*/ static Exp = null;
            /*string*/ static Gender = null;
            /*string*/ static FamilyName = null;
            /*string*/ static GivenName = null;
            /*string*/ static Iat = null;
            /*string*/ static Iss = null;
            /*string*/ static Jti = null;
            /*string*/ static Locale = null;
            /*string*/ static MiddleName = null;
            /*string*/ static Name = null;
            /*string*/ static NameId = null;
            /*string*/ static Nickname = null;
            /*string*/ static Nonce = null;
            /*string*/ static Nbf = null;
            /*string*/ static PhoneNumber = null;
            /*string*/ static PhoneNumberVerified = null;
            /*string*/ static Picture = null;
            /*string*/ static Prn = null;
            /*string*/ static PreferredUsername = null;
            /*string*/ static Profile = null;
            /*string*/ static Sid = null;
            /*string*/ static Sub = null;
            /*string*/ static Typ = null;
            /*string*/ static UniqueName = null;
            /*string*/ static UpdatedAt = null;
            /*string*/ static Website = null;
            /*string*/ static ZoneInfo = null;
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Act = "act";
                }
                {
                    this.Actort = "actort";
                }
                {
                    this.Acr = "acr";
                }
                {
                    this.Alg = "alg";
                }
                {
                    this.Amr = "amr";
                }
                {
                    this.Address = "address";
                }
                {
                    this.AtHash = "at_hash";
                }
                {
                    this.Aud = "aud";
                }
                {
                    this.AuthTime = "auth_time";
                }
                {
                    this.Azp = "azp";
                }
                {
                    this.Birthdate = "birthdate";
                }
                {
                    this.CHash = "c_hash";
                }
                {
                    this.Email = "email";
                }
                {
                    this.EmailVerified = "email_verified";
                }
                {
                    this.Exp = "exp";
                }
                {
                    this.Gender = "gender";
                }
                {
                    this.FamilyName = "family_name";
                }
                {
                    this.GivenName = "given_name";
                }
                {
                    this.Iat = "iat";
                }
                {
                    this.Iss = "iss";
                }
                {
                    this.Jti = "jti";
                }
                {
                    this.Locale = "locale";
                }
                {
                    this.MiddleName = "middle_name";
                }
                {
                    this.Name = "name";
                }
                {
                    this.NameId = "nameid";
                }
                {
                    this.Nickname = "nickname";
                }
                {
                    this.Nonce = "nonce";
                }
                {
                    this.Nbf = "nbf";
                }
                {
                    this.PhoneNumber = "phone_number";
                }
                {
                    this.PhoneNumberVerified = "phone_number_verified";
                }
                {
                    this.Picture = "picture";
                }
                {
                    this.Prn = "prn";
                }
                {
                    this.PreferredUsername = "preferred_username";
                }
                {
                    this.Profile = "profile";
                }
                {
                    this.Sid = "sid";
                }
                {
                    this.Sub = "sub";
                }
                {
                    this.Typ = "typ";
                }
                {
                    this.UniqueName = "unique_name";
                }
                {
                    this.UpdatedAt = "updated_at";
                }
                {
                    this.Website = "website";
                }
                {
                    this.ZoneInfo = "zoneinfo";
                }
            }
            static $h = 450465;
            static $z = 0;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":1310721,"n":"Act","d":450465,"h":4295417761,"f":4194337},{"t":1310721,"n":"Actort","d":450465,"h":8590385057,"f":4194337},{"t":1310721,"n":"Acr","d":450465,"h":12885352353,"f":4194337},{"t":1310721,"n":"Alg","d":450465,"h":17180319649,"f":4194337},{"t":1310721,"n":"Amr","d":450465,"h":21475286945,"f":4194337},{"t":1310721,"n":"Address","d":450465,"h":25770254241,"f":4194337},{"t":1310721,"n":"AtHash","d":450465,"h":30065221537,"f":4194337},{"t":1310721,"n":"Aud","d":450465,"h":34360188833,"f":4194337},{"t":1310721,"n":"AuthTime","d":450465,"h":38655156129,"f":4194337},{"t":1310721,"n":"Azp","d":450465,"h":42950123425,"f":4194337},{"t":1310721,"n":"Birthdate","d":450465,"h":47245090721,"f":4194337},{"t":1310721,"n":"CHash","d":450465,"h":51540058017,"f":4194337},{"t":1310721,"n":"Email","d":450465,"h":55835025313,"f":4194337},{"t":1310721,"n":"EmailVerified","d":450465,"h":60129992609,"f":4194337},{"t":1310721,"n":"Exp","d":450465,"h":64424959905,"f":4194337},{"t":1310721,"n":"Gender","d":450465,"h":68719927201,"f":4194337},{"t":1310721,"n":"FamilyName","d":450465,"h":73014894497,"f":4194337},{"t":1310721,"n":"GivenName","d":450465,"h":77309861793,"f":4194337},{"t":1310721,"n":"Iat","d":450465,"h":81604829089,"f":4194337},{"t":1310721,"n":"Iss","d":450465,"h":85899796385,"f":4194337},{"t":1310721,"n":"Jti","d":450465,"h":90194763681,"f":4194337},{"t":1310721,"n":"Locale","d":450465,"h":94489730977,"f":4194337},{"t":1310721,"n":"MiddleName","d":450465,"h":98784698273,"f":4194337},{"t":1310721,"n":"Name","d":450465,"h":103079665569,"f":4194337},{"t":1310721,"n":"NameId","d":450465,"h":107374632865,"f":4194337},{"t":1310721,"n":"Nickname","d":450465,"h":111669600161,"f":4194337},{"t":1310721,"n":"Nonce","d":450465,"h":115964567457,"f":4194337},{"t":1310721,"n":"Nbf","d":450465,"h":120259534753,"f":4194337},{"t":1310721,"n":"PhoneNumber","d":450465,"h":124554502049,"f":4194337},{"t":1310721,"n":"PhoneNumberVerified","d":450465,"h":128849469345,"f":4194337},{"t":1310721,"n":"Picture","d":450465,"h":133144436641,"f":4194337},{"t":1310721,"n":"Prn","d":450465,"h":137439403937,"f":4194337},{"t":1310721,"n":"PreferredUsername","d":450465,"h":141734371233,"f":4194337},{"t":1310721,"n":"Profile","d":450465,"h":146029338529,"f":4194337},{"t":1310721,"n":"Sid","d":450465,"h":150324305825,"f":4194337},{"t":1310721,"n":"Sub","d":450465,"h":154619273121,"f":4194337},{"t":1310721,"n":"Typ","d":450465,"h":158914240417,"f":4194337},{"t":1310721,"n":"UniqueName","d":450465,"h":163209207713,"f":4194337},{"t":1310721,"n":"UpdatedAt","d":450465,"h":167504175009,"f":4194337},{"t":1310721,"n":"Website","d":450465,"h":171799142305,"f":4194337},{"t":1310721,"n":"ZoneInfo","d":450465,"h":176094109601,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$2","d":450465,"h":180389076897,"f":16777217}],"h":450465}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames`; }
        });
        
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken", ($self) => class JwtSecurityToken extends $.$mit.Microsoft.IdentityModel.Tokens.SecurityToken
        {
            /*JwtPayload*/ _payload = null;
            $ctor$3(/*string*/ jwtEncodedString)
            {
                super.$ctor$1();
                {
                    if ($.$$.System.String.IsNullOrWhiteSpace(jwtEncodedString))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtEncodedString");
                    }
                    /*string[]*/ let tokenParts = $.$$.System.String.Split$3.call(jwtEncodedString, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*.*/ 46], [-1], null), ((5/*JwtConstants.MaxJwtSegmentCount*/ + 1) | 0));
                    if (tokenParts.length === 3/*JwtConstants.JwsSegmentCount*/)
                    {
                        if (!$.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.RegexJws.IsMatch$9(jwtEncodedString))
                        {
                            throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX12739: JWT has three segments but is not in proper JWS format."/*LogMessages.IDX12739*/));
                        }
                    }
                    else if (tokenParts.length === 5/*JwtConstants.JweSegmentCount*/)
                    {
                        if (!$.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.RegexJwe.IsMatch$9(jwtEncodedString))
                        {
                            throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX12740: JWT has five segments but is not in proper JWE format."/*LogMessages.IDX12740*/));
                        }
                    }
                    else 
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX12741: JWT must have three segments (JWS) or five segments (JWE)."/*LogMessages.IDX12741*/));
                    }
                    this.Decode(tokenParts, jwtEncodedString);
                }
                return this;
            }
            $ctor$4(/*JwtHeader*/ header, /*JwtPayload*/ payload, /*string*/ rawHeader, /*string*/ rawPayload, /*string*/ rawSignature)
            {
                super.$ctor$1();
                {
                    if (header === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("header");
                    }
                    if (payload === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload");
                    }
                    if ($.$$.System.String.IsNullOrWhiteSpace(rawHeader))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawHeader");
                    }
                    if ($.$$.System.String.IsNullOrWhiteSpace(rawPayload))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawPayload");
                    }
                    if ($.$$.System.String.op_Equality(rawSignature, null))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawSignature");
                    }
                    this.Header = header;
                    this.Payload = payload;
                    this.RawData = $.$$.System.String.Concat$10($.$$.System.ReadOnlySpan$$($.$$.System.String).op_Implicit$1([ rawHeader, ".", rawPayload, ".", rawSignature ]));
                    this.RawHeader = rawHeader;
                    this.RawPayload = rawPayload;
                    this.RawSignature = rawSignature;
                }
                return this;
            }
            $ctor$6(/*JwtHeader*/ header, /*JwtSecurityToken*/ innerToken, /*string*/ rawHeader, /*string*/ rawEncryptedKey, /*string*/ rawInitializationVector, /*string*/ rawCiphertext, /*string*/ rawAuthenticationTag)
            {
                super.$ctor$1();
                {
                    if (header === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("header");
                    }
                    if (innerToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("innerToken");
                    }
                    if ($.$$.System.String.op_Equality(rawEncryptedKey, null))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawEncryptedKey");
                    }
                    if ($.$$.System.String.IsNullOrEmpty(rawInitializationVector))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawInitializationVector");
                    }
                    if ($.$$.System.String.IsNullOrEmpty(rawCiphertext))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawCiphertext");
                    }
                    if ($.$$.System.String.IsNullOrEmpty(rawAuthenticationTag))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawAuthenticationTag");
                    }
                    this.Header = header;
                    this.InnerToken = innerToken;
                    this.RawData = $.$$.System.String.Join$8(".", $.$$.System.ReadOnlySpan$$($.$$.System.String).op_Implicit$1([ rawHeader, rawEncryptedKey, rawInitializationVector, rawCiphertext, rawAuthenticationTag ]));
                    this.RawHeader = rawHeader;
                    this.RawEncryptedKey = rawEncryptedKey;
                    this.RawInitializationVector = rawInitializationVector;
                    this.RawCiphertext = rawCiphertext;
                    this.RawAuthenticationTag = rawAuthenticationTag;
                }
                return this;
            }
            $ctor$5(/*JwtHeader*/ header, /*JwtPayload*/ payload)
            {
                super.$ctor$1();
                {
                    if (header === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("header");
                    }
                    if (payload === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload");
                    }
                    this.Header = header;
                    this.Payload = payload;
                    this.RawSignature = $.$$.System.String.Empty;
                }
                return this;
            }
            $ctor$2(/*string*/ issuer, /*string*/ audience, /*IEnumerable<Claim>*/ claims, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*SigningCredentials*/ signingCredentials)
            {
                super.$ctor$1();
                {
                    if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(expires) && $.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(notBefore))
                    {
                        if (notBefore >= expires)
                        {
                            throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12401: Expires: '{0}' must be after NotBefore: '{1}'."/*LogMessages.IDX12401*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(expires)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(notBefore)) ], null, null))));
                        }
                    }
                    this.Payload = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload().$ctor$15(issuer, audience, claims, notBefore?.Clone() ?? null, expires?.Clone() ?? null);
                    this.Header = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader().$ctor$21(signingCredentials);
                    this.RawSignature = $.$$.System.String.Empty;
                }
                return this;
            }
            /*string */ get Actor()
            {
                if (this.Payload !== null)
                {
                    return this.Payload.Actort;
                }
                return $.$$.System.String.Empty;
            }
            /*IEnumerable<string> */ get Audiences()
            {
                if (this.Payload !== null)
                {
                    return this.Payload.Aud;
                }
                return new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
            }
            /*IEnumerable<Claim> */ get Claims()
            {
                if (this.Payload !== null)
                {
                    return this.Payload.Claims;
                }
                return new ($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$1();
            }
            /*string */ get EncodedHeader()
            {
                return this.Header.Base64UrlEncode();
            }
            /*string */ get EncodedPayload()
            {
                if (this.Payload !== null)
                {
                    return this.Payload.Base64UrlEncode();
                }
                return $.$$.System.String.Empty;
            }
            /*JwtHeader*/ Header = null;
            /*string */ get Id()
            {
                if (this.Payload !== null)
                {
                    return this.Payload.Jti;
                }
                return $.$$.System.String.Empty;
            }
            /*string */ get Issuer()
            {
                if (this.Payload !== null)
                {
                    return this.Payload.Iss;
                }
                return $.$$.System.String.Empty;
            }
            /*JwtPayload */ get Payload()
            {
                if (this.InnerToken !== null)
                {
                    return this.InnerToken.Payload;
                }
                return this._payload;
            }
            /*JwtPayload */ set Payload(value)
            {
                this._payload = value;
            }
            /*JwtSecurityToken*/ InnerToken = null;
            /*string*/ RawAuthenticationTag = null;
            /*string*/ RawCiphertext = null;
            /*string*/ RawData = null;
            /*string*/ RawEncryptedKey = null;
            /*string*/ RawInitializationVector = null;
            /*string*/ RawHeader = null;
            /*string*/ RawPayload = null;
            /*string*/ RawSignature = null;
            /*SecurityKey */ get SecurityKey()
            {
                return null;
            }
            /*string */ get SignatureAlgorithm()
            {
                return this.Header.Alg;
            }
            /*SigningCredentials */ get SigningCredentials()
            {
                return this.Header.SigningCredentials;
            }
            /*EncryptingCredentials */ get EncryptingCredentials()
            {
                return this.Header.EncryptingCredentials;
            }
            /*SecurityKey*/ SigningKey = null;
            /*string */ get Subject()
            {
                if (this.Payload !== null)
                {
                    return this.Payload.Sub;
                }
                return $.$$.System.String.Empty;
            }
            /*DateTime */ get ValidFrom()
            {
                if (this.Payload !== null)
                {
                    return this.Payload.ValidFrom;
                }
                return $.$$.System.DateTime.MinValue;
            }
            /*DateTime */ get ValidTo()
            {
                if (this.Payload !== null)
                {
                    return this.Payload.ValidTo;
                }
                return $.$$.System.DateTime.MinValue;
            }
            /*DateTime */ get IssuedAt()
            {
                if (this.Payload !== null)
                {
                    return this.Payload.IssuedAt;
                }
                return $.$$.System.DateTime.MinValue;
            }
            static/*conventional*/ /*string */ ToString()
            {
                if (this.Payload !== null)
                {
                    return this.Header.SerializeToJson() + "." + this.Payload.SerializeToJson();
                }
                else 
                {
                    return this.Header.SerializeToJson() + ".";
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken.ToString.apply(this, arguments); }
            /*string */ UnsafeToString()
            {
                return this.RawData;
            }
            /*void */ Decode(/*string[]*/ tokenParts, /*string*/ rawData)
            {
                try
                {
                    this.Header = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader.Base64UrlDeserialize($.$$.System.Array.$ReadT1.call(tokenParts, 0));
                }
                catch(ex)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12729: Unable to decode the header '{0}' as Base64Url encoded string."/*LogMessages.IDX12729*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$$.System.Array.$ReadT1.call(tokenParts, 0) ], null, null)), ex));
                }
                if (tokenParts.length === 5/*JwtConstants.JweSegmentCount*/)
                {
                    this.DecodeJwe(tokenParts);
                }
                else 
                {
                    this.DecodeJws($.$$.System.Array.$ReadT1.call(tokenParts, 1));
                    this.RawHeader = $.$$.System.Array.$ReadT1.call(tokenParts, 0);
                    this.RawPayload = $.$$.System.Array.$ReadT1.call(tokenParts, 1);
                    this.RawSignature = $.$$.System.Array.$ReadT1.call(tokenParts, 2);
                }
                this.RawData = rawData;
            }
            /*void */ DecodeJws(/*string*/ payload)
            {
                if ($.$$.System.String.op_Inequality(this.Header.Cty, null) && $.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12738: Header.Cty != null, assuming JWS. Cty: '{0}'."/*LogMessages.IDX12738*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this.Header.Cty ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                }
                try
                {
                    this.Payload = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoding.Decode$5($.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload, payload, 0, payload.length, new ($.$$.System.Func$$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload))().$ctor($.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.CreatePayload));
                }
                catch(ex)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12723: Unable to decode the payload '{0}' as Base64Url encoded string."/*LogMessages.IDX12723*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ payload ], null, null)), ex));
                }
            }
            /*void */ DecodeJwe(/*string[]*/ tokenParts)
            {
                this.RawHeader = $.$$.System.Array.$ReadT1.call(tokenParts, 0);
                this.RawEncryptedKey = $.$$.System.Array.$ReadT1.call(tokenParts, 1);
                this.RawInitializationVector = $.$$.System.Array.$ReadT1.call(tokenParts, 2);
                this.RawCiphertext = $.$$.System.Array.$ReadT1.call(tokenParts, 3);
                this.RawAuthenticationTag = $.$$.System.Array.$ReadT1.call(tokenParts, 4);
            }
            static $h = 516001;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":13802545,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":34360254369,"f":50331649},"n":"Actor","d":516001,"h":30065287073,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":42950188961,"f":50331649},"n":"Audiences","d":516001,"h":38655221665,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":51540123553,"f":50331649},"n":"Claims","d":516001,"h":47245156257,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":60130058145,"f":50331777},"n":"EncodedHeader","d":516001,"h":55835090849,"f":2097281},{"p":1310721,"g":{"r":0,"d":0,"h":68719992737,"f":50331777},"n":"EncodedPayload","d":516001,"h":64425025441,"f":2097281},{"p":253857,"g":{"r":0,"d":0,"h":81604894625,"f":50331649},"s":{"r":0,"d":0,"h":85899861921,"f":83886088},"n":"Header","d":516001,"h":77309927329,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":94489796513,"f":50364417},"n":"Id","d":516001,"h":90194829217,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":103079731105,"f":50364417},"n":"Issuer","d":516001,"h":98784763809,"f":2129921},{"p":384929,"g":{"r":0,"d":0,"h":111669665697,"f":50331649},"s":{"r":0,"d":0,"h":115964632993,"f":83886088},"n":"Payload","d":516001,"h":107374698401,"f":2097153},{"p":516001,"g":{"r":0,"d":0,"h":128849534881,"f":50331649},"s":{"r":0,"d":0,"h":133144502177,"f":83886088},"n":"InnerToken","d":516001,"h":124554567585,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":146029404065,"f":50331649},"s":{"r":0,"d":0,"h":150324371361,"f":83886082},"n":"RawAuthenticationTag","d":516001,"h":141734436769,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":163209273249,"f":50331649},"s":{"r":0,"d":0,"h":167504240545,"f":83886082},"n":"RawCiphertext","d":516001,"h":158914305953,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":180389142433,"f":50331649},"s":{"r":0,"d":0,"h":184684109729,"f":83886082},"n":"RawData","d":516001,"h":176094175137,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":197569011617,"f":50331649},"s":{"r":0,"d":0,"h":201863978913,"f":83886082},"n":"RawEncryptedKey","d":516001,"h":193274044321,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":214748880801,"f":50331649},"s":{"r":0,"d":0,"h":219043848097,"f":83886082},"n":"RawInitializationVector","d":516001,"h":210453913505,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":231928749985,"f":50331649},"s":{"r":0,"d":0,"h":236223717281,"f":83886088},"n":"RawHeader","d":516001,"h":227633782689,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":249108619169,"f":50331649},"s":{"r":0,"d":0,"h":253403586465,"f":83886088},"n":"RawPayload","d":516001,"h":244813651873,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":266288488353,"f":50331649},"s":{"r":0,"d":0,"h":270583455649,"f":83886088},"n":"RawSignature","d":516001,"h":261993521057,"f":2097153},{"p":13671473,"g":{"r":0,"d":0,"h":279173390241,"f":50364417},"n":"SecurityKey","d":516001,"h":274878422945,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":287763324833,"f":50331649},"n":"SignatureAlgorithm","d":516001,"h":283468357537,"f":2097153},{"p":15965233,"g":{"r":0,"d":0,"h":296353259425,"f":50331649},"n":"SigningCredentials","d":516001,"h":292058292129,"f":2097153},{"p":3972145,"g":{"r":0,"d":0,"h":304943194017,"f":50331649},"n":"EncryptingCredentials","d":516001,"h":300648226721,"f":2097153},{"p":13671473,"g":{"r":0,"d":0,"h":317828095905,"f":50364417},"s":{"r":0,"d":0,"h":322123063201,"f":83918849},"n":"SigningKey","d":516001,"h":313533128609,"f":2129921},{"p":1310721,"g":{"r":0,"d":0,"h":330712997793,"f":50331649},"n":"Subject","d":516001,"h":326418030497,"f":2097153},{"p":34275329,"g":{"r":0,"d":0,"h":339302932385,"f":50364417},"n":"ValidFrom","d":516001,"h":335007965089,"f":2129921},{"p":34275329,"g":{"r":0,"d":0,"h":347892866977,"f":50364417},"n":"ValidTo","d":516001,"h":343597899681,"f":2129921},{"p":34275329,"g":{"r":0,"d":0,"h":356482801569,"f":50331777},"n":"IssuedAt","d":516001,"h":352187834273,"f":2097281}],"m":[{"r":1310721,"n":"ToString","d":516001,"h":360777768865,"f":16809985},{"r":1310721,"n":"UnsafeToString","d":516001,"h":365072736161,"f":16809985},{"r":65537,"p":[{"n":"tokenParts","p":$.$typeArray($.$$.System.String).$h},{"n":"rawData","p":1310721}],"n":"Decode","d":516001,"h":369367703457,"f":16777224},{"r":65537,"p":[{"n":"payload","p":1310721}],"n":"DecodeJws","d":516001,"h":373662670753,"f":16777218},{"r":65537,"p":[{"n":"tokenParts","p":$.$typeArray($.$$.System.String).$h}],"n":"DecodeJwe","d":516001,"h":377957638049,"f":16777218}],"l":[{"t":384929,"n":"_payload","d":516001,"h":4295483297,"f":4194306}],"c":[{"p":[{"n":"jwtEncodedString","p":1310721}],"n":".ctor","o":"$ctor$3","d":516001,"h":8590450593,"f":16777217},{"p":[{"n":"header","p":253857},{"n":"payload","p":384929},{"n":"rawHeader","p":1310721},{"n":"rawPayload","p":1310721},{"n":"rawSignature","p":1310721}],"n":".ctor","o":"$ctor$4","d":516001,"h":12885417889,"f":16777217},{"p":[{"n":"header","p":253857},{"n":"innerToken","p":516001},{"n":"rawHeader","p":1310721},{"n":"rawEncryptedKey","p":1310721},{"n":"rawInitializationVector","p":1310721},{"n":"rawCiphertext","p":1310721},{"n":"rawAuthenticationTag","p":1310721}],"n":".ctor","o":"$ctor$6","d":516001,"h":17180385185,"f":16777217},{"p":[{"n":"header","p":253857},{"n":"payload","p":384929}],"n":".ctor","o":"$ctor$5","d":516001,"h":21475352481,"f":16777217},{"p":[{"n":"issuer","p":1310721,"f":65},{"n":"audience","p":1310721,"f":65},{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"f":65},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h,"f":65},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h,"f":65},{"n":"signingCredentials","p":15965233,"f":65}],"n":".ctor","o":"$ctor$2","d":516001,"h":25770319777,"f":16777217}],"i":[241048],"h":516001}; }
            static get $b() { return $.$mit.Microsoft.IdentityModel.Tokens.SecurityToken; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact ]; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtSecurityToken`; }
        });
        
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler", ($self) => class JwtSecurityTokenHandler extends $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenHandler
        {
            static $_CertMatcher;
            static get CertMatcher()
            {
                let $cls = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler;
                return $cls.$_CertMatcher ??= $asm.$ncls("$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.CertMatcher", ($self) => class CertMatcher extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*bool*/ Invoke(/**/ cert)
                    {
                        return this.$nativeFunction.call(this.$target, cert);
                    }
                    static $h = 712609;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":262145,"p":[{"n":"cert","p":28226319}],"n":"Invoke","d":712609,"h":8590647201,"f":16777345},{"r":57016321,"p":[{"n":"cert","p":28226319},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":712609,"h":12885614497,"f":16777345},{"r":262145,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":712609,"h":17180581793,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":712609,"h":4295679905,"f":16777217}],"i":[57212929,113246209],"d":647073,"h":712609}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.CertMatcher`; }
                }, $cls, ($v) => $cls.$_CertMatcher = $v);
            }
            /*ISet<string>*/ _inboundClaimFilter = null;
            /*IDictionary<string, string>*/ _inboundClaimTypeMap = null;
            /*string*/ static _jsonClaimType = null;
            /*string*/ static _namespace = null;
            /*string*/ static _className = null;
            /*IDictionary<string, string>*/ _outboundClaimTypeMap = null;
            /*Dictionary<string, string>*/ _outboundAlgorithmMap = null;
            /*string*/ static _shortClaimType = null;
            /*bool*/ _mapInboundClaims = false;
            /*Microsoft.IdentityModel.Telemetry.ITelemetryClient*/ TelemetryClient = null;
            /*IDictionary<string, string>*/ static DefaultInboundClaimTypeMap = null;
            /*bool*/ static DefaultMapInboundClaims = true;
            /*IDictionary<string, string>*/ static DefaultOutboundClaimTypeMap = null;
            /*ISet<string>*/ static DefaultInboundClaimFilter = null;
            /*IDictionary<string, string>*/ static DefaultOutboundAlgorithmMap = null;
            /*Static constructor*/ static $cctor()
            {
            }
            $ctor$3()
            {
                super.$ctor$2();
                {
                    if (this._mapInboundClaims)
                    {
                        this._inboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultInboundClaimTypeMap);
                    }
                    else 
                    {
                        this._inboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$1();
                    }
                    this._outboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultOutboundClaimTypeMap);
                    this._inboundClaimFilter = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$3($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultInboundClaimFilter);
                    this._outboundAlgorithmMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultOutboundAlgorithmMap);
                }
                return this;
            }
            /*bool */ get MapInboundClaims()
            {
                return this._mapInboundClaims;
            }
            /*bool */ set MapInboundClaims(value)
            {
                if (!this._mapInboundClaims && value && this._inboundClaimTypeMap.System$Collections$Generic$ICollection$$$Count === 0)
                {
                    this._inboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultInboundClaimTypeMap);
                }
                this._mapInboundClaims = value;
            }
            /*IDictionary<string, string> */ get InboundClaimTypeMap()
            {
                return this._inboundClaimTypeMap;
            }
            /*IDictionary<string, string> */ set InboundClaimTypeMap(value)
            {
                this._inboundClaimTypeMap = $.$firstOf(value, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value") });
            }
            /*IDictionary<string, string> */ get OutboundClaimTypeMap()
            {
                return this._outboundClaimTypeMap;
            }
            /*IDictionary<string, string> */ set OutboundClaimTypeMap(value)
            {
                if (value === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                }
                this._outboundClaimTypeMap = value;
            }
            /*IDictionary<string, string> */ get OutboundAlgorithmMap()
            {
                return this._outboundAlgorithmMap;
            }
            /*ISet<string> */ get InboundClaimFilter()
            {
                return this._inboundClaimFilter;
            }
            /*ISet<string> */ set InboundClaimFilter(value)
            {
                if (value === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                }
                this._inboundClaimFilter = value;
            }
            static /*string */ get ShortClaimTypeProperty()
            {
                return $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler._shortClaimType;
            }
            static /*string */ set ShortClaimTypeProperty(value)
            {
                if ($.$$.System.String.IsNullOrWhiteSpace(value))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                }
                $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler._shortClaimType = value;
            }
            static /*string */ get JsonClaimTypeProperty()
            {
                return $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler._jsonClaimType;
            }
            static /*string */ set JsonClaimTypeProperty(value)
            {
                if ($.$$.System.String.IsNullOrWhiteSpace(value))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                }
                $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler._jsonClaimType = value;
            }
            /*bool */ get CanValidateToken()
            {
                return true;
            }
            /*bool */ get CanWriteToken()
            {
                return true;
            }
            /*Type */ get TokenType()
            {
                return $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken.$type;
            }
            /*bool */ CanReadToken(/*string*/ token)
            {
                if ($.$$.System.String.IsNullOrWhiteSpace(token))
                {
                    return false;
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null));
                    }
                    return false;
                }
                /*int*/ let tokenPartCount = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CountJwtTokenPart(token, ((5/*JwtConstants.MaxJwtSegmentCount*/ + 1) | 0));
                if (tokenPartCount === 3/*JwtConstants.JwsSegmentCount*/)
                {
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.RegexJws.IsMatch$9(token);
                }
                else if (tokenPartCount === 5/*JwtConstants.JweSegmentCount*/)
                {
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.RegexJwe.IsMatch$9(token);
                }
                $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX12720: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)"/*LogMessages.IDX12720*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                return false;
            }
            /*string */ CreateEncodedJwt$3(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                if (tokenDescriptor === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("tokenDescriptor");
                }
                return this.CreateJwtSecurityToken$3(tokenDescriptor).RawData;
            }
            /*string */ CreateEncodedJwt$2(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials)
            {
                return this.CreateJwtSecurityTokenPrivate((() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Issuer = issuer;
                    $i1.Audience = audience;
                    $i1.Subject = subject;
                    $i1.NotBefore = notBefore?.Clone() ?? null;
                    $i1.Expires = expires?.Clone() ?? null;
                    $i1.IssuedAt = issuedAt?.Clone() ?? null;
                    $i1.SigningCredentials = signingCredentials;
                    return $i1;
                })()).RawData;
            }
            /*string */ CreateEncodedJwt$1(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials)
            {
                return this.CreateJwtSecurityTokenPrivate((() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Issuer = issuer;
                    $i1.Audience = audience;
                    $i1.Subject = subject;
                    $i1.NotBefore = notBefore?.Clone() ?? null;
                    $i1.Expires = expires?.Clone() ?? null;
                    $i1.IssuedAt = issuedAt?.Clone() ?? null;
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    return $i1;
                })()).RawData;
            }
            /*string */ CreateEncodedJwt(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ claimCollection)
            {
                return this.CreateJwtSecurityTokenPrivate((() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Issuer = issuer;
                    $i1.Audience = audience;
                    $i1.Subject = subject;
                    $i1.NotBefore = notBefore?.Clone() ?? null;
                    $i1.Expires = expires?.Clone() ?? null;
                    $i1.IssuedAt = issuedAt?.Clone() ?? null;
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.Claims = claimCollection;
                    return $i1;
                })()).RawData;
            }
            /*JwtSecurityToken */ CreateJwtSecurityToken$3(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                if (tokenDescriptor === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("tokenDescriptor");
                }
                return this.CreateJwtSecurityTokenPrivate(tokenDescriptor);
            }
            /*JwtSecurityToken */ CreateJwtSecurityToken$1(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials)
            {
                return this.CreateJwtSecurityTokenPrivate((() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Issuer = issuer;
                    $i1.Audience = audience;
                    $i1.Subject = subject;
                    $i1.NotBefore = notBefore?.Clone() ?? null;
                    $i1.Expires = expires?.Clone() ?? null;
                    $i1.IssuedAt = issuedAt?.Clone() ?? null;
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    return $i1;
                })());
            }
            /*JwtSecurityToken */ CreateJwtSecurityToken(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ claimCollection)
            {
                return this.CreateJwtSecurityTokenPrivate((() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Issuer = issuer;
                    $i1.Audience = audience;
                    $i1.Subject = subject;
                    $i1.NotBefore = notBefore?.Clone() ?? null;
                    $i1.Expires = expires?.Clone() ?? null;
                    $i1.IssuedAt = issuedAt?.Clone() ?? null;
                    $i1.SigningCredentials = signingCredentials;
                    $i1.EncryptingCredentials = encryptingCredentials;
                    $i1.Claims = claimCollection;
                    return $i1;
                })());
            }
            /*JwtSecurityToken */ CreateJwtSecurityToken$2(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials)
            {
                return this.CreateJwtSecurityTokenPrivate((() =>
                {
                    //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                    const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Issuer = issuer;
                    $i1.Audience = audience;
                    $i1.Subject = subject;
                    $i1.NotBefore = notBefore?.Clone() ?? null;
                    $i1.Expires = expires?.Clone() ?? null;
                    $i1.IssuedAt = issuedAt?.Clone() ?? null;
                    $i1.SigningCredentials = signingCredentials;
                    return $i1;
                })());
            }
            /*SecurityToken */ CreateToken(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                if (tokenDescriptor === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("tokenDescriptor");
                }
                return this.CreateJwtSecurityTokenPrivate(tokenDescriptor);
            }
            /*JwtSecurityToken */ CreateJwtSecurityTokenPrivate(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                /*DateTime?*/ let expires = tokenDescriptor.Expires;
                /*DateTime?*/ let issuedAt = tokenDescriptor.IssuedAt;
                /*DateTime?*/ let notBefore = tokenDescriptor.NotBefore;
                if (this.SetDefaultTimesOnTokenCreation && (!$.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(expires) || !$.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(issuedAt) || !$.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(notBefore)))
                {
                    /*DateTime*/ let now = $.$$.System.DateTime.UtcNow;
                    if (!$.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(expires))
                    {
                        expires = $.$$.System.DateTime.op_Addition(now, $.$$.System.TimeSpan.FromMinutes$2(BigInt(this.TokenLifetimeInMinutes)));
                    }
                    if (!$.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(issuedAt))
                    {
                        issuedAt = now;
                    }
                    if (!$.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(notBefore))
                    {
                        notBefore = now;
                    }
                }
                /*string*/ let issuer = tokenDescriptor.Issuer;
                /*ClaimsIdentity*/ let subject = tokenDescriptor.Subject;
                /*IDictionary<string, object>*/ let claimCollection = tokenDescriptor.Claims;
                /*JwtPayload*/ let payload = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload().$ctor$16(issuer, tokenDescriptor.Audience, tokenDescriptor.Audiences, (subject === null ? null : this.OutboundClaimTypeTransform$1(subject.Claims)), (claimCollection === null ? null : this.OutboundClaimTypeTransform(claimCollection)), notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
                /*SigningCredentials*/ let signingCredentials = tokenDescriptor.SigningCredentials;
                /*string*/ let tokenType = tokenDescriptor.TokenType;
                /*JwtHeader*/ let header = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader().$ctor$17(signingCredentials, this.OutboundAlgorithmMap, tokenType, tokenDescriptor.AdditionalInnerHeaderClaims, tokenDescriptor.IncludeKeyIdInHeader);
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX12721: Creating JwtSecurityToken: Issuer: '{0}', Audience: '{1}'"/*LogMessages.IDX12721*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(issuer ?? "null"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.ToString.call(payload.Aud) ?? "null") ], null, null));
                }
                if ((subject?.Actor ?? null) !== null)
                {
                    payload.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$8("actort"/*JwtRegisteredClaimNames.Actort*/, this.CreateActorValue(subject.Actor)));
                }
                /*string*/ let rawHeader = header.Base64UrlEncode();
                /*string*/ let rawPayload = payload.Base64UrlEncode();
                /*string*/ let rawSignature = $.$$.System.String.Empty;
                if (signingCredentials !== null)
                {
                    /*string*/ let message = $.$$.System.String.Concat$12(rawHeader, ".", rawPayload);
                    rawSignature = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateEncodedSignature$2(message, signingCredentials);
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX12722: Creating security token from the header: '{0}', payload: '{1}'."/*LogMessages.IDX12722*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ rawHeader, rawPayload ], null, null));
                }
                /*EncryptingCredentials*/ let encryptingCredentials = tokenDescriptor.EncryptingCredentials;
                if (encryptingCredentials !== null)
                {
                    return this.EncryptToken(new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$4(header, payload, rawHeader, rawPayload, rawSignature), encryptingCredentials, tokenType, tokenDescriptor.AdditionalHeaderClaims);
                }
                return new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$4(header, payload, rawHeader, rawPayload, rawSignature);
            }
            /*JwtSecurityToken */ EncryptToken(/*JwtSecurityToken*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                if (encryptingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                /*var*/ let cryptoProviderFactory = encryptingCredentials.CryptoProviderFactory ?? encryptingCredentials.Key.CryptoProviderFactory;
                if (cryptoProviderFactory === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("IDX10620: Unable to obtain a CryptoProviderFactory, both EncryptingCredentials.CryptoProviderFactory and EncryptingCredentials.Key.CryptoProviderFactory are null."/*TokenLogMessages.IDX10620*/));
                }
                /*byte[]*/ let wrappedKey;
                /*SecurityKey*/ let securityKey = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetSecurityKey(encryptingCredentials, cryptoProviderFactory, additionalHeaderClaims, $.$ref(() => wrappedKey, ($v) => wrappedKey = $v, $.$typeArray($.$$.System.Byte)));
                let encryptionProvider = null;
                try
                {
                    encryptionProvider = cryptoProviderFactory.CreateAuthenticatedEncryptionProvider(securityKey, encryptingCredentials.Enc);
                    if (encryptionProvider === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14("IDX12730: Failed to create the token encryption provider."/*LogMessages.IDX12730*/));
                    }
                    try
                    {
                        /*var*/ let header = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader().$ctor$13(encryptingCredentials, this.OutboundAlgorithmMap, tokenType, additionalHeaderClaims);
                        /*var*/ let encodedHeader = header.Base64UrlEncode();
                        /*AuthenticatedEncryptionResult*/ let encryptionResult = encryptionProvider.Encrypt$1($.$$.System.Text.Encoding.UTF8.GetBytes$8(innerJwt.RawData), $.$$.System.Text.Encoding.ASCII.GetBytes$8(encodedHeader));
                        return $.$$.System.String.Equals$5.call("dir"/*JwtConstants.DirectKeyUseAlg*/, encryptingCredentials.Alg) ? new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$6(header, innerJwt, encodedHeader, $.$$.System.String.Empty, $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.IV), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.Ciphertext), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.AuthenticationTag)) : new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$6(header, innerJwt, encodedHeader, $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(wrappedKey), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.IV), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.Ciphertext), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.AuthenticationTag));
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$13($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10616: Encryption failed. EncryptionProvider failed for: Algorithm: '{0}', SecurityKey: '{1}'. See inner exception."/*TokenLogMessages.IDX10616*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Enc), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Key.KeyId) ], null, null)), ex));
                    }
                }
                finally
                {
                    encryptionProvider?.System$IDisposable$Dispose();
                }
            }
            /*IEnumerable<Claim> */ OutboundClaimTypeTransform$1(/*IEnumerable<Claim>*/ claims)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var claim = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*string*/ let type = null;
                            if (this._outboundClaimTypeMap.System$Collections$Generic$IDictionary$$$$TryGetValue(claim.Type, $.$ref(() => type, ($v) => type = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]))
                            {
                                yield new $.$ssc.System.Security.Claims.Claim().$ctor$4(type, claim.Value, claim.ValueType, claim.Issuer, claim.OriginalIssuer, claim.Subject);
                            }
                            else 
                            {
                                yield claim;
                            }
                        }
                    }
                }.bind(this));
            }
            /*Dictionary<string, object> */ OutboundClaimTypeTransform(/*IDictionary<string, object>*/ claimCollection)
            {
                /*var*/ let claims = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                var $en2 = claimCollection.System$Collections$Generic$IDictionary$$$$Keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claimType = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*string*/ let type;
                        if (this._outboundClaimTypeMap.System$Collections$Generic$IDictionary$$$$TryGetValue(claimType, $.$ref(() => type, ($v) => type = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]))
                        {
                            claims.set_Item(type, claimCollection.System$Collections$Generic$IDictionary$$$$get_Item(claimType, [$.$$.System.String, $.$$.System.Object]));
                        }
                        else 
                        {
                            claims.set_Item(claimType, claimCollection.System$Collections$Generic$IDictionary$$$$get_Item(claimType, [$.$$.System.String, $.$$.System.Object]));
                        }
                    }
                }
                return claims;
            }
            /*JwtSecurityToken */ ReadJwtToken(/*string*/ token)
            {
                if ($.$$.System.String.IsNullOrEmpty(token))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null))));
                }
                if (!this.CanReadToken(token))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX12709: CanReadToken() returned false. JWT is not well formed.\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX12709*/));
                }
                /*var*/ let jwtToken = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$2(null, null, null, null, null, null);
                jwtToken.Decode($.$$.System.String.Split$1.call(token, /*.*/ 46, 0), token);
                return jwtToken;
            }
            /*SecurityToken */ ReadToken(/*string*/ token)
            {
                return this.ReadJwtToken(token);
            }
            /*SecurityToken */ ReadToken$1(/*XmlReader*/ reader, /*TokenValidationParameters*/ validationParameters)
            {
                throw new $.$$.System.NotImplementedException().$ctor$9();
            }
            /*ClaimsPrincipal */ ValidateToken(/*string*/ token, /*TokenValidationParameters*/ validationParameters, /*out SecurityToken*/ validatedToken)
            {
                if ($.$$.System.String.IsNullOrWhiteSpace(token))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null))));
                }
                /*int*/ let tokenPartCount = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CountJwtTokenPart(token, ((5/*JwtConstants.MaxJwtSegmentCount*/ + 1) | 0));
                if (tokenPartCount !== 3/*JwtConstants.JwsSegmentCount*/ && tokenPartCount !== 5/*JwtConstants.JweSegmentCount*/)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX12741: JWT must have three segments (JWS) or five segments (JWE)."/*LogMessages.IDX12741*/));
                }
                if (tokenPartCount === 5/*JwtConstants.JweSegmentCount*/)
                {
                    /*var*/ let jwtToken = this.ReadJwtToken(token);
                    /*var*/ let decryptedJwt = this.DecryptToken(jwtToken, validationParameters);
                    return this.ValidateToken$2(decryptedJwt, jwtToken, validationParameters, validatedToken);
                }
                else 
                {
                    return this.ValidateToken$2(token, null, validationParameters, validatedToken);
                }
            }
            /*ClaimsPrincipal */ ValidateToken$2(/*string*/ token, /*JwtSecurityToken*/ outerToken, /*TokenValidationParameters*/ validationParameters, /*out SecurityToken*/ signatureValidatedToken)
            {
                /*BaseConfiguration*/ let currentConfiguration = null;
                if (validationParameters.ConfigurationManager !== null)
                {
                    try
                    {
                        currentConfiguration = validationParameters.ConfigurationManager.GetBaseConfigurationAsync($.$$.System.Threading.CancellationToken.None).ConfigureAwait$2(false).GetAwaiter().GetResult();
                    }
                    catch(ex)
                    {
                        if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                        {
                            $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogWarning($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10261: Unable to retrieve configuration from authority: '{0}'. \nProceeding with token validation in case the relevant properties have been set manually on the TokenValidationParameters. Exception caught: \n {1}. See https://aka.ms/validate-using-configuration-manager for additional information."/*TokenLogMessages.IDX10261*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(validationParameters.ConfigurationManager.MetadataAddress), $.$$.System.Exception.ToString.call(ex) ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                        }
                    }
                }
                /*ExceptionDispatchInfo*/ let exceptionThrown;
                /*ClaimsPrincipal*/ let claimsPrincipal = outerToken !== null ? this.ValidateJWE(token, outerToken, validationParameters, currentConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo)) : this.ValidateJWS(token, validationParameters, currentConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo));
                if (validationParameters.ConfigurationManager !== null)
                {
                    if (claimsPrincipal !== null)
                    {
                        if (currentConfiguration !== null)
                        {
                            validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                        }
                        return claimsPrincipal;
                    }
                    else if ($.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.IsRecoverableException(exceptionThrown.SourceException, (currentConfiguration !== null && currentConfiguration.TokenDecryptionKeys.System$Collections$Generic$ICollection$$$Count > 0)))
                    {
                        if (currentConfiguration !== null)
                        {
                            this.TelemetryClient.Microsoft$IdentityModel$Telemetry$ITelemetryClient$IncrementConfigurationRefreshRequestCounter$2(validationParameters.ConfigurationManager.MetadataAddress, "LastKnownGood"/*TelemetryConstants.Protocols.Lkg*/, "Unknown"/*TelemetryConstants.Protocols.ConfigurationSourceUnknown*/);
                            validationParameters.ConfigurationManager.RequestRefresh();
                            validationParameters.RefreshBeforeValidation = true;
                            /*var*/ let lastConfig = currentConfiguration;
                            currentConfiguration = validationParameters.ConfigurationManager.GetBaseConfigurationAsync($.$$.System.Threading.CancellationToken.None).ConfigureAwait$2(false).GetAwaiter().GetResult();
                            if (lastConfig !== currentConfiguration)
                            {
                                claimsPrincipal = outerToken !== null ? this.ValidateJWE(token, outerToken, validationParameters, currentConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo)) : this.ValidateJWS(token, validationParameters, currentConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo));
                                if (claimsPrincipal !== null)
                                {
                                    validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                                    return claimsPrincipal;
                                }
                            }
                        }
                        if (validationParameters.ConfigurationManager.UseLastKnownGoodConfiguration)
                        {
                            validationParameters.RefreshBeforeValidation = false;
                            validationParameters.ValidateWithLKG = true;
                            /*var*/ let recoverableException = exceptionThrown.SourceException;
                            /*string*/ let kid = outerToken !== null ? outerToken.Header.Kid : ($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.ValidateSignatureUsingDelegates(token, validationParameters, null) ?? this.GetJwtSecurityTokenFromToken(token, validationParameters)).Header.Kid;
                            let $i5 = 0;
                            let $arr5 = validationParameters.ConfigurationManager.GetValidLkgConfigurations();
                            while ($i5 < $arr5.length)
                            {
                                let lkgConfiguration = $arr5[$i5++];
                                if (!$.$$.System.Object.Equals$1.call(lkgConfiguration, currentConfiguration) && $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.IsRecoverableConfiguration(kid, currentConfiguration, lkgConfiguration, recoverableException))
                                {
                                    claimsPrincipal = outerToken !== null ? this.ValidateJWE(token, outerToken, validationParameters, lkgConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo)) : this.ValidateJWS(token, validationParameters, lkgConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo));
                                    if (claimsPrincipal !== null)
                                    {
                                        return claimsPrincipal;
                                    }
                                }
                            }
                        }
                    }
                }
                if (claimsPrincipal !== null)
                {
                    return claimsPrincipal;
                }
                exceptionThrown.Throw();
                return null;
            }
            /*ClaimsPrincipal */ ValidateJWE(/*string*/ decryptedJwt, /*JwtSecurityToken*/ outerToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ currentConfiguration, /*out SecurityToken*/ signatureValidatedToken, /*out ExceptionDispatchInfo*/ exceptionThrown)
            {
                exceptionThrown.$v = null;
                try
                {
                    /*SecurityToken*/ let innerToken;
                    /*ClaimsPrincipal*/ let claimsPrincipal = this.ValidateJWS(decryptedJwt, validationParameters, currentConfiguration, $.$ref(() => innerToken, ($v) => innerToken = $v, $.$mit.Microsoft.IdentityModel.Tokens.SecurityToken), exceptionThrown);
                    outerToken.InnerToken = $.$as(innerToken, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken);
                    signatureValidatedToken.$v = exceptionThrown.$v === null ? outerToken : null;
                    return claimsPrincipal;
                }
                catch(ex)
                {
                    exceptionThrown.$v = $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(ex);
                    signatureValidatedToken.$v = null;
                    return null;
                }
            }
            /*ClaimsPrincipal */ ValidateJWS(/*string*/ token, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ currentConfiguration, /*out SecurityToken*/ signatureValidatedToken, /*out ExceptionDispatchInfo*/ exceptionThrown)
            {
                exceptionThrown.$v = null;
                try
                {
                    /*ClaimsPrincipal*/ let claimsPrincipal;
                    if (validationParameters.SignatureValidator !== null || validationParameters.SignatureValidatorUsingConfiguration !== null)
                    {
                        signatureValidatedToken.$v = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.ValidateSignatureUsingDelegates(token, validationParameters, currentConfiguration);
                        claimsPrincipal = this.ValidateTokenPayload($.$as(signatureValidatedToken.$v, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken), validationParameters, currentConfiguration);
                        if (currentConfiguration === null)
                        {
                            this.ValidateIssuerSecurityKey(signatureValidatedToken.$v.SigningKey, $.$as(signatureValidatedToken.$v, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken), validationParameters);
                        }
                        else 
                        {
                            $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerSecurityKey(signatureValidatedToken.$v.SigningKey, signatureValidatedToken.$v, validationParameters, currentConfiguration);
                        }
                    }
                    else 
                    {
                        /*JwtSecurityToken*/ let jwtToken = this.GetJwtSecurityTokenFromToken(token, validationParameters);
                        if (validationParameters.ValidateSignatureLast)
                        {
                            claimsPrincipal = this.ValidateTokenPayload(jwtToken, validationParameters, currentConfiguration);
                            jwtToken = this.ValidateSignatureAndIssuerSecurityKey(token, jwtToken, validationParameters, currentConfiguration);
                            signatureValidatedToken.$v = jwtToken;
                        }
                        else 
                        {
                            signatureValidatedToken.$v = this.ValidateSignatureAndIssuerSecurityKey(token, jwtToken, validationParameters, currentConfiguration);
                            claimsPrincipal = this.ValidateTokenPayload($.$as(signatureValidatedToken.$v, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken), validationParameters, currentConfiguration);
                        }
                    }
                    return claimsPrincipal;
                }
                catch(ex)
                {
                    exceptionThrown.$v = $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(ex);
                    signatureValidatedToken.$v = null;
                    return null;
                }
            }
            static /*JwtSecurityToken */ ValidateSignatureUsingDelegates(/*string*/ token, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters") });
                if (validationParameters.SignatureValidatorUsingConfiguration !== null)
                {
                    /*var*/ let validatedJwtToken = validationParameters.SignatureValidatorUsingConfiguration.Invoke(token, validationParameters, configuration);
                    if (validatedJwtToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    let validatedJwt;
                    if (!($.$is(validatedJwtToken, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken, { set $v(v){ validatedJwt = v; } })))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10506: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters did not return a '{0}', but returned a '{1}' when validating token: '{2}'.\nIf you are using ASP.NET Core 8 or later, see https://learn.microsoft.com/en-us/dotnet/core/compatibility/aspnet-core/8.0/securitytoken-events for more details."/*TokenLogMessages.IDX10506*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(validatedJwtToken)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    return validatedJwt;
                }
                else if (validationParameters.SignatureValidator !== null)
                {
                    /*var*/ let validatedJwtToken = validationParameters.SignatureValidator.Invoke(token, validationParameters);
                    if (validatedJwtToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    let validatedJwt;
                    if (!($.$is(validatedJwtToken, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken, { set $v(v){ validatedJwt = v; } })))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10506: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters did not return a '{0}', but returned a '{1}' when validating token: '{2}'.\nIf you are using ASP.NET Core 8 or later, see https://learn.microsoft.com/en-us/dotnet/core/compatibility/aspnet-core/8.0/securitytoken-events for more details."/*TokenLogMessages.IDX10506*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(validatedJwtToken)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    return validatedJwt;
                }
                return null;
            }
            /*JwtSecurityToken */ ValidateSignatureAndIssuerSecurityKey(/*string*/ token, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                /*JwtSecurityToken*/ let validatedToken = this.ValidateSignature$2(token, jwtToken, validationParameters, configuration);
                if (configuration === null)
                {
                    this.ValidateIssuerSecurityKey(jwtToken.SigningKey, jwtToken, validationParameters);
                }
                else 
                {
                    $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerSecurityKey(jwtToken.SigningKey, jwtToken, validationParameters, configuration);
                }
                return validatedToken;
            }
            /*JwtSecurityToken */ GetJwtSecurityTokenFromToken(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                if (validationParameters.TokenReader !== null)
                {
                    /*var*/ let securityToken = validationParameters.TokenReader.Invoke(token, validationParameters);
                    if (securityToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10510: Token validation failed. The user defined 'Delegate' set on TokenValidationParameters.TokenReader returned null when reading token: '{0}'."/*TokenLogMessages.IDX10510*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    let jwtToken;
                    if (!($.$is(securityToken, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken, { set $v(v){ jwtToken = v; } })))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10509: Token validation failed. The user defined 'Delegate' set on TokenValidationParameters.TokenReader did not return a '{0}', but returned a '{1}' when reading token: '{2}'."/*TokenLogMessages.IDX10509*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(securityToken)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    return jwtToken;
                }
                else 
                {
                    return this.ReadJwtToken(token);
                }
            }
            /*ClaimsPrincipal */ ValidateTokenPayload$1(/*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                return this.ValidateTokenPayload(jwtToken, validationParameters, null);
            }
            /*ClaimsPrincipal */ ValidateTokenPayload(/*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                /*DateTime?*/ let expires = (jwtToken.Payload.Expiration === null) ? null : new ($.$$.System.Nullable$$($.$$.System.DateTime))().$ctor$3(jwtToken.ValidTo);
                /*DateTime?*/ let notBefore = (jwtToken.Payload.NotBefore === null) ? null : new ($.$$.System.Nullable$$($.$$.System.DateTime))().$ctor$3(jwtToken.ValidFrom);
                this.ValidateLifetime(notBefore?.Clone() ?? null, expires?.Clone() ?? null, jwtToken, validationParameters);
                this.ValidateAudience(jwtToken.Audiences, jwtToken, validationParameters);
                /*string*/ let issuer = configuration === null ? this.ValidateIssuer(jwtToken.Issuer, jwtToken, validationParameters) : $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuer(jwtToken.Issuer, jwtToken, validationParameters, configuration);
                this.ValidateTokenReplay(expires?.Clone() ?? null, jwtToken.RawData, validationParameters);
                if (validationParameters.ValidateActor && !$.$$.System.String.IsNullOrWhiteSpace(jwtToken.Actor))
                {
                    this.ValidateToken(jwtToken.Actor, validationParameters.ActorValidationParameters ?? validationParameters, $.$discardRef());
                }
                $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateTokenType$1(jwtToken.Header.Typ, jwtToken, validationParameters);
                /*var*/ let identity = this.CreateClaimsIdentity(jwtToken, issuer, validationParameters);
                if (validationParameters.SaveSigninToken)
                {
                    identity.BootstrapContext = jwtToken.RawData;
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10241: Security token validated. token: '{0}'."/*TokenLogMessages.IDX10241*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jwtToken ], null, null));
                }
                return new $.$ssc.System.Security.Claims.ClaimsPrincipal().$ctor$5(identity);
            }
            /*ClaimsPrincipal */ CreateClaimsPrincipalFromToken(/*JwtSecurityToken*/ jwtToken, /*string*/ issuer, /*TokenValidationParameters*/ validationParameters)
            {
                /*var*/ let identity = this.CreateClaimsIdentity(jwtToken, issuer, validationParameters);
                if (validationParameters.SaveSigninToken)
                {
                    identity.BootstrapContext = jwtToken.RawData;
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10241: Security token validated. token: '{0}'."/*TokenLogMessages.IDX10241*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jwtToken ], null, null));
                }
                return new $.$ssc.System.Security.Claims.ClaimsPrincipal().$ctor$5(identity);
            }
            /*string */ WriteToken(/*SecurityToken*/ token)
            {
                if (token === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                }
                /*JwtSecurityToken*/ let jwtToken = $.$as(token, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken);
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$13($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12706: '{0}' can only write SecurityTokens of type: '{1}', 'token' type is: '{2}'."/*LogMessages.IDX12706*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler"/*_className*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(token)) ], null, null)), "token"));
                }
                /*var*/ let encodedPayload = jwtToken.EncodedPayload;
                /*var*/ let encodedSignature = $.$$.System.String.Empty;
                /*var*/ let encodedHeader = $.$$.System.String.Empty;
                if (jwtToken.InnerToken !== null)
                {
                    if (jwtToken.SigningCredentials !== null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14("IDX12736: JwtSecurityToken.SigningCredentials is not supported when JwtSecurityToken.InnerToken is set."/*LogMessages.IDX12736*/));
                    }
                    if (jwtToken.InnerToken.Header.EncryptingCredentials !== null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14("IDX12737: EncryptingCredentials set on JwtSecurityToken.InnerToken is not supported."/*LogMessages.IDX12737*/));
                    }
                    if (jwtToken.Header.EncryptingCredentials === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14("IDX12735: If JwtSecurityToken.InnerToken != null, then JwtSecurityToken.Header.EncryptingCredentials must be set."/*LogMessages.IDX12735*/));
                    }
                    if (jwtToken.InnerToken.SigningCredentials !== null)
                    {
                        encodedSignature = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateEncodedSignature$2($.$$.System.String.Concat$12(jwtToken.InnerToken.EncodedHeader, ".", jwtToken.EncodedPayload), jwtToken.InnerToken.SigningCredentials);
                    }
                    return this.EncryptToken(new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$4(jwtToken.InnerToken.Header, jwtToken.InnerToken.Payload, jwtToken.InnerToken.EncodedHeader, encodedPayload, encodedSignature), jwtToken.EncryptingCredentials, jwtToken.InnerToken.Header.Typ, null).RawData;
                }
                /*var*/ let header = jwtToken.EncryptingCredentials === null ? jwtToken.Header : new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader().$ctor$21(jwtToken.SigningCredentials);
                encodedHeader = header.Base64UrlEncode();
                if (jwtToken.SigningCredentials !== null)
                {
                    encodedSignature = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateEncodedSignature$2($.$$.System.String.Concat$12(encodedHeader, ".", encodedPayload), jwtToken.SigningCredentials);
                }
                if (jwtToken.EncryptingCredentials !== null)
                {
                    return this.EncryptToken(new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$4(header, jwtToken.Payload, encodedHeader, encodedPayload, encodedSignature), jwtToken.EncryptingCredentials, jwtToken.Header.Typ, null).RawData;
                }
                else 
                {
                    return $.$$.System.String.Concat$10($.$$.System.ReadOnlySpan$$($.$$.System.String).op_Implicit$1([ encodedHeader, ".", encodedPayload, ".", encodedSignature ]));
                }
            }
            static /*void */ RecordSignatureValidationTelemetry(/*Microsoft.IdentityModel.Telemetry.ITelemetryClient*/ telemetryClient, /*string*/ errorType, /*SecurityToken*/ securityToken, /*string*/ algorithm, /*SecurityKey*/ key)
            {
                if ($.$mit.Microsoft.IdentityModel.Telemetry.CryptoTelemetry.RecordSignatureValidationTelemetry)
                {
                    telemetryClient.Microsoft$IdentityModel$Telemetry$ITelemetryClient$IncrementSignatureValidationCounter(errorType, securityToken.Issuer, algorithm, key);
                }
            }
            static /*bool */ ValidateSignature(/*byte[]*/ encodedBytes, /*byte[]*/ signature, /*SecurityKey*/ key, /*string*/ algorithm, /*SecurityToken*/ securityToken, /*TokenValidationParameters*/ validationParameters, /*Microsoft.IdentityModel.Telemetry.ITelemetryClient*/ telemetryClient)
            {
                /*CryptoProviderFactory*/ let cryptoProviderFactory = null;
                /*SignatureProvider*/ let signatureProvider = null;
                try
                {
                    $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAlgorithm(algorithm, key, securityToken, validationParameters);
                }
                catch($e)
                {
                    $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "AlgorithmNotSupported"/*TelemetryConstants.SignatureValidationErrors.AlgorithmNotSupported*/, securityToken, algorithm, key);
                    throw $e;
                }
                try
                {
                    cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                    signatureProvider = cryptoProviderFactory.CreateForVerifying$1(key, algorithm);
                    if (signatureProvider === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10636: CryptoProviderFactory.CreateForVerifying returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10636*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key === null ? "Null" : key.KeyId), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(algorithm) ], null, null))));
                    }
                }
                catch($e)
                {
                    $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "SignatureProviderCreationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureProviderCreationFailed*/, securityToken, algorithm, key);
                    throw $e;
                }
                try
                {
                    /*bool*/ let isValid = signatureProvider.Verify(encodedBytes, signature);
                    $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, isValid ? "None"/*TelemetryConstants.SignatureValidationErrors.None*/ : "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, securityToken, algorithm, key);
                    return isValid;
                }
                catch($e)
                {
                    $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, securityToken, algorithm, key);
                    throw $e;
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            /*JwtSecurityToken */ ValidateSignature$1(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                /*JwtSecurityToken*/ let validatedJwt = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.ValidateSignatureUsingDelegates(token, validationParameters, null);
                /*JwtSecurityToken*/ let parsedJwtToken = this.GetJwtSecurityTokenFromToken(token, validationParameters);
                return this.ValidateSignature$2(token, validatedJwt ?? parsedJwtToken, validationParameters, null);
            }
            /*JwtSecurityToken */ ValidateSignature$2(/*string*/ token, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                /*byte[]*/ let encodedBytes = $.$$.System.Text.Encoding.UTF8.GetBytes$8(jwtToken.RawHeader + "." + jwtToken.RawPayload);
                /*bool*/ let kidMatched = false;
                /*IEnumerable<SecurityKey>*/ let keys = null;
                if ($.$$.System.String.IsNullOrEmpty(jwtToken.RawSignature))
                {
                    if (validationParameters.RequireSignedTokens)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10504: Unable to validate signature, token does not have a signature: '{0}'."/*TokenLogMessages.IDX10504*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jwtToken ], null, null))));
                    }
                    else 
                    {
                        return jwtToken;
                    }
                }
                if (validationParameters.IssuerSigningKeyResolverUsingConfiguration !== null)
                {
                    keys = validationParameters.IssuerSigningKeyResolverUsingConfiguration.Invoke(token, jwtToken, jwtToken.Header.Kid, validationParameters, configuration);
                }
                if (validationParameters.IssuerSigningKeyResolver !== null)
                {
                    keys = validationParameters.IssuerSigningKeyResolver.Invoke(token, jwtToken, jwtToken.Header.Kid, validationParameters);
                }
                else 
                {
                    /*var*/ let key = configuration === null ? this.ResolveIssuerSigningKey(token, jwtToken, validationParameters) : $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey$1(jwtToken.Header.Kid, jwtToken.Header.X5t, validationParameters, configuration);
                    if (key !== null)
                    {
                        kidMatched = true;
                        keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (keys === null && validationParameters.TryAllIssuerSigningKeys)
                {
                    keys = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys$1(configuration, validationParameters);
                }
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                /*bool*/ let kidExists = !$.$$.System.String.IsNullOrEmpty(jwtToken.Header.Kid);
                /*byte[]*/ let signatureBytes;
                try
                {
                    signatureBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.RawSignature);
                }
                catch(e)
                {
                    throw new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$19("IDX10508: Signature validation failed. Signature is improperly formatted."/*TokenLogMessages.IDX10508*/, e);
                }
                if (keys !== null)
                {
                    var $en3 = keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var key = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            try
                            {
                                if ($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.ValidateSignature(encodedBytes, signatureBytes, key, jwtToken.Header.Alg, jwtToken, validationParameters, this.TelemetryClient))
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10242: Security token: '{0}' has a valid signature."/*TokenLogMessages.IDX10242*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jwtToken ], null, null));
                                    }
                                    jwtToken.SigningKey = key;
                                    return jwtToken;
                                }
                            }
                            catch(ex)
                            {
                                (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2($.$$.System.Exception.ToString.call(ex));
                            }
                            if (key !== null)
                            {
                                (keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1()).Append$19($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.ToString.call(key));
                                if (kidExists && !kidMatched && $.$$.System.String.op_Inequality(key.KeyId, null))
                                {
                                    kidMatched = $.$$.System.String.Equals$4.call(jwtToken.Header.Kid, key.KeyId, $.$is(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/);
                                }
                            }
                        }
                    }
                }
                /*var*/ let keysInTokenValidationParameters = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys$1(null, validationParameters);
                /*var*/ let keysInConfiguration = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys$1(configuration, null);
                /*var*/ let numKeysInTokenValidationParameters = $.$sl.System.Linq.Enumerable.Count$1($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keysInTokenValidationParameters);
                /*var*/ let numKeysInConfiguration = $.$sl.System.Linq.Enumerable.Count$1($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keysInConfiguration);
                if (kidExists)
                {
                    if (kidMatched)
                    {
                        /*JwtSecurityToken*/ let localJwtToken = jwtToken;
                        /*var*/ let isKidInTVP = $.$sl.System.Linq.Enumerable.Any($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keysInTokenValidationParameters, new ($.$$.System.Func$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$$.System.Boolean))().$ctor(this,  (/*x*/ x) =>
                        {
                            return $.$$.System.String.Equals$5.call(x.KeyId, localJwtToken.Header.Kid);
                        }, {"r":262145,"p":[{"n":"x","p":13671473}],"n":"","d":647073,"h":0,"f":17825794}));
                        /*var*/ let keyLocation = isKidInTVP ? "TokenValidationParameters" : "Configuration";
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10511: Signature validation failed. Keys tried: '{0}'. \nNumber of keys in TokenValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'. \nMatched key was in '{3}'. \nkid: '{4}'. \nExceptions caught:\n '{5}'.\ntoken: '{6}'. See https://aka.ms/IDX10511 for details."/*TokenLogMessages.IDX10511*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keyLocation), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Header.Kid), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                    /*DateTime?*/ let expires = (jwtToken.Payload.Expiration === null) ? null : new ($.$$.System.Nullable$$($.$$.System.DateTime))().$ctor$3(jwtToken.ValidTo);
                    /*DateTime?*/ let notBefore = (jwtToken.Payload.NotBefore === null) ? null : new ($.$$.System.Nullable$$($.$$.System.DateTime))().$ctor$3(jwtToken.ValidFrom);
                    if (!validationParameters.ValidateSignatureLast)
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.InternalValidators.ValidateAfterSignatureFailed(jwtToken, notBefore?.Clone() ?? null, expires?.Clone() ?? null, jwtToken.Audiences, validationParameters, configuration);
                    }
                }
                if (!(keysAttempted === null))
                {
                    if (kidExists)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenSignatureKeyNotFoundException().$ctor$28($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10503: Signature validation failed. The token's kid is: '{0}', but did not match any keys in TokenValidationParameters or Configuration. Keys tried: '{1}'.\nNumber of keys in TokenValidationParameters: '{2}'. \nNumber of keys in Configuration: '{3}'.\nExceptions caught:\n '{4}'.\ntoken: '{5}'. See https://aka.ms/IDX10503 for details."/*TokenLogMessages.IDX10503*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Header.Kid), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.System.Int32)), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                    else 
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenSignatureKeyNotFoundException().$ctor$28($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10517: Signature validation failed. The token's kid is missing. Keys tried: '{0}'.\nNumber of keys in TokenValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\nExceptions caught:\n '{3}'.\ntoken: '{4}'. See https://aka.ms/IDX10503 for details."/*TokenLogMessages.IDX10517*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.System.Int32)), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                }
                $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SigningKeyNotFound"/*TelemetryConstants.SignatureValidationErrors.SigningKeyNotFound*/, jwtToken, jwtToken.SignatureAlgorithm, null);
                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenSignatureKeyNotFoundException().$ctor$28("IDX10500: Signature validation failed. No security keys were provided to validate the signature."/*TokenLogMessages.IDX10500*/));
            }
            static /*IEnumerable<SecurityKey> */ GetAllDecryptionKeys(/*TokenValidationParameters*/ validationParameters)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (validationParameters.TokenDecryptionKey !== null)
                    {
                        yield validationParameters.TokenDecryptionKey;
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        var $en4 = validationParameters.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var key = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                yield key;
                            }
                        }
                    }
                }.bind(this));
            }
            /*ClaimsIdentity */ CreateClaimsIdentity(/*JwtSecurityToken*/ jwtToken, /*string*/ issuer, /*TokenValidationParameters*/ validationParameters)
            {
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                /*var*/ let actualIssuer = issuer;
                if ($.$$.System.String.IsNullOrWhiteSpace(issuer))
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX10244: Issuer is null or empty. Using runtime default for creating claims '{0}'."/*TokenLogMessages.IDX10244*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/) ], null, null));
                    }
                    actualIssuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                }
                return this.MapInboundClaims ? this.CreateClaimsIdentityWithMapping(jwtToken, actualIssuer, validationParameters) : this.CreateClaimsIdentityWithoutMapping(jwtToken, actualIssuer, validationParameters);
            }
            /*ClaimsIdentity */ CreateClaimsIdentityWithMapping(/*JwtSecurityToken*/ jwtToken, /*string*/ actualIssuer, /*TokenValidationParameters*/ validationParameters)
            {
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, actualIssuer);
                var $en2 = jwtToken.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var jwtClaim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (this._inboundClaimFilter.System$Collections$Generic$ICollection$$$Contains(jwtClaim.Type, [$.$$.System.String]))
                        {
                            continue;
                        }
                        /*string*/ let claimType;
                        /*bool*/ let wasMapped = true;
                        if (!this._inboundClaimTypeMap.System$Collections$Generic$IDictionary$$$$TryGetValue(jwtClaim.Type, $.$ref(() => claimType, ($v) => claimType = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]))
                        {
                            claimType = jwtClaim.Type;
                            wasMapped = false;
                        }
                        if ($.$$.System.String.op_Equality(claimType, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/))
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12710: Only a single 'Actor' is supported. Found second claim of type: '{0}', value: '{1}'"/*LogMessages.IDX12710*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtClaim.Value, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JwtSecurityToken*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken);
                                identity.Actor = this.CreateClaimsIdentity(actor, actualIssuer, validationParameters);
                            }
                        }
                        /*Claim*/ let claim = new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, actualIssuer, actualIssuer, identity);
                        if (jwtClaim.Properties.System$Collections$Generic$ICollection$$$Count > 0)
                        {
                            var $en5 = jwtClaim.Properties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var kv = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item(kv.Key, kv.Value, [$.$$.System.String, $.$$.System.String]);
                                }
                            }
                        }
                        if (wasMapped)
                        {
                            claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.ShortClaimTypeProperty, jwtClaim.Type, [$.$$.System.String, $.$$.System.String]);
                        }
                        identity.AddClaim(claim);
                    }
                }
                return identity;
            }
            /*ClaimsIdentity */ CreateClaimsIdentityWithoutMapping(/*JwtSecurityToken*/ jwtToken, /*string*/ actualIssuer, /*TokenValidationParameters*/ validationParameters)
            {
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, actualIssuer);
                var $en2 = jwtToken.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var jwtClaim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (this._inboundClaimFilter.System$Collections$Generic$ICollection$$$Contains(jwtClaim.Type, [$.$$.System.String]))
                        {
                            continue;
                        }
                        /*string*/ let claimType = jwtClaim.Type;
                        if ($.$$.System.String.op_Equality(claimType, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/))
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12710: Only a single 'Actor' is supported. Found second claim of type: '{0}', value: '{1}'"/*LogMessages.IDX12710*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtClaim.Value, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JwtSecurityToken*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken);
                                identity.Actor = this.CreateClaimsIdentity(actor, actualIssuer, validationParameters);
                            }
                        }
                        /*Claim*/ let claim = new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, actualIssuer, actualIssuer, identity);
                        if (jwtClaim.Properties.System$Collections$Generic$ICollection$$$Count > 0)
                        {
                            var $en5 = jwtClaim.Properties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var kv = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item(kv.Key, kv.Value, [$.$$.System.String, $.$$.System.String]);
                                }
                            }
                        }
                        identity.AddClaim(claim);
                    }
                }
                return identity;
            }
            /*string */ CreateActorValue(/*ClaimsIdentity*/ actor)
            {
                if (actor === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("actor");
                }
                if (actor.BootstrapContext !== null)
                {
                    /*string*/ let encodedJwt = $.$as(actor.BootstrapContext, $.$$.System.String);
                    if ($.$$.System.String.op_Inequality(encodedJwt, null))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX12713: Creating actor value using actor.BootstrapContext(as string)"/*LogMessages.IDX12713*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                        return encodedJwt;
                    }
                    /*JwtSecurityToken*/ let jwtToken = $.$as(actor.BootstrapContext, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken);
                    if (jwtToken !== null)
                    {
                        if ($.$$.System.String.op_Inequality(jwtToken.RawData, null))
                        {
                            $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX12714: Creating actor value using actor.BootstrapContext.rawData"/*LogMessages.IDX12714*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                            return jwtToken.RawData;
                        }
                        else 
                        {
                            $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX12715: Creating actor value by writing the JwtSecurityToken created from actor.BootstrapContext"/*LogMessages.IDX12715*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                            return this.WriteToken(jwtToken);
                        }
                    }
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX12711: actor.BootstrapContext is not a string AND actor.BootstrapContext is not a JWT"/*LogMessages.IDX12711*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                }
                $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX12712: actor.BootstrapContext is null. Creating the token using actor.Claims."/*LogMessages.IDX12712*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                return this.WriteToken(new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$2(null, null, actor.Claims, null, null, null));
            }
            /*void */ ValidateAudience(/*IEnumerable<string>*/ audiences, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAudience(audiences, jwtToken, validationParameters);
            }
            /*void */ ValidateLifetime(/*DateTime?*/ notBefore, /*DateTime?*/ expires, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateLifetime$1(notBefore?.Clone() ?? null, expires?.Clone() ?? null, jwtToken, validationParameters);
            }
            /*string */ ValidateIssuer(/*string*/ issuer, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                return $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuer$1(issuer, jwtToken, validationParameters);
            }
            /*void */ ValidateTokenReplay(/*DateTime?*/ expires, /*string*/ securityToken, /*TokenValidationParameters*/ validationParameters)
            {
                $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateTokenReplay$1(expires?.Clone() ?? null, securityToken, validationParameters);
            }
            /*SecurityKey */ ResolveIssuerSigningKey(/*string*/ token, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey$1(jwtToken.Header.Kid, jwtToken.Header.X5t, validationParameters, null);
            }
            /*SecurityKey */ ResolveTokenDecryptionKey(/*string*/ token, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.Header.Kid))
                {
                    if (validationParameters.TokenDecryptionKey !== null && $.$$.System.String.Equals$2(validationParameters.TokenDecryptionKey.KeyId, jwtToken.Header.Kid, $.$is(validationParameters.TokenDecryptionKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                    {
                        return validationParameters.TokenDecryptionKey;
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        var $en4 = validationParameters.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var key = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.Header.Kid, $.$is(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                                {
                                    return key;
                                }
                            }
                        }
                    }
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.Header.X5t))
                {
                    if (validationParameters.TokenDecryptionKey !== null)
                    {
                        if ($.$$.System.String.Equals$2(validationParameters.TokenDecryptionKey.KeyId, jwtToken.Header.X5t, $.$is(validationParameters.TokenDecryptionKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                        {
                            return validationParameters.TokenDecryptionKey;
                        }
                        /*X509SecurityKey*/ let x509Key = $.$as(validationParameters.TokenDecryptionKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey);
                        if (x509Key !== null && $.$$.System.String.Equals$2(x509Key.X5t, jwtToken.Header.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            return validationParameters.TokenDecryptionKey;
                        }
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        var $en4 = validationParameters.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var key = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.Header.X5t, $.$is(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                                {
                                    return key;
                                }
                                /*X509SecurityKey*/ let x509Key = $.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey);
                                if (x509Key !== null && $.$$.System.String.Equals$2(x509Key.X5t, jwtToken.Header.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    return key;
                                }
                            }
                        }
                    }
                }
                return null;
            }
            /*string */ DecryptToken(/*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                if ($.$$.System.String.IsNullOrEmpty(jwtToken.Header.Enc))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10612: Decryption failed. Header.Enc is null or empty, it must be specified."/*TokenLogMessages.IDX10612*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null))));
                }
                /*var*/ let keys = this.GetContentEncryptionKeys(jwtToken, validationParameters);
                /*var*/ let decryptionParameters = this.CreateJwtTokenDecryptionParameters(jwtToken, keys);
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecryptJwtToken$1(jwtToken, validationParameters, decryptionParameters);
            }
            /*JwtTokenDecryptionParameters */ CreateJwtTokenDecryptionParameters(/*JwtSecurityToken*/ jwtToken, /*IEnumerable<SecurityKey>*/ keys)
            {
                return (() =>
                {
                    //new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenDecryptionParameters()
                    const $t1 = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenDecryptionParameters;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Alg = jwtToken.Header.Alg;
                    $i1.AuthenticationTagBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.RawAuthenticationTag);
                    $i1.CipherTextBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.RawCiphertext);
                    $i1.DecompressionFunction = new ($.$$.System.Func$$$$$($.$typeArray($.$$.System.Byte), $.$$.System.String, $.$$.System.Int32, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecompressToken);
                    $i1.Enc = jwtToken.Header.Enc;
                    $i1.EncodedToken = jwtToken.RawData;
                    $i1.HeaderAsciiBytes = $.$$.System.Text.Encoding.ASCII.GetBytes$8(jwtToken.EncodedHeader);
                    $i1.InitializationVectorBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.RawInitializationVector);
                    $i1.MaximumDeflateSize = this.MaximumTokenSizeInBytes;
                    $i1.Keys$1 = keys;
                    $i1.Zip = jwtToken.Header.Zip;
                    return $i1;
                })();
            }
            /*IEnumerable<SecurityKey> */ GetContentEncryptionKeys(/*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                /*IEnumerable<SecurityKey>*/ let keys = null;
                if (validationParameters.TokenDecryptionKeyResolver !== null)
                {
                    keys = validationParameters.TokenDecryptionKeyResolver.Invoke(jwtToken.RawData, jwtToken, jwtToken.Header.Kid, validationParameters);
                }
                else 
                {
                    /*var*/ let key = this.ResolveTokenDecryptionKey(jwtToken.RawData, jwtToken, validationParameters);
                    if (key !== null)
                    {
                        keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (keys === null)
                {
                    keys = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.GetAllDecryptionKeys(validationParameters);
                }
                if ($.$$.System.String.Equals$5.call(jwtToken.Header.Alg, "dir"/*JwtConstants.DirectKeyUseAlg*/))
                {
                    return keys;
                }
                /*var*/ let unwrappedKeys = new ($.$$.System.Collections.Generic.List$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey))().$ctor$1();
                /*var*/ let exceptionStrings = new $.$$.System.Text.StringBuilder().$ctor$1();
                /*var*/ let keysAttempted = new $.$$.System.Text.StringBuilder().$ctor$1();
                var $en2 = keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var key = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        try
                        {
                            if ($.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.EcdsaWrapAlgorithms.System$Collections$Generic$ICollection$$$Contains(jwtToken.Header.Alg, [$.$$.System.String]))
                            {
                                /*ECDsaSecurityKey*/ let publicKey;
                                if ($.$mit.Microsoft.IdentityModel.Tokens.AppContextSwitches.UseRfcDefinitionOfEpkAndKid)
                                {
                                    /*string*/ let epk = jwtToken.Header.GetStandardClaim("epk"/*JwtHeaderParameterNames.Epk*/);
                                    publicKey = new $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey().$ctor$5(new $.$mit.Microsoft.IdentityModel.Tokens.JsonWebKey().$ctor$4(epk), false);
                                }
                                else 
                                {
                                    publicKey = $.$as(validationParameters.TokenDecryptionKey, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey);
                                }
                                /*var*/ let ecdhKeyExchangeProvider = new $.$mit.Microsoft.IdentityModel.Tokens.EcdhKeyExchangeProvider().$ctor$1($.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey), publicKey, jwtToken.Header.Alg, jwtToken.Header.Enc);
                                /*string*/ let apu = jwtToken.Header.GetStandardClaim("apu"/*JwtHeaderParameterNames.Apu*/);
                                /*string*/ let apv = jwtToken.Header.GetStandardClaim("apv"/*JwtHeaderParameterNames.Apv*/);
                                /*SecurityKey*/ let kdf = ecdhKeyExchangeProvider.GenerateKdf(apu, apv);
                                /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(kdf, ecdhKeyExchangeProvider.GetEncryptionAlgorithm());
                                /*var*/ let unwrappedKey = kwp.UnwrapKey($.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.RawEncryptedKey));
                                unwrappedKeys.Add(new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3(unwrappedKey));
                            }
                            else if (key.CryptoProviderFactory.IsSupportedAlgorithm(jwtToken.Header.Alg, key))
                            {
                                /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(key, jwtToken.Header.Alg);
                                /*var*/ let unwrappedKey = kwp.UnwrapKey($.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.RawEncryptedKey));
                                unwrappedKeys.Add(new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3(unwrappedKey));
                            }
                        }
                        catch(ex)
                        {
                            exceptionStrings.AppendLine$2($.$$.System.Exception.ToString.call(ex));
                        }
                        keysAttempted.AppendLine$2(key.KeyId);
                    }
                }
                if (unwrappedKeys.Count > 0 || exceptionStrings.Length === 0)
                {
                    return unwrappedKeys;
                }
                else 
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenKeyWrapException().$ctor$16($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10618: Key unwrap failed using decryption Keys: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10618*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Text.StringBuilder.ToString.call(keysAttempted)), exceptionStrings, jwtToken ], null, null))));
                }
            }
            static /*byte[] */ GetSymmetricSecurityKey(/*SecurityKey*/ key)
            {
                if (key === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                }
                /*SymmetricSecurityKey*/ let symmetricSecurityKey = $.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey);
                if (symmetricSecurityKey !== null)
                {
                    return symmetricSecurityKey.Key;
                }
                else 
                {
                    /*JsonWebKey*/ let jsonWebKey = $.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.JsonWebKey);
                    if (jsonWebKey !== null && $.$$.System.String.op_Inequality(jsonWebKey.K, null))
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jsonWebKey.K);
                    }
                }
                return null;
            }
            /*void */ ValidateIssuerSecurityKey(/*SecurityKey*/ key, /*JwtSecurityToken*/ securityToken, /*TokenValidationParameters*/ validationParameters)
            {
                $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerSecurityKey$1(key, securityToken, validationParameters);
            }
            /*void */ WriteToken$1(/*XmlWriter*/ writer, /*SecurityToken*/ token)
            {
                throw new $.$$.System.NotImplementedException().$ctor$9();
            }
            /*Task<TokenValidationResult> */ ValidateTokenAsync$2(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                try
                {
                    /*var*/ let validatedToken;
                    /*var*/ let claimsPrincipal = this.ValidateToken(token, validationParameters, $.$ref(() => validatedToken, ($v) => validatedToken = $v, $.$mit.Microsoft.IdentityModel.Tokens.SecurityToken));
                    return $.$$.System.Threading.Tasks.Task.FromResult($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, (() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                        const $t2 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.SecurityToken = validatedToken;
                        $i2.ClaimsIdentity = $.$as((claimsPrincipal?.Identity ?? null), $.$ssc.System.Security.Claims.ClaimsIdentity);
                        $i2.IsValid = true;
                        return $i2;
                    })());
                }
                catch(ex)
                {
                    return $.$$.System.Threading.Tasks.Task.FromResult($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, (() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.IsValid = false;
                        $i1.Exception = ex;
                        return $i1;
                    })());
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._mapInboundClaims = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultMapInboundClaims;
                this.TelemetryClient = new $.$mit.Microsoft.IdentityModel.Telemetry.TelemetryClient().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._jsonClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties/json_type";
                }
                {
                    this._namespace = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties";
                }
                {
                    this._className = "System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler";
                }
                {
                    this._shortClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties/ShortTypeName";
                }
                {
                    this.DefaultInboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.InboundClaimTypeMap);
                }
                {
                    this.DefaultOutboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.OutboundClaimTypeMap);
                }
                {
                    this.DefaultInboundClaimFilter = $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.InboundClaimFilter;
                }
                {
                    this.DefaultOutboundAlgorithmMap = (() =>
                    {
                        //new $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String)()
                        const $t1 = $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha256"/*SecurityAlgorithms.EcdsaSha256Signature*/, "ES256"/*SecurityAlgorithms.EcdsaSha256*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha384"/*SecurityAlgorithms.EcdsaSha384Signature*/, "ES384"/*SecurityAlgorithms.EcdsaSha384*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha512"/*SecurityAlgorithms.EcdsaSha512Signature*/, "ES512"/*SecurityAlgorithms.EcdsaSha512*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#hmac-sha256"/*SecurityAlgorithms.HmacSha256Signature*/, "HS256"/*SecurityAlgorithms.HmacSha256*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#hmac-sha384"/*SecurityAlgorithms.HmacSha384Signature*/, "HS384"/*SecurityAlgorithms.HmacSha384*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#hmac-sha512"/*SecurityAlgorithms.HmacSha512Signature*/, "HS512"/*SecurityAlgorithms.HmacSha512*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"/*SecurityAlgorithms.RsaSha256Signature*/, "RS256"/*SecurityAlgorithms.RsaSha256*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#rsa-sha384"/*SecurityAlgorithms.RsaSha384Signature*/, "RS384"/*SecurityAlgorithms.RsaSha384*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#rsa-sha512"/*SecurityAlgorithms.RsaSha512Signature*/, "RS512"/*SecurityAlgorithms.RsaSha512*/);
                        return $i1;
                    })();
                }
            }
            static $h = 647073;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14457905,"p":[{"p":262145,"g":{"r":0,"d":0,"h":85899992993,"f":50331649},"s":{"r":0,"d":0,"h":90194960289,"f":83886081},"n":"MapInboundClaims","d":647073,"h":81605025697,"f":2097153},{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"g":{"r":0,"d":0,"h":98784894881,"f":50331649},"s":{"r":0,"d":0,"h":103079862177,"f":83886081},"n":"InboundClaimTypeMap","d":647073,"h":94489927585,"f":2097153},{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"g":{"r":0,"d":0,"h":111669796769,"f":50331649},"s":{"r":0,"d":0,"h":115964764065,"f":83886081},"n":"OutboundClaimTypeMap","d":647073,"h":107374829473,"f":2097153},{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"g":{"r":0,"d":0,"h":124554698657,"f":50331649},"n":"OutboundAlgorithmMap","d":647073,"h":120259731361,"f":2097153},{"p":$.$$.System.Collections.Generic.ISet$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":133144633249,"f":50331649},"s":{"r":0,"d":0,"h":137439600545,"f":83886081},"n":"InboundClaimFilter","d":647073,"h":128849665953,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":146029535137,"f":50331681},"s":{"r":0,"d":0,"h":150324502433,"f":83886113},"n":"ShortClaimTypeProperty","d":647073,"h":141734567841,"f":2097185},{"p":1310721,"g":{"r":0,"d":0,"h":158914437025,"f":50331681},"s":{"r":0,"d":0,"h":163209404321,"f":83886113},"n":"JsonClaimTypeProperty","d":647073,"h":154619469729,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":171799338913,"f":50364417},"n":"CanValidateToken","d":647073,"h":167504371617,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":180389273505,"f":50364417},"n":"CanWriteToken","d":647073,"h":176094306209,"f":2129921},{"p":142475265,"g":{"r":0,"d":0,"h":188979208097,"f":50364417},"n":"TokenType","d":647073,"h":184684240801,"f":2129921}],"m":[{"r":262145,"p":[{"n":"token","p":1310721}],"n":"CanReadToken","d":647073,"h":193274175393,"f":16809985},{"r":1310721,"p":[{"n":"tokenDescriptor","p":14130225}],"n":"CreateEncodedJwt","o":"@$3","d":647073,"h":197569142689,"f":16777345},{"r":1310721,"p":[{"n":"issuer","p":1310721},{"n":"audience","p":1310721},{"n":"subject","p":295390},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"issuedAt","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"signingCredentials","p":15965233}],"n":"CreateEncodedJwt","o":"@$2","d":647073,"h":201864109985,"f":16777345},{"r":1310721,"p":[{"n":"issuer","p":1310721},{"n":"audience","p":1310721},{"n":"subject","p":295390},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"issuedAt","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"signingCredentials","p":15965233},{"n":"encryptingCredentials","p":3972145}],"n":"CreateEncodedJwt","o":"@$1","d":647073,"h":206159077281,"f":16777345},{"r":1310721,"p":[{"n":"issuer","p":1310721},{"n":"audience","p":1310721},{"n":"subject","p":295390},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"issuedAt","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"signingCredentials","p":15965233},{"n":"encryptingCredentials","p":3972145},{"n":"claimCollection","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"CreateEncodedJwt","d":647073,"h":210454044577,"f":16777345},{"r":516001,"p":[{"n":"tokenDescriptor","p":14130225}],"n":"CreateJwtSecurityToken","o":"@$3","d":647073,"h":214749011873,"f":16777345},{"r":516001,"p":[{"n":"issuer","p":1310721},{"n":"audience","p":1310721},{"n":"subject","p":295390},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"issuedAt","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"signingCredentials","p":15965233},{"n":"encryptingCredentials","p":3972145}],"n":"CreateJwtSecurityToken","o":"@$1","d":647073,"h":219043979169,"f":16777345},{"r":516001,"p":[{"n":"issuer","p":1310721},{"n":"audience","p":1310721},{"n":"subject","p":295390},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"issuedAt","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"signingCredentials","p":15965233},{"n":"encryptingCredentials","p":3972145},{"n":"claimCollection","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"CreateJwtSecurityToken","d":647073,"h":223338946465,"f":16777345},{"r":516001,"p":[{"n":"issuer","p":1310721,"f":65},{"n":"audience","p":1310721,"f":65},{"n":"subject","p":295390,"f":65},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h,"f":65},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h,"f":65},{"n":"issuedAt","p":$.$typeNullable($.$$.System.DateTime).$h,"f":65},{"n":"signingCredentials","p":15965233,"f":65}],"n":"CreateJwtSecurityToken","o":"@$2","d":647073,"h":227633913761,"f":16777345},{"r":13802545,"p":[{"n":"tokenDescriptor","p":14130225}],"n":"CreateToken","d":647073,"h":231928881057,"f":16809985},{"r":516001,"p":[{"n":"tokenDescriptor","p":14130225}],"n":"CreateJwtSecurityTokenPrivate","d":647073,"h":236223848353,"f":16777218},{"r":516001,"p":[{"n":"innerJwt","p":516001},{"n":"encryptingCredentials","p":3972145},{"n":"tokenType","p":1310721},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"EncryptToken","d":647073,"h":240518815649,"f":16777218},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"p":[{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"OutboundClaimTypeTransform","o":"@$1","d":647073,"h":244813782945,"f":16777218},{"r":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object).$h,"p":[{"n":"claimCollection","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"OutboundClaimTypeTransform","d":647073,"h":249108750241,"f":16777218},{"r":516001,"p":[{"n":"token","p":1310721}],"n":"ReadJwtToken","d":647073,"h":253403717537,"f":16777217},{"r":13802545,"p":[{"n":"token","p":1310721}],"n":"ReadToken","d":647073,"h":257698684833,"f":16809985},{"r":13802545,"p":[{"n":"reader","p":53394070},{"n":"validationParameters","p":16817201}],"n":"ReadToken","o":"@$1","d":647073,"h":261993652129,"f":16809985},{"r":426462,"p":[{"n":"token","p":1310721},{"n":"validationParameters","p":16817201},{"n":"validatedToken","p":13802545,"f":2}],"n":"ValidateToken","d":647073,"h":266288619425,"f":16809985},{"r":426462,"p":[{"n":"token","p":1310721},{"n":"outerToken","p":516001},{"n":"validationParameters","p":16817201},{"n":"signatureValidatedToken","p":13802545,"f":2}],"n":"ValidateToken","o":"@$2","d":647073,"h":270583586721,"f":16777218},{"r":426462,"p":[{"n":"decryptedJwt","p":1310721},{"n":"outerToken","p":516001},{"n":"validationParameters","p":16817201},{"n":"currentConfiguration","p":1678385},{"n":"signatureValidatedToken","p":13802545,"f":2},{"n":"exceptionThrown","p":97386497,"f":2}],"n":"ValidateJWE","d":647073,"h":274878554017,"f":16777218},{"r":426462,"p":[{"n":"token","p":1310721},{"n":"validationParameters","p":16817201},{"n":"currentConfiguration","p":1678385},{"n":"signatureValidatedToken","p":13802545,"f":2},{"n":"exceptionThrown","p":97386497,"f":2}],"n":"ValidateJWS","d":647073,"h":279173521313,"f":16777218},{"r":516001,"p":[{"n":"token","p":1310721},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385}],"n":"ValidateSignatureUsingDelegates","d":647073,"h":283468488609,"f":16777250},{"r":516001,"p":[{"n":"token","p":1310721},{"n":"jwtToken","p":516001},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385}],"n":"ValidateSignatureAndIssuerSecurityKey","d":647073,"h":287763455905,"f":16777218},{"r":516001,"p":[{"n":"token","p":1310721},{"n":"validationParameters","p":16817201}],"n":"GetJwtSecurityTokenFromToken","d":647073,"h":292058423201,"f":16777218},{"r":426462,"p":[{"n":"jwtToken","p":516001},{"n":"validationParameters","p":16817201}],"n":"ValidateTokenPayload","o":"@$1","d":647073,"h":296353390497,"f":16777220},{"r":426462,"p":[{"n":"jwtToken","p":516001},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385}],"n":"ValidateTokenPayload","d":647073,"h":300648357793,"f":16777218},{"r":426462,"p":[{"n":"jwtToken","p":516001},{"n":"issuer","p":1310721},{"n":"validationParameters","p":16817201}],"n":"CreateClaimsPrincipalFromToken","d":647073,"h":304943325089,"f":16777218},{"r":1310721,"p":[{"n":"token","p":13802545}],"n":"WriteToken","d":647073,"h":309238292385,"f":16809985},{"r":65537,"p":[{"n":"telemetryClient","p":236593},{"n":"errorType","p":1310721},{"n":"securityToken","p":13802545},{"n":"algorithm","p":1310721},{"n":"key","p":13671473}],"n":"RecordSignatureValidationTelemetry","d":647073,"h":313533259681,"f":16777250},{"r":262145,"p":[{"n":"encodedBytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"signature","p":$.$typeArray($.$$.System.Byte).$h},{"n":"key","p":13671473},{"n":"algorithm","p":1310721},{"n":"securityToken","p":13802545},{"n":"validationParameters","p":16817201},{"n":"telemetryClient","p":236593}],"n":"ValidateSignature","d":647073,"h":317828226977,"f":16777250},{"r":516001,"p":[{"n":"token","p":1310721},{"n":"validationParameters","p":16817201}],"n":"ValidateSignature","o":"@$1","d":647073,"h":322123194273,"f":16777348},{"r":516001,"p":[{"n":"token","p":1310721},{"n":"jwtToken","p":516001},{"n":"validationParameters","p":16817201},{"n":"configuration","p":1678385}],"n":"ValidateSignature","o":"@$2","d":647073,"h":326418161569,"f":16777218},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,"p":[{"n":"validationParameters","p":16817201}],"n":"GetAllDecryptionKeys","d":647073,"h":330713128865,"f":16777250},{"r":295390,"p":[{"n":"jwtToken","p":516001},{"n":"issuer","p":1310721},{"n":"validationParameters","p":16817201}],"n":"CreateClaimsIdentity","d":647073,"h":335008096161,"f":16777348},{"r":295390,"p":[{"n":"jwtToken","p":516001},{"n":"actualIssuer","p":1310721},{"n":"validationParameters","p":16817201}],"n":"CreateClaimsIdentityWithMapping","d":647073,"h":339303063457,"f":16777218},{"r":295390,"p":[{"n":"jwtToken","p":516001},{"n":"actualIssuer","p":1310721},{"n":"validationParameters","p":16817201}],"n":"CreateClaimsIdentityWithoutMapping","d":647073,"h":343598030753,"f":16777218},{"r":1310721,"p":[{"n":"actor","p":295390}],"n":"CreateActorValue","d":647073,"h":347892998049,"f":16777348},{"r":65537,"p":[{"n":"audiences","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h},{"n":"jwtToken","p":516001},{"n":"validationParameters","p":16817201}],"n":"ValidateAudience","d":647073,"h":352187965345,"f":16777348},{"r":65537,"p":[{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"jwtToken","p":516001},{"n":"validationParameters","p":16817201}],"n":"ValidateLifetime","d":647073,"h":356482932641,"f":16777348},{"r":1310721,"p":[{"n":"issuer","p":1310721},{"n":"jwtToken","p":516001},{"n":"validationParameters","p":16817201}],"n":"ValidateIssuer","d":647073,"h":360777899937,"f":16777348},{"r":65537,"p":[{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"securityToken","p":1310721},{"n":"validationParameters","p":16817201}],"n":"ValidateTokenReplay","d":647073,"h":365072867233,"f":16777348},{"r":13671473,"p":[{"n":"token","p":1310721},{"n":"jwtToken","p":516001},{"n":"validationParameters","p":16817201}],"n":"ResolveIssuerSigningKey","d":647073,"h":369367834529,"f":16777348},{"r":13671473,"p":[{"n":"token","p":1310721},{"n":"jwtToken","p":516001},{"n":"validationParameters","p":16817201}],"n":"ResolveTokenDecryptionKey","d":647073,"h":373662801825,"f":16777348},{"r":1310721,"p":[{"n":"jwtToken","p":516001},{"n":"validationParameters","p":16817201}],"n":"DecryptToken","d":647073,"h":377957769121,"f":16777220},{"r":851229,"p":[{"n":"jwtToken","p":516001},{"n":"keys","p":$.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h}],"n":"CreateJwtTokenDecryptionParameters","d":647073,"h":382252736417,"f":16777218},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,"p":[{"n":"jwtToken","p":516001},{"n":"validationParameters","p":16817201}],"n":"GetContentEncryptionKeys","d":647073,"h":386547703713,"f":16777224},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"key","p":13671473}],"n":"GetSymmetricSecurityKey","d":647073,"h":390842671009,"f":16777250},{"r":65537,"p":[{"n":"key","p":13671473},{"n":"securityToken","p":516001},{"n":"validationParameters","p":16817201}],"n":"ValidateIssuerSecurityKey","d":647073,"h":395137638305,"f":16777348},{"r":65537,"p":[{"n":"writer","p":58440342},{"n":"token","p":13802545}],"n":"WriteToken","o":"@$1","d":647073,"h":399432605601,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,"p":[{"n":"token","p":1310721},{"n":"validationParameters","p":16817201}],"n":"ValidateTokenAsync","o":"@$2","d":647073,"h":403727572897,"f":16809985}],"l":[{"t":$.$$.System.Collections.Generic.ISet$$($.$$.System.String).$h,"n":"_inboundClaimFilter","d":647073,"h":8590581665,"f":4194306},{"t":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"n":"_inboundClaimTypeMap","d":647073,"h":12885548961,"f":4194306},{"t":1310721,"n":"_jsonClaimType","d":647073,"h":17180516257,"f":4194338},{"t":1310721,"n":"_namespace","d":647073,"h":21475483553,"f":4194338},{"t":1310721,"n":"_className","d":647073,"h":25770450849,"f":4194338},{"t":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"n":"_outboundClaimTypeMap","d":647073,"h":30065418145,"f":4194306},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String).$h,"n":"_outboundAlgorithmMap","d":647073,"h":34360385441,"f":4194306},{"t":1310721,"n":"_shortClaimType","d":647073,"h":38655352737,"f":4194338},{"t":262145,"n":"_mapInboundClaims","d":647073,"h":42950320033,"f":4194306},{"t":236593,"n":"TelemetryClient","d":647073,"h":47245287329,"f":4194312},{"t":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"n":"DefaultInboundClaimTypeMap","d":647073,"h":51540254625,"f":4194337},{"t":262145,"n":"DefaultMapInboundClaims","d":647073,"h":55835221921,"f":4194337},{"t":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"n":"DefaultOutboundClaimTypeMap","d":647073,"h":60130189217,"f":4194337},{"t":$.$$.System.Collections.Generic.ISet$$($.$$.System.String).$h,"n":"DefaultInboundClaimFilter","d":647073,"h":64425156513,"f":4194337},{"t":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"n":"DefaultOutboundAlgorithmMap","d":647073,"h":68720123809,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":647073,"h":77310058401,"f":16777217}],"i":[11312177],"j":[712609],"h":647073}; }
            static get $b() { return $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenHandler; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mit.Microsoft.IdentityModel.Tokens.ISecurityTokenValidator ]; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler`; }
        });
        
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader", ($self) => class JwtHeader extends $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object)
        {
            /*string*/ ClassName = null;
            $ctor$10()
            {
                super.$ctor$6($.$$.System.StringComparer.Ordinal);
                {
                }
                return this;
            }
            $ctor$11(/*string*/ json)
            {
                super.$ctor$1();
                {
                    _ = $.$firstOf(json, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("json") });
                    /*Utf8JsonReader*/ let reader = new $.$stj.System.Text.Json.Utf8JsonReader().$ctor$4($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1($.$$.System.Text.Encoding.UTF8.GetBytes$8(json)), new $.$stj.System.Text.Json.JsonReaderOptions());
                    if (!$.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 1/*JsonTokenType.StartObject*/, true))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$stj.System.Text.Json.JsonException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX11023: Expecting json reader to be positioned on '{0}', reader was positioned at: '{1}', Reading: '{2}', Position: '{3}', CurrentDepth: '{4}', BytesConsumed: '{5}'."/*Microsoft.IdentityModel.Tokens.LogMessages.IDX11023*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("JsonTokenType.StartObject"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenType, $.$stj.System.Text.Json.JsonTokenType)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(this.ClassName), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenStartIndex, $.$$.System.Int64)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.CurrentDepth, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.BytesConsumed, $.$$.System.Int64)) ], null, null))));
                    }
                    while(true)
                    {
                        if (reader.TokenType === 5/*JsonTokenType.PropertyName*/)
                        {
                            /*string*/ let propertyName = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyName($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), this.ClassName, true);
                            /*object*/ let obj;
                            if (reader.TokenType === 3/*JsonTokenType.StartArray*/)
                            {
                                obj = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadArrayOfObjects($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), propertyName, this.ClassName);
                            }
                            else 
                            {
                                obj = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyValueAsObject($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), propertyName, this.ClassName, false);
                            }
                            this.set_Item(propertyName, obj);
                        }
                        else if ($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 2/*JsonTokenType.EndObject*/, true))
                        {
                            break;
                        }
                        else if (!reader.Read())
                        {
                            break;
                        }
                    }
                }
                return this;
            }
            $ctor$21(/*SigningCredentials*/ signingCredentials)
            {
                this.$ctor$20(signingCredentials, null);
                {
                }
                return this;
            }
            $ctor$16(/*EncryptingCredentials*/ encryptingCredentials)
            {
                this.$ctor$15(encryptingCredentials, null);
                {
                }
                return this;
            }
            $ctor$20(/*SigningCredentials*/ signingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap)
            {
                this.$ctor$19(signingCredentials, outboundAlgorithmMap, null);
                {
                }
                return this;
            }
            $ctor$19(/*SigningCredentials*/ signingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType)
            {
                this.$ctor$18(signingCredentials, outboundAlgorithmMap, tokenType, null);
                {
                }
                return this;
            }
            $ctor$17(/*SigningCredentials*/ signingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalInnerHeaderClaims, /*bool*/ includeKeyIdInHeader)
            {
                super.$ctor$6($.$$.System.StringComparer.Ordinal);
                {
                    if (signingCredentials === null)
                    {
                        this.set_Item("alg"/*JwtHeaderParameterNames.Alg*/, "none"/*SecurityAlgorithms.None*/);
                    }
                    else 
                    {
                        /*string*/ let outboundAlg;
                        if (outboundAlgorithmMap !== null && outboundAlgorithmMap.System$Collections$Generic$IDictionary$$$$TryGetValue(signingCredentials.Algorithm, $.$ref(() => outboundAlg, ($v) => outboundAlg = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]))
                        {
                            this.Alg = outboundAlg;
                        }
                        else 
                        {
                            this.Alg = signingCredentials.Algorithm;
                        }
                        if (includeKeyIdInHeader)
                        {
                            if (!$.$$.System.String.IsNullOrEmpty(signingCredentials.Key.KeyId))
                            {
                                this.Kid = signingCredentials.Key.KeyId;
                            }
                            let x509SigningCredentials;
                            if ($.$is(signingCredentials, $.$mit.Microsoft.IdentityModel.Tokens.X509SigningCredentials, { set $v(v){ x509SigningCredentials = v; } }))
                            {
                                this.set_Item("x5t"/*JwtHeaderParameterNames.X5t*/, $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(x509SigningCredentials.Certificate.GetCertHash()));
                            }
                        }
                    }
                    if ($.$$.System.String.IsNullOrEmpty(tokenType))
                    {
                        this.Typ = "JWT"/*JwtConstants.HeaderType*/;
                    }
                    else 
                    {
                        this.Typ = tokenType;
                    }
                    this.AddAdditionalClaims(additionalInnerHeaderClaims, false);
                    this.SigningCredentials = signingCredentials;
                }
                return this;
            }
            $ctor$18(/*SigningCredentials*/ signingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalInnerHeaderClaims)
            {
                this.$ctor$17(signingCredentials, outboundAlgorithmMap, tokenType, additionalInnerHeaderClaims, true);
                {
                }
                return this;
            }
            $ctor$15(/*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap)
            {
                this.$ctor$14(encryptingCredentials, outboundAlgorithmMap, null);
                {
                }
                return this;
            }
            $ctor$14(/*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType)
            {
                this.$ctor$13(encryptingCredentials, outboundAlgorithmMap, tokenType, null);
                {
                }
                return this;
            }
            $ctor$12(/*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalHeaderClaims, /*bool*/ includeKeyIdInHeader)
            {
                super.$ctor$6($.$$.System.StringComparer.Ordinal);
                {
                    if (encryptingCredentials === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials");
                    }
                    /*string*/ let outboundAlg;
                    if (outboundAlgorithmMap !== null && outboundAlgorithmMap.System$Collections$Generic$IDictionary$$$$TryGetValue(encryptingCredentials.Alg, $.$ref(() => outboundAlg, ($v) => outboundAlg = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]))
                    {
                        this.Alg = outboundAlg;
                    }
                    else 
                    {
                        this.Alg = encryptingCredentials.Alg;
                    }
                    if (outboundAlgorithmMap !== null && outboundAlgorithmMap.System$Collections$Generic$IDictionary$$$$TryGetValue(encryptingCredentials.Enc, $.$ref(() => outboundAlg, ($v) => outboundAlg = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]))
                    {
                        this.Enc = outboundAlg;
                    }
                    else 
                    {
                        this.Enc = encryptingCredentials.Enc;
                    }
                    if ($.$mit.Microsoft.IdentityModel.Tokens.AppContextSwitches.UseRfcDefinitionOfEpkAndKid)
                    {
                        if (includeKeyIdInHeader && !$.$$.System.String.IsNullOrEmpty(encryptingCredentials.KeyExchangePublicKey.KeyId))
                        {
                            this.Kid = encryptingCredentials.KeyExchangePublicKey.KeyId;
                        }
                        if ($.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.EcdsaWrapAlgorithms.System$Collections$Generic$ICollection$$$Contains(encryptingCredentials.Alg, [$.$$.System.String]))
                        {
                            this.Add("epk"/*JwtHeaderParameterNames.Epk*/, $.$mit.Microsoft.IdentityModel.Tokens.JsonWebKeyConverter.ConvertFromSecurityKey(encryptingCredentials.Key).RepresentAsAsymmetricPublicJwk());
                        }
                    }
                    else 
                    {
                        if (includeKeyIdInHeader && !$.$$.System.String.IsNullOrEmpty(encryptingCredentials.Key.KeyId))
                        {
                            this.Kid = encryptingCredentials.Key.KeyId;
                        }
                    }
                    if ($.$$.System.String.IsNullOrEmpty(tokenType))
                    {
                        this.Typ = "JWT"/*JwtConstants.HeaderType*/;
                    }
                    else 
                    {
                        this.Typ = tokenType;
                    }
                    this.AddAdditionalClaims(additionalHeaderClaims, encryptingCredentials.SetDefaultCtyClaim);
                    this.EncryptingCredentials = encryptingCredentials;
                }
                return this;
            }
            $ctor$13(/*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                this.$ctor$12(encryptingCredentials, outboundAlgorithmMap, tokenType, additionalHeaderClaims, true);
                {
                }
                return this;
            }
            /*string */ get Alg()
            {
                return this.GetStandardClaim("alg"/*JwtHeaderParameterNames.Alg*/);
            }
            /*string */ set Alg(value)
            {
                this.set_Item("alg"/*JwtHeaderParameterNames.Alg*/, value);
            }
            /*string */ get Cty()
            {
                return this.GetStandardClaim("cty"/*JwtHeaderParameterNames.Cty*/);
            }
            /*string */ set Cty(value)
            {
                this.set_Item("cty"/*JwtHeaderParameterNames.Cty*/, value);
            }
            /*string */ get Enc()
            {
                return this.GetStandardClaim("enc"/*JwtHeaderParameterNames.Enc*/);
            }
            /*string */ set Enc(value)
            {
                this.set_Item("enc"/*JwtHeaderParameterNames.Enc*/, value);
            }
            /*EncryptingCredentials*/ EncryptingCredentials = null;
            /*string */ get IV()
            {
                return this.GetStandardClaim("iv"/*JwtHeaderParameterNames.IV*/);
            }
            /*string */ get Kid()
            {
                return this.GetStandardClaim("kid"/*JwtHeaderParameterNames.Kid*/);
            }
            /*string */ set Kid(value)
            {
                this.set_Item("kid"/*JwtHeaderParameterNames.Kid*/, value);
            }
            /*SigningCredentials*/ SigningCredentials = null;
            /*string */ get Typ()
            {
                return this.GetStandardClaim("typ"/*JwtHeaderParameterNames.Typ*/);
            }
            /*string */ set Typ(value)
            {
                this.set_Item("typ"/*JwtHeaderParameterNames.Typ*/, value);
            }
            /*string */ get X5t()
            {
                return this.GetStandardClaim("x5t"/*JwtHeaderParameterNames.X5t*/);
            }
            /*string */ get X5c()
            {
                return this.GetStandardClaim("x5c"/*JwtHeaderParameterNames.X5c*/);
            }
            /*string */ get Zip()
            {
                return this.GetStandardClaim("zip"/*JwtHeaderParameterNames.Zip*/);
            }
            static /*JwtHeader */ Base64UrlDeserialize(/*string*/ base64UrlEncodedJsonString)
            {
                _ = $.$firstOf(base64UrlEncodedJsonString, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("base64UrlEncodedJsonString") });
                return new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader().$ctor$11($.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$3(base64UrlEncodedJsonString));
            }
            /*string */ Base64UrlEncode()
            {
                return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$3(this.SerializeToJson());
            }
            /*string */ GetStandardClaim(/*string*/ claimType)
            {
                /*object*/ let value;
                if (this.TryGetValue(claimType, $.$ref(() => value, ($v) => value = $v, $.$$.System.Object)))
                {
                    if (value === null)
                    {
                        return null;
                    }
                    let str;
                    if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                    {
                        return str;
                    }
                    let jsonElement;
                    let list;
                    let objectList;
                    if ($.$is(value, $.$stj.System.Text.Json.JsonElement, { set $v(v){ jsonElement = v; } }))
                    {
                        return $.$stj.System.Text.Json.JsonElement.ToString.call(jsonElement);
                    }
                    else if ($.$is(value, $.$$.System.Collections.Generic.IList$$($.$$.System.String), { set $v(v){ list = v; } }))
                    {
                        /*JsonElement*/ let json = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.CreateJsonElement(list);
                        return $.$stj.System.Text.Json.JsonElement.ToString.call(json);
                    }
                    else if ($.$is(value, $.$$.System.Collections.Generic.IList$$($.$$.System.Object), { set $v(v){ objectList = v; } }))
                    {
                        /*var*/ let stringList = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$3(objectList.System$Collections$Generic$ICollection$$$Count);
                        var $en4 = objectList.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                let strItem;
                                if ($.$is(item, $.$$.System.String, { set $v(v){ strItem = v; } }))
                                {
                                    stringList.Add(strItem);
                                }
                                else 
                                {
                                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$stj.System.Text.Json.JsonException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX11026: Unable to get claim value as a string from claim type:'{0}', value type was:'{1}'. Acceptable types are String, IList<String>, and System.Text.Json.JsonElement."/*Microsoft.IdentityModel.Tokens.LogMessages.IDX11026*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(claimType), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(item)) ], null, null))));
                                }
                            }
                        }
                        /*JsonElement*/ let json = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.CreateJsonElement(stringList);
                        return $.$stj.System.Text.Json.JsonElement.ToString.call(json);
                    }
                    return $.$$.System.String.Empty;
                }
                return null;
            }
            /*void */ AddAdditionalClaims(/*IDictionary<string, object>*/ additionalHeaderClaims, /*bool*/ setDefaultCtyClaim)
            {
                if ($.$$.System.Int32.op_GreaterThan$1((additionalHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0) && $.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, $.$sl.System.Linq.Enumerable.Intersect($.$$.System.String, additionalHeaderClaims.System$Collections$Generic$IDictionary$$$$Keys, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader.DefaultHeaderParameters, $.$$.System.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12742: ''{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX12742*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ "additionalHeaderClaims", $.$$.System.String.Join$5(", ", $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader.DefaultHeaderParameters) ], null, null))));
                }
                if (additionalHeaderClaims !== null)
                {
                    if (!additionalHeaderClaims.System$Collections$Generic$IDictionary$$$$TryGetValue("cty"/*JwtHeaderParameterNames.Cty*/, $.$discardRef(), [$.$$.System.String, $.$$.System.Object]) && setDefaultCtyClaim)
                    {
                        this.Cty = "JWT"/*JwtConstants.HeaderType*/;
                    }
                    var $en3 = additionalHeaderClaims.System$Collections$Generic$IDictionary$$$$Keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var claim = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.set_Item(claim, additionalHeaderClaims.System$Collections$Generic$IDictionary$$$$get_Item(claim, [$.$$.System.String, $.$$.System.Object]));
                        }
                    }
                }
                else if (setDefaultCtyClaim)
                {
                    this.Cty = "JWT"/*JwtConstants.HeaderType*/;
                }
            }
            /*IList<string>*/ static DefaultHeaderParameters = null;
            /*string */ SerializeToJson()
            {
                let memoryStream = null;
                try
                {
                    memoryStream = new $.$$.System.IO.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    try
                    {
                        writer = new $.$stj.System.Text.Json.Utf8JsonWriter().$ctor$2(memoryStream, (() =>
                        {
                            //new $.$stj.System.Text.Json.JsonWriterOptions()
                            const $t1 = $.$stj.System.Text.Json.JsonWriterOptions;
                            const $i1 = new $t1();
                            $i1.Encoder = $.$stew.System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i1;
                        })());
                        writer.WriteStartObject();
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObjects($.$ref(() => writer, ($v) => writer = $v, $.$stj.System.Text.Json.Utf8JsonWriter), this);
                        writer.WriteEndObject();
                        writer.Flush();
                        return $.$$.System.Text.Encoding.UTF8.GetString(memoryStream.GetBuffer(), 0, $.$cast(memoryStream.Length, $.$$.System.Int32));
                    }
                    finally
                    {
                        {
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    memoryStream?.System$IDisposable$Dispose();
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.ClassName = "System.IdentityModel.Tokens.Jwt.JwtHeader";
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultHeaderParameters = (() =>
                    {
                        //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                        const $t1 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add("alg"/*JwtHeaderParameterNames.Alg*/);
                        $i1.Add("kid"/*JwtHeaderParameterNames.Kid*/);
                        $i1.Add("x5t"/*JwtHeaderParameterNames.X5t*/);
                        $i1.Add("enc"/*JwtHeaderParameterNames.Enc*/);
                        $i1.Add("zip"/*JwtHeaderParameterNames.Zip*/);
                        return $i1;
                    })();
                }
            }
            static $h = 253857;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":64424763297,"f":50331649},"s":{"r":0,"d":0,"h":68719730593,"f":83886082},"n":"Alg","d":253857,"h":60129796001,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":77309665185,"f":50331649},"s":{"r":0,"d":0,"h":81604632481,"f":83886082},"n":"Cty","d":253857,"h":73014697889,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":90194567073,"f":50331649},"s":{"r":0,"d":0,"h":94489534369,"f":83886082},"n":"Enc","d":253857,"h":85899599777,"f":2097153},{"p":3972145,"g":{"r":0,"d":0,"h":107374436257,"f":50331649},"s":{"r":0,"d":0,"h":111669403553,"f":83886082},"n":"EncryptingCredentials","d":253857,"h":103079468961,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":120259338145,"f":50331649},"n":"IV","d":253857,"h":115964370849,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":128849272737,"f":50331649},"s":{"r":0,"d":0,"h":133144240033,"f":83886082},"n":"Kid","d":253857,"h":124554305441,"f":2097153},{"p":15965233,"g":{"r":0,"d":0,"h":146029141921,"f":50331649},"s":{"r":0,"d":0,"h":150324109217,"f":83886082},"n":"SigningCredentials","d":253857,"h":141734174625,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":158914043809,"f":50331649},"s":{"r":0,"d":0,"h":163209011105,"f":83886082},"n":"Typ","d":253857,"h":154619076513,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":171798945697,"f":50331649},"n":"X5t","d":253857,"h":167503978401,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":180388880289,"f":50331649},"n":"X5c","d":253857,"h":176093912993,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":188978814881,"f":50331649},"n":"Zip","d":253857,"h":184683847585,"f":2097153}],"m":[{"r":253857,"p":[{"n":"base64UrlEncodedJsonString","p":1310721}],"n":"Base64UrlDeserialize","d":253857,"h":193273782177,"f":16777249},{"r":1310721,"n":"Base64UrlEncode","d":253857,"h":197568749473,"f":16777345},{"r":1310721,"p":[{"n":"claimType","p":1310721}],"n":"GetStandardClaim","d":253857,"h":201863716769,"f":16777224},{"r":65537,"p":[{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"setDefaultCtyClaim","p":262145}],"n":"AddAdditionalClaims","d":253857,"h":206158684065,"f":16777224},{"r":1310721,"n":"SerializeToJson","d":253857,"h":214748618657,"f":16777345}],"l":[{"t":1310721,"n":"ClassName","d":253857,"h":4295221153,"f":4194312},{"t":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,"n":"DefaultHeaderParameters","d":253857,"h":210453651361,"f":4194344}],"c":[{"n":".ctor","o":"$ctor$10","d":253857,"h":8590188449,"f":16777217},{"p":[{"n":"json","p":1310721}],"n":".ctor","o":"$ctor$11","d":253857,"h":12885155745,"f":16777224},{"p":[{"n":"signingCredentials","p":15965233}],"n":".ctor","o":"$ctor$21","d":253857,"h":17180123041,"f":16777217},{"p":[{"n":"encryptingCredentials","p":3972145}],"n":".ctor","o":"$ctor$16","d":253857,"h":21475090337,"f":16777217},{"p":[{"n":"signingCredentials","p":15965233},{"n":"outboundAlgorithmMap","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h}],"n":".ctor","o":"$ctor$20","d":253857,"h":25770057633,"f":16777217},{"p":[{"n":"signingCredentials","p":15965233},{"n":"outboundAlgorithmMap","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h},{"n":"tokenType","p":1310721}],"n":".ctor","o":"$ctor$19","d":253857,"h":30065024929,"f":16777217},{"p":[{"n":"signingCredentials","p":15965233},{"n":"outboundAlgorithmMap","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h},{"n":"tokenType","p":1310721},{"n":"additionalInnerHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"includeKeyIdInHeader","p":262145}],"n":".ctor","o":"$ctor$17","d":253857,"h":34359992225,"f":16777224},{"p":[{"n":"signingCredentials","p":15965233},{"n":"outboundAlgorithmMap","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h},{"n":"tokenType","p":1310721},{"n":"additionalInnerHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":".ctor","o":"$ctor$18","d":253857,"h":38654959521,"f":16777217},{"p":[{"n":"encryptingCredentials","p":3972145},{"n":"outboundAlgorithmMap","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h}],"n":".ctor","o":"$ctor$15","d":253857,"h":42949926817,"f":16777217},{"p":[{"n":"encryptingCredentials","p":3972145},{"n":"outboundAlgorithmMap","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h},{"n":"tokenType","p":1310721}],"n":".ctor","o":"$ctor$14","d":253857,"h":47244894113,"f":16777217},{"p":[{"n":"encryptingCredentials","p":3972145},{"n":"outboundAlgorithmMap","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h},{"n":"tokenType","p":1310721},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"includeKeyIdInHeader","p":262145}],"n":".ctor","o":"$ctor$12","d":253857,"h":51539861409,"f":16777224},{"p":[{"n":"encryptingCredentials","p":3972145},{"n":"outboundAlgorithmMap","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h},{"n":"tokenType","p":1310721},{"n":"additionalHeaderClaims","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":".ctor","o":"$ctor$13","d":253857,"h":55834828705,"f":16777217}],"i":[$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,$.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,31588353,31457281,$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,31719425,113246209,112984065],"h":253857}; }
            static get $b() { return $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object), $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtHeader`; }
        });
        
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload", ($self) => class JwtPayload extends $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object)
        {
            /*string*/ static ClassName = null;
            /*List<string>*/ _audiences = null;
            /*string*/ _azp = null;
            /*long?*/ _exp = null;
            /*DateTime?*/ _expDateTime = null;
            /*long?*/ _iat = null;
            /*DateTime?*/ _iatDateTime = null;
            /*string*/ _id = null;
            /*string*/ _iss = null;
            /*string*/ _jti = null;
            /*long?*/ _nbf = null;
            /*DateTime?*/ _nbfDateTime = null;
            /*string*/ _sub = null;
            /*string*/ _tid = null;
            $ctor$10()
            {
                this.$ctor$15(null, null, null, null, null);
                {
                }
                return this;
            }
            static /*JwtPayload */ CreatePayload(/*byte[]*/ bytes, /*int*/ length)
            {
                /*JwtPayload*/ let payload = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload().$ctor$10();
                /*Utf8JsonReader*/ let reader = new $.$stj.System.Text.Json.Utf8JsonReader().$ctor$4($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$14($.$$.System.Byte, bytes).Slice(0, length)), new $.$stj.System.Text.Json.JsonReaderOptions());
                if (!$.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 1/*JsonTokenType.StartObject*/, true))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$stj.System.Text.Json.JsonException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX11023: Expecting json reader to be positioned on '{0}', reader was positioned at: '{1}', Reading: '{2}', Position: '{3}', CurrentDepth: '{4}', BytesConsumed: '{5}'."/*Microsoft.IdentityModel.Tokens.LogMessages.IDX11023*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("JsonTokenType.StartObject"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenType, $.$stj.System.Text.Json.JsonTokenType)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenStartIndex, $.$$.System.Int64)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.CurrentDepth, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.BytesConsumed, $.$$.System.Int64)) ], null, null))));
                }
                while(true)
                {
                    if (reader.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Aud))
                        {
                            reader.Read();
                            payload._audiences = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                            if (reader.TokenType === 3/*JsonTokenType.StartArray*/)
                            {
                                $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadStrings$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), payload._audiences, "aud"/*JwtRegisteredClaimNames.Aud*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, false);
                                payload.set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, payload._audiences);
                            }
                            else 
                            {
                                payload._audiences.Add($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "aud"/*JwtRegisteredClaimNames.Aud*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, false));
                                payload.set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, payload._audiences.get_Item(0));
                            }
                        }
                        else if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Exp))
                        {
                            payload._exp = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadLong($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "exp"/*JwtRegisteredClaimNames.Exp*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("exp"/*JwtRegisteredClaimNames.Exp*/, $.$box(payload._exp, $.$$.System.Nullable$$($.$$.System.Int64)));
                            payload._expDateTime = $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(payload._exp));
                        }
                        else if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iat))
                        {
                            payload._iat = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadLong($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "iat"/*JwtRegisteredClaimNames.Iat*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("iat"/*JwtRegisteredClaimNames.Iat*/, $.$box(payload._iat, $.$$.System.Nullable$$($.$$.System.Int64)));
                            payload._iatDateTime = $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(payload._iat));
                        }
                        else if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iss))
                        {
                            payload._iss = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "iss"/*JwtRegisteredClaimNames.Iss*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("iss"/*JwtRegisteredClaimNames.Iss*/, payload._iss);
                        }
                        else if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Jti))
                        {
                            payload._jti = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "jti"/*JwtRegisteredClaimNames.Jti*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("jti"/*JwtRegisteredClaimNames.Jti*/, payload._jti);
                        }
                        else if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Nbf))
                        {
                            payload._nbf = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadLong($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "nbf"/*JwtRegisteredClaimNames.Nbf*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload._nbfDateTime = $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(payload._nbf));
                            payload.set_Item("nbf"/*JwtRegisteredClaimNames.Nbf*/, $.$box(payload._nbf, $.$$.System.Nullable$$($.$$.System.Int64)));
                        }
                        else if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Sub))
                        {
                            payload._sub = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadStringOrNumberAsString($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "sub"/*JwtRegisteredClaimNames.Sub*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("sub"/*JwtRegisteredClaimNames.Sub*/, payload._sub);
                        }
                        else 
                        {
                            /*string*/ let propertyName = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyName($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item(propertyName, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyValueAsObject($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), propertyName, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, false));
                        }
                    }
                    else if ($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 2/*JsonTokenType.EndObject*/, true))
                    {
                        break;
                    }
                    else if (!reader.Read())
                    {
                        break;
                    }
                }
                return payload;
            }
            $ctor$11(/*IEnumerable<Claim>*/ claims)
            {
                this.$ctor$15(null, null, claims, null, null);
                {
                }
                return this;
            }
            $ctor$15(/*string*/ issuer, /*string*/ audience, /*IEnumerable<Claim>*/ claims, /*DateTime?*/ notBefore, /*DateTime?*/ expires)
            {
                this.$ctor$14(issuer, audience, claims, notBefore?.Clone() ?? null, expires?.Clone() ?? null, null);
                {
                }
                return this;
            }
            $ctor$14(/*string*/ issuer, /*string*/ audience, /*IEnumerable<Claim>*/ claims, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                super.$ctor$6($.$$.System.StringComparer.Ordinal);
                {
                    if (claims !== null)
                    {
                        this.AddClaims(claims);
                    }
                    this.AddFirstPriorityClaims$1(issuer, audience, notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
                }
                return this;
            }
            $ctor$12(/*string*/ issuer, /*IList<string>*/ audiences, /*IEnumerable<Claim>*/ claims, /*IDictionary<string, object>*/ claimsCollection, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                this.$ctor$16(issuer, "", audiences, claims, claimsCollection, notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
                {
                }
                return this;
            }
            $ctor$16(/*string*/ issuer, /*string*/ audience, /*IList<string>*/ audiences, /*IEnumerable<Claim>*/ claims, /*IDictionary<string, object>*/ claimsCollection, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                super.$ctor$6($.$$.System.StringComparer.Ordinal);
                {
                    if (claims !== null)
                    {
                        this.AddClaims(claims);
                    }
                    if (claimsCollection !== null && $.$sl.System.Linq.Enumerable.Any$1($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object), claimsCollection))
                    {
                        this.AddDictionaryClaims(claimsCollection);
                    }
                    if (audiences !== null)
                    {
                        this.AddFirstPriorityClaims(issuer, audience, audiences, notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
                    }
                    else 
                    {
                        this.AddFirstPriorityClaims(issuer, audience, (() =>
                        {
                            let $t1 = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                            return $t1;
                        })(), notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
                    }
                }
                return this;
            }
            /*void */ AddFirstPriorityClaims$1(/*string*/ issuer, /*string*/ audience, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                this.AddFirstPriorityClaims(issuer, audience, (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    return $t1;
                })(), notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
            }
            $ctor$13(/*string*/ issuer, /*string*/ audience, /*IEnumerable<Claim>*/ claims, /*IDictionary<string, object>*/ claimsCollection, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                this.$ctor$16(issuer, audience, (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    return $t1;
                })(), claims, claimsCollection, notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
                {
                }
                return this;
            }
            /*void */ AddFirstPriorityClaims(/*string*/ issuer, /*string*/ audience, /*IList<string>*/ audiences, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(expires))
                {
                    if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(notBefore))
                    {
                        if ($.$$.System.DateTime.op_GreaterThanOrEqual($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(notBefore), $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(expires)))
                        {
                            throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12401: Expires: '{0}' must be after NotBefore: '{1}'."/*LogMessages.IDX12401*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(expires)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(notBefore)) ], null, null))));
                        }
                        this.set_Item("nbf"/*JwtRegisteredClaimNames.Nbf*/, $.$box($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(notBefore).ToUniversalTime()), $.$$.System.Int64));
                    }
                    this.set_Item("exp"/*JwtRegisteredClaimNames.Exp*/, $.$box($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(expires).ToUniversalTime()), $.$$.System.Int64));
                }
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(issuedAt))
                {
                    this.set_Item("iat"/*JwtRegisteredClaimNames.Iat*/, $.$box($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(issuedAt).ToUniversalTime()), $.$$.System.Int64));
                }
                if (!$.$$.System.String.IsNullOrEmpty(issuer))
                {
                    this.set_Item("iss"/*JwtRegisteredClaimNames.Iss*/, issuer);
                }
                if (!$.$$.System.String.IsNullOrEmpty(audience))
                {
                    this.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$7("aud"/*JwtRegisteredClaimNames.Aud*/, audience, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/));
                }
                var $en2 = audiences.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var aud = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (!$.$$.System.String.IsNullOrEmpty(aud))
                        {
                            this.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$7("aud"/*JwtRegisteredClaimNames.Aud*/, aud, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/));
                        }
                    }
                }
            }
            /*string */ get Actort()
            {
                return this.GetStandardClaim("actort"/*JwtRegisteredClaimNames.Actort*/);
            }
            /*string */ get Acr()
            {
                return this.GetStandardClaim("acr"/*JwtRegisteredClaimNames.Acr*/);
            }
            /*IList<string> */ get Amr()
            {
                return this.GetListOfClaims("amr"/*JwtRegisteredClaimNames.Amr*/);
            }
            /*int? */ get AuthTime()
            {
                return this.GetIntClaim("auth_time"/*JwtRegisteredClaimNames.AuthTime*/);
            }
            /*IList<string> */ get Aud()
            {
                if (this._audiences === null)
                {
                    /*List<string>*/ let tmp = this.GetListOfClaims("aud"/*JwtRegisteredClaimNames.Aud*/);
                    $.$$.System.Threading.Interlocked.CompareExchange$14($.$$.System.Collections.Generic.List$$($.$$.System.String), $.$ref(() => this._audiences, ($v) => this._audiences = $v, $.$$.System.Collections.Generic.List$$($.$$.System.String)), tmp, null);
                }
                return this._audiences;
            }
            /*string */ get Azp()
            {
                return this.GetStandardClaim("azp"/*JwtRegisteredClaimNames.Azp*/);
            }
            /*string */ get CHash()
            {
                return this.GetStandardClaim("c_hash"/*JwtRegisteredClaimNames.CHash*/);
            }
            /*int? */ get Exp()
            {
                return this.GetIntClaim("exp"/*JwtRegisteredClaimNames.Exp*/);
            }
            /*long? */ get Expiration()
            {
                return this.GetLongClaim("exp"/*JwtRegisteredClaimNames.Exp*/);
            }
            /*string */ get Jti()
            {
                this._jti ??= this.GetStandardClaim("jti"/*JwtRegisteredClaimNames.Jti*/);
                return this._jti;
            }
            /*int? */ get Iat()
            {
                return this.GetIntClaim("iat"/*JwtRegisteredClaimNames.Iat*/);
            }
            /*string */ get Iss()
            {
                this._iss ??= this.GetStandardClaim("iss"/*JwtRegisteredClaimNames.Iss*/);
                return this._iss;
            }
            /*int? */ get Nbf()
            {
                return this.GetIntClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/);
            }
            /*string */ get Nonce()
            {
                return this.GetStandardClaim("nonce"/*JwtRegisteredClaimNames.Nonce*/);
            }
            /*long? */ get NotBefore()
            {
                return this.GetLongClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/);
            }
            /*string */ get Sub()
            {
                this._sub ??= this.GetStandardClaim("sub"/*JwtRegisteredClaimNames.Sub*/);
                return this._sub;
            }
            /*DateTime */ get ValidFrom()
            {
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(this._nbfDateTime))
                {
                    return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._nbfDateTime);
                }
                /*long?*/ let l = this.GetLongClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/);
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(l))
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(l));
                }
                this._nbfDateTime = $.$$.System.DateTime.MinValue;
                return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._nbfDateTime);
            }
            /*DateTime */ get ValidTo()
            {
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(this._expDateTime))
                {
                    return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._expDateTime);
                }
                /*long?*/ let l = this.GetLongClaim("exp"/*JwtRegisteredClaimNames.Exp*/);
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(l))
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(l));
                }
                this._expDateTime = $.$$.System.DateTime.MinValue;
                return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._expDateTime);
            }
            /*DateTime */ get IssuedAt()
            {
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(this._iatDateTime))
                {
                    return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._iatDateTime);
                }
                /*long?*/ let l = this.GetLongClaim("iat"/*JwtRegisteredClaimNames.Iat*/);
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(l))
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(l));
                }
                this._iatDateTime = $.$$.System.DateTime.MinValue;
                return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._iatDateTime);
            }
            /*IEnumerable<Claim> */ get Claims()
            {
                /*List<Claim>*/ let claims = new ($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$1();
                /*string*/ let issuer = this.Iss ?? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                var $en2 = this.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var keyValuePair = $en2.Current;
                    {
                        let str;
                        let j;
                        let objects;
                        let dictionary;
                        let dateTime;
                        let boolValue;
                        if (keyValuePair.Value === null)
                        {
                            claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, $.$$.System.String.Empty, "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/, issuer, issuer));
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.System.String, { set $v(v){ str = v; } }))
                        {
                            claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, str, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.GetClaimValueType(keyValuePair.Key, str), issuer, issuer));
                        }
                        else if ($.$is(keyValuePair.Value, $.$stj.System.Text.Json.JsonElement, { set $v(v){ j = v; } }))
                        {
                            $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.AddClaimsFromJsonElement(keyValuePair.Key, issuer, j, claims);
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object), { set $v(v){ objects = v; } }))
                        {
                            this.AddListofObjects(keyValuePair.Key, objects, claims, issuer);
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object), { set $v(v){ dictionary = v; } }))
                        {
                            var $en5 = dictionary.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var item = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    if (item.Value !== null)
                                    {
                                        claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, "{" + item.Key + ":" + $.$$.System.Object.ToString.call(item.Value) + "}", $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.GetClaimValueType(item.Key, item.Value), issuer, issuer));
                                    }
                                }
                            }
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.System.DateTime, { set $v(v){ dateTime = v; } }))
                        {
                            claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, dateTime.ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/, issuer, issuer));
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.System.Boolean, { set $v(v){ boolValue = v; } }))
                        {
                            if (boolValue)
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, "true", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                            }
                            else 
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, "false", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                            }
                        }
                        else if (keyValuePair.Value !== null)
                        {
                            /*var*/ let value = keyValuePair.Value;
                            /*var*/ let claimValueType = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.GetClaimValueType(keyValuePair.Key, value);
                            let formattable;
                            if ($.$is(value, $.$$.System.IFormattable, { set $v(v){ formattable = v; } }))
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, formattable.System$IFormattable$ToString(null, $.$$.System.Globalization.CultureInfo.InvariantCulture), claimValueType, issuer, issuer));
                            }
                            else 
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, $.$$.System.Object.ToString.call(value), claimValueType, issuer, issuer));
                            }
                        }
                    }
                }
                return claims;
            }
            /*void */ AddListofObjects(/*string*/ key, /*IEnumerable<object>*/ objects, /*List<Claim>*/ claims, /*string*/ issuer)
            {
                var $en2 = objects.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var obj = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        let claimValue;
                        let boolValue;
                        let dateTimeValue;
                        let jsonElement;
                        let innerObjects;
                        if ($.$is(obj, $.$$.System.String, { set $v(v){ claimValue = v; } }))
                        {
                            claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(key, claimValue, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, issuer, issuer));
                        }
                        else if ($.$is(obj, $.$$.System.Boolean, { set $v(v){ boolValue = v; } }))
                        {
                            if (boolValue)
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(key, "true", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                            }
                            else 
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(key, "false", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                            }
                        }
                        else if ($.$is(obj, $.$$.System.DateTime, { set $v(v){ dateTimeValue = v; } }))
                        {
                            claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(key, dateTimeValue.ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/, issuer, issuer));
                        }
                        else if ($.$is(obj, $.$stj.System.Text.Json.JsonElement, { set $v(v){ jsonElement = v; } }))
                        {
                            claims.Add($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromJsonElement(key, issuer, jsonElement));
                        }
                        else if ($.$is(obj, $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object), { set $v(v){ innerObjects = v; } }))
                        {
                            this.AddListofObjects(key, innerObjects, claims, issuer);
                        }
                        else 
                        {
                            /*var*/ let claimValueType = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.GetClaimValueType(key, obj);
                            let formattable;
                            if ($.$is(obj, $.$$.System.IFormattable, { set $v(v){ formattable = v; } }))
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(key, formattable.System$IFormattable$ToString(null, $.$$.System.Globalization.CultureInfo.InvariantCulture), claimValueType, issuer, issuer));
                            }
                            else 
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(key, $.$$.System.Object.ToString.call(obj), claimValueType, issuer, issuer));
                            }
                        }
                    }
                }
            }
            static /*void */ AddClaimsFromJsonElement(/*string*/ claimType, /*string*/ issuer, /*JsonElement*/ jsonElement, /*List<Claim>*/ claims)
            {
                if (jsonElement.ValueKind === 2/*JsonValueKind.Array*/)
                {
                    var $en3 = jsonElement.EnumerateArray().GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var element = $en3.Current;
                        {
                            claims.Add($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromJsonElement(claimType, issuer, element));
                        }
                    }
                }
                else 
                {
                    claims.Add($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromJsonElement(claimType, issuer, jsonElement));
                }
            }
            /*void */ AddClaim(/*Claim*/ claim)
            {
                if (claim === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("claim"));
                }
                this.AddClaims($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$ssc.System.Security.Claims.Claim), [claim], [-1], null));
            }
            /*void */ AddClaims(/*IEnumerable<Claim>*/ claims)
            {
                if (claims === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("claims"));
                }
                var $en2 = claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        /*string*/ let jsonClaimType = claim.Type;
                        /*object*/ let jsonClaimValue = $.$$.System.String.Equals$5.call(claim.ValueType, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/) ? claim.Value : $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetClaimValueUsingValueType(claim);
                        /*object*/ let existingValue;
                        if (this.TryGetValue(jsonClaimType, $.$ref(() => existingValue, ($v) => existingValue = $v, $.$$.System.Object)))
                        {
                            /*IList<object>*/ let claimValues = $.$as(existingValue, $.$$.System.Collections.Generic.IList$$($.$$.System.Object));
                            if (claimValues === null)
                            {
                                claimValues = new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                                claimValues.System$Collections$Generic$ICollection$$$Add(existingValue, [$.$$.System.Object]);
                                this.set_Item(jsonClaimType, claimValues);
                            }
                            claimValues.System$Collections$Generic$ICollection$$$Add(jsonClaimValue, [$.$$.System.Object]);
                        }
                        else 
                        {
                            this.set_Item(jsonClaimType, jsonClaimValue);
                        }
                    }
                }
            }
            /*void */ AddDictionaryClaims(/*IDictionary<string, object>*/ claimsCollection)
            {
                if (claimsCollection === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("claimsCollection"));
                }
                var $en2 = claimsCollection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var kvp = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.set_Item(kvp.Key, kvp.Value);
                    }
                }
            }
            static /*string */ GetClaimValueType(/*string*/ claimType, /*object*/ value)
            {
                if (value === null)
                {
                    return "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/;
                }
                /*Type*/ let objType = $.$$.System.Object.GetType.call(value);
                let str;
                if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                {
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetStringClaimValueType(str, claimType);
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Int32.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#integer32"/*ClaimValueTypes.Integer32*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Int64.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#integer64"/*ClaimValueTypes.Integer64*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Boolean.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Double.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Single.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Decimal.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/;
                }
                else if (value === null)
                {
                    return "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$stj.System.Text.Json.JsonElement.$type))
                {
                    return "JSON"/*JsonClaimValueTypes.Json*/;
                }
                return $.$$.System.Type.ToString.call(objType);
            }
            /*string */ GetStandardClaim(/*string*/ claimType)
            {
                /*object*/ let value;
                if (this.TryGetValue(claimType, $.$ref(() => value, ($v) => value = $v, $.$$.System.Object)))
                {
                    if (value === null)
                    {
                        return null;
                    }
                    let str;
                    if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                    {
                        return str;
                    }
                    return $.$$.System.String.Empty;
                }
                return null;
            }
            /*int? */ GetIntClaim(/*string*/ claimType)
            {
                /*object*/ let claimValue;
                if (this.TryGetValue(claimType, $.$ref(() => claimValue, ($v) => claimValue = $v, $.$$.System.Object)))
                {
                    /*int*/ let i = 0;
                    if ($.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.TryConvertToInt(claimValue, $.$ref(() => i, ($v) => i = $v, $.$$.System.Int32)))
                    {
                        return i;
                    }
                }
                return null;
            }
            /*long? */ GetLongClaim(/*string*/ claimType)
            {
                /*object*/ let claimValue;
                if (this.TryGetValue(claimType, $.$ref(() => claimValue, ($v) => claimValue = $v, $.$$.System.Object)))
                {
                    /*long*/ let l = 0n;
                    if ($.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.TryConvertToLong(claimValue, $.$ref(() => l, ($v) => l = $v, $.$$.System.Int64)))
                    {
                        return l;
                    }
                }
                return null;
            }
            static /*bool */ TryConvertToInt(/*object*/ value, /*ref int*/ outVal)
            {
                outVal.$v = 0;
                try
                {
                    let i;
                    if ($.$is(value, $.$$.System.Int32, { set $v(v){ i = v; } }))
                    {
                        outVal.$v = i;
                        return true;
                    }
                    let str;
                    if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                    {
                        /*int*/ let result;
                        if ($.$$.System.Int32.TryParse$8(str, $.$ref(() => result, ($v) => result = $v, $.$$.System.Int32)))
                        {
                            outVal.$v = result;
                            return true;
                        }
                    }
                    outVal.$v = $.$$.System.Convert.ToInt32$5($.$$.System.Math.Truncate$1($.$$.System.Convert.ToDouble$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture)));
                    return true;
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.FormatException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.System.OverflowException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.System.InvalidCastException)
                    {
                        return false;
                    }
                    else
                    {
                        throw $e;
                    }
                }
                return false;
            }
            static /*bool */ TryConvertToLong(/*object*/ value, /*ref long*/ outVal)
            {
                outVal.$v = 0n;
                try
                {
                    let l;
                    if ($.$is(value, $.$$.System.Int64, { set $v(v){ l = v; } }))
                    {
                        outVal.$v = l;
                        return true;
                    }
                    let str;
                    if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                    {
                        /*long*/ let result;
                        if ($.$$.System.Int64.TryParse$8(str, $.$ref(() => result, ($v) => result = $v, $.$$.System.Int64)))
                        {
                            outVal.$v = result;
                            return true;
                        }
                    }
                    outVal.$v = $.$$.System.Convert.ToInt64$5($.$$.System.Math.Truncate$1($.$$.System.Convert.ToDouble$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture)));
                    return true;
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.FormatException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.System.OverflowException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.System.InvalidCastException)
                    {
                        return false;
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*List<string> */ GetListOfClaims(/*string*/ claimType)
            {
                /*List<string>*/ let claimValues = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                /*object*/ let value;
                if (!this.TryGetValue(claimType, $.$ref(() => value, ($v) => value = $v, $.$$.System.Object)))
                {
                    return claimValues;
                }
                let jsonElement;
                let str;
                let values;
                if ($.$is(value, $.$stj.System.Text.Json.JsonElement, { set $v(v){ jsonElement = v; } }))
                {
                    /*List<string>*/ let list;
                    if ($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.TryCreateTypeFromJsonElement($.$$.System.Collections.Generic.List$$($.$$.System.String), jsonElement, $.$ref(() => list, ($v) => list = $v, $.$$.System.Collections.Generic.List$$($.$$.System.String))))
                    {
                        return list;
                    }
                }
                else if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                {
                    claimValues.Add(str);
                }
                else if ($.$is(value, $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object), { set $v(v){ values = v; } }))
                {
                    var $en3 = values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            claimValues.Add($.$$.System.Object.ToString.call(item));
                        }
                    }
                }
                else 
                {
                    claimValues.Add($.$$.System.Object.ToString.call(value));
                }
                return claimValues;
            }
            /*string */ SerializeToJson()
            {
                let memoryStream = null;
                try
                {
                    memoryStream = new $.$$.System.IO.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    try
                    {
                        writer = new $.$stj.System.Text.Json.Utf8JsonWriter().$ctor$2(memoryStream, (() =>
                        {
                            //new $.$stj.System.Text.Json.JsonWriterOptions()
                            const $t1 = $.$stj.System.Text.Json.JsonWriterOptions;
                            const $i1 = new $t1();
                            $i1.Encoder = $.$stew.System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i1;
                        })());
                        writer.WriteStartObject();
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObjects($.$ref(() => writer, ($v) => writer = $v, $.$stj.System.Text.Json.Utf8JsonWriter), this);
                        writer.WriteEndObject();
                        writer.Flush();
                        return $.$$.System.Text.Encoding.UTF8.GetString(memoryStream.GetBuffer(), 0, $.$cast(memoryStream.Length, $.$$.System.Int32));
                    }
                    finally
                    {
                        {
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    memoryStream?.System$IDisposable$Dispose();
                }
            }
            static /*JwtPayload */ Base64UrlDeserialize(/*string*/ base64UrlEncodedJsonString)
            {
                _ = $.$firstOf(base64UrlEncodedJsonString, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("base64UrlEncodedJsonString") });
                return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoding.Decode$5($.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload, base64UrlEncodedJsonString, 0, base64UrlEncodedJsonString.length, new ($.$$.System.Func$$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload))().$ctor($.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.CreatePayload));
            }
            /*string */ Base64UrlEncode()
            {
                return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$3(this.SerializeToJson());
            }
            static /*JwtPayload */ Deserialize(/*string*/ jsonString)
            {
                _ = $.$firstOf(jsonString, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jsonString") });
                /*byte[]*/ let bytes = $.$$.System.Text.Encoding.UTF8.GetBytes$8(jsonString);
                return $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.CreatePayload(bytes, bytes.length);
            }
            //default member initializer
            constructor()
            {
                super();
                this._expDateTime = null;
                this._iatDateTime = null;
                this._nbfDateTime = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ClassName = "System.IdentityModel.Tokens.Jwt.JwtPayload";
                }
            }
            static $h = 384929;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":111669534625,"f":50331649},"n":"Actort","d":384929,"h":107374567329,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":120259469217,"f":50331649},"n":"Acr","d":384929,"h":115964501921,"f":2097153},{"p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":128849403809,"f":50331649},"n":"Amr","d":384929,"h":124554436513,"f":2097153},{"p":$.$typeNullable($.$$.System.Int32).$h,"g":{"r":0,"d":0,"h":137439338401,"f":50331649},"n":"AuthTime","d":384929,"h":133144371105,"f":2097153},{"p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":146029272993,"f":50331649},"n":"Aud","d":384929,"h":141734305697,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":154619207585,"f":50331649},"n":"Azp","d":384929,"h":150324240289,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":163209142177,"f":50331649},"n":"CHash","d":384929,"h":158914174881,"f":2097153},{"p":$.$typeNullable($.$$.System.Int32).$h,"g":{"r":0,"d":0,"h":171799076769,"f":50331649},"n":"Exp","d":384929,"h":167504109473,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"\u0060int? JwtPayload.Exp\u0060 is deprecated and will be removed in a future release. Use \u0060long? JwtPayload.Expiration\u0060 instead. For more information, see https://aka.ms/IdentityModel/7-breaking-changes","t":1310721}]}]},{"p":$.$typeNullable($.$$.System.Int64).$h,"g":{"r":0,"d":0,"h":180389011361,"f":50331649},"n":"Expiration","d":384929,"h":176094044065,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":188978945953,"f":50331649},"n":"Jti","d":384929,"h":184683978657,"f":2097153},{"p":$.$typeNullable($.$$.System.Int32).$h,"g":{"r":0,"d":0,"h":197568880545,"f":50331649},"n":"Iat","d":384929,"h":193273913249,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"\u0060int? JwtPayload.Iat\u0060 is deprecated and will be removed in a future release. Use \u0060DateTime JwtPayload.IssuedAt\u0060 instead. For more information, see https://aka.ms/IdentityModel/7-breaking-changes","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":206158815137,"f":50331649},"n":"Iss","d":384929,"h":201863847841,"f":2097153},{"p":$.$typeNullable($.$$.System.Int32).$h,"g":{"r":0,"d":0,"h":214748749729,"f":50331649},"n":"Nbf","d":384929,"h":210453782433,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"\u0060int? JwtPayload.Nbf\u0060 is deprecated and will be removed in a future release. Use \u0060long? JwtPayload.NotBefore\u0060 instead. For more information, see https://aka.ms/IdentityModel/7-breaking-changes","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":223338684321,"f":50331649},"n":"Nonce","d":384929,"h":219043717025,"f":2097153},{"p":$.$typeNullable($.$$.System.Int64).$h,"g":{"r":0,"d":0,"h":231928618913,"f":50331649},"n":"NotBefore","d":384929,"h":227633651617,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":240518553505,"f":50331649},"n":"Sub","d":384929,"h":236223586209,"f":2097153},{"p":34275329,"g":{"r":0,"d":0,"h":249108488097,"f":50331649},"n":"ValidFrom","d":384929,"h":244813520801,"f":2097153},{"p":34275329,"g":{"r":0,"d":0,"h":257698422689,"f":50331649},"n":"ValidTo","d":384929,"h":253403455393,"f":2097153},{"p":34275329,"g":{"r":0,"d":0,"h":266288357281,"f":50331649},"n":"IssuedAt","d":384929,"h":261993389985,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,"g":{"r":0,"d":0,"h":274878291873,"f":50331777},"n":"Claims","d":384929,"h":270583324577,"f":2097281}],"m":[{"r":384929,"p":[{"n":"bytes","p":$.$typeArray($.$$.System.Byte).$h},{"n":"length","p":655361}],"n":"CreatePayload","d":384929,"h":68719861665,"f":16777256},{"r":65537,"p":[{"n":"issuer","p":1310721},{"n":"audience","p":1310721},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"issuedAt","p":$.$typeNullable($.$$.System.DateTime).$h}],"n":"AddFirstPriorityClaims","o":"@$1","d":384929,"h":94489665441,"f":16777224},{"r":65537,"p":[{"n":"issuer","p":1310721},{"n":"audience","p":1310721},{"n":"audiences","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"issuedAt","p":$.$typeNullable($.$$.System.DateTime).$h}],"n":"AddFirstPriorityClaims","d":384929,"h":103079600033,"f":16777224},{"r":65537,"p":[{"n":"key","p":1310721},{"n":"objects","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object).$h},{"n":"claims","p":$.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"issuer","p":1310721}],"n":"AddListofObjects","d":384929,"h":279173259169,"f":16777218},{"r":65537,"p":[{"n":"claimType","p":1310721},{"n":"issuer","p":1310721},{"n":"jsonElement","p":2143171},{"n":"claims","p":$.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"AddClaimsFromJsonElement","d":384929,"h":283468226465,"f":16777256},{"r":65537,"p":[{"n":"claim","p":164318}],"n":"AddClaim","d":384929,"h":287763193761,"f":16777217},{"r":65537,"p":[{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":"AddClaims","d":384929,"h":292058161057,"f":16777217},{"r":65537,"p":[{"n":"claimsCollection","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"AddDictionaryClaims","d":384929,"h":296353128353,"f":16777224},{"r":1310721,"p":[{"n":"claimType","p":1310721},{"n":"value","p":131073}],"n":"GetClaimValueType","d":384929,"h":300648095649,"f":16777250},{"r":1310721,"p":[{"n":"claimType","p":1310721}],"n":"GetStandardClaim","d":384929,"h":304943062945,"f":16777224},{"r":$.$typeNullable($.$$.System.Int32).$h,"p":[{"n":"claimType","p":1310721}],"n":"GetIntClaim","d":384929,"h":309238030241,"f":16777224},{"r":$.$typeNullable($.$$.System.Int64).$h,"p":[{"n":"claimType","p":1310721}],"n":"GetLongClaim","d":384929,"h":313532997537,"f":16777224},{"r":262145,"p":[{"n":"value","p":131073},{"n":"outVal","p":655361,"f":4}],"n":"TryConvertToInt","d":384929,"h":317827964833,"f":16777250},{"r":262145,"p":[{"n":"value","p":131073},{"n":"outVal","p":917505,"f":4}],"n":"TryConvertToLong","d":384929,"h":322122932129,"f":16777250},{"r":$.$$.System.Collections.Generic.List$$($.$$.System.String).$h,"p":[{"n":"claimType","p":1310721}],"n":"GetListOfClaims","d":384929,"h":326417899425,"f":16777224},{"r":1310721,"n":"SerializeToJson","d":384929,"h":330712866721,"f":16777345},{"r":384929,"p":[{"n":"base64UrlEncodedJsonString","p":1310721}],"n":"Base64UrlDeserialize","d":384929,"h":335007834017,"f":16777249},{"r":1310721,"n":"Base64UrlEncode","d":384929,"h":339302801313,"f":16777345},{"r":384929,"p":[{"n":"jsonString","p":1310721}],"n":"Deserialize","d":384929,"h":343597768609,"f":16777249}],"l":[{"t":1310721,"n":"ClassName","d":384929,"h":4295352225,"f":4194344},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.String).$h,"n":"_audiences","d":384929,"h":8590319521,"f":4194312},{"t":1310721,"n":"_azp","d":384929,"h":12885286817,"f":4194312},{"t":$.$typeNullable($.$$.System.Int64).$h,"n":"_exp","d":384929,"h":17180254113,"f":4194312},{"t":$.$typeNullable($.$$.System.DateTime).$h,"n":"_expDateTime","d":384929,"h":21475221409,"f":4194312},{"t":$.$typeNullable($.$$.System.Int64).$h,"n":"_iat","d":384929,"h":25770188705,"f":4194312},{"t":$.$typeNullable($.$$.System.DateTime).$h,"n":"_iatDateTime","d":384929,"h":30065156001,"f":4194312},{"t":1310721,"n":"_id","d":384929,"h":34360123297,"f":4194312},{"t":1310721,"n":"_iss","d":384929,"h":38655090593,"f":4194312},{"t":1310721,"n":"_jti","d":384929,"h":42950057889,"f":4194312},{"t":$.$typeNullable($.$$.System.Int64).$h,"n":"_nbf","d":384929,"h":47245025185,"f":4194312},{"t":$.$typeNullable($.$$.System.DateTime).$h,"n":"_nbfDateTime","d":384929,"h":51539992481,"f":4194312},{"t":1310721,"n":"_sub","d":384929,"h":55834959777,"f":4194312},{"t":1310721,"n":"_tid","d":384929,"h":60129927073,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$10","d":384929,"h":64424894369,"f":16777217},{"p":[{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h}],"n":".ctor","o":"$ctor$11","d":384929,"h":73014828961,"f":16777217},{"p":[{"n":"issuer","p":1310721},{"n":"audience","p":1310721},{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h}],"n":".ctor","o":"$ctor$15","d":384929,"h":77309796257,"f":16777217},{"p":[{"n":"issuer","p":1310721},{"n":"audience","p":1310721},{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"issuedAt","p":$.$typeNullable($.$$.System.DateTime).$h}],"n":".ctor","o":"$ctor$14","d":384929,"h":81604763553,"f":16777217},{"p":[{"n":"issuer","p":1310721},{"n":"audiences","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"claimsCollection","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"issuedAt","p":$.$typeNullable($.$$.System.DateTime).$h}],"n":".ctor","o":"$ctor$12","d":384929,"h":85899730849,"f":16777217},{"p":[{"n":"issuer","p":1310721},{"n":"audience","p":1310721},{"n":"audiences","p":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h},{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"claimsCollection","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"issuedAt","p":$.$typeNullable($.$$.System.DateTime).$h}],"n":".ctor","o":"$ctor$16","d":384929,"h":90194698145,"f":16777217},{"p":[{"n":"issuer","p":1310721},{"n":"audience","p":1310721},{"n":"claims","p":$.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h},{"n":"claimsCollection","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h},{"n":"notBefore","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"expires","p":$.$typeNullable($.$$.System.DateTime).$h},{"n":"issuedAt","p":$.$typeNullable($.$$.System.DateTime).$h}],"n":".ctor","o":"$ctor$13","d":384929,"h":98784632737,"f":16777217}],"i":[$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,$.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,31588353,31457281,$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,31719425,113246209,112984065],"h":384929}; }
            static get $b() { return $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object), $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtPayload`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Collections.Immutable", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.Microsoft.IdentityModel.Logging", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Logging", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.IdentityModel.Tokens", "NetJs.Microsoft.IdentityModel.JsonWebTokens"))